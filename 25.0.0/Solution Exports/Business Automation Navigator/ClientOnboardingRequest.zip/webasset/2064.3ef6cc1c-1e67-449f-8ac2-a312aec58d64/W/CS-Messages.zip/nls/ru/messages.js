/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "Класс",

		// Property list
		properties_file_name: "Имя файла",
		properties_file_save_in: "Сохранить в",
		properties_add_file: "Добавить файл",
		properties_add_mvcp: "Добавить ${0}",
		properties_remove_mvcp: "Удалить из ${0}",
		properties_use_file_name: "Имя файла будет использоваться для этого свойства",

		properties_optional_label: "${0} (необязательно)",

		properties_document_or_folder_not_found: "Не удается найти документ или папку.",
		properties_class_not_found: "Не удается найти класс содержимого.",
		properties_folder_duplicate_item_invalid_prop: "Элемент с таким именем уже существует в этой папке, или вы ввели недопустимое значение свойства.",
		properties_item_invalid_prop: "Вы ввели недопустимое значение для одного или нескольких свойств.",

		properties_invalid_long_value: "Это недопустимое значение. Значение должно быть целым числом, например, 5 или 1349.",
		properties_invalid_float_value: "Недопустимое значение. Значение должно представлять собой число с плавающей запятой, например, 1,2 или 365.",
		properties_min_value: "Минимальное значение: ${0}",
		properties_max_value: "Максимальное значение: ${0}",
		properties_max_length: "Максимальная длина: ${0}",
		properties_invalid_guid: "Недопустимое значение. Значение должно представлять собой глобальный уникальный идентификатор (Globally Unique Identifier, GUID), например: {F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}.",
		properties_value_required: "Это значение является обязательным.",
		properties_unique_value_required: "Это значение должно быть уникальным.",
		properties_file_required: "Требуется файл.",
		properties_invalid_folder_name: "Имя папки не должно содержать ни одного из следующих символов: \\ / : * ? \" < > |",

		properties_move_edit_confirm_msg: "Вы изменяете свойства следующего документа<br>${0}<br><br>Хотите сохранить свои изменения?",
		properties_move_edit_confirm_no: "Нет",
		properties_move_edit_confirm_yes: "Да",
		properties_move_edit_confirm_title: "Подтверждение",
		properties_edit_save_success: "Свойства сохранены.",
		properties_edit_save_failure: "Свойства не сохранены.",
		properties_no_item_selected: "Не выбран элемент.",

		// Content list
		contlist_column_spec_title: "Заголовок",
		contlist_column_spec_name: "Имя",
		contlist_column_spec_version_label: "Версия",
		contlist_column_spec_modified_by: "Изменено",
		contlist_column_spec_mod_date: "Последняя модификация",
		contlist_column_spec_created_by: "Создатель:",
		contlist_column_spec_creation_date: "Создано",
		contlist_column_spec_mime_type: "Тип документа",
		contlist_column_spec_size: "Размер",
		contlist_column_spec_thumbnail: "Свернутое изображение",

		contlist_paging_no_more_items: "Больше нет элементов",
		contlist_paging_of_at_least_items: "${0} из хотя бы ${1} элементов",
		contlist_paging_of_items: "${0} из ${1} элементов",
		contlist_paging_items: "Элементы ${0}",
		contlist_paging_items_per_page: "Элементов на странице: ${0}",

		contlist_checked_out: "Зарезервированные",
		contlist_checked_out_by: "Зарезервировано: ${0}",

		contlist_size_units_B: "B",
		contlist_size_units_KB: "Кб",
		contlist_size_units_MB: "МБ",
		contlist_size_units_GB: "Гб",
		contlist_size_units_TB: "ТБ",

		contlist_missing_server_error: "Сервер не задан.",
		contlist_invalid_server_error: "Сервер '{0}' не существует.",
		contlist_error_retrieving_doc_props: "Ошибка при получении свойств документа.",
		contlist_error_retrieving_folder_props: "Ошибка при получении свойств папки.",
		contlist_checkout_failed: "Не удалось зарезервировать документ",
		contlist_cancel_checkout_failed: "Отмена резервирования завершилась неудачно",
		contlist_rename_folder_failed: "Не удалось переименовать папку.",
		contlist_folder_name_not_unique: "Имя папки должно быть уникальным.",
		contlist_delete_object_failed: "Не получилось удалить объект.",
		contlist_display_properties_failed: "Не удалось показать свойства. ${0}",
		contlist_save_props_failed: "Не удалось сохранить свойства.",
		contlist_upload_failed: "Не удалось закачать версию",
		contlist_add_folder_failed: "Не удалось добавить папку. ${0}",
		contlist_add_document_failed: "Не удалось добавить документ. ${0}",
		contlist_search_failed: "Не удалось извлечь результаты поиска",
		contlist_folder_containees_failed: "Не удалось извлечь содержимое папки",
		contlist_delete_folder_referenced: "Нельзя удалить папку, так как она содержит подпапки.",
		contlist_docs_not_added: "Не удалось найти следующую папку: ${0}",

		contlist_checkout_success: "Документ зарезервирован",
		contlist_delete_success: "Объект удален",
		contlist_rename_folder_success: "Папка переименована",
		contlist_save_props_success: "Свойства сохранены.",
		contlist_cancel_checkout_success: "Отмена резервирования выполнена успешно",
		contlist_upload_version_success: "Версия закачана",
		contlist_add_folder_success: "Папка добавлена.",
		contlist_add_doc_success: "Документ добавлен.",
		contlist_add_docs_success: "Документы добавлены",

		contlist_menu_action_open: "Открыть",
		contlist_menu_action_rename: "Переименовать",
		contlist_menu_action_properties: "Свойства",
		contlist_menu_action_view: "Представление",
		contlist_menu_action_download: "Скачать",
		contlist_menu_action_checkout: "Зарезервировать",
		contlist_menu_action_edit_document: "Изменить документ",
		contlist_menu_action_cancel_checkout: "Отменить резервирование",
		contlist_menu_action_delete_doc: "Удалить документ",
		contlist_menu_action_rename_folder: "Переименовать папку",
		contlist_menu_action_add_folder: "Добавить папку",
		contlist_menu_action_delete_folder: "Удалить папку",
		contlist_menu_action_add_doc: "Добавить документ",
		contlist_menu_action_upload: "Закачать новую версию",

		contlist_document_properties: "Свойства документа",
		contlist_folder_properties: "Свойства папки",
		contlist_folder_name: "Имя папки",

		contlist_cancel_btn_label: "Отмена",
		contlist_add_btn_label: "Добавить",
		contlist_ok_btn_label: "ОК",
		contlist_edit_btn_label: "Изменить",
		contlist_save_btn_label: "Сохранить",
		contlist_upload_btn_label: "Закачать",
		contlist_refresh_btn_label: "Обновить",
		contlist_next_btn_label: "Далее",
		contlist_previous_btn_label: "Назад",

		contlist_delete_folder_confirm: "Вы собираетесь удалить папку ${0}. Продолжить?",
		contlist_delete_doc_confirm: "Вы собираетесь удалить документ ${0}. Продолжить?",

		contlist_no_mimetype: "В этом элементе нет содержимого.",
		contlist_folder_mimetype: "Папка",

		contlist_filter_search_hint: "Поиск документов",
		contlist_filter_folder_hint: "Список папок",

		contlist_root_folder: "Корневая папка",
		contlist_drop_folder_error: "Невозможно добавить папки. Выберите только файлы.",
		contlist_add_in_process: "Дождитесь завершения добавления предыдущего документа, прежде чем добавлять еще один.",
		contlist_add_doc_max_exceeded: "Можно добавить элементы в количестве до ${0}. Вы пытаетесь добавить элементы в количестве ${1}.",
		contlist_progress_success: "Успешно",
		contlist_progress_alert: "Оповещение",
		contlist_progress_error: "Ошибка",
		contlist_progress_uploading: "Закачивание",
		contlist_progress_processing: "Обрабатывается 1 файл",
		contlist_progress_uploading_text: "Закачивается 1 файл",
		contlist_progress_upload_failed: "Возникла проблема",
		contlist_progress_close: "Закрыть",
		progress_ind_uploaded_status: "Закачано",
		progress_ind_uploaded: "Закачан 1 файл",
		progress_ind_uploaded_error: "Обработка не запущена",		
		progress_ind_processing_status: "Обрабатывается",
		progress_ind_processing_err: "Возникла проблема",
		progress_ind_processed: "Обработан 1 файл",	
		progress_ind_failed: "Завершено неудачно",
		progress_ind_review_doc: "Требуется пересмотр",	
		progress_ind_updating: "Обновляется 1 файл",
		progress_ind_updating_status: "изменение",
		progress_ind_update_err: "Возникла проблема",
		progress_ind_timeout: "Истек срок ожидания мониторинга",
		progress_ind_refresh: "Обновить",

		getcontent_ret_versions_error: "Получение серии версий завершилось неудачно",
		getcontent_ret_properties_error: "Получение свойств документа завершилось неудачно",

		contentviewer_test_mode: "Средство просмотра не покажет документы в режиме предварительного просмотра. Надо запустить настольное приложение IBM Navigator.",

		thumbnail_retreival_error: "Получение миниизображения завершилось неудачно.",

		status_10: "Закачано",
		status_20: "Обрабатывается",
		status_25: "Предварительная обработка",
		status_30: "Требуется пересмотр",
		status_40: "Изменяется",
		status_900: "Ошибка обработки",
		status_910: "Ошибка обновления",

		/*do not remove this line*/nop: null
});
