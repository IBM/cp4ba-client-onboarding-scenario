/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
 /**
 * @ignore
 * @instance
 * @memberof ProfileModal
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof ProfileModal
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof ProfileModal
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof ProfileModal
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof ProfileModal
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof ProfileModal
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof ProfileModal
 * @method triggerFormulaUpdates
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 * </table>
 */
workplace_control_InitProfileModal = function (utilities, taskUtils, wpResources, domAttr)
{
    "use strict";
    this._instance =
    {
    	initialUserPreference : {}
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            _hideModel: function _hideModel(view){
                bpmext.log.info("ProfileModal._hideModel LOG >>", view);
                view._instance.emailAddressInput.setVisible(false, true);
                view._instance.languageSingleSelect.setVisible(false, true);
                view._instance.calendarTypeSingleSelect.setVisible(false, true);
                view._instance.notificationCheckbox.setVisible(false, true);
                view._instance.openInNewWindowCheckbox.setVisible(false, true);
                view._instance.modalSection.setVisible(false, true);
                view._instance.jobTitleInput.setVisible(false, true);
                view._instance.phoneNumberInput.setVisible(false, true);
                view.setVisible(false, true);
            },
            _getUserPreference: function _getUserPreference(view) {
                bpmext.log.info("ProfileModal._getUserPreference LOG >>", view);
                try {
                    wpResources.user.get()
                        .then(dojo.hitch(view, function(user) {
                            if (user.userPreferences) {
                            	// keeping initial User Preference 
                            	view._instance.initialUserPreference = user.userPreferences;
                                var taskEmailAddress = wpResources.user.PREFERENCE.taskEmailAddress;
                                var taskNotification = wpResources.user.PREFERENCE.taskNotification;
                                var openInNewWindow = wpResources.user.PREFERENCE.portalOpenTaskInNewWindow;
                                var taskJobTitle = wpResources.user.PREFERENCE.title;
                                var taskPhoneNumber = wpResources.user.PREFERENCE.phoneNumber;
                               
                                var emailAddress = user.userPreferences[taskEmailAddress] ? user.userPreferences[taskEmailAddress] : "";
                                var emailNotification = user.userPreferences[taskNotification] ? user.userPreferences[taskNotification] : false;
                                var jobTitle = user.userPreferences[taskJobTitle] ? user.userPreferences[taskJobTitle] : "";
                                var phoneNumber = user.userPreferences[taskPhoneNumber] ? user.userPreferences[taskPhoneNumber] : "";
                                this._instance.languageSingleSelect = bpmext.ui.getView("LanguageSingleSelect", this);
                                this._instance.calendarTypeSingleSelect = bpmext.ui.getView("CalendarTypeSingleSelect", this);

                                // Set modal title to full name and add a tooltip
                                view._instance.panel.setTitle(user.fullName);
                                var titleEle = view._instance.panel.context.element.querySelector(".panel-title");
                                if (user.fullName != user.userName) {
                                    bpmext.ui.util.showTooltip(
                                        titleEle,
                                        user.fullName + " (" + user.userName + ")",
                                        {horizontalPos: "LEFT", plainText: false, smartPositioning: true, openDelay: 0.5}
                                    );
                                }

                                view._instance.emailAddressInput.setText(emailAddress);

                                if (emailNotification === "true" && emailAddress !== ""){
                                    view._instance.notificationCheckbox.setChecked(true);
                                } else {
                                    view._instance.notificationCheckbox.setChecked(false);
                                }
                                
                                //Load avatar
                                wpResources.avatar.get(user.userName).then( function(avatar) {
                                	view._instance.profileAvatarImage.setImage(avatar.toDataURI(), "External");
                                	//Disable delete avatar button based on isDefault
                                	if (avatar.isDefault == "true") {
                                		view._instance.deleteAvatar.setEnabled(false);
                                	} else {
                                		view._instance.deleteAvatar.setEnabled(true);
                                	}
                                });
                                
                                wpResources.config.get().then(function(mashupsConfig) {
                                    if (user.userPreferences[openInNewWindow]){
                                        if(user.userPreferences[openInNewWindow] == "generalPreference.fields.openTaskInNewWindow.default"){
                                            view._instance.openInNewWindowCheckbox.setChecked(mashupsConfig.openTaskInNewWindow);
                                        }else{
                                            view._instance.openInNewWindowCheckbox.setChecked(user.userPreferences[openInNewWindow] == "generalPreference.fields.openTaskInNewWindow.yes" ? true : false);
                                        }
                                    }else{
                                        view._instance.openInNewWindowCheckbox.setChecked(mashupsConfig.openTaskInNewWindow);
                                    }
                                });
 
                                var taskToMeNotification = user.userPreferences[wpResources.user.PREFERENCE.portalNotificationNewTaskToMe];
                                if (taskToMeNotification !== "false") {
                                    taskToMeNotification = true;
                                } else {
                                	taskToMeNotification = false;
                                }
                                var taskToGroupNotification = user.userPreferences[wpResources.user.PREFERENCE.portalNotificationNewTaskToMyGroup];
                                if (taskToGroupNotification != "true") {
                                    taskToGroupNotification = false;
                                }
 
                                view._instance.taskNotificationCheckbox.setChecked(taskToMeNotification);
                                view._instance.taskNotificationGroupCheckbox.setChecked(taskToGroupNotification);
                                view._instance.jobTitleInput.setText(jobTitle);
                                view._instance.phoneNumberInput.setText(phoneNumber);
                                
                                // Locale, language & Calendar settings
                                var localeFormat = user.userPreferences[wpResources.user.PREFERENCE.localeFormat];
                                var language = user.userPreferences[wpResources.user.PREFERENCE.locale]; 
                                var calendarType = user.userPreferences[wpResources.user.PREFERENCE.calendarType];
								localeFormat = localeFormat ? localeFormat : taskUtils.DEFAULT_LANGUAGE.EN;
								language = language ? language : taskUtils.DEFAULT_LANGUAGE.EN;
								calendarType = calendarType ? calendarType : taskUtils.CALENDAR_TYPES.gregorian;
                                view._instance.languageSingleSelect.setSelectedItem(language);
                                view._instance.calendarTypeSingleSelect.setSelectedItem(calendarType);
                            
                                // Disable the fields if not editable
                                if (user.editableUserPreferences) {
                                    var emailAddressEditable = user.editableUserPreferences.indexOf(taskEmailAddress) !== -1;
                                    var notificationEditable = user.editableUserPreferences.indexOf(taskNotification) !== -1;
                                    var openInNewWindowEditable = user.editableUserPreferences.indexOf(openInNewWindow) !== -1;
                                    var taskToMeNotificationEditable = user.editableUserPreferences.indexOf(wpResources.user.PREFERENCE.portalNotificationNewTaskToMe) !== -1;
                                    var taskToGroupNotificationEditable = user.editableUserPreferences.indexOf(wpResources.user.PREFERENCE.portalNotificationNewTaskToMyGroup) !== -1;
                                    var jobTitleEditable = user.editableUserPreferences.indexOf(taskJobTitle) !== -1;
                                    var phoneNumberEditable = user.editableUserPreferences.indexOf(taskPhoneNumber) !== -1;
                                    var languageSingleSelectEditable  = user.editableUserPreferences.indexOf(wpResources.user.PREFERENCE.locale) !== -1;
                                    var calendarTypeSingleSelectEditable   = user.editableUserPreferences.indexOf(wpResources.user.PREFERENCE.calendarType) !== -1;
                                    
                                    view._instance.notificationEditable = notificationEditable;
                                    view._instance.emailAddressInput.setEnabled(emailAddressEditable);
                                    view._instance.notificationCheckbox.setEnabled(notificationEditable && emailAddress !== "");
                                    view._instance.openInNewWindowCheckbox.setEnabled(openInNewWindowEditable);
                                    view._instance.taskNotificationCheckbox.setEnabled(taskToMeNotificationEditable);
                                    view._instance.taskNotificationGroupCheckbox.setEnabled(taskToGroupNotificationEditable);
                                    view._instance.jobTitleInput.setEnabled(jobTitleEditable);
                                    view._instance.phoneNumberInput.setEnabled(phoneNumberEditable);
                                    view._instance.modalSection.setPrimaryButtonEnabled(emailAddressEditable || notificationEditable || openInNewWindowEditable);
                                    view._instance.languageSingleSelect.setEnabled(languageSingleSelectEditable);
                                    view._instance.calendarTypeSingleSelect.setEnabled(calendarTypeSingleSelectEditable);
                                }
                            } else {
                                bpmext.log.error("Profile Modal", "Unable to get user info");
                            }
                        }));
                } catch (error) {
                    bpmext.log.error(error.message);
                }
            },
            _isInNavigator: function _isInNavigator(view) {
            	if (view.context.options.inNavigator.get("value") || view.context.isApp()) {
            		return true;
            	} else {
            		return false;
            	}
            },
            _updateUserPreference: function _updateUserPreference(view) {
                bpmext.log.info("ProfileModal._updateUserPreference LOG >>", view);
                try {
                	
            		var fileSelected = view._instance.changeAvatar.context.element.querySelector("#avatar").files;
            		var editAvatarStatus = view._instance.profileAvatarImage.context.element.querySelector('.SPARKImage img').getAttribute('editAvatar');
            		var fileToSave = "";
            		var avatarToChange = "";
            		if (fileSelected.length > 0) {
            			//Change avatar - Delete existing and then change the new avatar
            			var fileToSave = fileSelected[0];
            			wpResources.avatar.deleteAvatar().then( function(avatar) {
            				bpmext.log.info("Delete avatar from dB");
            			});
            			wpResources.avatar.set({avatar: fileToSave}).then( function(avatar) {
            				bpmext.log.info("avatar save response - success");
            			}).catch(function(error) {
            				bpmext.log.info("avatar save response error: ", error);
            			});
            			avatarToChange = window.URL.createObjectURL(fileToSave);
            			view._instance.changeAvatar.context.element.querySelector('#avatar').value="";
            		} else if (editAvatarStatus ==  "true") {
            			//Delete avatar
            			wpResources.avatar.deleteAvatar().then( function(avatar) {
            				bpmext.log.info("Delete avatar from dB");
            			});
            			avatarToChange = com_ibm_bpm_coach.getManagedAssetUrl("current.png", com_ibm_bpm_coach.assetType_WEB, "SYSWPT");
            			view._instance.profileAvatarImage.context.element.querySelector('.SPARKImage img').setAttribute("editAvatar", false);
            		}
            	
                    var prefs = { };
                    prefs[wpResources.user.PREFERENCE.taskEmailAddress] = view._instance.emailAddressInput.getData();
                    prefs[wpResources.user.PREFERENCE.taskNotification] = view._instance.notificationCheckbox.isChecked() ? "true" : "false";
                    prefs[wpResources.user.PREFERENCE.portalOpenTaskInNewWindow] = view._instance.openInNewWindowCheckbox.isChecked() ? "generalPreference.fields.openTaskInNewWindow.yes" : "generalPreference.fields.openTaskInNewWindow.no";
                    prefs[wpResources.user.PREFERENCE.portalNotificationNewTaskToMe] = view._instance.taskNotificationCheckbox.isChecked() ? "true" : "false";
                    prefs[wpResources.user.PREFERENCE.portalNotificationNewTaskToMyGroup] = view._instance.taskNotificationGroupCheckbox.isChecked() ? "true" : "false";
                    
                    prefs[wpResources.user.PREFERENCE.title] = view._instance.jobTitleInput.getData();
                    prefs[wpResources.user.PREFERENCE.phoneNumber] = view._instance.phoneNumberInput.getData();
        
                    // ***************
                    // IMPORTANT NOTE : -->>'Language' is saved to 'locale' in user preference.  DONT CHANGE THIS!!!
                    prefs[wpResources.user.PREFERENCE.locale] = view._instance.languageSingleSelect.getData();
                    prefs[wpResources.user.PREFERENCE.calendarType] = view._instance.calendarTypeSingleSelect.getData();
                    
                    wpResources.user.setPreferences({preferences: prefs});
                    
                    //Update avatar on pageswitcher
                    if (avatarToChange != "") {
                    	if (document.querySelector(".dbac--header-btn--icon-wrapper .dbac--header-user-dd-menu--userInitialsIcon img")) {
                    		document.querySelector(".dbac--header-btn--icon-wrapper .dbac--header-user-dd-menu--userInitialsIcon img").src = avatarToChange;
                    		document.querySelector(".dbac--header-user-dd-menu--headerDropDownMenuBar .dbac--header-user-dd-menu--username .dbac--header-user-dd-menu--userInitialsIcon-lg img").src= avatarToChange;
                    	} else if (this._isInNavigator(view)) {
                    		window.top.document.querySelector(".ecm.icn .ecmBanner .bannerIconButton .dijitIcon.person").style.cssText='background-image:url("'+avatarToChange+'");background-size: 100% 100%;';
                    		window.top.document.querySelector(".ecm.icn .bannerMenu .dijitIcon.bannerMenuItemUserIcon").style.cssText='background-image:url("'+avatarToChange+'");background-size: 100% 100%;filter: unset;-webkit-filter: unset;';
                    	}
                    }
                    // Send event to task list and instance list to update user preferences
                    taskUtils.EVENTS.UPDATE_USER_PREFERENCES.publish(prefs);
                    // Reload windows in case Language or local changed or calendar type changed
                    if(view._instance.initialUserPreference[wpResources.user.PREFERENCE.localeFormat] !==  prefs[wpResources.user.PREFERENCE.localeFormat]
                    	|| view._instance.initialUserPreference[wpResources.user.PREFERENCE.locale] !==  prefs[wpResources.user.PREFERENCE.locale]
                    	|| view._instance.initialUserPreference[wpResources.user.PREFERENCE.calendarType] !==  prefs[wpResources.user.PREFERENCE.calendarType] )
                   	{
                    	parent.location.reload();
                	}
                } catch (error) {
                    bpmext.log.error(error.message);
                }
            }
        };


        /*
        Public control methods *************************************************************
         */

         /**
         * @instance
         * @memberof ProfileModal
         * @method closeModal
         * @desc Closes the modal dialog
         */
        this.constructor.prototype.closeModal = function() {
            bpmext.log.info("ProfileModal.closeModal ENTER >> ",this);
            this._instance.changeAvatar.context.element.querySelector('#avatar').value="";
            this._proto._hideModel(this);
            bpmext.log.info("ProfileModal.closeModal EXIT << ");
        };

         /**
         * @instance
         * @memberof ProfileModal
         * @method saveModal
         * @desc Saves the data on the dialog
         */
        this.constructor.prototype.saveModal = function() {
            bpmext.log.info("ProfileModal.saveModal ENTER >> ", this);
            if (this.validateEmailAddress()) {
                this._proto._updateUserPreference(this);
                this.closeModal();
            }
            bpmext.log.info("ProfileModal.saveModal EXIT << ");
        };

        /**
         * @instance
         * @memberof ProfileModal
         * @method loadLangauges
         * @returns null
         * @desc Load all language to languageSingleSelect
         */
        this.constructor.prototype.loadLangauges = function(view) {
            bpmext.log.info("ProfileModal.loadLangauges ENTER >> ", this);
            wpResources.config.get().then(function(mashupsConfig) {
			    if (mashupsConfig.availableLocales && view) {
			    	var defaultLangValue = taskUtils.DEFAULT_LANGUAGE.EN;
			    	var defaultLangLabel = bpmext.localization.formatMsg("ProfileModal", "en");
					var langList = taskUtils.getLanguages(mashupsConfig.availableLocales, defaultLangValue, defaultLangLabel);
					view._instance.languageSingleSelect.clearItems();
					for ( var lang in langList) {
						var langName = langList[lang];
						view._instance.languageSingleSelect.appendItem(lang, langName);
					}
					
			}
            });
            bpmext.log.info("ProfileModal.loadLangauges EXIT << ");
        };
        /**
         * @instance
         * @memberof ProfileModal
         * @method loadCalendarTypes
         * @returns null
         * @desc Load all CalendarType to calendarTypeSingleSelect
         */
        this.constructor.prototype.loadCalendarTypes = function() {
        	bpmext.log.info("ProfileModal.loadCalendarTypes ENTER >> ", this);
        	this._instance.calendarTypeSingleSelect.clearItems();
			var calendarTypeOptions = [
				{
					label:  bpmext.localization.formatMsg("ProfileModal", "calendarTypeGregorian"),
					value: taskUtils.CALENDAR_TYPES.gregorian
				},
				{
					label: bpmext.localization.formatMsg("ProfileModal", "calendarTypeIslamic"),
					value: taskUtils.CALENDAR_TYPES.islamic
				},
				{
					label: bpmext.localization.formatMsg("ProfileModal", "calendarTypeHebrew"),
					value: taskUtils.CALENDAR_TYPES.hebrew
				}
			];
			for ( var optionIndex in calendarTypeOptions) {
				var calendarTypeOption = calendarTypeOptions[optionIndex];
				this._instance.calendarTypeSingleSelect.appendItem(calendarTypeOption.value, calendarTypeOption.label);
			}
			bpmext.log.info("ProfileModal.loadCalendarTypes EXIT << ");
		};
        /**
         * @instance
         * @memberof ProfileModal
         * @method showModal
         * @desc Display the modal
         */
        this.constructor.prototype.showModal = function() {
            bpmext.log.info("ProfileModal.showModal ENTER >> ", this);

            this._proto._getUserPreference(this);
            this._instance.emailAddressInput.setVisible(true);
            this._instance.notificationCheckbox.setVisible(true);
            this._instance.openInNewWindowCheckbox.setVisible(true);
            this._instance.taskNotificationCheckbox.setVisible(true);
            this._instance.taskNotificationGroupCheckbox.setVisible(true);
            this._instance.modalSection.setVisible(true);
            this._instance.jobTitleInput.setVisible(true);
            this._instance.phoneNumberInput.setVisible(true);
            if (this._proto._isInNavigator(this) || document.querySelector(".dbac--header-btn--icon-wrapper .dbac--header-user-dd-menu--userInitialsIcon img")) {
            	this._instance.changeAvatar.setVisible(true);
            	this._instance.deleteAvatar.setVisible(true);
            } else {
            	this._instance.changeAvatar.setVisible(false);
            	this._instance.deleteAvatar.setVisible(false);
            }
            // incase of appEngine- not showing Calendar, Locale and Language
            if(!wpResources.isAppEngine){
              this._instance.languageSingleSelect.setVisible(true);
              this._instance.calendarTypeSingleSelect.setVisible(true);    
            }

            this.show();
            taskUtils.setTabCycle(this);
            bpmext.log.info("ProfileModal.showModal EXIT >> ", this);
        };

         /**
         * @instance
         * @memberof ProfileModal
         * @method validateEmailAddress
         * @returns {Boolean} the boolean value for the validity of the email address
         * @desc Controls the visibility of plain input and enables or disables the save button
         */
        this.constructor.prototype.validateEmailAddress = function() {
            bpmext.log.info("ProfileModal.validateEmailAddress ENTER >> ", this);
            var validEmail = false;
            //Only enable save button if there is a valid email
            var validationRE = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            var emailAddressInput = this._instance.emailAddressInput;
            var emailAddressData = emailAddressInput.getData() ? emailAddressInput.getData().toLowerCase() : "";
            validEmail = emailAddressData === "" || validationRE.test(emailAddressData);
            this._instance.modalSection.setPrimaryButtonEnabled(!!validEmail);
            if (validEmail) {
                emailAddressInput.setValid(true);
            } else {
                emailAddressInput.setValid(false, bpmext.localization.formatMsg("ProfileModal", "invalidEmail"));
            }
            if (this._instance.notificationEditable === true) {
                this._instance.notificationCheckbox.setEnabled(true);
                if (emailAddressData === "") {
                    this._instance.notificationCheckbox.setChecked(false);
                    this._instance.notificationCheckbox.setEnabled(false);
                }
            }

            bpmext.log.info("ProfileModal.validateEmailAddress EXIT << ");
            return validEmail;
        };
        
        /**
         * @instance
         * @memberof ProfileModal
         * @method deleteAvatarAction
         * @returns void
         * @desc Set default image for avatar preview and disable delete button
         */
        this.constructor.prototype.deleteAvatarAction = function() {
            var defaultAvatarURL = com_ibm_bpm_coach.getManagedAssetUrl("current.png", com_ibm_bpm_coach.assetType_WEB, "SYSWPT");
            this._instance.profileAvatarImage.setImage(defaultAvatarURL, "Web");
            
            //editAvatar act as a flag to identify the avatar is deleted or not
            this._instance.profileAvatarImage.context.element.querySelector('.SPARKImage img').setAttribute("editAvatar", true);
            this._instance.changeAvatar.context.element.querySelector('#avatar').value="";
            this._instance.deleteAvatar.setEnabled(false);
        };
        
        /**
         * @instance
         * @memberof ProfileModal
         * @method changeAvatarAction
         * @returns void
         * @desc  Avatar preview and enable delete button
         */
        this.constructor.prototype.changeAvatarAction = function() {
        	arguments[0]._instance.profileAvatarImage.setImage(window.URL.createObjectURL(event.target.files[0]), "External");
        	arguments[0]._instance.profileAvatarImage.context.element.querySelector('.SPARKImage img').setAttribute("editAvatar", false);
        	arguments[0]._instance.deleteAvatar.setEnabled(true);
        };
        
        /**
         * @instance
         * @memberof ProfileModal
         * @method setButtonTooltip
         * @returns void
         * @desc Set tooltip for change/delete avatar button
         */
        this.constructor.prototype.setButtonTooltip = function(view) {
        	//set tooltip for change avatar icon button
        	var changeAvatarIcon = view._instance.changeAvatar.context.element;
        	changeAvatarIcon.onmouseenter = function() {
        		bpmext.ui.util.showTooltip (
    				changeAvatarIcon,
    				bpmext.localization.formatMsg("ProfileModal", "changeAvatar"),
    				{ horizontalPos: "LEFT", plainText: false, smartPositioning: true, openDelay: 0.5 }
        		);
        	};
        	
        	//set tooltip for delete avatar icon button
        	var deleteAvatarIcon = view._instance.deleteAvatar.context.element;
        	deleteAvatarIcon.onmouseenter = function() {
        		bpmext.ui.util.showTooltip (
        			deleteAvatarIcon,
        			bpmext.localization.formatMsg("ProfileModal", "deleteAvatar"),
        			{horizontalPos: "LEFT", plainText: false, smartPositioning: true, openDelay: 0.5}
        		);
        	};
        };

        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function (){
            bpmext.log.info("ProfileModal.load ENTER >>", this);

            this._instance.modalSection = bpmext.ui.getContainer("ModalSection", this);
            this._instance.modalSection.setPrimaryButtonText(bpmext.localization.formatMsg("ProfileModal", "save"));
            this._instance.modalSection.setSecondaryButtonText(bpmext.localization.formatMsg("ProfileModal", "cancel"));
            //CV in ModalSection
            this._instance.panel = bpmext.ui.getContainer("Panel", this);
            //CV in Panel
            this._instance.emailAddressInput = bpmext.ui.getView("EmailAddressInput", this);
            this._instance.notificationCheckbox = bpmext.ui.getView("EmailNotificationCheckbox", this);
            this._instance.openInNewWindowCheckbox = bpmext.ui.getView("OpenInNewWindowCheckbox", this);
            this._instance.taskNotificationCheckbox = bpmext.ui.getView("TaskNotificationCheckbox", this);
            this._instance.taskNotificationGroupCheckbox = bpmext.ui.getView("TaskNotificationGroupCheckbox", this);
            this._instance.notificationTitle = bpmext.ui.getView("NotificationTitle", this);
            this._instance.jobTitleInput = bpmext.ui.getView("JobTitleInput", this);
            this._instance.phoneNumberInput = bpmext.ui.getView("PhoneNumberInput", this);
            this._instance.profileAvatarImage = bpmext.ui.getView("ProfileAvatar", this);
            this._instance.changeAvatar = bpmext.ui.getView("ChangeAvatarBtn", this);
            this._instance.deleteAvatar = bpmext.ui.getView("DeleteAvatarIcon", this);
            this._instance.languageSingleSelect = bpmext.ui.getView("LanguageSingleSelect", this);
            this._instance.calendarTypeSingleSelect = bpmext.ui.getView("CalendarTypeSingleSelect", this);

            //Assign labels and texts to controls
            this._instance.modalSection._instance.modalDialog.ariaLabel = bpmext.localization.formatMsg("ProfileModal", "emailNotification");
            this._instance.emailAddressInput.setLabel(bpmext.localization.formatMsg("ProfileModal", "emailAddress"));
            this._instance.notificationCheckbox.setLabel(bpmext.localization.formatMsg("ProfileModal", "notificationCheckbox"));
            this._instance.openInNewWindowCheckbox.setLabel(bpmext.localization.formatMsg("ProfileModal", "openInNewWindowCheckbox"));
            this._instance.taskNotificationCheckbox.setLabel(bpmext.localization.formatMsg("ProfileModal", "taskNotificationCheckbox"));
            this._instance.taskNotificationGroupCheckbox.setLabel(bpmext.localization.formatMsg("ProfileModal", "taskNotificationGroupCheckbox"));
            this._instance.notificationTitle.setLabel(bpmext.localization.formatMsg("ProfileModal", "notificationTitle"));
            this._instance.jobTitleInput.setLabel(bpmext.localization.formatMsg("ProfileModal", "jobTitle"));
            this._instance.phoneNumberInput.setLabel(bpmext.localization.formatMsg("ProfileModal", "phoneNumber"));          
            this._instance.changeAvatar.setText(bpmext.localization.formatMsg("ProfileModal", "changeAvatar"));
            
            var opts = this.context.options;

            if (!opts.inNavigator) {
                bpmext.ui.substituteConfigOption(this, "inNavigator", false);
            }
            
            //Append input type file to the change avatar button
            var f = document.createElement("input");
            f.type="file";
            f.name="avatar";
            f.id="avatar";
            f.accept="image/png, image/gif, image/jpeg";
            f.onchange = this.changeAvatarAction.bind(f,this);
            this._instance.changeAvatar.context.element.appendChild(f);
              
            //Set tooltip for change/delete avatar
            this.setButtonTooltip(this);
            this._instance.languageSingleSelect.setLabel(bpmext.localization.formatMsg("ProfileModal", "languageSingleSelect"));
            this._instance.calendarTypeSingleSelect.setLabel(bpmext.localization.formatMsg("ProfileModal", "calendarTypeSingleSelect"));
            
            // populating language and localeFormat dropdown
            this.loadLangauges(this);
            this.loadCalendarTypes(this);

            var panelHeaderIcon = this._instance.panel.context.element.querySelector("div.panel-heading-controls > div.panel-heading-icon > i");
            !!panelHeaderIcon && domAttr.remove(panelHeaderIcon, "tabindex");

            taskUtils.EVENTS.SET_EMAIL_NOTIFICATION.subscribe(function(eventName, eventView) {
                if (this.ui.getParent().isVisible()) {
                    this.showModal();
                }
            }, this);

            // Move focus to close icon when Save is disabled
            var primaryBtn = this._instance.modalSection._instance.primaryBtn;
            var secondaryBtn = this._instance.modalSection._instance.secondaryBtn;
            var closeIcon = this._instance.panel.context.element.querySelector("div.panel-heading-controls > div.panel-heading-icon");
            secondaryBtn.onkeydown = function(event) {
                if (primaryBtn.disabled && event.key === "Tab") {
                    if (event.shiftKey) {
                        return;
                    }
                    event.preventDefault();
                    closeIcon.focus();
                }
            };

            this.loadContainer(this);

            bpmext.log.info("ProfileModal.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try {
                utilities.handleVisibility(this.context);
            }
            catch (e){
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e, this);
                if(e.stack) {
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack), this);
                }
            }
        };

        this.constructor.prototype.change = function (event){
            bpmext.log.info("ProfileModal.change ENTER >> (event): " + event, this);
            bpmext.log.info("ProfileModal.change ENTER >>", this);
        };

        this.constructor.prototype.unload = function (){
            bpmext.log.info("ProfileModal.unload ENTER >> ", this);
            bpmext.ui.unloadContainer(this);
            bpmext.log.info("ProfileModal.unload ENTER >>", this);
        };
    }
};