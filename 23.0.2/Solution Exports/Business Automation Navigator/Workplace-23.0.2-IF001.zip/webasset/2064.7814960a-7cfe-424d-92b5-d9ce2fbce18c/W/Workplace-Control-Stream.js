/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof Stream
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof Stream
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof Stream
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof Stream
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof Stream
 * @method setData
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 */
workplace_control_InitStream = function (utilities, domClass, taskUtils, wpResources)
{
	"use strict";
	/*
	Instance-specific "PRIVATE" data
	We use _instance so as to keep the number of attributes and functions visible at the main
	object level to a minimum. If we don't do that, people will see all kinds of extra
	functions and attributes at the main object level and assume it is ok to use them.

	We'll need to tell users/developers that anything under _instance is private and should
	not be accessed/called outside of the control.
	 */
    this._instance =
    {

    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            EVT_ONLOAD : "eventON_LOAD",

            _fetchStream: function(view, instanceID, systemID) {
                bpmext.log.info("InstanceUI._fetchStream ENTER >>: ", view);
                view._instance.piid = instanceID, view._instance.systemID = systemID;
                view._instance.socialResource.getStreamForInstance({piid: instanceID, systemID: systemID}).then(function(stream) {
                	if(stream.totalItems > 0) {
                		view._proto._loadStream(view, stream.items);
                	}
                });

                bpmext.log.info("InstanceUI._fetchStream EXIT >>: ", view);

            },

            _loadStream: function(view, items) {
            	 bpmext.log.info("InstanceUI._loadStream ENTER >>: ", view);

            	 view._instance.streamCardCV.setViewData(items, true);

                 bpmext.log.info("InstanceUI._loadStream EXIT >>: ", view);
            }

        };

        /*
        Public control methods *************************************************************
         */

        /**
		 * @instance
		 * @memberof Stream
		 * @method addCommentDirectly
		 * @desc add a comment directly to the instance
		 */
        this.constructor.prototype.addCommentDirectly = function() {
        	bpmext.log.info("Stream.addCommentDirectly ENTER>>", this);
        	var view = this;
        	view.addComment(view._instance.addCommentTxt.getData());
        };

        /**
		 * @instance
		 * @memberof Stream
		 * @method addComment
		 * @desc add a comment
		 */
        this.constructor.prototype.addComment = function(comment, origCommentId) {
        	bpmext.log.info("Stream.addComment ENTER>>", this);
        	var view = this;
        	var option = {"piid": view._instance.piid, "comment":comment, "origCommentId": origCommentId};
        	view._instance.processResource.postComment(option).then(function(){
        		view.refresh();
        	});
        };

        /**
		 * @instance
		 * @memberof Stream
		 * @method refresh
		 * @desc Reloads the mention list
		 */
        this.constructor.prototype.refresh = function() {
        	bpmext.log.info("Stream.refresh ENTER>>", this);
			this._proto._fetchStream(this, this._instance.piid, this._instance.systemID);
        };

		/**
		 * @instance
		 * @memberof Stream
		 * @method StreamToggle
		 * @desc To expand or collapse panel
		 */
        this.constructor.prototype.StreamToggle = function() {
			bpmext.log.info("Stream.StreamToggle ENTER >>", this);
			var domObj = this.context.element;

			var btnElement = this._instance.buttonCV && this._instance.buttonCV.context.element.querySelector(".btn[role=button]");
			btnElement && btnElement.focus();

			if(this._instance.mentionsCV.isExpanded()){
				domClass.add(domObj,"collapse");
				this._instance.mentionsCV.collapse();
			}else{
				domClass.remove(domObj,"collapse");
				this._instance.mentionsCV.expand();
			}
		};

        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function ()
        {
        	bpmext.log.info("Stream.load ENTER >>", this);
        	var opts = this.context.options;

        	if (!opts.streams) {
                bpmext.ui.substituteConfigOption(this, "streams", []);
            }

            if (!opts.instance) {
                 bpmext.ui.substituteConfigOption(this, "instance", {});
            }

        	this._instance.streamCardCV = bpmext.ui.getContainer("StreamCards1", this);
        	this._instance.addCommentTxt = bpmext.ui.getView("AddCommentTxt", this);
        	this._instance.addCommentBtn = bpmext.ui.getView("AddComBtn", this);
			this._instance.socialResource = wpResources.social;
			this._instance.processResource = wpResources.process;

            taskUtils.EVENTS.VIEW_STREAM.subscribe(function(eventName, eventData){
                if(eventData.piid){
                    // Get process stats
                    this._instance.piid = eventData.piid;
                    var systemID = opts.instance.systemID;
                    this._proto._fetchStream(this, this._instance.piid, systemID);
                    // Show streams panel

                    this.show();
                }
			}, this);

            bpmext.ui.loadView(this);

            bpmext.log.info("Stream.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try
            {
                utilities.handleVisibility(this.context);
            }
            catch (e)
            {
                //{#feature: US-1330 Added RT localization}
                //bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if(e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    //bpmext.log.error("  Call stack: " + e.stack);
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                }
            }
        };

        this.constructor.prototype.change = function (event)
        {
        	bpmext.log.info("Stream.change ENTER >> (event): " + event, this);
			if (event.type === "config") {
                switch (event.property) {
                    case "_metadata.visibility": {
                        this.view();
                        break;
                    }
                }
            }
             bpmext.log.info("Stream.change EXIT >>", this);
        };

        this.constructor.prototype.unload = function ()
        {
            bpmext.ui.unloadView(this);
        };
    }
};