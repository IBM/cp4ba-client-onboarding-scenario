/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof ActivityCards
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof ActivityCards
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof ActivityCards
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof ActivityCards
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof ActivityCards
 * @method setData
 */

/**
 * <table>
 * 
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 * 
 *   <tr class=Prop>
 *       <td>On card focus:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when a card gains focus.</td>
 *               </tr>
 *           </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">Description</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">target {object}</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">card object</td>
 *               </tr>
 *       </table>
 *     </td>
 *   </tr>
 * 
 *   <tr class=Prop>
 *       <td>On card blur:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when a task loses focus.</td>
 *               </tr>
 *           </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">Description</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">target {object}</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">card object</td>
 *               </tr>
 *           </table>
 *       </td>
 *   </tr>
 * 
 * </table>
 */
workplace_control_InitActivityCards = function (utilities, taskUtils, domClass, domConstruct, wpResources, domAttr)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            //Event constants
            EVT_ONCARD_FOCUS : "eventON_CARD_FOCUS",
            EVT_ONCARD_BLUR: "eventON_CARD_BLUR",

            /******************** Mapping data to UI - start ********************/
            /********** setting card events - start **********/
            _loadActivityCardBody: function (view, target, controlState) {
                var activity = view.getActivities()[controlState.index];
                if (activity) {
                    var cardWrapperContext = target.context.element.querySelector("div.SPARKWell");
                    domAttr.set(cardWrapperContext, "role", "note");
                    domAttr.set(cardWrapperContext, "aria-label", activity.activityName);
                }

                view._proto._bindingActivityCardEvents(view, target);
            },

            _bindingActivityCardEvents: function _bindingActivityCardEvents(view, target) {
                var cardContent = target.context.element.querySelector(".SPARKWell.stat-panel[tabindex=\"0\"]");

                if (cardContent) {
                    var currentElement = null;
                    cardContent._updateCurrentElement = function (event) {
                        if (event.type === "focus") {
                            currentElement = event.target;
                        } else if (event.type === "click") {
                            currentElement = event.target;
                        }
                    };

                    cardContent._customEventHandler = function (event) {
                        if (event.type === "focus") {
                            if (view._instance.focusTimer) {
                                clearTimeout(view._instance.focusTimer);
                            }

                            // 150ms delay is using to make sure that focus always happens after blur
                            view._instance.focusTimer = setTimeout(function () {
                                var controlState = view._instance.state[target.ui.getIndex()];

                                // prevent launch side info multiple times
                                if (!controlState.focused) {
                                    controlState.focused = true;
                                    bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONCARD_FOCUS, target);
                                }
                                delete view._instance.focusTimer;
                            }, 150);
                        } else if (event.type === "blur" && currentElement !== null) {
                            if (view._instance.blurTimer) {
                                clearTimeout(view._instance.blurTimer);
                            }
    
                            // 140ms delay is using to make sure that blur always happens before focus
                            view._instance.blurTimer = setTimeout(function () {
                                var activeEle = document.activeElement;
                                var popupMenu = document.querySelector(".Popup_Menu.menu[data-menuidpath=\"Instance_UI:Actions_Menu:Popup_Menu1\"]");
                                var rightPanel = document.querySelector(".Vertical_Layout[data-viewid='ActivityRightPanel']");
    
                                // block blur effect on when focus on its child or items in its child's
                                var isChildOfPopupMenu = popupMenu  && popupMenu.contains(activeEle);
                                var isChildOfRightPanel = rightPanel && rightPanel.contains(currentElement);
                                if (!target.context.element.contains(activeEle) && !isChildOfRightPanel && !isChildOfPopupMenu) {
                                    var controlState = view._instance.state[target.ui.getIndex()];
                                    controlState.focused = false;
    
                                    bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONCARD_BLUR, target);
                                }
                                delete view._instance.blurTimer;
                            }, 140);
                        }
                    };

                    document.addEventListener("focus", cardContent._updateCurrentElement, true);
                    document.addEventListener("click", cardContent._updateCurrentElement, true);
                    cardContent.addEventListener("focus", cardContent._customEventHandler, true);
                    cardContent.addEventListener("blur", cardContent._customEventHandler, true);
                }
            },

            _removeActivityCardEvents: function _removeActivityCardEvents (view) {
                if (view._instance.activityCards) {
                    var cardContents = view._instance.activityCards.context.element.querySelectorAll(".SPARKWell.stat-panel[tabindex=\"0\"]");

                    for (var i=0; i<cardContents.length; i++) {
                        var cardContent = cardContents[i];
                        if (cardContent && cardContent._customEventHandler) {
                            cardContent.removeEventListener("focus", cardContent._customEventHandler, true);
                            cardContent.removeEventListener("blur", cardContent._customEventHandler, true);
                            delete cardContent._customEventHandler;
                        }
                    }
                }

                if (view._instance.blurTimer) {
                    clearTimeout(view._instance.blurTimer);
                    delete view._instance.blurTimer;
                }

                if (view._instance.focusTimer) {
                    clearTimeout(view._instance.focusTimer);
                    delete view._instance.focusTimer;
                }
            },
            /********** setting card events - end **********/


            /********** setting card header - start **********/
            _loadActivityCardHeader: function (view, target, controlState) {
                var activity = view.getActivities()[controlState.index];

                var activityNameType = target.context.getSubview("Activity_NameType", target)[0];
                if (activityNameType) {
                    var activityName = activityNameType.context.getSubview("Activity_Name", activityNameType)[0];
                    activityName.setLabelVisible(false, true);
                    activityName.setData(activity.activityName);

                    var activityType = activityNameType.context.getSubview("Activity_Type", activityNameType)[0];
                    activityType.setLabelVisible(false, true);

                    if (activity.activityType) {
                        var type;
                        if (activity.activityType === "activityRequired") {
                            type = "activityRequired";
                            activityType.setLabelVisible(true);
                            activityType.setLabel(" ");
                            activityType.setEnabled(true, true);
                        } else {
                            type = (activity.activityType || "").toLowerCase();
                        }
                        var typeText = bpmext.localization.formatMsg("instanceUI", type);

                        // add all must approve info for the approval activity
                        if (activity.activityType === "APPROVAL" && activity.allMustApprove) {
                            typeText =  bpmext.localization.formatMsg("instanceUI", "allMustApprove", typeText);
                        }
                        activityType.setData(typeText);
                    } else {
                        activityType.setVisible(false, true);
                    }


                }

                var activityInfo = target.context.getSubview("Activity_Info", target)[0];
                if (activityInfo) {
                    var activityPriority = activityInfo.context.getSubview("Activity_Priority", activityInfo)[0];
                    var activityStart = activityInfo.context.getSubview("Activity_Start_Date", activityInfo)[0];
                    var activityCompleted = activityInfo.context.getSubview("Activity_Completed_Date", activityInfo)[0];
                    var activityDue = activityInfo.context.getSubview("Activity_Due_Date", activityInfo)[0];
                    var assignee = activityInfo.context.getSubview("Assignee", activityInfo)[0];

                    activityPriority.setLabel(bpmext.localization.formatMsg("taskCard", "cardPriority"));
                    activityStart.setLabel(bpmext.localization.formatMsg("instanceUI", "dateCreated"));
                    activityCompleted.setLabel(bpmext.localization.formatMsg("taskCard", "completed"));
                    activityDue.setLabel(bpmext.localization.formatMsg("taskCard", "cardDue"));

                    if(activity.priority) {
                        activityPriority.setData(taskUtils.getPriorityLabel(activity.priority));
                    }
                    else {
                        activityPriority.setVisible(false, true);
                    }
                    
                    if(activity.dueTime) {
                        activityDue.setData(taskUtils.formatDate(new Date(activity.dueTime), true));
                    }
                    else {
                        activityDue.setVisible(false, true);
                    }
                    
                    if(activity.startTime) {
                        activityStart.setData(taskUtils.formatDate(new Date(activity.startTime), true));
                    }
                    else {
                        activityStart.setVisible(false, true);
                    }
                    
                    if(activity.endTime) {
                        activityCompleted.setData(taskUtils.formatDate(new Date(activity.endTime), true));
                    }
                    else {
                        activityCompleted.setVisible(false, true);
                    }
                    

                    var assignees = activity.assignees || [];
                    if (assignees.length === 0) {
                        assignee.setVisible(false, true);
                    } else {
                        assignee.setLabel(bpmext.localization.formatMsg("taskCard", "cardAssignee"));
                        assignee.setData(assignees.join(", "));
                    }
                }
            },
            /********** setting card header - end **********/


            /********** setting card status - start **********/
            _loadActivityCardStatus: function (view, target, controlState) {
                var activity = view.getActivities()[controlState.index];

                if (activity.status) {
                    var activityStatusIcon = target.context.getSubview("Activity_Status_Icon", target)[0];

                    var stateSpan =  domConstruct.create("span");
                    domAttr.set(stateSpan, "class", activity.status || "activityUnknown");
                    domConstruct.create("span", {className: "activityStatsIcon"}, stateSpan);
    
                    activityStatusIcon.setLabelVisible(false, true);
                    activityStatusIcon.setData(stateSpan.outerHTML);
    
                    var activityStatus = target.context.getSubview("Activity_Status", target)[0];
                    activityStatus.setLabelVisible(false, true);
                    activityStatus.setData(bpmext.localization.formatMsg("instanceUI", activity.status || "noDetailFound"));
                } else {
                    target.setVisible(false, true);
                }
            },
            /********** setting card status - end **********/


            /********** setting card detail - start **********/
            _loadActivityCardDetail: function (view, target, controlState) {
                if (!controlState.detailControl) {
                    controlState.detailControl = target;
                }

                var activity = view.getActivities()[controlState.index];
                if((activity.subTasks && activity.subTasks.length > 0) || (activity.checkListData && activity.checkListData.length > 0)) {

                    var detailBtnWrap = target.context.getSubview("Detail_Button_Wrap", target)[0];
                    if (detailBtnWrap) {
                        var toggleBtn = detailBtnWrap.context.getSubview("Detail_Button", detailBtnWrap)[0];
                        if (toggleBtn) {
                            toggleBtn.setIcon(controlState.expandStates ? "ci-chevron-up" : "ci-chevron-down");
    
                            // Accessibility
                            var detailButton = toggleBtn.context.element.querySelector("div[role=button]");
                            !!detailButton && domAttr.set(detailButton, "title", bpmext.localization.formatMsg("instanceUI",
                                controlState.expandStates ? "lessDetail" : "moreDetail"));
                            !!detailButton && domAttr.set(detailButton, "aria-label", bpmext.localization.formatMsg("instanceUI",
                                controlState.expandStates ? "lessDetail" : "moreDetail"));
                        }
                    }
    
                    var detailWrap = target.context.getSubview("Detail_Wrap", target)[0];
                    if (detailWrap) {
                        if (controlState.expandStates) {
                            var collapsedBtn = detailWrap.context.element.querySelector("div[role=button].accordion-toggle.collapsed");
                            collapsedBtn ? collapsedBtn.click() : detailWrap.expand();
                        } else {
                            var expandBtn = detailWrap.context.element.querySelector("div[role=button].accordion-toggle:not(.collapsed)");
                            expandBtn ? expandBtn.click() : detailWrap.collapse();
                        }

                        // init batch modify button
                        var isActivityCompleted = ["activityApproved", "activityRejected", "activityCompleted"].indexOf(activity.status) >= 0;
                        if (!controlState.batchModifyBtn) {
                            var toolbar = detailWrap.context.getSubview("Toolbar", detailWrap)[0];
                            
                            if (toolbar) {
                                // hide controls in toolbar when an activity is completed
                                toolbar.setVisible(!isActivityCompleted, true);
                                
                                var batchModifyBtn = toolbar.context.getSubview("BatchModify", toolbar)[0];
                                if (batchModifyBtn) {
                                    view._proto._setTaskTableBtnTooltips(view, batchModifyBtn);
                                    batchModifyBtn.setEnabled(false, false);

                                    controlState.batchModifyBtn = batchModifyBtn;
                                }
                            }
                        }

                        if (!controlState.taskTable) {
                            var taskTable = detailWrap.context.getSubview("Activity_Subtask_Table", detailWrap)[0];
                            if (taskTable) {
                                // change table's selection mode to none when an activity is completed
                                taskTable.context.options.selectionMode.set("value", isActivityCompleted ? "N" : "M");
                                controlState.taskTable = taskTable;
                            }
                        }
                    }
                } else {
                    target.setVisible(false);
                }
            },

            _toggleBatchModify: function (view, target, controlState, value){
                var detailWrap = target.context.getSubview("Detail_Wrap")[0]; 
                var toolbar = detailWrap.context.getSubview("Toolbar")[0];
                var batchModifyBtn = toolbar.context.getSubview("BatchModify")[0];
                var taskTable = detailWrap.context.getSubview("Activity_Subtask_Table")[0];
                batchModifyBtn.setVisible(value, true);
                if(value === false){
                    taskTable.context.options.selectionMode.set("value", "N");
                } else{
                    taskTable.context.options.selectionMode.set("value", "M");
                }
            },

            _loadSubtaskTable: function (view, target, controlState) {
                var activity = view.getActivities()[controlState.index];
                var rows, columnSpecs;

                if (activity.checkListData) {
                    rows = activity.checkListData.items;
                    columnSpecs = this._getChecklistColumnSpecs();
                    domClass.add(target.context.element, "checkListTable");
                }
                else {
                    rows = activity.subTasks;
                    columnSpecs = this._getTaskTableColumnSpecs();
                }

                target.setVisible(!!rows && rows.length > 0, true);
                target.setColumns(columnSpecs);
                target.setViewData(rows, true);
            },

            _getTaskTableColumnSpecs: function () {
                return [
                    {
                        visibility: true,
                        sortable: false,
                        renderAs: "C",
                        dataElementName: "name",
                        width: "35%",
                        label: bpmext.localization.formatMsg("controlTaskList", "taskSubject"),
                        name:"name"
                    }, {
                        visibility: true,
                        sortable: false,
                        renderAs: "C",
                        dataElementName: "owner",
                        width: "35%",
                        label: bpmext.localization.formatMsg("controlTaskList", "assignedToUser"),
                        name:"owner"
                    }, {
                        visibility: true,
                        sortable: false,
                        renderAs: "C",
                        dataElementName: "status",
                        label: bpmext.localization.formatMsg("controlTaskList", "taskStatus"),
                        name:"status"
                    }, {
                        visibility: true,
                        sortable: false,
                        renderAs: "C",
                        label: ""
                    },
                ];
            },

            _getChecklistColumnSpecs: function () {

                return [
                    {
                        visibility: true,
                        sortable: false,
                        renderAs: "H",
                        dataElementName: "itemDescription",
                        label: bpmext.localization.formatMsg("instanceUI", "checklistItemNameLabel"),
                        width: "80%",
                        name: "itemDescription",
                        type: taskUtils.COLUMN_TYPES.STRING
                    }, {
                        visibility: true,
                        sortable: false,
                        renderAs: "H",
                        dataElementName: "completed",
                        label: bpmext.localization.formatMsg("instanceUI", "checklistItemValueLabel"),
                        name: "completed",
                        width: "20%",
                        type: taskUtils.COLUMN_TYPES.BOOLEAN,
                        options: {type: "icon", falseValue: "ci-checkbox", trueValue: "ci-checkbox-checked-filled"}
                    }
                ];
            },

            _loadTaskNameCell: function _loadTaskNameCell (view, task) {
                var isCompleted = taskUtils.getStatusLabel(task) === bpmext.localization.formatMsg("controlTaskList", "taskCompleted");
                var hasOwnerShip = view._proto._isTaskLaunchableByCurrentUser(view, task);

                var taskName;
                if (isCompleted || !hasOwnerShip) {
                    taskName = domConstruct.create("div");
                    taskName.innerText = task.displayName;
                } else {
                    taskName = domConstruct.create("a", {
                        "href": "javascript:void(0)",
                        "target": "_self",
                        "aria-label": task.displayName
                    });
                    taskName.innerText = task.displayName;
                    taskName.addEventListener("click", function () {
                        view.launchTask(task);
                    });
                }

                return taskName;
            },

            _isTaskLaunchableByCurrentUser: function _isTaskLaunchableByCurrentUser (view, task) {
                var hasRequiredFields = ["owner", "assignedToDisplayName", "assignedToType"].reduce(function (acc, field) {
                    return acc && Object.prototype.hasOwnProperty.call(task, field);
                }, true);

                if (hasRequiredFields) {
                    // tasks from instance UI
                    if (task.assignedToType === "group") {
                        return (view._instance.userGroups.indexOf(task.assignedToDisplayName) > -1);
                    } else if (task.assignedToType === "user") {
                        return (task.owner === view._instance.currentUser);
                    }
                }

                return false;
            },

            _loadTaskOwnerCell: function _loadTaskOwnerCell (task) {
                var div = domConstruct.create("div");
                div.innerText = task.owner || task.teamDisplayName;
                return div;
            },

            _loadTaskStatusCell: function _loadTaskStatus (task) {
                var status;
                if (task) {
                    var text = taskUtils.getStatusLabel(task);
                    var className = taskUtils.getStatusClassName(task);
                    var isCompleted = text === bpmext.localization.formatMsg("controlTaskList", "taskCompleted");

                    // showing approved or rejected if the task has been completed
                    if (task._EXTRA_DATA && task._EXTRA_DATA.activityType === "APPROVAL" && isCompleted) {
                        text = bpmext.localization.formatMsg("instanceUI", task._EXTRA_DATA.approved ? "activityApproved" : "activityRejected");

                        status =  domConstruct.create("span", {
                            className: "activityStatsWrap " + (task._EXTRA_DATA.approved ? "activityApproved" : "activityRejected")
                        });

                        domConstruct.create("span", {className: "activityStatsIcon"}, status);
                        domConstruct.create("span", {className: "activityStatsText", innerHTML: text}, status);

                        return status;
                    }

                    status =  domConstruct.create("span", {
                        className: className,
                        "aria-label":  bpmext.localization.formatMsg("taskCard", "taskStatus") + ": " + text
                    });

                    var innerIcon = domConstruct.create("span", {className: "taskStatsIcon"});
                    domConstruct.place(innerIcon, status);

                    var innerText = domConstruct.create("span", {className: "taskStatsText", innerHTML: text});
                    domConstruct.place(innerText, status);

                } else {
                    status =  domConstruct.create("span");
                }

                return status;
            },

            _loadTaskOverflowIconCell: function _loadTaskOverflowIconCell (view, task) {
                var isCompleted = taskUtils.getStatusLabel(task) === bpmext.localization.formatMsg("controlTaskList", "taskCompleted");
                var hasOwnerShip = view._proto._isTaskLaunchableByCurrentUser(view, task);

                if (isCompleted || !hasOwnerShip) {
                    return domConstruct.create("div");
                } else {
                    var div = domConstruct.create("div", {"class": "Icon"});

                    var btnWrapper = domConstruct.create("div", {
                        "class": "OverflowIconBtn SPARKIcon btn",
                        "role": "button",
                        "tabindex": "0",
                        "title": bpmext.localization.formatMsg("taskCard", "taskActions"),
                        "aria-label": bpmext.localization.formatMsg("taskCard", "taskActions"),
                        "aria-haspopup": "true",
                        "parentViewName": view.ui.getAbsoluteName(),
                        "taskId": task.tkiid,
                        "processId": task.piid,
                        "systemID": task.systemID,
                        "isWorkstream": task.IS_WORKSTREAM || "true" /* default to true*/
                    }, div);

                    var btnLabel = domConstruct.create("span", {
                        "class": "btn-label icon ci"
                    }, btnWrapper);

                    var icon = utilities.getCarbonIcon("ci-overflow-menu-vertical");
                    domConstruct.place(icon, btnLabel);

                    var openActionMenuHandler = function(targetIcon){
                        var parentView = view.ui.getParent();

                        var processId = targetIcon.getAttribute("processId"),
                            taskId = targetIcon.getAttribute("taskId"),
                            systemID = targetIcon.getAttribute("systemID"),
                            isWorkstream = targetIcon.getAttribute("isWorkstream");
                        //Load actions menu
                        parentView._instance.actionsMenu.loadMenu(processId, taskId, systemID, isWorkstream, null, targetIcon);
                        domClass.add(targetIcon, "active");
                    };

                    btnWrapper.addEventListener("click", function(event){
                        event.stopPropagation();
                        openActionMenuHandler(this);
                    }, true);

                    btnWrapper.addEventListener("keydown", function(event){
                        event.stopPropagation();

                        // if input key is space or enter key
                        if (event.key === "Enter" || event.key === " " || event.key === "Spacebar") {
                            openActionMenuHandler(this);
                        }
                    }, true);

                    return div;
                }
            },
            /********** setting card detail - end **********/
            /******************** Mapping data to UI - end ********************/



            /******************** Other - start ********************/
            _setViewData: function _setViewData(view, data, createPseudoBinding){
                var ctx = view.context;

                if (!data || data.length < 1) {
                    view.setVisible(false, true);
                } else {
                    view.setVisible(true, true);
                }

                if(ctx){
                    if(ctx.binding){
                        ctx.binding.set("value", data);
                    } else if (createPseudoBinding === true) {
                        ctx.binding = bpmext.ui.substituteObject(view);
                        ctx.binding.set("value", data);
                    }
                }
            },

            _getCurrentUserInfo: function _getCurrentUserInfo (view) {
                bpmext.log.info("ActivityCards._getCurrentUserInfo ENTER");

                // refresh user's information
                return wpResources.user.get({refresh: true}).then(function(currentUser) {
                    view._instance.currentUser = currentUser.userName;
                    view._instance.userGroups = currentUser.memberships;
                });
            },

            _initControlState: function _initControlState (view, activities) {
                bpmext.log.info("ActivityCards._initControlState ENTER");

                activities = activities || [];

                var state = [];
                for (var i=0; i<activities.length; i++) {
                    state.push({
                        index: i,
                        focused: false,
                        expandStates: false
                    });
                }

                view._instance.state = state;
            },

            _getControlState: function _getControlState (view, target) {
                var state = view._instance.state;
                if (!target || !state) {
                    return false;
                }

                var curIndex = target.ui.getIndex();
                return curIndex < state.length ? state[curIndex] : false;
            },

            _closeAllActivityCardsDetail: function _closeAllActivityCardsDetail (view) {
                bpmext.log.info("ActivityCards._closeAllActivityCardsDetail ENTER");

                var state = view._instance.state;

                if (!state) {
                    return;
                }

                for (var i=0; i<state.length; i++) {
                    var controlState = state[i];
                    if (controlState.expandStates) {
                        controlState.expandStates = false;
                        view._proto._loadActivityCardDetail(view, controlState.detailControl, controlState);
                    }
                }
            },

            _resetAllActivityCardsFocusState: function _resetAllActivityCardsFocusState (view) {
                bpmext.log.info("ActivityCards._closeAllActivityCardsDetail ENTER");

                var state = view._instance.state;

                if (!state) {
                    return;
                }

                for (var i=0; i<state.length; i++) {
                    var controlState = state[i];
                    controlState.focused = false;
                }
            },

            _launchTask: function _launchTask(view, data) {
                bpmext.log.info("ActivityCards._launchTask ENTER >> data: ", data);

                bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONTASK_LAUNCHED, data);
                var origin = view.ui.getParent().context? view.ui.getParent().context.viewid: null;
                taskUtils.EVENTS.INSTANCE_TASK_BEFORE_LAUNCH.publish({task: data, skipClaim: view.context.options.skipClaimForTasks.get("value"), origin: origin});
            },

            _setTaskTableBtnTooltips: function _setTaskTableBtnTooltips(view, target, message, alwaysShow) {
                if (!target && !target.context && !target.context.element) {
                    return;
                }

                var EDT_BtnCtl = target.context.element;

                // if the tooltip text remain same, do nothing
                if (!view._instance.batchModifyTP_TEXT || view._instance.batchModifyTP_TEXT !== message) {
                    view._instance.batchModifyTP_TEXT = message || bpmext.localization.formatMsg("TeamPerformance", "edtTooltip");
                } else {
                    return;
                }

                if (view._instance.batchModifyTP) {
                    bpmext.ui.util.closeTooltip(view._instance.batchModifyTP, EDT_BtnCtl);
                }
                
                view._instance.batchModifyTP = bpmext.ui.util.showTooltip(
                    EDT_BtnCtl,
                    view._instance.batchModifyTP_TEXT,
                    {horizontalPos: "LEFT", plainText: false, smartPositioning: true, openDelay: 0.5, alwaysShow: alwaysShow}
                );
            },

            _isTaskAbleToModify: function _isTaskAbleToModify(view, task) {
                if (taskUtils.isTaskCompleted(task)) {
                    return {
                        enable: false,
                        warningMessage: bpmext.localization.formatMsg("controlTaskList", "cannotModifyCompletedTask")
                    };
                } else if (!view._proto._checkTaskOwnership(view, task)) {
                    return {
                        enable: false,
                        warningMessage: bpmext.localization.formatMsg("controlTaskList", "cannotModifyNotOwnedTask")
                    };
                }

                return {
                    enable: true
                };
            },

            _checkTaskOwnership: function _checkTaskOwnership(view, task) {
                if (view._instance.currentUser || view._instance.currentUserMemberships) {
                    task["OWNER"] = task["OWNER"] || task["owner"];
                    if (task["OWNER"]) {
                        // check if current user is the task owner
                        return task["OWNER"] === view._instance.currentUser;
                    } else if (task["ASSIGNED_TO_ROLE_DISPLAY_NAME"] || task["assignedToDisplayName"]) {
                        var assignedToRole = task["ASSIGNED_TO_ROLE_DISPLAY_NAME"] || task["assignedToDisplayName"];
                        // check if current user belong to the task assign group
                        return (view._instance.currentUserMemberships || [])
                            .indexOf(assignedToRole) > -1;
                    }
                }
                return false;
            }
            /******************** Other - end ********************/
        };

        /*
        Public control methods *************************************************************
        */

        /**
		 * @instance
		 * @memberof ActivityCards
		 * @method setActivities
         * @param {Activities[]} activities List of activities
		 * @desc Sets the activity value
         */
        this.constructor.prototype.setActivities = function(activities) {
            bpmext.log.info("ActivityCards.setActivities ENTER >> (data): ", activities);
            var view = this;
            if (view._instance.setActivitiesTimeout) {
                clearTimeout(view._instance.setActivitiesTimeout);
            }
            //In some cases, the current user is not updated, so we may need to delay the loading of the activities until the user is loaded
            if (activities.length === 0 || view._instance.currentUser) {
                this.context.options.activities.set("value", activities);
            } else {
                view._instance.setActivitiesTimeout = setTimeout(function() {
                      view.setActivities.call(view, activities);
                },100);
            }
            bpmext.log.info("ActivityCards.setActivities EXIT");
        };

        /**
		 * @instance
		 * @memberof ActivityCards
		 * @method getActivities
         * @return {Activities[]} A list of activities
		 * @desc Gets the activity value
         */
        this.constructor.prototype.getActivities = function() {
            return this.context.options.activities.get("value").items || [];
        };

        /**
		 * @instance
		 * @memberof ActivityCards
		 * @method loadActivityCardBody
		 * @desc Loads activity card body
		 */
        this.constructor.prototype.loadActivityCardBody = function(target) {
            var controlState = this._proto._getControlState(this, target);
            controlState && this._proto._loadActivityCardBody(this, target, controlState);
        };

        /**
		 * @instance
		 * @memberof ActivityCards
		 * @method loadActivityCardHeader
		 * @desc Loads activity card header section
		 */
        this.constructor.prototype.loadActivityCardHeader = function(target) {
            var controlState = this._proto._getControlState(this, target);
            controlState && this._proto._loadActivityCardHeader(this, target, controlState);
        };

        /**
		 * @instance
		 * @memberof ActivityCards
		 * @method loadActivityCardStatus
		 * @desc Loads activity card status section
		 */
        this.constructor.prototype.loadActivityCardStatus = function(target) {
            var controlState = this._proto._getControlState(this, target);
            controlState && this._proto._loadActivityCardStatus(this, target, controlState);
        };

        /**
		 * @instance
		 * @memberof ActivityCards
		 * @method loadActivityCardDetail
		 * @desc Loads activity card detail section
		 */
        this.constructor.prototype.loadActivityCardDetail = function (target) {
            var controlState = this._proto._getControlState(this, target);
            controlState && this._proto._loadActivityCardDetail(this, target, controlState);
            this._proto._toggleBatchModify(this, target, controlState, false);
        };

        /**
		 * @instance
		 * @memberof ActivityCards
		 * @method loadActivityCardSubTaskTable
		 * @desc Loads am activity card
		 */
        this.constructor.prototype.loadActivityCardSubTaskTable = function(target) {
            var controlState = this._proto._getControlState(this, target);
            controlState && this._proto._loadSubtaskTable(this, target, controlState);
        };

        /**
		 * @instance
		 * @memberof ActivityCards
		 * @method createCustomCell
         * @param {View} target The current view
         * @param {Cell} cell The table cell where the status information will be displayed
         * @return {div} The div with the cell format information
		 * @desc Creates the custom cells based on the current task
         */
        this.constructor.prototype.createCustomCell = function createCustomCell(target, row) {
            if (!row) {
                return domConstruct.create("div");
            }

            switch (row.varName) {
                case "name":
                    return this._proto._loadTaskNameCell(this, row.row.data);
                case "status":
                    return this._proto._loadTaskStatusCell(row.row.data);
                case "owner":
                    return this._proto._loadTaskOwnerCell(row.row.data);
                default:
                    return this._proto._loadTaskOverflowIconCell(this, row.row.data);
            }
        };

        /**
		 * @instance
		 * @memberof ActivityCards
		 * @method resetFocusState
         * @desc Reset focus state
         */
        this.constructor.prototype.resetFocusState = function resetFocusState() {
            this._proto._resetAllActivityCardsFocusState(this);
            bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONCARD_BLUR);
        };

        /**
		 * @instance
		 * @memberof ActivityCards
		 * @method toggleDetailButton
		 * @desc Toggles the activity detail button
		 */
        this.constructor.prototype.toggleDetailButton = function (target) {
            var controlState = this._proto._getControlState(this, target);

            // if the section is previously collapsed
            if (!controlState.expandStates) {
                // make sure only one detail section is open at a time
                this._proto._closeAllActivityCardsDetail(this);

                controlState.expandStates = !controlState.expandStates;
                controlState && this._proto._loadActivityCardDetail(this, controlState.detailControl, controlState);
            } else {
                // prevent activate parent onclick
                this._instance.stopPropagation = true;

                this._proto._closeAllActivityCardsDetail(this);
            }
        };

        /**
		 * @instance
		 * @memberof ActivityCards
		 * @method expandCardContent
		 * @desc Toggles the activity detail button
		 */
        this.constructor.prototype.expandCardContent = function (target) {
            var controlState = this._proto._getControlState(this, target);

            // stop propagation effect form button
            if (this._instance.stopPropagation) {
                delete this._instance.stopPropagation;
                return;
            }

            // if the section is previously collapsed
            if (!controlState.expandStates) {
               this.toggleDetailButton(target);
            }
        };

        /**
		 * @instance
		 * @memberof ActivityCards
		 * @method launchTask
         * @param {Task} task The task of the list that contains the record
		 * @desc Launches the task referenced by the given task
         */
        this.constructor.prototype.launchTask = function launchTask(task) {
            bpmext.log.info("ActivityCards.launchTask ENTER >> (data): ", task);

            var view = this;
            var tkiid = task["TASK.TKIID"] || task.tkiid;

            if (!taskUtils.isTaskCompleted(task)) {
                wpResources.task.get({tkiid: tkiid, includeURL: true, systemID: task.systemID}).then(function(task) {
                    view._proto._launchTask(view, task);
                });
            }

            bpmext.log.info("ActivityCards.launchTask EXIT");
        };

        /**
		 * @instance
		 * @memberof ActivityCards
		 * @method onRowSelected
         * @param {target} taskTable Currently modifying task list
		 * @desc Toggle batch modify button
         */
        this.constructor.prototype.onRowSelected = function onRowSelected (target) {
            var controlState = this._proto._getControlState(this, target);
            if (controlState.batchModifyBtn) {
                var selectedRecords = target.getSelectedRecords() || [];
    
                var i, result = {}, warningMessage;
                for (i = 0; i < selectedRecords.length; i++) {
                    result = this._proto._isTaskAbleToModify(this, selectedRecords[i]);
                    if (!result.enable) {
                        warningMessage = result.warningMessage;
                        break;
                    }
                }

                // In case of selecting invalid tasks, show a warning tooltip above the batch modify button
                this._proto._setTaskTableBtnTooltips(this, controlState.batchModifyBtn, warningMessage);
                
                // Enable the button whenever rows on select
                controlState.batchModifyBtn.setEnabled(selectedRecords.length > 0, true);

                // Set the button to danger style on warning
                controlState.batchModifyBtn.setColorStyle(warningMessage ? "G" : "T");
            }
        };

        /**
		 * @instance
		 * @memberof ActivityCards
		 * @method openBatchModifyTasks
		 * @desc Event handler for launch batch modify tasks modal
         */
        this.constructor.prototype.openBatchModifyTasks = function openBatchModifyTasks(target) {
            bpmext.log.info("ActivityCards.openBatchModifyTasks >>", this);

            var result, view = this;
            var controlState = this._proto._getControlState(this, target);
            if (controlState.taskTable) {
                // Skipping all tasks that are not able to modify
                var tasks = controlState.taskTable.getSelectedRecords().filter(function (task) {
                    result = view._proto._isTaskAbleToModify(view, task);
                    return result.enable;
                });
    
                taskUtils.EVENTS.BATCH_MODIFY_TASKS.publish({
                    view: view,
                    tasks: tasks
                });
            }
        };

        /*
        Coach NG Lifecycle methods *************************************************************
        */

        this.constructor.prototype.load = function ()
        {
            bpmext.log.info("ActivityCards.load ENTER >>", this);

            var opts = this.context.options;

            if (!opts.activities) {
                bpmext.ui.substituteConfigOption(this, "activities", []);
            }

            if (!opts.skipClaimForTasks) {
                bpmext.ui.substituteConfigOption(this, "skipClaimForTasks", false);
            }

            // Activity cards
            this._instance.activityCards = bpmext.ui.getContainer("Activity_Cards", this);

            // get current user info
            this._proto._getCurrentUserInfo(this);

            this.loadContainer(this);

            // Binding Events
            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONCARD_FOCUS);
            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONCARD_BLUR);

            bpmext.log.info("ActivityCards.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try
            {
                utilities.handleVisibility(this.context);
            }
            catch (e)
            {
                //{#feature: US-1330 Added RT localization}
                //bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if(e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    //bpmext.log.error("  Call stack: " + e.stack);
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                }
            }
        };

        this.constructor.prototype.change = function (event)
        {
            bpmext.log.info("ActivityCards.change ENTER >>");
            if (event.type === "config") {
                switch (event.property) {
                    case "_metadata.visibility": {
                        this.view();
                        break;
                    }
                    case "activities": {
                        // make sure that removing all event handlers
                        this._proto._removeActivityCardEvents(this);

                        this._proto._initControlState(this, event.newVal.items);

                        var view = this._instance.activityCards;
                        !!view && this._proto._setViewData(view, event.newVal, true);

                        break;
                    }
                }
            }
            bpmext.log.info("ActivityCards.change EXIT >>");
        };

        this.constructor.prototype.unload = function () {
            this._proto._removeActivityCardEvents(this);
            bpmext.ui.unloadContainer(this);
        };
    }
};
