/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define("com.ibm.bpm.workplace.resources/Notifications", [
    "com.ibm.bpm.workplace.core/dojox.cometd",
    "com.ibm.bpm.workplace.core/taskUtils",
    "./resourceBase"
], function (dojoxcometd, taskUtils, resourceBase) {
    "use strict";
    // module:
    //        Notification service module
    // summary:
    //        Defines the Notification service module to be used by Workplace Components
    // description:
    //        This module defines the API that can be used by Notifications consumers
    //        The Dojo cometD client can also be accessed and used using the exposed APIs

    var cometD = dojoxcometd,
        connect,
        disconnect,
        subscribeToChannels,
        subscribe,
        unsubscribeFromChannels,
        activate,
        subscriptionList = [],
        isNotificationWebMessagingEnabled = true,
        isTaskListWebMessagingEnabled = true,
        currentUser,
        _connectionEstablished,
        _connectionBroken,
        _connectionClosed,
        _metaConnect,
        _metaHandshake,
        _metaDisconnect,
        _escapeChannelSegment,
        _handleNotificationMessage,
        _handleTaskNotificationMessage,
        _handleConnectionSucceeded,
        _establishSubscriptionsOnServer,
        config = {},
        CONSTANTS = {
            CHANNELS: {
                PORTAL_USER_SUBSCRIPTION_CHANNEL: "/service/bpm/portal/subscription",
                PORTAL_NOTIFICATION_CHANNEL_PREFIX: "/bpm/ProcessPortal/notifications",
                TASK_LIST_USER_NOTIFICATION_CHANNEL_PREFIX: "/bpm/process_portal/task_list/user/",
                TASK_LIST_GROUP_NOTIFICATION_CHANNEL_PREFIX: "/bpm/process_portal/task_list/group/"
            },
            NOTIFICATION: {
                TASK_RESOURCE_ASSIGNED: "TASK_RESOURCE_ASSIGNED",
                TASK_COLLABORATION_INVITE: "TASK_COLLABORATION_INVITE",
                PROCESS_COMMENT_TAGGED: "PROCESS_COMMENT_TAGGED",
                TASK_FIELD_CHANGED: "TASK_FIELD_CHANGED"
            }
        };

    /**------------------------------------------------------------------------------------------**/
    /** PRIVATE FUNCTIONS                                                                        **/
    /**------------------------------------------------------------------------------------------**/

    /** **/
    _escapeChannelSegment = function _escapeChannelSegment(channelSegment) {
        return channelSegment.replace(/~/g, "~007e").replace(/\//g, "~002f");
    };

    /** Request server to subscribe **/
    _establishSubscriptionsOnServer = function _establishSubscriptionsOnServer(currentUser) {
        // only establish subscriptions on the server if either user/group or task list notifications are enabled
        if (isNotificationWebMessagingEnabled || isTaskListWebMessagingEnabled) {
            // figure out which notification types we need to subscribe to
            var typesArray = [],
                types,
                subscriptionObj;
            // request subscriptions to notifications from channel "/bpm/ProcessPortal/notifications"
            if (isNotificationWebMessagingEnabled) {
                typesArray.push("NOTIFICATIONS");
            }
            // request subscriptions to task list notifications from channels
            // "/bpm/process_portal/task_list/user/" and "/bpm/process_portal/task_list/group/"
            if (isTaskListWebMessagingEnabled) {
                typesArray.push("TASK_LIST");
            }

            types = typesArray.join(",");

            subscriptionObj = {
                userName: currentUser.userName,
                userID: currentUser.userID,
                types: types
            };

            // request the server to subscribe the client to all the pertinent channels for the specified user and
            // the enabled notification types
            if (cometD) {
                cometD.publish(CONSTANTS.CHANNELS.PORTAL_USER_SUBSCRIPTION_CHANNEL, subscriptionObj);
            }
        }
    };

    /** Handle successful connection**/
    _handleConnectionSucceeded = function _handleConnectionSucceeded(currentUser) {
        if (currentUser) {
            _establishSubscriptionsOnServer(currentUser);
        } else {
            require(["com.ibm.bpm.workplace.resources/UserResource"], function (user) {
                user.get().then(function (user) {
                    currentUser = user;
                    _establishSubscriptionsOnServer(currentUser);
                });
            });
        }
    };

    _connectionEstablished = function _connectionEstablished() {
        _handleConnectionSucceeded(currentUser);
        taskUtils.setNotificationExistence(true);
    };

    _connectionBroken = function _connectionBroken() {
        taskUtils.setNotificationExistence(false);
    };

    _connectionClosed = function _connectionClosed() {
        taskUtils.setNotificationExistence(false);
    };

    var _connected = false;
    /** Function that manages the connection status with the Bayeux server **/
    _metaConnect = function _metaConnect(message) {

        // If the client has tried to reconnect 5 times
        if(message.successful === false && message.advice.interval===5000){
            taskUtils.EVENTS.COMETD_FAILED_TO_CONNECT.publish();
        }

        if (cometD.isDisconnected()) {
            _connected = false;
            _connectionClosed();
            return;
        }

        var wasConnected = _connected;
        _connected = message.successful === true;
        if (!wasConnected && _connected) {
            _connectionEstablished();
        } else if (wasConnected && !_connected) {
            _connectionBroken();
        }
    };

    /** Function invoked when first contacting the server and **/
    /** when the server has lost the state of this client **/
    /** READ this thoroughly https://docs.cometd.org/current/reference/#_javascript_subscribe_vs_listen**/
    _metaHandshake = function _metaHandshake(/* handshake */) {
        require(["com.ibm.bpm.workplace.resources/UserResource"], function (user) {
            user.get().then(function (user) {
                currentUser = user;
                subscribeToChannels(currentUser);
            });
        });
    };

    /** Function invoked when this client is disconnected from server  **/
    _metaDisconnect = function _metaDisconnect() {
        if (cometD) {
            cometD.handshake();
        }
    };

    /** Handler for generic notifications coming from the "/bpm/ProcessPortal/notifications" channel **/
    _handleNotificationMessage = function _handleNotificationMessage(incomingMessage) {
        var data = incomingMessage.data;
        if (data) {
            switch (data.kind) {
                case CONSTANTS.NOTIFICATION.TASK_RESOURCE_ASSIGNED:
                    taskUtils.EVENTS.NOTIFICATION_TASK_RESOURCE_ASSIGNED.publish(data);
                    break;
                case CONSTANTS.NOTIFICATION.TASK_FIELD_CHANGED:
                    taskUtils.EVENTS.TASK_FIELD_CHANGED.publish(data);
                    break;
                case CONSTANTS.NOTIFICATION.TASK_COLLABORATION_INVITE:
                    taskUtils.EVENTS.NOTIFICATION_TASK_COLLABORATION_INVITE.publish(data);
                    break;
                case CONSTANTS.NOTIFICATION.PROCESS_COMMENT_TAGGED:
                    taskUtils.EVENTS.NOTIFICATION_PROCESS_COMMENT_TAGGED.publish(data);
                    break;
                default:
                    break;
            }
        }
    };

    /** Handler for Task List notifications coming from the **/
    /** "/bpm/process_portal/task_list/user/" and "/bpm/process_portal/task_list/group/" channels **/
    _handleTaskNotificationMessage = function _handleTaskNotificationMessage(incomingMessage) {
        var data = incomingMessage.data;
        // PUBLISH CLOSED/TERMINATED TASKS
        taskUtils.EVENTS.TASKLIST_TASK_RESOURCE_ASSIGNED.publish(data);
    };

    /**------------------------------------------------------------------------------------------**/
    /** END OF PRIVATE FUNCTIONS                                                                 **/
    /**------------------------------------------------------------------------------------------**/

    /**------------------------------------------------------------------------------------------**/
    /** PUBLIC FUNCTIONS                                                                         **/
    /**------------------------------------------------------------------------------------------**/

    /** Add listener to the list of listeners, "subscriptionList" **/
    /** @param {String} channel - The channel/topic name that needs to attach the callback to **/
    /** @param {Function} callback -The callback function that needs to be executed on channel/topic event **/
    subscribe = function subscribe(channel, callback) {
        if (cometD) {
            //https://docs.cometd.org/current/reference/#_javascript_subscribe_vs_listen
            subscriptionList.push(cometD.subscribe(channel, callback));
        }
    };

    /** Remove all subscribers the list of subscribers, "subscriptionList" **/
    unsubscribeFromChannels = function unsubscribeFromChannels() {
        if (cometD) {
            subscriptionList.forEach(function callUnsubscribe(subObject) {
                cometD.unsubscribe(subObject);
            });
            subscriptionList = [];
        }
    };

    /** Function called once connected, for the user to attach handlers for events coming from the 3 channels:  **/
    /** "/bpm/ProcessPortal/notifications", "/bpm/process_portal/task_list/user/" and "/bpm/process_portal/task_list/group/"  **/
    /** @param {Object} currentUser - The current user object **/
    subscribeToChannels = function subscribeToChannels(currentUser) {
        unsubscribeFromChannels();
        // only proceed with adding listeners if either user/group or task list notifications are enabled
        if (isNotificationWebMessagingEnabled || isTaskListWebMessagingEnabled) {
            // add listeners for user/group notifications, if enabled
            if (isNotificationWebMessagingEnabled) {
                subscribe(CONSTANTS.CHANNELS.PORTAL_NOTIFICATION_CHANNEL_PREFIX + "/*", _handleNotificationMessage);
            }

            // add listeners for task list notifications, if enabled
            if (isTaskListWebMessagingEnabled) {
                // task list push events for user
                subscribe(
                    CONSTANTS.CHANNELS.TASK_LIST_USER_NOTIFICATION_CHANNEL_PREFIX +
                        _escapeChannelSegment(currentUser.userName),
                    _handleTaskNotificationMessage
                );

                // task list push events for groups
                subscribe(
                    CONSTANTS.CHANNELS.TASK_LIST_GROUP_NOTIFICATION_CHANNEL_PREFIX + "*",
                    _handleTaskNotificationMessage
                );
            }
        }
    };

    /** Function that is called to connect cometD client to cometD server side  **/
    connect = function connect() {
        if (cometD) {
            cometD.addListener("/meta/handshake", _metaHandshake);
            cometD.addListener("/meta/connect", _metaConnect);
            cometD.addListener("/meta/disconnect", _metaDisconnect);
            cometD.handshake();
        }
    };

    /** Function that is called to disconnect the cometD client from cometD server side  **/
    /** NOTE: This can also be achieved by accessing the cometD nodule and running its 'disconnect' public function **/
    disconnect = function disconnect() {
        if (cometD) {
            cometD.disconnect();
            taskUtils.EVENTS.COMETD_DISCONNECTED.publish();
        }
    };

    activate = function activate(cachedContext, force) {
        // We only need to activate once
        if (!config.url || force) {
            require(["com.ibm.bpm.workplace.resources/REPResource"], function (configResource) {
                configResource.get().then(function (mashupConfigs) {
                    var unloadHandler = function unloadHandler() {
                        cometD.disconnect();
                    };

                    if (cachedContext && resourceBase.isAppEngine) {
                        config.url = "https://" + location.host + cachedContext.rewriteURI(resourceBase.contextRoot.socialBusWeb + "/cometd", "PFS");

                        //add the CSRF Token
                        config.requestHeaders = config.requestHeaders || {};
                        config.requestHeaders[cachedContext.getCSRFTokenHeaderName()] = cachedContext.getCSRFToken();
                    } else {
                        config.url = location.protocol + "//" + location.host + resourceBase.contextRoot.socialBusWeb + "/cometd";
                    }

                    // enable websocket when running on AE or Liberty
                    cometD.websocketEnabled = mashupConfigs.isLiberty || resourceBase.isAppEngine;

                    /*
                    // remove all transport types except websockets when running on AE
                    // CometD falls back on Long-poll and callback when websockets fail. So, this will disable this behaviour
                    if (resourceBase.isAppEngine) {
                        cometD.getTransportTypes().forEach(function (transport) {
                            if (transport !== "websocket") {
                                cometD.unregisterTransport(transport);
                            }
                        });
                    }
                    */

                    if (!mashupConfigs.disableCometD) {
                        // set CometD configuration
                        cometD.configure(config);
                        // If the window unloads, be sure to disconnect from cometD server
                        window.addEventListener("beforeunload", unloadHandler, false);
                        connect();
                    }
                });
            });
        }
    };

    /**------------------------------------------------------------------------------------------**/
    /** END OF PUBLIC FUNCTIONS                                                                  **/
    /**------------------------------------------------------------------------------------------**/

    // (public) exports
    return {
        subscribe: subscribe,
        unsubscribeFromChannels: unsubscribeFromChannels,
        cometD: cometD,
        connect: connect,
        CONSTANTS: CONSTANTS,
        disconnect: disconnect,
        subscribeToChannels: subscribeToChannels,
        activate: activate
    };
});
