/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define(["./constants"], function(constants) {
    "use strict";
    var i18nUtils = {};

    i18nUtils.formatLabel = function formatLabel(labelMap, label) {
        var labelOrArray = labelMap[label] || label;
        if (Array.isArray(labelOrArray)) {
            labelOrArray = bpmext.localization.formatMsg.apply(null, labelOrArray);
        }
        return labelOrArray;
    };

    i18nUtils.getLabelFromInstanceProperty = function getLabelFromInstanceProperty(property) {
        var instancePropertyLabels = {
            riskState: ["instanceList", "state"],
            executionState: ["instanceList", "InstanceState"],
            name: ["instanceList", "name"],
            bpdName: ["instanceList", "bpdName"],
            type: ["caseList", "type"],
            creationDate: ["instanceList", "creationDate"],
            instanceCreationDate: ["instanceList", "creationDate"],
            lastModifiedBy: ["caseList", "lastModifiedBy"],
            lastModificationTime: ["caseList", "lastModificationTime"],
            dueDate: ["instanceList", "dueDate"],
            instanceStatus: ["instanceList", "state"],
            instanceName: ["instanceList", "name"],
            instanceDueDate: ["instanceList", "dueDate"],
            instanceAtRiskDate: ["instanceList", "instanceAtRiskDate"],
            instanceCompletionDate: ["instanceList", "instanceCompletionDate"],
            instanceHealth: ["instanceList", "instanceHealth"],
            instanceLastModificationDate: ["instanceList", "instanceLastModificationDate"],
            instanceLastModifier: ["instanceList", "instanceLastModifier"],
            instanceStageStatus: ["instanceList", "instanceStageStatus"],
            instanceStarterId: ["instanceList", "instanceStarterId"],
            isWorkstream: ["instanceList", "isWorkstream"],
            processAppName: ["instanceList", "processAppName"],
            instanceId: ["instanceList", "instanceId"],
            instanceProcessApp: ["instanceList", "instanceProcessApp"],
            instanceSnapshot: ["instanceList", "instanceSnapshot"],
            parentActivityId: ["instanceList", "parentActivityId"],
            parentCaseId: ["instanceList", "parentCaseId"],
            workflowApplication: ["instanceList", "workflowApplication"],
            caseIdentifier: ["caseList","caseIdentifier"],
        };
        return i18nUtils.formatLabel(instancePropertyLabels, property);
    };

    i18nUtils.getInstanceSystemDataDescription = function getInstanceSystemDataDescription(property) {
        var instanceDescription = {
            workflowType: ["instanceSystemDataDescriptions", "workflowType"],
            name: ["instanceSystemDataDescriptions", "name"],
            instanceName: ["instanceSystemDataDescriptions", "instanceName"],
            dueDate: ["instanceSystemDataDescriptions", "dueDate"],
            instanceDueDate: ["instanceSystemDataDescriptions", "instanceDueDate"],
            creationDate: ["instanceSystemDataDescriptions", "creationDate"],
            instanceCreationDate: ["instanceSystemDataDescriptions", "instanceCreationDate"],
            InstanceState: ["instanceSystemDataDescriptions", "InstanceState"],
            instanceStatus: ["instanceSystemDataDescriptions", "InstanceStatus"],
            instanceAtRiskDate: ["instanceSystemDataDescriptions", "instanceAtRiskDate"],
            instanceCompletionDate: ["instanceSystemDataDescriptions", "instanceCompletionDate"],
            instanceHealth: ["instanceSystemDataDescriptions", "instanceHealth"],
            instanceLastModificationDate: ["instanceSystemDataDescriptions", "instanceLastModificationDate"],
            instanceLastModifier: ["instanceSystemDataDescriptions", "instanceLastModifier"],
            instanceStageStatus: ["instanceSystemDataDescriptions", "instanceStageStatus"],
            instanceStarterId: ["instanceSystemDataDescriptions", "instanceStarterId"],
            processAppName: ["instanceSystemDataDescriptions", "processAppName"],
            bpdName: ["instanceSystemDataDescriptions", "bpdName"],
            instanceId: ["instanceSystemDataDescriptions", "instanceId"],
            instanceProcessApp: ["instanceSystemDataDescriptions", "instanceProcessApp"],
            instanceSnapshot: ["instanceSystemDataDescriptions", "instanceSnapshot"],
            instanceSnapshotId: ["instanceSystemDataDescriptions", "instanceSnapshotId"],
            parentActivityId: ["instanceSystemDataDescriptions", "parentActivityId"],
            parentCaseId: ["instanceSystemDataDescriptions", "parentCaseId"],
            workflowApplication: ["instanceSystemDataDescriptions", "workflowApplication"],
        };
        return i18nUtils.formatLabel(instanceDescription, property);
    };

    i18nUtils.getLabelFromCaseProperty = function getLabelFromCaseProperty(property) {
        var casePropertyLabels = {
        	caseType: ["caseList", "caseType"],
        	executionState: ["caseList", "caseState"],
        	caseIdentifier: ["caseList", "caseIdentifier"],
            name: ["caseList", "name"],
            creationDate: ["caseList", "creationDate"],
            lastModifiedBy: ["caseList", "lastModifiedBy"],
            lastModificationTime: ["caseList", "lastModificationTime"]
        };
        return i18nUtils.formatLabel(casePropertyLabels, property);
    };

    i18nUtils.getLabelFromTaskProperty = function getLabelFromTaskProperty(property) {
        var taskPropertyLabels = {
            WLE_TASK_MULTI_ATTRIBUTES: ["controlTaskList", "kind"],
            taskIsAtRisk: ["controlTaskList", "taskIsAtRisk"],
            taskDueDate: ["controlTaskList", "taskDueDate"],
            taskState: ["controlTaskList", "taskState"],
            taskSubject: ["controlTaskList", "taskSubject"],
            instanceName: ["controlTaskList", "instanceName"],
            taskClosedDate: ["controlTaskList", "taskClosedDate"],
            assignedToRoleDisplayName: ["controlTaskList", "assignedToRoleDisplayName"],
            taskStatus: ["controlTaskList", "taskStatus"],
            taskPriority: ["controlTaskList", "taskPriority"],
            taskActivityType: ["controlTaskList", "taskActivityType"],
            instanceId: ["controlTaskList", "instanceId"],
            instanceAtRiskDate:["controlTaskList", "instanceAtRiskDate"],
            instanceCompletionDate:["controlTaskList", "instanceCompletionDate"],
            instanceCreationDate:["controlTaskList", "instanceCreationDate"],
            instanceLastModificationDate:["controlTaskList", "instanceLastModificationDate"],
            instanceDueDate: ["controlTaskList", "instanceDueDate"],
            instanceCreateDate: ["controlTaskList", "instanceCreateDate"],
            instanceModifyDate: ["controlTaskList", "instanceModifyDate"],
            instanceStatus: ["controlTaskList", "instanceStatus"],
            instanceStageStatus: ["controlTaskList", "instanceStageStatus"],
            instanceProcessApp: ["controlTaskList", "instanceProcessApp"],
            instanceSnapshot: ["controlTaskList", "instanceSnapshot"],
            caseFolderId: ["controlTaskList", "caseFolderId"],
            startingDocumentId: ["controlTaskList", "startingDocumentId"],
            taskActivityName: ["controlTaskList", "taskActivityName"],
            assignedToUser: ["controlTaskList", "assignedToUser"],
            taskReceivedDate: ["controlTaskList", "taskReceivedDate"],
            taskSentTime: ["controlTaskList", "taskSentTime"],
            taskReadTime: ["controlTaskList", "taskReadTime"],
            taskReceivedFrom: ["controlTaskList", "taskReceivedFrom"],
            taskId: ["controlTaskList", "taskId"],
            taskAtRiskTime: ["controlTaskList", "taskAtRiskTime"],
            caseFolderServerName: ["controlTaskList", "caseFolderServerName"],
            startingDocumentServerName: ["controlTaskList", "startingDocumentServerName"],
            bpdName: ["controlTaskList", "bpdName"],
            taskClosedBy: ["controlTaskList", "taskClosedBy"],
            parentCaseId: ["controlTaskList", "parentCaseId"],
            parentActivityId: ["controlTaskList", "parentActivityId"],
            workflowApplication: ["controlTaskList", "workflowApplication"],
            startableServiceName: ["controlActivityViewer", "startableServiceName"]
        };
        return i18nUtils.formatLabel(taskPropertyLabels, property);
    };

    i18nUtils.getTaskSystemDataDescription = function getTaskSystemDataDescription(property) {
        var taskDescriptions = {
            taskIsAtRisk: ["taskSystemDataDescriptions", "taskIsAtRisk"],
            taskDueDate: ["taskSystemDataDescriptions", "taskDueDate"],
            taskState: ["taskSystemDataDescriptions", "taskState"],
            taskSubject: ["taskSystemDataDescriptions", "taskSubject"],
            instanceName: ["taskSystemDataDescriptions", "instanceName"],
            taskClosedDate: ["taskSystemDataDescriptions", "taskClosedDate"],
            assignedToRoleDisplayName: ["taskSystemDataDescriptions", "assignedToRoleDisplayName"],
            taskStatus: ["taskSystemDataDescriptions", "taskStatus"],
            taskPriority: ["taskSystemDataDescriptions", "taskPriority"],
            taskActivityType: ["taskSystemDataDescriptions", "taskActivityType"],
            instanceId: ["taskSystemDataDescriptions", "instanceId"],
            instanceAtRiskDate:["taskSystemDataDescriptions", "instanceAtRiskDate"],
            instanceCompletionDate:["taskSystemDataDescriptions", "instanceCompletionDate"],
            instanceCreationDate:["taskSystemDataDescriptions", "instanceCreationDate"],
            instanceLastModificationDate:["taskSystemDataDescriptions", "instanceLastModificationDate"],
            instanceDueDate: ["taskSystemDataDescriptions", "instanceDueDate"],
            instanceCreateDate: ["taskSystemDataDescriptions", "instanceCreateDate"],
            instanceModifyDate: ["taskSystemDataDescriptions", "instanceModifyDate"],
            instanceStatus: ["taskSystemDataDescriptions", "instanceStatus"],
            instanceProcessApp: ["taskSystemDataDescriptions", "instanceProcessApp"],
            instanceSnapshot: ["taskSystemDataDescriptions", "instanceSnapshot"],
            caseFolderId: ["taskSystemDataDescriptions", "caseFolderId"],
            startingDocumentId: ["taskSystemDataDescriptions", "startingDocumentId"],
            taskActivityName: ["taskSystemDataDescriptions", "taskActivityName"],
            assignedToUser: ["taskSystemDataDescriptions", "assignedToUser"],
            taskReceivedDate: ["taskSystemDataDescriptions", "taskReceivedDate"],
            taskSentTime: ["taskSystemDataDescriptions", "taskSentTime"],
            taskReadTime: ["taskSystemDataDescriptions", "taskReadTime"],
            taskReceivedFrom: ["taskSystemDataDescriptions", "taskReceivedFrom"],
            taskId: ["taskSystemDataDescriptions", "taskId"],
            taskAtRiskTime: ["taskSystemDataDescriptions", "taskAtRiskTime"],
            caseFolderServerName: ["taskSystemDataDescriptions", "caseFolderServerName"],
            startingDocumentServerName: ["taskSystemDataDescriptions", "startingDocumentServerName"],
            bpdName: ["taskSystemDataDescriptions", "bpdName"],
            taskClosedBy: ["taskSystemDataDescriptions", "taskClosedBy"],
            parentCaseId: ["taskSystemDataDescriptions", "parentCaseId"],
            parentActivityId: ["taskSystemDataDescriptions", "parentActivityId"],
            workflowApplication: ["taskSystemDataDescriptions", "workflowApplication"],
            startableServiceName: ["taskSystemDataDescriptions", "startableServiceName"]
        };
        return i18nUtils.formatLabel(taskDescriptions, property);
    };

    i18nUtils.getPriorityLabel = function getPriorityLabel(priority) {
        var messages = bpmext.localization.formatMsg;
        var label = priority;
        switch (priority) {
            case constants.PRIORITY.LOWEST:
            case "Lowest":
                label = messages("controlTaskList", "PriorityVeryLow");
                break;
            case constants.PRIORITY.LOW:
            case "Low":
                label = messages("controlTaskList", "PriorityLow");
                break;
            case constants.PRIORITY.HIGH:
            case "High":
                label = messages("controlTaskList", "PriorityHigh");
                break;
            case constants.PRIORITY.HIGHEST:
            case "Highest":
                label = messages("controlTaskList", "PriorityVeryHigh");
                break;
            default:
                label = messages("controlTaskList", "PriorityMedium");
        }
        return label;
    };
    
    i18nUtils.getActivityTypeLabel = function getActivityTypeLabel(type) {
    	var messages = bpmext.localization.formatMsg;
        var label = type;
        switch (type) {
            case "USER_TASK":
                label = messages("searchFilter", "userTask");
                break;
            case "SERVICE_TASK":
                label = messages("searchFilter", "serviceTask");
                break;
            case "DECISION_TASK":
                label = messages("searchFilter", "decisionTask");
                break;
            default:
                label = messages("searchFilter", "userTask");
        }
        return label;
    };
    
    i18nUtils.getInstanceStatus = function getInstanceStatus(task) {
        var messages = bpmext.localization.formatMsg, label;
        if (task && task.PI_STATUS) {
            switch (task.PI_STATUS) {
                case "Active":
                    label = messages("searchFilter", "active");
                    break;
                case "Completed":
                    label = messages("searchFilter", "completed");
                    break;
                case "Failed":
                    label = messages("searchFilter", "failed");
                    break;
                case "Suspended":
                    label = messages("searchFilter", "suspended");
                    break;
                case "Terminated":
                    label = messages("searchFilter", "terminated");
                    break;
                case "DidNotStart":
                    label = messages("searchFilter", "didNotStart");
                    break;
                default:
                    label = task.PI_STATUS;
            }
        }
        return label;
    };

    i18nUtils.getDueStatusLabel = function getDueStatusLabel(instance) {
        var messages = bpmext.localization.formatMsg;
        var now = new Date();
        var label = instance.executionState || instance.PI_STATUS;
        if (instance) {
            var dueDate = instance.dueDate || instance.PI_DUE;
            var atRiskDate = instance.atRiskDate || instance.PI_AT_RISK_TIME;
            if (instance.executionState === "Completed" || instance.PI_STATUS === "Completed") {
                label = messages("searchFilter", "completed");
            } else if (instance.executionState === "Failed" || instance.PI_STATUS === "Failed") {
                label = messages("searchFilter", "failed");
            } else if (instance.executionState === "Suspended" || instance.PI_STATUS === "Suspended") {
                label = messages("searchFilter", "suspended");
            } else if (instance.executionState === "Terminated" || instance.PI_STATUS === "Terminated") {
                label = messages("searchFilter", "terminated");
            } else if (instance.executionState === "Active" || instance.PI_STATUS === "Active") {
                if (dueDate && now > new Date(dueDate)) {
                    label = messages("controlTaskList", "taskOverdue");
                } else if (atRiskDate && now > new Date(atRiskDate) || i18nUtils.isInstanceAtRisk(instance)) {
                    label = messages("controlTaskList", "taskAtRisk");
                } else if (!instance.DUE && !instance.dueTime && !dueDate) {
                    label = messages("instanceList", "active");
                } else {
                    label = messages("controlTaskList", "taskOnTrack");
                }
            } else if (instance.executionState === "Working" || instance.PI_STATUS === "Working") {
                label = messages("instanceList", "working");
            } /**else if (instance.executionState === "New") {
                label = messages("instanceList", "new");
            } else if (instance.executionState === "Initializing") {
                label = messages("instanceList", "initializing");
            }**/
        }
        return label;
    };

    i18nUtils.getCompletionPercentage = function getCompletionPercentage(instance) {
        var now = new Date();
        var createdDate = new Date(instance.creationTime || instance.creationDate || instance.PI_CREATED);
        var dueDate = new Date(instance.dueDate || instance.PI_DUE);
        var instanceCompletionDuration = dueDate - createdDate;
        return Math.floor(((now - createdDate) / instanceCompletionDuration) * 100);
    };

    i18nUtils.isInstanceAtRisk = function isInstanceAtRisk(instance) {
        return i18nUtils.getCompletionPercentage(instance) > 85;
    };

    i18nUtils.getInstanceDueStatusImageURL = function getInstanceDueStatusImageURL(instance, skipOnTrack) {
        var now = new Date();
        var status, url;
        if (instance) {
            var dueDate = instance.PI_DUE || instance.dueDate;
            var atRiskDate = instance.atRiskDate || instance.PI_AT_RISK_TIME;
            if (instance.executionState === "Completed" || instance.PI_STATUS === "Completed") {
                status = "completed";
            } else if (instance.executionState === "Failed" || instance.PI_STATUS === "Failed") {
                status = "terminated";
            } else if (instance.executionState === "Suspended" || instance.PI_STATUS === "Suspended") {
                status = "suspended";
            } else if (instance.executionState === "Terminated" || instance.PI_STATUS === "Terminated") {
                status = "terminated";
            } else if (instance.executionState === "Active" || instance.PI_STATUS === "Active") {
                if (dueDate && now > new Date(dueDate)) {
                    status = "overdue";
                } else if (atRiskDate && now > new Date(atRiskDate) || i18nUtils.isInstanceAtRisk(instance)) {
                    instance.IS_AT_RISK = true;
                    status = "atRisk";
                } else if (skipOnTrack !== true) {
                    status = "onTrack";
                }
            }
        }
        if (status) {
            url = com_ibm_bpm_coach.getManagedAssetUrl("status_" + status +".png", com_ibm_bpm_coach.assetType_WEB,"SYSWPT");
        }
        return url;
    };

    i18nUtils.getTaskDueStatusImageURL = function getTaskDueStatusImageURL(taskOrInstance, skipOnTrack) {
        var now = new Date();
        var status, url, dueDate = taskOrInstance.DUE || taskOrInstance.dueTime || taskOrInstance.dueDate || taskOrInstance.PI_DUE;
        if (taskOrInstance) {
            if ((taskOrInstance.STATUS || taskOrInstance.status) === "Closed" || (taskOrInstance.STATE || taskOrInstance.state) === "STATE_FINISHED" || taskOrInstance.PI_STATUS === "Completed") {
                status = "completed";
            } else if (dueDate && now > new Date(dueDate)) {
                status = "overdue";
            } else if (taskOrInstance.IS_AT_RISK || now > new Date(taskOrInstance.AT_RISK_TIME || taskOrInstance.atRiskTime) || taskOrInstance.INSTANCE_RISK_STATE == "AtRisk") {
                status = "atRisk";
            } else if (skipOnTrack !== true) {
                status = "onTrack";
            }
        }
        if (status) {
            url = com_ibm_bpm_coach.getManagedAssetUrl("status_" + status +".png", com_ibm_bpm_coach.assetType_WEB,"SYSWPT");
        }
        return url;
    };

    i18nUtils.getStatusLabel = function getStatusLabel(taskOrInstance) {
        var messages = bpmext.localization.formatMsg;
        var now = new Date();
        var label;
        if (taskOrInstance) {
            if ((taskOrInstance.STATUS || taskOrInstance.status) === "Closed" || (taskOrInstance.STATE || taskOrInstance.state) === "STATE_FINISHED") {
                label = messages("controlTaskList", "taskCompleted");
            } else if (now > new Date(taskOrInstance.DUE || taskOrInstance.dueTime || taskOrInstance.dueDate)) {
                label = messages("controlTaskList", "taskOverdue");
            } else if (taskOrInstance.IS_AT_RISK || now > new Date(taskOrInstance.AT_RISK_TIME || taskOrInstance.atRiskTime)) {
                label = messages("controlTaskList", "taskAtRisk");
            } else if (!taskOrInstance.DUE && !taskOrInstance.dueTime && !taskOrInstance.dueDate) {
                label = messages("instanceList", "active");
            } else {
                label = messages("controlTaskList", "taskOnTrack");
            }
        }
        return label;
    };

    i18nUtils.getStatusClassName = function getStatusClassName(task) {
        var now = new Date();
        var className;
        if (task) {
            if ((task.STATUS || task.status) === "Closed" || (task.STATE || task.state) === "STATE_FINISHED") {
                className = "completedTask";
            } else if (now > new Date(task.DUE || task.dueTime)) {
                className = "overdueTask";
            } else if (task.IS_AT_RISK || now > new Date(task.AT_RISK_TIME || task.atRiskTime)) {
                className = "atRiskTask";
            } else {
                className = "onTrackTask";
            }
        }
        return className;
    };

    /**
     * @param {integer} daysUntil
     * @return {string}
     */
    i18nUtils.getDueLabel = function getDueLabel(daysUntil) {
        var labelName;
        if (daysUntil < -1) {
            labelName = "dueDaysAgo";
            daysUntil *= -1;
        } else if (daysUntil === -1) {
            labelName = "dueYesterday";
        } else if (daysUntil === 0) {
            labelName = "dueToday";
        } else if (daysUntil === 1) {
            labelName = "dueTomorrow";
        } else {
            labelName = "dueIn";
        }
        return bpmext.localization.formatMsg("instanceUI", labelName, daysUntil);
    };

    /**
     * @param {integer} daysUntil
     * @return {string}
     */
    i18nUtils.getCompletedLabel = function getCompletedLabel(daysUntil) {
        var labelName;
        if (daysUntil < -1) {
            labelName = "completedDaysAgo";
            daysUntil *= -1;
        } else if (daysUntil === -1) {
            labelName = "completedYesterday";
        } else if (daysUntil === 0) {
            labelName = "completedToday";
        } 
        return bpmext.localization.formatMsg("instanceUI", labelName, daysUntil);
    };

    /**
     * @param {integer} daysUntil
     * @return {string}
     */
    i18nUtils.getModifiedLabel = function getModifiedLabel(daysUntil) {
        var labelName;
        if (daysUntil < -1) {
            labelName = "modifiedDaysAgo";
            daysUntil *= -1;
        } else if (daysUntil === -1) {
            labelName = "modifiedYesterday";
        } else if (daysUntil === 0) {
            labelName = "modifiedToday";
        } 
        return bpmext.localization.formatMsg("instanceUI", labelName, daysUntil);
    };

    i18nUtils.createSkeletonTableColumns = function createSkeletonTableColumns(numOfColumns, showActionMenu) {
        var x = 0, skeletonColumn = [];
        while(x < numOfColumns){
            skeletonColumn.push({
                visibility: true,
                renderAs: "C",
                dataElementName: "skeleton",
                label:""
            });
            x++;
        }
        if (showActionMenu) {
            skeletonColumn.push({
                visibility: true,
                renderAs: "C",
                dataElementName: "skeletonActionMenu",
                label:""
            });
        }
        return skeletonColumn;
    };

    i18nUtils.createSkeletonTableData = function createSkeletonTableData(numOfRows) {
        var x = 0, skeletonData = [];
        while(x < numOfRows){
            x++;
            var row = {};
            skeletonData.push(row);
        }
        return skeletonData;
    };

    i18nUtils.removeScopedFileds = function removeScopedFileds(systemData, isPXServer) {
        var scopeFilters = isPXServer ? constants.DEFAULT_PX_SCOPE_FILTERS : constants.DEFAULT_SCOPE_FILTERS;
        var sytemDataWithoutScope = systemData;
        for(var x=0; x<scopeFilters.length; x++){
            for(var y =0; y < sytemDataWithoutScope.length; y++){
                if(scopeFilters[x] == sytemDataWithoutScope[y].name){
                    sytemDataWithoutScope.splice(y,1);
                    break;
                }
            }
        }
        return sytemDataWithoutScope;
    };

    i18nUtils.getFieldsToHide = function getFieldsToHide(isPXServer, instanceFields, caseMode) {
        if(instanceFields){
            if(isPXServer){
            	if(caseMode){
            		return constants.HIDDEN_PX_CASE_INSTANCE_COLUMN_FIELDS;
            	}else{
            		return constants.HIDDEN_PX_INSTANCE_COLUMN_FIELDS;
            	}
                
            }else{
            	if(caseMode){
            		return constants.HIDDEN_CASE_INSTANCE_COLUMN_FIELDS;
            	}else{
            		return constants.HIDDEN_INSTANCE_COLUMN_FIELDS;
            	}
            }
        }else{
            if(isPXServer){
                return constants.HIDDEN_PX_COLUMN_FIELDS;
            }else{
                return constants.HIDDEN_COLUMN_FIELDS;
            }
        }
    };

    return i18nUtils;
});
