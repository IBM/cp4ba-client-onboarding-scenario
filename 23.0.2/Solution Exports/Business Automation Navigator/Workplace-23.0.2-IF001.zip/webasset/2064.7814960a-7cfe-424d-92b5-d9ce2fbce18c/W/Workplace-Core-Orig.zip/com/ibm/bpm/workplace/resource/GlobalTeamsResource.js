/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define("com.ibm.bpm.workplace.resources/GlobalTeamsResource", ["./resourceBase"], function(resource) {
    "use strict";
    var ROUTE = resource._buildUrl("${urlPrefix}/v1/globalTeams", {
        urlPrefix: resource.contextRoot.federatedURL || resource.contextRoot.rest
    });

    /**
     * Get all teams the current user belongs to.
     *
     * @param {Object} [options] - optional params to pass to the underlying API
     * @param {String} [options.filter] - Filter the global teams and include only team names that match the specified filter condition. The filter is case insensitive.
     *                                  Example: "hiring*" will return all teams whose names begin with "hiring".
     * @param {Number} [options.size] - Specifies the maximum number of entities to be returned.
     *                                  If a number is not specified, the default size (100) defined for the query will be used.
     * @returns {Promise} that resolves to the system information
     */
    function get(options) {
        var url = ROUTE,
            query = {};
        // build query params
        if (options) {
            if (options.filter) {
                query.filter = encodeURIComponent(options.filter);
                query.encodedParams = "filter";
            }
            if (options.size > 0) {
                query.size = options.size;
            }
        }
        // set federationMode
        query.federationMode = resource.isFederated;
        return resource
            .get(url, {
                query: query
            })
            .then(function success(res) {
                return resource.isFederated ? res.teams : res.data.teams;
            });
    }

    // module.exports
    return {
        get: get
    };
});
