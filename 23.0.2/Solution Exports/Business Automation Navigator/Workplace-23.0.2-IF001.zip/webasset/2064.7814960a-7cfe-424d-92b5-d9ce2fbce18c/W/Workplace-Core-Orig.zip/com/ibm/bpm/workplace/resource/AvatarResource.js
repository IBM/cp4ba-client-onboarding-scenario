/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define("com.ibm.bpm.workplace.resources/AvatarResource", ["./resourceBase"], function(resource) {
    "use strict";
    var CURRENT = "current",
        ROUTE = resource._buildUrl("${urlPrefix}/v1/avatar/", { urlPrefix: resource.contextRoot.rest });

    /**
     * Get Avatar information of user
     *
     * @param {String|Number} [username] - user name or user id of user, default is "current" for the current user
     * @returns {Promise} a promise that resolves to the avatar information
     */
    function get(username) {
        return resource.get(ROUTE + (username || CURRENT)+"?"+Date.now()).then(function success(res) {
            res.data.toDataURI = function toDataURI() {
                return resource._buildUrl("data:image/${imageFormat};charset=utf-8;base64,${userAvatarImage}", this);
            };
            return res.data;
        });
    }

    /**
     * Set an avatar for the user
     *
     * @param {Object} options - params to pass to the underlying API
     * @param {String|Number} [options.username] - user name or user id of user, default is "current" for the current user
     * @param {File} options.avatar - file object of the avatar image to save
     *
     * @returns {Promise} - a promise that resolves to the new avatar information
     */
    function set(options) {
        if (options && options.avatar) {
            var formData = new FormData();
            formData.append("avatar", options.avatar);
            return resource.post(ROUTE + (options.username || CURRENT), {
                data: formData,
                headers: {
                    "Content-Type": undefined
                }
            });
        }
    }

    /**
     * Delete avatar of user
     *
     * @param {String|Number} [username] - user name or user id of user, default is "current" for the current user
     * @returns {Promise} a promise that resolves to the avatar information
     */
    function deleteAvatar(username) {
        return resource.del(ROUTE + (username || CURRENT)).then(function success(res) {
            return res.data;
        });
    }

    // module.exports
    return {
        CURRENT: CURRENT,
        get: get,
        set: set,
        deleteAvatar: deleteAvatar
    };
});
