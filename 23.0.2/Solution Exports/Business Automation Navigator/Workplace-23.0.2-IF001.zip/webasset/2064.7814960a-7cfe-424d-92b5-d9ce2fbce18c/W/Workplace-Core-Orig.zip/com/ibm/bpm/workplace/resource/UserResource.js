/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define("com.ibm.bpm.workplace.resources/UserResource", ["dojo/Deferred", "./resourceBase"], function(Deferred, resource) {
    "use strict";
    var ROUTE = "${urlPrefix}/v1/user",
        UPDATE_ROUTE = ROUTE + "/${username}",
        PARTS = {
            ALL: "all",
            MEMBERSHIPS: "memberships",
            NONE: "none"
        },
        ACTIONS = {
            SET_PREFERENCES: "setPreferences"
        },
        CURRENT = "current",
        PREFERENCE = {
            alertOnAssignAndRun: "Alert On Assign And Run",
            baseTextDirection: "Base Text Direction",
            blueworksLiveEmail: "Blueworks Live Email",
            blueworksLiveServerUrl: "Blueworks Live Server URL",
            calendarType: "Calendar Type",
            federatedPortalDashboardDisplayOrder: "Federated Portal Dashboard Display Order",
            hideInstanceUiUpdateWarning: "Hide Instance UI Update Warning",
            hideRemoveTrackedVariableWarning: "Hide Remove Tracked Variable Warning",
            image: "Image",
            locale: "Locale",
            phoneNumber: "Phone Number",
            portalDashboardDisplayOrder: "Portal Dashboard Display Order",
            portalDefaultPage: "Portal Default Page",
            portalMentionTimestamp: "Portal Mention Timestamp",
            portalNotificationNewTaskToMe: "Portal Notification New Task To Me",
            portalNotificationNewTaskToMyGroup: "Portal Notification New Task To My Group",
            portalNotificationOnActivityChange: "Portal Notification On Activity Change",
            portalNotificationPostMention: "Portal Notification Post Mention",
            portalOpenTaskInNewWindow: "Portal Open Task In New Window",
            portalTaskListView: "Portal Task List View",
            primaryRole: "Primary Role",
            rulesLocale: "Rules Locale",
            sendConnectionsNotificationOnNewTask: "Send Connections Notification On New Task",
            showUnfollowMessages: "Show Unfollow Messages",
            taskEmailAddress: "Task Email Address",
            taskNotification: "Task Notification",
            title: "Title",
            userData: "User Data",
            viewMode: "View Mode"
        },
        _userPreferencesPromise; // promise to cache the user preferences

    /**
     * Get user details
     *
     * @param {Object} [options] - optional params to pass to the underlying API
     * @param {String} [options.userName] - username of the user. if not specified information about "current" user will be returned
     * @param {String} [options.userID] - user id of the user. if not specified information about "current" user will be returned
     * @param {String[]} [options.parts] - parts to request, default is [ALL]. See #Parts
     * @param {Boolean} [options.includeInternalMemberships] - true to include internal memberships, default is false
     * @param {Boolean} [options.includeMembershipsAsIDs] - true to return memberships as Ids, default is false
     * @param {Boolean} [options.includeEditableUserPreferences] - true to include the list of user preferences which can be managed by the user.
     * @param {String[]} [options.groups] - list of groups to verify user membership
     * @param {Boolean} [options.refresh] - true to bust the cache and reload the user preferences
     * @param {Boolean} [options.noCache] - true to not cache the resulting promise (used in cases to look up other users)
     * @returns {Promise} promise that resolves to the list of users
     */
    function get(options) {
        var url, query, retPromise = _userPreferencesPromise;
        if (!_userPreferencesPromise || (options && (options.refresh || options.noCache))) {
            // build url based on options params
            url = resource._buildUrl(ROUTE, {
                urlPrefix: resource.contextRoot.rest
            });

            // build default query params
            query = {
                parts: (options && options.parts) || PARTS.ALL,
                includeInternalMemberships: (options && options.includeInternalMemberships) || false,
                includeEditableUserPreferences: true,
                userName: (options && options.username) || undefined,
                userID: (options && options.userID) || undefined
            };
            if (query.userName) {
                query.userName = encodeURIComponent(query.userName);
                query.encodedParams = "username";
            }
            if(options && (options.includeEditableUserPreferences === false)) {
            	query.includeEditableUserPreferences = false;
            }

            retPromise = resource
                .get(url, {
                    query: query
                })
                .then(
                    function success(res) {
                        return res.data;
                    }
                );
            if (!options || (options && !options.noCache)) {
                _userPreferencesPromise = retPromise;
            }
        }
        return retPromise;
    }

    /**
     * Set user preferences, using a preferences object. See # PREFERENCE to see a list of available user preferences.
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {String} [options.username] - username or id of the user. if not specified information about "current" user will be returned
     * @param {Object<String, String>} options.preferences - A collection of one or more user preferences in the form of an object, for example {"email":"myuser@myhost.com"}
     *                                                          See #PREFERENCE for available preferences
     * @returns {Promise} a promise that resolves to the updated user information
     */
    function setPreferences(options) {
        var url, query, data;
        if (options && options.preferences) {
            // build url based on options params
            url = resource._buildUrl(UPDATE_ROUTE, {
                urlPrefix: resource.contextRoot.rest,
                username: options.username || CURRENT
            });

            // build default query params
            query = {
                action: ACTIONS.SET_PREFERENCES
            };

            data = {
                // prefs need to be a stringified JSON object
                prefs: options.preferences
            };
            return resource
                .put(url, {
                    query: query,
                    data: JSON.stringify(data)
                })
                .then(
                    function success(res) {
                        get({refresh: true});
                        return res.data;
                    }, function error(err) {
                        if (err && err.response && err.response.data && err.response.data.status === 500 && err.response.data.errorNumber === "CWMFS4021E" ) {
                            resource.showError(bpmext.localization.formatMsg("Errors", "noFederatedSystem"), err);
                        } else {
                            resource.showError(bpmext.localization.formatMsg("Errors", "updateProfileError"), err);
                        }
                        throw err;
                    }
                );
        }
    }

    /**
     * Logs out the current user
     * @returns {String} The logout page location
     */
    function getLogoutPage() {
        return window.location.href + "/logout.jsp";
    }

    return {
        PARTS: PARTS,
        PREFERENCE: PREFERENCE,
        get: get,
        setPreferences: setPreferences,
        getLogoutPage: getLogoutPage
    };
});
