/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define(["com.ibm.bpm.workplace.core/valueFormatter",], function ( valueFormatter) {
    "use strict";

	var supportedLocales = ["ar","bg","cs","da","de","el","es","es_MX","fi","fr","he","hu","it","iw","ja","ko","nb","nl","no","pl","pt","pt_BR","ro","ru","sk","sv","tr","zh","zh_TW"];

	var replaceStr = function(format, args)
	{
		return format.replace(/{(\d+)}/g, function(match, number) {
			return (args[number] || match) + "";
		});
	};

	var initLocalization = function(bpmext, messages, defaultMessages, locale) {
		if (bpmext.localization) {
			//merge messages
			Object.keys(messages).forEach (function(key) {
				bpmext.localization.messages[key] = messages[key];
			});
			Object.keys(defaultMessages).forEach (function(key) {
				bpmext.localization.defaultMessages[key] = defaultMessages[key];
			});
			bpmext.localization.workplaceFormatDate = valueFormatter.formatDate;
			bpmext.localization.workplaceFormatNumber = valueFormatter.formatNumber;
		} else {
			bpmext.localization = {
				messages: messages,
				defaultMessages: defaultMessages,
				formatString: function(format) {
					return replaceStr(format, Array.prototype.slice.call(arguments, 1));
				},
				formatMsg: function(root, key) {
					var format;
					if(messages[root] && messages[root][key]){
						format = messages[root][key];
					}else if(defaultMessages[root] && defaultMessages[root][key]){
						format = defaultMessages[root][key];
					}

					if(format != null)
					{
						return replaceStr(format, Array.prototype.slice.call(arguments, 2));
					}

					return "MESSAGE[" + locale + "->" + key + "]";
				},
			    workplaceFormatDate: valueFormatter.formatDate,
			    workplaceFormatNumber: valueFormatter.formatNumber

			};
		}
	};

	return {
		initMessages: function(locale, designer, callback)
		{
			// Setting Locale format
			valueFormatter.setLocaleFormat();
			if(locale === null) {
				locale = document.documentElement.lang.toLowerCase().replace(/[-_]/,"-");
				if (locale === "pt-br"){
					locale = "pt_BR";
				} else if (locale === "zh-tw"){
					locale = "zh_TW";
				} else if (locale === "zh-cn") {
					locale = "zh";
				} else if (locale === "ca") {
					locale = "es";
				} else if (locale === "en-ca" || locale === "en-gb") {
					locale = "";
				} else if (locale === "fr-ca") {
					locale = "fr";
				} else if (locale === "es-mx") {
					locale = "es_MX";
				}
			}
			//var moduleName = ""; //Test for undefined locale
			var moduleName = supportedLocales.indexOf(locale) !== -1 ? ("_" + locale) : "";
			var modulePath = "com.ibm.bpm.workplace.localization/messages" + moduleName;
			var defaultModulePath = "com.ibm.bpm.workplace.localization/messages";

			if(designer) {
				require([modulePath, defaultModulePath], function(messages, defaultMessages) {
					initLocalization(bpmext, messages, defaultMessages, locale);
					callback();
					//console.debug("Localization map loaded");
				});
			} else {
				require(["com.ibm.bpm.coach/bpmEventHelper", modulePath, defaultModulePath], function(bpmext, messages, defaultMessages) {
					initLocalization(bpmext, messages, defaultMessages, locale);
					//console.debug("Localization map loaded");
				});
			}
		}
	};
});