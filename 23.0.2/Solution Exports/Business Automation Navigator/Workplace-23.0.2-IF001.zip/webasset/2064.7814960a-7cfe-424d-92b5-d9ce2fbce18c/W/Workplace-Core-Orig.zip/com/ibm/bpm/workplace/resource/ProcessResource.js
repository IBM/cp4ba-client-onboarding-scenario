/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define("com.ibm.bpm.workplace.resources/ProcessResource", ["./resourceBase"], function (resource) {
    "use strict";
    var ROUTE = "${urlPrefix}/v1/process/${piid}",
    	BULKDETAILROUTE = "${urlPrefix}/v1/process?action=getdetails",
    	BUSINESSDATAROUTE = "${urlPrefix}/v1/process/businessData",
        PARTS = {
            ALL: "all",
            NONE: "none",
            HEADER: "header",
            DATA_MODEL: "dataModel",
            DATA: "data",
            BUSINESSDATA: "businessData",
            DIAGRAM: "diagram",
            EXECUTION_TREE: "executionTree",
            ACTIONS: "actions",
            SUMMARY: "summary",
            RELATIONSHIPS: "relationships"
        },
        ACTIONS = {
    		GETDETAILS: "getdetails",
            ADD_DOCUMENT: "addDocument",
            COMMENT: "comment",
            TRIGGER: "trigger",
            UPDATE: "update",
            TERMINATE: "terminate",
            SUSPEND: "suspend",
            RESUME: "resume",
            RETRY: "retry"
        },
        DOC_TYPES = {
            FILE: "file",
            URL: "url"
        };

    /**
     * Get Bulk Process Instance details
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {Number[]} options.piids - Comma-separated list of Process instance Id to get details for
     * @param {String[]} [options.parts] - Optional parts to request, default is [ALL, ACTIONS]. See #PARTS
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     *
     * @returns {Promise} promise that resolved to the response object
     */
    function getBulkDetails(options) {
        var url, instanceIds, parts;
        if (options && Array.isArray(options.piids) && options.piids.length > 0) {
            url = resource._buildUrl(BULKDETAILROUTE, {
                urlPrefix: resource.contextRoot.rest
            });
            instanceIds = (Array.isArray(options.piids) && options.piids);
            // check parts or assign the default value
            parts = (Array.isArray(options.parts) && options.parts) || [PARTS.ALL, PARTS.ACTIONS];
            return resource
                .get(url, {
                    query: {
                        federationMode: resource.isFederated,
                        instanceIds: instanceIds.join(),
                        parts: parts.join()
                    },
                    systemID: options.systemID
                })
                .then(function success(res) {
                    var data = resource.isFederated ? res : res.data;
                    // add systemID to the returned object
                    if (res.systemID) {
                        data.systemID = res.systemID;
                    }
                    return data;
                }, function error(err) {
                    if (err && err.response && err.response.status === 404) {
                        resource.showError(bpmext.localization.formatMsg("Errors", "processInstanceNotAvailable"), err);
                    }
                    throw err;
                });
        }
    }
    
    /**
     * Get Bulk Business Data for Process Instances
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {Number[]} options.piids - Comma-separated list of Process instance Id to get business data for
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     *
     * @returns {Promise} promise that resolved to the response object
     */
    function getBusinessData(options) {
    	var url, instanceIds;
        if (options && Array.isArray(options.piids) && options.piids.length > 0) {
            url = resource._buildUrl(BUSINESSDATAROUTE, {
                urlPrefix: resource.contextRoot.rest
            });
            instanceIds = (Array.isArray(options.piids) && options.piids);
            return resource
                .get(url, {
                    query: {
                        federationMode: resource.isFederated,
                        instanceIds: instanceIds.join()
                    },
                    systemID: options.systemID
                })
                .then(function success(res) {
                    var data = resource.isFederated ? res : res.data;
                    // add systemID to the returned object
                    if (res.systemID) {
                        data.systemID = res.systemID;
                    }
                    return data;
                }, function error(err) {
                    if (err && err.response && err.response.status === 404) {
                        resource.showError(bpmext.localization.formatMsg("Errors", "processInstanceNotAvailable"), err);
                    }
                    throw err;
                });
        }
    }
    
    /**
     * Get Process Instance details
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {Number} options.piid - Process instance Id to get details for
     * @param {String[]} [options.parts] - Optional parts to request, default is [ALL, ACTIONS]. See #PARTS
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     *
     * @returns {Promise} promise that resolved to the response object
     */
    function get(options) {
        var url, parts;
        if (options && options.piid) {
            url = resource._buildUrl(ROUTE, {
                urlPrefix: resource.contextRoot.rest,
                piid: options.piid
            });
            // check parts or assign the default value
            parts = (Array.isArray(options.parts) && options.parts) || [PARTS.ALL, PARTS.ACTIONS];
            return resource
                .get(url, {
                    query: {
                        federationMode: resource.isFederated,
                        parts: parts.join()
                    },
                    systemID: options.systemID
                })
                .then(function success(res) {
                    var data = resource.isFederated ? res : res.data;
                    // add systemID to the returned object
                    if (res.systemID) {
                        data.systemID = res.systemID;
                    }
                    return data;
                }, function error(err) {
                    if (err && err.response && err.response.status === 404) {
                        resource.showError(bpmext.localization.formatMsg("Errors", "processInstanceNotAvailable"), err);
                    }
                    throw err;
                });
        }
    }

    /**
     * Update the due date for a process instance. If no due date is provided, the due date on the instance will be disabled
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {Number} options.piid - Process instance Id to get details for
     * @param {Date} [options.dueDate] - optional date object, if not provided the instance due date will be disabled
     * @param {String[]} [options.parts] - Optional parts to request, default is [SUMMARY]. See #PARTS
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     *
     * @returns {Promise} promise that resolved to the response object
     */
    function updateDueDate(options) {
        var url, parts, dueDate;
        if (options && options.piid) {
            url = resource._buildUrl(ROUTE, {
                urlPrefix: resource.contextRoot.rest,
                piid: options.piid
            });

            // check parts or assign the default value
            parts = (Array.isArray(options.parts) && options.parts) || [PARTS.SUMMARY];

            // check for date object
            if (options.dueDate instanceof Date) {
                dueDate = options.dueDate.toISOString();
            }

            return resource
                .put(url, {
                    query: {
                        action: ACTIONS.UPDATE,
                        parts: parts.join(),
                        encodedParams: "dueDate",
                        dueDate: encodeURIComponent(dueDate || "none")
                    },
                    systemID: options.systemID
                })
                .then(function success(res) {
                    var data = resource.isFederated ? res : res.data;
                    // add systemID to the returned object
                    if (res.systemID) {
                        data.systemID = res.systemID;
                    }
                    return data;
                });
        }
    }

    /**
     * Post a comment on a process instance.
     *
     * @param {Object} options - params to pass to the underlying API
     * @param {Number} options.piid - Process instance Id
     * @param {String} options.comment - comment text to post. text will be encoded before making request
     * @param {String} [options.origCommentId] - parent comment id
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     * @param {String[]} [options.parts] - Optional parts to request, default is [NONE]. See #PARTS
     * @returns {Promise} a promise that resolves to the result of posting a comment
     */
    function postComment(options) {
        var url,
            query = {};
        if (options && options.piid && options.comment) {
            url = resource._buildUrl(ROUTE, {
                urlPrefix: resource.contextRoot.rest,
                piid: options.piid
            });

            // build query params
            query.action = ACTIONS.COMMENT;
            query.comment = options.comment;
            query.origCommentId = options.origCommentId;
            query.parts = ((Array.isArray(options.parts) && options.parts) || [PARTS.NONE]).join();

            return resource
                .post(url, {
                    query: query,
                    systemID: options.systemID
                })
                .then(function success(res) {
                    // add systemID to the returned object
                    if (res.systemID) {
                        res.data.systemID = res.systemID;
                    }
                    return res.data;
                });
        }
    }

    /**
     * Add a file or a url document to the process instance.
     *
     * @param {Object} options - params to pass to the underlying API
     * @param {Number} options.piid - Process instance Id to get details for
     * @param {File} [options.file] - File to upload, this optional if providing an external url
     * @param {String} [options.url] - External url to add to the process instance
     * @param {String} [options.name] - optional name for the uploaded file or url, defaults to the name of the file or the whole external url
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     * @param {String[]} [options.parts] - Optional parts to request, default is [NONE]. See #PARTS
     * @returns {Promise} a promise that resolves to the result of posting a comment
     */
    function addDocument(options) {
        var url,
            query = {},
            formData;
        if (options && options.piid && (options.file || options.url)) {
            url = resource._buildUrl(ROUTE, {
                urlPrefix: resource.contextRoot.rest,
                piid: options.piid
            });

            // build query params
            query.action = ACTIONS.ADD_DOCUMENT;
            query.parts = options.parts || [PARTS.NONE];

            if (options.file instanceof File) {
                // build form data
                formData = new FormData();
                formData.append("data", options.file);
                query.docType = DOC_TYPES.FILE;
                query.name = options.name || options.file.name;
            } else {
                // build url query data
                query.docType = DOC_TYPES.URL;
                query.docUrl = options.url;
                query.name = options.name || options.url;
            }

            // make the request
            return resource
                .post(url, {
                    query: query,
                    data: formData,
                    headers: {
                        "Content-Type": undefined
                    },
                    systemID: options.systemID
                })
                .then(function success(res) {
                    // add systemID to the returned object
                    if (res.systemID) {
                        res.data.systemID = res.systemID;
                    }
                    return res.data;
                });
        }
    }

    /**
     * Get Process Instance error details
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {Number} options.piid - Process instance Id to get details for
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     *
     * @returns {Promise} promise that resolved to the response object
     */
    function getError(options) {
        var url,
            endpoint = "${urlPrefix}/v1/process/errors?instanceIds=${piids}";

        if (options && options.piid) {
            url = resource._buildUrl(endpoint, {
                urlPrefix: resource.contextRoot.rest,
                piids: options.piid
            });

            // check parts or assign the default value
            return resource.put(url, { systemID: options.systemID }).then(function success(res) {
                var data = resource.isFederated ? res : res.data;
                // add systemID to the returned object
                if (res.systemID) {
                    data.systemID = res.systemID;
                }
                return data;
            });
        }
    }

    /**
     * Perform suspend, resume, terminate, retry for the given process
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {Number} options.piid - Process instance Id to get details for
     * @param {String} options.action - The action to perform on the process instance, [suspend, resume, terminate, retry]
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     * @param {String[]} [options.parts] - optional parts, A string indicating which parts of the response data should be returned. [header, dataModel, diagram, executionTree, all(default), none]
     *
     * @returns {Promise} promise that resolved to the response object
     */
    function performAction(options) {
        var url,
            query = {};

        if (options && options.piid && options.action) {
            url = resource._buildUrl(ROUTE, {
                urlPrefix: resource.contextRoot.rest,
                piid: options.piid
            });

            // build query params
            query.action = options.action;
            query.parts = ((Array.isArray(options.parts) && options.parts) || [PARTS.NONE]).join();

            return resource
                .put(url, {
                    query: query,
                    systemID: options.systemID
                })
                .then(function success(res) {
                    // add systemID to the returned object
                    if (res.systemID) {
                        res.data.systemID = res.systemID;
                    }
                    return res.data;
                });
        }
    }

    /**
     * Report an errored instance
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {Number} options.piid - Process instance Id to get details for
     * @param {String} options.systemID - systemID. This parameter is required when federated
     *
     * @returns {Promise} promise that resolved to the response object
     */
    function reportInstanceError(options) {
        //TODO move this into its own resource. It shouldn't be here since this is a federated API and not a BAW's
        if (options && options.piid && options.systemID) {
            var url = resource._buildUrl(resource.contextRoot.federatedURL + "/v2/update/bpd", {
                urlPrefix: resource.contextRoot.rest
            });

            if (options.systemID) {
                url += "/" + options.systemID;
            }

            if (options.piid) {
                url += "/" + options.piid;
            }

            return resource
                .put(url, {
                    query: {
                        updateTasks: true
                    }
                })
                .then(function success(res) {
                    // add systemID to the returned object
                    if (res.systemID) {
                        res.data.systemID = res.systemID;
                    }
                    return res.data;
                });
        }
    }

    /**
     *  Get the ad-hoc activities for the process
     *
     * @param {Object} options - params to pass to the underlying API
     * @param {Number} options.piid - process instance id
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     * @returns {Promise} promise that resolves to the URL
     */
    function getAdHocActivities(options) {
        var url;
        if (options && options.piid) {
            // build URL
            url = resource._buildUrl(ROUTE, {
                urlPrefix: resource.contextRoot.rest,
                piid: options.piid
            });
            url += "/adHocActivities";

            return resource.get(url, {systemID: options.systemID}).then(
                function success(res) {
                    var data = resource.isFederated ? res : res.data;
                    // add systemID to the returned object
                    if (res.systemID) {
                        data.systemID = res.systemID;
                    }
                    return data;
                }, function error (err) {
                    if (err && err.response && err.response.status === 404) {
                        resource.showError(bpmext.localization.formatMsg("Errors", "processInstanceNotAvailable"), err);
                    }
                    throw err;
                }
            );
        }
    }

    return {
        PARTS: PARTS,
        ACTIONS: ACTIONS,
        DOC_TYPES: DOC_TYPES,
        getBulkDetails: getBulkDetails,
        getBusinessData: getBusinessData,
        get: get,
        updateDueDate: updateDueDate,
        postComment: postComment,
        addDocument: addDocument,
        getError: getError,
        performAction: performAction,
        reportInstanceError: reportInstanceError,
        getAdHocActivities: getAdHocActivities
    };
});
