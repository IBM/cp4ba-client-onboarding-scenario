/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define("com.ibm.bpm.workplace.resources/ProcessesResource", ["./resourceBase"], function(resource) {
    "use strict";
    var ROUTE = resource._buildUrl("${urlPrefix}/${pathParam}", {
            urlPrefix: resource.contextRoot.federatedURL || resource.contextRoot.rest,
            pathParam: resource.isFederated ? "v1/instances" : "v1/processes/search"
        }),
        INTERACTION = {
            ALL: "all",
            ACTIVE: "active",
            WORKING: "Working",
            COMPLETED: "completed",
            FAILED: "failed",
            TERMINATED: "Terminated",
            DID_NOT_START: "Did_not_Start",
            SUSPENDED: "Suspended"
        },
    	TYPE = {
            PROCESSES: "Process",
            WORKSTREAMS: "Workstream",
            CASES: "Case"
        };

    /**
     * Get a list of Process Instance
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {String[]} options.statusFilter -  Comma-separated list of status to get the instance list
     * @param {String[]} options.stageFilter -  Comma-separated list of case stage to get the instance list
     * @param {String[]} [options.projectFilter] - Optional project to get the instance list, default is all
     * @param {String[]} [searchFilterScope] - Optional search filter scope: allowable values are AppShortName, InstanceName, TemplateId, All
     * @param {String} [options.searchFilter] - Optional name or short name of process application, or Case type.
     * @param {String} [options.caseScope] - Optional case search scope: allowable values are Allowed, Assigned.
     * @param {String} [options.fullTextSearchFilter] - Optional search terms to filter the list of instances, the search spans all instance fields.
     * @param {String} [options.type] - Optional type of instances, workstream, case or process
     * @param {String} [options.createdAfter] - Optional created after a specified date
     * @param {String} [options.createdBefore] - Optional created before a specified date
     * @param {String} [options.modifiedAfter] - Optional modified after a specified date
     * @param {String} [options.modifiedBefore] - Optional modified before a specified date
     * @param {String[]} [options.starterId] - Optional created by some specific users
     * @param {String} [options.lastModifiedBy] - Optional last modified by a specified user
     * @param {Number} [options.offset] - offset is calculated via [options.offset] x [options.limit]
     * @param {Number} [options.limit] - number of instances per page
     *
     * @returns {Promise} promise that resolved to the response object
     */
    function get(options) {
        var url = ROUTE,
            query = {},
            data = {};

        if (options) {
            query[resource.isFederated ? "size" : "limit"] = options.limit || 1000;
            if (options.offset != null){
                query.offset = options.offset * options.limit;
            }

            if (options.type) {
            	if(TYPE.CASES === options.type) {
            		query.instanceType = "Case";
            	} else if ((options.type === TYPE.WORKSTREAMS) || (options.type === TYPE.PROCESSES)){
            		query.instanceType = "BPD";
            		query.caseScope = null;
            		if(TYPE.WORKSTREAMS === options.type) {
            			query.processTypeFilter = "Workstream";
            		} else {
            			query.processTypeFilter = "Workflow";
            		}
            	}
            }

            if(resource.isFederated) {
                query.includeAllBusinessData = options.includeBusinessData || true;
                if (options.calcStats){
                    query.calcStats = options.calcStats;
                }
                if (options.alphabeticalSort){
                    query.alphabeticalSort = options.alphabeticalSort;
                }
                query.caseScope = options.caseScope || "Allowed";
                // if specifies case stage, need set instanceType to case; otherwise it will return processes
                if(query.stageStatusFilter) {
                    query.instanceType = "Case";
                }
                // For status, Case use working while bpd use active
                if(query.statusFilter && query.statusFilter.indexOf(INTERACTION.ACTIVE) !== -1) {
                    if(query.instanceType) {
                        if(query.instanceType === "Case") {
                            query.statusFilter = query.statusFilter.replace(INTERACTION.ACTIVE, INTERACTION.WORKING);
                        }
                    } else {
                        query.statusFilter = query.statusFilter.concat("," + INTERACTION.WORKING);
                    }
                }

                // prepare data params
                data = {
                    size: query.size,
                    id: (options && options.id) || 0,
                    name: (options && options.name) || "",
                    fields: (options && options.fields) || [],
                    interaction: (options && options.interaction) || INTERACTION.ACTIVE,
                    conditions: (options && options.conditions) || [],
                    sort: (options && options.sort) || []
                };

                return resource
                .put(url, {
                    query: query,
                    data: JSON.stringify(data) // data needs to be a string to bypass dojo's objectToQuery
                })
                .then(function success(res) {
                    return resource.isFederated ? res : res.data;
                }, function error(err) {
                    if (err) {
                        var data = err.response.data.Data || err.response.data;
                        if (data && data.status === 500 && data.errorNumber === "CWMFS4021E") {
                            resource.showError(bpmext.localization.formatMsg("Errors", "noFederatedSystem"), err);
                        } else {
                            resource.showError(data.errorMessage || data.message, err);
                        }
                    }
                    throw err;
                });
            } else {
                // non-federated params
                if (Array.isArray(options.statusFilter)) {
                    query.statusFilter = options.statusFilter.join();
                }
                if (Array.isArray(options.stageFilter)) {
                    query.stageStatusFilter = options.stageFilter.join();
                }
                if (Array.isArray(options.projectFilter)) {
                    query.projectFilter = options.projectFilter.join();
                }
                if (Array.isArray(options.starterId)) {
                    query.starterId = options.starterId.join();
                }
                if (options.projectFilterScope) {
                    query.projectFilterScope = options.projectFilterScope;
                }
                if (options.searchFilter) {
                    query.searchFilter = options.searchFilter;
                }
                if (Array.isArray(options.searchFilterScope)) {
                    query.searchFilterScope = options.searchFilterScope.join();
                }
                if (options.createdAfter) {
                    query.createdAfter = options.createdAfter;
                }
                if (options.createdBefore) {
                    query.createdBefore = options.createdBefore;
                }
                if (options.modifiedAfter) {
                    query.modifiedAfter = options.modifiedAfter;
                }
                if (options.modifiedBefore) {
                    query.modifiedBefore = options.modifiedBefore;
                }
                if (options.lastModifiedBy) {
                    query.caseLastModifier = options.lastModifiedBy;
                }
                query.includeNonAdmin = true;
                query.caseScope = null;
            }
            return resource
            .get(url, {
                query: query
            })
            .then(function success(res) {
                return resource.isFederated ? res : res.data;
            }, function error(err) {
                if (err) {
                    var data = err.response.data.Data || err.response.data;
                    resource.showError(data.errorMessage || data.message, err);
                }
                throw err;
            });
        }
    }

    return {
        get: get,
        TYPE:TYPE,
        INTERACTION: INTERACTION
    };
});
