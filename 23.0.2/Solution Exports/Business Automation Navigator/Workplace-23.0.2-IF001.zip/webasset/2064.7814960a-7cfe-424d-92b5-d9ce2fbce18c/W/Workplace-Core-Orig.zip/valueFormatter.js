/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define([ "dojox/date/islamic", 
         "dojox/date/islamic/Date",
		"dojox/date/islamic/locale", 
		"dojox/date/hebrew",
		"dojox/date/hebrew/Date",
		"dojox/date/hebrew/locale",
		"dojox/date/umalqura", 
		"dojox/date/umalqura/Date",
		"dojox/date/umalqura/locale", 
		"./constants",
		"dojo/date/locale", 
		"dojo/number",
		"dojo/dom-class",
		"dojo/cookie",
		"com.ibm.bpm.workplace.resources"],
		function(islamic, 
				islamicDate, 
				islamicLocale, 
				hebrew, 
				hebrewDate,
				hebrewLocale, 
				umalqura, 
				umalquraDate, 
				umalquraLocale,
				constants, 
				dojoLocale, 
				number,
				domClass,
				dojoCookie,
				wpResources) {
			"use strict";
			
			var locale = dojo.locale; // Default to dojo's locale
			var numberBundle = dojo.i18n.getLocalization("dojo.cldr", "number", locale);
			var calendarBundle = dojo.i18n.getLocalization("dojo.cldr", "gregorian", locale);
			var calendarType = '';

			var setCalendarType = function(userCalendarType) {
				if (userCalendarType) {
					calendarType = userCalendarType;
				}
			};

			var getCalendarType = function() {
				return calendarType;
			};
			
			var setLocale = function(newLocale) {
				if (newLocale) {
					locale = newLocale;
					numberBundle = dojo.i18n.getLocalization("dojo.cldr",
							"number", locale);
					calendarBundle = dojo.i18n.getLocalization("dojo.cldr",
							"gregorian", locale);
				}
			};

			var getLocale = function() {
				return locale;
			};
			
			var getBrowserLocale = function() {
				return navigator.language || navigator.userLanguage;
			};

			var isInNavigator = function() {
				var isNavigator = wpResources.isAppEngine;
			
				return isNavigator; 
	        };
	        
	        var getFromCookie = function(key) {
	    		return dojoCookie(key);
	    	};
	    	
	        var getFromLocalStorage = function(key) {
	    		return window.localStorage.getItem(key);
	    	};
	    	
	        var getNavigatorLocaleFormat  = function() {
	    		return getFromLocalStorage(constants.NAVIGATOR.localeFormat);
	    	};
	    	
			var getNavigatorLocale  = function() {
					return getFromCookie(constants.NAVIGATOR.locale);
			};
			
	    	var getNavigatorCalendarType  = function() {
	    		return getFromCookie(constants.NAVIGATOR.calendarType);
	    	};
	    	
	    	var updateLocale = function(locale, localeFormat){
	    		if (!locale && !localeFormat) {
					// if no userPreferences locale && no userPreferences language, then no need to call setLocale.  ValueFormatter will use the dojo gregorian and number.
				} else if (locale && localeFormat && locale == localeFormat) {
					// if userPreferences for locale == userPreferences for language, then no need to call setLocale.  ValueFormatter will use the dojo gregorian and number. 
				} else if (!localeFormat) {
					// if localeformat not set , then no need to call setLocale.  ValueFormatter will use the dojo gregorian and number.
				} else {
					//setLocale(localeFormat);
				}
	    	};
	    	
	    	var setLocaleFormat = function() {
				// If Navigator
				var isNavigator = isInNavigator();
				
				if(isNavigator){
					console.log("ValueFormater Navigator.userPreferences ENTER >>");
					// Locale language & Calendar settings from cookie
					var localeFormat = getNavigatorLocaleFormat();
					var locale = getNavigatorLocale(); 
					var calendarType = getNavigatorCalendarType();
					if(calendarType && constants.CALENDAR_TYPES[calendarType] ){
						setCalendarType(constants.CALENDAR_TYPES[calendarType.toLowerCase()]);
					}
					//updateLocale(locale, localeFormat);
					
					console.log("ValueFormater Navigator.userPreferences EXIT >>");
				} else {
					// User preference start
	            	wpResources.user.get().then(function (user) {
	                     if (user.userPreferences) {
							console.log("ValueFormater user.userPreferences ENTER >>", user.userPreferences);
							
							// Locale language & Calendar settings
							var localeFormat = user.userPreferences[wpResources.user.PREFERENCE.localeFormat];
							var locale = user.userPreferences[wpResources.user.PREFERENCE.locale]; 
							var calendarType = user.userPreferences[wpResources.user.PREFERENCE.calendarType];
							
							setCalendarType(calendarType);
							//updateLocale(locale, localeFormat);
							
							console.log("ValueFormater user.userPreferences EXIT >>", user.userPreferences);
	                     }
	            	 });
				}
			};
			
			var formatDate = function(date, includeTime) {
				if (typeof date === "string") {
					date = new Date(date);
				}
				var options = {
					dateStyle : "medium",
					selector : "date",
					formatLength : "medium"
				};
				if (includeTime) {
					options.timeStyle = "short";
					options.selector = "date and time";
				}
				options.locale = getLocale();
				var calendarType = getCalendarType();
				var formattedValue = ''
				if (calendarType == constants.CALENDAR_TYPES.islamic) { 
					// calendar type chosen islamic
					var dateIslamic = new dojox.date.islamic.Date();
					var islamicDate = dateIslamic.fromGregorian(date);
					formattedValue = dojox.date.islamic.locale.format(
							islamicDate, {
								islamicLocale : options.locale,
								selector : options.selector,
								formatLength : options.formatLength,
								fullYear : true
							});
				} else if (calendarType == constants.CALENDAR_TYPES.hebrew) {
					// calendar type chosen hebrew
					var dateHebrew = new dojox.date.hebrew.Date();
					var hebrewDate = dateHebrew.fromGregorian(date);
					formattedValue = dojox.date.hebrew.locale.format(
							hebrewDate, {
								hebrewLocale : options.locale,
								selector : options.selector,
								formatLength : options.formatLength,
								fullYear : true
							});
				} else { // calendar type chosen Gregorian / default as Gregorian
					formattedValue = dojoLocale.format(date, {
						locale : options.locale,
						selector : options.selector,
						formatLength : options.formatLength,
						fullYear : true
					});
				}
				return formattedValue;
			};
			/**
			 * Returns the decimal point used when displaying double or decimal
			 * values.
			 */
			var getDecimalPoint = function() {
				return numberBundle["decimal"] || ".";
			};

			var formatNumber = function(value) {
				var formattedValue = "";
				var locale = getLocale();
				console.log(locale,"locale")
				// Format the number using the given pattern or the locale
				// specific pattern
				// Note: numbers with exponents can't be formatted so we just
				// replace the decimal point
				var decimalPlaces = -1;
				// if ((type == "xs:double" || type == "xs:score") && !(value +
				// "").match(/E/i)) {
				// Preserve precision during formatting
				var index = (value + "").indexOf(".");
				decimalPlaces = index > 0 ? ((value + "").length - index - 1)
						: 0;
				// }
				if (decimalPlaces > -1) {
					// Format the number
					formattedValue = number.format(value, {
						locale : locale,
						places : decimalPlaces
					});
				} else {
					// Replace the decimal point (if any) with the locale
					// specific separator
					var decimalPoint = getDecimalPoint();
					if (decimalPoint != ".") {
						formattedValue = ("" + value)
								.replace(".", decimalPoint);
					} else {
						formattedValue = "" + value;
					}
				}
				return formattedValue;
			};



			return {
				formatNumber : formatNumber,
				formatDate : formatDate,
				getDecimalPoint : getDecimalPoint,
				getLocale : getLocale,
				setLocale : setLocale,
				setCalendarType : setCalendarType,
				getCalendarType : getCalendarType,
				setLocaleFormat : setLocaleFormat
			};
		});