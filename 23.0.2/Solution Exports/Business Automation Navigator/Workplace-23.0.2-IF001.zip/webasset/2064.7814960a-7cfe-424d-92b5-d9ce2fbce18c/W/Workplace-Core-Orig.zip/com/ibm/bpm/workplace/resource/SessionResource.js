/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define("com.ibm.bpm.workplace.resources/SessionResource", ["./resourceBase"], function (resource) {
    "use strict";
    var ROUTE = resource._buildUrl("${urlPrefix}/v1/system/session", {
            urlPrefix: resource.contextRoot.rest
        }),
        cachedPromise = undefined;

    /**
     * Gets the current session token information.
     * @returns {Promise} that resolves to the session information
     */
    function getToken() {
        if (!cachedPromise) {
            var url = ROUTE + "/token";

            cachedPromise = resource.post(url, { skipInterceptor: true }).then(function success(res) {
                var data = res && res.data,
                    token = data && data["access_token"];
                if (token) {
                    data.headerName = "Authorization";
                    data.headerValue = "Bearer " + token;
                }
                return data;
            });
        }
        return cachedPromise;
    }

    // module.exports
    return {
        getToken: getToken
    };
});
