/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define("com.ibm.bpm.workplace.resources/REPResource", [
    "dojo/Deferred",
    "dojo/_base/lang",
    "./resourceBase",
    "com.ibm.bpm.coach/bpmEventHelper"
], function (Deferred, lang, resource, bpmext) {
    "use strict";
    var ROUTE = resource._buildUrl("${urlPrefix}/v1/system/rep/${provider}", {
            urlPrefix: resource.contextRoot.rest,
            provider: "Mashups_ConfigService"
        }),
        cachedPromise = undefined,
        mashupsConfigProps = [
            "available.locales",
            "com.ibm.bpm.isLiberty",
            "com.ibm.bpm.oauth.reauth.allowed",
            "com.ibm.bpm.oauth.reauth.logoutTimeoutInSeconds",
            "com.ibm.bpm.oauth.reauth.logoutTimeoutInSecondsWhileReauth",
            "com.ibm.bpm.oauth.reauth.url",
            "com.ibm.bpm.portal.autoRefreshDelay",
            "com.ibm.bpm.portal.customLogout",
            "com.ibm.bpm.portal.defaultDashboardDisplayOrder",
            "com.ibm.bpm.portal.defaultNextTaskSavedSearch",
            "com.ibm.bpm.portal.defaultStartPage",
            "com.ibm.bpm.portal.defaultTaskListView",
            "com.ibm.bpm.portal.disableCFJSAPIInvocation",
            "com.ibm.bpm.portal.disableCometD",
            "com.ibm.bpm.portal.disableOpenInNewWindow",
            "com.ibm.bpm.portal.disableSocial",
            "com.ibm.bpm.portal.disableTaskAutoRefresh",
            "com.ibm.bpm.portal.displayTimeTracking",
            "com.ibm.bpm.portal.doNotClaimExternalUI",
            "com.ibm.bpm.portal.enableSystemTaskLaunchByPortal",
            "com.ibm.bpm.portal.excludeMembershipInfoFromUserInfoRestApis",
            "com.ibm.bpm.portal.excludeReferencedFromToolkit",
            "com.ibm.bpm.portal.federatedRefreshInterval",
            "com.ibm.bpm.portal.hideWorkDashboard",
            "com.ibm.bpm.portal.inactivity.monitor",
            "com.ibm.bpm.portal.inactivity.stopMonitorWhenOpenInNewWindow",
            "com.ibm.bpm.portal.inactivity.thresholdInSeconds",
            "com.ibm.bpm.portal.launchList.showMore.count",
            "com.ibm.bpm.portal.launchList.showMore.strategy",
            "com.ibm.bpm.portal.openTaskInNewWindow",
            "com.ibm.bpm.portal.restrictModifyTask.due",
            "com.ibm.bpm.portal.restrictModifyTask.priority",
            "com.ibm.bpm.portal.restrictModifyTask.reassign",
            "com.ibm.bpm.portal.restrictModifyTask",
            "com.ibm.bpm.portal.returnTaskToTeamOnLogout",
            "com.ibm.bpm.portal.autoClaimNextTask",
            "com.ibm.bpm.portal.showNextTaskDashboard",
            "com.ibm.bpm.portal.stream.attachments.extensions.blacklist",
            "com.ibm.bpm.portal.stream.attachments.extensions.whitelist",
            "com.ibm.bpm.portal.task.filter.service.alwaysRun",
            "com.ibm.bpm.portal.task.filter.service.name",
            "com.ibm.bpm.portal.task.filter.service.showToggle",
            "com.ibm.bpm.portal.walkme.enable",
            "com.ibm.bpm.portal.walkme.url",
            "com.ibm.bpm.social.enableRunInFrame",
            "com.ibm.bpm.social.restRequestTimeoutSeconds",
            "com.ibm.bpm.social.zResumable",
            "com.ibm.mashups.productname",
            "com.ibm.mashups.proxy.url"
        ];

    /**
     *  Parse the response body into a configuration object
     *
     * @param {Object} data - Response Object returned by the XHR call
     * @returns {Object} portal config
     */
    function configResponseHandler(data) {
        var props = data.propertyList,
            defaultObject = {
                walkme: {
                    enable: undefined,
                    url: undefined
                },
                taskFilterService: {
                    showToggle: undefined,
                    alwaysRun: undefined
                }
            };
        props = lang.mixin(defaultObject, props);
        return {
            availableLocales: _parseList(props["available.locales"]),
            zResumable: _parseList(props["com.ibm.bpm.social.zResumable"]),
            enableRunInFrame: _parseBoolean(props["com.ibm.bpm.social.enableRunInFrame"]),
            openTaskInNewWindow: _parseBoolean(props["com.ibm.bpm.portal.openTaskInNewWindow"]),
            excludeReferencedFromToolkit: _parseList(props["com.ibm.bpm.portal.excludeReferencedFromToolkit"]),
            defaultStartPage: props["com.ibm.bpm.portal.defaultStartPage"],
            disableCometD: _parseBoolean(props["com.ibm.bpm.portal.disableCometD"]),
            doNotClaimExternalUI: _parseBoolean(props["com.ibm.bpm.portal.doNotClaimExternalUI"]),
            disableCFJSAPIInvocation: _parseBoolean(props["com.ibm.bpm.portal.disableCFJSAPIInvocation"]),
            defaultDashboardDisplayOrder: props["com.ibm.bpm.portal.defaultDashboardDisplayOrder"],
            disableTaskAutoRefresh: _parseBoolean(props["com.ibm.bpm.portal.disableTaskAutoRefresh"]),
            disableSocial: _parseList(props["com.ibm.bpm.portal.disableSocial"]) || "all",
            restrictModifyTask: {
                all: _parseList(props["com.ibm.bpm.portal.restrictModifyTask"]),
                reassign: _parseList(props["com.ibm.bpm.portal.restrictModifyTask.reassign"]),
                due: _parseList(props["com.ibm.bpm.portal.restrictModifyTask.due"]),
                priority: _parseList(props["com.ibm.bpm.portal.restrictModifyTask.priority"])
            },
            federatedRefreshInterval: _parseNumber(props["com.ibm.bpm.portal.federatedRefreshInterval"], 60),
            streamAttachmentsBlacklist: _parseList(props["com.ibm.bpm.portal.stream.attachments.extensions.blacklist"]),
            streamAttachmentsWhitelist: _parseList(props["com.ibm.bpm.portal.stream.attachments.extensions.whitelist"]),
            defaultTaskListView: props["com.ibm.bpm.portal.defaultTaskListView"],
            displayTimeTracking: _parseBoolean(props["com.ibm.bpm.portal.displayTimeTracking"]),
            hideWorkDashboard: _parseList(props["com.ibm.bpm.portal.hideWorkDashboard"]),
            proxyUrl: props["com.ibm.mashups.proxy.url"],
            customLogout: props["com.ibm.bpm.portal.customLogout"],
            restRequestTimeoutSeconds: _parseNumber(props["com.ibm.bpm.social.restRequestTimeoutSeconds"]),
            excludeMembershipInfoFromUserInfoRestApis: _parseBoolean(
                props["com.ibm.bpm.portal.excludeMembershipInfoFromUserInfoRestApis"]
            ),
            launchListShowMoreStrategy: props["com.ibm.bpm.portal.launchList.showMore.strategy"],
            launchListShowMoreCount: _parseNumber(props["com.ibm.bpm.portal.launchList.showMore.count"]),
            showNextTaskDashboard: _parseList(props["com.ibm.bpm.portal.showNextTaskDashboard"]),
            defaultNextTaskSavedSearch: props["com.ibm.bpm.portal.defaultNextTaskSavedSearch"] || null,
            returnTaskToTeamOnLogout: _parseList(props["com.ibm.bpm.portal.returnTaskToTeamOnLogout"]),
            autoClaimNextTask: _parseList(props["com.ibm.bpm.portal.autoClaimNextTask"]),
            isLiberty: _parseBoolean(props["com.ibm.bpm.isLiberty"]),
            enableSystemTaskLaunchByPortal: _parseBoolean(props["com.ibm.bpm.portal.enableSystemTaskLaunchByPortal"]),
            autoRefreshDelay: _parseNumber(props["com.ibm.bpm.portal.autoRefreshDelay"], 500),
            oauth: {
                reauth: {
                    url: props["com.ibm.bpm.oauth.reauth.url"],
                    allowed: _parseBoolean(props["com.ibm.bpm.oauth.reauth.allowed"]),
                    logoutTimeout: _parseNumber(props["com.ibm.bpm.oauth.reauth.logoutTimeoutInSeconds"], 60),
                    logoutTimeoutWhileReauth: _parseNumber(
                        props["com.ibm.bpm.oauth.reauth.logoutTimeoutInSecondsWhileReauth"],
                        120
                    )
                }
            },
            productname: props["com.ibm.mashups.productname"],
            inactivity: {
                monitor: _parseBoolean(props["com.ibm.bpm.portal.inactivity.monitor"]),
                thresholdInSeconds: _parseNumber(props["com.ibm.bpm.portal.inactivity.thresholdInSeconds"]),
                stopMonitorWhenOpenInNewWindow: _parseBoolean(
                    props["com.ibm.bpm.portal.inactivity.stopMonitorWhenOpenInNewWindow"]
                )
            },
            walkme: {
                enable: _parseBoolean(props.walkme.enable) || _parseBoolean(props["com.ibm.bpm.portal.walkme.enable"]),
                url: props.walkme.url || props["com.ibm.bpm.portal.walkme.url"]
            },
            taskFilterService: {
                name: props["com.ibm.bpm.portal.task.filter.service.name"],
                alwaysRun: _parseBoolean(props.taskFilterService.alwaysRun) || _parseBoolean(props["com.ibm.bpm.portal.task.filter.service.alwaysRun"]),
                showToggle: _parseBoolean(props.taskFilterService.showToggle) || _parseBoolean(props["com.ibm.bpm.portal.task.filter.service.showToggle"])
            }
        };
    }

    /**
     *  Convert string to boolean value
     *
     * @param {String} str - String to parse its boolean value
     * @returns {Boolean} true if the string evaluated to true, false otherwise
     */
    function _parseBoolean(str) {
        return (str && ("" + str).toLowerCase() === "true") || false;
    }

    /**
     *  Convert a string to a list
     *
     * @param {String} str - string to convert to a list, uses "," (comma) as a separator
     * @returns {String[]} list of strings or undefined if the str is empty
     */
    function _parseList(str) {
        return (
            (str &&
                ("" + str)
                    .trim()
                    .toLowerCase()
                    .split(/\s*,\s*/)) ||
            undefined
        );
    }

    /**
     *  Parse Number from string
     *
     * @param {String} str - String to parse integer value of
     * @param {Number} defaultValue - default value to return if string is empty or invalid
     *
     * @returns {Number} - number that parsed from the string or default value
     */
    function _parseNumber(str, defaultValue) {
        return (str && parseInt("" + str, 10)) || defaultValue;
    }

    /**
     * Finds the WorkplaceConfig Data view and returns its binding value
     *
     * @returns {Object} -
     */
    function _getConfigViewValue() {
        var element = document.querySelector("[data-viewid='WorkplaceConfig']"),
            configDataView = element && bpmext.ui.getView(element.getAttribute("control-name") || ""),
            binding = configDataView && configDataView.context.binding,
            bindingValue = binding && binding.get("value"),
            props = bindingValue && bindingValue.toJSObject();
        return lang.mixin({}, props);
    }

    /**
     * Get the current Portal Config, the result of this is call is cached in memory
     * @param {Boolean} [refresh] - true to bust the cached result and retrieve from server
     * @returns {Promise} Promise that will evaluate to the Portal configuration object
     */
    function get(refresh) {
        if (!cachedPromise || refresh) {
            if (resource.isAppEngine) {
                var deferred = new Deferred(),
                    dataConfig = _getConfigViewValue();

                deferred.resolve(configResponseHandler({ propertyList: dataConfig }));
                cachedPromise = deferred.promise;
            } else {
                cachedPromise = resource
                    .get(ROUTE, {
                        query: {
                            properties: encodeURIComponent("[" + mashupsConfigProps.join() + "]"),
                            encodedParams: "properties"
                        }
                    })
                    .then(configResponseHandler);
            }
        }
        return cachedPromise;
    }

    return {
        get: get
    };
});
