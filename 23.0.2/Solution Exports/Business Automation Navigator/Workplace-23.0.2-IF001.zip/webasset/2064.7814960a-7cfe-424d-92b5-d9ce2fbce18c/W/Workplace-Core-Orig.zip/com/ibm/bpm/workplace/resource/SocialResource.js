/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define("com.ibm.bpm.workplace.resources/SocialResource", ["./resourceBase"], function(resource) {
    "use strict";
    var ROUTE = "${urlPrefix}/v1/social",
        SORT = {
            ASC: "asc",
            DESC: "desc"
        };

    /**
     * Get a list of followed instances
     *
     * @returns {Promise} a promise that resolves to the list of followed instances
     */
    function getFollowing() {
        var url = resource._buildUrl(ROUTE + "/instances/following", { urlPrefix: resource.contextRoot.rest });
        return resource.get(url).then(function success(res) {
            return res.data;
        });
    }

    /**
     * Get a list of mentions in instances
     * @param {Object} [options] - optional params to pass to the underlying API
     * @param {Number} [options.page] - The page of items to return. The default is no paging. Pages start at 1. Using 0 disables paging.
     * @param {Number} [options.pagesize] - The number of items to return on a page. The default is 10.
     * @param {Date} [options.since] - A filter for returning items only available since this date/time.
     * @param {String} [options.sort] - The sort order, either "asc" for ascending, or "desc" for descending. Default is "desc"
     * @returns {Promise} a promise that resolves to the list of mentions
     */
    function getMentions(options) {
        var url = resource._buildUrl(ROUTE + "/instances/mentions", { urlPrefix: resource.contextRoot.rest }),
            query = {};

        // build optional params
        if (options) {
            query.page = options.page;
            query.pagesize = options.pagesize;
            if (options.since instanceof Date) {
                query.since = options.since.toISOString();
            }
            if (options.sort === SORT.ASC || options.sort === SORT.DESC) {
                query.sort = options.sort;
            }
        }

        return resource.get(url, {
            query: query
        });
    }

    /**
     * Get a the stream activities of an instance
     *
     * @param {Object} options - params to pass to the underlying API
     * @param {Number} options.piid - Process instance Id
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     * @param {Number} [options.page] - The page of items to return. The default is no paging. Pages start at 1. Using 0 disables paging.
     * @param {Number} [options.pagesize] - The number of items to return on a page. The default is 10.
     * @param {Date} [options.since] - A filter for returning items only available since this date/time.
     * @param {String} [options.sort] - The sort order, either "asc" for ascending, or "desc" for descending. Default is "desc"
     * @returns {Promise} a promise that resolves to the list of stream activities
     */
    function getStreamForInstance(options) {
        if (options && options.piid) {
            var url = resource._buildUrl(ROUTE + "/instance/${piid}/stream", {
                    urlPrefix: resource.contextRoot.rest,
                    piid: options.piid
                }),
                query = {};

            // build optional params
            if (options) {
                query.page = options.page;
                query.pagesize = options.pagesize;
                if (options.since instanceof Date) {
                    query.since = options.since.toISOString();
                }
                if (options.sort === SORT.ASC || options.sort === SORT.DESC) {
                    query.sort = options.sort;
                }
            }

            return resource.get(url, {
                query: query,
                systemID: options.systemID
            }, function error(err) {
                if (err && err.response && err.response.status === 404) {
                    resource.showError(bpmext.localization.formatMsg("Errors", "processInstanceNotAvailable"), err);
                }
                throw err;
            });
        }
    }

    /**
     * Whether is following a process instance
     *
     * @param {Object} options - params to pass to the underlying API
     * @param {Number} options.piid - Process instance Id
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     * @returns {Promise} a promise that resolves to the "follow" action confirmation
     */
    function isFollowingInstance(options) {
        if (options && options.piid) {
            var url = resource._buildUrl(ROUTE + "/instance/${piid}/following", {
                urlPrefix: resource.contextRoot.rest,
                piid: options.piid
            });
            return resource.get(url, {
                systemID: options.systemID
            });
        }
    }

    /**
     * Follow a process instance
     *
     * @param {Object} options - params to pass to the underlying API
     * @param {Number} options.piid - Process instance Id
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     * @returns {Promise} a promise that resolves to the "follow" action confirmation
     */
    function followInstance(options) {
        if (options && options.piid) {
            var url = resource._buildUrl(ROUTE + "/instance/${piid}/following", {
                urlPrefix: resource.contextRoot.rest,
                piid: options.piid
            });
            return resource.post(url, {
                systemID: options.systemID
            });
        }
    }

    /**
     * Unfollow a process instance
     *
     * @param {Object} options - params to pass to the underlying API
     * @param {Number} options.piid - Process instance Id
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     * @returns {Promise} a promise that resolves to the "unfollow" action confirmation
     */
    function unfollowInstance(options) {
        if (options && options.piid) {
            var url = resource._buildUrl(ROUTE + "/instance/${piid}/following", {
                urlPrefix: resource.contextRoot.rest,
                piid: options.piid
            });
            return resource.del(url, {
                systemID: options.systemID
            });
        }
    }

    /**
     * Delete a single mention or all mentions if no id is specified
     *
     * @param {Object} [options] - optional params to pass to the underlying API
     * @param {String} [options.id] - id of the mention to delete
     * @returns {Promise} a promise that resolves to nothing when deletion is successful
     */
    function deleteMention(options) {
        var url;
        if (options && options.id) {
            url = resource._buildUrl(ROUTE + "/task/${id}/mentions", {
                urlPrefix: resource.contextRoot.rest,
                id: options.id
            });
        } else {
            url = resource._buildUrl(ROUTE + "/task/mentions/all", { urlPrefix: resource.contextRoot.rest });
        }

        return resource.del(url);
    }

    /**
     * Get a list of experts for a specific task
     *
     * @param {Object} options - param to pass to the underlying API
     * @param {Number} options.tkiid - task instance Id to get experts for
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     * @returns {Promise} a promise that resolves to a list of experts
     */
    function getExperts(options) {
        if (options && options.tkiid) {
            var url = resource._buildUrl(ROUTE + "/task/${tkiid}/experts", {
                urlPrefix: resource.contextRoot.rest,
                tkiid: options.tkiid
            });
            return resource.get(url, { systemID: options.systemID }).then(
                function success(res) {
                    return res.data;
                }, function error(err) {
                    if (err && err.response && err.response.status === 404) {
                        resource.showError(bpmext.localization.formatMsg("Errors", "processInstanceNotAvailable"), err);
                    }
                    throw err;
                }
            );
        }
    }

    // module.exports
    return {
        getFollowing: getFollowing,
        getMentions: getMentions,
        getStreamForInstance: getStreamForInstance,
        isFollowingInstance: isFollowingInstance,
        followInstance: followInstance,
        unfollowInstance: unfollowInstance,
        deleteMention: deleteMention,
        getExperts: getExperts
    };
});
