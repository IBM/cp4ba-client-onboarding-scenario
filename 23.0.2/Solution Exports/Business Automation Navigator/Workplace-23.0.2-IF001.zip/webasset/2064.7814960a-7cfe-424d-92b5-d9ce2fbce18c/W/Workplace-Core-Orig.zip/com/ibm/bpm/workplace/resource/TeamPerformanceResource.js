/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define("com.ibm.bpm.workplace.resources/TeamPerformanceResource", [
    "./resourceBase",
    "dojo/_base/Deferred"
], function(resource, Deferred) {
    "use strict";
    var ROUTE_BASE = "${urlPrefix}/v2/dashboards";
    var NOT_FED_ENV = "Not federated environment";
    var ORGANIZATION = {
        BY_TASK: "byTask",
        BY_INSTANCE: "byInstance"
    };
    var INTERACTION = {
        ALL: "all",
        CLAIMED: "claimed",
        AVAILABLE: "available",
        COMPLETED: "completed",
        CLAIMED_AND_AVAILABLE: "claimed_and_available"
    };

    function notFederatedEnv() {
        var deferred =  new Deferred();
        deferred.reject({
            errorMessage: NOT_FED_ENV
        });
        return deferred.promise;
    }

    /**
     * Retrieve summary information about the tasks of each team managed by the calling user.
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {String[]} options.filter -  Comma-separated list of filter strings
     *
     * @returns {Promise} promise that resolved to the response object
     */
    function getTeamSummaries(options) {
        if (!resource.contextRoot.federatedURL) {
            return notFederatedEnv();
        }

        var query = {};
        var url = resource._buildUrl(ROUTE_BASE + "/teamsummary", {
            urlPrefix: resource.contextRoot.federatedURL
        });

        // build query params
        if (options) {
            if (Array.isArray(options.filter)) {
                query.statusFilter = options.filter.join();
            }
        }

        return resource.get(url, {query: query});
    }

    /**
     * Retrieve summary information about the tasks of a team managed by the user
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {String} teamId - required - selected team ID
     *
     * @returns {Promise} promise that resolved to the response object
     */
    function getTeamSummaryByID(options) {
        if (!resource.contextRoot.federatedURL) {
            return notFederatedEnv();
        }

        if (options.teamId) {
            var url = resource._buildUrl(ROUTE_BASE + "/teamsummary/${teamId}", {
                urlPrefix: resource.contextRoot.federatedURL,
                teamId: options.teamId
            });

            return resource.get(url);
        }
    }

    /**
     * Retrieve a list of all tasks for a team managed by the user
     *
     * @param {Object} options - params to pass to the underlying API
     * @param {String} options.teamId - required - selected team ID
     * @param {Number} options.size - size of the maximum returning tasks, default 25
     * @param {Number} options.offset - number of skipping tasks
     * @param {Boolean} options.alphabeticalSort - wether sort the returning tasks alphabetically
     * @param {Object} options.data - saved search definition
     *
     * @returns {Promise} promise that resolved to the response object
     */
    function getTeamTasksByID(options) {
        var query = {usersFullName: true}, data = {};

        if (!resource.contextRoot.federatedURL) {
            return notFederatedEnv();
        }

        if (options.teamId) {
            var url = resource._buildUrl(ROUTE_BASE + "/teamtasks/${teamId}", {
                urlPrefix: resource.contextRoot.federatedURL,
                teamId: options.teamId
            });

            // build query params
            if (options) {
                if (!isNaN(options.size)) {
                    query.size = parseInt(options.size);
                }

                if (!isNaN(options.offset)) {
                    query.offset = parseInt(options.offset);
                }

                if (options.alphabeticalSort) {
                    query.alphabeticalSort = options.alphabeticalSort;
                }
            }

            data = {
                size: query.size,
                id: (options && options.id) || 0,
                name: (options && options.name) || "",
                fields: (options && options.fields) || [],
                organization: (options && options.organization) || ORGANIZATION.BY_TASK,
                shared: options && options.shared === true,
                teams: (options && options.teams) || [],
                interaction: (options && options.interaction) || INTERACTION.CLAIMED_AND_AVAILABLE,
                conditions: (options && options.conditions) || [],
                sort: (options && options.sort) || [],
                aliases: (options && options.aliases) || []
            };

            return resource
                .put(url, {
                    query: query,
                    data: JSON.stringify(data) // data needs to be a string to bypass dojo's objectToQuery
                });
        }
    }

    /**
     * Retrieve daily or hourly task trend for a team managed by the user
     *
     * @param {Object} options - params to pass to the underlying API
     * @param {String} options.teamId - required - selected team ID
     * @param {String} options.units - options of "", "HOUR" and "DAY", default "HOUR"
     * @param {Number} options.numPeriods - number of retrieving hourly/daily periods (range between 1 - 365)
     * @param {String} options.endPeriods - timestamp of the the end period, default current hour/day
     *
     * @returns {Promise} promise that resolved to the response object
     */
    function getTeamTrendByID(options) {
        var query = {};

        if (!resource.contextRoot.federatedURL) {
            return notFederatedEnv();
        }

        if (options.teamId) {
            var url = resource._buildUrl(ROUTE_BASE + "/teamtasktrend/${teamId}", {
                urlPrefix: resource.contextRoot.federatedURL,
                teamId: options.teamId
            });

            // build query params
            if (options) {
                if (!!options.units) {
                    var units = (options.units || "").toLocaleUpperCase();
                    query.units = units === "DAY" ? units : "HOUR";
                }

                if (options.endPeriods) {
                    query.endPeriods = options.endPeriods;
                }

                query.numPeriods = !isNaN(options.numPeriods) ? parseInt(options.numPeriods) : 1;
            }

            return resource.get(url, {query: query});
        }

    }

    /**
     * Retrieve a list of all members of a team managed by the user, with information about completed today and open tasks for each
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {String} teamId - required - selected team ID
     *
     * @returns {Promise} promise that resolved to the response object
     */
    function getTeamMembersByID(options) {
        if (!resource.contextRoot.federatedURL) {
            return notFederatedEnv();
        }

        if (options.teamId) {
            var url = resource._buildUrl(ROUTE_BASE + "/teammember/${teamId}", {
                urlPrefix: resource.contextRoot.federatedURL,
                teamId: options.teamId
            });

            return resource.get(url);
        }
    }

    /**
     * Retrieve summary information about the tasks of a team member managed by the calling user.
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {String} teamId - required - selected team ID
     * @param {String} username - required - user name
     *
     * @returns {Promise} promise that resolved to the response object
     */
    function getTeamMemberDetailByID(options) {
        if (!resource.contextRoot.federatedURL) {
            return notFederatedEnv();
        }

        if (options.teamId) {
            var url = resource._buildUrl(ROUTE_BASE + "/teammember/${teamId}/${username}", {
                urlPrefix: resource.contextRoot.federatedURL,
                teamId: options.teamId,
                username: options.username
            });

            return resource.get(url);
        }
    }

    return {
        getTeamSummaries: getTeamSummaries,
        getTeamSummaryByID: getTeamSummaryByID,
        getTeamTasksByID: getTeamTasksByID,
        getTeamTrendByID: getTeamTrendByID,
        getTeamMembersByID: getTeamMembersByID,
        getTeamMemberDetailByID: getTeamMemberDetailByID
    };
});
