/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define(["com.ibm.bpm.workplace.core/valueFormatter"],function(f){var m="ar bg cs da de el es es_MX fi fr he hu it iw ja ko nb nl no pl pt pt_BR ro ru sk sv tr zh zh_TW".split(" "),k=function(a,b){return a.replace(/{(\d+)}/g,function(a,e){return(b[e]||a)+""})},l=function(a,b,c,e){a.localization?(Object.keys(b).forEach(function(g){a.localization.messages[g]=b[g]}),Object.keys(c).forEach(function(g){a.localization.defaultMessages[g]=c[g]}),a.localization.workplaceFormatDate=f.formatDate,a.localization.workplaceFormatNumber=
f.formatNumber):a.localization={messages:b,defaultMessages:c,formatString:function(a){return k(a,Array.prototype.slice.call(arguments,1))},formatMsg:function(a,d){var h;b[a]&&b[a][d]?h=b[a][d]:c[a]&&c[a][d]&&(h=c[a][d]);return null!=h?k(h,Array.prototype.slice.call(arguments,2)):"MESSAGE["+e+"-\x3e"+d+"]"},workplaceFormatDate:f.formatDate,workplaceFormatNumber:f.formatNumber}};return{initMessages:function(a,b,c){f.setLocaleFormat();null===a&&(a=document.documentElement.lang.toLowerCase().replace(/[-_]/,
"-"),"pt-br"===a?a="pt_BR":"zh-tw"===a?a="zh_TW":"zh-cn"===a?a="zh":"ca"===a?a="es":"en-ca"===a||"en-gb"===a?a="":"fr-ca"===a?a="fr":"es-mx"===a&&(a="es_MX"));var e="com.ibm.bpm.workplace.localization/messages"+(-1!==m.indexOf(a)?"_"+a:"");b?require([e,"com.ibm.bpm.workplace.localization/messages"],function(b,d){l(bpmext,b,d,a);c()}):require(["com.ibm.bpm.coach/bpmEventHelper",e,"com.ibm.bpm.workplace.localization/messages"],function(b,d,c){l(b,d,c,a)})}}});