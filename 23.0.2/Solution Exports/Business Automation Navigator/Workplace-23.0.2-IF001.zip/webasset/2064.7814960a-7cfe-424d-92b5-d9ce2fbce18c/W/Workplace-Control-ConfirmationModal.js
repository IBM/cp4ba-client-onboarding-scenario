/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof ConfirmationModal
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof ConfirmationModal
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof ConfirmationModal
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof ConfirmationModal
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof ConfirmationModal
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof ConfirmationModal
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof ConfirmationModal
 * @method triggerFormulaUpdates
 */


/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 * </table>
 */
workplace_control_InitConfirmationModal = function (utilities, taskUtils, domAttr)
{
    "use strict";
    this._instance =
    {
        CONFIRM_ACTIONS: {
            TERMINATE_INSTANCE_EVENT: {
                title: function title(title) {
                    return bpmext.localization.formatMsg("ConfirmationModal", "terminateTitle", title);
                },
                message: bpmext.localization.formatMsg("ConfirmationModal", "terminateMessage"),
                button: bpmext.localization.formatMsg("ConfirmationModal", "terminateButton")
            }
        }
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            _localization: function _localization (view) {
                view._instance.modalSection.setSecondaryButtonText(bpmext.localization.formatMsg("ConfirmationModal", "closeButton"));
            },

            _loadModalText: function _loadModalText(view, action) {
                var textSettings = view._instance.CONFIRM_ACTIONS[action.name];
                if (textSettings) {
                    var title = textSettings.title(view._instance.workstreamName);
                    var message = textSettings.message;
                    var button = textSettings.button;

                    view._instance.modalSection._instance.modalDialog.ariaLabel = textSettings.title(view._instance.workstreamName);
                    view._instance.confirmationPanel.setTitle(title);
                    view._instance.confirmationMessage.setData(message);
                    view._instance.modalSection.setPrimaryButtonText(button);
                }
            }
        };


        /*
        Public control methods *************************************************************
         */

        /**
		 * @instance
		 * @memberof ConfirmationModal
		 * @method closeModal
		 * @desc Closes the modal dialog
		 */
        this.constructor.prototype.closeModal = function() {
            bpmext.log.info("ConfirmationModal.closeModal ENTER >> ",this);
            if (this.isVisible()) {
                this._instance.modalSection.hide();
                this.hide();
            }
			bpmext.log.info("ConfirmationModal.closeModal EXIT << ");
        };

        /**
		 * @instance
		 * @memberof ConfirmationModal
         * @param {String} workstreamName Name of the target workstream
		 * @method showModal
		 * @desc Display the modal
		 */
        this.constructor.prototype.showModal = function() {
            bpmext.log.info("ConfirmationModal.showModal ENTER >> ", this);
            this._instance.modalSection.show();
            this.show();
            taskUtils.setTabCycle(this);
            bpmext.log.info("ConfirmationModal.showModal EXIT >> ", this);
        };

        /**
		 * @instance
		 * @memberof ConfirmationModal
		 * @method performAction
		 * @desc Perform the workstream Action
		 */
        this.constructor.prototype.performAction = function() {
            bpmext.log.info("ConfirmationModal.performAction ENTER >> ", this);
            this._instance.deferAction && this._instance.deferAction();
			bpmext.log.info("ConfirmationModal.performAction EXIT << ");
        };

        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function () {
            bpmext.log.info("ConfirmationModal.load ENTER >>", this);

            this._instance.modalSection = bpmext.ui.getContainer("ModalSection", this);
            this._instance.confirmationPanel = bpmext.ui.getContainer("ConfirmationPanel", this);

            // Confirm message
            this._instance.confirmationMessage = bpmext.ui.getView("ConfirmationMessage", this);

            // init
            this._instance.confirmationMessage.setLabelVisible(false);
            this._proto._localization(this);

            var confirmationPanelHeaderIcon = this._instance.confirmationPanel.context.element.querySelector("div.panel-heading-controls > div.panel-heading-icon > i");
            !!confirmationPanelHeaderIcon && domAttr.remove(confirmationPanelHeaderIcon, "tabindex");

            this.loadContainer(this);

             // Respond to actions changes
             taskUtils.EVENTS.PERFORM_WORKSTREAM_ACTION.subscribe(function (eventName, eventData) {
                var action = eventData && eventData.action;
                var deferAction = eventData && eventData.deferAction;

                if (action && deferAction) {
                    this._instance.deferAction = deferAction;
                    this._instance.workstreamName = eventData.workstreamName;

                    this._proto._loadModalText(this, action);
                    this.showModal();
                }
             }, this);

            taskUtils.EVENTS.ACTION_PERFORMED.subscribe(this.closeModal, this);

            bpmext.log.info("ConfirmationModal.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try {
                utilities.handleVisibility(this.context);
            }
            catch (e){
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e, this);
                if(e.stack) {
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack), this);
                }
            }
        };

        this.constructor.prototype.change = function (event){
            bpmext.log.info("ConfirmationModal.change ENTER >> (event): " + event, this);
            if (event.type === "config") {
                switch (event.property) {
                    case "_metadata.visibility": {
                        this.view();
                        break;
                    }
                }
            }
            bpmext.log.info("ConfirmationModal.change ENTER >>", this);
        };

        this.constructor.prototype.unload = function (){
            bpmext.log.info("ConfirmationModal.unload ENTER >> ", this);
            bpmext.ui.unloadContainer(this);
            bpmext.log.info("ConfirmationModal.unload ENTER >>", this);
        };
    }
};