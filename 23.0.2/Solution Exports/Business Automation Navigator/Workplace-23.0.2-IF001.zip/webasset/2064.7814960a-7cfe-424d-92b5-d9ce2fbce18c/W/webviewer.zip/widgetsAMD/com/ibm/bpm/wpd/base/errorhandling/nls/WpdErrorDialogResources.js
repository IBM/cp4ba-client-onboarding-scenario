define({ root:
//begin v1.x content
{
    errorDialogTitle: "IBM BPM Error",
    moreDetails: "More Details...",
    closeMessage: "Close All Error Messages",
    contentMessage: "An error occurred."
}
//end v1.x content
,
ar: true,
cs: true,
de: true,
el: true,
es: true,
fr: true,
he: true,
hu: true,
it: true,
iw: true,
ja: true,
ko: true,
pl: true,
pt: true,
'pt-br': true,
ro: true,
ru: true,
tr: true,
zh: true,
'zh-tw': true,
nb: true,
no: true,
sv: true,
fi: true,
da: true,
sk: true,
nl: true
});
