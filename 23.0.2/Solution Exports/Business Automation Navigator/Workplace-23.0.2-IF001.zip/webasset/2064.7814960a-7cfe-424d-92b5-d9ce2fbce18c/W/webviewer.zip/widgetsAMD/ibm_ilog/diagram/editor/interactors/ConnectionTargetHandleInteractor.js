/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"../../interactors/Interactor"
], function(
declare,
Interactor
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var ConnectionTargetHandleInteractor =
declare("ibm_ilog.diagram.editor.interactors.ConnectionTargetHandleInteractor", [Interactor], {

	_handle: null,
	_viewport: null,

	initialize: function ( /* ibm_ilog.diagram.editor.ConnectionHandle */ connectionHandle) {
		this._handle = connectionHandle;
		this._viewport = connectionHandle.getViewport();
		this._initialize();
		return this;
	},

	_declareStates: function () {
		this._declareState("idle", ["onMouseRealease"]);
	},

	getDefaultConnections: function () {
		//
		//	summary:
		//		returns the default event mapping
		//
		return {
			onMouseRealease: {
				src: this._getInitialEventSource(),
				srcEvt: "onmouseup",
				connectTo: "_setTarget",
				gfxConnect: true
			}
		};
	},
	
	_getInitialEventSource: function () {
		return this._handle;
	},

	_setTarget: function (ge, e) {
		this._handle.getConnectionInteractor().setPortPosition(this._handle.getPortPosition());
	}
});

return ConnectionTargetHandleInteractor;

});
