/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["../main", "dojo/_base/declare", "dojo/_base/lang", "dojo/_base/array",
"dojo/_base/connect", "dojo/_base/config", "dojo/_base/json",
"dojox/dtl/_base", "dojox/dtl/Context", "dojox/collections/Dictionary",
"../util/ErrorReporter","../data/StoreApi"
],
function(iid, declare, lang, array, connect, config, json, dd, Context, Dictionary, R, StoreApi){

	// Note: we use dojo/_base/json which accepts non-strict JSON (i.e. no quotes needed around property names)
	//		 it would be nice to use dojo/json but we would have to convert all our templates to strict JSON...
	
	// TODO: Change to this when AMD conversion is complete:
	// var idb = {...
	var idb = lang.setObject("ibm_ilog.diagram.data.dtlbinding", {
		//dtlExp: /[\s{,]([\w'"]*):["'\s]*{{(.+?)}}[\s'"]*|[\s{,][\w]*:\s*['"][^'"]*{{[^'"]*}}[^'"]*['"]|{%.+?%}/g,
		//dtlExp: /([\s*{,])([\w\s'"]*):([^\{\{,]*{{(([^'"|]*)[^'"]*)}}[A-Za-z\s'"]*)|{%.+?%}/g,
		dtlExp: /([{,])(\s*['"]?([\w]*)['"]?\s*:([^\{\{,]*{{([^|}]+)[^}}]*}}[^,}]*))/g,
		//arrays:                  ([{,])(\s*['"]?([\w]*)['"]?:([^\{\{]*{{([^|}]+)[^}}]*}}[^,}\]]*))
		itemPropExp: /{{([^\.]*)[\.]?([^|}]*)\|?[^}]*\}{2}/,
		replaceExp: "$1_binding_$3:{destPName:'$3',srcPName:'$5',value:$4},$2",
		_get: function(key) {
			if (this.length) {
				return (this[0] instanceof idb.DataContext) ? this[0].get(key) : this[0][key];
			}
		}
	});
	
	$bind = function(expr) {
		var f = function() {
			return expr;
		};
		f.__is_idb = true;
		return f;
	};
	
	var dumpTpl = function(obj) {
		var recurse = arguments.callee, objtype = typeof obj;
		if (objtype == "number" || objtype == "boolean") {
			return obj + "";
		}
		if (obj === null) {
			return "null";
		}
		if (objtype == "string") {
			return json._escapeString(obj);
		}
		if (objtype == "function") {
			return obj.__is_idb ? obj.call() : null;
		}
		if (obj instanceof Array) {
			var res = array.map(obj, function(o) {
				var val = recurse(o);
				return val;
			});
			return '[' + res.join(',') + ']';
		}
		var output = [], key, sep = "", newLine = "";
		for (key in obj) {
			var keyStr, val;
			keyStr = json._escapeString(key);
			val = recurse(obj[key]);
			if (typeof val != "string") {
				// skip non-serializable values
				continue;
			}
			output.push(newLine + keyStr + ":" + sep + val);
		}
		return "{" + output.join("," + sep) + newLine + "}"; // String
	};
	
	
	var _handlersMap = new Dictionary();
	
	idb.connectShapeChanges = function(shape, ctx) {
		var handlers = _handlersMap.item(shape.getId());
		if (!handlers) {
			handlers = [];
			_handlersMap.add(shape.getId(), handlers);
		}
		var entry = {
			context: ctx,
			h: connect.connect(shape, 'onPropertyChanged', ctx, onShapeChanged)
		};
		handlers.push(entry);
	};
	
	idb.disconnectShapeChanges = function(/*ibm_ilog.diagram.data.dtlbinding.BoundContext*/ctx) {
		if (!ctx._shape) 
			return;
		var handlers = _handlersMap.item(ctx._shape.getId());
		if (handlers) {
			array.every(handlers, function(e, idx) {
				if (e.context === ctx) {
					connect.disconnect(e.h);
					handlers.splice(idx, 1);
					return false;
				}
				return true;
			});
		}
	};
	
	function onShapeChanged(property, oldValue, newValue) {
		var ctx = this;
		if (ctx.__changeBatchLevel) {
			ctx.__changeBatchQueue.push(property);
		} else {
			updateShapeBoundProperty(ctx, property, true);
		}
	};
	
	var _storesList = [];
	
	function _findStoreEntry(store) {
		var entry = null;
		array.every(_storesList, function(e, idx) {
			if (e.store === store) {
				entry = e;
				entry.idx = idx;
				return false;
			}
			return true;
		});
		return entry;
	};
	
	idb.connectStoreChanges = function(item, store, /*ibm_ilog.diagram.data.dtlbinding.BoundContext*/ ctx) {
		if (!StoreApi.getFeatures(store).canNotify) {
			return;
		}
		var entry = _findStoreEntry(store);
		if (!entry) {
			entry = {};
			entry.store = store;
			//entry.handler = connect.connect(store, "onSet", store, onStoreChanged);
			entry.handler = StoreApi.listen(store, {onUpdate: onStoreChanged, scope:store});
			// a map between the item identity and the associated context
			entry.ctxMap = new Dictionary();
			_storesList.push(entry);
		}
		var identity = StoreApi.getIdentity(store, item);
		// TODO: is it really a 1-1 relationship ? Not the case if two diagrams are connected to the same store in the same page.
		entry.ctxMap.add(identity, ctx);
	};
	
	idb.disconnectStoreChanges = function(/*ibm_ilog.diagram.data.dtlbinding.BoundContext*/ctx) {
		if (!ctx._dataCtx) 
			return;
		var store = ctx._dataCtx.store;
		if (!store) 
			return;
		var entry = _findStoreEntry(store);
		if (entry) {
			var item = ctx._dataCtx.item;
			var identity = StoreApi.getIdentity(store, item);
			entry.ctxMap.remove(identity);
			// no more entries for this store ?
			if (entry.ctxMap.count === 0) {
				// then disconnect the store
				//connect.disconnect(entry.handler);
				entry.handler.remove();
				// and remove the entry from the list
				_storesList.splice(entry.idx, 1);
			}
		}
	};
	
	function onStoreChanged(item, attribute, oldV, newV) {
		// Here, this = store;        
		var store = this;
		var entry = _findStoreEntry(store);
		if (!entry) 
			return; // should never happen
		var identity = StoreApi.getIdentity(store, item);
		var ctx = entry.ctxMap.item(identity);
		if (!ctx) 
			return;
		updateShapeBoundProperty(ctx, attribute);
	};
	
	var	dataPropExp = /{{\s*(data.[\w.]*)/;
	function getBindingPropertyValue(/*DataContext*/ctx, binding) {
		// check if the binding is a {{data.something...}}
		var	isDataProp = dataPropExp.test(binding.value);
		return isDataProp ? StoreApi.getValue(ctx.store,ctx.item,binding.srcPName) : undefined;		
	}
	
	function updateShapeBoundProperty(ctx, property, fromShape) {
		var bindings = ctx._bindings,
		// indicates if store is dojo.store implementation
			isDojoStore = ctx._dataCtx && StoreApi.fromDojoStore(ctx._dataCtx.store);
		
		if (!property && isDojoStore){ // a store and no property name -> dojo.store notification
			// find the property that changed. To avoid conflict with same-name prop ({{foo}} vs {{data.foo}}
			// ensures it is a *data.* prefix
			for (var i = 0; i < bindings.length; ++i) {
				var b = bindings[i];
				// check if the property has changed ?
				if (b.propValue !== getBindingPropertyValue(ctx._dataCtx, b)){
					property = b.srcPName;
					break;
				}
			}
		}
		for (var i = 0; i < bindings.length; ++i) {
			var binding = bindings[i];
			
			// TODO: uncomment this and demo does not render correctly the "Doctor's office" nodes. (multiline text not wrapped).
			// Either a invalidate() is missing, or a bug elsewhere, but it should work and the code below enabled.
			// 
			/*
			// skip the binding if the notif is from a shapeChanged and the binding is a {{data.xxx}}			
			if (fromShape && dataPropExp.test(binding.value))
				continue;
			*/
			
			if (binding.srcPName === property) {
				var shape = binding.target;
				// update the binding property value;
				if (isDojoStore) {
					binding.propValue = getBindingPropertyValue(ctx._dataCtx, binding);
				}
				var tpl = new dd.Template(binding.value, true);
				var v = tpl.render(ctx);
				v = _fromJson(v);
				var s0 = binding.path.length > 0 ? binding.path[0] : binding.destPName;
				var pname = (s0.substr(0, 1).toUpperCase()) + s0.substr(1);
				var mainGetter = lang.getObject('get' + pname, false, shape);
				if (!mainGetter) {
					continue;
				}
				// get a ref to the current toplevel property value. eg mainProp = shape.getStroke();
				var mainProp = mainGetter.call(shape);
				// go down the properties path and stop before the last element (e.g. mainProp.color)                    
				if (binding.path.length > 0) {
					var o = binding.path.length > 1 ? lang.getObject(binding.path.slice(1).join('.'), false, mainProp) : mainProp;
					// set the bound field to the new value (e.g: mainProp.color.r = newValue)
					o[binding.destPName] = v;
				} else {
					mainProp = v;
				}
				// finally call the setter with the updated mainProp object (e.g: shape.setStroke(mainProp))
				var mainSetter = lang.getObject('set' + pname, false, shape);
				if (mainSetter) {
				    if (config.isBidiInDojoDiagrammer &&  property === "textDir")
				        mainSetter.call(shape, mainProp, property);
				    else    				
					    mainSetter.call(shape, mainProp);
				}
			}
		}
	};
	
	// [av] TODO this is a generic array.contains implementation, maybe shoube placed somewhere else if needed.
	var __contains = function(a, v) {
		var i = a.length;
		while (i--) {
			if (a[i] === v) {
				return true;
			}
		}
		return false;
	};
	
	var __getChange = function(changes, shape, pname) {
		var c;
		for (var i = 0; i < changes.length; i++) {
			c = changes[i];
			if (c.shape == shape && c.pname == pname) {
				return c;
			}
		}
		return null;
	};
	
	function updateShapeBoundProperties(ctx, properties) {
	
		var complexChanges = [];
		var simpleChanges = [];
		
		array.forEach(ctx._bindings, function(binding) {
			if (__contains(properties, binding.srcPName)) {
				var shape = binding.target;
				var tpl = new dd.Template(binding.value, true);
				var v = tpl.render(ctx);
				v = _fromJson(v);
				var s0 = binding.path.length > 0 ? binding.path[0] : binding.destPName;
				var pname = (s0.substr(0, 1).toUpperCase()) + s0.substr(1);
				
				// go down the properties path and stop before the last element (e.g. mainProp.color)                    
				if (binding.path.length > 0) {
				
					var mainGetter = lang.getObject('get' + pname, false, shape);
					if (!mainGetter) {
						return;
					}
					
					var c = __getChange(complexChanges, shape, pname);
					if (!c) {
						c = {
							shape: shape,
							pname: pname,
							value: mainGetter.call(shape)
						};
						complexChanges.push(c);
					}
					
					var o = binding.path.length > 1 ? lang.getObject(binding.path.slice(1).join('.'), false, c.value) : c.value;
					// set the bound field to the new value (e.g: value.color.r = newValue)
					o[binding.destPName] = v;
				} else {
					simpleChanges.push({
						shape: shape,
						pname: pname,
						value: v
					});
				}
			};
		});
		
		array.forEach(complexChanges.concat(simpleChanges), function(c) {
			var mainSetter = lang.getObject('set' + c.pname, false, c.shape);
			if (mainSetter) {
				mainSetter.call(c.shape, c.value);
			}
		});
	};
	
	function _fromJson(v) {
		v = v.replace(/\\/g, '\\\\').replace(/\n/g, '\\n');
		if (v.charAt(0) == '"' && v.slice(-1) == '"') {
			v = '"' + v.slice(1, -1).replace(/"/g, '\\"') + '"';
		} else if (v.charAt(0) == "'" && v.slice(-1) == "'") {
			v = "'" + v.slice(1, -1).replace(/'/g, "\\'") + "'";
		}
		return json.fromJson(v);
	};
	
	idb.BoundContext = lang.extend(function(shape, listen) {
		this._shape = shape;
		// we don't mixin this with shape because we don't want the context methods (like dispose())
		// to be replaced by same-name shape methods.
		Context.call(this, {});
		this._listen = listen;
		if (this._shape) {
			if (this._listen) {
				idb.connectShapeChanges(shape, this);
				if (shape.getData) {
					var dataCtx = shape.getData();
					if (dataCtx) {
						this._dataCtx = dataCtx;
						idb.connectStoreChanges(dataCtx.item, dataCtx.store, this);
					}
				}
			}
			this.setThis(this._shape); // to resolve function call
		}
	}, Context.prototype, {
	
		get: function(key, otherwise) {
			if (this._shape) {
				var val;
				// special case: 'context': to be able to reference the shape in a template filter (as parameter)
				// { prop : {{ foo | myfilter:context }} } 
				// where myfilter:function(val, arg)  <- arg= this._shape
				if (key == 'context') 
					return this._shape;
				// first try a getKey()
				var pname = key.slice(0, 1).toUpperCase() + key.slice(1);
				var getter = lang.getObject('get' + pname, false, this._shape);
				if (getter && typeof(getter) == "function") {
					val = getter.call(this._shape);
					return val;
				}
				if (key in this._shape) {
					return this._shape[key];
				}
				// delegate to optional dict
				return Context.prototype.get.apply(this, arguments);
			}
		},
		dispose: function() {
			if (this._listen && this._shape) {
				idb.disconnectShapeChanges(this);
			}
			delete this._shape;
			if (this._listen) {
				idb.disconnectStoreChanges(this);
			}
			if (this._bindings) {
				this._bindings.length = 0;
			}
			delete this._bindings;
		},
		setBindings: function(bindings) {
			this._bindings = bindings;
			// iterate over the bindins prop 
			if (this._dataCtx && StoreApi.fromDojoStore(this._dataCtx.store)){
				for (var i=0; i<bindings.length;++i){
					var b = bindings[i];
					b.propValue = getBindingPropertyValue(this._dataCtx, b);
				}
			}
		},
		endBatch: function() {
			this.__changeBatchLevel--;
			if (!this.__changeBatchLevel) {
				try {
					updateShapeBoundProperties(this, this.__changeBatchQueue);
				} catch (e) {
					R.error("Wrapped", "BoundContext # endBatch", e);
				} finally {
					delete this.__changeBatchQueue;
				}
			}
		},
		startBatch: function() {
			if (!this.__changeBatchLevel) {
				this.__changeBatchQueue = [];
				this.__changeBatchLevel = 1;
			} else {
				this.__changeBatchLevel++;
			}
		}
		
	});
	
	function processTemplate(template) {
		var tpl = template, isStr = (typeof(template) == "string"), parse = isStr, useDtl = false;
		// a plain JS object -> dump to string except if it has no bindings
		if (!isStr && !template.noDtl) {
			// serialize the template object to string
			tpl = dumpTpl(template); /*String*/
			parse = true;
		}
		if (parse) {
			if (tpl.length > 0) {
				// detect whether dtl is used
				// need to use indexOf as the regexp may return result for str such as "{shape:{..}}"
				if (tpl.indexOf('{{') > 0 || tpl.indexOf("{%") > 0) {
					// some dtl markups have been found
					useDtl = true;
					var result = tpl.replace(idb.dtlExp, idb.replaceExp);
					if (result) {
						// escape the dtl expression so that it can be 'dejsonified'
						var valueExp = /(value):([^}}]*}}[^,}'"]*['"]*)/
						var values = result.match(valueExp);
						while (values) {
							var s = values[2];
							s = "'" + escape(s) + "'";
							result = result.replace(valueExp, "$1:" + s);
							values = result.match(valueExp);
						}
						tpl = result;
					}
				} else { // no DTL detects
					// no DTL and was a plain JS ? mark the template object for next passes
					if (!isStr) {
						tpl = template;
						template.noDtl = true;
					}
				}
			} else { // empty string -> make it plain object
				tpl = {};
				tpl.noDtl = true;
			}
		}
		return {
			tpl: tpl,
			useDtl: useDtl
		};
	};
	
	iid.declareTemplate = function(template) {
		var r = processTemplate(template);
		return new idb.GfxTemplate(r.tpl, r.useDtl);
	};
	
	idb.GfxTemplate = lang.extend(function(template, useDtl) {
		// 2 arguments:  the ctor expects in this case a preprocessed template
		// as first parameter, and whether it uses dtl as 2nd parameter.
		//
		// 1 argument : the ctor expects a raw template.
		
		this.template = null;
		this.useDtl = false;
		var i;
		
		if (arguments.length > 1) {
			this.useDtl = useDtl;
			if (useDtl) {
				this.template = new dd.Template(template, true);
			} else {
				this.template = template; /*String || Object*/
			}
		} else {
			var r = processTemplate(template);
			this.useDtl = r.useDtl;
			if (this.useDtl) {
				this.template = new dd.Template(r.tpl, true);
			} else {
				this.template = r.tpl; /*String || Object*/
			}
		}
	}, {
		render: function(context, parent) {
			// summary:
			//    Renders this template as a gfx shape.
			// context: dojox.dtl.Context:
			//    The binding context.
			// parent: dojox.gfx.Surface || dojox.gfx.Group
			//    The gfx parent.
			// returns: dojox.gfx.Shape
			//    The shape corresponding to the template definition. 
			
			var v;
			if (this.useDtl) {
				v = this.template.render(context); /*String*/
			} else {
				v = this.template; /* String || object */
			}
			var o, bindings;
			if (typeof(v) == "string") {
				o = _toObject(v);
				if (this.useDtl) 
					bindings = this._reduceBindings(o);
			} else {
				o = v;
			}
			// _instantiate is actually ibm_ilog.diagram.templating.instantiate,
			// but we cannot depend in templating because it would cause a circular dependency,
			// The _instantiate function is added to GfxTemplate by the templating module. 
			var s = this._instantiate(parent, o, bindings);
			if (bindings && context.setBindings) 
				context.setBindings(bindings);
			return s;
		},
		
		_reduceBindings: function(o, bindings) {
			var bindings = bindings || [];
			for (var p in o) {
				if (p.indexOf("_binding_") !== -1) {
					var b = o[p];
					b.value = unescape(b.value);
					b.idx = bindings.length;
					var pos = b.srcPName.indexOf('.');
					if (pos != -1) {
						b.srcPName = b.srcPName.slice(pos + 1);
					}
					bindings.push(b);
				} else if (typeof(o[p]) == "object" || typeof(o[p]) == "function") {
					this._reduceBindings(o[p], bindings);
				}
			}
			return bindings;
		}
	});
	
	function _toObject(v){
		var filtered = [], c = 0;
		v = v.replace(/(:[\s]*")(\s*\b[^"]*)(")/g, function(m, p1, p2, p3){
			m = p2.replace(/\\/g, '\\\\').replace(/\n/g, '\\n');
			return p1 + m + p3;
		});
		v = v.replace(/(:[\s]*')(\s*\b[^']*)(')/g, function(m, p1, p2, p3){
			m = p2.replace(/\\/g, '\\\\').replace(/\n/g, '\\n');
			return p1 + m + p3;
		});
		return json.fromJson(v);
	}
	
	var DataContext = declare('ibm_ilog.diagram.data.DataContext', null, {
		constructor: function(item, store) {
			this.item = item;
			this.store = store;
		},
		
		getValue: function(/*String*/attribute, /*value?*/ defaultValue) {
			// summary:
			//     Returns a single attribute value. This method is a shortcut to
			//     this.store.getValue(item, attribute, defaultValue).
			
			if (this.store && this.item) {
				return StoreApi.getValue(this.store, item, attribute, defaultValue);
			}
			return null;
		},
		
		get: function(key) {
			// summary:
			//     Internal method. Should not be called directly.
			
			var store = this.store;
			var item = this.item;
			if (key == "getLabel") {
				return StoreApi.getLabel(store, item);
			} else if (key == "getAttributes") {
				return StoreApi.getAttributes(store, item);
			} else if (key == "getIdentity") {
				if (StoreApi.getFeatures(store).identity) {
					return StoreApi.getIdentity(store, item);
				}
				return "Store has no identity API";
			} else {
				var values = StoreApi.getValues(store, item, key);
				if (!values) {
					return;
				}
				if (!(values instanceof Array)) {
					return new DataContext(values, store);
				}
				
				values = array.map(values, function(value) {
					if ((typeof(value) == "object" || typeof(value) == "function") && StoreApi.isItem(store, value)) {
						return new DataContext(value, store);
					}
					return value;
				});
				values.get = idb._get;
				return values;
			}
		}
	});
	
	idb.DataContext = DataContext;
	
	DataContext.prototype.get.safe = true;
	
	return idb;
});
