/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/event",
"dojo/_base/array",
"dojo/_base/json",
"dojox/collections/ArrayList",
"./Interactor",
"./DragInteractor",
"../Selection",
"../Selectable",
"../util/Geometry"
],
function(
declare,
event,
arr,
json,
ArrayList,
Interactor,
DragInteractor,
Selection,
Selectable,
g
){

var superclass = DragInteractor.prototype;
	
/*=====
var DragInteractor = ibm_ilog.diagram.interactors.DragInteractor;
=====*/

var MarqueeSelectionInteractor =
declare("ibm_ilog.diagram.interactors.MarqueeSelectionInteractor", [DragInteractor], {
	//summary:
	//		This function provides the functionality to manage marquee selection events on links and nodes.
	_selection: null,
	_background: null,
	_marqueePointerStart: null,
	_marquee:null,
	_marqueeStyle: json.fromJson('{"fill":"rgba(0, 0, 255, 0.1)" , "strok":{"width": "1", "color":"#0000FF"}}'),
	_marqueeMode: null,
	_partial: null,
	_mustClear: null,
	_declareStates: function() {
	// Summary:
	//		Add the crtl start to the original states
	this.inherited(arguments);	
		this._declareState("idle",["start","startCtrl"]);
	},
	
	getDefaultConnections:function(){
		//
		//	summary:
		//		returns the default event mapping
		//
    		var map = this.inherited(arguments);
    		map.startCtrl = {src:this._getInitialEventSource(),srcEvt:"onmousedown",connectTo:"_dragPreStart",filter:this._buildInputFilter({button:0,ctrl:true}),gfxConnect:true};
    		return map;
    },
    
	initialize: function(viewport,selection) {
		// summary:
		//		creates a new instance, sets the viewport appropriate elements from where to connect and set the default event mapping.
		//		If the given root is not a viewport, the standard selection is activated
		if(selection==null){	
			this._selection = new Selection();
		}else{
			this._selection = selection; 
		}
		this._background = viewport.getEventSourceBackground();
		this._marqueeMode = MarqueeSelectionInteractor.topParent;
		this._partial = true;
		this._viewport = viewport;
		this._initialize();
		return this;
	},
	
	_getInitialEventSource: function() {
		return this._background;
	},
	
	setMarqueeStyle: function(style/*a style json object*/){
    	//summary:
		//		set the marquee style
    	this._marqueeStyle = style;
    },
    
    getMode: function(){
    	//summary:
		//		gets the marquee mode
    	return this._marqueeMode;
    },
    
    setMode: function(mode){
    	//summary:
		//		sets the marquee mode
    	this._marqueeMode = mode;
    },
    isPartialSelectionEnabled: function(){
    	//summary:
		//		gets if the marquee selects partial bounded elements.
    	return this._partial;
    },
    
    setPartialSelectionEnabled: function(partial){
    	//summary:
		//		sets if the marquee selects partial bounded elements.
    	this._partial = partial;
    },
    _dragPreStart: function(e) {
		//	summary:
		//		Starts the marquee selection process by storing initial coordinates for pointer and view rectangle
		//
    	this.inherited(arguments);
    	if(!e.ctrlKey) { // ask for ctrl key
    		this._mustClear = true;
    	}else{
    		this._mustClear = false;
    	}
		this._marqueePointerStart = this._viewport.eventContentLocation(e);
			
    },
    
    _dragMove: function(e) {
		//
		//	summary:
		//		When the receiver is _marqueeActive, draw the corresponding marquee on the viewport UI layer.
    	//
    	// this.inherited(arguments); 
		// replaced by the following for performance:
		superclass._dragMove.apply(this, arguments);
		
    	var p = this._viewport.eventContentLocation(e); // current mouse coord
        
        var r = g.createRect(this._marqueePointerStart,p);
        
        var transformedRect = this._transformRect(r);
        transformedRect.width = transformedRect.width || 1; // zero crash vml
        transformedRect.height= transformedRect.height|| 1; // zero crash vml
        	
        if(this._marquee==null){
        	this._marquee = this._viewport.getOverlayLayer().createRect( transformedRect );
        	this._applyStyle(this._marquee,this._marqueeStyle);
        }else{
        	this._marquee.setShape(transformedRect);
        }
        
        
    },
   
	_dragEnd: function(e) {
		//
		//	summary:
		//		Terminates the current marquee selection process.
    	//
    	var dragged = this.hasDragged;
		this.inherited(arguments);
    	if(dragged){
    		var p2 = this._viewport.eventContentLocation(e);
    		this._selectBoundedElements(this._marqueePointerStart,p2);
    		this._viewport.getOverlayLayer().remove(this._marquee);
    		this._marquee = null;
    	}
    },
    
    _selectBoundedElements: function(p1,p2){
    	// Summary:
    	//		select all the elements that are completely bounded by the rectangle delimited by the given points
    	
    	var rect = g.createRect(p1,p2);
    	var graph = this._viewport._diagram.getGraph();
    	var toBeAdded = [];
    	this._selectElements(graph,graph,rect,toBeAdded);
    	this._selection.add(toBeAdded,this._mustClear);
    },
    
    _selectElements: function(parentGraph,graph,rect,toBeAdded){
    	var anyAdded = false;
    	for(var n in graph.children){
    		var c = graph.children[n];
    		var b = c.getBounds(parentGraph);
    		
    		var isBounded = this._evaluatesBounded(parentGraph,c,b,rect);
    		var isTouched = this._partial && this._evaluatesTouched(parentGraph,c,b,rect);
    		var isSubgraph = c._isIBMDiagramSubgraph && !c.isCollapsed();
    		
    		var shouldBeIncluded = isBounded||isTouched;
    		
    		switch(this._marqueeMode){
    			case MarqueeSelectionInteractor.topLevelOnly:{ 
    				if(shouldBeIncluded){
    					this._addToSelection(c,toBeAdded);
    					anyAdded = true;}
    				break;}
    			case MarqueeSelectionInteractor.topParent:{ 
    				if( (isSubgraph && isBounded) || (!isSubgraph && shouldBeIncluded)){
    					this._addToSelection(c,toBeAdded);
    					anyAdded = true;
    				}else {if(isSubgraph){
    					anyAdded = this._selectElements(parentGraph,c.getGraph(),rect,toBeAdded) || anyAdded;
    					if(!anyAdded && shouldBeIncluded){
    						this._addToSelection(c,toBeAdded);
    						anyAdded = true;
    					}
    				}}
    				break;}
    			case MarqueeSelectionInteractor.all:{ 
    				if(shouldBeIncluded){
    					this._addToSelection(c,toBeAdded);
    				anyAdded = true;}
    				if(isSubgraph){
    					anyAdded = this._selectElements(parentGraph,c.getGraph(),rect,toBeAdded) || anyAdded;}
    				break;}
    		}
    	}
    	return anyAdded;
    },
    _evaluatesBounded: function(parentGraph,element,bound,rect){
    	return bound && g.containsRect(rect,bound);
    },
    _evaluatesTouched: function (parentGraph,element,bound,rect){
    	if(element._isIBMDiagramLink){
    		var points = element._pathPoints;
    		var t = element.getShapeToContainerTransform(parentGraph);
    		var included = false;
    		arr.forEach(points,function(p){
    				included = included || g.containsPoint(rect,t.transformPoint(p));
    		},this);
    		return included;
    	}else{
    		return bound && g.rectIntersects(bound,rect);
    	}
    },
    _addToSelection: function(element,toBeAdded){
    	if(this._selection.accept(element) && element.isSelectable()){
    		toBeAdded.push(element);
    	}
    },
  //TODO this function should be in a tool
    _transformRect: function(bb/*rectangle*/) {
    	//
		//	summary:
		//		transform the rectangle to absolute UI coordinates
    	//
    	var v = this._viewport, z = v.getZoom(), vr = v.getViewRect();
    	bb = g.moveRect(bb,g.negPoint(vr)); 		
    	bb.width = bb.width*z;
    	bb.height = bb.height*z;
    	bb.x = bb.x*z;
    	bb.y = bb.y*z;
		return bb;
	},
    //TODO this function should be in a tool
	_applyStyle:function(shape, style){
		// summary:
		//		sets a new style to the desired element
		// shape:
		//		the shape to apply the style
		// style:
		//      the new style to be applied
		for (var p in style) {
			if (style.hasOwnProperty(p)){
				var setter = 'set' + p.charAt(0).toUpperCase() + p.substring(1);
				if (shape[setter]) {
					shape[setter](style[p]);
				}
			}
		}
	}

});

// ibm_ilog.diagram.interactors.MarqueeSelectionInteractor.topLevelOnly: number
//		in this mode, only the top level elements (the ones that are created in the graph) are selected.
//		This is the default value.
MarqueeSelectionInteractor.topLevelOnly = 0;

// ibm_ilog.diagram.interactors.MarqueeSelectionInteractor.topParent: number
//		in this mode, only the highest parent of the selected elements is selected, but not its children. 
//		For example, if a complete subgraph is bounded, just the subgraph is selected, but not its children.
//		In the case the subgraph is not completely bounded by the marquee, its bounded children are selected.
MarqueeSelectionInteractor.topParent = 1;

//ibm_ilog.diagram.interactors.MarqueeSelectionInteractor.all: number
//		in this mode all the bounding elements are selected.
MarqueeSelectionInteractor.all = 2;

return MarqueeSelectionInteractor;

});