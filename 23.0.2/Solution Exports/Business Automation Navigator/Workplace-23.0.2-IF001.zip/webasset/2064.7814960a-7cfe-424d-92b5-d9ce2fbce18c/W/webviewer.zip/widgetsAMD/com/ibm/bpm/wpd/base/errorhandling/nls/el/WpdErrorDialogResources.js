define({      
//begin v1.x content
    errorDialogTitle: "Σφάλμα IBM BPM",
    moreDetails: "Περισσότερες λεπτομέρειες...",
    closeMessage: "Κλείσιμο όλων των μηνυμάτων σφάλματος",
    contentMessage: "Παρουσιάστηκε σφάλμα."
//end v1.x content
});

