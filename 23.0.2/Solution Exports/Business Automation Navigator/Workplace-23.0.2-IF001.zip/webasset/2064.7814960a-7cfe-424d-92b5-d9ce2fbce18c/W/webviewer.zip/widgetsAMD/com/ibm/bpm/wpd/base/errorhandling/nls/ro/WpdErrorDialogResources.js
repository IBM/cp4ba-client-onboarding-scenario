define({      
//begin v1.x content
    errorDialogTitle: "Eroare IBM BPM",
    moreDetails: "Mai multe detalii...",
    closeMessage: "Închidere toate mesajele de eroare",
    contentMessage: "A apărut o eroare."
//end v1.x content
});

