define({      
//begin v1.x content
    errorDialogTitle: "IBM BPM Hatası",
    moreDetails: "Daha Fazla Ayrıntı...",
    closeMessage: "Tüm Hata İletilerini Kapat",
    contentMessage: "Bir hata oluştu."
//end v1.x content
});

