/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/declare", "dojox/collections/ArrayList"],
function(declare, ArrayList){

var Selectable =
declare("ibm_ilog.diagram.Selectable", [], {
	// summary:
	//		Selectable class group all the functionality to store and manage the selection state and style of a component.
	//      Link and Node must inherit this class in order to be selectable.
	
	// Allows to test the class faster that testing declaredClass
    _isIBMDiagramSelectable: true,
    
	// Internal selection state
	_selected: false,
	// enabled for select
	_selectable: true,
    // the list of styled
	_styledChildren : null,
   
    isSelected: function() {
	// summary:
	//		returns the selected state
	// returns:
	//      true if selected
		return this._selected;
	},
	setSelected: function(selected) {
		// summary:
		//		sets the selected state
		// selected:
		//		the new selection state
		// returns:
		//		true if the selection state could be changed
		this._selected = selected;
		this._changeSelectionStyle(selected);
		return true;
	},
	toggleSelected: function(){
		// summary:
		//		toggle the selection state
		// returns:
		//		true if the selection state could be changed
		var s = !this._selected;
		return this.setSelected(s);
	},
	setSelectable: function(selectable){
		// summary:
		//		enable or disable selecting
		// enabled:
		// 		true to enable selecting
		this._selectable = selectable;
	},
	isSelectable: function(){
		// summary:
		//		return if the selectable can be selected
		return this._selectable;
	},
	_changeSelectionStyle: function(selected){
		// summary:
		//		change the selection style
		// selected:
		//		the new selection state
		if(this._styledChildren == null){
			this._styledChildren = new ArrayList();
			this._findAllStyledElements();
		}
		var iterator = this._styledChildren.getIterator();
		while(!iterator.atEnd()){
			var shape = iterator.get();
			this._applySelectedStyle(shape,selected);
		}
	},
	
	_applySelectedStyle: function(shape,selected){
		// summary:
		//		change the selection style of the given shape
		// shape:
		//		the shape to be styled
		// selected:
		//		the new selection state	
		if(selected){
			if(!shape.onSelectionStyle || shape.__selectedStyleChanged){ // Added to fix Defect 344
				if(shape.__selectedStyleChanged){
					this._applyStyle(shape,shape['standardStyle']);
				}
				shape.standardStyle = this._getStandardStyle(shape,shape['selectedStyle']);
				this._applyStyle(shape,shape['selectedStyle']);
				shape.onSelectionStyle = true;
			}
		}else{
			this._applyStyle(shape,shape['standardStyle']);
			shape.standardStyle = null;
			shape.onSelectionStyle = false;
		}
		delete shape.__selectedStyleChanged;
	},
	_findAllStyledElements: function(){
		this._findStyledChildren(this.children);
	},
	_findStyledChildren: function(childrenArray){
		// summary:
		//		find all the children that have to be styled when selecting, and save the standard style
		for (var c in childrenArray){
			var child = childrenArray[c];
			if(!Selectable.Util.isSelectableInstance(child)) {
					if (child['selectedStyle']) {
						this._styledChildren.add(child);
					}
					if (child['children']) {
						this._findStyledChildren(child['children']);
					}
			}
		}
	},
	//TODO this function should be in a tool
	_applyStyle:function(shape, style){
		// summary:
		//		sets a new style to the desired element
		// shape:
		//		the shape to apply the style
		// style:
		//      the new style to be applied
		for (var p in style) {
			if (style.hasOwnProperty(p)){
				var setter = 'set' + p.charAt(0).toUpperCase() + p.substring(1);
				if (shape[setter]) {
					shape[setter](style[p]);
				}
			}
		}
	},
	_getStandardStyle:function(shape, style){
		// summary:
		//		gets the standard style of the given style element
		// shape:
		//		the shape to get the style
		// style:
		//      the style from where to get the elements
		var simpleStyle = {};
		for (var p in style) {
			if (style.hasOwnProperty(p)){
				var getter = 'get' + p.charAt(0).toUpperCase() + p.substring(1);
				if (shape[getter]) {
					simpleStyle[p] = shape[getter]();
				}
			}
		}
		return simpleStyle;
	}
});


Selectable.Util = {
	isSelectableInstance: function(ge){
		// Summary:
		//		this function returns if the given element is an instance of Selectable.
		//		It is a workaround to avoid using isInstanceOf (not supported on dojo 1.3.2)
		if(ge['_isIBMDiagramSelectable']){
			return true;
		}
		return false;
	}
}

return Selectable;

});
