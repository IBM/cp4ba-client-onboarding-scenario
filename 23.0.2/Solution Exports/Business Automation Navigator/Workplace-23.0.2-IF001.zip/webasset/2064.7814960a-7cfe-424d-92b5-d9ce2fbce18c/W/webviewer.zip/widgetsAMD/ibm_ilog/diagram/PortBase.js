/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/declare", "dojo/_base/array", "dojox/gfx/matrix",
"./util/Geometry", "./util/ClippingUtil"],
function(declare, array, matrix, Geometry, ClippingUtil){

var PortBase = declare("ibm_ilog.diagram.PortBase", null, {
	// summary:
	//		The PortBase class represents the base class for ports.
	// description:
	//		A port defines a connection point between a Link and a Node.
	//		The PortBase class is intended as the base class for subclasses that
	//		define different types of ports. PortBase instances should not be created
	//		directly, only its subclasses should be used.
	
	_owner: null,
	_links: null,
	_clipOnShape: null,
	
	getOwner: function() {
		// summary:
		//		Gets the owner Node of this port.
		// returns:
		//		The Node to which this port belongs.
		return this._owner;
	},
	
	_setOwner: function(owner) {
		// summary:
		//		Sets the owner Node of this port.
		// owner: ibm_ilog.diagram.Node:
		//		The new owner of this port.
		// description:
		//		This method is internal and should not be called directly by application code.
		
		if (owner != this._owner) {
			this._owner = owner;
			this.invalidateLinks();
		}
	},
	
	getConnectionPoint: function(link, parent, referencePoint, connectionPoint, originPoint, start){
		// summary: 
		//		Gets the connection point and the origin point for this port.
		// link: ibm_ilog.diagram.Link:
		//		The Link that is (or will be) connected to this port.
		// referencePoint:
		//		The opposite point of the segment connected to this port.
		// parent:
		//		The parent object (usually a Graph) that determines the coordinate space
		//		the connection point is relative to.
		// connectionPoint:
		//		An object (with 'x' and 'y' properties) into which the connection point will be stored.
		//		The connection point is the point where the link will start or end.
		// originPoint:
		//		An object (with 'x' and 'y' properties) into which the origin point will be stored.
		//		The origin point is the point towards which the link will 'aim' (typically the center of the node),
		//		and is used to determine the shape of orthogonal links for example.
		// returns:
		//		The 'connectionPoint' argument.
		// description:
		//		This is the central method of the PortBase class and is called by the Link object
		//		to get its start and end points. This method calls computeConnectionPoint, which is
		//		the method that actually calculates the connection point in the PortBase subclasses.
		//		Then, getConnectionPoint applies the clipping if getClipOnShape() is true.
		//		So, getConnectionPoint should not be overridden in subclasses, computeConnectionPoint
		//		is the method that is overridden instead.
		this.computeConnectionPoint(link, parent, referencePoint, connectionPoint, originPoint, start);
		if(this.getClipOnShape()){
			var p = this._clipToShape(link,parent,referencePoint, connectionPoint, originPoint, start);
			connectionPoint.x = p.x;
			connectionPoint.y = p.y;
		}
		return connectionPoint;
	},	
	
	computeConnectionPoint: function(link, parent, referencePoint, connectionPoint, originPoint, start){
		// summary: 
		//		Computes the connection point and the origin point for a given subclass of PortBase.
		// link: ibm_ilog.diagram.Link:
		//		The Link that is (or will be) connected to this port.
		// referencePoint:
		//		The opposite point of the segment connected to this port.
		// parent:
		//		The parent object (usually a Graph) that determines the coordinate space
		//		the connection point is relative to.
		// connectionPoint:
		//		An object (with 'x' and 'y' properties) into which the connection point will be stored.
		//		The connection point is the point where the link will start or end.
		// originPoint:
		//		An object (with 'x' and 'y' properties) into which the origin point will be stored.
		//		The origin point is the point towards which the link will 'aim' (typically the center of the node),
		//		and is used to determine the shape of orthogonal links for example.
		// returns:
		//		The 'connectionPoint' argument.
		// description:
		//		This method is called by PortBase.getConnectionPoint, and should be overridden in
		//		PortBase subclasses to actually implement the calculation of the connection point.
		//		Clipping on the node's shape is implemented by getConnectionPoint, so
		//		computeConnectionPoint does not have to care about it.
		//		The base implementation for the PortBase class returns the center of the node for both
		//		the connection point and the origin point.
		
		var bounds = this.getConnectionBounds(parent);
		connectionPoint.x = originPoint.x = bounds.x + bounds.width / 2;
		connectionPoint.y = originPoint.y = bounds.y + bounds.height / 2;
		return connectionPoint;
	},
	
	getConnectionBounds: function(parent) {
		// summary:
		//		Gets the bounds of the owner node's base shape used to compute the connection point.
		// parent:
		//		The parent object (usually a Graph) that determines the coordinate space
		//		the bounds are relative to.
		// returns:
		//		A rectangle (with 'x', 'y', 'width' and 'height' properties) containing the bounds
		//		used to compute the connection point.
		// description:
		//		This method returns the bounds that will be used by the port to compute the connection and origin points.
		//		The default implementation returns the bounds of the base shape returned by getBaseShape().
		//		This method	can be overridden to return different bounds.
		
		if(!parent)
			parent = this._owner.getParent();
		
		var baseShape = this.getBaseShape();
        var rect = baseShape.getBoundingBox();
        var m = matrix;
        // t1: transform from surface -> base shape
        var t1 = baseShape._getRealMatrix() || m.identity;
        // t2: transform from surface -> parent
        var t2 = parent._getRealMatrix() || m.identity;
        var t = m.multiply(t2.inverse(), t1);
		rect = t.transformRectangle(rect);
        return rect;
	},
	
	needsReferencePoint: function() {
		// summary:
		//		Indicates whether or not this port needs a reference point to compute the connection point.
		// returns:
		//		True if this port needs a reference point to compute the connection point,
		//		or false otherwise.
		// description:
		//		This method is used by a PortBase subclass implementation to signal whether or not
		//		it needs (and uses) the referencePoint argument passed to the getConnectionPoint method.
		//		A subclass must return true if it actually uses the referencePoint, or false if it does
		//		not use it. If needsReferencePoint returns true, the caller of the getConnectionPoint method
		//		(usually the Link object) must pass a valid referencePoint. If needsReferencePoint returns false,
		//		the PortBase subclass guarantees that the referencePoint will never be used or referenced,
		//		so the caller may pass an invalid point, or a null or undefined object.
		//		By default the method returns true if getClipOnShape() returns true, of false otherwise.
		//		PortBase subclasses that always need a reference point must override this method and return true.
		
		return this._clipOnShape || false;
	},
	
	invalidateLinks: function() {
		// summary:
		//		Invalidates the shape of all the links connected to this port. 
		// description:
		//		Invalidates the shape of all the links connected to this port. 
		//		This method must be called by PortBase subclasses when a change of the port
		//		causes the connection point to change.
		if(this._links)
			for(var i = 0; i < this._links.length; i++)
				this._links[i].invalidateLinkShape();
				
	},
	
	_addLink: function(link) {
		// summary:
		//		Adds a link to the list of links connected to this port.
		// description:
		//		This method is internal and should not be called directly by application code.
		if(!this._links)
			this._links = [ link ];
		else
			this._links.push(link);
	},
	
	_removeLink: function(link) {
		// summary:
		//		Removes a link from the list of links connected to this port.
		// description:
		//		This method is internal and should not be called directly by application code.
		if (this._links) {
			var index = array.indexOf(this._links, link);
			if (index >= 0) {
				if(this._links.length == 1)
					this._links = null;
				else
					this._links.splice(index, 1);
			}
		}
	},
	
	getLinks: function() {
		// summary:
		//		Gets the links connected to this port.
		// returns:
		//		An array of Links connected to this port.
		// description:
		//		Note that this method always returns a newly allocated array.
		var links = [];
		if (this._links) {
			for(var i = 0; i < this._links.length; i++)
			links.push(this._links[i]);
		}
		return links;
	},
	
	getLinksCount: function() {
		// summary:
		//		Gets the number of links connected to this port.
		
		return this._links ? this._links.length : 0;
	},

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////   CLIPPING TOOLS ///////////////////////////////////////////////////////////////////	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

	setClipOnShape: function(clipOnShape){
		// summary:
		//		Determines whether the connection point is "clipped" on the base shape of the node.
		// description:
		//		If clipOnShape is true, the getConnectionPoint method will extend the segment defined
		//		by the reference point and the connection point so that the connection point is on the
		//		outline of the node's shape, so that the connection point always "touches" the node shape
		//		even if the node is not rectangular (for example, if the node has an elliptical of polygonal shape).
		//		If clipOnShape is false, the getConnectionPoint always returns the return of computeConnectionPoint
		//		without modifying it, and the point may not be exactly on the boundary on the node shape.
		// clipOnShape:
		//		If true, the connection point is clipped on the node's shape, otherwise the connection point
		//		is the point returned by computeConnectionPoint.
		
		if (clipOnShape != this._clipOnShape) {
			this._clipOnShape = clipOnShape;
			this.invalidateLinks();
		}
	},
	
	getClipOnShape: function(){
		// summary:
		//		Gets the flag that determines whether the connection point is "clipped" on the base shape of the node.
		// description:
		//		If clipOnShape is true, the getConnectionPoint method will extend the segment defined
		//		by the reference point and the connection point so that the connection point is on the
		//		outline of the node's shape, so that the connection point always "touches" the node shape
		//		even if the node is not rectangular (for example, if the node has an elliptical of polygonal shape).
		//		If clipOnShape is false, the getConnectionPoint always returns the return of computeConnectionPoint
		//		without modifying it, and the point may not be exactly on the boundary on the node shape.
		// returns:
		//		True if the connection point is clipped on the node's shape, or false otherwise.
		
		return this._clipOnShape;
	},
	
	getBaseShape : function() {
		// summary:
		//		Gets the shape contained in the owner node's template to which links should be connected.
		// description:
		//		The base shape is used by getConnectionBounds to compute the default connection bounds,
		//		and also when clipOnShape is true to clip the connection point if the base shape is
		//		non-rectangular.
		//		By default the base shape is determined by calling the getBaseShape() of the owner node,
		//		but this can be overridden to connect links to a different template part of the node.
		
		return this._owner.getBaseShape();
	},
	
	_clipToShape: function(link,parent,referencePoint, connectionPoint, originPoint, start){
		
		var node = this._owner;
		var shape = this.getBaseShape();
		var bounds = this.getConnectionBounds(parent);
		
		if(shape == node){
			var shape = Geometry.Rect(bounds.x,bounds.y,bounds.width,bounds.height);
		}
			
		var resClipPoint = ClippingUtil.clipToShape(node,parent,shape,bounds,originPoint, connectionPoint, referencePoint)

		return resClipPoint?resClipPoint:connectionPoint;
	}
		
});

return PortBase;

});
