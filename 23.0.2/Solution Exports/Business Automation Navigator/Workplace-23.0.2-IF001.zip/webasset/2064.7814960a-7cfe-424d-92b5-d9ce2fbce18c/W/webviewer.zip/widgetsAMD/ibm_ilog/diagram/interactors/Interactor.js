/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"../main",
"dojo/_base/declare", "dojo/_base/lang", "dojo/_base/array", "dojo/_base/sniff",
"dojox/collections/Dictionary", "dojox/gfx",
"../_base/dojoext", "../util/HandleSet", "../util/ErrorReporter", "../Selectable"
],
function(
iid,
declare, lang, arr, has,
Dictionary, gfx,
dojex, HandleSet, R, Selectable
){
	
var InteractorState =
declare("ibm_ilog.diagram.interactors.InteractorState", [], {
	//
	//    summary:
	//        Represents a state of an interactor in terms of
	//      the connections are active during it.
	//
	_connections: null,

	_id: "",

	_interactor: null,

	constructor: function (interactor, id, connections) {
		this._interactor = interactor;
		this._id = id;
		this._connections = connections;
	},
	
	addConnection: function(c) {
		this._connections.push(c);
	},

	_forEachId: function (fname, s) {
		arr.forEach(this._connections, s[fname], s);
	},

	enter: function () {
		this._forEachId("_doConnect", this._interactor);
	},

	leave: function (host) {
		this._forEachId("_disconnect", this._interactor);
	}
});

var gfxCon = HandleSet.gfxConnector;
var gfxDis = HandleSet.gfxDisconnector;

/*=====
var HandleSet = ibm_ilog.diagram.util.HandleSet;
=====*/

var Interactor =
declare("ibm_ilog.diagram.interactors.Interactor", [HandleSet], {
	//
	//    summary:
	//        The interactor defines the API and common functionality for all the event management interactors.
	//
	//    description:
	//        The 
	//

	//
	//    The map with the connections used by the interactor
	//
	_connections: null,

	//
	//    _enabled:
	//        temporarily ignore events, but keeps dojo.connections
	//
	_enabled: true,

	//
	//    _manager:
	//        the mouse interactor manager which coordinates the use of the interactor
	//
	_manager: null,
	
	//
	//    _keyManager:
	//        the keyboard interactor manager which coordinates the use of the interactor
	//
	_keyManager: null,
	
	//
	//    _states:
	//        the states declared for this interactor
	//
	_states: null,

	//
	//    _state:
	//        the current state of the interactor
	//
	_state: null,

	//
	//    _hotKeys:
	//        the current hotKeys of the interactor
	//			format
	//			{ keyCode1:[connectionId1,connectionId2], keyCode2:[connectionId2] }
	//
	_hotKeys: null,

	_declareState: function (id, cids) {
		//
		//    summary:
		//        declares a state of the interactor
		//
		this._states.add(id, new InteractorState(this, id, cids));
	},

	_goStateId: function (stateId) {
		//
		//    summary:
		//        enters the state with the given id
		//
		this._goState(this._states.item(stateId));
	},

	_goState: function (s) {
		//
		//    summary:
		//        enters the state s
		//
		if (this._state !== s) {
			if (this._state) {
				this._state.leave(this);
			}
			this._state = s;
			if (this._state) {
				this._state.enter(this);
			}
		}
	},

	_declareStates: function () {
		//
		//    summary:
		//        subclasses must override this method for declaring interactor states
		//
	},

	setManager: function (manager) {
		this._manager = manager;
	},
	
	setKeyManager: function (keyManager) {
		this._keyManager = keyManager;
		this.registerHotKeys();
	},
	
	_initialize: function () {
		//
		//    summary:
		//        basic internal initialization
		//
		this.setConnections(this.getDefaultConnections());
		this._states = new Dictionary();
		this.initializeFilters();
		this._hotKeys = {};
		this._declareStates();
		return this;
	},

	_doConnect: function (id) {
		//
		//    summary:
		//        connects the connection declared with the given id, used by state transitions
		//
		var cdata = this._connections[id];
		if (cdata && !cdata.hotKey) {
			var target = cdata.target || this;
			if (cdata.connectTo in target) {
				var filteredHandler = cdata.filteredHandler;
				try{
					this._connect(id, cdata.src, cdata.srcEvt, this, filteredHandler, cdata.gfxConnect && gfxCon, cdata.gfxConnect && gfxDis);
				} catch(e) {
					R.warn("EventConnectionFailed", cdata.srcEvt);
				}
			} else {
				R.error("InvalidInteractorEvent", cdata.connectTo);
			}
		} else {
			R.error("InvalidInteractorId",id);
		}
	},
	
	keyPressed: function(ids,e){
		var managed = false;
		for(var index in ids){
			var cdata = this._connections[ids[index]];
			if(cdata.hotKey){
				managed = cdata.filteredHandler(e) || managed;
			}
		}
		return managed;
	},
	
	initializeFilters: function () {
		//
		//    summary:
		//       
		//
		for(var id in this._connections){
			var cdata = this._connections[id];
			var target = cdata.target || this;
			if (cdata.connectTo in target) {
				var filter = this._applyFilter(target, cdata.connectTo, cdata.filter);
				cdata.filteredHandler = filter;
			} else {
				R.error("InvalidInteractorEvent", cdata.connectTo);
			}
		}
	},

	registerHotKeys: function(){
		if(this._keyManager){
			this._keyManager.clearHotKeys(this.getKeyInteractorId(),this._hotKeys);
			this._hotKeys = {};
			for(var id in this._connections){
				var cdata = this._connections[id];
				var hk = cdata.hotKey;
				if(!(hk in this._hotKeys)){
					this._hotKeys[hk] = [];
				}
				this._hotKeys[hk].push(id);
			}
			this._keyManager.setHotKeys(this.getKeyInteractorId(),this._hotKeys);
		}
	},
	
	setEnabled: function (b) {
		if (this._enabled != b) {
			this._enabled = b;
			if (b) {
				this.onEnabled();
			}
			if (!b) {
				this.onDisabled();
			}
		}
	},

	getEnabled: function () {
		return this._enabled;
	},

	onEnabled: function () {},
	onDisabled: function () {},

	activate: function () {
		//
		// summary:
		//        Activates "idle" state
		//
		this._goStateId("idle");
	},

	deactivate: function () {
		//
		// summary:
		//        Disconnects all connections by going to the null state
		//
		this._goState(null);

		// shut down other temporary connections
		this._disconnectAll();
	},

	_fconnect: function (id, source, event, obj, handlerName) {
		//
		// summary:
		//        Makes a temporary connection with the standard enabled-only filter
		//
		switch (arguments.length) {
		case 5:
			return this._connect(id, source, event, obj, this._applyFilter(obj, handlerName));
		default:
			R.error("InvalidNumberOfArguments", arguments, 5);
		}
	},

	toString: function () {
		return this.declaredClass.split(".").pop();
	},

	setConnections: function (connections) {
		//
		//    summary:
		//        sets a new connections configuration
		//
		this._connections = connections;
	},

	overrideConnections: function (connections) {
		//
		//    summary:
		//        Override the default event map with the given handlers
		//
		this._connections = lang.clone(this._connections);
		lang.mixin(this._connections, connections);
	},

	getConnections: function () {
		//
		//    summary:
		//        return the eventMap
		//
		return this._connections;
	},

	getDefaultConnections: function () {
		//
		//    summary:
		//        This function has to be overriden by subclasses, and used to return the default event map for the Interactor
		//
		return {};
	},

	reactivate: function () {
		//
		// summary:
		//        release all the handles and reconnect.
		//
		this.deactivate();
		this.activate();
	},

	_basicBuildInputFilter: function(key,value) {
		if(value===undefined)
			R.error("InvalidInputFilterSpec",key);
		switch(key) {
		case "condition":
			return value;
		case "button":
			switch(value) {
			case 0:
				return this.eventButtonIsLeft;
			case 1:
				return this.eventButtonIsRight;
			case 2:
				return this.eventButtonIsMiddle;
			default:
				R.error("InvalidInputFilterSpec",key);
			}
		case "alt":
			return function(e) {
				return e.altKey === value;
			};
		case "ctrl":
			return function(e) {
				return e.ctrlKey === value;
			};
		case "shift":
			return function(e) {
				return e.shiftKey === value;
			};
		case "disabled":
			return function(e) {
				return false;
			};
		default:
			R.error("InvalidInputFilterSpec",key);
		}
	},
	
	_buildInputFilter: function(spec) {
		var filter = null;
		for(s in spec) {
			var newFilter = this._basicBuildInputFilter(s,spec[s]);  
			if(spec.hasOwnProperty(s)) {
				if(filter) {
					(function(oldFilter,newFilter) { // fresh scope
						filter = function(e) {
							return oldFilter(e) && newFilter(e);
						};
					})(filter,newFilter);
				} else {
					filter = newFilter;
				}
			}
		};
		return filter;
	},
	
	_assignEventInput: function(id,spec) {
		if('filter' in spec){
			this._connections[id].filter = this._buildInputFilter(spec.filter);
		}
		if('hotKey' in spec){
			this._connections[id].hotKey = spec.hotKey;
		}
	},	
	
	assignInputs: function(assignments) {
		for(id in assignments) {
			if(this._connections.hasOwnProperty(id)) {
				this._assignEventInput(id,assignments[id]);
			} else {
				R.error("InvalidInteractorEvent",id);
			}
		}
		this.initializeFilters();
		this.registerHotKeys();
		if (this._state !== null) {
			this.reactivate();
		}
	},
	
	_applyFilter: function (scope, handlerName, filter) {
		//
		// summary:
		//        if the filter function return true, calls the internal handler given as parameter
		// methodName:
		//        the handler to be called
		// filter:
		//         the filter function to be evaluated
		//
		var thiz = this;
		if (filter) {
			return function (e) {
				if (thiz._enabled && filter(e)) {
					scope[handlerName](e);
					return true;
				}
				return false;
			};
		} else {
			return function (e) {
				if (thiz._enabled) {
					scope[handlerName].apply(scope, arguments);
					return true;
				}
				return false;
			};
		}
	},

	_getGraphElementFromEventInRoot: function (event, root) {
		// Summary:
		//        Returns the GraphElement (i.e. Node or Link) containing the target of the specified event. 
		// event:
		//        The event.
		// root:
		//        The root GFX shape containing the graph elements.
		
		var gfxTarget = event.gfxTarget;
		if (gfxTarget) {
			// We are using a Dojo that adds a gfxTarget field to the event (Dojo 1.6+):
			// use this and look upwards to find the GraphElement.
			var ge = gfxTarget; // a GFX shape
			if (Selectable.Util.isSelectableInstance(ge)) {
				return ge;
			}
			if (!ge.getParent) 
				return null;
			for (var elem = ge.getParent(); elem && elem.getParent; elem = elem.getParent()) {
				if (Selectable.Util.isSelectableInstance(elem)) {
					return elem;
				}
				if (elem === root) 
					break;
			}
		}
		else {
			// We are using an older Dojo: use the old method, that is, search recursively
			// top-to-bottom from the root to find the GFX shape whose event source (= HTML node)
			// is the event target. This does not work for Canvas, so for Canvas we must be in
			// the case above (which means Canvas is not support for "old" Dojo versions).
			return this._getGraphElementFromHtml(event.target, root);
		}
		return null;
	},

	_getGraphElementFromHtml: function(html, root) {
		// Summary:
		//        Returns the GraphElement (i.e. Node or Link) containing the specified (HTML) event target.
		// html: Node
		//        The event target (an HTML node).
		// root:
		//        The root GFX shape containing the graph elements.
		
		// fix for touch event
		// on iOS the event target on a gfx text is a TextNode no the SVGText
		if (!iid.isSilverlight && html.nodeType == 3) 
			html = html.parentNode;
		
		if (gfx.equalSources(root.getEventSource(), html)) {
			return root;
		} else {
			if (root['children']) {
				for (var index in root.children) {
					var ge = this._getGraphElementFromHtml(html, root.children[index]);
					if (ge) {
						if (Selectable.Util.isSelectableInstance(ge)) {
							return ge;
						}
						else {
							return root;
						}
					}
				}
			}
		}
		
		return null;
	},

	__eod: undefined
});

//////////////////////////////////////////////////////////////////////////////
//
//    DOM Events Helper Functions
//
// dojo 1.4 has this already, but we need to support 1.3.2
if (has("ie") < 9) {
	if(gfx.renderer == 'vml') {
		lang.extend(Interactor, {
			eventButtonIsLeft: function (e) {
				return e.button & 1;
			}, eventButtonIsMiddle: function (e) {
				return e.button & 4;
			}, eventButtonIsRight: function (e) {
				return e.button & 2;
			}
		});
	} else {
		if(gfx.renderer == 'silverlight') {
			lang.extend(Interactor, {
				eventButtonIsLeft: function (e) {
					return true;
				}, eventButtonIsMiddle: function (e) {
					return false;
				}, eventButtonIsRight: function (e) {
					return false;
				}
			});
		}
	}
} else {
	lang.extend(Interactor, {
		eventButtonIsLeft: function (e) {
			return e.button == 0;
		}, eventButtonIsMiddle: function (e) {
			return e.button == 1;
		}, eventButtonIsRight: function (e) {
			return e.button == 2;
		}
	});
}

if (has("mozilla")) {
	lang.extend(Interactor, {
		eventNameWheel: "DOMMouseScroll",
		eventWheelAmmount: function (e) {
			return -e.detail;
		}
	});
} else {
	lang.extend(Interactor, {
		eventNameWheel: "onmousewheel",
		eventWheelAmmount: function (e) {
			return e.wheelDelta;
		}
	});
}

lang.extend(Interactor, {
	eventPageLocation: function (e) {
		//
		//    summary:
		//        returns pointer position associated with the given event
		//
		return {
			x: e.pageX,
			y: e.pageY
		};
	}, eventClientLocation: function (e) {
		//
		//    summary:
		//        returns pointer position associated with the given event
		//
		var r = dojex.coords(e.currentTarget);
		return {
			x: e.clientX - r.x,
			y: e.clientY - r.y
		};
	}
});

return Interactor;

});