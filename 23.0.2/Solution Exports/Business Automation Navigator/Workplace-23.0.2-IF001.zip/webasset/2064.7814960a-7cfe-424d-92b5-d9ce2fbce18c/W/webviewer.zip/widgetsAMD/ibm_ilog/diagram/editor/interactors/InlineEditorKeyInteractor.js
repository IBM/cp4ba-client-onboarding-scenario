/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/array",
"dojo/_base/lang",
"dojo/keys",
"../../interactors/Interactor",
"../../util/GraphUtil"
], function(
declare,
array,
lang,
keys,
Interactor,
gu
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var InlineEditorKeyInteractor =
declare("ibm_ilog.diagram.editor.interactors.InlineEditorKeyInteractor", [Interactor], {
	//summary:
	//		This interactor edit the first editable label through the keyboard interaction.
	//		This interactor has 1 connection: editInlineText.
	
	_diagram: null,
	initialize: function (diagram) {
	// summary:
    //		initialize the new instance.
    // diagram: ibm_ilog.diagram.widget.Diagram
    //		the associated diagram.			
		this._diagram = diagram;
		return this._initialize();
	},
	editInlineText: function(e){
		// summary:
		//		opens the inline editor of the first editable label of the focused graph element
		var ge = this._diagram.getFocusedElement();
		if(ge && !ge._isIBMDiagramLink){	
			var es = this._diagram.getEditables(ge);
			if(es && es.length) {
				// open the first visible editable
				array.some(es, lang.hitch(this, function(ed){
					if (gu.getSurface(ed.base)) {
						this._diagram.openEditableInlineEditor(ed);
						return true;
					}
				}));
			}
		}
	},
	getKeyInteractorId: function(){
		// summary:
	    //		returns the Interactor Id
		
		return InlineEditorKeyInteractor.KeyInteractorId;
	},
	getDefaultConnections: function () {
		// summary:
		//		returns the default event mapping
		
		return {
			editInlineText: {
				hotKey: keys.F2,
				connectTo: "editInlineText"
			}
		};
	},
	
	__eod: undefined
});

InlineEditorKeyInteractor.KeyInteractorId = "InlineEditor";

return InlineEditorKeyInteractor;

});
