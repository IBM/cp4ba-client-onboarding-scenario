/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/lang", "dojo/_base/declare", "./Layout"],
function(lang, declare, Layout){

/*=====
var Layout = ibm_ilog.diagram.gfxlayout.Layout;
=====*/

var GridLayout =
declare('ibm_ilog.diagram.gfxlayout.GridLayout', Layout, {
    // summary:
    //      A layout class that arranges children of a container as a grid.
    // description:
    //      The GridLayout class arranges children of a container as grid elements.
    //      <p>The grid structure is defined by the 'rows' and 'cols' constructor parameters. 
    //      These properties are arrays of descriptor objects that defined how the column or row
    //      size is computed. These descriptor objects support the following properties:
    //      'width': if the container width (resp. height) is not fixed, then the column width (resp. row height)
    //      depends on the value of this property. A value of -1 means the dimension will accomodate to the maximum
    //      children dimension. Any other positive number sets the column width (resp. row height).
    //      'weight': if the container width (resp. height) is fixed, this property defines how the space 
    //      remaining after all the fixed width's (resp. height's) have been substracted from the 
    //      container width (resp. height) is distributed accross the columns (resp. the rows).
    //      <p>
    //      The GridLayout class defines the paddingLeft, paddingRight, paddingTop and paddingBottom properties
    //      to specificy the internal margins of the panel from which the children are positionned. A convenient global padding
    //      property is also defined to set the same padding in all directions.
    //      <p>Children in the grid are placed into the grid cells according to the 'column' and 'row' properties of the children. 
    //      When these properties are not specified on a shape, the shape is automatically placed in the grid according
    //      to its order in the container children list. The direction of the placement flow is defined via the 'horizontalFlow'
    //      property, which is 'true' by default. For example, assuming the 'horizontalFlow' property is set to 'true' the children
    //      do not defined any specific row/col index, the first child will be placed at the (0,0) cell, the 2nd one at the (1,0) cell, and so on.
    //      <p>
    //      A child can span over multiple rows or columns depending on their 'colspan' or 'rowspan' properties. These properties indicates
    //      the number of columns or rows the child must overlap. A value of '-1' means the child should span over all the remaining columns or rows.
    //      <p>
    //      Children are arranged within the computed grid cell according to their 'valign' 
    //      (one of the 'top', 'center', 'bottom' and 'stretch' values), 'halign' (one of the 'left', 'center', 'right' and 'stretch' values) 
    //      and their 'margins' properties.
    
    // the rows and columns descriptor
    rows: null,
    cols: null,
    // padding
    padding: 0,
    paddingLeft: 0,
    paddingRight: 0,
    paddingTop: 0,
    paddingBottom: 0,
    
    horizontalFlow: true,
    
    constructor: function(args) {
        this.rows = this.rows || [];
        this.cols = this.cols || [];
        if (this.rows.length === 0) 
            this.rows[0] = {
                weight: 1,
                height: -1
            };
        if (this.cols.length === 0) 
            this.cols[0] = {
                weight: 1,
                width: -1
            };
        if (args && 'padding' in args) 
            this._setPadding(args.padding, false);
    },
	
	getConfig : function() {
		// summary:
		// 		Gets the current configuration of this layout instance.
		// Description:
		//		This method returns a descriptor of this layout current configuration
		//		as well as the type information so that it can be passed to the Group.setLayout() method
		//		(for example to make a copy the layout of a Group). 
		// returns: Object
		//	An object that represents the layout current configuration.
		var arg ={};
		arg.type = 'ibm_ilog.diagram.gfxlayout.GridLayout';
		if (this.padding)
			arg.padding = this.padding;
		else {
			arg.paddingLeft = this.paddingLeft;
			arg.paddingRight = this.paddingRight;
			arg.paddingTop = this.paddingTop;
			arg.paddingBottom = this.paddingBottom;
		}
		arg.rows = lang.clone(this.rows);
		arg.cols = lang.clone(this.cols);
		arg.horizontalFlow = this.horizontalFlow;
		return arg;	/*Object*/	
	},
    
    setHorizontalFlow: function(/*Boolean*/value) {
        // summary:
        //     Sets whether children with no specified 'row' or 'column' properties
        //     are arranged horizontally or vertically in the grid. 
        //  value: Boolean: the automatic flow direction. 
        
        if (value !== this.horizontalFlow) {
            var old = this.horizontalFlow;
            this.horizontalFlow = value;
            this.onLayoutPropertyChanged('horizontalFlow', old, value);
        }
    },
	
	getHorizontalFlow:function(){ 
		return this.horizontalFlow; 
	},
    
    setPadding: function(value) {
        // summary:
        //     Sets the padding of this layout.
        // description:
        //     This property is used to set the internal margins of this layout.
        //     The value can either be a 4-elements array whose items match
        //     respectively the left, top, right and bottom paddings ; or one integer
        //     that is applied to all paddings.
        this._setPadding(value, true);
    },
    _setPadding: function(value, notify) {
        if (value instanceof Array) {
            var l = value.length, oldL = this.paddingLeft, oldR = this.paddingRight, oldT = this.paddingTop, oldB = this.paddingBottom;
            if (l > 0) 
                this.paddingLeft = value[0];
            if (l > 1) 
                this.paddingTop = value[1];
            if (l > 2) 
                this.paddingRight = value[2];
            if (l > 3) 
                this.paddingBottom = value[3];
            if (notify &&
            (this.paddlingLeft !== oldL ||
            this.paddingTop !== oldT ||
            this.paddingBottom !== oldB ||
            this.paddingRight !== oldR)) {
            
                this.onLayoutPropertyChanged();
            }
        } else {
            var old = this.padding;
            this.padding = this.paddingLeft = this.paddingRight = this.paddingBottom = this.paddingTop = value;
            if (notify && (value !== old)) {
                this.onLayoutPropertyChanged();
            }
        }
    },
    
    adjustBBox: function(/*dojox.gfx.Rectangle*/bbox) {
        // summary:
        //     Returns the container bbox adjusted according to the constraints of this layout.
        // bbox: Rectangle: the bounding box of the associated container.
        
        bbox.x -= this.paddingLeft;
        bbox.y -= this.paddingTop;
        bbox.width += this.paddingLeft + this.paddingRight;
        bbox.height += this.paddingTop + this.paddingBottom;
        return bbox;
    },
    
    _getColIdx: function(shape, shapeIdx) {
        var c = 0;
        if ('column' in shape) 
            c = shape.column;
        else if (this.horizontalFlow) 
            c = shapeIdx % this.cols.length;
        else 
            c = Math.floor(shapeIdx / this.rows.length);
        return Math.min(c, this.cols.length - 1);
    },
    
    _getRowIdx: function(shape, shapeIdx) {
        var r = 0;
        if ('row' in shape) 
            r = shape.row;
        else if (this.horizontalFlow) 
            r = Math.floor(shapeIdx / this.cols.length);
        else 
            r = shapeIdx % this.rows.length;
        return Math.min(r, this.rows.length - 1);
    },
    
    _getRowDesc: function(rowIdx) {
        return rowIdx < this.rows.length ? this.rows[rowIdx] : null;
    },
    
    _getColDesc: function(colIdx) {
        return colIdx < this.cols.length ? this.cols[colIdx] : null;
    },
    
    computePreferredSize: function(proposedSize) {
    
        var children = this._container.children, count = children.length, i = 0, r = 0, c = 0, sh, sb, rDesc, cDesc, rm, cm;
        var rowsMetric = [], colsMetric = [];
        
        for (i = 0; i < this.rows.length; ++i) {
            rDesc = this.rows[i];
            rm = {};
            rm.height = 0;
            if ('height' in rDesc && rDesc.height !== -1) 
                rm.height = rDesc.height;
            rowsMetric.push(rm);
        }
        for (i = 0; i < this.cols.length; ++i) {
            cDesc = this.cols[i];
            cm = {};
            cm.width = 0;
            if ('width' in cDesc && cDesc.width !== -1) {
                cm.width = cDesc.width;
            }
            colsMetric.push(cm);
        }
        
        /*
         var totalFixedW = 0, totalWeightW = 0, totalFixedH = 0, totalWeightH = 0;
         
         for (i = 0; i < this.rows.length; ++i) {
         rDesc = this.rows[i];
         rm = {};
         rm.count = 0;
         rm.weight = -1;
         if ('weight' in rDesc) {
         var weight = rDesc.weight;
         rm.weight = weight;
         totalWeightH += weight;
         }
         rm.height = -1;
         if ('height' in rDesc && rDesc.height !== -1)
         rm.height = rDesc.height;
         rowsMetric.push(rm);
         }
         for (i = 0; i < this.cols.length; ++i) {
         cDesc = this.cols[i];
         cm = {};
         cm.count = 0;
         cm.weight = -1;
         if ('weight' in cDesc) {
         var weight = cDesc.weight;
         cm.weight = weight;
         totalWeightW += weight;
         }
         cm.width = -1;
         if ('width' in cDesc && cDesc.width !== -1) {
         cm.width = cDesc.width;
         }
         colsMetric.push(cm);
         }
         */
        for (i = 0; i < count; ++i) {
            sh = children[i];
            c = this._getColIdx(sh, i);
            r = this._getRowIdx(sh, i);
            // get the corresponding column/row descriptors
            rDesc = this.rows[r];
            cDesc = this.cols[c];
            var sz = {};
            sz.width = ('width' in cDesc && cDesc.width !== -1) ? cDesc.width : -1;
            sz.height = ('height' in rDesc && rDesc.height !== -1) ? rDesc.height : -1;
            sb = sh.computePreferredSize(sz);
			// take into account the shape width only if it is not an horizontal filler
			if (!sh.hfiller && 'width' in cDesc) {
                // if column width not set, set to the maximum preferred width
                if (cDesc.width === -1) {
                    var w = sb.width;
                    if (sh.margins) {
                        w = this._inflateH(w, sh.margins);
                    }
                    if (w > colsMetric[c].width) 
                        colsMetric[c].width = w;
                } else {
                    colsMetric[c].width = cDesc.width;
                }
            }
			// take into account the shape height only if it is not a vertical filler
            if (!sh.vfiller && 'height' in rDesc) {
                // if not fixed height, get the maximum preferred height 
                if (rDesc.height === -1) {
                    var h = sb.height;
                    if (sh.margins) {
                        h = this._inflateV(h, sh.margins);
                    }
                    if (h > rowsMetric[r].height) 
                        rowsMetric[r].height = h;
                } else {
                    rowsMetric[r].height = rDesc.height;
                }
            }
        }
        
        /*
         for (i = 0; i < count; ++i) {
         sh = children[i];
         c = this._getColIdx(sh, i);
         r = this._getRowIdx(sh, i);
         // get the corresponding column/row metrics
         rm = rowsMetric[r];
         cm = colsMetric[c];
         rDesc = this.rows[r];
         cDesc = this.cols[c];
         ++cm.count;
         ++rm.count;
         var sz = {};
         sz.width = ('width' in cDesc && cDesc.width !== -1) ? cDesc.width : -1;
         sz.height = ('height' in rDesc && rDesc.height !== -1) ? rDesc.height : -1;
         sb = sh.computePreferredSize(sz);
         // if column width not set, set to the maximum preferred width
         // (except if a weight has been specified, in this case the width
         // will be computed later when the total fixed width will be known
         if (this.cols[c].width === -1 && cm.weight === -1) {
         var w = sb.width;
         if (sh.margins)
         w = this._inflateH(w, sh.margins);
         if (w > cm.width)
         cm.width = w;
         }
         // if not fixed height, get the maximum preferred height
         if (this.rows[r].height === -1 && rm.weight === -1) {
         var h = sb.height;
         if (sh.margins)
         h = this._inflateV(h, sh.margins);
         if (h > rm.height)
         rm.height = h;
         }
         }
         // here, we have all fixed size computing done.
         // now we can compute the 'weighted' sizes
         if (totalWeightW > 0) {
         // Compute columns width
         for (i = 0; i < colsMetric.length; ++i) {
         cm = colsMetric[i];
         // if a width has been computed previously for this column, sum it
         if (cm.width !== -1) {
         totalFixedW += cm.width;
         } else { // width not set yet, and column not empty
         if (cm.weight === -1 && cm.count > 0) {
         cm.weight = 1;
         ++totalWeightW;
         } else if (cm.weight !== -1 && cm.count === 0) {
         // the column is empty, should not be included in the total
         --totalWeightW;
         }
         }
         }
         var remainingW = Math.max(0, contBounds.width - totalFixedW);
         // then compute the 'weighted' width
         if (totalWeightW > 0) {
         var unitW = remainingW / totalWeightW;
         for (i = 0; i < colsMetric.length; ++i) {
         cm = colsMetric[i];
         if (cm.width === -1 && cm.count > 0) {
         cDesc = this.cols[i];
         var weight = cDesc.weight || 1;
         cm.width = cm.weight * unitW;
         }
         }
         }
         }
         if (totalWeightH > 0) {
         
         for (i = 0; i < rowsMetric.length; ++i) {
         rm = rowsMetric[i];
         // if a height has been computed previously for this row, sum it
         if (rm.height !== -1) {
         totalFixedH += rm.height;
         } else {
         if (rm.weight === -1) {
         rm.weight = 1;
         totalWeightH += 1;
         }
         }
         }
         var remainingH = Math.max(0, contBounds.height - totalFixedH);
         if (totalWeightH > 0) {
         var unitH = remainingH / totalWeightH;
         for (i = 0; i < rowsMetric.length; ++i) {
         rm = rowsMetric[i];
         if (rm.height === -1) {
         rDesc = this.rows[i];
         var weight = rDesc.weight || 1;
         rm.height = rm.weight * unitH;
         }
         }
         }
         }
         if (totalWeightH > 0 || totalWeightW > 0) {
         for (i = 0; i < count; ++i) {
         sh = children[i];
         c = this._getColIdx(sh, i);
         r = this._getRowIdx(sh, i);
         // get the corresponding column/row metrics
         rm = rowsMetric[r];
         cm = colsMetric[c];
         var sz = {
         width: cm.width,
         height: rm.height
         };
         sb = sh.getPreferredSize(sz);
         
         }
         }
         */
        var sz = {
            width: 0,
            height: 0
        };
        if (proposedSize.width === -1) {
        
            for (i = 0; i < colsMetric.length; ++i) 
                sz.width += colsMetric[i].width;
        } else {
            sz.width = proposedSize.width;
        }
        if (proposedSize.height === -1) {
            for (i = 0; i < rowsMetric.length; ++i) 
                sz.height += rowsMetric[i].height;
        } else {
            sz.height = proposedSize.height;
        }
        sz.width += this.paddingLeft + this.paddingRight;
        sz.height += this.paddingTop + this.paddingBottom;
        
        return sz;
        
    },
    
    layoutChildren: function(contBounds) {
    
        contBounds = lang.clone(contBounds);
        var children = this._container.children, count = children.length, i = 0, r = 0, c = 0, sh, sb, rDesc, cDesc, cm, rm;
        var rowsMetric = [], colsMetric = [];
        var totalFixedW = 0, totalWeightW = 0, totalFixedH = 0, totalWeightH = 0;
        
        for (i = 0; i < this.rows.length; ++i) {
            rDesc = this.rows[i];
            rm = {};
            rm.count = 0;
            rm.weight = -1;
            if ('weight' in rDesc) {
                var weight = rDesc.weight;
                rm.weight = weight;
                totalWeightH += weight;
            }
            rm.height = -1;
            if ('height' in rDesc && rDesc.height !== -1) 
                rm.height = rDesc.height;
            rowsMetric.push(rm);
        }
        for (i = 0; i < this.cols.length; ++i) {
            cDesc = this.cols[i];
            cm = {};
            cm.count = 0;
            cm.weight = -1;
            if ('weight' in cDesc) {
                var weight = cDesc.weight;
                cm.weight = weight;
                totalWeightW += weight;
            }
            cm.width = -1;
            if ('width' in cDesc && cDesc.width !== -1) {
                cm.width = cDesc.width;
            }
            colsMetric.push(cm);
        }
        
        contBounds.width = Math.max(0, contBounds.width - this.paddingLeft - this.paddingRight);
        contBounds.height = Math.max(0, contBounds.height - this.paddingTop - this.paddingBottom);
        for (i = 0; i < count; ++i) {
            sh = children[i];
            sb = sh.getPreferredSize();
            c = this._getColIdx(sh, i);
            r = this._getRowIdx(sh, i);
            // get the corresponding column/row metrics
            rm = rowsMetric[r];
            cm = colsMetric[c];
            ++cm.count;
            ++rm.count;
            // if column width not set, set to the maximum preferred width
            // (except if a weight has been specified, in this case the width
            // will be computed later when the total fixed width will be known
            if (this.cols[c].width === -1 && cm.weight === -1) {
                var w = sb.width;
                if (sh.margins) 
                    w = this._inflateH(w, sh.margins);
                if (w > cm.width) 
                    cm.width = w;
            }
            // if not fixed height, get the maximum preferred height 
            if (this.rows[r].height === -1 && rm.weight === -1) {
                var h = sb.height;
                if (sh.margins) 
                    h = this._inflateV(h, sh.margins);
                if (h > rm.height) 
                    rm.height = h;
            }
        }
        // Compute columns width
        for (i = 0; i < colsMetric.length; ++i) {
            cm = colsMetric[i];
            // if a width has been computed previously for this column, sum it
            if (cm.width !== -1) {
                totalFixedW += cm.width;
            } else { // width not set yet, and column not empty
                if (cm.weight === -1 && cm.count > 0) {
                    cm.weight = 1;
                    ++totalWeightW;
                } else if (cm.weight !== -1 && cm.count === 0) {
                    // the column is empty, should not be included in the total
                    --totalWeightW;
                }
            }
        }
        var remainingW = Math.max(0, contBounds.width - totalFixedW);
        // then compute the 'weighted' width
        if (totalWeightW > 0) {
            var unitW = remainingW / totalWeightW;
            for (i = 0; i < colsMetric.length; ++i) {
                cm = colsMetric[i];
                if (cm.width === -1 && cm.count > 0) {
                    cDesc = this.cols[i];
                    var weight = cDesc.weight || 1;
                    cm.width = cm.weight * unitW;
                }
            }
        }
        
        for (i = 0; i < rowsMetric.length; ++i) {
            rm = rowsMetric[i];
            // if a height has been computed previously for this row, sum it
            if (rm.height !== -1) {
                totalFixedH += rm.height;
            } else {
                if (rm.weight === -1) {
                    rm.weight = 1;
                    totalWeightH += 1;
                }
            }
        }
        var remainingH = Math.max(0, contBounds.height - totalFixedH);
        if (totalWeightH > 0) {
            var unitH = remainingH / totalWeightH;
            for (i = 0; i < rowsMetric.length; ++i) {
                rm = rowsMetric[i];
                if (rm.height === -1) {
                    rDesc = this.rows[i];
                    var weight = rDesc.weight || 1;
                    rm.height = rm.weight * unitH;
                }
            }
        }
        // compute cell coord
        var currentX = /*contBounds.x + */ this.paddingLeft;
        for (i = 0; i < colsMetric.length; ++i) {
            cm = colsMetric[i];
            cm.x = currentX;
            currentX += cm.width;
        }
        var currentY = /*contBounds.y + */ this.paddingTop;
        for (i = 0; i < rowsMetric.length; ++i) {
            rm = rowsMetric[i];
            rm.y = currentY;
            currentY += rm.height;
        }
        // arrange children
        for (i = 0; i < count; ++i) {
            var slotBounds = {}, sh = children[i];
            c = this._getColIdx(sh, i);
            r = this._getRowIdx(sh, i);
            cm = colsMetric[c];
            rm = rowsMetric[r];
            slotBounds.x = cm.x;
            slotBounds.width = cm.width;
            slotBounds.y = rm.y;
            slotBounds.height = rm.height;
            // span
            var span = sh.colspan;
            if (span) {
                this._spanSlot(span, c, slotBounds, 'width', colsMetric);
            }
            span = sh.rowspan;
            if (span) {
                this._spanSlot(span, r, slotBounds, 'height', rowsMetric);
            }
            this.placeChildInSlot(sh, slotBounds, true, true);
        }
    },
    
    _spanSlot: function(span, dimIdx, slotBounds, dim, dimMetric) {
        if (span === -1) 
            span = dimMetric.length - dimIdx;
        if (span > 1) {
            var end = dimIdx + span;
            for (++dimIdx; dimIdx < end; ++dimIdx) {
                if (dimIdx < dimMetric.length) {
                    var dm = dimMetric[dimIdx];
                    slotBounds[dim] += dm[dim];
                }
            }
        }
        return slotBounds;
    }
});

return GridLayout;

});
