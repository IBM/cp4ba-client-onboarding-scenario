define({      
//begin v1.x content
    errorDialogTitle: "IBM BPM 错误",
    moreDetails: "更多详细信息...",
    closeMessage: "关闭所有错误消息",
    contentMessage: "发生错误。"
//end v1.x content
});

