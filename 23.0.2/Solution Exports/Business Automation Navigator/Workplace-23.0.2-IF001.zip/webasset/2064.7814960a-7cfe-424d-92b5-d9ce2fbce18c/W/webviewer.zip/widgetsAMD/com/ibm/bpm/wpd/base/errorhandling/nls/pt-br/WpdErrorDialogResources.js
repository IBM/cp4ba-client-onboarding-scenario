define({      
//begin v1.x content
    errorDialogTitle: "Erro do IBM BPM",
    moreDetails: "Mais Detalhes...",
    closeMessage: "Fechar Todas as Mensagens de Erro",
    contentMessage: "Ocorreu um erro."
//end v1.x content
});

