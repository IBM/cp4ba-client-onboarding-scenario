define({      
//begin v1.x content
    errorDialogTitle: "IBM BPM-Fehler",
    moreDetails: "Weitere Details...",
    closeMessage: "Alle Fehlernachrichten schließen",
    contentMessage: "Ein Fehler ist aufgetreten."
//end v1.x content
});

