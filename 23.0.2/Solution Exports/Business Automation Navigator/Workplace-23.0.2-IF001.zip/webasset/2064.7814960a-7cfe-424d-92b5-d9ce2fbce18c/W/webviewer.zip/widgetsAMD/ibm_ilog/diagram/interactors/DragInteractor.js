/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"../main",
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/event",
"dojox/gfx/matrix",
"./Interactor",
"../util/Geometry"
],
function(
iid,
declare,
lang,
event,
m,
Interactor,
g
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var DragInteractor =
declare("ibm_ilog.diagram.interactors.DragInteractor", [Interactor], {

	//
	//	_viewport: ibm_ilog.diagram.widget.Diagram
	//		The viewport where the drag occurs
	//
	_viewport: null,

	//
	//	hasDragged: Boolean
	//		true if last drag start was followed by a move
	//
	hasDragged: false,

	//
	//	_transform: [dojox.gfx.matrix.Matrix2D]
	//		Transform used to transform UI coordinate system into moveable object's system
	//
	_transform: null,

	//
	//	_last: 
	//		Last event coordinate
	//		
	_last: null, 

	//
	//	_first: 
	//		The event coordinate at which the drag started
	//		
	_first: null,

	//
	//	_firstViewportT:
	//		The viewport transform at the point where _first was defined or updated.
	//
	_firstViewportT: null,
		
	//
	//	_current: 
	//		Current event coordinate
	//		
	_current: null,
	
	//
	//	_delta: 
	//		The difference between _current and _last
	//		
	_delta: null,
	
	//
	//	_dragCursor: 
	//		Optional cursor ID set while dragging
	//		
	_dragCursor: null,
	
	//
	//	_cursorDom: 
	//		The DOM style that controls the cursor we will update
	//		
	_cursorStyle: null,

	
	_declareStates: function () {
		var idleStates = ["start"];
		if (iid.mobileEnabled)
			idleStates.push("touchStart");
		this._declareState("idle", idleStates);
		this._declareState("active", ["first", "move", "end", "cancelOnDragStart", "cancelOnSelectStart"]);
		if (iid.mobileEnabled)
			this._declareState("activeTouch", ["touchFirst","touchMove","touchEnd"]);
	},

	_initialize: function () {
		if (!this._viewport) {
			this._getEventCoord = this.__getEventCoordNoViewport;
			this._cursorStyle = this._cursorStyle || document.body.style;
		} else {
			this._cursorStyle = this._cursorStyle || this._viewport.getDiagram().domNode.style;
		}
		this._last = g.Point(0, 0);
		this._first = this._last;
		this._current = this._last;
		this.inherited(arguments);

	},

	initialize: function ( /*ibm_ilog.diagram.widget.Diagram*/ diagram) {
		if (diagram._isIBMDiagramDiagram) {
			this._viewport = diagram.getViewport();
		} else if (diagram._isIBMDiagramViewport) {
			this._viewport = diagram;
		}
		this._initialize();
		return this;
	},

	_getInitialEventSource: function () {
		return this._viewport.getEventSource();
	},

	getDefaultConnections: function () {
		//
		//	summary:
		//		returns the default event mapping
		//
		var defaultConnections = {
			start: {
				src: this._getInitialEventSource(),
				srcEvt: "onmousedown",
				connectTo: "_dragPreStart",
				filter: this._buildInputFilter({button:0,ctrl:false,shift:false}),
				gfxConnect: true
			}, first: {
				src: document,
				srcEvt: "onmousemove",
				connectTo: "_dragFirstMove"
			}, move: {
				src: document,
				srcEvt: "onmousemove",
				connectTo: "_dragMove"
			}, end: {
				src: document,
				srcEvt: "onmouseup",
				connectTo: "_dragEnd"
			}, cancelOnDragStart: {
				src: document,
				srcEvt: "ondragstart",
				target: dojo,
				connectTo: "stopEvent"
			}, cancelOnSelectStart: {
				src: document,
				srcEvt: "onselectstart",
				target: dojo,
				connectTo: "stopEvent"
			}
		};
		if (iid.mobileEnabled){
			var mobileDefaultConnections = {
				touchStart : {
					src: this._getInitialEventSource(),
					srcEvt: "ontouchstart",
					connectTo: "_dragTouchPreStart",
					gfxConnect: true
				}, touchFirst: {
					src: document,
					srcEvt: "ontouchmove",
					connectTo: "_dragTouchFirstMove"
				},  touchMove : {
					src: document,
					srcEvt: "ontouchmove",
					connectTo: "_dragTouchMove"
				}, touchEnd : {
					src: document,
					srcEvt: "ontouchend",
					connectTo: "_dragTouchEnd"
				}
			};
			lang.mixin(defaultConnections,mobileDefaultConnections);
		};
		return defaultConnections;
	},

	activate: function () {
		//
		//	summary:
		//		Activates the receiver by connecting it to its sources of events.
		//
		this._goStateId("idle");
		this.inherited(arguments);
	},

	_dragPreStart: function (e) {
		//
		//	summary:
		//		Starts the drag process by storing initial coordinates for pointer and view rectangle
		//
		if (this._state._id !== "idle") console.warn("Unexpected active dragging.");

		if (dojox.gfx.renderer !== "silverlight")
			event.fix(e);
		
		this._goStateId("active");
		this._startDragGesture(e);
		this._updateCursor();
	},

	_startDragGesture: function(e){
		this._firstViewportT = this._viewport ? this._viewport.getViewportInverseTransform() : null;
		this._last = this._getEventCoord(e);
		this._first = this._last;
		this._current = this._last;
		this._delta = {
			x: 0,
			y: 0
		};
		this._totalDelta = this._delta;
		
	},

	_showDragCursor: function() {
		if(this._dragCursor && this._cursorStyle && this._cursorBackup == null) {
			this._cursorBackup = this._cursorStyle.cursor;
			this._cursorStyle.cursor = this._dragCursor;
		}
	},

	_hideDragCursor: function() {
		if(this._cursorBackup!==null) {
			if (this._cursorStyle)
				this._cursorStyle.cursor = this._cursorBackup;
			this._cursorBackup = null;
		}
	},
	
	_updateCursor:function() {
		if(this._state._id=="active") {
			this._showDragCursor();
		} else {
			this._hideDragCursor();
		}
	},
	
	_dragFirstMove: function (e) {
		if (this._manager) {
			this._activationHandle = this._manager.push(this);
		}
		this._disconnect("first");
		this.hasDragged = true;
	},

	_dragMove: function (e) {
		if (dojox.gfx.renderer !== "silverlight")
			event.fix(e);
		this._dragGesture(e);
	},

	_dragGesture: function (e){
		this._last = this._current;
		this._current = this._getEventCoord(e);
		this._delta = {
			x: this._current.x - this._last.x,
			y: this._current.y - this._last.y
		};
		this._totalDelta = {
			x: this._current.x - this._first.x,
			y: this._current.y - this._first.y
		};
		
	},
	_dragEnd: function (e) {
		if (dojox.gfx.renderer !== "silverlight")
			event.fix(e);

		if (this._activationHandle) {
			this._manager.pop(this._activationHandle);
			this._activationHandle = null;
		}
		this._goState(null);

		this.hasDragged = false;
		this._goStateId("idle");
		
		this._updateCursor();
	},

	_getEventCoord: function (e) {
		var pl = this._viewport.eventClientLocation(e);
		if (this._transform) {
			pl = m.multiplyPoint(this._transform, pl);
		}
		return pl;
	},

	__getEventCoordNoViewport: function (e) {
		var pl = this.eventPageLocation(e);
		if (this._transform) {
			pl = m.multiplyPoint(this._transform, pl);
		}
		return pl;
	},
	_dragTouchPreStart: function (e) {
		if (dojox.gfx.renderer !== "silverlight")
			event.fix(e);
		e.preventDefault();		
		//
		//	summary:
		//		Starts the drag process by storing initial coordinates for pointer and view rectangle
		//
		if (this._state._id !== "idle") console.warn("Unexpected active dragging.");

		
		this._goStateId("activeTouch");
		this._startDragGesture(e);
		this._updateCursor();
	},	
	
	_dragTouchFirstMove: function (e) {
		if (dojox.gfx.renderer !== "silverlight")
			event.fix(e);
		e.preventDefault();		
		
		this._disconnect("touchFirst");
		this.hasDragged = true;
	},

	_dragTouchMove: function (e) {
		if (dojox.gfx.renderer !== "silverlight")
			event.fix(e);
		e.preventDefault();		
		// if more than one finger don't do anything
		if (e.touches.length > 1){
			return false;
		}
		
		this._dragGesture(e);
		
	},	
	_dragTouchEnd: function (e) {
		if (dojox.gfx.renderer !== "silverlight")
			event.fix(e);
		if (e.touches.length > 0){
			// one finger left, restart the gesture
			this._startDragGesture(e);
			return false;
		}
		if (this._activationHandle) {
			this._manager.pop(this._activationHandle);
			this._activationHandle = null;
		}
		this._goState(null);

		this.hasDragged = false;
		this._goStateId("idle");
		
		this._updateCursor();

		
	}	


});

return DragInteractor;

});