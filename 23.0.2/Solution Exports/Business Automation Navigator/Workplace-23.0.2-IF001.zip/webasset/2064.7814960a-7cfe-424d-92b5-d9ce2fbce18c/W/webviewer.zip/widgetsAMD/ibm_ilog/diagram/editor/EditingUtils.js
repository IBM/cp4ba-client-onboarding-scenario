/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/lang",
"dojo/_base/array",
"dojox/gfx",
"dojox/gfx/utils",
"dojox/gfx/matrix",
"dojox/collections/ArrayList",
"dojox/collections/Set",
"../base",
"./undo/GroupAction",
"./undo/UngroupAction",
"./undo/SimpleAction",
"./undo/MultipleAction",
"./undo/DeleteAction",
"./undo/ReorderAction",
"./undo/UndoActionList",
"./undo/ChangeLinkIntermediatePointsAction",
"./undo/InvertLinkAction",
"./undo/DropAction",
"../util/ErrorReporter",
"../util/GraphUtil",
"../util/Geometry",
"../util/Batch"
], function(
lang,
array,
gfx,
gfxu,
m,
ArrayList,
Set,
iid,
GroupAction,
UngroupAction,
SimpleAction,
MultipleAction,
DeleteAction,
ReorderAction,
UndoActionList,
ChangeLinkIntermediatePointsAction,
InvertLinkAction,
DropAction,
R,
gu,
g,
Batch
){

	// TODO: Change to this when AMD conversion is complete:
	// var eu = {};
	var eu = lang.getObject("ibm_ilog.diagram.editor.EditingUtils", true);


	// Some actions need EditingUtils, but they cannot add it in their dependencies since EditingUtils depends on them.
	// To fix this, we store a refence to EditingUtils in these actions here, and the actions will use EditingUtils like this:
	//	XxxAction.EditingUtils.blaBla()
	
	DropAction.EditingUtils = eu;
	GroupAction.EditingUtils = eu;
	UngroupAction.EditingUtils = eu;
	ReorderAction.EditingUtils = eu;
	InvertLinkAction.EditingUtils = eu;

//////////////////////////////////////////////////////////////////////////////
//		Deletion utilities
eu.deleteGraphElements = function deleteGraphElements(/*ibm_ilog.diagram.widget.Diagram*/diagram,/*ibm_ilog.diagram.GraphElement[]*/elements, /*Function?*/doDeleteFunction) {
	// summary:
	//		deletes the elements from the diagram
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram from where to delete
	// elements: ibm_ilog.diagram.GraphElement[]
	//		the elements set to be deleted
	// doDeleteFunction: Function
	//		an optional Function to perform the deletion.
	// returns:
	//		The Action corresponding to the delete operation.
	
	doDeleteFunction = typeof(doDeleteFunction) == "function" ? doDeleteFunction : eu.doDeleteAction;
	var targetSet = eu.prepareDeletedSet(diagram, elements);
	return doDeleteFunction(diagram, targetSet); // ibm_ilog.diagram.editor.undo.Action
};

eu.prepareDeletedSet = function(/*ibm_ilog.diagram.widget.Diagram*/diagram, /*ibm_ilog.diagram.GraphElement[]*/elements){
	// summary:
	//		Computes the set of GraphElement to delete based on the specified elements list.
	// description:
	//		This method processes the specified elements array to ensures children (if any) and connected links are deleted too.  
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		The diagram instance to remove the shapes from.
	// elements: ibm_ilog.diagram.GraphElement[]
	//		the elements set to be deleted
	// returns:
	//		the list of GraphElement to delete.
	
	var allElements = {};
	eu.findElementsToDelete(diagram,elements,allElements);
	
	var list = [];
	
	for(var ids in allElements){
		list.push(allElements[ids]);
	}
	eu._changeFocused(diagram,allElements);

	var targetSet = gu.maximals(list);
	return targetSet; // ibm_ilog.diagram.GraphElement[]
};

eu.doDeleteAction = function(/*ibm_ilog.diagram.widget.Diagram*/diagram, /*ibm_ilog.diagram.GraphElement[]*/shapes){
	// summary:
	//		Deletes the specified shapes from the given diagram and returns a corresponding undo Action.
	// description:
	//		This implementation removes the specified shapes from the diagram graph and dispose them.
	//		Note that it does not handle any data store-related tasks.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		The diagram instance to remove the shapes from.
	// shapes: ibm_ilog.diagram.GraphElement[]
	//		An array of ibm_ilog.diagram.GraphElement to remove.
	// returns:
	//		The action to undo the delete operation.
	
	var action = eu.createDeleteUndoAction(diagram,shapes);
	
	array.forEach(shapes,function(graphElement){
		graphElement.getParent().remove(graphElement);
		graphElement.dispose();
	});
	
	return action; // ibm_ilog.diagram.editor.undo.DeleteAction
};

eu._changeFocused = function _changeFocused(diagram,allElements){
	// summary:
	//		Change the focused element to the first available top parent available (if the focused element is been removed).
	var current = diagram.getFocusedElement();
	if(current && (current.getId() in allElements)){
		var children = diagram.getGraph().children;
		for(var i = 0 ; i<children.length ; i++){
			var child = children[i];
			if(child._isIBMDiagramNode && !(child.getId() in allElements)){
				diagram.setFocusedElement(child);
				return;
			}
		}
	}
};

eu.findElementsToDelete = function findElementsToDelete(diagram,elements,result){
	// summary:
	//		iterate over the elements and add to the result all the children and the connected links.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram from where to delete
	// elements: array of ibm_ilog.diagram.GraphElement
	//		the elements set to be deleted
	// result: array of ibm_ilog.diagram.GraphElement
	//		the resulting array.
	for(key in elements){
		var e = elements[key];
		var ge = diagram.asGraphElement(e);
		if(ge) {
			result[ge.getId()] = ge;
			if(ge._isIBMDiagramNode){
				array.forEach(ge.getLinks(),function(link){
					result[link.getId()] = link;
				});
				if(ge._isIBMDiagramSubgraph){
					eu.findElementsToDelete(diagram,ge.getGraph().children,result);
				}
			}
		}
	}
};

//////////////////////////////////////////////////////////////////////////////
// Group/Ungroup utilities

eu.groupElements = function groupElements(diagram,elements,subgraphName) {
	// summary:
	//		Creates a new subgraph, and moves all the elements inside it. 
	//		This method return a JSObject with the created subgraph and the Undo Action: { subgraph:sg , action:action }
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram from where to group
	// elements: array of ibm_ilog.diagram.GraphElement
	//		the elements set to be group
	// subgraphName: String
	//		the new subgraph label
	// return: { subgraph: ibm_ilog.diagram.Subgraph , action: ibm_ilog.diagram.editor.undo.GroupAction }
	var lca = gu.lowestCommonAncestor.apply(this,elements);
	
	var sg = diagram.createSubgraph(null,null,lca);
	
	sg.setLabel(subgraphName);
	
	eu.groupReparent(diagram,elements,sg,lca);

	var action = eu.createGroupUndoAction(sg,elements);
	
	return { subgraph:sg, action:action };
};

eu.ungroupElements = function ungroupElements(diagram,subgraph) {
	// summary:
	//		Deletes the subgraph and moves all its children to its parent.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram from where to ungroup
	// subgraph: ibm_ilog.diagram.Subgraph
	//		the subgraph to be ungrouped
	
	var elements = [].concat(subgraph.getGraph().children);
	
	var sgTransform = m.clone(subgraph.getTransform());
	
	eu.groupReparent(diagram,elements,subgraph.getParent(),subgraph);
	
	var subgraphId = subgraph.getId();
	
	var deleteAction = eu.deleteGraphElements(diagram,[subgraph]);
	
	var action = eu.createUngroupUndoAction(diagram,subgraphId,elements,deleteAction,sgTransform);
	
	return { elements:elements, action:action };
};

eu.groupReparent = function groupReparent(diagram,elements,newParent,oldParent) {
	// summary:
	//		Change the parent of all the elements given by parameter.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram from where to reparent
	// elements: array of ibm_ilog.diagram.GraphElement
	//		the elements to be reparented.
	// newParent: ibm_ilog.diagram.Subgraph or ibm_ilog.diagram.Graph
	//		the new parent
	// oldParent: ibm_ilog.diagram.Subgraph or ibm_ilog.diagram.Graph
	//		the old parent
	var graph = newParent._isIBMDiagramSubgraph?newParent.getGraph():newParent;
	Batch.endBatch(); // make sure everything is up to date...
	if (iid.isVml) {
		// VML: try to find a way to avoid wrong layouts and IE crashes...
		// Defect #3988 (wrong layout) + also seems to fix #3392 partially (crashes less frequently)
		array.forEach(elements, function(ge){
			if(ge._isIBMDiagramLink) return; // links are reparented separately
			if (ge.suspendInvalidate) 
				ge.suspendInvalidate();
			
			var oldInAdd = iid._inContainerAdd;
			iid._inContainerAdd = true;
			
			var oldParent = ge.getParent();
			if (oldParent) {
				oldParent.remove(ge);
			}
			graph.rawNode.appendChild(ge.rawNode);
			gfx.shape.Container.add.call(graph, ge);
			
			gfxu.forEach(ge, function(s){
				if (s.suspendInvalidate) 
					s.suspendInvalidate();
				if (typeof(s.getFont) == 'function') { // text shapes need to be completely refreshed
					s.setShape(s.getShape());
					s.setFont(s.getFont());
				}
				if (typeof(s.setFill) == 'function') { // if setFill is available a setStroke should be safe to assume also
					s.setFill(s.getFill());
					s.setStroke(s.getStroke());
				}
				if (s.resumeInvalidate) 
					s.resumeInvalidate();
			});
			
			iid._inContainerAdd = oldInAdd;
			
			if (ge.resumeInvalidate) 
				ge.resumeInvalidate();
		});
	} else // normal case (not VML):
	array.forEach(elements, function(ge){
		if(ge._isIBMDiagramLink) return; // links are reparented separately
		graph.add(ge);
	});
	array.forEach(elements,function(ge) {
		if(ge._isIBMDiagramLink) return; // links are reparented separately
		var op = oldParent;
		if(!oldParent){
			op = ge.getParent();
			if(op && op.getParent()){
				op = op.getParent();
			}
		}
		eu.reparentTransform(diagram,ge,newParent,op);
	});
	
	_reparentLinks(elements);
};

var _reparentLinks = function(elements){
	// now reparent all links
	array.forEach(elements,function(ge) {
		if(ge._isIBMDiagramLink){
			_reparentLink(ge);
		} else if(ge._isIBMDiagramNode){
			array.forEach(ge.getLinks(), function(l){
				_reparentLink(l);
			});
			if (ge._isIBMDiagramSubgraph) {
				_reparentLinks(ge.getGraph().children);
			}
		}
	});
};

var _reparentLink = function(l){
	var start = l.getStartNode();
	var end = l.getEndNode();
	if (start && end) {
		var a = gu.lowestCommonAncestor(start, end);
		l.removeShape(); // always remove and add the link to pop it to the front
		a.add(l);
	}
};

eu.reparentTransform = function reparentTransform(diagram,element,newParent,oldParent) {
	// summary:
	//		Apply the transformation to reparent an element without noticeable transformation change.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram from where to reparent
	// element: ibm_ilog.diagram.GraphElement
	//		the element to be reparented.
	// newParent: ibm_ilog.diagram.Subgraph or ibm_ilog.diagram.Graph
	//		the new parent
	// oldParent: ibm_ilog.diagram.Subgraph or ibm_ilog.diagram.Graph
	//		the old parent (can be null)
	if(oldParent){
		var oldT = oldParent.getShapeToContainerTransform(diagram.getGraph().getParent());
		element.applyLeftTransform(oldT);
	}
	newParent = newParent || diagram.getGraph();
	var newT = newParent.getShapeToContainerTransform(diagram.getGraph().getParent()).inverse();
	element.applyLeftTransform(newT);

};

//////////////////////////////////////////////////////////////////////////////
// Alignment functions

eu.alignLeft = function alignLeft(diagram,elements,pivotElement) {
	// summary:
	//		Align the elements based on the pivotElement left side.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram where the elements are aligned.
	// elements: array of ibm_ilog.diagram.Node
	//		the target set to be aligned.
	// pivotElement: ibm_ilog.diagram.Node
	//		the element taken as pivot for alignment.
	return eu.alignWithPivot(diagram,elements,pivotElement,function(b){ return {x:b.x,y:0}; }); 
};
eu.alignRight = function alignRight(diagram,elements,pivotElement) {
	// summary:
	//		Align the elements based on the pivotElement right side.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram where the elements are aligned.
	// elements: array of ibm_ilog.diagram.Node
	//		the target set to be aligned.
	// pivotElement: ibm_ilog.diagram.Node
	//		the element taken as pivot for alignment.
	return eu.alignWithPivot(diagram,elements,pivotElement,function(b){ return {x:b.x+b.width,y:0}; }); 
};
eu.alignHCenter = function alignHCenter(diagram,elements,pivotElement) {
	// summary:
	//		Align the elements based on the pivotElement horizontal center.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram where the elements are aligned.
	// elements: array of ibm_ilog.diagram.Node
	//		the target set to be aligned.
	// pivotElement: ibm_ilog.diagram.Node
	//		the element taken as pivot for alignment.
	return eu.alignWithPivot(diagram,elements,pivotElement,function(b){ return {x:b.x+b.width/2,y:0}; }); 
};
eu.alignTop = function alignTop(diagram,elements,pivotElement) {
	// summary:
	//		Align the elements based on the pivotElement top side.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram where the elements are aligned.
	// elements: array of ibm_ilog.diagram.Node
	//		the target set to be aligned.
	// pivotElement: ibm_ilog.diagram.Node
	//		the element taken as pivot for alignment.
	return eu.alignWithPivot(diagram,elements,pivotElement,function(b){ return {x:0,y:b.y}; }); 
};
eu.alignBottom = function alignBottom(diagram,elements,pivotElement) {
	// summary:
	//		Align the elements based on the pivotElement bottom side.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram where the elements are aligned.
	// elements: array of ibm_ilog.diagram.Node
	//		the target set to be aligned.
	// pivotElement: ibm_ilog.diagram.Node
	//		the element taken as pivot for alignment.
	return eu.alignWithPivot(diagram,elements,pivotElement,function(b){ return {x:0,y:b.y+b.height}; }); 
};
eu.alignVCenter = function alignVCenter(diagram,elements,pivotElement) {
	// summary:
	//		Align the elements based on the pivotElement vertical center.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//	the diagram where the elements are aligned.
	// elements: array of ibm_ilog.diagram.Node
	//	the target set to be aligned.
	// pivotElement: ibm_ilog.diagram.Node
	//	the element taken as pivot for alignment.
	return eu.alignWithPivot(diagram,elements,pivotElement,function(b){ return {x:0,y:b.y+b.height/2}; }); 
};

eu.alignWithPivot = function alignWithPivot(diagram,elements,pivotElement,getBBPivot) {
	// summary:
	//		Align the elements based on the pivotElement and the getBBPivot function.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram where the elements are aligned.
	// elements: array of ibm_ilog.diagram.Node
	//		the target set to be aligned.
	// pivotElement: ibm_ilog.diagram.Node
	//		the element taken as pivot for alignment.
	// getBBPivot: Function
	//		this function determines the alignment position.	
	
	var V = diagram.getViewport();
	var graph = diagram.getGraph();
	var refbb = pivotElement.getBounds(graph);
	var refPivot = getBBPivot(refbb);
	
	var mAction = new MultipleAction(UndoActionList.Align);
	
	for(var i = 1; i<elements.length; i++) {
		var ge = elements[i];
		var oldTransform = m.clone(ge.getTransform());
		var gebb = ge.getBounds(graph);
		var delta = g.subPoint(refPivot,getBBPivot(gebb));
		ge.setTransform(m.multiply(ge.getTransform(),m.translate(delta)));
		mAction.addAction(eu.createMoveUndoAction(ge,oldTransform,ge.getTransform()));
	}
	return mAction;
};

//////////////////////////////////////////////////////////////////////////////
// Reorder z-order functions

eu.reorderedParents = function reorderedParents(graphElements) {
	// summary:
	//		given a list of GraphElements, return and array list with the parents of the elements, 
	//		and a dictionary of the elements, with the Id as keys.
	// graphElements: array of ibm_ilog.diagram.GraphElement
	//		the elements to be processed.
	// return: {parents:dojox.collections.ArrayList,ids:{}}
	var ids = {}; 
	var parents = new ArrayList();
	var union = Set.union;
	
	array.forEach(graphElements,function(e){
		ids[e.getId()]=e;
		parents = union(parents,[e.getParent()]);
	});
	
	return {parents:parents,ids:ids};
};

eu.reorderSelection = function reorderSelection(selectedElements,childrenReorderer) {
	// summary:
	//		get the selection, and iterates over the selection parents,
	//		calling the childrenReorderer function passed as parameter, 
	//		with each parent element and the list of selected elements ids.
	// selectedElements: array of ibm_ilog.diagram.GraphElement
	//		the elements to be arranged.
	// childrenReorderer: Function
	//		the function to be called with each selection parent.
	var o = eu.reorderedParents(selectedElements);
	var actions = []; 
	for(var i = 0; i<o.parents.count ; i++){
		var parent = o.parents.item(i);
		var action = new ReorderAction();
		action.setOldElementList(parent.children);
		childrenReorderer(parent,o.ids);
		action.setNewElementList(parent.children);
		actions.push(action);
	}
	if(actions.length==1){
		return actions[0];
	}else{
		var action = new MultipleAction(UndoActionList.Reorder);
		array.forEach(actions,function(a){action.addAction(a);});
		return action;
	}
};

eu.setChildrenOrder = function setChildrenOrder(order) {
	// summary:
	//		order the elements in the order parameter, as they are passed.
	//		This cause a reverse z-order (the last element is the Front one, and the other way about).
	// order: array of ibm_ilog.diagram.GraphElement
	//		the elements to be order
	array.forEach(order,function(e){
		e.moveToFront();
	});
};

eu.classifyList = function classifyList(childList,in_b,scope) {
	// summary:
	//		evaluates each element in the with the in_b function, 
	//		and add it to the a list if true, and to the b one if false.
	// childList: array of ibm_ilog.diagram.GraphElement
	//		the elements to be order
	// in_b: Function
	//		the function to evaluate.
	// scope: Scope
	//		the scope where to evaluate the in_b function.
	var a = [], b = [];
	array.forEach(childList,function(e){
		if(in_b(e)) {
			b.push(e);
		} else {
			a.push(e);
		}
	},scope);
	return {a:a,b:b};
};

eu.sendToBack = function sendToBack(selectedElements) {
	// summary:
	//		Send the selected elements to back .
	// selectedElements: array of ibm_ilog.diagram.GraphElement
	//		the elements to be arranged
	return eu.reorderSelection(selectedElements,function(parent,ids){
		var p = eu.classifyList(parent.children,function(e) {
			return e.getId() in ids;
		});
		eu.setChildrenOrder(p.b.concat(p.a));
	});
};

eu.bringToFront = function bringToFront(selectedElements) {
	// summary:
	//		Send the selected elements to the front.
	// selectedElements: array of ibm_ilog.diagram.GraphElement
	//		the elements to be arranged
	return eu.reorderSelection(selectedElements,function(parent,ids){
		var p = eu.classifyList(parent.children,function(e) {
			return e.getId() in ids;
		});
		eu.setChildrenOrder(p.a.concat(p.b));
	});
};

eu.sendBackward = function sendBackward(selectedElements) {
	// summary:
	//		Send the selected elements one position back.
	// selectedElements: array of ibm_ilog.diagram.GraphElement
	//		the elements to be arranged.
	return  eu.reorderSelection(selectedElements,function(parent,ids){
		var cs = parent.children;
		var yielded = null;
		var newOrder = [];
		var restore = function() {
			if(yielded) {
				newOrder.push(yielded);
				yielded = null;
			}
		};
		for( var i = 0; i< cs.length; i++) {
			var e = cs[i];
			if(!(e.getId() in ids)) {
				restore();
				yielded = e;
			} else {
				newOrder.push(e);
				restore();
			}
		};
		restore();
		eu.setChildrenOrder(newOrder);
	});
};

eu.bringForward =  function bringForward(selectedElements) {
	// summary:
	//		Send the selected elements one position front.
	// selectedElements: array of ibm_ilog.diagram.GraphElement
	//		the elements to be arranged.
	return eu.reorderSelection(selectedElements,function(parent,ids){
		var cs = parent.children;
		var pushed = [];
		var newOrder = [];
		for( var i = 0; i< cs.length; i++) {
			var e = cs[i];
			if(e.getId() in ids) {
				pushed.push(e);
			} else {
				newOrder.push(e);
				newOrder = newOrder.concat(pushed);
				pushed = [];
			}
		};
		newOrder = newOrder.concat(pushed);
		eu.setChildrenOrder(newOrder);
	});
};

//////////////////////////////////////////////////////////////////////////////
//   DROP FUNCTIONS

eu.startDropAction = function startDropAction(droppedItem,p,D,elements,dropAction){
	// summary:
	//		starts a drop action. 
	//		This method cam be called externally, from the DropInteractor or from an DropAction (redo).
	// droppedItem: ibm_ilog.diagram.GraphElement
	//		the item that has been dropped.
	// p: Point
	//		the dropping point.
	// elements: array of ibm_ilog.diagram.GraphElement
	//		the elements that have been detected behind the point
	// dropAction: ibm_ilog.diagram.editor.undo.UngroupAction
	//		the droped action involved in the operation
	var di = D.getDropInteractor();
	di.setDroppedItem(droppedItem);
	if (di._onDropFunction) {
        try{
        	di._onDropFunction.call(null,droppedItem,p,D,elements,dropAction);
        }catch(e){
        	R.error("DropUserFunctionError",e);
        }
	}
	if(!dropAction.isRedoing()){
		D.getUndoManager().addAction(dropAction);
	}
};

//////////////////////////////////////////////////////////////////////////////
//		Intermediate point operations

eu.addItermediatePoint = function AddItermediatePoint(D,link,point,index){
	// summary:
	//		adds a intermediate point to the given link, in the specified index.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram where the elements are deleted.
	// link: ibm_ilog.diagram.Link
	//		the link to be modified
	// point: point
	//		the point to be added
	// index: integer
	//		the position where to be added (between the intermediate points).
	
	var intermediatePoints = link.getIntermediatePoints();
	intermediatePoints = intermediatePoints.slice(0,index).concat([point]).concat(intermediatePoints.slice(index));
	link.setIntermediatePoints(intermediatePoints);
	D.getUndoManager().addAction(eu.createAddItermediatePointUndoAction(D,link,point,index)); 
};
////////////////////////////////////////////////////////////////////////////////
// INVERT LINKS

eu.invertLink = function invertLink(link){
	var startPort = link.getStartPort();
	var endPort = link.getEndPort();
	link.setStartPort(endPort);
	link.setEndPort(startPort);
	return this.createInvertLinkUndoAction(link);
};


//////////////////////////////////////////////////////////////////////////////
//		CREATION OF UNDO ACTIONS

eu.createInvertLinkUndoAction = function createInvertLinkUndoAction(link){
	var action = new InvertLinkAction();
	action.setModifiedElementId(link.getId());
	return action;
};

eu.createDeleteUndoAction = function createDeleteUndoAction(diagram,targetSet){
	// summary:
	//		creates the move undo action, based on the target.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram where the elements are deleted.
	// targetSet: array of ibm_ilog.diagram.GraphElement
	//		the target set to be deleted
	var action = new DeleteAction(diagram);
	action.setDeleted(targetSet);
	return action;
};

eu.createGroupUndoAction = function createGroupUndoAction(subgraph,elements){
	// summary:
	//		creates the group undo action.
	// subgraph: ibm_ilog.diagram.Subgraph
	//		the created subgraph, that groups the elements.
	// elements: array of ibm_ilog.diagram.GraphElement
	//		the elements that have been group.
	var action = new GroupAction();
	action.setElements(elements);
	action.setSubgraph(subgraph);
	return action;
};

eu.createUngroupUndoAction = function createUngroupUndoAction(diagram,subgraphId,elements,deleteAction,sgTransform){
	// summary: ibm_ilog.diagram.editor.undo.UngroupAction
	//		creates the ungroup undo action.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram where the elements are ungroup.
	// subgraph: String
	//		the deleted subgraph Id.
	// elements: array of ibm_ilog.diagram.GraphElement
	//		the elements that have been ungroup.
	// deleteAction: ibm_ilog.diagram.editor.undo.DeleteAction
	//		the created deleteAction, obtained when deleting the subgraph.
	var action = new UngroupAction();
	action.setElements(elements);
	action.setSubgraphId(subgraphId);
	action.setSubgraphTransform(sgTransform);
	action.setDeleteAction(deleteAction);
	return action;
};

eu.createMoveUndoAction = function createMoveUndoAction(target,oldTransformation, newTransformation){
	// summary:ibm_ilog.diagram.editor.undo.UngroupAction
	//		creates the move undo action, based on the target.
	// target: ibm_ilog.diagram.GraphElement
	//		the element that has been moved.
	// oldTransformation: dojox.gfx.matrix
	//		the old transformation matrix.
	// newTransformation: dojox.gfx.matrix
	//		the new transformation matrix.
	var cloneF = function(object){return m.clone(object);};
	
	var action = new SimpleAction(UndoActionList.Move);
	action.setOldValue(m.clone(oldTransformation));
	action.setNewValue(m.clone(newTransformation));
	action.setMethodOrProperty('setTransform');
	action.setModifiedElementId(target.getId());
	action.setCloneFunction(cloneF);
	return action;
};

eu.createOnDropAction = function createOnDropAction(D,droppedItem,p,elements){
	// summary:ibm_ilog.diagram.editor.undo.DropAction
	//		creates the drop undo action.
	// droppedItem: ibm_ilog.diagram.GraphElement
	//		the item that has been dropped.
	// p: Point
	//		the dropping point.
	// elements: array of ibm_ilog.diagram.GraphElement
	//		the elements that have been detected behind the point
	var newElements = [];
	array.forEach(elements, function(item){
		newElements.push(item.getId());
	});
	var action = new DropAction();
	action.setDroppedItem(droppedItem);
	action.setDroppedPosition(p);
	action.setElementsList(newElements);
	action.setDropInteractor(D.getDropInteractor());
	return action;
};

eu.createAddItermediatePointUndoAction = function createAddItermediatePointUndoAction(diagram,link,point,index){
	// summary:
	//		creates the undo action
	var action = new ChangeLinkIntermediatePointsAction(diagram, link);
	action.setAddPointOperation(index,point);
	return action;
};

return eu;

});
