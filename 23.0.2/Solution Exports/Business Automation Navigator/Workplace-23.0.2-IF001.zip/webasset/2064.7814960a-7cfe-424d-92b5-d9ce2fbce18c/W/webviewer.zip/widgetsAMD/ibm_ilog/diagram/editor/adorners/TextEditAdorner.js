/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/config",
"dojo/_base/event",
"dojo/keys",
"dojo/dom-style",
"dijit/focus",
"dijit/form/_TextBoxMixin",
"dojox/gfx",
"dojox/dtl",
"../../base",
"../../templating",
"../../gfxwidget/GfxWidget",
"./ComponentAdorner",
"../undo/SimpleAction",
"dojo/has!isBidiInDojoDiagrammer?../../util/BidiUtil:"
], function(
declare,
lang,
config,
event,
keys,
style,
focus,
textboxmix,
gfx,
dtl,
iid,
templating,
GfxWidget,
ComponentAdorner,
SimpleAction,
BidiUtil
){
	
/*=====
var ComponentAdorner = ibm_ilog.diagram.editor.adorners.ComponentAdorner;
=====*/

var TextEditAdorner = iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.TextEditAdorner', [ComponentAdorner], {

	//	summary:
	//		An adorner for editing string-valued properties of Graph elements. 
	//	description:
	//		TextEditAdorner is an adorner that displays a TextBox for editing a 
	//		property of a Graph element. The user must provide an attachPoint name for 
	//		the property which is used to calculate the position of the TextBox, and 
	//		also a getter and setter of the property at the Graph element.   
	//	usage:
	//		The following code starts editing the "label" attribute of "node", using 
	//		getLabel/setLabel as accessorsm and "textShape" as value representation for
	//		reference when positioning the TextBox
	//
	//		textEditAdorner.setAccessors(
	//			function(adorned){
	//				return adorned.getLabel();
	//			},
	//			function(adorned,value){
	//				adorned.setLabel(value);
	//			});
	//		textEditAdorner.setComponent("textShape");
	//		textEditAdorner.setAdorned(node);
	//
	
	//
	// _lastAdorned: GraphElement
	//
	_lastAdorned: null,

	//
	//	_textbox: dijit.form.TextBox
	//
	_textbox: null,
		
	//
	//	_gettter: accessor to get the value of the property from the graph element
	//
	_getter: null,
	
	//
	//	_settter: accessor to set the value of the property to the graph element
	//
	_setter: null,

	setComponentAttachPoint: function(a) {
		//
		//	summary:
		//		Sets the component original attachpoint		 
		//
		this._componentAttachPoint = a;
	},

	getComponentAttachPoint: function() {
		//
		//	summary:
		//		Returns the attachPoint name of the visual shape associated with the property. 
		//
		return this._componentAttachPoint;
	},

	initialize: function () {
		this.inherited(arguments);
		
		// get textbox from template attachPoint  

		// this.textbox is the GfxWidget declared at the template
		this._textbox = this.textbox._widget;
	},

	setAccessors: function(getter,setter) {
		//
		//	summary:
		//		Configure the receiver with the setter and getter functions for the property on the graph element. 
		//
		this._getter = getter;
		this._setter = setter;
	},

	_onBlur: function() {
		//
		//	summary:
		//		unlink the adorner when the textbox looses focus
		//
		this.setAdorned(null);
	},
	
	_getTextBoxValue: function(){
		var value = this._textbox.get("value");
		// prevent DTL from escaping HTML, even if the binding was not marked with |safe.
		value = dtl.mark_safe(value);
		return value;
	},
	
	_setTextBoxValue: function(value){
		this._textbox.set("value", value);
	},
	
	_onKey: function(e) {
		//
		//	summary:
		//		Handle special keys:
		//			Enter: accepts the value and sets it to the currently adorned graph element.
		//			Esc: cancels the operation and hides the adorner.
		//
		if(e.keyCode==keys.ENTER && !e.shiftKey) { // ENTER
			var value = this._getTextBoxValue();
			if(value!=this._getter(this._lastAdorned)) {
				var action = this._createUndoAction(this._lastAdorned,value);
				this._setter(this._lastAdorned,value);
				this._diagram.getUndoManager().addAction(action);
			}
			event.stop(e);
			this.setAdorned(null);
			focus.focus(this._diagram.domNode);
		} else if(e.keyCode==keys.ESCAPE) { // ESC
			event.stop(e);
			this.setAdorned(null);
			focus.focus(this._diagram.domNode);
		}
		else if (config.isBidiInDojoDiagrammer) { //Bidi support
		    var textdir = this._diagram.textDir;
		    if ((textdir === undefined) || (textdir === ""))
		        return;
		    if (textdir == "auto") {
		        var value = this._getTextBoxValue();
	            textdir = BidiUtil.checkDir(value);
		        if (textdir == "rtl")
		          this._textbox.set("dir", "rtl");				         
		        else 
		          this._textbox.set("dir", "ltr");
		   }
		}		
	},
	
	_onPaste: function() {
		//
		//	summary:
		//      resolve "auto" text direction for pasted text
		//		unlink the adorner when the textbox looses focus
		//

	    var textdir = this._diagram.textDir;
	    if ((textdir === undefined) || (textdir === ""))
	        return;
	    if (textdir == "auto") {
	        var value = this._getTextBoxValue();
	        textdir = BidiUtil.checkDir(value);
	        if (textdir == "rtl")
	           this._textbox.set("dir", "rtl");		         
	        else 
	           this._textbox.set("dir", "ltr");
	   }
	},
	
	_createUndoAction: function(adorned,value){
		//
		//	summary:
		//		Create an Undo object for the operation of changing the 
		//		associated property to "value" on "adorned"
		//
		var action = new SimpleAction('EditText');
		action.setOldValue(adorned.getLabel());
		action.setNewValue(value);
		action.setModifiedElementId(adorned.getId());
		action.setter = this._setter;
		action.changeFunction = lang.hitch(action,function(value){	
			var modifiedObject = this.getModifiedElement();
			this.setter(modifiedObject,value);
		});
		return action;
	},
	
	clear: function() {
		//
		//	summary:
		//		Clear the value of the TextBox
		//
		this._setTextBoxValue("");
	},
	
	reset: function() {
		//
		//	summary:
		//		Rest the value of the TextBox to the original value found at the adorned object
		//
		var value = this._getter(this._lastAdorned);
		
		//set text direction to TextBox
        if (config.isBidiInDojoDiagrammer) {
		    var textdir = this._diagram.textDir;
		    if (textdir == "auto")
		        textdir = BidiUtil.checkDir(value);
            if (textdir == "rtl")
		        this._textbox.set("dir", "rtl");
            else if (textdir == "ltr")
		        this._textbox.set("dir", "ltr");
		} 	
				
		this._setTextBoxValue(value);
	},
	
	setOptions: function(options) {
		// instantiation options
		// TODO check why this is not working.
		if(options.style) {
			style.set(this._textbox.focusNode,options.style);
		}
	},

	setAdorned: function(e) {
		//
		//	summary:
		//		Change the adorned object. This causes the TextBox to appear at the corresponding 
		//		location (based on the location of the graph element and the location of the 
		//		property shown inside the element). 
		//		If null, the TextBox is hidden and unbinded.
		//
		this._disconnect("blur");
		this._disconnect("key");
		if (config.isBidiInDojoDiagrammer)
		    this._disconnect("paste");				
		this.clear();
		this.inherited(arguments);
		if(e) {
			this._lastAdorned = e;
			this.reset();
			this._textbox.focus();
			textboxmix.selectInputText(this._textbox.focusNode);

			// If the textbox looses focus, cancel.
			this._connect("blur",this._textbox,"onBlur",this,"_onBlur");

			// Handle Enter and Esc keys
			this._connect("key",this._textbox,"onKeyPress",this,"_onKey");
			
			//for contextual text direction, text direction of editor depends on pasted text 
			if (config.isBidiInDojoDiagrammer)
			    this._connect("paste",this._textbox,"_onInput",this,"_onPaste");				
		} else {
			this._textbox.domNode.blur();
		}
	},
		
	_updateLayout: function() {
		//
		//	summary:
		//		Publish new geometric values (causes template bindings to be applied if changed).
		//
		
		this.startDTLBatch();

		this.inherited(arguments);
		
		if(this._componentAttachPoint && this._componentAttachPoint.getFont) {
			var z = gfx.normalizedLength(this._componentAttachPoint.getFont().size);
			this.setRefFontPxSize(z*this._component._getRealMatrix().yy);
		}

		this.endDTLBatch();
	}
	
}));

templating.declareBindableProperty(TextEditAdorner, "refFontPxSize", 10);

return TextEditAdorner;

});
