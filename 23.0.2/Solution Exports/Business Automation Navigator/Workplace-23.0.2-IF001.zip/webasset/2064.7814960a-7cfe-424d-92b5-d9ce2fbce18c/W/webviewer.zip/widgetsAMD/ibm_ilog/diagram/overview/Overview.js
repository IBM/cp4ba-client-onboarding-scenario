/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"../main",
"dojo/_base/declare",
"dojo/_base/lang",
"dojox/gfx/matrix",
"../util/HandleSet",
"../util/Geometry"
],
function(
iid,
declare,
lang,
matrix,
HandleSet,
g
){

var Size = g.Size;

/*=====
var HandleSet = ibm_ilog.diagram.util.HandleSet;
=====*/

var Overview =
declare('ibm_ilog.diagram.overview.Overview', [HandleSet], {
//		summary:
//			Draws the overview as a GFX group.
//		
//		architecture:
//			The overview is a mini-diagram with no zooming or panning options that always shows the 
//			entire diagram, like a map.
//	
//			An Overview object draws a map-like representation of the contents of a viewport. It can be used 
//			through the OverviewWidget or directly (for example for using it to draw a component of the Viewport HUD).
//	
//			An Overview relies on an OverviewRenderer which encapsulates the algorithm for generating 
//			the overview image. Different algorithms provide different representation.
//	
//		view rectangle:
//			The Overview also represents the current location of the Viewport with a GFX Rectangle. 
//			Whenever the viewport is repositioned or zoomed, the Viewport object will notify the event, to 
//			which the Overview will react updating a rectangle shape.
//	
//		navigation:
//			See pointers on how the user could interact with the Overview, see the subclasses of OverviewInteractor
//			and how the Overview widget uses them.
//	

	
	//	
	//	_diagram: ibm_ilog.diagram.widget.Viewport
	//		The viewport
	//
	_viewport: null,
	
	//	
	//	_diagram: ibm_ilog.diagram.overview.OverviewRenderer
	//		The overview renderer
	//
	_renderer: null,

	//	
	//	_output: dojox.gfx.Group
	//		The insertion point into the Gfx Surface
	//
	_output: null,
	
	//	
	//	_render: dojox.gfx.Group
	//		Where the overview image is generated
	//
	_render: null,

	//	
	//	_content: Object
	//		The content renderer (usually the Graph).
	//
	_content: null,

	//	
	//	_hud: dojox.gfx.Group
	//		Where the overlay shapes are drawn (e.g. the view rectangie)
	//
	_hud: null,

	//	
	//	_enabled: boolean
	//		When false, the receiver hides its contents and ignores change events. 
	//
	_enabled: true,	

	setEnabled: function( /*boolean*/ enabled ) {
		if(!enabled && this._enabled) {
			this._output.remove(this._hud);
			this._render.clear();
			this._output.remove(this._render);
			if(this._timerHandle) {
				clearTimeout(this._timerHandle);
				this._timerHandle = null;
			}
			this._unsubscribe();
		} else if(enabled && !this._enabled) {
			this._output.add(this._hud);
			this._output.add(this._render);
			this._subscribe();
		}
		this._enabled = enabled;
	},
	
	isEnabled: function() {
			return this._enabled;
	},
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//
	//	Initialization
	//

	constructor: function( /*ibm_ilog.diagram.widget.Viewport*/ viewport,
			                                        /*Object*/ content,
	             /*ibm_ilog.diagram.overview.OverviewRenderer*/ renderer, 
	                                   /*dojox.gfx.Group*/ output, 
	                                              /*Size*/ size )
	{
		//
		//	summary:
		//		Constructs an Overview for observing the given viewport, whose contents will be drawn in an area 
		//		of the given size using the given renderer, and places it at the output gfx Group.
		//
		this._viewport = viewport;
		this._renderer = renderer;
		this._content = content;
		this._size = size;
		this._output = output;
		
		this._render = output.createGroup();

		// create hud group after render group so it is at the front
		this._hud = output.createGroup();
		this._createViewRectShape();
		this._createEventSourceShape();

		this._subscribe();
	},
	
	setContent: function( /*Object*/ content) {
		this._content = content;
	},
	
	getContent: function() {
		return this._content;
	},

	setViewport: function( /*Object*/ viewport) {
		this._viewport = viewport;
	},
	
	getViewport: function() {
		return this._viewport;
	},

	_unsubscribe: function () {
		this._disconnectAll();
	},
	
	_subscribe: function () {
  	this._connect("contentChanged",this._viewport.getContent(),"_onChanged",this,"_onContentChangedNotification");
  	this._connect("viewRectChanged",this._viewport,"onViewRectChanged",this,"_updateViewRectShape");
  	this._onContentChangedNotification();
  	this._updateViewRectShape();
	},
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//
	//	Overview operation
	//

	generateContent: function() {

		//
		//	Draws the overview picture
		//
		
		var render = this._beginRender();
		
		this._renderer.render(this._content,render);
		
		this._endRender(render);
		
		this._adjustContent();

	},

	_beginRender: function() {
		if(this._debug) {
			return this._render;
		} else {
			var render = this._output.createGroup();
			var cr = this._viewport.getContentRect();
	
			// we render offscreen, and move it when it's done
			render.setTransform(matrix.translate(iid._invisibleLocation,iid._invisibleLocation));
			render.moveToBack();
			return render;
		}
	},
	
	geViewport: function() {
		return this._viewport;
	},
	
	_endRender: function( render ) {
		if(!this._debug) {
			if(this._render) {
				this._output.remove(this._render);
			}
			this._render = render;
			render.setTransform();
		}
	},

	setRenderer: function( /*ibm_ilog.diagram.overview.OverviewRenderer*/ renderer ) {
		this._renderer = renderer;
	},
	
	getRenderer: function() {
		//
		//	summary:
		//		Returns the current renderer object used at the receiver.
		//
		return this._renderer;
	},

	//	
	//	_zoom:
	//		The current zoom factor applied to the contents displayed by the
	//		overview to be fit in the current overview size.
	//
	_zoom: 1,
	
	getZoom: function() {
		return this._zoom;
	},

	//	
	//	_size: 
	//		The size of the overview
	//
	_size: Size(0,0),
	
	getSize: function() {
		return this._size;
	},

	setSize: function( /*Size*/ sz ) {
	    this._size = sz;
		this._adjustContent();
	},
	
	_adjustContent: function() {
		
		var aabb = this._viewport.getContentRect();
		if(aabb.width && aabb.height) {
			var sz = this._size;
			var xr = sz.width/aabb.width;
			var yr = sz.height/aabb.height;
			var cent = { x: 0, y:0 };
	
			if(xr<yr) {
				this._zoom = xr;
				cent.y = (aabb.width*(sz.height/sz.width)-aabb.height)/2;
			} else {
				this._zoom = yr;
				cent.x = (aabb.height*(sz.width/sz.height)-aabb.width)/2;
			}
	
			var zt = matrix.scale(this._zoom);
			var tt = matrix.translate({x:-aabb.x+cent.x,y:-aabb.y+cent.y}); // uses rect origin
			var t  = matrix.multiply(zt,tt);
			this._render.setTransform(t);
			
			this._updateEventSourceShape();
			this._updateViewRectShape();
		}
		this.onContentReady();
		
	},
	
	onContentReady: function() {
		
	},
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//	
	//	_viewRectShape: 
	//		The GFX rectangle used to represent the view rectangle
	//
	_viewRectShape: null,

	//	
	//	_viewRectShapeFill:
	//		The fill of the view rect shape
	//	
	_viewRectFill:[0xAA,0xD7,0xFF,0.2],
	
	setViewRectFill: function(fill) {
		this._viewRectFill = fill;
		if(this._viewRectShape) {
			this._viewRectShape.setFill(fill);
		}
	},

	//	
	//	_viewRectShapeStroke:
	//		The stroke for the border of the view rect shape
	//
	_viewRectStroke:{color:[0xAA,0xD7,0xFF]},

	setViewRectStroke: function(stroke) {
		this._viewRectStroke = stroke;
		this._updateViewRectShape();
	},
	
	
	_createViewRectShape: function() {
		this._viewRectShape = this._hud.createRect();
		this._viewRectShape.setFill(this._viewRectFill);
		this._updateViewRectShape();
	},

	_updateViewRectShape: function() {
		//
		//	Updates the view rectangle
		//
		if(this._viewRectShape) {
			var t = this._render.getTransform();
			if(t) {
				var vr = g.clipRect(g.standarizeRect(this._size),t.transformRectangle(this._viewport.getViewRect()));
				this._viewRectShape.setShape(vr);
				this._viewRectShape.setStroke({color:this._viewRectStroke.color,width:(this._viewRectStroke.width||1)});

			}
		}
	},
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//	
	//	_eventSourceShape:
	//		A shape used as an event generator for interaction. Current implementation uses a invisible rectangle 
	//		(created with alpha 0.0001) that catches mouse events in the entire group area.
	//
	_eventSourceShape: null,

	getEventSource: function() {
		return this._eventSourceShape;
	},

	_createEventSourceShape: function() {
		this._eventSourceShape = this._hud.createRect();
		this._eventSourceShape.setFill([0,0,0,0.0001]);
		this._updateEventSourceShape();
	},
	
	_updateEventSourceShape: function() {
		//	
		//	Updates the event source shape size to the current viewport navigable area
		//
		if(this._eventSourceShape) {
			// the hooks are required on ie8 to reset the interactor connections (in the OverviewWidget).
			// because Rect.setShape changes the rawNode. So the handlers are lost.
			this.__ieBeforeEvtSrcChange();
			var shape = this._eventSourceShape.getShape();
			var r = g.standarizeRect(this._size);
			if (r.width !== shape.width || r.height !== shape.height)
				this._eventSourceShape.setShape(r);
			this.__ieAfterEvtSrcChange();
		}
	},
	__ieBeforeEvtSrcChange:function(){},
	__ieAfterEvtSrcChange:function(){},
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//	
	//	_timerHandle:
	//		The timer scheduled by the refreshContentNotification request
	//
	_timerHandle:null,
	
	//
	//	_timerInterval:
	//		Refresh rate used for monitoring changes in the content.
	//
	_timerInterval: 1500,

	//
	//	_timerWaitForInteractions: boolean
	//		if true, the rendering timer waits for interactions to finish
	//
	_timerWaitForInteractions: true,

	setWaitForInteractions: function( bool ) {
		this._timerWaitForInteractions = bool ;
	},
	
	getWaitForInteractions: function() {
		return this._timerWaitForInteractions;
	},

	//
	//	_interactorManager: ibm_ilog.diagram.interactors.InteractorManager
	//		the interactor manager to wait for
	//
	_interactorManager: null,

	setInteractorManager: function( interactorManager ) {
		this._interactorManager = interactorManager;
	},
	
	getInteractorManager: function( interactorManager ) {
		return this._interactorManager;
	},

	setRefreshContentsInverval: function( /*Number*/ msInterval ) {
		this._timerInterval = msInterval;
		if(msInterval<0 && this._timerHandle) {
			clearTimeout(this._timerHandle);
			this._timerHandle = null;
		}
	},
	
	getRefreshContentsInverval: function() {
		return this._timerInterval;
	},

	_onContentChangedNotification: function(){
		//
		//	summary:
		//		Sets up a timer to give the originating process time to finish with all the changes
		//
		if(this._timerInterval>=0 && !this._timerHandle) {
			this._timerHandle = 
				setTimeout(lang.hitch(this,this._timer),this._timerInterval);
		}
	},
	
	_timer: function() {
		//
		//	summary:
		//		Callback executed after the contentChangedNotification timer is finished.
		//
		this._timerHandle = null;
		if(this._timerWaitForInteractions && this._interactorManager && this._interactorManager.stackLength()) {
			this._onContentChangedNotification();
		} else {
			this.generateContent();
		}
	},

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//	
	//	clientToContent:
	//		
	//
	clientToContent: function() {
		return this._render._getRealMatrix().inverse();
	},


	contentToClient: function() {
		return this._render._getRealMatrix();
	}
});

return Overview;

});
