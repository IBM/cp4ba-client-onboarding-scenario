define({      
//begin v1.x content
    errorDialogTitle: "IBM BPM エラー",
    moreDetails: "詳細...",
    closeMessage: "すべてのエラー・メッセージを閉じる",
    contentMessage: "エラーが発生しました。"
//end v1.x content
});

