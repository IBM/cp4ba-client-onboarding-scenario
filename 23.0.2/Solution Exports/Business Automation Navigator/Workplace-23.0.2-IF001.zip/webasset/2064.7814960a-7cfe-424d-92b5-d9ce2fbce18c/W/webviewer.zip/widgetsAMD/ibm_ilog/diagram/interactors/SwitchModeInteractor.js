/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/array",
"dojo/keys",
"./Interactor",
"./MoveKeyInteractor",
"./Navigator"
],
function(
declare,
array,
keys,
Interactor,
MoveKeyInteractor,
Navigator
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var SwitchModeInteractor =
declare("ibm_ilog.diagram.interactors.SwitchModeInteractor", [Interactor], {
	//summary:
	//		This Interactor manages the UndoManager through the keyboard interaction.
	//		This Interactor have 3 connections: switchEdition, enterEdition, enterNavigation.
	
	_diagram: null,
	_onNavigation: null,
	_navigationInteractorIds: null,
	_editionInteractorIds: null,
	initialize: function (diagram) {
	// summary:
    //		initialize the new instance.
    // diagram: ibm_ilog.diagram.widget.Diagram
    //		the associated diagram.		
		this._diagram = diagram;
		this._navigationInteractorIds = [Navigator.KeyInteractorId];
		this._editionInteractorIds = [MoveKeyInteractor.KeyInteractorId];
		return this._initialize();
	},
	switchEdition: function(e){
		// summary:
	    //		switch between edition and navigation mode.
		if(this._onNavigation){
			this.enterEdition();
		}else{
			this.enterNavigation();
		}
	},
	enterEdition: function(){
		// summary:
	    //		enter edition mode
		this._setInteractorsEnabled(this._navigationInteractorIds,false);
		this._setInteractorsEnabled(this._editionInteractorIds,true);
		this._onNavigation = false;
	},
	enterNavigation: function(){
		// summary:
	    //		enter navigation mode
		this._setInteractorsEnabled(this._navigationInteractorIds,true);
		this._setInteractorsEnabled(this._editionInteractorIds,false);
		this._onNavigation = true;
	},
	addNavigationInteractorId: function(id){
		// summary:
		//		adds an interactor id, that will be enabled when entering on navigation mode
		this._navigationInteractorIds.push(id);
	},
	addEditionInteractorId: function(id){
		// summary:
		//		adds an interactor id, that will be enabled when entering on edition mode
		this._editionInteractorIds.push(id);
	},
	_setInteractorsEnabled: function(interactorsIds,enabled){
		array.forEach(interactorsIds,
				function(id){
						this._keyManager.get(id).setEnabled(enabled);
						},this);
	},
	getKeyInteractorId: function(){
		// summary:
	    //		returns the Interactor Id
		return SwitchModeInteractor.KeyInteractorId;
	},
	getDefaultConnections: function () {
		// summary:
		//		returns the default event mapping
		
		return {
			enterNavigation: {
				hotKey: null,
				connectTo: "enterNavigation",
				filter: this._buildInputFilter({})
			}, enterEdition: {
				hotKey: null,
				connectTo: "enterEdition",
				filter: this._buildInputFilter({})
			}, switchEdition: {
				hotKey: keys.F9,
				connectTo: "switchEdition"
			}
		};
	}
});

SwitchModeInteractor.KeyInteractorId = "EnterEdition";

return SwitchModeInteractor;

});
