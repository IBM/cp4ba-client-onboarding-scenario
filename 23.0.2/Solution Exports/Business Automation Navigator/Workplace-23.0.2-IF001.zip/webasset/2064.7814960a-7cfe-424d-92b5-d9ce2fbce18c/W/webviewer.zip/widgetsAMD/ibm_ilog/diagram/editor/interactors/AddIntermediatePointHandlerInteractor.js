/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/event",
"../../interactors/Interactor",
"../EditingUtils"
], function(
declare,
event,
Interactor,
EditingUtils
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var AddIntermediatePointHandlerInteractor =
declare("ibm_ilog.diagram.editor.interactors.AddIntermediatePointHandlerInteractor", [Interactor], {
	// summary:
	//		this interactor is created in the LinkIntermediatePointAdorner and have the functionality 
	//		to add intermediate points to the adorned link
	
	
	//	_handle: /*LinkIntermediatePointsHandle*/
	_handle: null,
	_viewport: null,
	
	_declareStates: function () {
		this._declareState("idle", ["add"]);
		//this._declareState("active", ["end"]);
	},

	getDefaultConnections: function () {
		// summary:
		//		returns the default event mapping
		
		return {
			add: {
				src: this._getInitialEventSource(),
				srcEvt: "onmousedown",
				connectTo: "_addIntermediatePoint",
				filter: this._buildInputFilter({shift:false,button:0}),
				gfxConnect:true
			}
		};
	},
	
	initialize: function( /* LinkIntermediatePointsHandle */ handle ) {
    	// Summary:
		//		sets the LinkIntermediatePointsHandle
    	this._handle = handle;
		this._viewport = handle.getViewport();
		this._initialize();
		return this;
	},
	
	_getInitialEventSource: function() {
		return this._handle;
	},
	
	_addIntermediatePoint: function(e) {
		// summary:
		//		Add the intermediate point to the adorned link
		var A = this._handle.getAdorner();
		var D = A.getDiagram();
		var link = A.getAdorned();
		var index = this._handle.getIndex();
		var point = this._getPoint(link,index);
		EditingUtils.addItermediatePoint(D,link,point,index);
		A.rebindAdorned();
		event.stop(e);
	},
	
	_getPoint: function(link,index){
		var iPoints = link._pathPoints;
		var p1 = iPoints[index];
		var p2 = iPoints[index+1];
		var point = {x:((p2.x-p1.x)/2+p1.x), y:((p2.y-p1.y)/2+p1.y)};
		return point;
	}
});

return AddIntermediatePointHandlerInteractor;

});
