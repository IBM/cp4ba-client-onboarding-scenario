define({      
//begin v1.x content
    errorDialogTitle: "Ошибка IBM BPM",
    moreDetails: "Дополнительно...",
    closeMessage: "Закрыть все сообщения об ошибках",
    contentMessage: "Произошла ошибка."
//end v1.x content
});

