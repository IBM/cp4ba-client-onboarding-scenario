define({      
//begin v1.x content
	BPD_DESC_HEADER: "Beskrivelse:",
	BPD_VAR_TITLE: "Variabler",
	BPD_NAME: "Navn",
	BPD_TYPE: "Type",
	BPD_VAR_IN: "Inn",
	BPD_VAR_OUT: "Ut",
	BPD_VAR_PRIVATE: "Privat",
	BPD_WORK_TITLE: "Arbeidsplan",
	BPD_PROCESS_KPIS: "Prosess-KPIer",
	BPD_LOADING: "Laster inn...",
	COACH_DIALOG_TITLE: 'Coach-forhåndsvisning',
	LOADING: 'Laster inn...',
	TIME_SCHEDULE: "Tidsplan",
	TIME_ZONE: 'Tidssone',
	HOLIDAY_SCHEDULE: 'Ferieplan',
	BPD_LIST: 'Liste',
	USE_DEFAULT: "(bruk standardverdi)",
    BPD_COPY_LINK_LABEL: "Del link",
    TOOLTIP_OVERDUE: "Forfalt",
    TOOLTIP_AT_RISK: "I faresonen",
    TOOLTIP_ON_TRACK: "I rute",
    LOOP_PREVENTED: "Bane ble ikke opprettet fordi forutsigelse av sløyfer ikke støttes nå.",
    CRITICAL_TASK_COUNT: "Antall forfalte oppgaver: ${count}",
    AT_RISK_TASK_COUNT: "Antall oppgaver i faresonen: ${count}",
    OK_TASK_COUNT: "Antall oppgaver i rute: ${count}",
    CLICK_TO_REROUTE: "Klikk for å omdirigere banen gjennom denne linken"
//end v1.x content
});

