/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"require",
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/config",
"dojo/_base/json",
"dojo/_base/window",
"dojo/_base/url",
"./ServerSideLayout"
],
function(
require,
declare,
lang,
config,
json,
window,
_Url,
ServerSideLayout
){

/*=====
var _AsynchronousLayout = ibm_ilog.diagram.graphlayout._AsynchronousLayout;
=====*/

var WebWorkerLayout =
declare('ibm_ilog.diagram.graphlayout.WebWorkerLayout', ServerSideLayout._AsynchronousLayout, 
{
	// summary:
	//		Executes a graph layout asynchronously in a Web Worker.
	// description:
	//		The WebWorkerLayout class is similar to the ServerSideLayout class,
	//		but instead of sending a request to a REST service on a remote server,
	//		it executes the graph layout on the client asynchronously using an HTML 5 Web Worker.
	//		This class can be used only if the browser supports web workers (which is not
	//		the case of Internet Explorer, for example).
	//		
	//		The main advantage of executing a graph layout in a Web Worker is that the browser UI
	//		is not blocked while the layout is executed. On the other hand, executing the
	//		layout in a worker thread has a cost, mainly due to the initialization of the
	//		worker which must load its own version of Dojo and the graph layout code before the layout
	//		can be executed. In addition, the graph topology is sent to the web worker and
	//		returned back to the calling thread by serializing the whole graph as a JSON string,
	//		which takes some additional time for big graphs.
	//		
	//		A WebWorkerLayout object is constructed with a Graph object.
	//		To execute a layout, the user must select the algorithm with the standard 
	//		client-side GraphLayout API:
	//		
	//		graph.setNodeLayout(x);
	//		graph.setLinkLayout(y);
	//		
	//		After this, the WebWorkerLayout object can be used to execute these 
	//		algorithms in a web worker by calling:
	//		
	//		webWorkerLayout.layout();
	//		
	//		This will obtain the currently configured layouts on the graph object,
	//		including optional settings for laying out internal subgraphs, gather
	//		their configured parameters and requesting the equivalent layout in the
	//		web worker.
	//
	//		Each time a layout is requested, the graph and the layout settings are
	//		serialized into a JSON object sent in the request.
	//
	//		The layout() method returns a dojo.Deferred which is signaled after the
	//		execution is complete.
	//		
	//		The web worker is reused if possible when the same WebWorkerLayout object
	//		is called several times on the same graph. The first layout execution will take more time
	//		due to the fact that the worker must load Dojo and the graph layout code.
	//		Subsequent layout executions will be faster.
	//		
	//		The WebWorkerLayout class cannot be used if Dojo is loaded from a CDN,
	//		so you must have a local copy of Dojo on your web site.
	
	_worker: null,
	
	_debugPrefix: "WebWorkerLayout: ",
	
	// dojoDir: String
	//		The parent directory of dojo/, relative to the ibm_ilog/diagram/graphlayout/webworker/ directory.
	//		This will be passed to the Web Worker thread to load Dojo.
	//		If not specified, this will be computed from the document URL and the dojo.baseUrl.
	dojoDir: null,
	
	_start: function(data) {
		//
		//	summary:
		//		Creates the Worker object to execute the layout, and applies the results.
		//	returns:
		//		a dojo.Deferred to signal when the process finishes.
		//

		// the worker is reused if already created
		if(!this._worker){
			// create and setup worker
			// first, compute the relative URL from the main application to the _Worker.js:
			this._worker = new Worker(require.toUrl('ibm_ilog/diagram/graphlayout/webworker/_Worker.js'));
			this._worker.onmessage = lang.hitch(this, function(e){
				
				var data = json.fromJson(e.data);
				if (data._error) {
					this._onError(data);
					this._worker = null; // don't reuse worker after an error...
				} else if(data._info) { console.log("[worker says:] " + data.message);
				} else {
					this._laidout = data;
					this._preLayoutDeferred.addCallback(lang.hitch(this,"_onComplete"));
				}
			});
			this._worker.onerror = lang.hitch(this, function(e){
				this._onError({ _error: true, responseText: e.message, workerError: e });
			});
			
			// Compute urls of dojo, ibm_ilog/graphlayout and ibm_ilog/diagram

			var baseUrl = this._getWorkerUrl(config.baseUrl);
			var graphlayoutUrl = this._getWorkerUrl(require.toUrl("ibm_ilog/graphlayout"));
			var diagramUrl = this._getWorkerUrl(require.toUrl("ibm_ilog/diagram"));

			this._worker.postMessage(baseUrl);
			this._worker.postMessage(graphlayoutUrl);
			this._worker.postMessage(diagramUrl);
			
		}
		
		// Now send the graph data:
		this._worker.postMessage(data);
	},
	
	_getWorkerUrl: function(url){
		return new _Url(window.doc.location.href, url).uri;
	},
	
	_stop: function()
	{
		if(this._worker){
			this._worker.terminate();
			this._worker = null; // cannot be reused after terminate()
		}
	}
});

return WebWorkerLayout;

});

