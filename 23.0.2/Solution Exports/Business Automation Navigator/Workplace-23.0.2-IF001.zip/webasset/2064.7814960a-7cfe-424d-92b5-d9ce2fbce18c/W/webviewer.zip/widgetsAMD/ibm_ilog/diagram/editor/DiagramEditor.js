/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"dojo/_base/config",
"dojo/_base/connect",
"dojo/_base/sniff",
"dojox/gfx",
"dojox/collections/Dictionary",
"../base",
"../widget/Diagram",
"../util/HandleSet",
"../Selectable",
"./interactors/DropInteractor",
"./adorners/ResizeAdorner",
"./adorners/ConnectionAdorner",
"./adorners/LinkConnectionAdorner",
"./adorners/LinkIntermediatePointsAdorner",
"./adorners/TextEditAdorner",
"./interactors/ResizeKeyInteractor",
"./interactors/DeleteKeyInteractor",
"./interactors/ConnectionKeyInteractor",
"./interactors/ClipboardKeyInteractor",
"./interactors/UndoManagerKeyInteractor",
"./interactors/InlineEditorKeyInteractor",
"../interactors/SwitchModeInteractor",
"../templates/editor_templates",
"./undo/UndoManager",
"./Clipboard",
"./DiagramSerializer",
"./EditingUtils",
"../util/ErrorReporter",
"../util/Geometry",
"../util/GraphUtil"
], function(
declare,
lang,
array,
config,
connect,
has,
gfx,
Dictionary,
iid,
Diagram,
HandleSet,
Selectable,
DropInteractor,
ResizeAdorner,
ConnectionAdorner,
LinkConnectionAdorner,
LinkIntermediatePointsAdorner,
TextEditAdorner,
ResizeKeyInteractor,
DeleteKeyInteractor,
ConnectionKeyInteractor,
ClipboardKeyInteractor,
UndoManagerKeyInteractor,
InlineEditorKeyInteractor,
SwitchModeInteractor,
editor_templates,
UndoManager,
Clipboard,
DiagramSerializer,
EditingUtils,
R,
g,
gu
)
{

/*=====
var Diagram = ibm_ilog.diagram.widget.Diagram;
=====*/

	var DiagramEditor =
	declare("ibm_ilog.diagram.editor.DiagramEditor", [Diagram], {
		//
		//	summary:
		//		This is an extension of the Diagram Dijit that provides editing capabilities.
		//
		//	description:
		//		In addition to the services from Diagram, this widget includes the following services:
		//
		//		- Can be a drag and drop target (look at samples/dnd/dnd.html)
		//		- Node/Subgraph resizing through adorners
		//		- Link creation and editing through adorners
		//
		_isIBMDiagramEditor: true,
		
		dropable: null,
		
		//
		//	allowFreeLinks: [markup] boolean
		//		this value determine if the interactors can create free links
		//		
		allowFreeLinks: null,
		
		//
		//	onDropFunction: [markup] function
		//		This function is called on diagram drop action
		//		format: DropFunction(droppedItem,point,Diagram,overElements,undoAction)
		//		
		onDropFunction: null,
		
		//
		//	onDropTemplateFunction: [markup] Boolean
		//		this function is called to determine the template on drop action
		// 		format: DropTemplateFunction(droppedItem,dataItem,diagram)
		//		
		onDropTemplateFunction: null,
		
		//
		//	allowCreateLinkFunction: [markup] function
		//		This function is called to know if it is allowed to create a new link between two nodes
		//		return true by default.
		//		format: allowCreateLinkFunction(DiagramEditor, startNode, endNode)
		//		
		allowCreateLinkFunction: null,
		
		//
		//	allowCreateNodeFunction: [markup] Boolean
		//		This function is called to know if it is allowed to create a new node
		//		return true by default.
		//		format: allowCreateNodeFunction(DiagramEditor, parentNode, childNode)
		allowCreateNodeFunction: null,
		
		
		//
		//  move: [markup] boolean
		//      enable or disable moving entities (true by default at DiagramEditor)
		//
		move: true,
		
		//	summary:
		//		Used to disable the initialization of inline-editable fields in the templates, lowering graphic overhead.
		//
		disableInlineEditors: false,
		
		// undoManager: this variables contains the UndoManager instance
		_undoManager: null,
		
		_adornersInitialized: false,
		_resizeAdorner: null,
		_connectionAdorner: null,
		_linkConnectionAdorner: null,
		_linkIntermediatePointsAdorner: null,
		
		enableDropable: function(enabled){
			if (this.dropable == null) {
				this.dropable = new DropInteractor(this, this.onDropFunction, this.onDropTemplateFunction);
			}
			if (enabled) {
				this.dropable.activate();
			} else {
				this.dropable.deactivate();
			}
		},
		
		postMixInProperties: function(){
			this.inherited(arguments);
			this._inlineEditors = new Dictionary();
		},
		
		postPostCreate: function(){
			connect.connect(this, "onNodeCreated", this, "_editorNodeCreated");
			connect.connect(this, "onLinkCreated", this, "_editorLinkCreated");
			connect.connect(this, "onSubgraphCreated", this, "_editorSubgraphCreated");
		},
		
		reset: function(){
			this.inherited(arguments);
			this._undoManager.reset();
			this._clipboard.clear();
		},
		
		// ========================================================================================================
		//
		//	INTERACTORS:
		//
		
		getAssociatedLinkAdornersFunction: function(ge){
			if (this._adornersInitialized) {
				return [this._linkConnectionAdorner, this._linkIntermediatePointsAdorner];
			} else {
				return [];
			}
		},
		
		getAssociatedNodeAdornersFunction: function(ge){
			if (this._adornersInitialized) {
				return [this._resizeAdorner, this._connectionAdorner];
			} else {
				return [];
			}
		},
		
		getAssociatedSubgraphAdornersFunction: function(){
			if (this._adornersInitialized) {
				if (config.useGfxLayout) {
					return [this._connectionAdorner];
				} else {
					return [this._resizeAdorner, this._connectionAdorner];
				}
			} else {
				return [];
			}
		},
		
		_initializeInteractors: function(){
			//
			//	summary:
			//		Initializes the interactors used by the Diagram
			//
			this._initializeUndoManager();
			
			this._initializeClipboard();
			
			this.inherited(arguments);
			
			this.enableDropable(true);
			
		},
		
		_initializeKeyInteractors: function(){
			//
			//	tags:
			//		private
			//
			this.inherited(arguments);
			
			this._keyInteractors.add(ResizeKeyInteractor.KeyInteractorId, new ResizeKeyInteractor().initialize(this));
			
			this._keyInteractors.add(DeleteKeyInteractor.KeyInteractorId, new DeleteKeyInteractor().initialize(this));
			
			this._keyInteractors.add(ConnectionKeyInteractor.KeyInteractorId, new ConnectionKeyInteractor().initialize(this));
			
			this._keyInteractors.add(ClipboardKeyInteractor.KeyInteractorId, new ClipboardKeyInteractor().initialize(this));
			
			this._keyInteractors.add(UndoManagerKeyInteractor.KeyInteractorId, new UndoManagerKeyInteractor().initialize(this));
			
			this._keyInteractors.add(InlineEditorKeyInteractor.KeyInteractorId, new InlineEditorKeyInteractor().initialize(this));
			
			var edition = this._keyInteractors.get(SwitchModeInteractor.KeyInteractorId);
			edition.addEditionInteractorId(ResizeKeyInteractor.KeyInteractorId);
			edition.enterNavigation();
			
		},
		
		_initializeUndoManager: function(){
			this._undoManager = new UndoManager(this);
		},
		
		registerInlineEditor: function(id, editor){
			//
			//	summary:
			//		Registers a new inline editor with a certain id.
			//	id: string
			//		The associated id for referencing the editor from editable attachpoints at graph element templates.
			//	editor: ibm_ilog.diagram.editor.adorners.TextEditAdorner
			//		The adorner used as editor.
			this._inlineEditors.add(id, editor);
		},
		
		_createAdorners: function(){
			this.inherited(arguments);
			this._resizeAdorner = this.createAdorner(ResizeAdorner, this._adornerTemplates, "ResizeAdorner");
			this._connectionAdorner = this.createAdorner(ConnectionAdorner, this._adornerTemplates, "ConnectionAdorner");
			this._linkIntermediatePointsAdorner = this.createAdorner(LinkIntermediatePointsAdorner, this._adornerTemplates, "LinkIntermediatePointsAdorner");
			this._linkConnectionAdorner = this.createAdorner(LinkConnectionAdorner, this._adornerTemplates, "LinkConnectionAdorner");
			this.registerInlineEditor("textbox", this.createAdorner(TextEditAdorner, this._adornerTemplates, "TextEditAdorner"));
			this.getInlineEditorId("textbox").textbox.prepare(this.canvasNode);
			this._adornersInitialized = true;
		},
		
		enterStandardMode: function(){
			//
			//	summary:
			//		TODO TBD. Probably to be renamed also
			//    	
			this._interactors.switchTo("move", "select", "pan", "zoom", "focus", "adorners", "marquee", "wheelPan");
			
		},
		resolveNodeTemplate: function(item){
			// summary:
			//    Returns the template to represent the specified node item.
			//    item: dojo.data.Item: the node data item.
			var dropTemplate = (this.dropable && this.dropable.isDropAction()) ? this.dropable.resolveNodeTemplate(item) : null;
			return dropTemplate != null ? dropTemplate : this.inherited(arguments);
			
		},
		setAcceptedDropTypes: function(types){
			// summary:
			//    Sets the accepted types to be dropped.
			if (this.dropable != null) {
				this.dropable.setAcceptedTypes(types);
				this.enableDropable(false);
				this.enableDropable(true);
			}
		},
		
		getDropInteractor: function(){
			// summary:
			//    return the drop interactor
			return this.dropable;
		},
		
		onLinkUpdated: function(diagram, link, isNew, undoAction){
			// sumamry:
			//		The user must connect to this function to create the link in the linkstore or customize the created link.
			// diagram: ibm_ilog.diagram.editor.DiagramEditor
			//		this is the DiagramEditor instance.
			// link: ibm_ilog.diagram.Link
			//		the updated link.
			// isNew: boolean
			//		identify if the link is recently created (true) or just modified (false).
			// undoAction: ibm_ilog.diagram.editor.undo.Action
			//		the Action that take place in this edition
		},
		
		allowCreateLink: function(startNode, endNode){
			// summary:
			//		evaluates if the link between two nodes can be created, based on the allowCreateLinkFunction
			// startNode: ibm_ilog.diagram.Node
			//		the possible link start node
			// enNode: ibm_ilog.diagram.Node
			//		the possible link end node
			return this.allowCreateLinkFunction ? this.allowCreateLinkFunction.call(null, this, startNode, endNode) : true;
		},
		
		allowCreateNode: function(parent, child){
			// summary:
			//		evaluates if the nodes can be created, based on the allowCreateLinkFunction
			// parent: ibm_ilog.diagram.Node
			//		the possible parent of the node
			// child: ibm_ilog.diagram.Node
			//		the created node
			return this.allowCreateNodeFunction ? this.allowCreateNodeFunction.call(null, this, parent, child) : true;
		},
		
		getUndoManager: function(){
			// summary:
			//		return the private instance of ibm_ilog.diagram.editor.undo.UndoManager
			return this._undoManager;
		},
		
		getAllowFreeLinks: function(){
			// summary:
			//		This method is deprecated from 1.1. Use dojo.get('allowFreeLinks') instead.
			//		true, if the diagram allow free links (links with no end or start node)
			return this.allowFreeLinks ? this.allowFreeLinks : false;
		},
		
		setAllowFreeLinks: function(allowFreeLinks){
			// summary:
			//		This method is deprecated from 1.1. Use dojo.set('allowFreeLinks', value) instead.
			//		Sets if the diagram allow free links (links with no end or start node)
			// allowFreeLinks: boolean
			// 		true, if the diagram allow free links (links with no end or start node)
			this.allowFreeLinks = allowFreeLinks;
		},
		
		
		// ========================================================================================================
		//
		//	INLINE EDITORS:
		//
		
		//
		//	defaultEditableRegionStyle:
		//		The style to be used for the editable region
		//
		defaultEditableRegionStyle: {
			fill: [0, 0, 0, 0.001],
			selectedStyle: {
				stroke: {
					style: 'ShortDot',
					color: 'black'
				}
			}
		},
		
		_isAttachPointEditable: function(a){
			//	summary:
			//		returns true if an attachPoint has a valid editable region information 
			//	a: the component
			return (a.shape.type == "text" || a.shape.type == "mltext") && a.editable && a.editable.editor && this._inlineEditors.contains(a.editable.editor) && (a.editable.id || (a.editable.getter && a.editable.setter));
		},
		
		_getEditableRegionBoundingBox: function(a){
			//	summary:
			//		returns the bounding box of the editable component
			//	a: the component that was declared editable
			var empty = g.EmptyRect, bb = a.getBoundingBox(), ed = a.editable;
			if (ed.baseRegion) {
				if (!bb) {
					bb = ed.baseRegion;
				} else {
					bb = g.addRect(bb, ed.baseRegion);
				}
			}
			if (ed.minRegionSize) {
				if (!bb) {
					bb = g.standarizeRect(ed.minRegionSize);
				} else {
					var w = ed.minRegionSize.width;
					var h = ed.minRegionSize.height;
					if (w) {
						bb = g.rectCenteredOverride(bb, {
							width: Math.max(w, bb.width)
						});
					}
					if (h) {
						bb = g.rectCenteredOverride(bb, {
							height: Math.max(h, bb.height)
						});
					}
				}
			}
			if (!bb) 
				bb = empty;
			var tr = a.getTransform();
			if (tr) {
				bb = tr.transformRectangle(bb);
			}
			if (ed.border && bb) {
				bb = g.expandRect(bb, ed.border);
			}
			return bb || empty;
		},
		
		_onEditableTextChanged: function(a, ge, er){
			//	summary:
			//		updates the editable region shape when its bounds have changed
			//	a: the component that was declared editable
			//	ge: the graph element
			//	er: the editable region shape
			
			if (has("ie") > 7 && iid.isVml && er.__ie8Handler !== undefined) {
				// dispose the handler set to solve ie8/vml setShape issue (see _createEditableRegionShape)
				er.disconnect(er.__ie8Handler);
			}
			er.setShape(this._getEditableRegionBoundingBox(a));
			if(er.computePreferredSize) er.computePreferredSize({width:-1, height:-1});
		},
		
		_createEditableRegionShape: function(a, ge){
			//	summary:
			//		created the editable region shape associated with an editable component
			//	a: the component that was declared editable
			//	ge: the graph element
			var editable = a.editable;
			var bb = this._getEditableRegionBoundingBox(a);
			var editableBaseShape = a.parent.createRect(bb);
			
			var style = lang.clone(this.defaultEditableRegionStyle || {});
			lang.mixin(style, editable.regionStyle);
			
			gu.applyStyle(editableBaseShape, style);
			
			if (editable.layoutProperties) 
				lang.mixin(editableBaseShape, editable.layoutProperties);
			
			if (gfx.renderer == "silverlight") {
				editableBaseShape.connect("onclick", this, function(){
					this._openInlineEditor(ge, a, editableBaseShape);
				});
			} else {
				editableBaseShape.connect("ondblclick", this, function(){
					this._openInlineEditor(ge, a, editableBaseShape);
				});
				// The edit shape can easily hide the expand button, so listen to clicks on the edit shape
				// and forward them to the button if necessary.
				if(ge._isIBMDiagramSubgraph){
					editableBaseShape.connect("onclick", this, function(e){
						var p = this.getViewport().eventContentLocation(e);
						if(ge.isCollapsed()){
							var b = ge._expandButton;
							if(b){
								var bb = b.getBoundingBox();
								if(bb){
									bb = b.getShapeToContainerTransform(this.getGraph()).transformRectangle(bb);
									if(g.containsPoint(bb, p)){
										ge._expandButtonClicked(e);
									}
								}
							}
						}
					});
				}
			}
			
			if (has("ie") > 7 && iid.isVml){
				connect.connect(editableBaseShape, 'setShape', this, function(){
					// in IE8/VML Rect.setShape creates a new rawNode. need to update the connections
					editableBaseShape.__ie8Handler = editableBaseShape.connect("ondblclick", this, function(){
						this._openInlineEditor(ge, a, editableBaseShape);
					});
				});
			}

			
			return editableBaseShape;
		},
		
		getInlineEditorId: function(id){
			//	summary:
			//		returns the inline editor registered with the given id
			return this._inlineEditors.item(id);
		},
		
		_openInlineEditor: function(ge, a, editableBaseShape){
			//	summary:
			//		opens an inline editor on the component a of graph element ge
			//	ge: the graph element
			//	a: the editable attachpoint
			//	editableBaseShape: the editable region shape
			this.visualizeBounds(ge, {
				expandCurrent: true
			});
			
			var e = this.getInlineEditorId(a.editable.editor), set, get;
			
			if (a.editable.id) {
				var uname = (a.editable.id.substr(0, 1).toUpperCase()) + a.editable.id.substr(1);
				get = "get" + uname;
				set = "set" + uname;
			} else {
				get = a.getter;
				set = a.setter;
			}
			if (a.editable.options) {
				e.setOptions(a.editable.options);
			}
			e.setAccessors(function(adorned){
				return adorned[get]();
			}, function(adorned, value){
				adorned[set](value);
			});
			
			e.setComponentAttachPoint(a);
			e.setComponent(editableBaseShape);
			e.setAdorned(ge);
		},
		
		initializeEditables: function(ge){
			//	summary:
			//		scan the attachpoints of graph element ge in search for editable 
			//		fields initialize the corresponding infrastructure to allow editing.  
			//	ge: the graph element
			if (!this.disableInlineEditors) {
				var maybeEditables = ge._attachPoints;
				array.forEach(ge._attachPoints, function(id){
					var a = ge[id];
					if (this._isAttachPointEditable(a)) {
						try {
							var editableBaseShape = this._createEditableRegionShape(a, ge);
							var textChanged = function(){
								this._onEditableTextChanged(a, ge, editableBaseShape);
							};
							
							// TODO need a.onChange here
							ge.addConnection(connect.connect(a, "setShape", this, textChanged));
							ge.addConnection(connect.connect(a, "setFont", this, textChanged));
							if (a.applyLayout) 
								ge.addConnection(connect.connect(a, "applyLayout", this, textChanged));
							if (ge._isIBMDiagramSubgraph) {
								ge.addConnection(connect.connect(ge, "onCollapsedChanged", this, textChanged));
							}
							ge.__editables = (ge.__editables || []);
							ge.__editables.push({
								ge: ge,
								attach: a,
								base: editableBaseShape
							});
						} catch (e) {
							R.warn("Wrapped", "DiagramEditor.js # initializeEditables", e);
						}
					}
				}, this);
			}
		},
		
		getEditables: function(ge){
			//
			//	summary:
			//		Return the editable attachpoints of a graph element
			//	ge:
			//		ibm_diargram.GraphElement
			//	returns:
			//		The set of the editable attachpoint belonging to a graph element.
			//
			return ge.__editables;
		},
		
		openEditableInlineEditor: function(editable){
			//
			//	summary:
			//		Open the inline editor associated with a graph element editable attachpoint.
			//	editable: {ge:,attach:,base:}
			//		The editable attachpoint belonging to a graph element.
			//
			this._openInlineEditor(editable.ge, editable.attach, editable.base);
		},
		
		_editorNodeCreated: function(node, diagram){
			this.initializeEditables(node);
		},
		
		_editorSubgraphCreated: function(subgraph, diagram){
			this.initializeEditables(subgraph);
		},
		
		_editorLinkCreated: function(link, diagram){
			this.initializeEditables(link);
		},
		
		// ========================================================================================================
		//
		//	CLIPBOARD:
		//
		_clipboard: null,
		
		_initializeClipboard: function(){
			this._clipboard = new Clipboard(this);
		},
		getClipboard: function(){
			// summary:
			//		return the private instance of ibm_ilog.diagram.editor.Clipboard
			return this._clipboard;
		},
		
		// =========================================================================================================
		//
		//	RemoveSerializer:
		// 
		
		_removeSerializer: null,
		
		_getRemoveSerializer: function(){
			var thiz = this;
			if (!this._removeSerializer) {
				var notificationObject = {
					diagram: thiz,
					onSerialize: function(graphElement, serializedData){
					},
					onDeserialize: function(serializedData, newGraphElement, container, undoAction){
						var um = this.diagram.getUndoManager();
						um.registerGraphElementReplacement(serializedData.id, newGraphElement.getId());
					}
				};
				this._removeSerializer = new DiagramSerializer(this, null, notificationObject);
			}
			return this._removeSerializer;
		},
		
		// doDeleteFunction: Function
		// An optional function that handles delete operation and returns a corresponding Action
		// to be added to the undo manager (see ibm_ilog.diagram.editor.undo.Action). If no function
		// is specified, the default behavior is to remove and dispose the graphical shapes from the diagram
		// without any datastore-related considerations.
		// The function receives the following parameters:
		//		diagram: ibm_ilog.diagram.widget.Diagram. The diagram containing the elements to remove.
		//		elements: ibm_ilog.diagram.GraphElement. The graphical elements to delete.
		// The function must returns a ibm_ilog.diagram.editor.undo.Action instance that matches the function implementation (aka:
		// capable of undoing the deletion).
		doDeleteFunction : null,
		
		deleteGraphElements: function(/*ibm_ilog.diagram.GraphElement[]*/elements){
			// summary:
			//		Deletes the selected elements and all the connected links. 
			// description:
			//		This method should be invoked to delete the specified elements from the diagram and handles the 
			//		interface with the undo manager. The way the delete operation
			//		itself is performed may be customized by setting the doDeleteFunction property to a custom implementation. The
			//		default implementation removes and disposes the graphical shapes from the diagram without any datastore-related
			//		considerations. If you need to change this behavior, set this property so that it gets invoked instead of the default implementation.
			// elements: ibm_ilog.diagram.GraphElement[]
			// 		The elements to delete.
			// returns:
			//		true if the deletion could be performed, false otherwise.
		
			if (elements) {
				var action = EditingUtils.deleteGraphElements(this, elements, this.doDeleteFunction);
				var um = this.getUndoManager();
				um.addAction(action);
				return true; // Boolean
			}
			return false; // Boolean
		},
		
		// marks the end of definition to make life easier with trailing '},'...
		__eod: null
	});
	
	return DiagramEditor;
	
});

