/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare", "dojo/_base/connect", "dojo/_base/event",
"./Interactor",
"../util/Geometry", "../util/GraphUtil"
],
function(
declare, connect, event,
Interactor,
g, gu
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var AdornerFocusInteractor =
declare("ibm_ilog.diagram.interactors.AdornerFocusInteractor", [Interactor], {
	//
	//	summary:
	//		This interactor sets the diagram widget adorners focus 
	//		according to current mouse location. 
	//
	
	//
	//	_viewport: ibm_ilog.diagram.widget.Viewport
	//		The diagram viewport 
	//
	_viewport: null,

	//
	//	_diagram: ibm_ilog.diagram.widget.Diagram
	//
	_diagram: null,

	_nodeMargin: 15,
	_linkMargin: 15,

	_lowCpuMode: null,

	_lastPosition: null,
	
	initialize: function ( /*ibm_ilog.diagram.widget.Diagram*/ diagram) {
		this._diagram = diagram;
		this._viewport = diagram.getViewport();
		this._initialize();
		this._lowCpuMode = this._diagram.isLowCpuMode();
		
		connect.connect(this._diagram, 'lowCpuModeChange', this, function () {
			this._lowCpuMode = this._diagram.isLowCpuMode();
			this.deactivate();
			this._initialize();
		});
		
		this._lastPosition = {
			x: 0,
			y: 0
		};
		return this;
	},

	_declareStates: function () {
		if (this._lowCpuMode == true) {
			this._declareState("idle", ["nodeover", "linkover", "subgraphover", "testfreecursor","onLeaveSurface"]);
		} else {
			this._declareState("idle", ["detectOnOver","onLeaveSurface"]);
		}
	},

	getDefaultConnections: function () {
		//
		//	summary:
		//		returns the default event mapping
		//
		return {
			nodeover: {
				src: this._diagram,
				srcEvt: "onNodeMouseOver",
				connectTo: "_setNodeAdornersFocus"
			},
			linkover: {
				src: this._diagram,
				srcEvt: "onLinkMouseOver",
				connectTo: "_setNodeAdornersFocus"
			},
			subgraphover: {
				src: this._diagram,
				srcEvt: "onSubgraphMouseOver",
				connectTo: "_setNodeAdornersFocus"
			},
			testfreecursor: {
				gfxConnect: true,
				src: this._viewport.getEventSource(),
				srcEvt: "onmousemove",
				connectTo: "_testFreeCursor"
			},
			detectOnOver: {
				src: this._viewport.getEventSource(),
				srcEvt: "onmousemove",
				connectTo: "_detectOnOver",
				gfxConnect: true
			},
			onLeaveSurface: {
				src: this._diagram.domNode,
				srcEvt: "onmouseleave",
				connectTo: "_onLeaveSurface"
			}
		};
	},
	
	_onLeaveSurface: function(e) {
		// Check if we are completely outside of the surface,
		// in that case we get no move event so we must free the adorners.
		var out = false;
		var l = this._viewport.eventClientLocation(e);
		if(l.x <= 0 || l.y <= 0){
			out = true;
		} else {
			var d = this._viewport.getClientSize();
			if(l.x >= d.width || l.y >= d.height)
				out = true;
		}
		if(out){
			this._freeCursor();
			this._freeLinkCursor();
		}
	},

	_setNodeAdornersFocus: function (ge, e) {
		// Summary:
		//		Sets the appropriate cursor, according to the ge element. Release the previous cursor, id applied.
		//		
		var cursorIsFree = this._diagram.getNodeAdornersFocus() == null;
		if (!ge._isIBMDiagramLink && (cursorIsFree || gu.isContainedBy(ge, this._diagram.getNodeAdornersFocus()))) {
			this._freeLinkCursor(null);
			this._diagram.setNodeAdornersFocus(ge);
			event.stop(e);
		} else if (ge._isIBMDiagramLink) {
			this._freeCursor(null);
			this._diagram.setLinkAdornersFocus(ge);
			event.stop(e);
		}
	},

	onEnabled: function () {
		this._goStateId("idle");
	},

	onDisabled: function () {
		this._goState(null);
		this._freeCursor();
	},

	_freeCursor: function (e) {
		// Summary:
		//		Free the node/subgraph cursor
		//
		this._diagram.setNodeAdornersFocus(null);
	},

	_freeLinkCursor: function (e) {
		// Summary:
		//		Free the link cursor
		//
		this._diagram.setLinkAdornersFocus(null);
	},

	_testFreeCursor: function (e) {
		// Summary:
		//		Free the cursor testing the bounding box (adding a margin)
		//
		var D = this._viewport.getDiagram();
		var c = this._diagram.getNodeAdornersFocus();
		if (c) {
			var outOfBounds;
			var bb = g.expandRect(c.getBounds(this._viewport.getSurface()), this._nodeMargin);
			var l = this._viewport.eventClientLocation(e);
			outOfBounds = !g.containsPoint(bb, l);
			if (D.mustFreeAdornersFocus(c, p, this._nodeMargin, outOfBounds)) {
				this._freeCursor();
			}
		}
		c = this._diagram.getLinkAdornersFocus();
		if (c) {
			var V = this._viewport;
			var p = V.eventContentLocation(e);
			outOfBounds = !c.hitTest(p, D.getGraph(), this._linkMargin);
			if (D.mustFreeAdornersFocus(c, p, this._linkMargin, outOfBounds)) {
				this._freeLinkCursor();
			}
		}
	},

	_detectOnOver: function (e) {
		//added to increase performance
		var current = {
			x: e.pageX,
			y: e.pageY
		};
		var delta = {
			x: Math.abs(current.x - this._lastPosition.x),
			y: Math.abs(current.y - this._lastPosition.y)
		};
		var minDelta = 2;
		if (delta.x < minDelta && delta.y < minDelta) {			
			return;
		}
		this._testFreeCursor(e);
		var p = this._viewport.eventContentLocation(e);
		var ges = this._diagram.getGraph().hitTest(p, 4);
		var ge = this._changeFocus(ges);
		if (ge) {
			this._setNodeAdornersFocus(ge, e);
		}
		this._lastPosition = {
			x: current.x,
			y: current.y
		};

	},
	_changeFocus: function (ges) {
		if (ges.length > 0) {
			var D = this._viewport.getDiagram();
			var anyCursor = this._diagram.getNodeAdornersFocus() || this._diagram.getLinkAdornersFocus();
			var changeAdornersFocus = true;
			// Adrian: now no longer depends on the selection state.
			//   Cf. Defect 2111.
			if (anyCursor && (/* anyCursor.isSelected() || */ anyCursor._isIBMDiagramLink)) {
				changeAdornersFocus = false;
			}

			var newge = ges[0];
			/* Adrian: now no longer depends on the selection state.
			   Cf. Defect 2111.
			for (var index in ges) {
				if (ges[index].isSelected()) {
					newge = ges[index];
					break;
				}
			}
			*/
			/* Adrian: Old comment already present before my changes for defect 2111.
			var newge = null;
			for(var index in ges){
				if(ges[index].isSelected()){
					newge = ges[index];
					break;
				}else{
					if(!newge && ges[index]._isIBMDiagramNode){
						newge = ges[index];
					}
				}
			}
			newge = newge?newge:ges[0];
			*/
			// Adrian: now no longer depends on the selection state.
			// Cf. defect 2111
			if (newge._isIBMDiagramLink /* && !newge.isSelected() */) {
				if (anyCursor && anyCursor._isIBMDiagramNode && !gu.isContainedBy(newge, anyCursor)) {
					changeAdornersFocus = false;
				}
			}

			return D.changeAdornersFocus(anyCursor, newge, ges, changeAdornersFocus);
		}
		return null;
	}
});

return AdornerFocusInteractor;

});
