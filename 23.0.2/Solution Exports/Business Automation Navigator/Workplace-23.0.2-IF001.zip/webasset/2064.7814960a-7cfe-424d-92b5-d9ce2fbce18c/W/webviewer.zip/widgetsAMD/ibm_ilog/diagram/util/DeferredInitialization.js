/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/declare", "dojo/_base/connect", "./GlobalInitialization"],
function(declare, connect, gi){
	
	var di = declare("ibm_ilog.diagram.util.DeferredInitialization",[],{
		//
		//	summary:
		//		Provide the users of the class with a whenLoaded(cb) API for
		//		waiting for instances to finish initialization. Also subscribes
		//		the instance to the global initialization coordinator for global
		//		synchrinzation.
		//
		__initialized: false,
		
		_beginInit: function() {
			//
			//	summary:
			//		Begins initialization process.
			//
			this.__initialized = false;
	    	gi.beginInit();
	    },
	    
	    _endInit: function() {
			//
			//	summary:
			//		Finishes initialization process, subsequently executing all 
	    	//		registered callbacks.
			//
			this.__initialized = true;
	    	gi.endInit();
	    },
        
        isInitialized: function(){
            // summary:
            //     Returns whether the initialization process is done.
            return this.__initialized;
        },
	    
	    _defaultErrorHandler: function() {
	    	console.log(arguments);
	    },
	    
	    whenLoaded: function(cb,eb) {
			//
			//	summary:
			//		Registers a callback to be executed after the instance has 
	    	//		been initialized, or executes immediately if already initialized.
			//
	    	if(this.__initialized) {
	    		cb();
	    	} else {
		    	var h = connect.connect(this,"_endInit",function(){
		    		cb();
		    		connect.disconnect(h);
		    	});
	    	}
	    	return this;
	    }
    
	});
	
	return di;
});
