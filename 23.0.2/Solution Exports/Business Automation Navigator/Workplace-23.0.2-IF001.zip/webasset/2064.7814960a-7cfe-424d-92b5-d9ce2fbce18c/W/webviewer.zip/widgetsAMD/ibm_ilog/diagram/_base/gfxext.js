/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["../main", "dojo/_base/lang", "dojo/_base/declare", "dojo/_base/config", "dojo/_base/array",
"dojo/_base/html", "dojo/_base/window", "dojo/_base/sniff", "dojo/dom",
"dojox/gfx", "dojox/gfx/shape", "dojox/gfx/utils", "dojox/gfx/matrix",
"dojo/has!config-isBidiInDojoDiagrammer?../util/BidiUtil:"],
function(iid, lang, declare, config, arr, html, win, has, dom, g, gs, gfxu, matrix, BidiUtil){

	// TODO:
	// For now we must create a global object since there are still references to ibm_ilog.diagram._base.gfxext
	// in the rest of the code, but when AMD migration is finished all global references should be replaced
	// by module references and this will be replaced by a simple object creation:
	// var ge = {};
	var ge = lang.getObject("ibm_ilog.diagram._base.gfxext", true);
	
	var renderer = g.renderer;
	switch (renderer) {
		case 'vml':
			iid.isVml = true;
			break;
		case 'svg':
			iid.isSvg = true;
			if (g.svg.useSvgWeb) {              
				iid.isSvgWeb = true;
			}			
			break;
		case 'silverlight':
			iid.isSilverlight = true;
			break;
		case 'canvas':
		case 'canvasWithEvents':
			iid.isCanvas = true;
			break;
	}
	
	iid.mobileEnabled = iid.isSilverlight ? false : true;
	
	// VML Container.add fix for Dojo >= 1.6:
	if (iid.isVml) {
		// Surface/Group.add in Dojo 1.6+ will call setShape and setFont recursively
		// on all children of the Group. This causes trouble in our code because we
		// trap these methods to notify changes in parents. To avoid this, we set
		// a global flag saying that we are inside add, and we should not propagate
		// notifications up. The flag is also checked in the MultilineText object
		// to avoid re-wrapping text.
		// Update in DD 1.1.1: Container.add is really too slow, we patch it to get acceptable perfs.
		// This can be turned off by dojoConfig { patchGfxAdd: false; }
		// Update: this is now done directly in GFX (config.fixVmlAdd) but wee keep this flag
		// just in case, because our fix should be slightly faster than GFX's patch
		// (we do not update at all any style while GFX updates the fill/stroke of the shape)
		var patchGfxAdd = config.patchGfxAdd;
		var oldAdd = !patchGfxAdd ? g.vml.Surface.prototype.add :
		function(shape){
			if (this != shape.getParent()) {
				this.rawNode.appendChild(shape.rawNode);
				gs.Container.add.call(this, shape);
			}
		};
		var myAdd = function(shape){
			var oldInAdd = iid._inContainerAdd;
			iid._inContainerAdd = true;
			oldAdd.call(this, shape);
			iid._inContainerAdd = oldInAdd;
			return this; // self
		};
		
		g.vml.Surface.prototype.add = myAdd;
		g.vml.Group.prototype.add = myAdd;
	}
	
	//
	// uniqueId generator
	//
	var _currentId = 0;
	iid._IdGenerator = {};
	iid._IdGenerator.nextId = function(obj) {
		return ++_currentId;
	};
	
	// "invisible location" values:
	if(!iid.isVml){
		iid._invisibleLocation = -10000;
		iid._invisibleSize = 1010;
	} else {
		iid._invisibleLocation = 100000;
		iid._invisibleSize = 10;
	}
	
	ge.patchMethod = function(/*Object*/type, /*String*/ method, /*Function*/ execBefore, /*Function*/ execAfter) {
		// summary:
		//     Patches the specified method of the given type so that the 'execBefore' (resp. 'execAfter') function is 
		//     called before (resp. after) invoking the legacy implementation.
		// description:
		//     The execBefore function is invoked with the following parameter:
		//     execBefore(method, arguments) where 'method' is the patched method name and 'arguments' the arguments received
		//     by the legacy implementation.
		//     The execAfter function is invoked with the following parameter:
		//     execBefore(method, returnValue, arguments) where 'method' is the patched method name, 'returnValue' the value
		//     returned by the legacy implementation and 'arguments' the arguments received by the legacy implementation.
		// type: Object: the type to patch.
		// method: String: the method name.
		// execBefore: Function: the function to execute before the legacy implementation. 
		// execAfter: Function: the function to execute after the legacy implementation.
		var old = type.prototype[method];
		type.prototype[method] = function() {
			var callee = method;
			if (execBefore) 
				execBefore.call(this, callee, arguments);
			var ret = old.apply(this, arguments);
			if (execAfter) 
				ret = execAfter.call(this, callee, ret, arguments) || ret;
			return ret;
		};
	};
	
	// SVGWeb fix
	if(iid.isSvgWeb){
		var svg = g.svg;
		var oldcs = svg.createSurface;
		svg.createSurface = function(parentNode, width, height){
			var s = oldcs.call(this, parentNode, width, height);
			s._parent = dom.byId(parentNode);
			return s;
		};
		if(svg != g)
			g.createSurface = svg.createSurface;
	}
	
	//
	// Silverlight event conversion fix
	// Fixes:
	//  1.  e.target should be mapped to EventArgs.Source
	//  2.  e.pageX/pageY are added so that it does not break the interactions code
	// COO: Code borrowed from dojox/gfx/silverlight.js
	if (iid.isSilverlight) {
		
		lang.extend(g.Group, {
			_setFillAttr : function() {}
		});
		
		
	    var surfaces = g.silverlight.surfaces;
		var mouseFix = function(s, a) {
			var ev = {
				target: s,
				currentTarget: s,
				preventDefault: function() {
				},
				stopPropagation: function() {
				}
			};
			if (a) {
				try {
					// BEGIN PATCH
					if (a.source) // source is defined from Silverlight 2+
						ev.target = a.source;
					// END PATCH
					ev.ctrlKey = a.ctrl;
					ev.shiftKey = a.shift;
					var p = a.getPosition(null);
					ev.x = ev.offsetX = ev.layerX = p.x;
					ev.y = ev.offsetY = ev.layerY = p.y;
					// calculate clientX and clientY
					var parent = s.getHost().parentNode;//surfaces[s.getHost().content.root.name];
					var t = html.position(parent);
					ev.clientX = t.x + p.x;
					ev.clientY = t.y + p.y;
					// BEGIN PATCH 2
					var d = (win.doc.documentElement && win.doc.documentElement.scrollLeft != null) ? win.doc.documentElement : win.doc.body;
					ev.pageX = ev.clientX + d.scrollLeft;
					ev.pageY = ev.clientY + d.scrollTop;
					// END PATCH 2
				} catch (e) {
					// squelch bugs in MouseLeave's implementation
				}
			}
			return ev;
		};
		var keyFix = function(s, a) {
			var ev = {
				keyCode: a.platformKeyCode,
				ctrlKey: a.ctrl,
				shiftKey: a.shift
			};
			// BEGIN PATCH
			if (a.source) // source is defined from Silverlight 2+
				ev.target = a.source;
			// END PATCH
			return ev;
		};
		var eventNames = {
			onclick: {
				name: "MouseLeftButtonUp",
				fix: mouseFix
			},
			onmouseenter: {
				name: "MouseEnter",
				fix: mouseFix
			},
			onmouseleave: {
				name: "MouseLeave",
				fix: mouseFix
			},
			onmouseover: {
				name: "MouseEnter",
				fix: mouseFix
			},
			onmouseout: {
				name: "MouseLeave",
				fix: mouseFix
			},
			onmousedown: {
				name: "MouseLeftButtonDown",
				fix: mouseFix
			},
			onmouseup: {
				name: "MouseLeftButtonUp",
				fix: mouseFix
			},
			onmousemove: {
				name: "MouseMove",
				fix: mouseFix
			},
			onkeydown: {
				name: "KeyDown",
				fix: keyFix
			},
			onkeyup: {
				name: "KeyUp",
				fix: keyFix
			}
		};
		var eventsProcessing = {
			connect: function(name, object, method) {
				var token, n = name in eventNames ? eventNames[name] : {
					name: name,
					fix: function() {
						return {};
					}
				};
				if (arguments.length > 2) {
					token = this.getEventSource().addEventListener(n.name, function(s, a) {
						lang.hitch(object, method)(n.fix(s, a));
					});
				} else {
					token = this.getEventSource().addEventListener(n.name, function(s, a) {
						object(n.fix(s, a));
					});
				}
				return {
					name: n.name,
					token: token
				};
			},
			disconnect: function(token) {
				this.getEventSource().removeEventListener(token.name, token.token);
			}
		};
		lang.extend(g.silverlight.Shape, eventsProcessing);
		lang.extend(g.silverlight.Surface, eventsProcessing);
		// COO END
	}
	
	//
	// Extends createShape to support our own shape types
	//
	
	var extendCreateShape = function(callee, ret, args) {
		if (!ret) {
			var sh = args[0];
			switch (sh.type) {
				case 'graph':
					ret = this.createObject(iid.Graph);
					break;
				case 'node':
					ret = this.createObject(iid.Node);
					break;
				case 'link':
					ret = this.createObject(iid.Link);
					break;
				case 'subgraph':
					ret = this.createObject(iid.Subgraph);
					break;
				case 'swimlane':
					ret = this.createObject(iid.SwimLane);
					break;
			}
		}
		return ret;
	};
	ge.patchMethod(g.Surface, "createShape", null, extendCreateShape);
	ge.patchMethod(g.Group, "createShape", null, extendCreateShape);
	
	var vmlFixList = [];
	
	var needsVmlFix = function(instance) {
		for (var i = 0; i < vmlFixList.length; ++i) {
			if (instance instanceof vmlFixList[i]) {
				return true;
			}
		}
		return false;
	};
	
	iid.gfxDeclaration = function(ctor) {
		ctor.nodeType = g.Group.nodeType;
		vmlFixList.push(ctor);
		return ctor;
	};
	
	iid.gfxDeclare = function(name, superclass, declarations) {
		//
		//	NOTE: warning, this may break dojo doc tools
		//
		var ctor = declare.apply(dojo, arguments);
		return iid.gfxDeclaration(ctor);
	};
	
	//
	// Fix VML createObject to perform additional initializations
	// performed in VML createObject implementation.
	//
	
	if (iid.isVml) {
		var fixVMLCreateObject = function(callee, ret, args) {
			var shape = ret;
			if ((iid.Node && (shape instanceof iid.Node)) ||
			(iid.Graph && (shape instanceof iid.Graph)) ||
			(iid.Subgraph && (shape instanceof iid.Subgraph)) ||
			(iid.Link && (shape instanceof iid.Link)) ||
			(needsVmlFix(shape))) {
			
				// Call Creator._overrideSize
				var node = shape.rawNode;
				this._overrideSize(node);
				
				// Need to do vml-specific createGroup tasks
				// see dojox.gfx.vml.js/createGroup()
				var r = shape.rawNode.ownerDocument.createElement("v:rect");
				r.style.left = r.style.top = 0;
				r.style.width = shape.rawNode.style.width;
				r.style.height = shape.rawNode.style.height;
				r.filled = r.stroked = "f";
				shape.rawNode.appendChild(r);
				shape.bgNode = r;
			}
		};
		ge.patchMethod(g.Surface, 'createObject', null, fixVMLCreateObject);
		ge.patchMethod(g.Group, 'createObject', null, fixVMLCreateObject);
	}
	
	//
	// Change notifications
	//
	
	ge.propagateChange = function(source, reason) {
		for (var shape = source; shape && !shape._noOnChanged && shape.getParent; shape = shape.getParent()) {
			if (shape._onChanged) 
				shape._onChanged(source, reason);
		}
	};
	
	(function() {
		var fixvml = iid.isVml;
		// a function used to propagate the change notification to the hierarchy
		var onChangeFunc = function(callee, ret, args) {
			if(iid._inContainerAdd) return;
			if (config.useGfxLayout) {
				this.__shapeSet(callee);
				// no need to invalidate top-level panels that are translated.
				var p = this.getParent();
				if (callee !== 'setTransform' || (p && p.getLayout && p.getLayout())) 
					this.invalidate();
			}
			ge.propagateChange(this, callee);
		};
		// make it accessible from outside (used in MultilineText as it overrides the setShape method
		// and therefore delete the patch
		ge.onChangePatch = onChangeFunc;
		 		
		// a patched function for vml to be called before the original function 
		var vmlFixRawNodePath = function() {
			if (!this.rawNode.path) 
				this.rawNode.path = {};
		};
		
		//Bidi support functions
		if (config.isBidiInDojoDiagrammer) {
		    //apply Bidi format on the text, using text direction and complex expression properties
    	    var bidiUpdateText = function(callee, args) {      
			    var sh = args[0];
			    if (sh === undefined){
				    return;
			    }
			    //for case the user call setShape()with argument containing a new textDir but not text, like text.setShape({textDir: "ltr"});
			    if (sh.text === undefined) {
				    if (this.getShape().__beforeBidi)
					    sh.text = this.getShape().__beforeBidi;
				    else {
					    if (this.getShape().text === undefined)
						    return;
					    sh.text = this.getShape().text;
				    }	
			    }
			    if (sh.textDir === undefined) {
			        if (sh.ceType) {
			           this.getShape().textDir = "ltr"; 
			        }
				    if (this.getShape().textDir === undefined) 
					    return;
				    sh.textDir = this.getShape().textDir; //for case like applyLayout(), when textDir is not set in argument shape.
			    }
                if (typeof(sh.text) != "string") {
				    sh.text = sh.text.toString();
                }
			    if (sh.__stopBidi || sh.text.length < 2) { //no need to apply bidi format
				    if (sh.__stopBidi) //flag __stopBidi can be used by user to prevent multiple transformation of the same text
					    delete sh.__stopBidi;
				    return;
			    }
			    
			    //store original, non processed text in __beforeBidi field
			    if (args[1] === undefined) {  
			    	if (sh.__beforeBidi) {    
			            this.getShape().__old = sh.__beforeBidi; //fix for print (deserialization), to fix second transformation of the same text during createText
			        }
			        sh.__beforeBidi = sh.text;
			    }  
			    else if (sh.__beforeBidi) // text direction was changed after the text was processed
			        sh.text = sh.__beforeBidi;  
			    
			    //need for additional/future shape processing, like applyLayout() 
                this.getShape().__beforeBidi = sh.__beforeBidi;  
			    
			    //complex expression case
			    if (sh.ceType) {
                    sh = BidiUtil.complExp.call(this,sh);
                    this.getShape().ceType = sh.ceType;		            
                    return true;
			    }
			    sh = BidiUtil.bidiFormat.call(this,sh);
			    return true;
		    };
      		
      		//set text direction to the shape, get if from argument, or
      		//from the parents, if possible.  
      		//then we call setShape with shape containing textDir parameter
      		var bidiUpdateShape = function(calee, textShape, args) {			
			    var sh = textShape.getShape();
			    var bidi = false;
			    if (!sh.textDir && args[0] && args[0].textDir)
				    sh.textDir = args[0].textDir;
    		  				
			    //trying to get textDir form parents			
			    if (!sh.textDir) {
				    bidi = true;
				    var sp = textShape;
				    var i = 0;
				    while (sp) {
					    if (sp.textDir) {
						    sh.textDir = sp.textDir;
						    break;
					    }
					    else if(sp.getTextDir) {
						    sh.textDir = sp.getTextDir();
						    break;
					    }
					    if (!sp.parent)
						    break;
					    sp = sp.getParent();
					    i++;
				    }
			    }
       			if (sh.__old){ //fix for print (deserialization), to fix second transformation of the same text during createText
    			    sh.text = sh.__old;
    			    delete sh.__old;
    			    if (args[0] && args[0].__beforeBidi)
    			        delete args[0].__beforeBidi;
    			    bidi = true;
    			} 			
			    if (sh.textDir && bidi) {
				    if (args[0] && args[0].ceType) //parameter for complex expression, for case, textDir was not set explicitly in the template
				        sh.ceType = args[0].ceType;	
				    textShape.setShape(sh);
			    }
    		
			    return textShape;
		    };	
		 }   
		ge.patchMethod(g.Rect, "setShape", null, onChangeFunc);
		ge.patchMethod(g.Circle, "setShape", null, onChangeFunc);
		ge.patchMethod(g.Ellipse, "setShape", null, onChangeFunc);
		ge.patchMethod(g.Line, "setShape", fixvml ? vmlFixRawNodePath : null, onChangeFunc);
		ge.patchMethod(g.Polyline, "setShape", fixvml ? vmlFixRawNodePath : null, onChangeFunc);
		ge.patchMethod(g.Path, "setShape", fixvml ? vmlFixRawNodePath : null);
		ge.patchMethod(g.Image, "setShape", null, onChangeFunc);
		ge.patchMethod(g.Text, "setShape", config.isBidiInDojoDiagrammer ? bidiUpdateText : null, onChangeFunc);
		ge.patchMethod(g.TextPath, "setShape", null, onChangeFunc);
		
		ge.patchMethod(g.Rect, "setTransform", null, onChangeFunc);
		ge.patchMethod(g.Circle, "setTransform", null, onChangeFunc);
		ge.patchMethod(g.Ellipse, "setTransform", null, onChangeFunc);
		ge.patchMethod(g.Line, "setTransform", null, onChangeFunc);
		ge.patchMethod(g.Polyline, "setTransform", null, onChangeFunc);
		ge.patchMethod(g.Image, "setTransform", null, onChangeFunc);
		ge.patchMethod(g.Text, "setTransform", null, onChangeFunc);
		ge.patchMethod(g.TextPath, "setTransform", null, onChangeFunc);
		
		ge.patchMethod(g.Group, "setTransform", null, onChangeFunc);
		ge.patchMethod(g.Group, "add", null, onChangeFunc);
		ge.patchMethod(g.Group, "remove", null, onChangeFunc);
		ge.patchMethod(g.Group, "clear", null, onChangeFunc);
		ge.patchMethod(g.Group, "createText", null, config.isBidiInDojoDiagrammer ? bidiUpdateShape : null);  		
		
		ge.patchMethod(g.Text, "setFont", null, onChangeFunc);
		
	})();
	
	//
	// dojox.gfx.matrix.Matrix2D extensions
	//
	
	lang.mixin(matrix, {
		createFromRectangles: function(/* dojox.gfx.Rectangle */content, /*dojox.gfx.Rectangle */ viewport, /*Boolean*/ keepAspectRatio) {
			// summary:
			//        Creates a dojo.gfx.Matrix2d instance that allows to transform
			//        a rectangle so that it is visible in a viewport rectangle.
			// content:
			//        The content rectangle to display in the viewport.
			// viewport:
			//        The destination viewport.
			// keepAspectRatio:
			//		  If true, the resulting matrix preserves the aspect ratio, 
			//			so applying it to the content rectangle may not give exactly the viewport rectangle.
			//		  If false, the resulting matrix does not preserve the aspect ratio, 
			//			and it exactly transforms the content rectangle into the viewport rectangle.
			var sx = (Math.abs(viewport.width - content.width) < 0.001) ? 1 : viewport.width / content.width;
			var sy = (Math.abs(viewport.height - content.height) < 0.001) ? 1 : viewport.height / content.height;
			var t = new matrix.Matrix2D();
			if (keepAspectRatio) {
				var s = Math.min(sx, sy);
				t.xx = t.yy = s;
				t.dx = (viewport.x + viewport.width / 2 - s * (content.x + content.width / 2));
				t.dy = (viewport.y + viewport.height / 2 - s * (content.y + content.height / 2));
			} else {
				t.xx = sx;
				t.yy = sy;
				t.dx = viewport.x - sx * content.x;
				t.dy = viewport.y - sy * content.y;
			}
			t.xy = 0;
			t.yx = 0;
			return t;
		}
	});
	lang.extend(matrix.Matrix2D, {
		inverse: function() {
			// summary:
			//        Returns the inverse transformation.
			return matrix.invert(this);
		},
		isScale: function() {
			// summary:
			//        Indicates whether this transform corresponds to a scaling operation.
			return this.xy === 0 && this.yx === 0;
		},
		isTranslation: function() {
			// summary:
			//        Indicates whether this transform corresponds to a translation operation.
			return this.xy === 0 && this.yx === 0 && this.xx === 1 && this.yy === 1;
		},
		isIdentity: function() {
			// summary:
			//        Indicates whether this transform corresponds to the identity operation.
			return this.xy === 0 && this.yx === 0 && this.xx === 1 && this.yy === 1 && this.dx === 0 && this.dy === 0;
		},
		isRotation: function() {
			// summary:
			//        Indicates whether this transform corresponds to a rotation operation.
			return (this.xy === 0 && this.yx === 0) || (this.yx * this.xx + this.xy * this.yy === 0);
		},
		isInvertible: function() {
			// summary:
			//        Indicates whether this transform is invertible.
			return this.xx * this.yy - this.yx * this.xy !== 0;
		},
		isSame: function(t) {
			// summary:
			//        Indicates whether this transform and the specified transform are the same.
			return this.xx === t.xx && this.xy === t.xy && this.yx === t.yx &&
			this.yy === t.yy &&
			this.dx === t.dx &&
			this.dy === t.dy;
		},
		transformPoints: function(points) {
			// summary:
			//        Applies this transformation to an array of points.
			return arr.map(points, function(p) {
				return matrix.multiplyPoint(this, p);
			}, this);
		},
		transformPoint: function(/* dojox.gfx.Point */p) {
			// summary:
			//        Applies this transformation to the specified point.
			return matrix.multiplyPoint(this, p);
		},
		transformRectangle: function(/* dojox.gfx.Rectangle */rect) {
			// summary:
			//        Applies the transformation to a rectangle.
			// description:
			//        The method applies the transformation on all corners of the
			//        rectangle and returns the smallest rectangle enclosing the 4 transformed
			//        points.            
			rect = rect ||
			{
				x: 0,
				y: 0,
				width: 0,
				height: 0
			};
			if (this.isIdentity()) {
				return {
					'x': rect.x,
					'y': rect.y,
					'width': rect.width,
					'height': rect.height
				};
			}
			var m = matrix;
			var p0 = m.multiplyPoint(this, rect.x, rect.y);
			var p1 = m.multiplyPoint(this, rect.x, rect.y + rect.height);
			var p2 = m.multiplyPoint(this, rect.x + rect.width, rect.y);
			var p3 = m.multiplyPoint(this, rect.x + rect.width, rect.y + rect.height);
			var minx = Math.min(p0.x, p1.x, p2.x, p3.x);
			var miny = Math.min(p0.y, p1.y, p2.y, p3.y);
			var maxx = Math.max(p0.x, p1.x, p2.x, p3.x);
			var maxy = Math.max(p0.y, p1.y, p2.y, p3.y);
			var r = {};
			r.x = minx;
			r.y = miny;
			r.width = maxx - minx;
			r.height = maxy - miny;
			return r;
		},
		transformVector: function(/* dojox.gfx.Point || dojox.gfx.Size */p) {
			// summary:
			//        Applies the transformation to a vector.
			var x, y, r = {};
			if (this.isIdentity()) {
				return p;
			}
			if ('x' in p && 'y' in p) { // point
				x = p.x;
				y = p.y;
				r.x = (x * this.xx) + (y * this.xy);
				r.y = (x * this.yx) + (y * this.yy);
			} else if ('width' in p && 'height' in p) { // size
				x = p.width;
				y = p.height;
				r.width = (x * this.xx) + (y * this.xy);
				r.height = (x * this.yx) + (y * this.yy);
			}
			return r;
		}
	});
	
	// dojox.gfx.Text.getBoundingBox fix
	_isOrphan = function(shape) {
		// a Surface does not have getParent() method.
		/*
		 for (var p = shape.getParent();p && p.getParent; p=p.getParent()){
		 }
		 return p === null;
		 */
		var p = shape.rawNode;
		while (p && p !== document.body) {
			if (p.style && p.style.display === 'none') 
				return true;
			p = p.parentNode;
		}
		return p !== document.body;
	};
	
	lang.extend(g.Text, {
		getBoundingBox: function() {
			var sh = this.getShape(), sz;
			sz = this.__getTextBBox(sh.text);
			return sz;
		},
		
		__getTextBBox: function(s) {
			if (!s || s.length == 0) 
				return null;
			if (iid.isSvg && !iid.isSvgWeb) {
				// try/catch the FF native getBBox error. cheaper than walking up in the DOM
				// hierarchy to check the conditions (bench show /10 )
				try {
					return this.rawNode.getBBox();
				} catch (e) {
					return null;
				}
			} else if (iid.isVml) {
				// mandatory fix or IE crash in the vgx.dll (vml impl.)
				if (_isOrphan(this)) {
					return null;
				}
				var rawNode = this.rawNode, _display = rawNode.style.display;
				rawNode.style.display = "inline";
				
				// [av] added ||0 to avoid the IE crashes.
				// TODO remove ||0 and solve NaNs from "auto" settings in IE properly
				var w = g.pt2px(parseFloat(rawNode.currentStyle.width)) || 0;
				var h = g.pt2px(parseFloat(rawNode.currentStyle.height)) || 0;
				var sz = {
					x: 0,
					y: 0,
					width: w,
					height: h
				};
				// in VML, the width/height we get are in view coordinates
				var m = this._getRealMatrix();
				if (m && !m.isIdentity()) {
					sz = m.inverse().transformRectangle(sz);
				}
				// It's impossible to get the x/y from the currentStyle.left/top,
				// because all negative coordinates are 'clipped' to 0.
				// (x:0 + translate(-100) -> x=0
				this._computeLocation(sz);
				rawNode.style.display = _display;
				return sz;
			} else if (iid.isSilverlight) {
				var bb = {
					width: this.rawNode.actualWidth,
					height: this.rawNode.actualHeight
				};
				return this._computeLocation(bb,0.75); // 0.75: rough approx. of ascent...	
			} else if (this.getTextWidth) {
				if(iid.isSvgWeb && !this.parent)
					return null;
				var w = this.getTextWidth();
				var font = this.getFont();
				var fz = font ? font.size : g.defaultFont.size;
				var h = g.normalizedLength(fz);
				// TODO check if 0,0 is ok or needs to be corrected.
				sz = {
					width: w,
					height: h
				};
				this._computeLocation(sz, 0.85); // 0.85: rough approx. of ascent...
				return sz;
			}
		},
		
		_computeLocation: function(sz, coef) {
			var width = sz.width, height = sz.height, sh = this.getShape(), align = sh.align;
			switch (align) {
				case 'end':
					sz.x = sh.x - width;
					break;
				case 'middle':
					sz.x = sh.x - width / 2;
					break;
				case 'start':
				default:
					sz.x = sh.x;
					break;
			}
			coef = coef || 1;
			sz.y = sh.y - height*coef; // rough approximation of the ascent!...
			return sz;
		}
	});
	
	//
	// selectedStyle property
	//
	
	var SelectedStyleMixin = {
		setSelectedStyle:function(style) {
			this.selectedStyle = style;
			this.onSelectedStyleChanged();
		},
		getSelectedStyle:function() {
			return this.selectedStyle;
		},
		onSelectedStyleChanged: function() {
			var ge = iid.GraphElement.byShape(this);
			if(ge) {
				this.__selectedStyleChanged = true; // flag to force re-applying of selected style
				ge._changeSelectionStyle(ge.isSelected());
			}
		},
		__eod: undefined
	};
	lang.extend(gs.Shape, SelectedStyleMixin);
	
	// VML/IE8: patch for cases where surface is created outside of the DOM.
	//
	if(iid.isVml && has("ie") >= 8){
		var _patchMethod = function(method, field){
			var shapeProto = g.vml.Shape.prototype;
			var old = shapeProto[method];
			shapeProto[method] = function(a){
				var s = this.getParent();
				while(s && s.getParent) s = s.getParent();
				if(s && _isOrphan(s)){
					this[field] = a;
					if(s){
						if(s._parent && !s._timer){
							//console.log("watching orphan surface...");
							s._timer = setTimeout(lang.hitch(s, _timer), 100);
						}
						return this;
					} else {
						return old.call(this, a); // no surface?
					}
				} else {
					return old.call(this, a);
				}
			};
		};
		var _timer = function(){
			var s = this;
			if(!s._parent){
				//console.log("surface disposed.");
				delete s._timer;
			} else if(_isOrphan(s)){
				// still not added: continue waiting
				//console.log("surface still orphan: continue waiting...");
				s._timer = setTimeout(lang.hitch(s, _timer), 100);
			} else {
				delete s._timer;
				//console.log("surface added: fixing");
				// remove/add surface node (don't know why exactly but hey that's VML...)
				s._parent.removeChild(s.clipNode);
				s._parent.appendChild(s.clipNode);
				// reset all shapes and styles on all shapes
				gfxu.forEach(s, function(shape){
					if(shape != s){
						if(shape.setShape) shape.setShape(shape.shape);
						if(shape.setFill) shape.setFill(shape.fillStyle);
						if(shape.setStroke) shape.setStroke(shape.strokeStyle);
					}
				}, s);
			}
		};
		_patchMethod("setShape", "shape");
		_patchMethod("setFill", "fillStyle");
		_patchMethod("setStroke", "strokeStyle");
	}
	
	return ge;
});
