/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"./Action",
"./UndoActionList"
], function(
declare,
lang,
array,
Action,
UndoActionList
){
	
/*=====
var Action = ibm_ilog.diagram.editor.undo.Action;
=====*/

	var MultipleAction =
	declare("ibm_ilog.diagram.editor.undo.MultipleAction", [Action], {
		//
		//	summary:
		//		this action groups a list of actions. It simple groups a set of actions in a single complex action.
		//
		_actionList:null,
		_reverseUndo: null,
		_reverseRedo: null,
	constructor:function(label){
		//
		//	summary:
		//		creates a  new instance, setting up the label
		//
		this._label = label;
		this.initialize(lang.hitch(this,this._undoFunction),lang.hitch(this,this._redoFunction));
		this._actionList = [];
		this._reverseUndo = true;
		this._reverseRedo = false;
	},
	addAction: function(action){
		//
		//	summary:
		//		adds an action to the list
		this._actionList.push(action);
	},
	_undoFunction: function(){
		var size = this._actionList.length;
		for(var index = 0;index<size;index++){
			var action = this._reverseUndo?this._actionList[size-index-1]:this._actionList[index];
			action.undo();
		}
	},
	_redoFunction: function(){
		var size = this._actionList.length;
		for(var index = 0;index<size;index++){
			var action = this._reverseRedo?this._actionList[size-index-1]:this._actionList[index];
			action.redo();
		}
	},
	setUndoManager: function(undoManager){
		//
		//	summary:
		//		sets the undo Manager to each individual action added to the list
		this._undoManager = undoManager;
		array.forEach(
				this._actionList,
			    function(item){
			        item.setUndoManager(undoManager);
			    }
			);
	},
	setReverseUndo:function(reverse){
		// summary:
		//		sets to apply the undo actions in reverse order
			this._reverseUndo = reverse;
	},
	getReverseUndo: function(){
		// summary:
		//		gets to apply the undo actions in reverse order
		return this._reverseUndo;
	},
	setReverseRedo:function(reverse){
		// summary:
		//		sets to apply the redo actions in reverse order
		this._reverseRedo = reverse;
	},
	getReverseRedo: function(){
		// summary:
		//		gets to apply the redo actions in reverse order
		return this._reverseRedo;
	}
	});
	
	return MultipleAction;
	
});
