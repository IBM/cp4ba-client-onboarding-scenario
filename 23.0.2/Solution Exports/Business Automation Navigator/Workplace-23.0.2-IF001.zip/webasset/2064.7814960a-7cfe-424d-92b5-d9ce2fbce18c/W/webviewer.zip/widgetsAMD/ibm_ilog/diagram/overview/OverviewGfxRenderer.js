/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"dojox/gfx",
"dojox/gfx/utils",
"./OverviewRenderer"
],
function(
declare,
lang,
array,
g,
gu,
OverviewRenderer
){

/*=====
var OverviewRenderer = ibm_ilog.diagram.overview.OverviewRenderer;
=====*/

var OverviewGfxRenderer =
declare('ibm_ilog.diagram.overview.OverviewGfxRenderer', OverviewRenderer, {
	
	// static
	_transformSerialize: function transformSerialize(
			/* dojox.gfx.Surface || dojox.gfx.Shape */ object,
			/* Function | String */                    transform
		)
	{
		var t = {}, isSurface = object instanceof g.Surface;

		var transformChildren = function() {
			var mapf = function(x){ return transformSerialize(x,transform); };
			var notz = function(x){ return x!=null; };
			return array.filter(array.map(object.children,mapf),notz);
		};
		
		if(isSurface) {
			return transformChildren();	// Array
		} else {
			return transform(object,transformChildren);
		}

	},

	
	// static
	_shapeCopy: function(copy,shape,getChildren) {
		var v;
		if(!(shape instanceof g.Surface) &&
	       !(shape instanceof g.Group)){		
			copy.shape = shape.getShape();
		} else {
			copy.children = getChildren();	
		}
		
		if(shape.getTransform){
			v = shape.getTransform();
			if(v){ copy.transform = v; }
		}
		if(shape.getStroke){
			v = shape.getStroke();
			if(v){ copy.stroke = v; }
		}
		if(shape.getFill){
			v = shape.getFill();
			if(v){ copy.fill = v; }
		}
		if(shape.getFont){
			v = shape.getFont();
			if(v){ copy.font = v; }
		}
	},


	// static
	stdShapeFilter: function(filter) {
		return function (shape,getChildren) {
				if(filter(shape)) {
					var copy = {};
					this._shapeCopy(copy,shape,getChildren);
					return copy;
				} else {
					return null;
				}
			};
	},
	
	// static
	overviewFilter0: function( object ) {
		return true;
	},

	// static
	overviewFilter1: function( object ) {
		var t = {}, v, isSurface = object instanceof g.Surface;
		if(isSurface || object instanceof g.Group){
			return true;
		} else {
			return object.getShape().type=="rect";
		}
	},
	
	// static
	overviewFilter2: function( object ) {
		var t = {}, v, isSurface = object instanceof g.Surface;
		if(isSurface || object instanceof g.Group){
			return true;
		} else {
			return object.getShape().type=="polyline";
		}
	},

	// static
	overviewTransform3: function(shape,getChildren) {
		var isSurface = shape instanceof g.Surface;
		var isGroup   = shape instanceof g.Group;
		if(isSurface || isGroup || shape.getShape().type=="rect" ){
			var copy = {};
			this._shapeCopy(copy,shape,getChildren);
			if(shape.getShape().type=="rect") {
				copy.fill = {r:0,g:0,b:0,a:1}; // build fill by hand because destination objects are empty after "serialization"
			}
			return copy;
		} else {
			return null;
		}
	},
	
	constructor: function( /*ibm_ilog.diagram.widget.Diagram*/ diagram ) {
		this._diagram = diagram;
	},

	render: function( /*dojox.gfx.Group*/ output ) {

		var nodefilter = nodefilter || lang.hitch(this,this.overviewTransform3);
		
		var graphJson = this._transformSerialize(this._diagram.getGraph(),nodefilter);
		
		gu.deserialize(output, graphJson);
		
	}
});

return OverviewGfxRenderer;

});
