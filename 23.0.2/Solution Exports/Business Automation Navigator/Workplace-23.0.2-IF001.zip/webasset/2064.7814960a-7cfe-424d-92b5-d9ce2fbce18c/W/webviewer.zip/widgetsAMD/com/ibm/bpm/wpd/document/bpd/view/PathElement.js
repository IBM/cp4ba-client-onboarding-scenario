/**
 * An element in an PathAdorner. It is an AdornerTarget so can contain adorners.
 */
define([
   "dojo/_base/declare", "dojo/_base/lang", "dojo/aspect", "./AdornerTarget"
], function(declare, lang, aspect, AdornerTarget) {
   return declare([
      AdornerTarget
   ], {

      adorners : null,
      adornerListeners : null,
      data : null,

      constructor : function() {
         this.adorners = [];
         this.adornerListeners = [];
         this.data = {};
      },

      getData : function() {
         return this.data;
      },

      addAdorner : function(adorner) {
         if (!adorner)
            return;
         this.adorners.push(adorner);
         this.adornerListeners.push(aspect.after(adorner, "onEvent", lang.hitch(this, function(adorner, eventName, data) {
            this.onAdornerEvent(this, adorner, eventName, data);
         }), true));
      },

      removeAdorner : function(adorner) {
         if (!adorner)
            return;
         var index = this.adorners.indexOf(adorner);
         if (index === -1)
            return;
         this.adorners.splice(index, 1);
         this.adornerListeners[i].remove();
         this.adornerListeners.splice(index, 1);
      },

      adorn : function() {
         for ( var i = 0; i < this.adorners.length; i++) {
            this.adorners[i].adorn();
         }
      },

      unAdorn : function() {
         for ( var i = 0; i < this.adorners.length; i++) {
            this.adorners[i].unAdorn();
         }
      },

      destroy : function() {
         this.deregisterAllAdornerListeners();
         for ( var i = 0; i < this.adorners.length; i++) {
            this.adorners[i].destroy();
         }
         this.adorners.length = 0; // Clear the adorners
      },

      /**
       * Is fired when any child adorner fires its onEvent method.
       */
      onAdornerEvent : function(pathElement, adorner, eventName, data) {

      },

      deregisterAllAdornerListeners : function() {
         if (!this.adornerListeners)
            return;
         for ( var i = 0; i < this.adornerListeners.length; i++) {
            this.adornerListeners[i].remove();
         }
         this.adornerListeners.length = 0;
      }

   });

});