define({      
//begin v1.x content
    errorDialogTitle: "Chyba produktu IBM BPM",
    moreDetails: "Další podrobnosti...",
    closeMessage: "Zavřít všechny chybové zprávy",
    contentMessage: "Došlo k chybě."
//end v1.x content
});

