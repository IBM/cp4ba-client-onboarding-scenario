/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/declare",
"./PortBase"],
function(declare, PortBase){

/*=====
var PortBase = ibm_ilog.diagram.PortBase;
=====*/

var AutomaticPort = declare("ibm_ilog.diagram.AutomaticPort", PortBase, {
	// summary:
	//		The AutomaticPort class represents a port that connects a link to the middle of the
	//		closest side of a node.
	
	needsReferencePoint: function(){
		// summary:
		//		Returns true to indicate that the automatic port needs a reference point
		//		to compute the connection point.
		return true;
	},
		
	computeConnectionPoint: function(link, parent, referencePoint, connectionPoint, originPoint, start){
		// summary:
		//		Implements the calculation of the connection and origin points for the AutomaticPort class.
		// description:
		//		Computes the connection point as the middle of the side of the node that is closest
		//		to the reference point.
		//		The origin point is always the center of the node.
		
		var bounds = this.getConnectionBounds(parent);
		var cx = bounds.x + bounds.width/2;
		var cy = bounds.y + bounds.height/2;
		originPoint.x = cx;
		originPoint.y = cy;
		connectionPoint.x = cx;
		connectionPoint.y = cy;
		if (bounds.width > 0 && bounds.height > 0) {
			var dx = referencePoint.x - cx;
			var dy = referencePoint.y - cy;
			var refRatio = dx != 0 ? (dy > 0 ? dy : -dy) / (dx > 0 ? dx : -dx) : 2;
			if (refRatio > 1) {
				// above or below: determine which from sign of dy
				connectionPoint.y = bounds.y;
				if (dy > 0) 
					connectionPoint.y += bounds.height;
			}
			else {
				// left or right: determine which from sign of dx
				connectionPoint.x = bounds.x;
				if (dx > 0) 
					connectionPoint.x += bounds.width;
			}
		}
		return connectionPoint;
	}
});

return AutomaticPort;

});
