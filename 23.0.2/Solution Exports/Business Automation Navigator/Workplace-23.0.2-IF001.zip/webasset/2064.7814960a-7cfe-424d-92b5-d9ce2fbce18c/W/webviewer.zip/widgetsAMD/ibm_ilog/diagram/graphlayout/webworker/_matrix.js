/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/lang", "dojox/gfx/matrix"], function(lang, matrix){

lang.extend(matrix.Matrix2D, {
	inverse: function() {
		// summary:
		//        Returns the inverse transformation.
		return matrix.invert(this);
	},
	isIdentity: function() {
		// summary:
		//        Indicates whether this transform corresponds to the identity operation.
		return this.xy === 0 && this.yx === 0 && this.xx === 1 && this.yy === 1 && this.dx === 0 && this.dy === 0;
	},
	transformPoint: function(/* dojox.gfx.Point */p) {
		// summary:
		//        Applies this transformation to the specified point.
		return matrix.multiplyPoint(this, p);
	},
	transformRectangle: function(/* dojox.gfx.Rectangle */rect) {
		// summary:
		//        Applies the transformation to a rectangle.
		// description:
		//        The method applies the transformation on all corners of the
		//        rectangle and returns the smallest rectangle enclosing the 4 transformed
		//        points.            
		rect = rect ||
		{
			x: 0,
			y: 0,
			width: 0,
			height: 0
		};
		if (this.isIdentity()) {
			return {
				'x': rect.x,
				'y': rect.y,
				'width': rect.width,
				'height': rect.height
			};
		}
		var m = matrix;
		var p0 = m.multiplyPoint(this, rect.x, rect.y);
		var p1 = m.multiplyPoint(this, rect.x, rect.y + rect.height);
		var p2 = m.multiplyPoint(this, rect.x + rect.width, rect.y);
		var p3 = m.multiplyPoint(this, rect.x + rect.width, rect.y + rect.height);
		var minx = Math.min(p0.x, Math.min(p1.x, Math.min(p2.x, p3.x)));
		var miny = Math.min(p0.y, Math.min(p1.y, Math.min(p2.y, p3.y)));
		var maxx = Math.max(p0.x, Math.max(p1.x, Math.max(p2.x, p3.x)));
		var maxy = Math.max(p0.y, Math.max(p1.y, Math.max(p2.y, p3.y)));
		var r = {};
		r.x = minx;
		r.y = miny;
		r.width = maxx - minx;
		r.height = maxy - miny;
		return r;
	}
});

return matrix;

});

