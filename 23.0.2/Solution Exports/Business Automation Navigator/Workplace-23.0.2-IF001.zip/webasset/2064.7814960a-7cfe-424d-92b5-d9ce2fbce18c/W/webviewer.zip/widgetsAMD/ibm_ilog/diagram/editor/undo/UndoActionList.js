/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/lang"], function(lang) {

	// TODO: Change to this when AMD conversion is complete:
	// var UndoActionList = {};
	var UndoActionList = lang.getObject("ibm_ilog.diagram.editor.undo.UndoActionList", true);

	UndoActionList.Drop = "Drop";
	UndoActionList.RemoveIntermediatePoint = "RemoveIntermediatePoint";
	UndoActionList.AddIntermediatePoint = "AddIntermediatePoint";
	UndoActionList.ModifyIntermediatePoint = "ModifyIntermediatePoint";
	UndoActionList.Connect = "Connect";
	UndoActionList.ReConnect = "ReConnect";
	UndoActionList.ReParent = "ReParent";
	UndoActionList.Resize = "Resize";
	UndoActionList.Move = "Move";
	UndoActionList.Delete = "Delete";
	UndoActionList.Paste = "Paste";
	UndoActionList.Align = "Align";
	UndoActionList.Group = "Group";
	UndoActionList.Ungroup = "Ungroup";
	UndoActionList.Reorder = "Reorder";
	UndoActionList.InvertLink = "InvertLink";
	
	return UndoActionList;
	
});
