/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"../../interactors/Interactor"
], function(
declare,
Interactor
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var ClipboardKeyInteractor =
declare("ibm_ilog.diagram.editor.interactors.ClipboardKeyInteractor", [Interactor], {
	//summary:
	//		This interactor manages the Clipboard through the keyboard interaction.
	//		This interactor has 3 connections: cut, copy, paste.
	
	_diagram: null,
	initialize: function (diagram) {
	// summary:
    //		initialize the new instance.
    // diagram: ibm_ilog.diagram.widget.Diagram
    //		the associated diagram.		
		this._diagram = diagram;
		return this._initialize();
	},
	copy: function(e){
		// summary:
	    //		This method calls the Clipboard Copy function.
		this._diagram.getClipboard().copy();
	},
	paste: function(e){
		// summary:
	    //		This method calls the Clipboard Paste function. The pasteObject is the focused element if it is a subgraph, or its parent if other.
		//		If there is no focused element, the paste action is done in the top level graph. The paste position is set to {x:0,y:0} but the pasted 
		//		elements remains selected to easily move them.
		
		var clipboard = this._diagram.getClipboard();
		var container = this._diagram.getFocusedElement();
		if(container){
			if(container._isIBMDiagramSubgraph){
				container = container.getGraph();
			}else{
				container = container.getParent();
			}
		}else{
			container = this._diagram.getGraph();
		}
		
		clipboard.paste(container);
	},
	cut: function(e){
		// summary:
	    //		This method calls the Clipboard Cut function.
		this._diagram.getClipboard().cut();
	},
	getKeyInteractorId: function(){
		// summary:
	    //		returns the Interactor Id
		return ClipboardKeyInteractor.KeyInteractorId;
	},
	getDefaultConnections: function () {
		// summary:
		//		returns the default event mapping
		
		return {
			copy: {
				hotKey: 67,//  letter C	
				connectTo: "copy",
				filter: this._buildInputFilter({ctrl:true,shift:false,alt:false})
			}, paste: {
				hotKey: 86,//  letter V
				connectTo: "paste",
				filter: this._buildInputFilter({ctrl:true,shift:false,alt:false})
			}, cut: {
				hotKey: 88,//  letter X
				connectTo: "cut",
				filter: this._buildInputFilter({ctrl:true,shift:false,alt:false})
			}
		};
	}
});

ClipboardKeyInteractor.KeyInteractorId = "Clipboard";

return ClipboardKeyInteractor;

});
