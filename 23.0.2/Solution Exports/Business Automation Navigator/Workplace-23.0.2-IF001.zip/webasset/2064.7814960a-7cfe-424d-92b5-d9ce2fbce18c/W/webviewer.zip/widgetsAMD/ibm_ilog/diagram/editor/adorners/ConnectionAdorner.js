/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"../../base",
"./ConnectionHandle",
"../../adorners/AdornerWithHandles",
"../../util/Geometry"
], function(
declare,
iid,
ConnectionHandle,
AdornerWithHandles,
g
){
    
/*=====
var AdornerWithHandles = ibm_ilog.diagram.adorners.AdornerWithHandles;
=====*/

	var Point = g.Point;
	
	var ConnectionAdorner =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.ConnectionAdorner',[AdornerWithHandles],{

    	initialize: function() {
    		this.inherited(arguments);

    		this._createConnectionHandle("hndT",Point(0.5,0));
    		this._createConnectionHandle("hndR",Point(1,0.5));
    		this._createConnectionHandle("hndB",Point(0.5,1));
    		this._createConnectionHandle("hndL",Point(0,0.5));
    	},
        
    	_createConnectionHandle: function(attachPoint,p) {
    		var h = this._createHandle(ConnectionHandle,attachPoint);
    		if(h) {
    			h.setup(p);
    		}
    	}

    }));

	return ConnectionAdorner;

});

