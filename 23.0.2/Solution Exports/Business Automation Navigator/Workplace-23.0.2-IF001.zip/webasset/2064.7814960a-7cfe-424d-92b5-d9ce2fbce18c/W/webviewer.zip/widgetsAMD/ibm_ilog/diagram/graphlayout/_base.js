/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/lang",
"./LayoutRunner",
"./Animation",
"./_LayoutProvider",
"ibm_ilog/graphlayout/RecursiveMultipleLayout",
"./GraphAdapter"
],
function(
lang,
LayoutRunner,
Animation,
_LayoutProvider,
RecursiveMultipleLayout,
GraphAdapter
){
	
	// The purpose of this module is to avoid loading graph layout classes if no graph layout is used in the app.
	// This works as follows: if graph layout is used, at least one graph layout class will be loaded.
	// All graph layout classes are subclasses of GraphLayout.js, which has this module (ibm_ilog/diagram/graphlayout/_base)
	// in its reference list. When this module is loaded, it will mixin some graph layout class pointers into
	// LayoutRunner, which then be able to use them (at runtime).
		
	return lang.mixin(LayoutRunner, {
		Animation: Animation,
		_LayoutProvider: _LayoutProvider,
		RecursiveMultipleLayout: RecursiveMultipleLayout,
		GraphAdapter: GraphAdapter
	});
});
