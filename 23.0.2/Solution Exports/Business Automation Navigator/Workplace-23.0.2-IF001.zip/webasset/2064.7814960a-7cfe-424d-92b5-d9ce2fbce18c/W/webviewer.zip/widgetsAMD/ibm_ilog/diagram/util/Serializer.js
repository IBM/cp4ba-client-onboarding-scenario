/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/declare", "dojo/_base/array", "dojox/collections/Dictionary", "./GraphUtil", "./ErrorReporter"],
function(declare, array, Dictionary, gu, R){

/*=====
ibm_ilog.diagram.util.__SubgraphSerializationInfo = function(){
	//	summary:
	//		Output of a subgraph deserialization with information for the 
	//		deserialization procedure. 
	//	created: Object
	//		The newly created object corresponding to the deserialization of the 
	//		subgraph. To be stored in the dictionary passed through all deserialization
	//		callbacks by it's old id. 
	//	container: Object
	//		The container that has been created while deserializing the subgraph.
	this.created = created;
	this.container = container;
};
=====*/

/*=====
ibm_ilog.diagram.util.__NodeSerializationInfo = function(){
	//	summary:
	//		Output of a node deserialization with information for the 
	//		deserialization procedure. 
	//	created: Object?
	//		The newly created object corresponding to the deserialization of the 
	//		node. To be stored in the dictionary passed through all deserialization
	//		callbacks by it's old id. 
	this.created = created;
};
=====*/

/*=====
ibm_ilog.diagram.util.__LinkSerializationInfo = function() {
	//	summary:
	//		Output of a link deserialization with information for the 
	//		deserialization procedure. 
	//	created: Object?
	//		The newly created object corresponding to the deserialization of the 
	//		link. To be stored in the dictionary passed through all deserialization
	//		callbacks by it's old id. 
	this.created = created;
};
=====*/

/*=====
ibm_ilog.diagram.util.__SerializerArgs = function(){
	//	getId: Function?
	//		This is used for identifying serialized graph elements through 
	//		the serialization/deserialization process.
	//	serializeNodeData: Function?
 	//		Callback used for serializing a node. The user must use this function
 	//		for creating the appropiate representation for a node which will later
 	//		be used by the corresponding deserialization function.
	//	serializeLinkData: Function?
 	//		Callback used for serializing a link. The user must use this function
 	//		for creating the appropiate representation for a link which will later
 	//		be used by the corresponding deserialization function.
	//	serializeSubgraphData: Function?
 	//		Callback used for serializing a subgraph. The user must use this function
 	//		for creating the appropiate representation for a subgraph which will later
 	//		be used by the corresponding deserialization function.
	//	deserializeNodeData: Function?
 	//		Deserialize a node from the serialized data into the given container.
	//	deserializeLinkData: Function?
 	//		Deserialize a link from the serialized data into the given container.
	//	deserializeSubgraphData: Function?
 	//		Deserialize a subgraph from the serialized data into the given container.
	
	// [av] TODO the following doc style is copied from dojo.xhr but is not currently working.
	this.getId = function(ge) {
		//	ge: ibm_ilog.diagram.GraphElement
	}
	
	this.serializeNodeData  = function(node){
		//	node: ibm_ilog.diagram.Node
		//	returns: ibm_ilog.diagram.util.__NodeSerializationInfo
	}
	 
	this.serializeLinkData  = function(link){
		//	link: ibm_ilog.diagram.Link
		//	returns: ibm_ilog.diagram.util.__LinkSerializationInfo
	};
	
	this.serializeSubgraphData  = function(subgraph){
		//	subgraph: ibm_ilog.diagram.Subgraph
		//	returns: ibm_ilog.diagram.util.__SubgraphSerializationInfo
	};
	 
	this.deserializeNodeData = function(serializedData,newByOldId,container){
		//	serializedData:	Object
		//		This is the serialized representation of the node to be deserialized.
	 	//	newByOldId: dojox.collections.Dictionary
	 	//		This is a dictionary of the newly deserialized objects accessible by
	 	//		their original id. This is used for cloning relations between the 
	 	//		original objects.
	 	//	container: Object
	 	//		The container into which to deserialize the node. This objects are 
	 	//		completely managed by the user callbacks.
	};
	 
	this.deserializeLinkData = function(serializedData,newByOldId,container){
		//	serializedData:	Object
		//		This is the serialized representation of the link to be deserialized.
	 	//	newByOldId: dojox.collections.Dictionary
	 	//		This is a dictionary of the newly deserialized objects accessible by
	 	//		their original id. This is used for cloning relations between the 
	 	//		original objects.
	 	//	container: Object?
	 	//		The container into which to deserialize the link. This objects are 
	 	//		completely managed by the user callbacks.
	};
	 
	this.deserializeSubgraphData = function(serializedData,newByOldId,container){
		//	serializedData:	Object
		//		This is the serialized representation of the subgraph to be deserialized.
	 	//	newByOldId: dojox.collections.Dictionary
	 	//		This is a dictionary of the newly deserialized objects accessible by
	 	//		their original id. This is used for cloning relations between the 
	 	//		original objects.
	 	//	container: Object
	 	//		The container into which to deserialize the subgraph. This objects are 
	 	//		completely managed by the user callbacks.
	};

};
=====*/

var Serializer = declare("ibm_ilog.diagram.util.Serializer",null,{
	//
	//	summary:
	//		This class is a template-based serialization procedure for GraphElements. Provided
	//		a specific set of user callbacks, the instances of this class can be used to 
	//		execute the serialization of a network of entities and its corresponding 
	//		deserialization.
	//
	//	see:
	//		ibm_ilog.diagram.util.__SerializerArgs

	constructor: function( /*ibm_ilog.diagram.util.__SerializerArgs*/ kwArgs ) {
		this._kwArgs = kwArgs;
		this._newByOldId = new Dictionary();
	},	
	
	testApiDoc: function( /*ibm_ilog.diagram.util.__SerializerArgs*/ kwArgs ) {
	
	},
	
	serialize: function(geSet) {
		//
		//	summary:
		//		Serializes a set of graph elements.
		//	geSet: Array
		//		Array of graph elements to serialize. Deserialization occurs once 
		//		for each regardlessly of the relationships between them.
		//		See also ibm_ilog.diagram.util.GraphUtil.maximals for achieving a variant
		//		which removes duplicated copying.
		//	returns: Array
		//		The serialized representation for each of the elements
		//		
		var c = this._kwArgs;
				
		var geById = new Dictionary();
		
		var dispatchers = {
			N:function(ge) { return c.serializeNodeData(ge); },
			L:function(ge) { return c.serializeLinkData(ge); },
			S:function(ge) { return c.serializeSubgraphData(ge); }
		};
		
		array.forEach(geSet,function(geRoot){
			gu.forEach(geRoot,function(ge){
				var id = c.getId(ge);
				if(!geById.contains(id)) {
					geById.add(id,gu.dispatchClass(ge,arguments,this,dispatchers));
				}
			},this);
		},this);

		var node = function(ps,ge) {
			return {
				node:1,
				id: c.getId(ge),
				data: geById.item(c.getId(ge))
			};
		};

		var link = function(ps,ge) {
			return {
				link:1,
				id: c.getId(ge),
				data: geById.item(c.getId(ge))
			};
		};

		var graph = function(ps,ns,ge,fc) {
			// the serialization of a graph is the 
			// already serialized child collection "fc"
			return fc;
		};
		
		var child = function(ps,fc,fe) {
			// add serialized child "fe" to the serialized 
			// child collection "fc" and return 
			var nc = [];
			for(var x in fc) {
				if(x) {
					nc.push(fc[x]);
				}
			}
			nc.push(fe);
			return nc;
		};
		
		var sub = function(ps,ns,ge,fg) {
			// data + serialized children collection 
			return {
				subgraph:1,
				id: c.getId(ge),
				data:geById.item(c.getId(ge)),
				children:fg
			};
		};
	
		var r = [];
		array.forEach(geSet,function(maximalGE){

			r.push(gu.fold(
				maximalGE,
				undefined,
				gu.folders({
					node: node,
					sub:  sub,
					link: link,
					graph: graph,
					cBase: [],
					child: child
				}),
				this
			));
		},this);
		
		return r;
		
	},
	
	deserialize: function(s,container) {
		//
		//	summary:
		//		Deserialize a set of elements into a container
		//	s: Array
		//		The serialized representations of the elements to deserialize
		//	container: Object
		//		The container into which to create the elements.
		//

		var result = array.map(s,function(s){
			return this._deserializeElement(s,container);
		},this);
		this._newByOldId.clear();
		return result;
	},

	_deserializeElement: function(se,container) {
		//
		//	summary:
		//		Deserialize a graph element into a container
		//	se: Array
		//		The serialized representation of the element to deserialize
		//	container: Object
		//		The container into which to create the elements.
		//
		var c = this._kwArgs;
		var dict = this._newByOldId;
		var newge;
		
	    if(se.node) {
		    newge = c.deserializeNodeData(se.data,dict,container);
		    if(newge) {
		    	dict.add(se.id,newge);
		    }
	    }
	    
	    if(se.subgraph) {
	    	newge = c.deserializeSubgraphData(se.data,dict,container);
	    	if(newge) {
			    dict.add(se.id,newge);
				array.forEach(se.children,function(e){
					this._deserializeElement(e,newge);
				},this);
	    	}
		}

		if(se.link) {
		    newge = c.deserializeLinkData(se.data,dict,container);
		    if(newge) {
		    	dict.add(se.id,newge);
		    }
		}
		return newge;
	}	
});

return Serializer;
});


