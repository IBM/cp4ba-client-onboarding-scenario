define({      
//begin v1.x content
    errorDialogTitle: "Errore IBM BPM",
    moreDetails: "Ulteriori dettagli...",
    closeMessage: "Chiudi tutti i messaggi di errore",
    contentMessage: "Si è verificato un errore."
//end v1.x content
});

