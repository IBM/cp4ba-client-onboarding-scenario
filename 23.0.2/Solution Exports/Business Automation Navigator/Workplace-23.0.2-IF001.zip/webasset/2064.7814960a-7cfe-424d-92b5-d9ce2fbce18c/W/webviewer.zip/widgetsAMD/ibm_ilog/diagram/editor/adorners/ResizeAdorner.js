/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"../../base",
"../../adorners/AdornerWithHandles",
"../adorners/ResizeHandle",
"../../util/Geometry"
], function(
declare,
iid,
AdornerWithHandles,
ResizeHandle,
g
){

/*=====
var AdornerWithHandles = ibm_ilog.diagram.adorners.AdornerWithHandles;
=====*/

	var Point = g.Point;

	var ResizeAdorner =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.ResizeAdorner', [AdornerWithHandles], {
	//
	//	summary:
	//		An adorner with handles to resize the adorned.
	//	description:
	//		This Adorner creates 4 ResizeHandles, one at each corner of the 
	//		adorned bouding box.
	//		Each ResizeHandle allows to grab that corner of the bounding box 
	//		and resize the adornee by moving that corner.
	//
	initialize: function () {
		this.inherited(arguments);

		this._createResizeHandle("hndTL", Point(0, 0));
		this._createResizeHandle("hndTR", Point(1, 0));
		this._createResizeHandle("hndBL", Point(0, 1));
		this._createResizeHandle("hndBR", Point(1, 1));
	},

	_createResizeHandle: function (attachPoint, p) {
		var h = this._createHandle(ResizeHandle, attachPoint);
		if (h) {
			h.setup(p);
		}
	}

}));

return ResizeAdorner;

});
