/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"./UserCustomizedAction",
"./UndoActionList",
"../../Port"
], function(
declare,
lang,
UserCustomizedAction,
UndoActionList,
Port
){
	
/*=====
var UserCustomizedAction = ibm_ilog.diagram.editor.undo.UserCustomizedAction;
=====*/

	var ConnectAction =
	declare("ibm_ilog.diagram.editor.undo.ConnectAction", [UserCustomizedAction], {
		//	
		// summary:
		//		this action undo/redo any Connect action.
		//		This action must be modified for the user if any user defined action is done on a connect action.
		//
		_linkId: null,
		_parentId: null,
		_createPointFunction: null,
		_linkShapeType: null,
	constructor:function(diagram,link,parent){
		//	
		// summary:
		//		creates a new instance, setting the corresponding label
		this._label = UndoActionList.Connect;
		this._linkId = link.getId();
		this._parentId = diagram.getUndoManager().getParentId(parent);
		this._linkShapeType = link.getShapeType();
		var start = link.getStartPort();
		this._start = {
			auto: !start._isIBMDiagramBasicPort,
			position: start._isIBMDiagramBasicPort?start.getPosition():null,
			nodeId: start.getOwner().getId()	
		};
		
		var end = link.getEndPort();
		if(end){
			this._end = {
				auto: !end._isIBMDiagramBasicPort,
				position: end._isIBMDiagramBasicPort?end.getPosition():null,
				nodeId: end.getOwner().getId()	
			};
		}else{
			this._end = {
					point: lang.clone(link.getFallbackEndPoint())
				};
		}
	},
	_clearPorts: function(){
		var port;
		var link = this.getUndoManager().getRegisteredGraphElement(this._linkId);
		port = link.getStartPort();
		link.setStartPort(null);
		//remove Port
		if(port && port._isIBMDiagramBasicPort){
			port.getOwner().removePort(port);
		}
		port = link.getEndPort();
		link.setEndPort(null);
		//remove Port
		if(port && port._isIBMDiagramBasicPort){
			port.getOwner().removePort(port);
		}
	},
	_createPort: function(automaticPortType,position){
		var port;
		if(automaticPortType || !position){
			port = new Port.AutomaticPort();
		}else{
			port = new Port.BasicPort();
			port.setPosition(position);
		}
		return port;
	},
	getLink: function(){
		//	
		// summary:
		//		returns the link, looking for replaces if necessary
		return this.getUndoManager().getRegisteredGraphElement(this._linkId);
	},
	undoFunction: function(){
		var parent = this.getUndoManager().getRegisteredParent(this._parentId);
		var link = this.getLink();
		parent.remove(link);
		this._clearPorts();
		link.dispose();
	},
	redoFunction: function(){
		var parent = this.getUndoManager().getRegisteredParent(this._parentId);
		var link = parent.createLink();
		this.getUndoManager().registerGraphElementReplacement(this._linkId,link.getId());
		link.setShapeType(this._linkShapeType);
		
		var startNode = this.getUndoManager().getRegisteredGraphElement(this._start.nodeId);
		var endNode = this.getUndoManager().getRegisteredGraphElement(this._end.nodeId);
		
		var startP = this._createPort(this._start.auto,this._start.position);
		startNode.addPort(startP);
		link.setStartPort(startP);
		
		if(endNode){
			var endP = this._createPort(this._end.auto,this._end.position);
			endNode.addPort(endP);
			link.setEndPort(endP);
		}else{
			link.setFallbackEndPoint(lang.clone(this._end.point));
		}
		var D = this.getUndoManager().getDiagram();
		D._onLinkCreated(link,startNode,endNode,D);
		D.onLinkUpdated(D,link,true,this);
		this._linkId = link.getId();
	}
	});
	
	return ConnectAction;
	
});
