/**
 * Utilities to help fetch elements from a ILog diagram
 * 
 */
define([
      "dojo/_base/declare", "dojo/_base/lang", "require"
], function(declare, lang, require) {

   var ILogDiagramUtils = declare([], {

      /**
       * Find the model item associated with a given ID.
       */
      getNodeById : function(ilogDiagram, id) {
         if (!id || !ilogDiagram)
            return null;
         // Get the list of links available as an ItemFileReadStore
         var nodes = ilogDiagram.nodesStore;
         // Query the store for a given link
         var node;
         nodes.fetchItemByIdentity({
            identity : id,
            onItem : function(item, request) {
               node = item;
            }
         });
         return node;
      },

      /**
       * Find the model item associated with a given Node name.
       */
      getNodeByName : function(ilogDiagram, name) {
         if (!name || !ilogDiagram)
            return null;
         // Get the list of links available as an ItemFileReadStore
         var nodes = ilogDiagram.nodesStore;
         // Query the store for a given node with the specified name
         var node;
         nodes.fetch({
            query : {
               label : name
            },
            onItem : function(item, request) {
               node = item;
            }
         });
         return node;
      },

      /**
       * Find the GFX element representing the node associated with a given ID
       */
      getGfxNodeById : function(ilogDiagram, id) {
         try {
            if (!id || !ilogDiagram)
               return null;
            var node = this.getNodeById(ilogDiagram, id);
            if (!node)
               return null;
            return ilogDiagram.getGraphElementFromDataItem(node);
         } catch (e) {
            console.error(e);
            return null;
         }
      },

      /**
       * Find the GFX element representing the node's halo associated with a given ID
       */
      getGfxHaloForId : function(ilogDiagram, id) {
         try {
            if (!id || !ilogDiagram)
               return null;
            var gfxNode = this.getGfxNodeById(ilogDiagram, id);
            if (!gfxNode)
               return;
            var halo = gfxNode.halo;
            return halo;
         } catch (e) {
            console.error(e);
            return null;
         }
      },

      /**
       * Find the link model item associated with a given ID
       */
      getLinkById : function(ilogDiagram, id) {
         if (!id || !ilogDiagram)
            return null;
         // Get the list of links available as an ItemFileReadStore
         var links = ilogDiagram.linksStore;
         // Query the store for a given link
         var link;
         links.fetchItemByIdentity({
            identity : id,
            onItem : function(item, request) {
               link = item;
            }
         });
         return link;
      },

      /**
       * Find the GFX element representing the link associated with a given ID
       */
      getGfxLinkById : function(ilogDiagram, id) {
         try {
            if (!id || !ilogDiagram)
               return null;
            var link = this.getLinkById(ilogDiagram, id);
            if (!link)
               return null;
            return ilogDiagram.asGraphElement(link);
         } catch (e) {
            console.error(e);
            return null;
         }
      },

      /**
       * Return all of the links for a diagram
       */
      getAllLinks : function(ilogDiagram) {
         try {
            if (!ilogDiagram)
               return null;
            var links = [];
            ilogDiagram.linksStore.fetch({
               onComplete : lang.hitch(this, function(linkItems, request) {
                  var link;
                  for ( var i = 0; i < linkItems.length; i++) {
                     links.push(linkItems[i]);
                  }
               })
            });
            return links;
         } catch (e) {
            console.error(e);
            return null;
         }
      },
      
      /**
       * Return all of the nodes for a diagram that satisfy the specified filter
       */
      getNodes : function(ilogDiagram, filter) {
         try {
            if (!ilogDiagram)
               return null;
            var unfilteredNodes = [];
            var filteredNodes = [];
            ilogDiagram.nodesStore.fetch({
               onComplete : lang.hitch(this, function(nodeItems, request) {
                  var node;
                  for ( var i = 0; i < nodeItems.length; i++) {
                     unfilteredNodes.push(nodeItems[i]);
                  }
               })
            });
            if (!filter) return unfilteredNodes;
            for (var i = 0; i < unfilteredNodes.length; i++) {
               if (filter(unfilteredNodes[i])) {
                  filteredNodes.push(unfilteredNodes[i]);
               }
            }
            return filteredNodes;
         } catch (e) {
            console.error(e);
            return null;
         }
      },
      
      /**
       * Return all link ids in the diagram
       * 
       */
      getAllLinkIds : function(ilogDiagram) {
         try {
            if (!ilogDiagram)
               return null;
            var links = this.getAllLinks(ilogDiagram);
            if (!links) {
               return null; 
            }
            var linkIds = [];
            for (var i = 0; i < links.length; i++) {
               linkIds.push(links[i].id[0]);
            }
            return linkIds;
         } catch (e) {
            console.error(e);
            return null;
         }
      },
      
      /**
       * Return all node ids in the diagram that satisfy the specified filter
       * 
       */
      getNodeIds : function(ilogDiagram, filter) {
         try {
            if (!ilogDiagram)
               return null;
            var nodes = this.getNodes(ilogDiagram, filter);
            if (!nodes) {
               return null; 
            }
            var nodeIds = [];
            for (var i = 0; i < nodes.length; i++) {
               nodeIds.push(nodes[i].id[0]);
            }
            return nodeIds;
         } catch (e) {
            console.error(e);
            return null;
         }
      },
      
      toUrl: function(path) {
      	var url = require.toUrl(path);
        // remove build id when Dojo cacheBust is used
        if (window.dojoConfig && window.dojoConfig.cacheBust) {
	        if (url.indexOf('?'+window.dojoConfig.cacheBust) > 0) {
				url = url.replace('?'+window.dojoConfig.cacheBust,'');
			}
		}      	
      	return url;
      }

   });
   return new ILogDiagramUtils();
});