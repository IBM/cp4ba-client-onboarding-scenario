/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"../../main",
"dojo/_base/declare",
"dojox/gfx",
"dojo/_base/lang",
"../../interactors/DragInteractor",
"../interactors/ConnectionTargetInteractor",
"../undo/ReConnectAction",
"../undo/ReparentingAction",
"../undo/MultipleAction",
"../undo/UndoActionList",
"../../Port",
"../../util/GraphUtil"
], function(
iid,
declare,
gfx,
lang,
DragInteractor,
ConnectionTargetInteractor,
ReConnectAction,
ReparentingAction,
MultipleAction,
UndoActionList,
Port,
gu
){

/*=====
var DragInteractor = ibm_ilog.diagram.interactors.DragInteractor;
=====*/

var LinkConnectionHandleInteractor =
declare("ibm_ilog.diagram.editor.interactors.LinkConnectionHandleInteractor", [DragInteractor], {

	//	_handle: /*ibm_ilog.diagram.editor.ConnectionHandle*/
	_handle:null,
	_automaticPortType: false,
	_target: null,
	_targetPosition: null,
	_targetInteractor: null,
	_allowFreeLinks: false,
	_link: null,
	_savedConnection: null,
	_oldLinkParent: null,
	
	initialize: function( /* ibm_ilog.diagram.editor.ConnectionHandle */ connectionHandle ) {
		this._handle = connectionHandle;
		this._viewport = connectionHandle.getViewport();
		this._targetInteractor = new ConnectionTargetInteractor().initialize(this._handle._adorner._viewport._diagram,this);
		this._initialize();
		return this;
	},
	
	setTarget: function(target){
		// Summary:
		// 		sets the target to be binded with the link 
		this._target = target;
	},
	
	setPortPosition: function(position){
		// Summary:
		//		sets the port position where to bind the link
		this._targetPosition = position;
	},
	_getInitialEventSource: function() {
		return this._handle;
	},

    _dragPreStart: function() {
		this._allowFreeLinks = this._viewport.getDiagram().getAllowFreeLinks();
		this._handle.interactionBegun(this);
		this.inherited(arguments);
	},
	
	_dragMove: function(e) {
    	
		this.inherited(arguments);
		
    	var A = this._handle._adorner;
    	var V = A._viewport;
    	var portPosition = this._handle.getLocation();

		if( this._link == null ){
			this._link = A._adorned;
			this._link._no_reconnect_on_add = true; // to avoid an infinite event look
			this._targetPosition = null;
			var fixedNode,isStart;
			
			var port,point;
			if(portPosition == 0){
				port= this._link.getStartPort();
				point= this._link.getFallbackStartPoint();
				this._link.setStartPort(null);
				fixedNode = this._link.getEndNode();
				isStart = false;
			}else{
				port= this._link.getEndPort();
				point= this._link.getFallbackEndPoint();
				this._link.setEndPort(null);
				fixedNode = this._link.getStartNode();
				isStart = true;
			}
			
			//Save unused port data
			if(port){
				this._savedConnection = {
					auto: !port._isIBMDiagramBasicPort,
					position: port._isIBMDiagramBasicPort?port.getPosition():null,
					node: port.getOwner()	
				};
			}else{
				this._savedConnection = {
						point: lang.clone(point)
				};
			}
			
			//remove unused Port
			if(port && port._isIBMDiagramBasicPort){
				port.getOwner().removePort(port);
			}
			
			//Set the top level parent
			this._oldLinkParent = this._link.getParent();
			V.getDiagram().getGraph().add(this._link);
			this._targetInteractor.setUp(fixedNode,isStart,this._allowFreeLinks);
			this._targetInteractor.activate();
		}
		
		var point = V.eventContentLocation(e);
		var t = this._link.getShapeToContainerTransform(V._diagram.getGraph().getParent()).inverse();
		point = t.transformPoint(point);
		
		if(portPosition == 0){
			point = this._displacePoint(point,this._link,true);
			this._link.setFallbackStartPoint(point);
		}else{
			point = this._displacePoint(point,this._link,false);
			this._link.setFallbackEndPoint(point);
		}
		
		this._link.validateLinkShape();
	},

	_dragEnd: function(e) {
		this.inherited(arguments);
		var A = this._handle._adorner;
		var V = A._viewport;
		var D = A._diagram;
		var portPosition = this._handle.getLocation();
		if( this._link != null ){
			if(this._target){
				var connection = {auto:this._automaticPortType,
								  position: this._targetPosition,
								  node: this._target};
				
				this._applyConnection(this._link,portPosition,connection,this._createPort);
				
				//reparent the link, with the lower common parent
				var start = this._link.getStartPort().getOwner();
				var end = this._link.getEndPort().getOwner();
				if(D.allowCreateLink(start,end)){
					var cParent = gu.lowestCommonAncestor(start,end);
					if(cParent!=this._oldLinkParent){
						if(iid.isVml){
							// workaround for VML remove/add bug, occurs here since fixVmlAdd flag was added
							var oldParent = this._oldLinkParent;
							if(oldParent) { oldParent.remove(this._link); }
							cParent.rawNode.appendChild(this._link.rawNode);
							gfx.shape.Container.add.call(cParent, this._link);
							gfx.utils.forEach(this._link, function(s){
								if(s.setFill) s.setFill(s.getFill());
								if(s.setStroke) s.setStroke(s.getStroke());
							});
						} else {
							cParent.add(this._link);
						}
					}
					var action = this._createUndoReConnectionAction(D,this._link,cParent,this._oldLinkParent,portPosition,this._savedConnection,connection);
					D.onLinkUpdated(D,this._link,false,action);
					if(D._isIBMDiagramEditor){
						D.getUndoManager().addAction(this._createUndoAction(D,this._link,cParent,this._oldLinkParent,action));
					}
				}else{
					this._applyConnection(this._link,portPosition,this._savedConnection,this._createPort);
					//TODO add onMessage call
				}
			}else{
				if(!this._allowFreeLinks){
					this._applyConnection(this._link,portPosition,this._savedConnection,this._createPort);
					//TODO add onMessage call
				}else{
					var action = this._createUndoReConnectionAction(D,this._link,this._link.getParent(),this._oldLinkParent,portPosition,this._savedConnection,connection);
					D.onLinkUpdated(D,this._link,false,action);
					if(D._isIBMDiagramEditor){
						var connection = {point:lang.clone(portPosition==0?this._link.getFallbackStartPoint():this._link.getFallbackEndPoint())};
						D.getUndoManager().addAction(this._createUndoReConnectionAction(D,this._link,this._link.getParent(),this._oldLinkParent,action));
					}
				}
			}
			
			this._savedPort = null;
			delete this._link._no_reconnect_on_add;
			this._link =null;
			this._targetInteractor.deactivate();
		}
		this._handle.interactionEnded(this);
	},
	
	_displacePoint: function(point,link,isStart){
		// Added to fix requirement 642
		var p;
		if(!isStart){
			p = link._pathPoints[link._pathPoints.length-1];
		}else{
			p = link._pathPoints[0];
		}
		var dx = (point.x-p.x)<0?5:-5;
		var dy = (point.y-p.y)<0?5:-5;
		return {x: point.x+dx, y: point.y+dy};
	},
	
	_applyConnection: function(link,portPosition,connection,portFunction){
		var port;
		if(connection.node){
			port = portFunction.call(this,connection.auto,connection.position);
			connection.node.addPort(port);
		}
		if(portPosition == 0){
			if(port){
				link.setStartPort(port);
			}else{
				link.setFallbackStartPoint(lang.clone(connection.point));
			}
		}else{
			if(port){
				link.setEndPort(port);
			}else{
				link.setFallbackEndPoint(lang.clone(connection.point));
			}
		}
	},
	
	_createPort: function(automaticPortType,position){
		var port;
		if(automaticPortType || !position){
			port = new Port.AutomaticPort();
		}else{
			port = new Port.BasicPort();
			port.setPosition(position);
		}
		return port;
	},
	_createUndoReConnectionAction: function(diagram,link,newParent,oldParent,position,savedConnection,newConnection){
		var action = new ReConnectAction(diagram,link,position,savedConnection,newConnection,this._createPort,this._applyConnection);
		return action;
	},
	_createUndoAction: function(diagram,link,newParent,oldParent,action){
		
		if(oldParent!=newParent){
			var reParentAction = new ReparentingAction();
			reParentAction.setOldParentId(diagram.getUndoManager().getParentId(oldParent));
			reParentAction.setNewParentId(diagram.getUndoManager().getParentId(newParent));
			reParentAction.setModifiedElementId(link.getId());
			var mAction = new MultipleAction(UndoActionList.ReConnect);
			mAction.addAction(action);
			mAction.addAction(reParentAction);
			return mAction;
		}else{
			return action;
		}
	}
});

return LinkConnectionHandleInteractor;

});
