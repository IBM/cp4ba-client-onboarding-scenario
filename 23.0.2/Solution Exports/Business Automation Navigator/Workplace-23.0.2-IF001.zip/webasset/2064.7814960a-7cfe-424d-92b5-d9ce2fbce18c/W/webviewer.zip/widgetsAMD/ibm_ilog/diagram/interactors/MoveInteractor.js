/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/array",
"dojo/_base/sniff",
"require",
"dojox/gfx/matrix",
"dojox/gfx/utils",
"./DragInteractor",
"../Selection",
"../util/Geometry",
"../util/GraphUtil",
"../util/Batch"
],
function(
declare,
array,
has,
require,
m,
gfxu,
DragInteractor,
Selection,
g,
gu,
Batch
){

/*=====
ibm_ilog.diagram.__MoveInteractorArgs = function() {
	//	doMove: Function?
	//		Concrete the movement to a graph element.
	//	isMovable: Function?
	//		Return true if the given graph element is allowed to move
	this.doMove = function(graphElement,originalTransform,delta) {
		//	summary:
		//		Concrete the movement to a graph element.
		//	graphElement:
		//		The graph element to move.
		//	originalTransform:
		//		The matrix representing the location from which the delta is computed.
		//	delta:
		//		The amount to translate the entity from its original location.
	}
	this.isMovable = function(graphElement) {
		//	summary:
		//		Return true if the given graph element is allowed to move
		//	graphElement:
		//		The graph element to test.
	}
};	
=====*/

var superclass = DragInteractor.prototype;

// The following classes are loaded dynamically if the editor modules are loaded.

var MultipleAction = null;
var UndoActionList = null;
var EditingUtils = null;
var _classesRequired = false;

var _requireClasses = function()
{
	if(!_classesRequired){
		// no try/catch, if we are in the editor these classes must be there.
		MultipleAction = require("../editor/undo/MultipleAction");
		UndoActionList = require("../editor/undo/UndoActionList");
		EditingUtils = require("../editor/EditingUtils");
	}
	_classesRequired = true;
}

/*=====
var DragInteractor = ibm_ilog.diagram.interactors.DragInteractor;
=====*/

var MoveInteractor =
declare("ibm_ilog.diagram.interactors.MoveInteractor", [DragInteractor], {
	//
	//	summary:
	//		A MoveInteractor allows the user to move the currently selected entities.
	//
	
	//
	//	_selection: ibm_ilog.diagram.Selection
	//		The selection, object, whose entities are to be moved by the operation
	//
	_selection: null,

	//
	//	_viewport: ibm_ilog.diagram.widget.Diagram
	//		The viewport witht the content to move
	//
	_viewport: null,

	//
	//	_content: dojox.gfx.Group
	//		The root of the elements to make moveable, used as the source of events.
	//
	_content: null,

	//
	//	_targetSet: array
	//		The elements that are going to be moved.
	//
	_targetSet: null,
	
	//
	//	_dragCursor: string
	//		id of the cursor used while dragging
	//
	_dragCursor: "move",
		
	initialize: function( /*ibm_ilog.diagram.Selection*/ selection, /*ibm_ilog.diagram.Viewport|ibm_ilog.diagram.Graph*/ viewportOrContent, /*ibm_ilog.diagram.__MoveInteractorArgs*/ callbacks ) {
		//
		//	summary:
		//		Constructs the MoveInteractor
		//

		if(viewportOrContent._isIBMDiagramDiagram) {
			this._viewport = viewportOrContent.getViewport();
			this._content = this._viewport.getContent();
		} else if(viewportOrContent._isIBMDiagramViewport) {
			this._viewport = viewportOrContent;
			this._content = this._viewport.getContent();
		} else if(viewportOrContent._isIBMDiagramGraph) {
			this._content = gu.getSurface(viewportOrContent);
			this._cursorStyle = this._content.getEventSource().style; 
		} else {
			R.error("UnexpectedArgument");
		}

		if(callbacks) {
			if(callbacks.doMove) {
				this._doMove = callbacks.doMove;
			}
			
			if(callbacks.isMovable) {
				this._isMovable = callbacks.isMovable;
			}
		}
		this._selection = selection;
		this._initialize();
		if(has("ie") < 8) this._ie7 = true;
		return this;
	},

	_getInitialEventSource: function() {
		return this._content; 
	},
	
	activate: function() {
		//
		//	summary:
		//		Activates the receiver by connecting it to its sources of events.
		//
		this._fconnect("selection",this._selection,"onSelectionChanged",this,"_onSelectionChanged");
		this.inherited(arguments);
		if(this._enabled) {
			this._buildTargetSet();
		}
	},
	
	onEnabled: function() {
		this._buildTargetSet();
	},
	
	_onSelectionChanged: function() {
		this._buildTargetSet();
	},

	_isMovable: function(ge) {
		return true;
	},
	
	_buildTargetSet: function() {
		//
		//	summary:
		//		Builds the set of entities that are going to be affected by the drag.
		//
		//	description:
		//		Grab Nodes and Subgraphs from the _selection object. Their original 
		//    transforms are saved to be used in the drag process. We also store 
		//		viewport-to-element transforms since they are not likely to change
		//		while dragging (would require modifying the transformation of some
		//		of the parents of the selected shape). This might change if we plan
		//		to provide pan-while-moving.
		//

		var s = this._selection.fastGet();
		var gs = [];
		
		s.forEach(function(e){
			var ge = this._selection._asGraphElement(e);
			if(ge && this._isMovable(ge)) {
				// no link moving for now
				gs.push(ge);
			}
		},this);
		
		this._targetSet = array.map(gu.maximals(gs),function(e){
			return { t1:e.getTransform(), e:e, t:this.getTransformToElement(e) };
		},this);
		
	},
	
	getTransformToElement: function(e) {
		//	returns:
		//		a transform from viewport coords to element coords
		var rm = e._getRealMatrix();
		return (rm && rm.inverse());
	},

	_getGraphElementFromEvent: function (e) {
		//	summary:
		//		return the selection object
		var ge = this._getGraphElementFromEventInRoot(e, this._content);
		return ge !== this._content ? ge : null;
	},

	_dragPreStart: function(e) {
		
		var starter = this._getGraphElementFromEvent(e);
		if(starter && !starter._isIBMDiagramLink && starter.isSelectable()) {
			//
			// [AV]
			// We should not be able to click on a non-selectable/moveable entity and 
			// start the drag from there, even thouh other entities in the target set
			// may be moveable.
			// To avoid this, we peek what's right below the position where we started
			// the drag. It should be a node or subgraph, and should be selectable.
			//
			// note: We may have not selected the to-be-dragged entity yet. It might 
			//       be selected in this same click right after this handler. So we can't
			//       test for isSelected() here.
			// 
		
			this.inherited(arguments);
			this._doDragPreStart(e);
		}
	},
	
  _dragTouchPreStart: function (e) {
    e.target = e.touches[0].target;
    var starter = this._getGraphElementFromEvent(e);
    if(starter && !starter._isIBMDiagramLink && starter.isSelectable()) {
      //
      // [AV]
      // We should not be able to click on a non-selectable/moveable entity and 
      // start the drag from there, even thouh other entities in the target set
      // may be moveable.
      // To avoid this, we peek what's right below the position where we started
      // the drag. It should be a node or subgraph, and should be selectable.
      //
      // note: We may have not selected the to-be-dragged entity yet. It might 
      //       be selected in this same click right after this handler. So we can't
      //       test for isSelected() here.
      // 
      this.inherited(arguments);
      
      this._doDragPreStart(e);
    }
    
  },

  _doDragPreStart: function (e){
    
    array.forEach(this._targetSet,function(s){
      s.t = this.getTransformToElement(s.e);
      s.t1 = s.e.getTransform();
    },this);
    
    if(this._viewport) {
      // Monitor viewport transform changes while dragging, so that we can update 
      // the viewport-to-element transforms.
      this._connect("updateTransforms",this._viewport,"onViewRectChanged",this,"_viewportMoved");
    }
    
  },
  
	_viewportMoved: function(){
		var oldit = this._firstViewportT || m.identity;
		var newt = this._viewport.getViewportTransform();
		
		// compute the new location of the first click in client coords.
		this._first = newt.transformPoint(oldit.transformPoint(this._first));
		
		array.forEach(this._targetSet,function(s){
			s.t = this.getTransformToElement(s.e);
		},this);
		this._firstViewportT = this._viewport.getViewportInverseTransform();
	},

	_doMove: function(graphElement,originalTransform,delta) {
		//	summary:
		//		Concrete the movement to a graph element.
		//	graphElement:
		//		The graph element to move.
		//	originalTransform:
		//		The matrix representing the location from which the delta is computed.
		//	delta:
		//		The ammount to translate the entity from its original location.
		graphElement.setTransform(m.multiply(originalTransform,m.translate(delta)));
		// workaround for IE7 bug when selecting several objects quickly
		if(this._ie7 && !graphElement._isIBMDiagramSubgraph){
			gfxu.forEach(graphElement, function(s){
				if(s.setShape && !s._isIBMDiagramMultilineText)
					s.setShape(s.getShape());
			});
		}
	},
	
	_dragMove: function(e) {
		//
		//	summary:
		//		Applies the current movement delta to the selected objects.
		//
		//	notes:
		//		It ends up transforming the UI coords to model coords and back to scrollbars coords,
		//		May need to be refactored if this is a performance bottleneck
		//
		
		// this.inherited(arguments); 
		// replaced by the following for performance:
		superclass._dragMove.apply(this, arguments);
		//
		
    this._doDragMove(e);
	},
	
  _dragTouchMove: function (e) {
    //
    //  summary:
    //    Applies the current movement delta to the selected objects.
    //
    //  notes:
    //    It ends up transforming the UI coords to model coords and back to scrollbars coords,
    //    May need to be refactored if this is a performance bottleneck
    //
    
    // this.inherited(arguments); 
    // replaced by the following for performance:
    superclass._dragTouchMove.apply(this, arguments);
    //
    this._doDragMove(e);
  },	
  
  _doDragMove: function (e){
    // check move limits defined on the Graph if any:
    var current = this._current;
    array.forEach(this._targetSet,function(s){
      var delta = g.subPoint(m.multiplyPoint(s.t,current),m.multiplyPoint(s.t,this._first));
      var p = s.e.getParent();
      if (p && p.onElementMoving) {
        var oldx = delta.x;
        var oldy = delta.y;
        p.onElementMoving.call(p, s.e, s.t1, delta);
        if (delta.x != oldx || delta.y != oldy)
          current = m.multiplyPoint(s.t.inverse(),g.addPoint(delta, m.multiplyPoint(s.t,this._first)));
      }
    },this);
    
    array.forEach(this._targetSet,function(s){
      var delta = g.subPoint(m.multiplyPoint(s.t,current),m.multiplyPoint(s.t,this._first));
      this._doMove(s.e,s.t1,delta);
    },this);
    
    Batch.endBatch(); // update links immediately for better visual result
    
  },
	_dragEnd: function(e) {
		var dragged = this.hasDragged;
		this.inherited(arguments);
    this._doDragEnd(dragged);
	},
	
  _dragTouchEnd: function (e) {
    var dragged = this.hasDragged;
    this.inherited(arguments);
    this._doDragEnd(dragged);
  },
  
  _doDragEnd: function (dragged){
    this._disconnect("updateTransforms");
    
    if(dragged && this._viewport && this._viewport.getDiagram()._isIBMDiagramEditor){
      var um = this._viewport.getDiagram().getUndoManager();
      um.addAction(this._createUndoAction());
    }
    
  },
  
	_createUndoAction: function(){
		
		_requireClasses();
		
		var mAction = new MultipleAction(UndoActionList.Move);
		
		array.forEach(this._targetSet, function(s){
			var action = EditingUtils.createMoveUndoAction(s.e, s.t1, s.e.getTransform());
			mAction.addAction(action);
		});
			
		return mAction;
	}
});

return MoveInteractor;

});
