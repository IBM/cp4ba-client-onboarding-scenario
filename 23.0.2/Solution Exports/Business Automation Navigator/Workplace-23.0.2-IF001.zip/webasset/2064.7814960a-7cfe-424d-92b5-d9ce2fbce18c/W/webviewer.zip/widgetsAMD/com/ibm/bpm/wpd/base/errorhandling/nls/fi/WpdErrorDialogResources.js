define({      
//begin v1.x content
    errorDialogTitle: "IBM BPM -virhe",
    moreDetails: "Lisää tietoja...",
    closeMessage: "Sulje kaikki virhesanomat",
    contentMessage: "Järjestelmässä on ilmennyt virhe."
//end v1.x content
});

