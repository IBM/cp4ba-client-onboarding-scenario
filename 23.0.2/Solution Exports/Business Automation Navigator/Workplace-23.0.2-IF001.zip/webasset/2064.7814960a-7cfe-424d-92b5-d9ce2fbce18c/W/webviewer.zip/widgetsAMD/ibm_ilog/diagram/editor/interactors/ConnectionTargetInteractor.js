/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"../../interactors/Interactor",
"../adorners/ConnectionTargetAdorner",
"../../util/Geometry",
"../../util/GraphUtil"
], function(
declare,
Interactor,
ConnectionTargetAdorner,
g,
gu
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var ConnectionTargetInteractor =
declare("ibm_ilog.diagram.editor.interactors.ConnectionTargetInteractor", [Interactor], {
	//
	//	summary:
	//		A ConnectionTargetInteractor controls the process of selecting the target Connection point
	//		This feature has a low cpu usage alternative. (set in the diagram)
	//
	//
	//	_viewport: ibm_ilog.diagram.widget.Viewport
	//		The diagram viewport 
	//
	_viewport: null,

	//
	//	_diagram: ibm_ilog.diagram.widget.Diagram
	//		The diagram to pan
	//
	_diagram: null,

	_targetIsFree: true,

	_target: null,

	_targetAdorner: null,

	_margin: 12,

	_fixedNode: null,
	_isStart: true,
	_standardCursor: null,
	_forbiddenCursor: "not-allowed",
	_allowedCursor: "crosshair",
	_connectionInteractor: null,
	_lowCpuMode: null,
	_lastPosition: null,

	initialize: function ( /*ibm_ilog.diagram.widget.Diagram*/ diagram, connectionInteractor) {
		this._diagram = diagram;
		this._viewport = diagram.getViewport();
		this._targetIsFree = true;
		this._target = null;
		this._connectionInteractor = connectionInteractor;
		this._targetAdorner = diagram.createAdorner(ConnectionTargetAdorner, this._diagram._adornerTemplates, "ConnectionAdorner");
		this._targetAdorner.setConnectionInteractor(connectionInteractor);
		this._initialize();
		return this;
	},

	setUp: function (node, isStart, allowFreeLinks) {
		this._fixedNode = node;
		this._isStart = isStart;
		this._allowFreeLinks = allowFreeLinks;
		if(this._lowCpuMode != this._diagram.isLowCpuMode()){
			this._lowCpuMode = this._diagram.isLowCpuMode();
			this.deactivate();
			this._initialize();
		}
		this._lastPosition = {x:0, y:0};
	},

	_declareStates: function () {
		if(this._lowCpuMode == true){
			this._declareState("idle", ["nodeover", "subgraphover", "testfreetarget"]);
		}else{
			this._declareState("idle", ["detectOnOver"]);
		}
	},

	getDefaultConnections: function () {
		//
		//	summary:
		//		returns the default event mapping
		//
		if(this._lowCpuMode == true){
			return {
				nodeover: {
					src: this._diagram,
					srcEvt: "onNodeMouseOver",
					connectTo: "_setTarget"
				}, subgraphover: {
					src: this._diagram,
					srcEvt: "onSubgraphMouseOver",
					connectTo: "_setTarget"
				}, testfreetarget: {
					src: this._viewport.getEventSource(),
					srcEvt: "onmousemove",
					connectTo: "_testFreeTarget",
					gfxConnect: true
				}
				};
				
		}else{
						return {
				detectOnOver: {
					src: this._viewport.getEventSource(),
					srcEvt: "onmousemove",
					connectTo: "_detectOnOver",
					gfxConnect: true
				}
				};
		}
	},

	_setTarget: function (ge, e) {
		if (this._targetIsFree || gu.isContainedBy(ge, this._target)) {
			var start, end;
			if (this._isStart) {
				start = this._fixedNode;
				end = ge;
			} else {
				end = this._fixedNode;
				start = ge;
			}
			var D = this._diagram;
			if (!D.allowCreateLink(start, end)) {
				D.domNode.style.cursor = this._forbiddenCursor;
			} else {
				D.domNode.style.cursor = this._allowedCursor;
			}
			this._setTargetAdorner(ge);
			this._targetIsFree = false;
			//dojo.stopEvent(e);
		}
	},

	_setTargetAdorner: function (ge) {
		this._target = ge;
		this._targetAdorner.setAdorned(ge);
		this._connectionInteractor.setTarget(ge);
	},

	activate: function () {
		this.inherited(arguments);
		this._standardCursor = dojo.isIE ? "default" : this._diagram.domNode.style.cursor;
		this._setFreeCursor();
	},

	deactivate: function () {
		this.inherited(arguments);
		this._freeTarget();
		this._diagram.domNode.style.cursor = this._standardCursor;
	},

	_freeTarget: function (e) {
		if (!this._targetIsFree) {
			this._targetAdorner.setAdorned(null);
			this._connectionInteractor.setTarget(null);
		}
		this._targetIsFree = true;
		this._target = null;
		this._setFreeCursor();
	},

	_testFreeTarget: function (e) {
		if (!this._targetIsFree) {
			var c = this._target;
			if (c) {
				var bb = g.expandRect(c.getBounds(this._viewport.getSurface()), this._margin);
				var l = this._viewport.eventClientLocation(e);
				if (!g.containsPoint(bb, l)) {
					this._freeTarget();
				}
			}
		}
	},
	_setFreeCursor: function () {
		if (this._allowFreeLinks) {
			this._diagram.domNode.style.cursor = this._allowedCursor;
		} else {
			this._diagram.domNode.style.cursor = this._forbiddenCursor;
		}
	},
	_detectOnOver: function (e) {
		//added to increase performance
		var current = {x:e.pageX, y:e.pageY};
		var delta = {
				x: Math.abs(current.x - this._lastPosition.x),
				y: Math.abs(current.y - this._lastPosition.y)
			};
		var minDelta = 2;
		if(delta.x<minDelta && delta.y<minDelta){
			return;
		}
		
		this._testFreeTarget(e);	
		var p = this._viewport.eventContentLocation(e);
		var ges = this._diagram.getGraph().hitTest(p,0);
		for (var index in ges){
			var ge = ges[index];
			if(ge._isIBMDiagramNode || ge._isIBMDiagramSubgraph){
				this._setTarget(ge,e);
				break;
			}
		}
		
		this._lastPosition = {x:current.x, y:current.y};
		
	}

});

return ConnectionTargetInteractor;

});
