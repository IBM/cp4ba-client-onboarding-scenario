/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/lang", "dojo/_base/connect"],
function(lang, connect){
	
	// TODO: Change to this when AMD conversion is complete:
	// var gi = {};
	var gi = lang.getObject("ibm_ilog.diagram.util.GlobalInitialization", true);
	
	gi._initializing = 0;
	
	gi.then = function(cb) {
		//
		//	summary:
		//		Executes cb after all registered entities have initialized.
		//
		if(!gi._initializing) {
			cb();
		} else {
			var h = connect.connect(gi,"_finishedInit",function(){
				cb();
				connect.disconnect(h);
			});
		}
	};
	
	gi.beginInit = function() {
		//
		//	summary:
		//		Notify an entity begins initialization.
		//
		
		gi._initializing++;
	};
	
	gi._finishedInit = function() {

	};

	gi.endInit = function() {
		//
		//	summary:
		//		Notify an entity just finished initialization.
		//
		gi._initializing--;
		if(!gi._initializing) {
			gi._finishedInit();
		}
	};
	
	return gi;
});
