/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/connect",
"dojox/collections/Dictionary",
"../../util/LimitedStack",
"../../util/GraphUtil"
], function(
declare,
connect,
Dictionary,
LimitedStack,
gu
){
	
	var UndoManager =
	declare("ibm_ilog.diagram.editor.undo.UndoManager", [], {
	//
	//	summary:
	//		this class is the central component of the Undo Management system.
	//	The undo management provides the user the ability to undo applied changes to the diagram, and after an undo operation, the redo of the undone
	//	action. This feature is available out of the box in the DiagramEditor, and support not only all standard changes that can be applied through 
	//  the DiagramEditor, but also any simple property change that the user could apply programmatically, with the corresponding undo object registration.
	//	More complex operation can also be supported by the Undo Management system, but the user would be responsible for the implementation of the custom undo action
	//
	_undoList:null,
	_redoList:null,
	_geList: null,
	_geReplacementList: null,
	_diagram: null,
	_maximumStackSize: null,
	
	constructor:function(diagram){
		//
		//	summary:
		//		creates a new instance of UndoManager
		//
		this._undoList = new LimitedStack();
		this._redoList = new LimitedStack();
		this._geReplacementList = new Dictionary();
		this._geList = new Dictionary();
		this._diagram = diagram;
		this._connectOnCreate();
	},
	
	_connectOnCreate: function(){
		connect.connect(this._diagram,'onNodeCreated',this,this._registerGraphElement);
		connect.connect(this._diagram,'onLinkCreated',this,this._registerGraphElement);
		connect.connect(this._diagram,'onSubgraphCreated',this,this._registerGraphElement);
		connect.connect(this._diagram,'beforeGraphElementDispose',this,function(ge){this._unregisterGraphElement(ge.getId());});
		
		//adds the top level graph
		// workaround to add id to topLevelGraph 
		var graph = this._diagram.getGraph();
		graph.getId = function(){return 'topLevelGraph';};
		this._registerGraphElement(graph,this._diagram);
	},
	
	_registerGraphElement: function(ge,diagram){
		//
		//	summary:
		//		register a new ge id
		var id = ge.getId();
		this._geList.add(id,ge);
	},
	
	_unregisterGraphElement: function(id){
		//
		//	summary:
		//		unregister a ge id
		this._geList.remove(id);
	},
	
	addAction:function(action){
		//
		//	summary:
		//		adds an action to the undo action stack (clearing the redo stack) 	
		this._undoList.push(action);
		this._redoList.clear();
		action.setUndoManager(this);
		this.onChange(action);
	},
	
	undoAction:function(){
		//
		//	summary:
		//		unstacks an action from the undo stack, apply the undo operation and stack it on the redo stack
		if(this._undoList.count > 0){
			var action = this._undoList.pop();
			action.undo();
			this._redoList.push(action);
			this.onChange(action);
		}
	},
	
	redoAction:function(){
		//
		//	summary:
		//		unstack an action from the redo stack, apply the redo operation and stack it on the undo stack
		if(this._redoList.count > 0){
			var action = this._redoList.pop();
			action.redo();
			this._undoList.push(action);
			this.onChange(action);
		}
		
	},
	
	getUndoStack:function(){
		//
		//	summary:
		//		returns a copy of the undo stack
		return this._undoList.clone();
	},
	
	getRedoStack:function(){
		//
		//	summary:
		//		returns a copy of the redo stack
		return this._redoList.clone();
	},

	getUndoStackCount:function(){
		//
		//	summary:
		//		returns the size of the undo stack
		return this._undoList.count;
	},
	
	getRedoStackCount:function(){
		//
		//	summary:
		//		returns the size of the redo stack
		return this._redoList.count;
	},

	onChange:function(action){
		//
		//	summary:
		//		this method is called when and undo or redo action is applied
	},
	
	getRegisteredGraphElement: function(id){
		//
		//	summary:
		//		gets the registered graph element corresponding to the given id, looking for the replacement if necessary
		if(!id){
			return null;
		}
		var replacementId = this.getRegisteredGraphElementReplacement(id);
		return this._geList.item(replacementId);
	},
	
	registerGraphElementReplacement: function(oldId,newId){
		//
		//	summary:
		//		register when a graph element id is replaced by another (when a ge is removed and by a undo/redo operation a replacement is created again, with a new Id)
		this._geReplacementList.add(oldId,newId);
	},
	
	getRegisteredGraphElementReplacement: function(id){
		//
		//	summary:
		//		gets the registered replacement for the given ge id. Look for it recursively so as to find the last replacement.
		//		if not replacement is registered the given ge id is returned.
		
		var newId = this._geReplacementList.item(id);
		if(newId && newId!=id){
			var otherId = this.getRegisteredGraphElementReplacement(newId);
			if(newId && otherId && newId!=otherId){
				newId = otherId;
				this._geReplacementList.add(id,newId);
			}
		}
		return newId?newId:id;
	},
	
	getRegisteredParent: function(id){
		//
		//	summary:
		//		return the graph parent for the given id.
		//		If the id correspond to a subgraph, the inner graph is returned.
		var parent = this.getRegisteredGraphElement(id);
		if(parent._isIBMDiagramSubgraph){
			return parent.getGraph();
		}
		return parent;
	},
	
	getParentId: function(parent){
		//
		//	summary:
		//		get the Parent id.
		//		If the given parent is a graph from a subgraph, return the subgraph id. 
		//		If the parent is the top level graph, the graph id is returned
		var sg = gu.getOwningSubgraph(parent);
		return sg?sg.getId():parent.getId();
	},
	
	setMaximumStackSize: function(stackSize){
		//
		//	summary:
		//		sets the maximum stack size
		this._maximumStackSize = stackSize;
		var notify = stackSize && (this._undoList.count>stackSize || this._undoList.count>stackSize);
		this._undoList.setMaxSize(stackSize);
		this._redoList.setMaxSize(stackSize);
		if(notify){
			this.onChange(null);
		}
	},
	
	getMaximumStackSize: function(){
		//
		//	summary:
		//		gets the maximum stack size
		return this._maximumStackSize;
	},
	
	getDiagram: function(){
		//
		//	summary:
		//		gets the used Diagram
		return this._diagram;
	},
	
	reset: function(){
		this._undoList.clear();
		this._redoList.clear();
		this._geReplacementList.clear();
		this._geList.clear();
		this.onChange(null);
	}
	});
	
	return UndoManager;
	
});
