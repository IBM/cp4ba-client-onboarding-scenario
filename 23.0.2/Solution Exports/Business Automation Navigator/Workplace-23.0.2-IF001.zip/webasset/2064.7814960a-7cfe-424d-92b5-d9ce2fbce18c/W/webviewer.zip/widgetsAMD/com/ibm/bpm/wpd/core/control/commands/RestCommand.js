define(["dojo/_base/declare",
        "dojo/_base/lang",
        "dojo/dom",
        "./BaseCommand",
        "../WpdRestHandler",
        "../../../base/errorhandling/WpdLogger",
        "dojo/_base/xhr",
        ],

function(declare,
		lang,
		dom,
        BaseCommand,
        WpdRestHandler,
        WpdLogger, xhr) {
return declare([BaseCommand], {

	url: null,
	sendRequest : function(){
        this.getAccessToken().then(lang.hitch(this, function (token) {
            var params = this.getRequestParams(), headers;
            if (token) {
                headers = {"Authorization": "Bearer " + token}
            }
            this.url = params.url;
            WpdRestHandler.getInstance().performRequest(params.action, params.url, lang.hitch(this, this.onSuccess), lang.hitch(this, this.onError),
                headers, null, null, null, null,null,this.preventCache(), this.params.systemID, this.params.restUrlPrefix);
        }));
	},

	onError : function (response){
		var className = this.declaredClass;
		var methodName = "onError";
		var status = response.status;
		var message = "Error on url: " + this.url +
		'\nMessage: ' + status + ": " + response.message;

		var loadingImg = dom.byId("wpdLoadingImag");
		if (!!loadingImg) {
			loadingImg.style.display = "none";
		}

		//log into server and show a dialog if fatal
		WpdLogger.logError(className, methodName, message, 'severe');

	},

	onSuccess : function (response){
		//m.ibm.bpm.wpd.core.control.WpdRestHandler.getInstance().removeUrl(this.url);
	},

	/*
	 * Prevent cache on dojo rest call, overwrite.
	 */
	preventCache: function() {
		return false;
    },

    getAccessToken: function getAccessToken () {
    if (this._getAccessTokenPromise === undefined) {
            this._getAccessTokenPromise = xhr.post({
                url: dojoConfig.App._bpmContextRootMap.rest + "/v1/system/session/token",
                handleAs: "json",
                sync: true,
                load: lang.hitch(this, function(response) {
                    var token;
                    if (response && response.data && response.data.access_token) {
                        token = response.data.access_token;
                    }
                    return token;
                }),
                error: lang.hitch(this, this.onError)
            });
        }
        return this._getAccessTokenPromise;
    }

});

});
