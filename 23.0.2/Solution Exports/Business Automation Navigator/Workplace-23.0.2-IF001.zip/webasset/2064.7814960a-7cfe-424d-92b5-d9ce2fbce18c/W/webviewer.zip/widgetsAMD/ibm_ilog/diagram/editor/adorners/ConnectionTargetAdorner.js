/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"../../base",
"../../adorners/AdornerWithHandles",
"../adorners/ConnectionTargetHandle",
"../../util/Geometry"
], function(
declare,
iid,
AdornerWithHandles,
ConnectionTargetHandle,
g
){
/*=====
var AdornerWithHandles = ibm_ilog.diagram.adorners.AdornerWithHandles;
=====*/

	var Point = g.Point;
	
	var ConnectionTargetAdorner =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.ConnectionTargetAdorner',[AdornerWithHandles],{

    	initialize: function() {
    		this.inherited(arguments);

    		this._createHandle(ConnectionTargetHandle,"hndT").setup(Point(0.5,0));
    		this._createHandle(ConnectionTargetHandle,"hndR").setup(Point(1,0.5));
    		this._createHandle(ConnectionTargetHandle,"hndB").setup(Point(0.5,1));
    		this._createHandle(ConnectionTargetHandle,"hndL").setup(Point(0,0.5));
    	},
    
    	setConnectionInteractor: function(connectionInteractor){
    		this["hndT"].setConnectionInteractor(connectionInteractor);
    		this["hndR"].setConnectionInteractor(connectionInteractor);
    		this["hndB"].setConnectionInteractor(connectionInteractor);
    		this["hndL"].setConnectionInteractor(connectionInteractor);
    	},
    	
    	activate: function() {
    		this._activateHandle("hndT");
    		this._activateHandle("hndR");
    		this._activateHandle("hndB");
    		this._activateHandle("hndL");
    	},
    	
    	deactivate: function() {
    		this._deactivateHandle("hndT");
    		this._deactivateHandle("hndR");
    		this._deactivateHandle("hndB");
    		this._deactivateHandle("hndL");
    	}

    }));

	return ConnectionTargetAdorner;
	
});
