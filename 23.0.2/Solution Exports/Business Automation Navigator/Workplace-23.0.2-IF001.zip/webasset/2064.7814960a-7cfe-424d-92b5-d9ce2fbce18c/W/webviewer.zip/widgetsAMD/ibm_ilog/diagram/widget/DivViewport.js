/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/declare", 
		"dojo/_base/sniff", 
		"dojo/_base/window", 
		"dojo/_base/connect", 
		"dojo/dom-attr", 
		"dojo/dom-style", 
		"dojox/gfx/matrix", 
		"dijit/registry", 
		"./Viewport", 
		"../util/HandleSet", 
		"../util/Geometry", 
		"../util/ErrorReporter"], 
		function(declare, has, window, connect, doma, domstyle, matrix, registry, Viewport, HandleSet, g, R){

	var Size = g.Size, PointZero = g.PointZero, Point = g.Point;
	
	function getScrollBarWidth(){
		var a = document.createElement('p');
		a.style.width = "100%";
		a.style.height = "200px";
		var b = document.createElement('div');
		b.style.position = "absolute";
		b.style.top = "0px";
		b.style.left = "0px";
		b.style.visibility = "hidden";
		b.style.width = "200px";
		b.style.height = "150px";
		b.style.overflow = "hidden";
		b.appendChild(a);
		document.body.appendChild(b);
		var w1 = a.offsetWidth;
		b.style.overflow = 'scroll';
		var w2 = a.offsetWidth;
		if (w1 == w2) 
			w2 = b.clientWidth;
		document.body.removeChild(b);
		return (w1 - w2);
	};
	
	/*=====
	 var Viewport = ibm_ilog.diagram.widget.Viewport;
	 var HandleSet = ibm_ilog.diagram.util.HandleSet;
	 =====*/
	var DivViewport = declare('ibm_ilog.diagram.widget.DivViewport', [Viewport, HandleSet], {
		//
		//	summary:
		//		This is a Viewport class based on an HTML <div> which overflows with scrollbars.
		//
		//	description:
		//
		//		DivViewport depends on a div declared at Diagram.html with attachPoint=scrollbarsNode.
		//		This div encloses the diagram Surface. 
		//		
		//		The diagram Surface is extended to enclose the whole diagram tightly. The 
		//		div is constrained to the desired client size using its width and height 
		//		properties. The view rectangle is then associated with the div scroll 
		//		positions, scrollTop and scrollLeft. Setting the view rectangle then 
		//		updates scrollTop and scrollLeft.
		//
		//		The zoom level is derived from the view rectangle, but is mapped entirely 
		//		different than its position. Instead, the zoom controls a scale transformation 
		//		of the entire Diagram. If the view rectangle is small, the Diagram is zoomed 
		//		in to fit the requested portion into the viewport window. With this also the 
		//		Surface is scaled, as it is required that the entire Graph fits the surface 
		//		exactly so that the scrollTop/scrollLeft properties work.
		//		
		//	note:
		//		the zooming service required from the Diagram object should be at a UI 
		//		level and should not affect, for example, the bouding box of the the Graph 
		//		objects. One option is to define an intermediate node between the Surface root 
		//		and the Graph node, which controls this transformation.
		//
		
		//
		//	The DOMNode of the div to which we bound
		//
		_scrollbars: null,
		
		_scrollbarsContent: null,
		
		_scrollbarWidth: 0, // TODO compute this
		_scrollCache: PointZero,
		
		_hScrollbarVisible: true,
		
		_vScrollbarVisible: true,
		
		templateString: function(){
			return "<div style='overflow:hidden; position:relative;' tabindex='-1' role='presentation'>" +
			"<div dojoAttachPoint='scrollbarsNode' style='z-index:0; position:absolute; top:0px; left:0px; overflow:auto' tabindex='-1' role='presentation'>" +
			"<div dojoAttachPoint='scrollbarsContentNode' style='visibility:hidden' tabindex='-1' role='presentation'></div>" +
			"</div>" +
			"<div dojoAttachPoint='canvasNode' style='z-index:1; position:absolute; top:0px; left:0px'></div>" +
			"</div>";
		},
		
		//
		//	_updatingScrollbars:
		//		true when scrollbar position is being updated and we will ignore related events
		//		useful in chrome since it reports events immediately.
		//
		_updatingScrollbars: false,
		
		_computeScrollbarWidth: function(){
			return (this._scrollbarWidth = getScrollBarWidth());
		},
		
		getScrollbarWidth: function(){
			return this._scrollbarWidth || this._computeScrollbarWidth();
		},
		
		getHudSize: function(){
			var hsz = this.getClientSize();
			var sbw = this.getScrollbarWidth();
			if (!this._hScrollbarVisible) {
				hsz.height += sbw;
			}
			if (!this._vScrollbarVisible) {
				hsz.width += sbw;
			}
			return hsz;
		},
		
		updateScrollbarVisibilityFlags: function(){
			var hv = (this._scrollbars.scrollWidth > this._scrollbars.clientWidth);//(this._viewRect.width<this._contentRect.width);
			if (this._hScrollbarVisible != hv) {
				this._hScrollbarVisible = hv;
				this._needsHudRelayout = true;
			}
			var vv = (this._scrollbars.scrollHeight > this._scrollbars.clientHeight);//(this._viewRect.height<this._contentRect.height);
			if (this._vScrollbarVisible != vv) {
				this._vScrollbarVisible = vv;
				this._needsHudRelayout = true;
			}
		},
		_getSurfaceXOffset:function(){
			return this.isRtl() ? (this._vScrollbarVisible ? this.getScrollbarWidth(): 0) : 0;
		},
		
		_onContentBoundingBoxChanged: function(){
			//
			//	summary:
			//		The function is executed when the content of the content has changed.
			//
			//	returns:
			//		True if the change affected content bounding box.
			//
			//	tags:
			//		private
			//
			this.inherited(arguments)
		},
		_canvasNode:null,
		initialize: function( /*ibm_ilog.diagram.widget.Diagram*/diagram){
			//
			//	summary:
			//		Initializes a Viewport for collaborating with the diagram.
			//
			//	diagram: ibm_ilog.diagram.widget.Diagram
			//		The diagram
			//
			this._scrollbars = diagram.scrollbarsNode;
			this._scrollbarsContent = diagram.scrollbarsContentNode;
			this._canvasNode = diagram.canvasNode;
			this.inherited(arguments);
			
			this._connect("onscroll", this._scrollbars, "onscroll", this, "_onScroll");
			if (!diagram.getParent()) 
				this._connect("onresize", has("ie") ? diagram.domNode : window.global, "onresize", this, "_onResize");
			
			var parent = registry.getEnclosingWidget(diagram.domNode.parentNode);
			
			// we are in dojox.mobile
			if (parent && typeof(parent.onAfterTransitionIn) == "function") {
				connect.connect(parent, "onAfterTransitionIn", this, "_onAfterTransitionIn");
				
			};
		},
		
		_debug: false,
		
		_onScroll: function(e){
			if (!this._updatingScrollbars) {
				var p = Point(this._scrollbars.scrollLeft, this._scrollbars.scrollTop);
				
				if (this._debug) {
					console.log("cached:", g.printRect(this._scrollCache), ", scroll:", g.printPoint(p));
				}
				
				// The following condition traps bouncing events generated by 
				// the receiver updating the scrollbar programatically
				
				if (!g.equalPoint(this._scrollCache, p)) {
					var q = this._pointScrollToModel(p);
					this.setViewRect(q, {
						instant: true
					});
				}
			}
		},
		
		_onResize: function(e){
			if (!this._diagram.domNode) 
				return; // widget has probably been removed from the DOM... TODO: remove the listener?
			var csz = this._computeInitialSize();
			this.setSize(csz, false);
		},
		
		_onAfterTransitionIn: function(){
			this.updateScrollbarVisibilityFlags();
			var csz = this._computeInitialSize();
			this.setSize(csz, false);
			
		},
		
		setClientSize: function( /*Size*/sz){
			//
			//	summary:
			//		Sets the client Size
			//
			this.setSize({
				width: sz.width + this.getScrollbarWidth(),
				height: sz.height + this.getScrollbarWidth()
			});
		},
		
		setSize: function( /*Size*/sz){
			//
			//	summary:
			//		Sets the Viewport Size
			//
			var sbw = this.getScrollbarWidth();
			
			var style = {
				style: {
					width: sz.width + "px",
					height: sz.height + "px"
				}
			};
			
			if (arguments.length < 2 || arguments[1]) 
				doma.set(this._diagram.domNode, style);
			doma.set(this._scrollbars, style);
			
			this._updateClientSize(Size(sz.width - sbw, sz.height - sbw));
			this._updateSurface();
		},
		
		
		_updateClientSize: function( /*Size*/sz){
			//
			//	summary:
			//		Updates viewportRect from the div attributes
			//
			//	tags:
			//		private
			//
			var vpH = sz.height || this._scrollbars.clientHeight;
			var vpW = sz.width || this._scrollbars.clientWidth;
			
			var newClientSize = {
				width: vpW,
				height: vpH
			};
			
			
			if (!g.equalRect(this._clientSize, newClientSize)) {
			
				this._clientSize = newClientSize;
				
				this._computeContentRect();
				
				switch (this._resizeMode) {
					case 1: // keep zoom level
						// Note that we do NOT set the height attribute. Explanation from Abel:
						// setViewRect can handle missing variables and they are 
						// inferred. We never want to change the aspect ratio, so this is a 
						// way of specifying priority: "take whatever height you need, but 
						// set width to what I give you"
						this.setViewRect({
							x: this._viewRect.x,
							y: this._viewRect.y,
							width: (newClientSize.width / this.getZoom())
						}, {
							instant: true
						});
						break;
					case 2:
						this._onViewRectConstraintsChanged();
						break;
					default:
						R.error("InvalidViewportResizeMode", this._resizeMode)
				}
				
				this.onClientSizeChanged();
				
			}
		},
		
		_pointContentToScroll: function(p){
			var r = g.subPoint(this._viewportMatrix.transformPoint(p), this._transformedContentRect);
			if (has("ff") && this._scrollCache && this.isRtl()) {
				//https://bugzilla.mozilla.org/show_bug.cgi?id=383026
				var corr = this._scrollCache.width - this._viewportMatrix.transformRectangle(this._viewRect).width;
				r.x = r.x - corr;
			}
			return r;
		},
		
		isRtl: function(){
			//	summary:
			//		returns true if running on RTL mode.
			//	note:
			//		Peller said in the forum that RTL is supported only if set at the body. This is a dijit limitation.
			return doma.get(window.doc.body, "dir") == "rtl";
		},
		
		_pointScrollToModel: function(p){
			if (has("ff") && this._scrollCache && this.isRtl()) {
				//https://bugzilla.mozilla.org/show_bug.cgi?id=383026
				var corr = this._scrollCache.width - this._viewportMatrix.transformRectangle(this._viewRect).width;
				p.x = corr + p.x;
			}
			return this._viewportMatrixInverse.transformPoint(g.addPoint(this._transformedContentRect, p));
		},
		
		onViewRectChanged: function onViewRectChanged(){
			this.updateScrollbarVisibilityFlags();
			this.inherited(arguments);
		},
		
		_applyViewRect: function( /*Boolean*/sizeChanged, /*Boolean*/ originChanged){
			//
			//	summary:
			//		Updates the surface size and _transformedContentRect based on the _viewRect and
			//		_contentRect. Called after a change in zoom or Graph content.
			//
			//	tags:
			//		private
			//
			
			if (!this.__initialized) {
				return;
			}
			
			this.inherited(arguments);
			
			// create transformation, apply if to Graph, and compute new transformedContentRect
			var zt = matrix.scale(this._zoom);
			var tt = matrix.translate(g.negPoint(this._viewRect)); // uses rect origin
			var t = matrix.multiply(zt, tt);
			
			this._transformedContentRect = t.transformRectangle(g.addRect(this._viewRect, this._contentRect));
			
			var scrollContentSize = g.floorSize(g.growRect(this._transformedContentRect, this.getClientSize()));
			// this._transformedContentRect;
			// [AV] replace by this go back to tight surface mode
			
			this._viewportMatrix = t;
			this._viewportMatrixInverse = t.inverse();
			
			var scrollCache = g.floorPoint(this._pointContentToScroll(this._viewRect));
			
			scrollCache.width = scrollContentSize.width;
			scrollCache.height = scrollContentSize.height;
			
			this._updatingScrollbars = true; // needed for chrome
			//this._disconnect("onscroll"); // does not seem to work for avoiding the event generated 
			// update in the following lines
			
			// "if" to avoid updating in the wrong order (shrinking width while position requires it, and viceversa.)
			// and to avoid updating unless strictly necessary
			if (scrollCache.width >= this._scrollCache.width) {
				if (this._scrollCache.width != scrollCache.width) {
					this._scrollbarsContent.style.width = scrollCache.width + "px";
				}
				if ((this._scrollCache.x) != (scrollCache.x)) {
					this._scrollbars.scrollLeft = scrollCache.x;
				}
			} else {
				if (this._scrollCache.x != scrollCache.x) {
					this._scrollbars.scrollLeft = scrollCache.x;
				}
				if (this._scrollCache.width != scrollCache.width) {
				
					this._scrollbarsContent.style.width = scrollCache.width + "px";
				}
			}
			
			if (scrollCache.height >= this._scrollCache.height) {
				if (this._scrollCache.height != scrollCache.height) {
					this._scrollbarsContent.style.height = scrollCache.height + "px";
				}
				if (this._scrollCache.y != scrollCache.y) {
					this._scrollbars.scrollTop = scrollCache.y;
				}
			} else {
				if (this._scrollCache.y != scrollCache.y) {
					this._scrollbars.scrollTop = scrollCache.y;
				}
				if (this._scrollCache.height != scrollCache.height) {
					this._scrollbarsContent.style.height = scrollCache.height + "px";
				}
			}
			
			scrollCache.x = this._scrollbars.scrollLeft; // sometimes the assignment fails, not setting the correct value
			scrollCache.y = this._scrollbars.scrollTop; // this gets the real into the cache
			this._scrollCache = scrollCache;
			
			this._updatingScrollbars = false;
			
			// give the change to the DOM to process the recent 
			// updates so we don't get their notifications
			//		setTimeout(dojo.hitch(this,function(){
			//			this._connect("onscroll",this._scrollbars,"onscroll",this,"_onScroll");
			//		}),1);
			
			this._setViewportTransform(t);
		}
		
		
	});
	
	
	return DivViewport;
	
});
