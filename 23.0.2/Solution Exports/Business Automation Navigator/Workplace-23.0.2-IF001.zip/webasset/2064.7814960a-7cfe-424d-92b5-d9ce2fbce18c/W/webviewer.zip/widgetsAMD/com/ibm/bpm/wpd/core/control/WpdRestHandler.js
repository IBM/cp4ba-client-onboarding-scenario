define(["dojo/_base/declare",
        "dojo/_base/connect",
        "dojo/_base/lang",
        "dojo/_base/xhr",
        "dojo/_base/kernel",
        "com.ibm.bpm.wpd/base/bootstrap",
        "../model/shellstate/ShellStateModel"],
function(declare,
		connect,
		lang,
		xhr,
		kernel, bootstrap,
		ShellStateModel) {

var _WpdRestHandler = declare([], {
	iContext: null,
	_serviceURLRoot: null, //will hardcode some value here

	_outstandingRequest: null,

	constructor : function (iContext, serviceURLRoot) {
		this.iContext = iContext;
		this.serviceURLRoot = serviceURLRoot;
		this._outstandingRequest = {};
	},

	performRequest: function(verb, url, loadFn, errorFn, headers, isSync, message, deferred, handleAsType, xMethodOverride, preventCache, systemID, restUrlPrefix) {
        var requestUrl;
        if (restUrlPrefix) {
            requestUrl = restUrlPrefix + url;
        } else {
            requestUrl = this.serviceURLRoot + url;
        }
		//if (!!ShellStateModel.getInstance().remoteId) {
			//requestUrl = this.calculateRemoteRequestURL("rest/bpm/wle"+ url);
		//}
		this._performRequest(verb, requestUrl, loadFn, errorFn, headers, isSync, message, deferred, handleAsType, xMethodOverride, null, null, preventCache);
	},

	performProxiedRequest: function(verb, serviceURLRoot, url, loadFn, errorFn, headers, isSync, message, deferred, handleAsType, xMethodOverride, user, password) {
		var requestUrl = serviceURLRoot + url;
		this._performRequest(verb, requestUrl, loadFn, errorFn, headers, isSync, message, deferred, handleAsType, xMethodOverride, user, password);
	},

	_performRequest: function(verb, requestUrl, loadFn, errorFn, headers, isSync, message, deferred, handleAsType, xMethodOverride, user, password, preventCache) {
		if(!!this.isOutstandingUrl(requestUrl)){
			return;
		}
		this._outstandingRequest[requestUrl] = true;

		var request = {};
		request.sync = !!isSync;

		var _this = this;
		request.load = function(response){
			_this.removeUrl(requestUrl);
			loadFn(response);
		};
		//request.url = this.iContext.io.rewriteURI(requestUrl);
		request.url = requestUrl;

		request.timeout = 40000;

		if (!handleAsType) {
			request.handleAs = "json";
		} else {
			request.handleAs = handleAsType;
		}

		if (preventCache)
			request.preventCache = preventCache;

		//request.preventCache = true;
		if (errorFn) {
			request.error = function(response){
				_this.removeUrl(requestUrl);
				errorFn(response);
			};
		}
		if (headers) {
			request.headers = lang.clone(headers);
		} else {
			request.headers = new Object();
		}

		if (!!xMethodOverride) {
			request.headers["X-Method-Override"] = xMethodOverride;
		}

		if (!!user){
			request.user = user;
		}

		if (!!password){
			request.password = password;
		}

		if (verb == "put" || verb == "rawPut"){
			request.mimetype = "text/json;charset=utf-8";
			request.putData = message;
		} else if (verb == "post" || verb == "rawPost") {
			request.mimetype = "text/json;charset=utf-8";
			request.postData = message;
		}

		request.headers["Accept"] = "application/json";

		if (verb == "get") {
			deferred = kernel.xhrGet(request);
		} else if (verb == "rawPost") {
			request.postData = message;
			kernel.rawXhrPost(request);
		} else if (verb == "post") {
		    kernel.xhrPost(request);
		} else if (verb == "rawPut") {
		    kernel.rawXhrPut(request);
		} else if (verb == "put") {
		    kernel.xhrPut(request);
		} else if (verb == "delete") {
		    kernel.xhrDelete(request);
		}

	},

	isOutstandingUrl:function(url){
		return !!this._outstandingRequest[url];
	},

	removeUrl:function(url){
		delete this._outstandingRequest[url];
	}


});

var _instance;
var _WpdRestHandlerWrapper = {
	getInstance : function(iContext, serviceURLRoot) {
		return (_instance = (_instance || new _WpdRestHandler(iContext, serviceURLRoot)));
	},
	deleteInstance : function() {
		return delete _instance;
	}
}

return _WpdRestHandlerWrapper;

});

/*
com.ibm.bpm.wpd.core.control.WpdRestHandler.getInstance = function() {
	// summary:
	//	retrieve the singleton WpdRestHandler instance
	//  It is initialized in bootstrap.js during start up
	return dojo.global.BPM.WPD_RestHandler;
};
*/