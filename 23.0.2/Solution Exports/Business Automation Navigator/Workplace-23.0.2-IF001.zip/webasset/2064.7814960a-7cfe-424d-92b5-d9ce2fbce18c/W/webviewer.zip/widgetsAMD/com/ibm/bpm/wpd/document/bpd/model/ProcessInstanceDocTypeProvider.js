define(["dojo/_base/declare",
        "dojo/_base/connect",
        "dojo/_base/lang",
        "../../../core/model/documenttype/providers/BaseDocTypeProvider",
		"../view/BPDViewer",
		"../../model/VisualModelHelper",
		"com.ibm.bpm.wpd/base/bootstrap",
		"../../../core/control/WpdRestHandler"],
function(declare,
		connect,
		lang,
		BaseDocTypeProvider,
		BPDViewer,
		VisualModelHelper,
		bootstrap,
		WpdRestHandler) {

return declare([BaseDocTypeProvider], {

	config : null,

	contructor : function () {
		this.config = {};
		this.config.additionalDataHandlers = [];
	},
	
	getDocType: function(){
	
		return "ProcessInstanceType";
	},
	
	createViewer : function(model, parent){
		var params = {viewStateModel:model};
		params.config = this.config;
		params.type = this.getDocType();
		var viewer = new BPDViewer(params, parent);	
		return viewer;
	},
	
	reuseViewer : function(){
		return false;
	},
	
	getDocumentId: function (properties){
		var documentId = !!properties.documentId ? properties.documentId: properties.bpdId;
		return documentId;	
	},
	
	getInstanceIds: function(){
		return this.config.instanceIds;
	},
	
	getDisplayName: function (properties){
		return properties.instanceName;
	},
	
	getRequestParams:function(properties){		
		var params = {};
		params.action = "get";				
		params.url = this.getPORestPath(properties);
		return params;
	},
	
	getPORestPath: function(properties){
		var instanceIds;
		if(!!properties.instanceIds){
			instanceIds = properties.instanceIds;
			this.config.instanceIds = instanceIds;
		}
		else{
			instanceIds = this.config.instanceIds;
		}
		var branchId = properties.branchId;
		var snapshotId = properties.snapshotId;
		var documentId = properties.documentId;
        var projectId = properties.projectId;
		
		var url;
		if (!!instanceIds) {
		    // /rest/bpm/wle/v1/visual/processModel/instances?instanceIds=[53,54,55]
		    // /rest/bpm/wle/v1/visual/processModel/instance/{instanceId}
		    var instanceIdsStr = "[" + instanceIds.toString() + "]";
		    url = "/v1/visual/processModel/instances" + "?instanceIds=" + instanceIdsStr;
		    //params.showExecutionPath = true;
		    //params.showCurrentActivites = true;
		    //params.showNote = false;
		    //params.showColor= false,
		    var showExecutionPath = !!this.config.showExecutionPath ? this.config.showExecutionPath: true;
		    var showCurrentActivites = !!this.config.showCurrentActivites ? this.config.showCurrentActivites: true;
		    var showNote = !!this.config.showNote ? this.config.showNote: false;
		    var showColor = !!this.config.showColor ? this.config.showColor: false;

	        if (!!documentId){
	            url = url + "&bpdId=" + documentId;
	        }
	        if (!!branchId){
	            url = url + "&branchId=" + branchId;
	        }
	        else if(snapshotId){
	            url = url + "&snapshotId=" + snapshotId;
	        }
		} else {
    		if (!!documentId && (!!projectId || !!snapshotId || !!branchId)) {
    		    url = "/v1/visual/processModel/" + documentId + "?";
    		    if (!!snapshotId) {
    		        url = url + "snapshotId=" + snapshotId;
    		    }
    		    if (!!branchId) {
    		        if (!!snapshotId) {
    		            url = url + "&";
    		        }
    		        url = url + "branchId=" + branchId;
    		    }
                if (!!projectId) {
                    if (!!snapshotId || !!branchId) {
                        url = url + "&";
                    }
                    url = url + "projectId=" + projectId;
                }
    		}
		}

		url = url + "&showCurrentActivites=" + showCurrentActivites
						+ "&showExecutionPath="   + showExecutionPath
						+ "&showNote=" 			+ showNote
						+ "&showColor=" 		+ showColor; 
		return url;
	},

	/**
	 * Make more rest call or function call to retrive additional data and update the model
	 * @param model the data model 
	 * @param params, params passed in from event
	 */
	processResponseData : function(model, params) {
		this.updateModelForCriticalPath(model, params);
		if (!!this.config.additionalDataHandlers){
			for (var i=0; i<this.config.additionalDataHandlers.length; i++) {
				this.config.additionalDataHandlers[i](model, params.instanceIds, this.getDocumentId(params));
			}
		}
		return model;
	},
	
	updateModelForCriticalPath: function(data, params){
		//this.config.criticalPathFlowIds is set in the generateProcessInstanceIlog.jsp
		if (this.config.criticalPathFlowIds.length==0) {
			return data;
		}
		
		if (params.subProcParentId) {		
																
				WpdRestHandler.getInstance()._performRequest(
						"get", 
						bootstrap.getEndPointAndContextRootForModule(bootstrap.wpdConstant.BPM_WARNAME_PROCESSPORTALSUPPORT) + "/jsp/criticalPath?action=GET_FLOWS&parentId=" + params.subProcParentId, 
						lang.hitch(this, function(response) {
							this.updateLink(data, response);	
						}),
						null, 
						null, 
						true);
		} else {
			this.updateLink(data, this.config.criticalPathFlowIds);	
		} 

		return data; 
	},
	
	updateLink : function(data, flowIds) {
			for (var i=0; i<data["links"].length; i++) {
				var mylink = data["links"][i];
				if (this.isLinkInCriticalPath(flowIds, mylink.id)) {
					mylink["inCriticalPath"]=true;
				}
			}
	},
	
	isLinkInCriticalPath : function(criticalPathFlowIds, linkId) {
		for (var i=0; i<criticalPathFlowIds.length; i++) {
			if (linkId==criticalPathFlowIds[i]) {
				return true;
			}		
		}		
		return false;
	},

	getIconPath : function(size){
		//if(size == 16){
			//return "images/processes-16.png";
		//}
	},
		
	/**
	 * 
	 * @param model
	 * @param updateType the function supported by VisualModelHelper
	 * @param params
	 */
	updateModel: function(model, updateType, params){
		if (updateType == "decorateNodeWithImage"){		 
			VisualModelHelper.decorateNodesWithImage(model, params);
		}
	}
});

});
