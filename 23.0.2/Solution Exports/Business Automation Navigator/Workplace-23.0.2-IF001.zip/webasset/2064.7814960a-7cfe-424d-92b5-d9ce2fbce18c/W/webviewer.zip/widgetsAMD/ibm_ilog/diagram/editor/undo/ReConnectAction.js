/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"./UserCustomizedAction",
"./UndoActionList"
], function(
declare,
lang,
UserCustomizedAction,
UndoActionList
){
	
/*=====
var UserCustomizedAction = ibm_ilog.diagram.editor.undo.UserCustomizedAction;
=====*/

	var ReConnectAction =
	declare("ibm_ilog.diagram.editor.undo.ReConnectAction", [UserCustomizedAction], {
		//	
		// summary:
		//		this action undo/redo any ReConnect action.
		//		This action must be modified for the user if any user defined action is done on a ReConnect action.
		//
		_linkId: null,
		_applyConnectionFunction: null,
		_createPortFunction: null,
		_oldConnection: null,
		_newConnection: null,
		_portPosition: null,
	
	constructor:function(diagram,link,position,savedConnection,newConnection,createPort,applyConnection){
		
		this._label = UndoActionList.ReConnect;
		this._linkId = link.getId();
		this._portPosition = position;
		this._createPortFunction = lang.hitch(this,createPort);
		this._applyConnectionFunction = lang.hitch(this,applyConnection);
		
		savedConnection.nodeId = savedConnection.node?savedConnection.node.getId():null;
		savedConnection.node = null;
		this._oldConnection = savedConnection;
		
		newConnection.nodeId = newConnection.node?newConnection.node.getId():null;
		newConnection.node = null;
		this._newConnection = newConnection;
	},
	_clearPort: function(){
		var port;
		var link = this.getUndoManager().getRegisteredGraphElement(this._linkId);
		if(this._portPosition == 0){
			port = link.getStartPort();
			link.setStartPort(null);
		}else{
			port = link.getEndPort();
			link.setEndPort(null);
		}
		//remove Port
		if(port && port._isIBMDiagramBasicPort){
			port.getOwner().removePort(port);
		}
	},
	getLink: function(){
		// Summary:
		//		return the link modified (verifying replaces)
		return this.getUndoManager().getRegisteredGraphElement(this._linkId);
	},
	isStartModified: function(){
		// Summary:
		//		return true if the start of the link is the modified component.
		return this._portPosition == 0;
	},
	undoFunction: function(){
		var link = this.getLink();
		var node = this.getUndoManager().getRegisteredGraphElement(this._oldConnection.nodeId);
		this._oldConnection.nodeId = node.getId();
		this._clearPort.call(this);
		this._oldConnection.node = node;
		this._applyConnectionFunction.call(null,link,this._portPosition,this._oldConnection,this._createPortFunction);
		this._oldConnection.node = null;
		var D = this.getUndoManager().getDiagram();
		D.onLinkUpdated(D,link,false,this);
	},
	
	redoFunction: function(){
		var link = this.getLink();
		var node = this.getUndoManager().getRegisteredGraphElement(this._newConnection.nodeId);
		this._newConnection.nodeId = node?node.getId():null;
		this._clearPort.call(this);
		this._newConnection.node = node;
		this._applyConnectionFunction.call(null,link,this._portPosition,this._newConnection,this._createPortFunction);
		this._newConnection.node = null;
		var D = this.getUndoManager().getDiagram();
		D.onLinkUpdated(D,link,false,this);
	}
	});
	
	return ReConnectAction;
	
});
