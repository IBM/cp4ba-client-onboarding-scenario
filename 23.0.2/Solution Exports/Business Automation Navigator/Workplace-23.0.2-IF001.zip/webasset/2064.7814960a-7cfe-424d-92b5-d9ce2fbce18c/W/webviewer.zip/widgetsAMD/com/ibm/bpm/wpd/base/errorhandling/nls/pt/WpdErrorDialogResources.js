define({      
//begin v1.x content
    errorDialogTitle: "Erro do IBM BPM",
    moreDetails: "Mais detalhes...",
    closeMessage: "Fechar todas as mensagens de erro",
    contentMessage: "Ocorreu um erro."
//end v1.x content
});

