// ErrorDialog.js
// BEGIN COPYRIGHT
// *************************************************************************
//
// Licensed Materials - Property of IBM
// 5725-C96
// Copyright IBM Corporation 2011, 2013. All Rights Reserved.
// US Government Users Restricted Rights- Use, duplication or disclosure
// restricted by GSA ADP Schedule Contract with IBM Corp.
//
// *************************************************************************
// END COPYRIGHT
define(["dijit/Dialog",
        "dojo",
        "dojo/i18n!./nls/WpdErrorDialogResources", //"dojo/i18n!./nls/ErrorMessage",
        "dijit/_Widget",
        "dijit/_TemplatedMixin"], function(Dialog, dojo, i18n){

  /**
   * In order to correctly use this Error Dialog, the following Dashboards CSS must to be loaded on the html page as well.
   *    /dashboards/src/main/resources/com/ibm/bpm/dashboards/controls/css/errorDialog.css
   *
   * NOTE: This ErrorDialog is from the Dashboards module becuase the current WpdErrorDialog has a dependency on GWT for styleing.
   *        Originial: /dashboards/src/main/resources/com/ibm/bpm/dashboards/utils/ErrorDialog.js
   *
   * TODO This is a simple Error Dialog for first tests based on the Process Portal error dialog
   */
  var ErrorDialog = {};

  ErrorDialog =
    dojo.declare("ErrorDialog", [dijit._Widget,
                                 dijit._TemplatedMixin], {
      baseClass: "ErrorDialog",
      baseTextDirection: "ltr", //Default to LTR base text direction
      controlId: "",

      templateString: "<div><div class='error-dialog-box'>"
        + "<div dojoAttachPoint='message' class='error-dialog-message'></div>"
        + "<div dojoAttachPoint='detailsTitle' style='display:inline'></div>"
        + "<div dojoAttachPoint='detailsContent' class='error-dialog-details-content'></div>" + "</div>"
        + "<div dojoAttachPoint='buttonContainer' class='bpmDashboardsDialogButtonContainer'></div>"
        + "<div style='clear: both'></div>" + "</div>",

      widgetsInTemplate: false,

      _dialog: null,

      _title: null,
      _message: "",
      _label: null,
      _details: null,

      /**
       * Creates a popup which will show a message.
       * 
       * @param message The message to be shown
       * @param details The details to be shown
       * @param label The label of the confirmation button
       * 
       * Please use the static method below instead of directly instanciating the popups.
       * 
       */
      constructor: function(params){
        this._nlsResources = i18n;

        if (typeof params.labelKey === 'string') {
          this._label = this._nlsResources[params.labelKey];
        }
        if (typeof params.titleKey === 'string') {
          this._title = this._nlsResources[params.titleKey];
        }
        if (typeof params.message === 'string') {
          this._message = params.message;
        }
        if (typeof params.label === 'string') {
          this._label = params.label;
        }
        if (typeof params.details === 'string') {
          this._details = params.details;
        }
      },

      postCreate: function postCreate_ErrorDialog(){
        this.inherited(arguments);

        if (this._title) {
          this._dialog = new Dialog({
            "class": "bpmDashboardsDialog",
            "title": this._title
          });
          this._dialog.titleBar.style.borderBottom = "0px";
        }
        else {
          this._dialog = new Dialog({});
        }

        this.message.innerHTML = this._message;
        var self = this;
        if (this._label != null) {
          this._addButton(this.id + "_confirmationButton", this._label, function(){
            self.hide();
          });
        }

        // If details exist, create a title pane for it.
        if (this._details) {
          var bundle = i18n;

          var detailsTitlePic = document.createElement("div");
          detailsTitlePic.innerHTML = "+";
          dojo.addClass(detailsTitlePic, "error-dialog-details-title");
          this.detailsTitle.appendChild(detailsTitlePic);

          var detailsTitleLabel = document.createElement("div");
          //detailsTitleLabel.innerHTML = bundle["dialog_details_more"];
          detailsTitleLabel.innerHTML = bundle["moreDetails"];
          dojo.addClass(detailsTitleLabel, "error-dialog-details-title");
          this.detailsTitle.appendChild(detailsTitleLabel);

          this.detailsTitle.tabIndex = "0";

          dojo.style(this.detailsContent, "display", "none");
          this.detailsContent.innerHTML = this._details;

          var detailsHidden = true;
          this.connect(this.detailsTitle, "ondijitclick", function(e){
            if (detailsHidden) {
              dojo.style(this.detailsContent, "display", "block");
              detailsHidden = false;
              detailsTitlePic.innerHTML = "-";
              //detailsTitleLabel.innerHTML = bundle["dialog_details_hide"];
            }
            else {
              dojo.style(this.detailsContent, "display", "none");
              detailsHidden = true;
              detailsTitlePic.innerHTML = "+";
              //detailsTitleLabel.innerHTML = bundle["dialog_details_more"];
            }
          });
        }
        else {
          dojo.style(this.detailsTitle, "display", "none");
          dojo.style(this.detailsContent, "display", "none");
        }

        this.connect(this._dialog, 'onHide', "_finish");
        this.inherited("postCreate", arguments);
      },

      _addButton: function(id, value, callback, context){
        if (this.buttonContainer) {
          var button = document.createElement("button");
          button.innerHTML = value;
          dojo.attr(button, "title", value);
          button.id = id;

          // If context is not provided or undefined, use a null context
          if (context == undefined) {
            dojo.attr(button, "onclick", dojo.hitch(null, callback));
          }
          else {
            dojo.attr(button, "onclick", dojo.hitch(context, callback));
          }
          this.buttonContainer.appendChild(button);
        }
      },

      _finish: function _finish_ErrorDialog(){
        // Trigger any subsequent user actions 
        // Synchronous call to event handler methods.
        this.onClose();
        // Basically this is also a dijit._Widget with a meaningful destroy method.#
        // Because the onHide event is triggered within a fade, one cannot immediately destroy everything.
        setTimeout(dojo.hitch(this, this.destroy), 1000);
      },

      /**
       * Event handling hook.
       */
      onClose: function onClose_ErrorDialog(){
      },

      show: function(){
        if (!this.loaded) {
          this._dialog.attr("content", this.domNode);
          this.loaded = true;
        }

        this._dialog.show();
      },

      hide: function(){
        this._dialog.hide();
      },

      destroy: function(finalize){
        if (this._dialog) {
          this._dialog.destroy();
          this._dialog = null;
        }
        this.inherited('destroy', arguments);
      }

    });

  /**
   * Creates a modal error popup with the provided message. <br />
   * I.e. dojo.require("ErrorDialog"); ErrorDialog.showError(message, details);
   * 
   * @param message The message to be shown
   * @param details The details to be shown
   */
  ErrorDialog.showError =
    function(message /* string */, details /* string */){
      var dialog = new ErrorDialog({
        "titleKey": "errorDialogTitle",
        "labelKey": "closeMessage",
        "message": message,
        "details": details
      });
      dialog.show();
    };

  return ErrorDialog;

});