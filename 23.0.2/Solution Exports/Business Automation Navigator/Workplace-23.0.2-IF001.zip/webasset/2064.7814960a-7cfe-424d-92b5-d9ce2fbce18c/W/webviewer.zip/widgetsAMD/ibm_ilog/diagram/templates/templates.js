/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"../main",
"dojo/_base/lang", "dojo/_base/config",
"dojox/collections/Dictionary",
"../util/MultilineText",
"../data/dtlbinding"
],
function(iid, lang, config, Dictionary, MultilineText, dtlbinding){

	// TODO: Change to this when AMD conversion is complete:
	// var t = {};
	var t = lang.getObject("ibm_ilog.diagram.templates", true);
	
if (config.useGfxLayout) {

	// NODE - GFX-LAYOUT TEMPLATE

t.defaultNodeTemplate = [{
    dojoAttachPoint: 'baseShape',
    shape:{
        width:80, height:40, r: (iid.isVML ? "0" : "5"),
        type:'rect'
    },
    fill: '{{backgroundColor}}',
    stroke: {'color': '{{borderColor}}', 'width': 2 },
    selectedStyle: {
        fill: '{{selectedBackgroundColor}}'
    }
},{
    dojoAttachPoint: 'textShape', 
    margins:[5,2,5,2],
    shape:{
        type:'mltext',
        text:'{{label}}', 
        wrap: $bind('{{wrap}}'), width: 70,
        align:'middle'
    }, 
    editable: {
        id:'label',
        editor:'textbox',
        border:2,
        minRegionSize:{width:50,height:15},
        regionStyle:{selectedStyle:{stroke:{color:'white',style:'ShortDot'}}},
        layoutProperties: {margins:[5,5,5,5], valign: 'center', halign: 'center'}
    },
    fill:'{{textColor}}', 
    font:{type:'font', size:'10pt', family:'sans-serif'},
    selectedStyle: {
        fill: '{{selectedTextColor}}'
    }
}];

t.defaultOverviewNodeTemplate = [{
  dojoAttachPoint: 'baseShape',
  shape:{
      width:80, height:40, r: (iid.isVml ? "0" : "5"),
      type:'rect'
  },
  fill: '{{backgroundColor}}',
  stroke: {'color': '{{borderColor}}', 'width': 2 }
}];

} else {

	// NODE - NON GFX-LAYOUT TEMPLATE

t.defaultNodeTemplate = [{
    dojoAttachPoint: 'baseShape',
    shape: {
        x: 0,
        y: 0,
        width: 80,
        height: 40,
        r: 5,
        type: 'rect'
    },
    fill: '{{backgroundColor}}',
    stroke: {
        'color': '{{borderColor}}',
        'width': 2
    },
    selectedStyle: {
        fill: '{{selectedBackgroundColor}}'
    }
}, {
   dojoAttachPoint: 'textShape',
   shape: {
       type: 'text',
       text: '{{label}}',
       x: 40,
       y: 24,
       align: 'middle'
   },
   editable: {
       id:'label',
       editor:'textbox',
       border:2,
       regionStyle:{selectedStyle:{stroke:{color:'white',style:'ShortDot'}}},
       baseRegion:{x:20,width:40,y:11,height:15}
   },
   fill: '{{textColor}}',
   font: {
       type: 'font',
       size: '10pt',
       family: 'sans-serif'
       },
   selectedStyle: {
       fill: '{{selectedTextColor}}'
   }
}];

t.defaultOverviewNodeTemplate = [{
  dojoAttachPoint: 'baseShape',
  shape: {
      x: 0,
      y: 0,
      width: 80,
      height: 40,
      r: 5,
      type: 'rect'
  },
  fill: '{{backgroundColor}}',
  stroke: {
      'color': '{{borderColor}}',
      'width': 2
  }
}];

}

t.defaultLinkTemplate = [{
    dojoAttachPoint: '_path',
    shape: {
        type: 'polyline',
        points: [{
            x: 0,
            y: 0
        }, {
            x: 100,
            y: 0
        }]
    },
    stroke: {
        width: $bind("{{strokeWidth}}"),
        color: '{{strokeColor}}'
    },
    selectedStyle: {
        stroke: {
            width: $bind("{{selectedStrokeWidth}}"),
            color: '{{selectedStrokeColor}}'
        }
    }
}, {
    dojoAttachPoint: '_endArrow',
    shape: {
        type: 'polyline',
        points: [{
            x: -8,
            y: 4
        }, {
            x: 0,
            y: 0
        }, {
            x: -8,
            y: -4
        }]
    },
    fill: '{{strokeColor}}',
    selectedStyle: {
        fill: '{{selectedStrokeColor}}'
    }
}];

t.defaultOverviewLinkTemplate = [{
  dojoAttachPoint: '_path',
  shape: {
      type: 'polyline',
      points: [{
          x: 0,
          y: 0
      }, {
          x: 100,
          y: 0
      }]
  },
  stroke: {
      width: $bind("{{strokeWidth}}"),
      color: '{{strokeColor}}'
  }
}];

if (config.useGfxLayout) {

	// SUBGRAPH - GFX-LAYOUT TEMPLATE

    t.defaultSubgraphTemplate = [{
        dojoAttachPoint: '_expandedGroup',
        layout: {
            type: 'ibm_ilog.diagram.gfxlayout.GridLayout',
            rows: [{
                height: -1
            }, {
                height: -1
            }]
        },
        children: [{
            dojoAttachPoint: '_expandedBaseShape',
            row: 0,
            rowspan: -1,
            shape: {
                type: 'rect',
                width: 0,
                height: 0,
                r: 4
            },
            fill: '{{headerColor}}',
            selectedStyle: {
                fill: '{{selectedHeaderColor}}'
            },
            stroke: '#404040'
        }, {
			hfiller:true,
            dojoAttachPoint: '_header',
            row: 0,
            margins: [2, 0, 2, 2],
            layout: {
                type: 'ibm_ilog.diagram.gfxlayout.StackLayout',
                horizontal: true,
                gap: 2
            },
            children: [{
                dojoAttachPoint: '_collapseButton',
                valign: 'center',
                layout: {
                    type: 'ibm_ilog.diagram.gfxlayout.GridLayout'
                },
                children: [{
                    shape: {
                        type: 'rect',
                        width: 12,
                        height: 12,
                        r: 4
                    },
                    fill: '#808080'
                }, {
                    valign: 'center',
                    halign: 'center',
                    shape: {
                        type: 'line',
                        x1: 3,
                        y1: 6,
                        x2: 9,
                        y2: 6
                    },
                    stroke: {
                        color: 'white',
                        width: 2
                    }
                }]
            }, {
            	layout: {
					type: 'ibm_ilog.diagram.gfxlayout.GridLayout'
				},
				children:[{
                dojoAttachPoint: 'titleShape',
				valign: 'center', halign: 'left',
                shape: {
                    type: 'text',
                    text: '{{label}}',
                    align: 'start'
                },
                fill: '{{textColor}}',
                font: {
                    type: 'font',
                    size: '10pt',
                    family: 'sans-serif'
                },
                editable: {
                    id: 'label',
                    editor: 'textbox',
                    options: {
                        style: {
                            'text-align': 'left'
                        }
                    },
                    border: 2,
			        regionStyle:{selectedStyle:{stroke:{color:'white',style:'ShortDot'}}},
    		    	layoutProperties: { valign: 'center', halign: 'left'}
                },
                selectedStyle: {
                    fill: '{{selectedTextColor}}'
                }
				}]
            }]
        }, {
            dojoAttachPoint: '_graphBackground',
            row: 1,
            margins: 2,
            col: 0,
            shape: {
                type: 'rect',
                width: 0,
                height: 0
            },
            fill: '{{graphBackgroundColor}}'
        }, {
            dojoAttachPoint: '_graph',
            row: 1,
            margins: $bind('{{graphMargin}}'),
			minimumSize: { width: 80, height: 40 },
            col: 0,
            shape: {
                type: 'graph'
            }
        }]
    }, {
        dojoAttachPoint: '_collapsedGroup',
        layout: {
            type: 'ibm_ilog.diagram.gfxlayout.GridLayout'
        },
        children: [{
            dojoAttachPoint: '_collapsedBaseShape',
            shape: {
                width: 80,
                height: 40,
                r: 5,
                type: 'rect'
            },
            fill: '{{backgroundColor}}',
            stroke: {
                'width': 2
            },
            selectedStyle: {
                fill: '{{selectedBackgroundColor}}'
            }
        }, {
            dojoAttachPoint: 'textShape',
            margins: 5,
            shape: {
                type: 'mltext',
                text: '{{label}}',
		        wrap: $bind('{{wrap}}'), width: 70,
                align: 'middle'
            },
            fill: '{{textColor}}',
            selectedStyle: {
                fill: '{{selectedTextColor}}'
            },
    		editable: {
        		id:'label',
    		    editor:'textbox',
    		    border:2,
    		    regionStyle:{selectedStyle:{stroke:{color:'white',style:'ShortDot'}}},
    		    layoutProperties: {margins:[5,5,5,5], valign: 'center', halign: 'center'}
    		},
            font: {
                type: 'font',
                size: '10pt',
                family: 'sans-serif'
            }
        }, {
            margins: 4,
            valign: 'top',
            halign: 'left',
            dojoAttachPoint: '_expandButton',
            layout: {
                type: 'ibm_ilog.diagram.gfxlayout.GridLayout'
            },
            children: [{
                shape: {
                    type: 'rect',
                    width: 12,
                    height: 12,
                    r: 4
                },
                fill: '#808080'
            }, {
                valign: 'center',
                halign: 'center',
                shape: {
                    type: 'line',
                    x1: 3,
                    y1: 6,
                    x2: 9,
                    y2: 6
                },
                stroke: 'white'
            }, {
                valign: 'center',
                halign: 'center',
                shape: {
                    type: 'line',
                    x1: 6,
                    y1: 3,
                    x2: 6,
                    y2: 9
                },
                stroke: {
                    color: 'white',
                    width: 2
                }
            }]
        }]
    }];
    
} else {

	// SUBGRAPH - NON GFX-LAYOUT TEMPLATE

	t.defaultSubgraphTemplate = [{
        dojoAttachPoint: '_expandedGroup',
        children: [{
            dojoAttachPoint: '_expandedBaseShape',
           shape: {
               type: 'rect',
               r: 5
           },
           fill: '{{headerColor}}',
           selectedStyle: {
               fill: '{{selectedHeaderColor}}'
           },
           stroke: '#404040'
       }, {
           dojoAttachPoint: '_graphBackground',
           shape: {
               type: 'rect'
           },
           fill: '{{graphBackgroundColor}}'
       }, {
            dojoAttachPoint: '_graph',
            shape: {
                type: 'graph'
            }
        }, {
           dojoAttachPoint: '_header',
           transform: { dx: -8, dy: -26 },
           children: [{
               dojoAttachPoint: '_collapseButton',
               children: [{
                   shape: {
                       type: 'rect',
                       x: 0,
                       y: 0,
                       width: 12,
                       height: 12,
                       r: 4
                   },
                   fill: '#808080'
               }, {
                   shape: {
                       type: 'line',
                       x1: 3,
                       y1: 6,
                       x2: 9,
                       y2: 6
                   },
                   stroke: {
                       color: 'white',
                       width: 2
                   }
               }]
           }, {
               dojoAttachPoint: 'titleShape',
               shape: {
                   type: 'text',
                   text: '{{label}}',
                   x: 15,
                   y: 10,
                   align: 'start'
               },
               fill: '{{textColor}}',
               font: {
                   type: 'font',
                   size: '10pt',
                   family: 'sans-serif'
               },
               editable: { 
                   id:'label', 
                   editor:'textbox', 
                   options:{style:{'text-align':'left'}},
                   border:2,
                   baseRegion:{x:20,width:40,y:0,height:15}
               },
               selectedStyle: {
                   fill: '{{selectedTextColor}}'
               }
           }]
       }]
    }, {
        dojoAttachPoint: '_collapsedGroup',
        children: [{
            dojoAttachPoint: '_collapsedBaseShape',
            shape: {
                x: 0,
                y: 0,
                width: 80,
                height: 40,
                r: 5,
                type: 'rect'
            },
            fill: '{{backgroundColor}}',
            stroke: {
                'width': 2
            },
            selectedStyle: {
                fill: '{{selectedBackgroundColor}}'
            }
        }, {
            dojoAttachPoint: 'textShape',
            shape: {
                type: 'text',
                text: '{{label}}',
                x: 40,
                y: 24,
                align: 'middle'
            },
            fill: '{{textColor}}',
            selectedStyle: {
                fill: '{{selectedTextColor}}'
            },
            editable:{
               id:'label',
               editor:'textbox',
               border:2,
               baseRegion:{x:20,width:40,y:11,height:15}
           },
            font: {
                type: 'font',
                size: '10pt',
                family: 'sans-serif'
            }
        }, {
            dojoAttachPoint: '_expandButton',
           transform: { dx:2, dy:2 },
            children: [{
                shape: {
                    type: 'rect',
                    x: 0,
                    y: 0,
                    width: 12,
                    height: 12,
                    r: 4
                },
                fill: '#808080'
            }, {
                shape: {
                    type: 'line',
                    x1: 3,
                    y1: 6,
                    x2: 9,
                    y2: 6
                },
                stroke: 'white'
            }, {
                shape: {
                    type: 'line',
                    x1: 6,
                    y1: 3,
                    x2: 6,
                    y2: 9
                },
                stroke: {
                    color: 'white',
                    width: 2
                }
            }]
        }]
    }];

}

t.defaultOverviewExpandedSubgraphTemplate = [{
	dojoAttachPoint: 'baseShape',
	shape: {
		type: 'rect'
	},
	fill: '{{graphBackgroundColor}}',
	stroke: '#404040'
}];

t.defaultOverviewCollapsedSubgraphTemplate = [{
	dojoAttachPoint: 'baseShape',
	shape: {
		type: 'rect'
	},
	fill: '{{backgroundColor}}',
	stroke: '#404040'
}];


t.defaultNodeFocusAdornerTemplate = [{
	dojoAttachPoint: 'adornerRoot',
	children:[{
   	dojoAttachPoint: 'baseShape',
   	shape: {
       x: $bind("{{elemBaseLeft}}-3"),
       y: $bind("{{elemBaseTop}}-3"),
       width: $bind("{{elemBaseWidth}}+6"),
       height: $bind("{{elemBaseHeight}}+6"),
       type: 'rect'
		},
		stroke: {
			color: 'black',
			style: 'ShortDot'
		}
	}]
}];

t.defaultAnnotationTargetAdornerTemplate = [{
	dojoAttachPoint: 'adornerRoot',
	children:[{
	   	dojoAttachPoint: 'baseShape',
	   	shape: {
	       x: $bind("{{elemBaseLeft}}"),
	       y: $bind("{{elemBaseTop}}"),
	       width: $bind("{{elemBaseWidth}}"),
	       height: $bind("{{elemBaseHeight}}"),
	       type: 'rect'
		}
	}]
}];

if(config.useGfxLayout) {

	// ANNOTATION - GFX-LAYOUT TEMPLATE

	t.defaultAnnotationAdornerTemplate = [{
		dojoAttachPoint: 'adornerRoot',
    transform:{dx: $bind("{{elemBaseRight}}+15"),dy: $bind("{{elemBaseTop}}-25")},
		layout:{ type:'ibm_ilog.diagram.gfxlayout.GridLayout'},
		children:[{
		   	dojoAttachPoint: 'baseShape',
		   	shape: {
		       width: 1,
		       height: 1,
		       type: 'rect'
			},
			stroke: {
				color: [0,0,0,1],
				style: 'ShortDot',
				width: 1
			},
			fill: [222,222,150,0.75]
		},{
		   dojoAttachPoint: 'textShape',
			valign:'center',
			halign:'center',
			margins:4,
		   shape: {
		       type: 'text',
		       text: '{{annotation|safe}}',
		       x: 5,
		       y: 15,
		       align: 'middle'
		   },
		   fill: [0,0,0],
		   font: {
		       type: 'font',
		       size: '10pt',
		       family: 'sans-serif'
		   }
		}
		]
	}];
} else {
	
	// ANNOTATION - NON GFX-LAYOUT TEMPLATE
	
	t.defaultAnnotationAdornerTemplate = [{
		dojoAttachPoint: 'adornerRoot',
    transform:{dx: $bind("{{elemBaseRight}}+15"),dy: $bind("{{elemBaseTop}}-25")},
		children:[{
	   	dojoAttachPoint: 'baseShape',
	   	shape: {
	       width: 150,
	       height: 20,
	       type: 'rect'
			},
			stroke: {
				color: [120,120,0,1],
				style: 'ShortDot',
				width: 2
			},
			fill: [120,120,0,0.5]
		},{
		   dojoAttachPoint: 'textShape',
		   shape: {
		       type: 'text',
		       text: '{{annotation|safe}}',
		       x: 5,
		       y: 15,
		       align: 'left'
		   },
		   fill: [0,0,0],
		   font: {
		       type: 'font',
		       size: '10pt',
		       family: 'sans-serif'
		   }
		}
		]
	}];
}	

t.defaultAnnotationLinkTemplate = [{
    dojoAttachPoint: '_path',
    shape: {
        type: 'polyline',
        points: [{
            x: 0,
            y: 0
        }, {
            x: 100,
            y: 0
        }]
    },
		stroke: {
			color: [0,0,0,1],
			style: 'ShortDot',
			width: 1
		},
    selectedStyle: {
        stroke: {
            width: $bind("{{selectedStrokeWidth}}"),
            color: '{{selectedStrokeColor}}'
        }
    }
}];

t.defaultLinkFocusAdornerTemplate = [{
	dojoAttachPoint: 'adornerRoot',
	children:[{
	    dojoAttachPoint: '_path',
	    shape: {
	        type: 'polyline',
	        points: [{
	            x: 0,
	            y: 0
	        }, {
	            x: 0,
	            y: 0
	        }]
	    },
	    stroke: {
			 width: 5,
	        color: [255,0,255,0.5]
	    }
	}]
}];
t.defaultLinkFocusAdornerTemplate.noDtl = true;

t.defaultAdornerTemplates = t.defaultAdornerTemplates || new Dictionary();

t.defaultAdornerTemplates.add("NodeFocusAdorner",t.defaultNodeFocusAdornerTemplate);
t.defaultAdornerTemplates.add("LinkFocusAdorner",t.defaultLinkFocusAdornerTemplate);
t.defaultAdornerTemplates.add("AnnotationAdorner",t.defaultAnnotationAdornerTemplate);
t.defaultAdornerTemplates.add("AnnotationTargetAdorner",t.defaultAnnotationTargetAdornerTemplate);
t.defaultAdornerTemplates.add("AnnotationLink",t.defaultAnnotationLinkTemplate);

t.defaultSwimLaneTemplate = "[{" +
"    dojoAttachPoint: '_expandedGroup'," +
"    layout:{" +
"       type:'ibm_ilog.diagram.gfxlayout.GridLayout'," +
" {% if vertical %}" +
"       rows:[{height:-1},{}]" +
" {% else %}" +
"  {% if rightToLeft %}" +
"       cols:[{},{width:-1}]" +
"  {% else %}" +
"       cols:[{width:-1},{}]" +
"  {% endif %}" +
" {% endif %}" +
"    }," +
"    children: [{" +
"           dojoAttachPoint: '_expandedBaseShape'," +
" {% if vertical %}" +
"           row:0, rowspan:2," +
" {% else %}" +
"           column:0, colspan:2," +
" {% endif %}" +
"           shape:{"+
"               type:'rect', width:0, height:0"+
"           },"+
"           fill:'{{headerColor}}'," +
"           selectedStyle: { "+
"               fill: '{{selectedHeaderColor}}'"+
"           }," +
"           stroke:'#404040'" +
"       }, {" +
"           dojoAttachPoint: '_header'," +
" {% if vertical %}" +
"           row:0, margins:[2,0,2,2]," +
"  {% if nested %}" +
"   		minimumSize: { width:-1, height:16 }," +
"  {% endif %}" +
" {% else %}" +
"  {% if rightToLeft %}" +
"           column:1, margins:[2,2,0,2]," +
"  {% else %}" +
"           column:0, margins:[0,2,2,2]," +
"  {% endif %}" +
"  {% if nested %}" +
"   		minimumSize: { width:16, height:-1 }," +
"  {% endif %}" +
" {% endif %}" +
"           layout:{type:'ibm_ilog.diagram.gfxlayout.GridLayout'" +
" {% if not nested %}" +
"               ," +
"  {% if vertical %}" +
"               horizontalFlow:true, cols:[{width:-1},{}]" +
"  {% else %}" +
"               horizontalFlow:false, rows:[{height:-1},{}]" +
"  {% endif %}" +
" {% endif %}" +
"           }," +
"           children:["+
" {% if not nested %}" +
"             {" +
"               dojoAttachPoint: '_collapseButton',"+
" {% if vertical %}" +
"               valign:'center', halign:'left'," +
" {% else %}" +
"               halign:'center', valign:'top'," +
" {% endif %}" +
"               layout:{type:'ibm_ilog.diagram.gfxlayout.GridLayout'}," +
"               children: [{" +
"                   shape: {" +
"                       type: 'rect'," +
"                       x: 0," +
"                       y: 0," +
"                       width: 12," +
"                       height: 12" +
"                   }," +
"                   fill: '#808080'" +
"               },{ " +
"                   valign:'center',halign:'center'," +
"                   shape: {" +
"                       type: 'line'," +
"                       x1: 3," +
"                       y1: 6," +
"                       x2: 9," +
"                       y2: 6" +
"                   }," +
"                   stroke: {" +
"                       color: 'white'," +
"                       width: 2" +
"                   }" +
"               }]" +
"           },"+
" {% endif %}" +
"           {" +
"            	layout: {" +
"					type: 'ibm_ilog.diagram.gfxlayout.GridLayout'" +
"				}," +
"				children:[{" +
"               dojoAttachPoint: 'titleShape'," +
" {% if vertical %}" +
"               valign:'center', halign:'stretch'," +
" {% else %}" +
"               halign:'center', valign:'stretch'," +
"  {% if rightToLeft %}" +
"           	transform: {xx: 0, xy: -1, yx: 1, yy: 0}," +
"  {% else %}" +
"           	transform: {xx: 0, xy: 1, yx: -1, yy: 0}," +
"  {% endif %}" +
" {% endif %}" +
"               shape: {" +
"                   type: 'text'," +
"                   text: '{{label}}'," +
" {% if vertical %}" +
"                   align: 'middle'" +
" {% else %}" +
"  {% if rightToLeft %}" +
"                   align: 'middle'" +
"  {% else %}" +
"                   align: 'middle'" +
"  {% endif %}" +
" {% endif %}" +
"               }," +
"               fill: '{{textColor}}'," +
"               font: {" +
"                   type: 'font'," +
"                   size: '10pt'," +
"                   family: 'sans-serif'" +
"               }," +
"               editable: { " +
"                   id:'label', " +
"                   editor:'textbox', " +
"                   options:{style:{'text-align':'left'}}," +
"                   border:2," +
"			        regionStyle:{selectedStyle:{stroke:{color:'white',style:'ShortDot'}}}," +
"    		    	layoutProperties: {" +
" {% if vertical %}" +
"               valign:'center', halign:'left'" +
" {% else %}" +
"               halign:'center', valign:'top'" +
" {% endif %}" +
"                   }" +
"               },"+
"               selectedStyle: {" +
"                  fill: '{{selectedTextColor}}'" +
"               }" +
"				}]" +
"           }]" +
"       }, {" +
"           dojoAttachPoint: '_graphRect'," +
" {% if vertical %}" +
"           row:1," +
" {% else %}" +
"  {% if not rightToLeft %}" +
"           column:1," +
"  {% endif %}" +
" {% endif %}" +
"           shape:{"+
"               type:'rect',"+
"               width:0,height:0"+
"           }" +
"       }, {" +
"           dojoAttachPoint: '_graphBackground'," +
" {% if vertical %}" +
"           row:1," +
" {% else %}" +
"  {% if rightToLeft %}" +
"           column:0," +
"  {% else %}" +
"           column:1," +
"  {% endif %}" +
" {% endif %}" +
"           margins:1," +
"           shape:{"+
"               type:'rect',"+
"               width:0,height:0"+
"           }," +
"           fill:'{{graphBackgroundColor}}'" +
"       }, {" +
" {% if vertical %}" +
"           row:1, column:0," +
" {% else %}" +
"  {% if rightToLeft %}" +
"           column:0," +
"  {% else %}" +
"           column:1," +
"  {% endif %}" +
"           row:0," +
" {% endif %}" +
"           margins:0," +
"           halign:'left', valign:'top'," +
"           children: [{" +
"               shape:{"+
"                   type:'rect',"+
"                   x:0,y:0,width:0,height:0"+
"               }" +
"           }, {" +
"               dojoAttachPoint: '_graph'," +
"               shape:{"+
"                   type:'graph'"+
"               }" +
"           }]" +
"       }]" +
"   }, {" +
"   dojoAttachPoint: '_collapsedGroup'," +
"   layout:{type:'ibm_ilog.diagram.gfxlayout.GridLayout'}," +
"   children:[{"+ 
"     layout:{type:'ibm_ilog.diagram.gfxlayout.GridLayout'}," +
" {% if vertical %}" +
"     halign:'left'," +
" {% else %}" +
"     valign:'top'," +
" {% endif %}" +
"     children:[{"+ 
"		 dojoAttachPoint: '_collapsedBaseShape'," +
"        shape: {" +
"            x: 0," +
"            y: 0," +
"            width: 80," +
"            height: 40," +
"            r: 5," +
"            type: 'rect'" +
"        }," +
"        fill: '{{backgroundColor}}'," +
"        stroke: {" +
"            'width': 2" +
"        }," +
"        selectedStyle: {" +
"            fill: '{{selectedBackgroundColor}}'" +
"        }" +
"   }," +
"   {" +
"        dojoAttachPoint: 'textShape'," +
"        margins:5," +
"        shape: {" +
"            type: 'mltext'," +
"            text: '{{label}}'," +
"            x: 40," +
"            y: 24," +
"	         wrap: {{wrap}}, width: 70," +
"            align: 'middle'" +
"        }," +
"        fill: '{{textColor}}'," +
"        selectedStyle: {" +
"            fill: '{{selectedTextColor}}'" +
"        }," +
"        editable:{" +
"           id:'label'," +
"           editor:'textbox'," +
"           border:2," +
"   		regionStyle:{selectedStyle:{stroke:{color:'white',style:'ShortDot'}}}," +
"   		layoutProperties: {margins:[5,5,5,5], valign: 'center', halign: 'center'}" +
"        },"+
"        font: {" +
"            type: 'font'," +
"            size: '10pt'," +
"            family: 'sans-serif'" +
"        }" +
"   }," +
"   {" +
"       margins:4," +
"       valign:'top'," +
" {% if vertical %}" +
"       halign:'left'," +
" {% else %}" +
"  {% if rightToLeft %}" +
"       halign:'right'," +
"  {% else %}" +
"       halign:'left'," +
"  {% endif %}" +
" {% endif %}" +
"       dojoAttachPoint: '_expandButton'," +
"       layout:{type:'ibm_ilog.diagram.gfxlayout.GridLayout'}," +
"       children:[{" +
"            shape: {" +
"                type: 'rect'," +
"                x: 0," +
"                y: 0," +
"                width: 12," +
"                height: 12," +
"                r: 4" +
"            }," +
"            fill: '#808080'" +
"        }, {" +
"            valign:'center',halign:'center'," +
"            shape: {" +
"                type: 'line'," +
"                x1: 3," +
"                y1: 6," +
"                x2: 9," +
"                y2: 6" +
"            }," +
"            stroke: 'white'" +
"        }, {" +
"           valign:'center',halign:'center'," +
"           shape: {" +
"                type: 'line'," +
"                x1: 6," +
"                y1: 3," +
"                x2: 6," +
"                y2: 9" +
"            }," +
"            stroke: {" +
"                color: 'white'," +
"                width: 2" +
"            }" +
"       }" +
"       ]" +
"     }" +
"     ]" +
"   }" +
"   ]" +
"}" +
"]";

return t;

});
