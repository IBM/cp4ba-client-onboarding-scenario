define(["dojo/_base/declare",
        "../MObject"],
function(declare,
		MObject) {

/**
 * ViewState of a Viewer
 *  
 */
return declare("com.ibm.bpm.wpd.core.model.viewstate.ViewStateModel", [MObject], {
		
	_documentModel: null,	// type: josn object
   // _currentSelection : null,     We might need it
    
	
	type : null,            // type: String, the type of this view {AssetListView, BPDDocType, ServiceDocType...}
	keyId: null, //branchId or snapshotId or projectId
    documentId: null,
    name : null,    
    
    constructor: function() {
		//this._currentSelection = [];
	},
	
//	setCurrentSelection : function(value){
//		this.setAttribute("_currentSelection", value);
//	},
//	
//	getCurrentSelection : function(){
//		return this._currentSelection;
//	},

	
	getDocumentModel : function (){
		return this._documentModel;
	},
	
	setDocumentModel : function(value){
		this._documentModel = value;
	}

});

});
