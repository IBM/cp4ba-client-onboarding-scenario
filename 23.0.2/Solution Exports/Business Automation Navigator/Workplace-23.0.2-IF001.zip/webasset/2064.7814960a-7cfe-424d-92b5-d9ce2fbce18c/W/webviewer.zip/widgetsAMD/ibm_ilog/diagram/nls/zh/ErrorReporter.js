/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
// NLS_CHARSET=UTF-8

define({
	//-------------------------------------------------------
	// ErrorReporter internals
	//
	
	// Explanation: An unexpected internal error has occurred in the Dojo Diagrammer code.
	// User action: This is an internal error and the cause is not immediately known. If the error persists, consult the support pages.
	Unknown: "未知错误。",
	// Explanation: The 'error' or 'warning' method of ibm_ilog.diagram.util.ErrorReporter has been called with an invalid identifier.
	// User action: Verify that identifiers passed to ibm_ilog.diagram.util.ErrorReporter methods are valid.
	InvalidErrorId: "字符串 \"${errorId}\" 不是有效的错误标识。",
	// Explanation: The ibm_ilog.diagram.util.ErrorReporter.declareError method is called with an identifier that is already declared.
	// User action: Verify that the declared error identifier is not already declared.
	ErrorIdAlreadyDeclared: "错误标识 \"${errorId}\" 已经注册。",

	
	//-------------------------------------------------------
	// Generic-JavaScript
	//
	// Explanation: A user-defined subclass of a Dojo Diagrammer base class does not define a required method.
	// User action: Verify that all required methods are declared in your subclass.
	SubclassResponsibility: "${methodName} 必须在子类中执行。",
	// Explanation: An object is null and it is expected to not be null.
	// User action: Verify that you provide an object that is not null for the object that is specified in the error message.
	NullPointerException:"${objectName} 为空。",
	// Explanation: An object is null and it is expected to not be null.
	// User action: Verify that you provide an object that is not null for the object that is specified in the error message. The error message also contains a hint to help you find the class that contains the error.
	NullPointerException2:"${objectName} 为空[提示：${where}]。",
	// Explanation: An error that was caused by another nested error has occurred.
	// User action: Refer to the user action for the nested error whose identifier is contained in the error message.
	Wrapped:"错误位于 ${process}：(${error})。",
	// Explanation: An unexpected argument value was passed to a function.
	// User action: The function name, expected value (or value range) and actual argument value are contained in the error message. Verify that the argument value is correct.
	UnexpectedArgument:"意外的参数类型或范围。",
	
	// Explanation: A function was called with an invalid number of arguments.
	// User action: The expected and actual number of arguments are contained in the error message. Verify that the number of arguments are correct.
	InvalidNumberOfArguments:"发现 ${numberOfArgs} 和一个预期的 ${options}",
	
	// Explanation: An unexpected value was returned by a function.
	// User action: The function name, expected return value type and actual return value type are contained in the error message. Verify that the returned value type is correct.
	UnexpectedReturnValueType: "意外的返回值类型。来自 ${functionName}():${expectedType} 的预期类型。已获得：${actualType}",


	//-------------------------------------------------------
	// Generic-Graph/Diagram
	//
	
	// Explanation: A function expects a graph element (for example, a node, link, or subgraph) but another type of object was found.
	// User action: Verify that a graph element is supplied.
	GraphElementExpected: "预期的图形元素：图形、节点、链接或子图。", 

	
	//-------------------------------------------------------
	// DataStore
	//
	// Explanation: The Diagram widget processed a data item that is not contained in the data store specified as the nodesStore or linksStore attributes
	// User action: Verify that the data store contains the item that is specified as the nodesStore or linksStore attributes of the Diagram widget.
	NotInDataStore:"此实体不在数据存储中。",
	// Explanation: The nodesQuery or linksQuery attribute of the Diagram widget is specified as a string, and it should be an object.
	// User action: Verify that the nodesQuery or linksQuery attribute is an object and not a string.
	CannotUseAStringForAQuery:"此存储查询必须定义为对象，不能定义为字符串。",
	// Explanation: The nodesStore attribute of the Diagram widget is not specified.
	// User action: Specify the nodesStore attribute on the Diagram widget.
	NodesStoreRequired:"窗口小部件需要定义节点存储。",	
	// Explanation: The data store that is specified as the nodesStore or linksStore attribute does not implement the dojo.data.api.Indentity interface.
	// User action: Specify a data store that implements the dojo.data.api.Indentity interface.
	StoresMustSupportIdentity:"此存储必须支持功能 'dojo.data.api.Read'。",
	// Explanation: The data store that is specified as the nodesStore or linksStore attribute does not implement the dojo.data.api.Read interface.
	// User action: Specify a data store that implements the dojo.data.api.Read interface.
	StoresMustSupportRead:"此存储必须支持功能 'dojo.data.api.Read'。",
	
	// Explanation: An error occurred while loading the data store specified as the nodesStore attribute of the Diagram widget.
	// User action: The error message contains the the nested error. Correct the nested error.
	UnexpectedErrorOnNodesStoreFetch:"访存 NodesStore 期间发生错误：(${errorString})",
	// Explanation: An error occurred while loading the data store specified as the linksStore attribute of the Diagram widget.
	// User action: The error message contains the the nested error. Correct the nested error.
	UnexpectedErrorOnLinksStoreFetch:"访存 LinksStore 期间发生错误：(${errorString})",

	
	//-------------------------------------------------------
	// Overview
	//

	// Explanation: The diagram attribute of the Overview widget is not defined.
	// User action: Define the diagram attribute of the Overview widget.
	OverviewDiagramMissing:"“预览”窗口小部件需要“图”窗口小部件（属性 'diagram'==${diagram}）。",

	
	//-------------------------------------------------------
	// WAI
	//

	// Explanation: The internal Web Accessibility Initiative (WAI) node was not found for the given graph element.
	// User action: Use the createNode/createLink/createSubgraph methods of the diagram, not the graph methods to create elements in a diagram.
	MissingWaiNode:"未找到图形元素的 WAI-ARIA 节点：${element}",

	//-------------------------------------------------------
	// ServerSideLayout
	//

	// Explanation: The specified graph layout algorithm is not supported for server-side layout.
	// User action: Use another graph layout algorithm that supports server-side layout, or use client-side graph layout.
	UnsupportedAlgorithm: "算法 ${algorithmClass} 不支持服务器端图形布局。",  
	

	//-------------------------------------------------------
	// Interactors
	//
	// Explanation: The InteractorManager.push method was called while an interactor is already contained in the active stack.
	// User action: Do not push an interactor while an interactor is already contained in the active stack.
	RestrictedToOneInteractor:"只有一个交互方可以推进活动的堆栈中。", 
	// Explanation: The InteractorManager.get method was called with an invalid interactor identifier.
	// User action: Verify that the identifier passed to the InteractorManager.get method is valid.
	InvalidInteractorId: "交互方标识 ${interactorId} 无效。", 
	// Explanation: An Interactor object attempted to connect to an invalid event name.
	// User action: Verify that the connection objects returned by the getDefaultConnections() method of the interactor contain valid event names.
	InvalidInteractorEvent: "无效的交互方事件：${name}", 
	// Explanation: An invalid filter definition was defined in an interactor object.
	// User action: Verify that the connection objects returned by the getDefaultConnections() method of the interactor contain valid filter definitions.
	InvalidInputFilterSpec: "事件 \"${name}\" 的交换方输入过滤器规范无效。",  


	//-------------------------------------------------------
	// UI events/connections
	//
	// Explanation: An internal connection is made to an event while another connection is still active.
	// User action: This is an internal error. If the error persists, consult the support pages.
	ConnectionStillActive: "连接 ${id} 仍然为已连接。", 
	// Explanation: An internal connection to an event has failed.
	// User action: This is an internal error. If the error persists, consult the support pages.
	EventConnectionFailed: "未能连接到事件：${eventName}。", 


	//-------------------------------------------------------
	// Viewport
	//
	// Explanation: The maximum zoom is set to a value less than the minimum zoom.
	// User action: Set the maximum zoom to a value greater than the minimum zoom.
	MaxZoomBelowMin: "最大缩放的设置不能低于最小缩放。", 
	// Explanation: The minimum zoom is set to a value greater than the maximum zoom.
	// User action: Set the minimum zoom to a value less than the maximum zoom.
	MinZoomAboveMax: "最小缩放的设置不能高于最大缩放。", 

	
	//-------------------------------------------------------
	// User-defined functions
	//
	// Explanation: An error occurred while starting the user-defined drop function.
	// User action: The error message contains the error that occurred in the user-defined drop function. Correct this error. 
	DropUserFunctionError: "删除用户函数时发生错误：${error}",
	// Explanation: An error occurred while starting the user-defined undo function.
	// User action: The error message contains the error that occurred in the user-defined undo function. Correct this error. 
	UndoUserActionError:"在 ${action}：(${error}) 上撤销用户活动时发生错误。",
	
	//-------------------------------------------------------
	// Swim lanes
	
	// Explanation: An attempt to create a SwimLane element was made while the GFX layout feature is not enabled.
	// User action: Enable GFX layout by specifying 'gfxLayout: true' in the global djConfig object.
	SwimLanesRequireGfxLayout: "使用泳道时必须启用 GFX 布局 (djConfig.useGfxLayout=true)",
	
	//-------------------------------------------------------
	// Dojo
	
	// Explanation: A Dojo Diagrammer feature that requires at least a specific version of Dojo was used.
	// User action: Configure the application to use at least the specified version of Dojo, or do not use the feature.
	UnsupportedDojoFeature: "该功能在此版本的 Dojo 中不可用。需要 Dojo ${version}。",	
	
	//-------------------------------------------------------
	LASTERRORCODE: ""
	
});

