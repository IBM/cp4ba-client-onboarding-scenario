/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/keys",
"../../interactors/Interactor"
], function(
declare,
keys,
Interactor
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var DeleteKeyInteractor =
declare("ibm_ilog.diagram.editor.interactors.DeleteKeyInteractor", [Interactor], {
	//summary:
	//		This interactor manages the graphElements deletion through the keyboard interaction.
	//		This interactor has 2 connections: deleteDelete, deleteBackSpace. Both connections call the "doDelete" method.
	_diagram: null,
	_serializer: null,
	initialize: function (diagram) {
		// summary:
		//		initialize the new instance.
		// diagram: ibm_ilog.diagram.editor.DiagramEditor
		//		the associated diagram editor.		
		this._diagram = diagram;
		return this._initialize();
	},
	getKeyInteractorId: function(){
		// summary:
	    //		returns the Interactor Id
		return DeleteKeyInteractor.KeyInteractorId;
	},
	getDefaultConnections: function () {
		// summary:
		//		returns the default event mapping
		
		return {
			deleteDelete: {
				hotKey: keys.DELETE,	
				connectTo: "doDelete"
			}, 
			deleteBackSpace: {
				hotKey: keys.BACKSPACE,
				connectTo: "doDelete"
			}
		};
	},
	
	doDelete: function(){
		// summary:
		//		Deletes the selected elements and all the connected links. If none selected,
		//		removes the focused element and all connected links.
		var targetSet = this._buildTargetSet();
		return targetSet ? this._diagram.deleteGraphElements(targetSet) : false;
	},
	
	_buildTargetSet: function(){
		//
		//	summary:
		//		Builds the set of entities that are going to be affected by the delete action.
		//
		//	description:
		//		gets the selected object and iterate over them to add all the children and 
		//		connected nodes to to deletion target set.
		//		If no element is selected, the target set is created based on the focused object.
		var selection = this._diagram.getSelection();
		var s = selection.fastGet().toArray();
		var targetSet = null;
		
		if(s.length == 0){
			var c = this._diagram.getFocusedElement();
			if(c){
				targetSet = [c];
			}else{
				return null;
			}
		}else{
			targetSet = s;
		}
		return targetSet;
	}
});

DeleteKeyInteractor.KeyInteractorId = "Delete";

return DeleteKeyInteractor;

});
