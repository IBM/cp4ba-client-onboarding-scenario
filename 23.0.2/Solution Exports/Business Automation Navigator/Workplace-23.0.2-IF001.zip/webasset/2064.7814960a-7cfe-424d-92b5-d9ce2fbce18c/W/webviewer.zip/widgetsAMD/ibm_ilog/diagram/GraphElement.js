/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["./base",
"dojo/_base/lang", "dojo/_base/array", "dojo/_base/declare", "dojo/_base/connect",
"dojox/gfx/_base",
"./Selectable", "./templating"],
function(iid, lang, array, declare, connect, gfx, Selectable, templating){

/*=====
var gfx = dojox.gfx;
var Selectable = ibm_ilog.diagram.Selectable;
var templating = ibm_ilog.diagram.templating;
=====*/

var GraphElement =
declare("ibm_ilog.diagram.GraphElement", [gfx.Group, Selectable, templating._DiagramTemplated], {
  	//
	// summary:
  	//		An element that can be contained in a Graph.
	//
    
	_gfxConnections: null,
	_dojoConnections: null,
	
	//
	//	_IBMDiagramType: String
	//		Graph element type, used to distinguish basic graph element types: node, subgraph, link. 
	//		Used to quickly index maps based on graph element types.
	//
	_IBMDiagramType: undefined,
	
	_isIBMDiagramGraphElement: true,
	
	toString: function() {
    	return this.declaredClass.split(".").pop()+" "+this.getId()+(this.getLabel?(": "+this.getLabel()):"");
    },
    constructor: function() {
        var id = iid._IdGenerator.nextId(this).toString();
        this.getId = function() {
            return id;
        };
        this._gfxConnections = [];
		this._dojoConnections =  [ connect.connect(this,"setLabel",this,function(){
        	connect.publish('/ibm_diagram/GraphElement/labelChanged', [this]);
        }) ];
    },
    dispose: function(options) {
    	//	summary:
			//		Dispose this GraphElement.
			//	description:
			//		This function should be called when the GraphElement is completely deleted, that is, when it is removed
			//		from its parent graph and it will never be used again.
			//	options:
    	//		options.noRecurse:
			//			Do not recurse children
    	this.beforeDisposing(this);
    	connect.publish('/ibm_diagram/GraphElement/beforeDisposing',[this]);
    	this._dispose();
    	this.afterDisposing(this);
    	connect.publish('/ibm_diagram/GraphElement/afterDisposing',[this]);
    	//free connections
    	this.disconnectAll();
    },
    beforeDisposing: function(graphElement) {
    	// summary:
        //		This function is called before disposing the GraphElement
    },
    afterDisposing: function(graphElement) {
    	// summary:
        //		This function is called after disposing the GraphElement
    	// description:
        //		This function free all possible listeners
    	
    	// free possible listeners
        this._disposeBoundCountext();
    },
    connect: function() {
    	// summary:
        //		override gfx.connect to add the handle to the internal list
    	var conn = this.inherited(arguments);
    	this._gfxConnections.push(conn);
    	return conn;
    },
    addConnection: function(connection){
    	// summary:
		//		Records a connection to an event on this graph element so it can be disconnected at dispose time.
		// description:
        //		This method should be called to record the result of every dojo.connect call done to the graph element that
    	//		should be disconnected on dispose. Do not call this method when a call to this.connect() is done (that is,
		// 		a GFX event connection), since this is already done internally.
    	this._dojoConnections.push(connection);
		
		// PR: you should NOT called this method for dojo.connect handler. Indeed, the
		// disconnectAll() method calls this.disconnect() which does not always relies on dojo.disconnect,
		// depending on the renderer. In general: you should not mix dojo.connect/disconnect with shape.connect/disconnect.
		//
		// ==> This method should be removed.
		// [Eric] changed the doc to explain this, and created 2 different lists (one for GFX events and one for dojo connect/on)
    },
    disconnectAll: function() {
    	// summary:
        //		This function is disconnect every connect attached to this element
    	array.forEach(this._gfxConnections,lang.hitch(this,function(conn){
    		this.disconnect(conn);
    		delete conn;
    	}));
    	array.forEach(this._dojoConnections,lang.hitch(this,function(conn){
    		conn.remove();
			delete conn;
    	}));
    	this._gfxConnections = [];
    	this._dojoConnections = [];
    },
    _dispose: function(graphElement) {
    	// summary:
        //		this function should be overriden by any GraphElement subclass that needs any specific disposing action.
    }
    
});

GraphElement.byShape = function(shape) {
	// summary:
	//		Returns the GraphElement that contains the specified shape, or null.
	
	for(var p = shape; p && p.getParent; p = p.getParent())
		if(p instanceof GraphElement)
			return p;
	return null;
};

return GraphElement;

});
