define({      
//begin v1.x content
    errorDialogTitle: "IBM BPM 錯誤",
    moreDetails: "相關詳細資料...",
    closeMessage: "關閉所有錯誤訊息",
    contentMessage: "發生錯誤。"
//end v1.x content
});

