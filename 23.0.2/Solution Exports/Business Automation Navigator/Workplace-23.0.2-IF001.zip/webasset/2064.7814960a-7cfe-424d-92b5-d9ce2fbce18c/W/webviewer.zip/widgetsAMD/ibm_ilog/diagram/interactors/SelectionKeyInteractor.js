/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/keys",
"./Interactor"
],
function(
declare,
keys,
Interactor
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var SelectionKeyInteractor =
declare("ibm_ilog.diagram.interactors.SelectionKeyInteractor", [Interactor], {
	//summary:
	//		This Interactor manages the Selection through the keyboard interaction.
	//		This Interactor have 4 connections: singleSelect, multiSelect, selectAll and clearSelection.		
	
	_diagram: null,
	
	initialize: function (diagram) {
	// summary:
    //		initialize the new instance.
    // diagram: ibm_ilog.diagram.widget.Diagram
    //		the associated diagram.				
		this._diagram = diagram;
		return this._initialize();
	},
	
	getSelection: function () {
		// Summary:
		//		return the selection object.
		// return: ibm_ilog.diagram.Selection
		return this._diagram.getSelection();
	},
	
	getKeyInteractorId: function(){
		// Summary:
		//		return the interactor Id.
		return SelectionKeyInteractor.KeyInteractorId;
	},
	getDefaultConnections: function () {
		// summary:
		//		returns the default event mapping
		
		return {
			singleSelect: {
				hotKey:keys.SPACE,
				connectTo: "singleSelect",
				filter: this._buildInputFilter({ctrl:false})
			}, multiSelect: {
				hotKey:keys.SPACE,
				connectTo: "multiSelect",
				filter: this._buildInputFilter({ctrl:true})
			}, selectAll: {
				hotKey:65,/*letter a*/
				connectTo: "selectAll",
				filter: this._buildInputFilter({ctrl:true})
			}, clearSelection: {
				hotKey:keys.ESCAPE,
				connectTo: "clearSelection"
			}
		};
	},
	singleSelect: function(e){
		// summary:
	    //		This method clears the selection and adds the focused element to the selection.
	    // e: Event object
	    //		the event to be treated.
		var sel = this.getSelection();
		var ge = this._diagram.getFocusedElement();
		if(ge && sel.accept(ge)){
			sel.add(ge,true);
		}
	},
	multiSelect: function(e){
		// summary:
	    //		This method clears the adds the focused element to the selection or removed it if selected.
	    // e: Event object
	    //		the event to be treated.
		var sel = this.getSelection();
		var ge = this._diagram.getFocusedElement();
		if(ge){
			if(ge.isSelected()){
				sel.remove(ge);
			}else{
				if(sel.accept(ge)){
					sel.add(ge,false);
				}
			}
		}
	},
	selectAll: function(e){
		// summary:
	    //		This method adds all the graph elements to the selection
	    // e: Event object
	    //		the event to be treated.
		var graph = this._diagram.getGraph();
		this.getSelection().selectAll(graph);
	},
	clearSelection: function(e){
		// summary:
	    //		This method clears the selection
	    // e: Event object
	    //		the event to be treated.
		var sel = this.getSelection();
		sel.clear();
	}
});

SelectionKeyInteractor.KeyInteractorId = "Selection";

return SelectionKeyInteractor;


});

