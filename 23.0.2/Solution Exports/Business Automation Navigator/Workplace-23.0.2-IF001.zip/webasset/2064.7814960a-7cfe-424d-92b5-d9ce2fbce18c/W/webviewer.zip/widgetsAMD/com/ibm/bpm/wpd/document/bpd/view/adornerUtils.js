/**
 * Utilities to create the various adorner types.
 * 
 */
define([
   "dojo/_base/declare", "dojo/_base/lang", "dojo/aspect", "./ColorLinkAdorner", "./HighlightBorderNodeAdorner", "./TaskStatsNodeAdorner", "./RerouteToLinkAdorner", "./PathAdorner", "./adornerConstants", "./PathElement"
], function(declare, lang, aspect, ColorLinkAdorner, HighlightBorderNodeAdorner, TaskStatsNodeAdorner, RerouteToLinkAdorner, PathAdorner, adornerConstants, PathElement) {

   var AdornerUtils = declare([], {

      createColorLinkAdorner : function(adornerTarget, color, width) {
         var adorner = new ColorLinkAdorner({
            adornerTarget : adornerTarget,
            color : color,
            width : width
         });
         return adorner;
      },

      createHighlightBorderNodeAdorner : function(adornerTarget, color, width, opacity) {
         var adorner = new HighlightBorderNodeAdorner({
            adornerTarget : adornerTarget,
            color : color,
            width : width,
            opacity : opacity
         });
         return adorner;
      },

      createTaskStatsNodeAdorner : function(adornerTarget, criticalCount, atRiskCount, okCount, mode) {
         if (typeof mode === "undefined")
            mode = "MODE_HORZ";
         var adorner = new TaskStatsNodeAdorner({
            adornerTarget : adornerTarget,
            criticalCount : criticalCount,
            atRiskCount : atRiskCount,
            okCount : okCount,
            mode : mode
         });
         return adorner;
      },

      createRerouteToLinkAdorner : function(adornerTarget) {
         var adorner = new RerouteToLinkAdorner({
            adornerTarget : adornerTarget
         });
         return adorner;
      },
      
      /**
       * Create an adorner that will show random statistics under all activities in the provided
       * diagram.
       * 
       * @param bpdViewer
       * @param counts bpdFlowObjectId, countAtRisk, countOnTrack, countOverdue
       * @returns
       */
      createTaskStatsPathAdorner : function(bpdViewer, counts) {
         if (!bpdViewer)
            return null;
         var pathAdorner = new PathAdorner();
         for ( var i = 0; i < counts.length; i++) {
            var target = new PathElement({
               ilogDiagram : bpdViewer.ilogDiagrammer,
               id : counts[i].bpdFlowObjectId,
               type : adornerConstants.TYPE_ACTIVITY
            });
            var adorner = this
               .createTaskStatsNodeAdorner(target, counts[i].countOverdue,  counts[i].countAtRisk,  counts[i].countOnTrack, "MODE_VERT");
            target.addAdorner(adorner);
            pathAdorner.addElement(target);
         }
         // Registers listener. When a task adorner is selected we have to make sure that any other
         // adorners in the path are unselected.
         aspect.after(pathAdorner, "onAdornerEvent", function(path, pathElement, adorner, eventName, data) {
            if (eventName === "STAT_TYPE_SELECTED") {
               // If it's a different adorner, then we need to unselect it.
               if (pathAdorner.getData().selectedAdorner && adorner != pathAdorner.getData().selectedAdorner) {
                  pathAdorner.getData().selectedAdorner.unselect();
               }
               pathAdorner.getData().selectedAdorner = adorner;
               //console.log("Selected stat: " + data + " for node:" + pathElement.id);
            }
         }, true);
         return pathAdorner;
      }

   });
   return new AdornerUtils();
});