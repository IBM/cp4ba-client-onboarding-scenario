/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/connect",
"dojo/_base/event",
"./Interactor"
],
function(
declare,
lang,
connect,
event,
Interactor
){

var KeyboardInteractorManager =
declare("ibm_ilog.diagram.interactors.KeyboardInteractorManager", [], {
	// summary:
	//		This class manage the keyInteractor, by connection to the Diagram onkeydown event and pushing it to the appropriate registered Interactors.
	// The associated diagram
	_diagram: null,

	// the event connection
	_connection: null,

	// a dictionary of keyInteractors, by id
	_keyInteractors: null,

	//a map of hoKeys with the keyInteractors connections to be launch in each case
	// format:
	//			{ 65: { interactorId1:[connection1,connection2] , interactorId2:[connection3] },
	//			  70: { interactorId2:[connection4] } }
	_hotKeys: null,

	constructor: function (diagram) {
		// summary:
		//		Creates a new instance.
		// diagram: ibm_ilog.diagram.widget.Diagram
		//		the associated diagram.
		this._diagram = diagram;
		this._keyInteractors = {};
		this._hotKeys = {};
	},
	activate: function () {
		// summary:
		//		Activate the Manager, creating the connection.
		if (!this._connection) {
			this._connection = connect.connect(this._diagram.getKeyboardEventSource(), "onkeydown", this, "keyPressed");
		}
	},
	deactivate: function () {
		// summary:
		//		Deactivate the Manager, deleting the connection.
		connect.disconnect(this._connection);
		this._connection = null;
	},
	add: function (id, keyInteractor) {
		// summary:
		//		Adds a new keyInteractor.
		// id: String
		//		the keyIntearctor id.		
		// keyInteractor: ibm_ilog.diagram.interactors.Interactor
		//		the keyIntearctor to be added.		
		this._keyInteractors[id] = keyInteractor;
		keyInteractor.setKeyManager(this);
	},
	get: function (id) {
		// summary:
		//		Gets a keyInteractor by its id.
		// id: String
		//		the keyIntearctor id.
		// return: ibm_ilog.diagram.interactors.Interactor
		return this._keyInteractors[id];
	},
	remove: function (id) {
		// summary:
		//		Removes a keyInteractor by its id.
		// id: String
		//		the keyIntearctor id.
		delete(this._keyInteractors[id]);
	},
	keyPressed: function (e) {
		// summary:
		//		This method is called when a key is pressed in the diagram.
		// e: Event object
		//		the event to be treated.
		// return boolean
		var wasHandled = false;

		if (e.keyCode in this._hotKeys) {
			for (var accId in this._hotKeys[e.keyCode]) {
				wasHandled = this._keyInteractors[accId].keyPressed(this._hotKeys[e.keyCode][accId], e) || wasHandled;
			}
		}

		// If handled, stop the event and prevent default
		if (wasHandled) {
			event.stop(e);
			if (e.preventDefault) {
				e.preventDefault();
			}
		}
		return wasHandled;
	},

	setHotKeys: function (id, hotKeys) {
		// summary:
		//		This method is called to register the hotkeys to the manager. Ideally, this is called inside the Interactors at initialization time.
		// id: String
		//		the keyIntearctor id.
		// hotKeys: JS object
		//		a dictionary with the hotKeys to be register and the connections to be registered in each one. Format: {key1:[conn1,conn2], key2:[conn4]}
		for (var key in hotKeys) {
			if (!(key in this._hotKeys)) {
				this._hotKeys[key] = {};
			}
			this._hotKeys[key][id] = lang.clone(hotKeys[key]);
		}
	},
	clearHotKeys: function (id, hotKeys) {
		// summary:
		//		This method is called to clear the hotkeys in the manager. Ideally, this is called inside the Interactors when trying to unregister it for removal or reconfiguration.
		// id: String
		//		the keyIntearctor id.
		// hotKeys: JS object
		//		a dictionary with the hotKeys to be register and the connections to be registered in each one. Format: {key1:[conn1,conn2], key2:[conn4]}
		for (var key in hotKeys) {
			delete this._hotKeys[key][id];
		}
	},

	__eod: undefined
});

return KeyboardInteractorManager;

});
