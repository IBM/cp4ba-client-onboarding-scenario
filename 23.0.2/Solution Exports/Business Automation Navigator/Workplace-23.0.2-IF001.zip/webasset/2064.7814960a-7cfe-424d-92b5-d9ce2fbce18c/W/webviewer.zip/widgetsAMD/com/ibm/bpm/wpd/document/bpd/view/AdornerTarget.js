/**
 * What is being adorned.  A node/link in a diagram.
 */
define([
   "dojo/_base/declare", "dojo/_base/lang"
], function(declare, lang) {

   return declare([], {

      // the base diagram
      ilogDiagram : null,

      // The type of element.  Can be TYPE_LINK, TYPE_NODE, TYPE_GATEWAY....
      type : null,

      // ID of the element to be adorned
      id : null,

      constructor : function(args) {
         lang.mixin(this, args);
      }

   });

});
