define(["dojo/_base/declare",
        "dojo/dom",
        "dojo/_base/json",
        "./RestCommand",
        "../../../base/errorhandling/WpdLogger",
        "../../model/shellstate/ShellStateModel",
        "../../model/providers/ModelTypeProviderRegistry",
        "../../model/viewstate/ViewStateModel",
        "../../../base/bootstrap"],

function(declare,
		dom,
		json,
        RestCommand,
        WpdLogger,
        ShellStateModel,
        ModelTypeProviderRegistry,
        ViewStateModel,
        bootstrap) {
return declare([RestCommand], {
	/**
	 * Open a document/po.
	 */
	
	docTypeProvider : null, // a instance of BaseDocTypeProvider

    execute : function () {
        try{
            //console.log("cmd=", cmd);
            console.debug( "in execute OpenDocumentCommand: " + new Date().getTime());
    
            this._execute();
        }
         catch (err){
            var className = this.declaredClass;
            var methodName = "dispatch";
            var viewerName;
            var commandClassName = "OpenDocumentCommand";
            var message = "Executing " + commandClassName + " caught exception" +
                '\nMessage: ' + err.message;
    
            var loadingImg = dom.byId("wpdLoadingImag");
            if (!!loadingImg) {
                loadingImg.style.display = "none";
            }
    
            WpdLogger.logError(className, methodName, message);
        }
    },
	
	/**
	 * If a ViewStateModel for the requested po is found, set it as the ActiveViewStateModel
	 * Otherwise request it from the server, then create a ViewStateModel using the response data
	 */
	_execute : function () {
		
		var documentId = this._getDocumentId();	
		var keyId = this._getKeyId();
		var ssm = ShellStateModel.getInstance();		
		
		//first try to find it in the list of openViewStateModels, ie, in the breadcrum
		var vsm = ssm.findOpenViewStateModelForDocId(documentId, keyId);		
		if (!!vsm){
			if( vsm != ssm.getActiveViewStateModel()){
				
				//TODO move the non active vsm in a list and move it back when needed (do it in shellstatemodel)
				//Or do not remove the vsm for updating breadcrum, instead, ask teh breadcrumb do it
				ssm.removeTrailingViewStateModel(vsm);	
				
				ssm.setActiveViewStateModel(vsm);
			}
			return;
		}
		else{	
			/*
			 * The requested document is not in the list of vsms that are in the breadcrumb list
			 * now try to find it in the cached list
			*/
			vsm = null; // ssm.findCachedViewStateModelForDocId(documentId, keyId);
			if(!!vsm){
				ssm.addOpenViewStateModel(vsm);	
				ssm.setActiveViewStateModel(vsm);
			}
			else{
				if (bootstrap.getBPMGlobals().WPD_useWLEServer){
					this.sendRequest();
					/*
					 * Do some work wile waiting for respond,
					 * Check how many I have cached, if reach 20, then remove the old ones
					 * Actually, the vsm is not that heavy
					 */
				
				}
				else {	
					this.onSuccessOldWay();
				}	
			}
		}
	},
		
	getRequestParams:function(){		
		//This assume that the docType is always carried in the event for drill in at process instance view
		var docType = this._getDocType();
		this.docTypeProvider = ModelTypeProviderRegistry.getInstance().getDocTypeProvider(docType);
		
		var params = this.docTypeProvider.getRequestParams(this.params);
		return params;
	},
	
//getRequestParams:function(){
//		
//		var params = {};
//		params.action = "get";
//		
//		var docId = this.params.documentId;
//		
//		var branchId = this.params.branchId;
//		var snapshotId = !!this.params.snapshotId;
//		if (!this.params.branchId && !this.params.snapshotId && !this.params.instanceId ){
//			throw new Error("Neither branchId nor snapshot is provided");
//		}
//		
//		//This assume that the docType is always carried in the event for drill in at process instance view
//		var docType = this._getDocType();
//		var docTypeProvider = ModelTypeProviderRegistry.getInstance().getDocTypeProvider(docType);
//		
//		//check this for now, will remove this hard coded checking later
//		if(docType == "ProcessInstanceType"){
//			params.url = docTypeProvider.getPORestPath(this.params);
//		}
//		else{
//			params.url = docTypeProvider.getPORestPath(docId);
//			if (!!branchId){
//				params.url = params.url + "branchId=" + branchId;
//			}
//			else{
//				params.url = params.url + "snapshotId=" + snapshotId;
//			}
//		}
//		return params;
//	},
	
//	getRequestUrlForInstance : function(){
//		var branchId = this.params.branchId;
//		var snapshotId = this.params.snapshotId;
//		var instanceId = this.params.instanceId;
//		var docId = this.params.documentId;
//		
//		
//		if(!!instanceId){
//			ShellStateModel.getInstance().instanceId = instanceId;
//		}
//		
//		//for drill in case: instanceId is not provided in the event
//		else if(!!ShellStateModel.getInstance().instanceId){
//			instanceId = ShellStateModel.getInstance().instanceId;
//		}
//		else{
//			//Should never happen:  change this to an error log later
//			("instanceId is not set");
//		}
//		var docType = this.params.type;
//		var docTypeProvider = ModelTypeProviderRegistry.getInstance().getDocTypeProvider(docType);
//	    var url = docTypeProvider.getPORestPath(instanceId, branchId, snapshotId, docId);
//	    return url;
//	   
//	},
	
	/**
	 * This function is for off server testing
	 */
	onSuccessOldWay : function (){
		
		//get a response from star 4 server", Ask Yi to clean up the response even more
		var tempresponse = '{"status":"200","data":{"id":"bpdid:d6beacb0b334f609:-6770573d:1306ad780c9:-7ffc","label":"BPD1","items":[{"type":"start","successors":[{"_reference":"bpdid:d6beacb0b334f609:-6770573d:1306ad780c9:-7ff4"}],"id":"bpdid:d6beacb0b334f609:-6770573d:1306ad780c9:-7ff6","label":"Start","x":50,"y":50},{"type":"end","successors":[],"id":"bpdid:d6beacb0b334f609:-6770573d:1306ad780c9:-7ff5","label":"End","x":350,"y":50},{"type":"activity","successors":[{"_reference":"bpdid:d6beacb0b334f609:-6770573d:1306ad780c9:-7ff5"}],"id":"bpdid:d6beacb0b334f609:-6770573d:1306ad780c9:-7ff4","label":"Task1","x":211,"y":73},{"width":3000,"height":150,"type":"swimlane","children":[{"_reference":"bpdid:d6beacb0b334f609:-6770573d:1306ad780c9:-7ff6"},{"_reference":"bpdid:d6beacb0b334f609:-6770573d:1306ad780c9:-7ff5"},{"_reference":"bpdid:d6beacb0b334f609:-6770573d:1306ad780c9:-7ff4"}],"id":"bpdid:d6beacb0b334f609:-6770573d:1306ad780c9:-7ff8","label":"Participant","x":0,"y":0},{"width":3000,"height":150,"type":"swimlane","children":[],"id":"bpdid:d6beacb0b334f609:-6770573d:1306ad780c9:-7ff7","label":"System","x":0,"y":150}]}}';
		var tempResponseObj = json.parse(tempresponse);	
	
		//get the document part
		var documentObj = tempResponseObj.data;
				
		var documentName = this.params.documentName;
		var documentType = "BPDDocType";
		var documentId = this.params.documentId;
				
		var vsmObj = {};
		var vsmObj = {documentName: documentName, documentType:documentType, documentId:documentId, document:documentObj};
		var vsm = this.createViewStateModel(vsmObj);

		var ssm = ShellStateModel.getInstance();
		ssm.addOpenViewStateModel(vsm);	
		ssm.setActiveViewStateModel(vsm);
	},
	
	onSuccess : function (response){
		
		//console.debug( "onSuccess open: " + new Date().getTime());
		
		var documentObj;		
		if(!!this.docTypeProvider.processResponseData){
			documentObj = this.docTypeProvider.processResponseData(response.data, this.params);		
		}
		else{
			documentObj = response.data;
		}
		
		var documentName = this._getDocumentName(documentObj);
		var documentId = this._getDocumentId();
		var documentType = this._getDocType();		
		
		var vsmObj = {documentName: documentName, documentType:documentType, documentId:documentId, document:documentObj};
		vsmObj.keyId = this._getKeyId();
		var vsm = this.createViewStateModel(vsmObj);
		
		//add the newly created vsm to the list of open view state models and set it to the current active one
		var ssm = ShellStateModel.getInstance();
		ssm.addOpenViewStateModel(vsm);	
		ssm.setActiveViewStateModel(vsm);
		//always cache, because we know that it is not cached before
		ssm.addCachedViewStateModel(vsm);
	},
	
	/**
	 * Create and returns ViewStateModel
	 * @param data
	 * @returns a ViewStateModel for the data
	 */
	createViewStateModel : function (data){
		
		var vsm;
		
		//find docTypeProvider
		//var docTypeProvider = ModelTypeProviderRegistry.getInstance().getDocTypeProvider(data.documentType);
		if (!!this.docTypeProvider){
			vsm = this.docTypeProvider.createViewStateModel(data);
		}
		else{
			vsm = new ViewStateModel();
		}
		
		//ViewStateModel has a name, type and documentId, branchOrSanpshotId and subProcParentId
		//Keep the information needed by ViewStateModel in vsm, because the json object format are controlled by each DocumentViewer
		vsm.name = data.documentName;
		vsm.documentId = data.documentId;
		vsm.type = data.documentType;
		vsm.keyId = data.keyId;
		vsm.subProcParentId = this.params.subProcParentId;
		vsm.zoomLevel = this.params.zoomLevel;
				
		//documentModel. No need to ask the docType provider to do this for the webviewer
		var dm = data.document; //this.createDocumentModel(documentObj);
		vsm.setDocumentModel(dm);	
			
		return vsm;
	},
	
	_getDocumentId:function(){
		if(!!this.params.documentId){
			return this.params.documentId;
		}		
		var docType = this._getDocType();
		this.docTypeProvider = ModelTypeProviderRegistry.getInstance().getDocTypeProvider(docType);
	   
		var docId = this.docTypeProvider.getDocumentId(this.params);
		if(!docId){
			throw new Error("No Unique document Id is provided");
		}
		return docId;
	},
	
	_getDocumentName:function(documentObj){
		if(!!this.params.documentName){
			return this.params.documentName;
		}
		else if( !!documentObj && !!documentObj.name){
			return documentObj.name;
		}
		//for process instance view
		var docType = this._getDocType();
		//var docTypeProvider = ModelTypeProviderRegistry.getInstance().getDocTypeProvider(docType);
		return this.docTypeProvider.getDisplayName(this.params);		
	},
	
	_getKeyId:function(){
		var keyId = this.params.keyId;
		if(!keyId){
		    if (!!this.params.branchId) {
	            keyId = this.params.branchId;
		    } else if (!!this.params.shotshotId) {
	            keyId = this.params.snapshotId;
            } else if (!!this.params.projectId) {
                keyId = this.params.projectId;
            }
		}
		return keyId;
	},
	
	_getDocType: function(){
		var documentType;
		if (!!this.params.type){
			documentType = this.params.type;
		}
		else{
			documentType = ModelTypeProviderRegistry.getInstance().getDocumentTypeByPO(this.params.documentId, this.params.assetType);
		}
		return documentType;
	}
});


});
