/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
// NLS_CHARSET=UTF-8

define({
	//-------------------------------------------------------
	// ErrorReporter internals
	//
	
	// Explanation: An unexpected internal error has occurred in the Dojo Diagrammer code.
	// User action: This is an internal error and the cause is not immediately known. If the error persists, consult the support pages.
	Unknown: "알 수 없는 오류입니다.",
	// Explanation: The 'error' or 'warning' method of ibm_ilog.diagram.util.ErrorReporter has been called with an invalid identifier.
	// User action: Verify that identifiers passed to ibm_ilog.diagram.util.ErrorReporter methods are valid.
	InvalidErrorId: "\"${errorId}\" 문자열이 올바른 오류 ID가 아닙니다.",
	// Explanation: The ibm_ilog.diagram.util.ErrorReporter.declareError method is called with an identifier that is already declared.
	// User action: Verify that the declared error identifier is not already declared.
	ErrorIdAlreadyDeclared: "오류 ID \"${errorId}\"이(가) 이미 등록되어 있습니다.",

	
	//-------------------------------------------------------
	// Generic-JavaScript
	//
	// Explanation: A user-defined subclass of a Dojo Diagrammer base class does not define a required method.
	// User action: Verify that all required methods are declared in your subclass.
	SubclassResponsibility: "${methodName}이(가) 서브클래스에서 구현되어야 합니다.",
	// Explanation: An object is null and it is expected to not be null.
	// User action: Verify that you provide an object that is not null for the object that is specified in the error message.
	NullPointerException:"${objectName}이(가) 널로 확인되었습니다.",
	// Explanation: An object is null and it is expected to not be null.
	// User action: Verify that you provide an object that is not null for the object that is specified in the error message. The error message also contains a hint to help you find the class that contains the error.
	NullPointerException2:"${objectName}이(가) 널로 확인되었습니다[힌트: ${where}].",
	// Explanation: An error that was caused by another nested error has occurred.
	// User action: Refer to the user action for the nested error whose identifier is contained in the error message.
	Wrapped:"${process}의 오류: (${error}).",
	// Explanation: An unexpected argument value was passed to a function.
	// User action: The function name, expected value (or value range) and actual argument value are contained in the error message. Verify that the argument value is correct.
	UnexpectedArgument:"예기치 않은 인수 유형 또는 범위입니다.",
	
	// Explanation: A function was called with an invalid number of arguments.
	// User action: The expected and actual number of arguments are contained in the error message. Verify that the number of arguments are correct.
	InvalidNumberOfArguments:"${numberOfArgs}개 발견되고 ${options} 중 하나로 예상됨",
	
	// Explanation: An unexpected value was returned by a function.
	// User action: The function name, expected return value type and actual return value type are contained in the error message. Verify that the returned value type is correct.
	UnexpectedReturnValueType: "예기치 않은 리턴값 유형입니다. ${functionName}()에서 예상된 유형: ${expectedType}. 실제 유형: ${actualType}",


	//-------------------------------------------------------
	// Generic-Graph/Diagram
	//
	
	// Explanation: A function expects a graph element (for example, a node, link, or subgraph) but another type of object was found.
	// User action: Verify that a graph element is supplied.
	GraphElementExpected: "예상 그래프 요소: 그래프, 노드, 링크 또는 서브그래프", 

	
	//-------------------------------------------------------
	// DataStore
	//
	// Explanation: The Diagram widget processed a data item that is not contained in the data store specified as the nodesStore or linksStore attributes
	// User action: Verify that the data store contains the item that is specified as the nodesStore or linksStore attributes of the Diagram widget.
	NotInDataStore:"엔티티가 데이터 저장소에 없습니다.",
	// Explanation: The nodesQuery or linksQuery attribute of the Diagram widget is specified as a string, and it should be an object.
	// User action: Verify that the nodesQuery or linksQuery attribute is an object and not a string.
	CannotUseAStringForAQuery:"저장소 조회는 문자열이 아닌 오브젝트로 정의해야 합니다.",
	// Explanation: The nodesStore attribute of the Diagram widget is not specified.
	// User action: Specify the nodesStore attribute on the Diagram widget.
	NodesStoreRequired:"위젯에는 노드 저장소를 정의해야 합니다.",	
	// Explanation: The data store that is specified as the nodesStore or linksStore attribute does not implement the dojo.data.api.Indentity interface.
	// User action: Specify a data store that implements the dojo.data.api.Indentity interface.
	StoresMustSupportIdentity:"저장소는 'dojo.data.api.Read' 기능을 지원해야 합니다.",
	// Explanation: The data store that is specified as the nodesStore or linksStore attribute does not implement the dojo.data.api.Read interface.
	// User action: Specify a data store that implements the dojo.data.api.Read interface.
	StoresMustSupportRead:"저장소는 'dojo.data.api.Read' 기능을 지원해야 합니다.",
	
	// Explanation: An error occurred while loading the data store specified as the nodesStore attribute of the Diagram widget.
	// User action: The error message contains the the nested error. Correct the nested error.
	UnexpectedErrorOnNodesStoreFetch:"NodesStore 페치 중 오류: (${errorString})",
	// Explanation: An error occurred while loading the data store specified as the linksStore attribute of the Diagram widget.
	// User action: The error message contains the the nested error. Correct the nested error.
	UnexpectedErrorOnLinksStoreFetch:"LinksStore 페치 중 오류: (${errorString})",

	
	//-------------------------------------------------------
	// Overview
	//

	// Explanation: The diagram attribute of the Overview widget is not defined.
	// User action: Define the diagram attribute of the Overview widget.
	OverviewDiagramMissing:"개요 위젯에는 다이어그램 위젯이 필요합니다(속성 'diagram'==${diagram}).",

	
	//-------------------------------------------------------
	// WAI
	//

	// Explanation: The internal Web Accessibility Initiative (WAI) node was not found for the given graph element.
	// User action: Use the createNode/createLink/createSubgraph methods of the diagram, not the graph methods to create elements in a diagram.
	MissingWaiNode:"그래프 요소 ${element}에 대한 WAI-ARIA 노드를 찾을 수 없습니다.",

	//-------------------------------------------------------
	// ServerSideLayout
	//

	// Explanation: The specified graph layout algorithm is not supported for server-side layout.
	// User action: Use another graph layout algorithm that supports server-side layout, or use client-side graph layout.
	UnsupportedAlgorithm: "서버측 그래프 레이아웃에 ${algorithmClass} 알고리즘이 지원되지 않습니다.",  
	

	//-------------------------------------------------------
	// Interactors
	//
	// Explanation: The InteractorManager.push method was called while an interactor is already contained in the active stack.
	// User action: Do not push an interactor while an interactor is already contained in the active stack.
	RestrictedToOneInteractor:"하나의 인터랙터만 활성 스택에 푸시할 수 있습니다.", 
	// Explanation: The InteractorManager.get method was called with an invalid interactor identifier.
	// User action: Verify that the identifier passed to the InteractorManager.get method is valid.
	InvalidInteractorId: "인터랙터 ID ${interactorId}이(가) 올바르지 않습니다.", 
	// Explanation: An Interactor object attempted to connect to an invalid event name.
	// User action: Verify that the connection objects returned by the getDefaultConnections() method of the interactor contain valid event names.
	InvalidInteractorEvent: "올바르지 않은 인터랙터 이벤트: ${name}", 
	// Explanation: An invalid filter definition was defined in an interactor object.
	// User action: Verify that the connection objects returned by the getDefaultConnections() method of the interactor contain valid filter definitions.
	InvalidInputFilterSpec: "\"${name}\" 이벤트에 올바르지 않은 인터랙터 입력 필터 스펙",  


	//-------------------------------------------------------
	// UI events/connections
	//
	// Explanation: An internal connection is made to an event while another connection is still active.
	// User action: This is an internal error. If the error persists, consult the support pages.
	ConnectionStillActive: "연결 ${id}이(가) 여전히 연결되어 있습니다.", 
	// Explanation: An internal connection to an event has failed.
	// User action: This is an internal error. If the error persists, consult the support pages.
	EventConnectionFailed: "${eventName} 이벤트에 연결하는 데 실패했습니다.", 


	//-------------------------------------------------------
	// Viewport
	//
	// Explanation: The maximum zoom is set to a value less than the minimum zoom.
	// User action: Set the maximum zoom to a value greater than the minimum zoom.
	MaxZoomBelowMin: "최대 확대/축소 값을 최소 확대/축소 값 이하로 설정할 수 없습니다.", 
	// Explanation: The minimum zoom is set to a value greater than the maximum zoom.
	// User action: Set the minimum zoom to a value less than the maximum zoom.
	MinZoomAboveMax: "최소 확대/축소 값을 최대 확대/축소 값 이상으로 설정할 수 없습니다.", 

	
	//-------------------------------------------------------
	// User-defined functions
	//
	// Explanation: An error occurred while starting the user-defined drop function.
	// User action: The error message contains the error that occurred in the user-defined drop function. Correct this error. 
	DropUserFunctionError: "사용자 기능 삭제 시 오류: ${error}",
	// Explanation: An error occurred while starting the user-defined undo function.
	// User action: The error message contains the error that occurred in the user-defined undo function. Correct this error. 
	UndoUserActionError:"${action}에 적용하는 동안 사용자 조치 실행 취소 시 오류: (${error}).",
	
	//-------------------------------------------------------
	// Swim lanes
	
	// Explanation: An attempt to create a SwimLane element was made while the GFX layout feature is not enabled.
	// User action: Enable GFX layout by specifying 'gfxLayout: true' in the global djConfig object.
	SwimLanesRequireGfxLayout: "GFX 레이아웃은 스윔레인이 사용될 때 사용 가능해야 합니다(djConfig.useGfxLayout=true).",
	
	//-------------------------------------------------------
	// Dojo
	
	// Explanation: A Dojo Diagrammer feature that requires at least a specific version of Dojo was used.
	// User action: Configure the application to use at least the specified version of Dojo, or do not use the feature.
	UnsupportedDojoFeature: "이 기능은 본 버전의 Dojo에서 사용할 수 없습니다. Dojo ${version}이(가) 필요합니다.",	
	
	//-------------------------------------------------------
	LASTERRORCODE: ""
	
});

