/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"../../base",
"../../adorners/HighlightedHandle",
"../interactors/ConnectionTargetHandleInteractor"
], function(
declare,
iid,
HighlightedHandle,
ConnectionTargetHandleInteractor
){

/*=====
var HighlightedHandle = ibm_ilog.diagram.adorners.HighlightedHandle;
=====*/

	var ConnectionTargetHandle =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.ConnectionTargetHandle',[HighlightedHandle],{
		
		//
		//	_location: Point
		//
		location: null,
		connectionInteractor: null,
		setup: function(location) {
			this.location = location;
			this.addInteractor(new ConnectionTargetHandleInteractor().initialize(this));
			return this;
		},
		setConnectionInteractor: function(connectionInteractor){
			this.connectionInteractor = connectionInteractor;
		},	
		getConnectionInteractor:function(){
			return this.connectionInteractor;
		},
		getPortPosition:function(){
			return this.location;
		}
	}));
	
	ConnectionTargetHandle.templateId = "ConnectionTargetHandle";

	return ConnectionTargetHandle;
	
});
