/**
 * An adorner that wraps an ILog Adorner.
 * 
 */
define([
   "dojo/_base/declare", "dojo/_base/lang", "dojo/aspect", "./Adorner"
], function(declare, lang, aspect, Adorner) {
   return declare([
      Adorner
   ], {

      ilogAdorner : null,
      adornerListener : null,

      constructor : function(args) {
         lang.mixin(this, args);
      },
      
      adorn : function() {
         this.inherited(arguments);
         if (this.ilogAdorner) {
            // Listen to the adorner _updateLayout.  This lets us react to zoom events and alter our
            // shapes if needed.  Do an initial update.  Allows setup and update code to be common 
            // this way.
            this.updateLayout();
            this.adornerListener = aspect.after(this.ilogAdorner, "_updateLayout", lang.hitch(this, function() {
               this._updateLayout();
            }));
         }
      },

      unAdorn : function() {
         try {
            // If not adorned, nothing to do.
            if (!this.adorned)
               return;
            // If no saved adorner then nothing to do
            if (this.ilogAdorner) {
               // Stop listening to the update events.
               if (this.adornerListener) {
                  this.adornerListener.remove();
                  this.adornerListener = null;
               }
               this.adornerTarget.ilogDiagram.destroyAdorner(this.ilogAdorner);
               this.ilogAdorner = null;
            }
            this.inherited(arguments);
         } catch (e) {
            console.error(e);
         }
      },
      
      // Intermediate point for updating the layout.  Forwards
      // to updateLayout if the conditions are right.
      _updateLayout: function() {
         if (this.ilogAdorner) {
            if (this.ilogAdorner.getAdorned() != null) {
               this.updateLayout();
            }
         }
      },
      
      /**
       * Can be overridden to adjust to changes in zoom.
       * 
       */
      updateLayout: function() {
         
      }

   });

});
