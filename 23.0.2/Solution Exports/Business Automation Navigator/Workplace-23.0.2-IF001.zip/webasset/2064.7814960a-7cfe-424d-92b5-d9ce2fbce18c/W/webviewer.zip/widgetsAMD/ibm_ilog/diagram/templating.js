/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/lang", "dojo/_base/array", "dojo/_base/declare",
"./_base/gfxext", "./data/dtlbinding", "./util/ErrorReporter"],
function(lang, array, declare, ge, idb, R){

	// TODO: Change to this when AMD conversion is complete:
	// var idt = {};
	var idt = lang.getObject("ibm_ilog.diagram.templating", true);
	
	lang.mixin(idt, {
	
		instantiate: function(/*dojox.gfx.Surface || dojox.gfx.Group */parent, /*Object*/ template, bindings) {
			// summary:
			//        Instantiate the specified template.
			// description:
			//        A template object describes both the contents of a shape and its
			//        appearance properties. The description object must conform to the
			//        gfx serialization specification. In addition, it supports the concept
			//        of attach point that exists in dijit with the dojoAttachPoint attribute.
			//        When this method is invoked, an instance of the template is created 
			//        and initialized. If attach points are defined in the template, the 
			//        corresponding properties are defined on the instance.
			// parent: dojox.gfx.Surface || dojox.gfx.Group:
			//        The container of the new shape.
			// template: Object :
			//        The description object.
			try {
				// flag used to skip _onChanged notification 
				parent._noOnChanged = true;
				// no validation during the deserialization
				if (parent.suspendInvalidate) 
					parent.suspendInvalidate();
				
				var t = idt._deserialize(parent, template, bindings);
				// create dojoAttachPoint fields
				if (t instanceof Array) {
					array.forEach(t, function(s) {
						idt._makeAttachPoint(s, parent);
					});
				} else {
					idt._makeAttachPoint(t, parent);
				}
			} finally {
				delete parent._noOnChanged;
				// trigger layout
				if (parent.resumeInvalidate) 
					parent.resumeInvalidate(true);
				ge.propagateChange(parent, null);
			}
			return t;
		},
		
		_makeAttachPoint: function(s, root) {
			root = root || s;
			if (s._attachPoint) {
				root[s._attachPoint] = s;
				// track attachPoints to be able to dispose them 
				if (!('_attachPoints' in root)) 
					root._attachPoints = [];
				root._attachPoints.push(s._attachPoint);
				delete s._attachPoint;
			}
			// Group ?
			if ('children' in s) {
				array.forEach(s.children, function(c) {
					idt._makeAttachPoint(c, root);
				});
			}
		},
		
		_deserialize: function(/* dojox.gfx.Surface || dojox.gfx.Group */parent,/* Object */ object, bindings) {
			// summary:
			//        Deserializes the specified template object.
			// template: Object : the description object to deserialize.
			// returns:
			//        A gfx shape that represents the specified description.
			
			if (object instanceof Array) {
				return array.map(object, function(s) {
					return idt._deserialize(parent, s, bindings);
				}); // Array
			}
			try {
				var shape = ("shape" in object) ? parent.createShape(object.shape) : parent.createGroup();
			} catch (e) {
				R.error("Wrapped", "templating.js # _deserialize # createShape/group", e);
			}
			if (bindings && bindings.length > 0) {
				// TODO: bindings is not used here. Replace with a bool
				idt.resolveBindingRefs(shape, object, bindings);
			}
			try {
				if (shape.suspendInvalidate) 
					shape.suspendInvalidate();
				// flag used to skip _onChanged notification 
				shape._noOnChanged = true;
				for (var p in object) {
					if (p == 'shape') 
						continue;
					else if (p == "transform") {
						shape.setTransform(object.transform);
					} else if (p == "stroke") {
						shape.setStroke(object.stroke);
					} else if (p == "fill") {
						shape.setFill(object.fill);
					} else if (p == "font") {
						shape.setFont(object.font);
					} else if (p == "children") {
						array.forEach(object.children, function(c) {
							idt._deserialize(shape, c, bindings);
						});
					} else if (p == "selectedStyle") {
						shape.selectedStyle = object.selectedStyle;
					} else if (p == "dojoAttachPoint") {
						shape._attachPoint = object.dojoAttachPoint;
					} else { // extended attribute
						// first check if a setter exists
						var n = p.substr(0, 1).toUpperCase() + p.substr(1);
						var setter = shape['set' + n];
						if (typeof(setter) == "function") {
							setter.call(shape, object[p]);
						} else {
							// fallback
							shape[p] = object[p];
						}
					}
				}
			} finally {
				delete shape._noOnChanged;
				if (shape.resumeInvalidate) 
					shape.resumeInvalidate(false); // false = do not trigger a validate()
				ge.propagateChange(shape, null);
			}
			return shape; // dojox.gfx.Shape
		},
		
		resolveBindingRefs: function(shape, o, bindings, path) {
			path = path || [];
			for (var p in o) {
				if (p && p != "children") {
					if (p.indexOf("_binding_") !== -1) {
						var b = o[p];
						b.target = shape;
						b.path = lang.clone(path);
						// not needed anymore
						delete o[p];
					} else if (typeof(o[p]) == "object" || typeof(o[p]) == "function") {
						var npath = lang.clone(path);
						npath.push(p);
						this.resolveBindingRefs(shape, o[p], bindings, npath);
					}
				}
			}
		}
		
	});
	
	//
	// _DiagramTemplated
	//
	var _DiagramTemplated = declare("ibm_ilog.diagram.templating._DiagramTemplated", null, {
	
		applyTemplate: function(template, context) {
			// summary:
			//    Applies the specified template on this instance.
			// template: Object or string :
			//    the template to apply.
			// context: Object : the runtime context. Optional. If not specified, the runtime context is this shape instance.
			if (template) {
				if (this.children.length > 0) {
					this.clear();
				}
				this._clearAttachPoints();
				this._disposeBoundCountext();
				var dtlTemplate = template instanceof idb.GfxTemplate ? template : new idb.GfxTemplate(template);
				this._boundContext = context || new idb.BoundContext(this, dtlTemplate.useDtl);
				try {
				
					if (this.suspendInvalidate) 
						this.suspendInvalidate();
					var content = dtlTemplate.render(this._boundContext, this);
					this.onTemplateApplied(template);
				} catch (e) {
					this.onTemplateError(template, e);
					R.error("Wrapped", "_DiagramTemplated.applyTemplate", e);
				} finally {
					if (this.resumeInvalidate) 
						this.resumeInvalidate(true);
				}
				return content;
			}
			return null;
		},
		
		onTemplateApplied: function(/*Object || String*/template) {
			// summary:
			//      Invoked when the template has been applied.
			// template: Object or string :
			//    the template to apply.
		},
		
		onTemplateError: function(/*Object || String*/template, /*Exception*/ e) {
			// summary:
			//      Invoked if an error is raised when applying the specified template .
			// template: Object or string :
			//    the template to apply.
		},
		
		_disposeBoundCountext: function() {
			if (this._boundContext && this._boundContext.dispose) {
				this._boundContext.dispose();
			}
		},
		
		_clearAttachPoints: function() {
			if (this._attachPoints) {
				array.forEach(this._attachPoints, function(p) {
					delete this[p];
				}, this);
				this._attachPoints.length = 0;
				delete this._attachPoints;
			}
		},
		
		layoutShape: function( /*{shape}*/target) {
			//
			//	No layout needed by default.
			//
		},
		
		shallowInstantiateAt: function(target, template) {
			//
			//	Instantiate a shallow version of the node, only visible shape is
			//	generated, otherwise the result has no unneeded members. This means
			//	the result may not be an instance of the class of the receiver.
			//
			if (template) {
					var dtlTemplate = template instanceof idb.GfxTemplate ? template : new idb.GfxTemplate(template);
					var context = new idb.BoundContext(this, dtlTemplate.useDtl);
					var content = dtlTemplate.render(context, target);
			}
			
			return target;
			
		},
		
		onPropertyChanged: function(property, oldValue, newValue) {
			// summary:
			//		Called when a bindable property has changed.
			// description:
			//		Bindable properties are properties defined on a Node or a Link
			//		and that can be used in templates using bindings.
		},
		
		_getBindableProperty: function(property) {
			// summary:
			//		The generic method that gets a bindable property.
			// tags:
			//		private
			return this["_" + property];
		},
		
		_setBindableProperty: function(property, newValue) {
			// summary:
			//		The generic method that sets a bindable property.
			// tags:
			//		private
			var oldValue = this["_" + property];
			if (newValue != oldValue) {
				this["_" + property] = newValue;
				this.onPropertyChanged(property, oldValue, newValue);
			}
		},
		
		startDTLBatch: function() {
			if (this._boundContext) {
				this._boundContext.startBatch();
			}
		},
		
		endDTLBatch: function() {
			if (this._boundContext) {
				this._boundContext.endBatch();
			}
		}
	});
	
	// Declares a bindable property by extending a class with the following:
	//	- the field that contains the value (initialized to the default value)
	//	- the setXyx and getXyz methods that get and set the value
	idt.declareBindableProperty = function(type, property, defaultValue) {
		// summary:
		//		Declares a bindable property for an object type.
		// description:
		//		Bindable properties are properties of a graphic object (Node, Link or Subgraph)
		//		that can be used to define bindings in templates.
		// type:
		//		The type to which the property must be added.
		// property:
		//		The name of the property. If the property name is 'foo', declaring the bindable property
		//		will extend the specified type with two methods: getFoo() and a setFoo(newValue).
		//		In the template of the object, you can define bindings like: text: '{{foo}}'.
		//		The initial value of the bindable property will be used when creating the object, and
		//		when the property is changed the template will be updated automatically.
		// defaultValue:
		//		The default value of the property.
		var extension = {};
		// value field
		extension["_" + property] = defaultValue;
		var uname = (property.substr(0, 1).toUpperCase()) + property.substr(1);
		// getter function
		extension["get" + uname] = function() {
			return this._getBindableProperty(property);
		};
		// setter function
		extension["set" + uname] = function(newValue) {
			this._setBindableProperty(property, newValue);
			return this;
		};
		// OK extend now.
		lang.extend(type, extension);
	};
	
	// See comment in data/dtlbinding.js (GfxTemplate.render function)
	lang.extend(idb.GfxTemplate, {
		_instantiate: idt.instantiate
	});
	
	idt._DiagramTemplated = _DiagramTemplated;
	
	return idt;
});
