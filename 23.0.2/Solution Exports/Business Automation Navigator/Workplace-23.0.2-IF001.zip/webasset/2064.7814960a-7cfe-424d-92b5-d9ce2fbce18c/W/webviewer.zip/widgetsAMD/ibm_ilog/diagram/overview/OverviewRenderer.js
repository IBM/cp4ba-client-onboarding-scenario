/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"../util/ErrorReporter"
],
function(
declare,
R
){

var OverviewRenderer =
declare('ibm_ilog.diagram.overview.OverviewRenderer',null, {
	
	//
	//	summary:
	//		The abstract superclass of overview renderers. This class may only exist
	//		for documentation purposes only.
	//

	render: function( /*Object*/content, /*dojox.gfx.Group*/ output ) {
		R.error("SubclassResponsibility","render");
	}
		
});

return OverviewRenderer;

});
