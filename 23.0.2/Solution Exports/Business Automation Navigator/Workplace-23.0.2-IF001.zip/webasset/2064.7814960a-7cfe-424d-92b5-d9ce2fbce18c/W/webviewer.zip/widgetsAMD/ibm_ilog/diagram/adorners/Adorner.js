/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"../main",
"dojo/_base/declare",
"dojo/_base/config",
"dojo/_base/lang",
"dojo/_base/connect",
"dojox/gfx/matrix",
"../templating",
"./TemplatedOverlay",
"../util/HandleSet",
"../util/GraphUtil",
"../util/Geometry",
"../util/ErrorReporter"
],
function(
iid,
declare,
config,
lang,
connect,
m,
templating,
TemplatedOverlay,
HandleSet,
gu,
g,
R
){

var __invisibleLocation = g.Rect(iid._invisibleLocation, iid._invisibleLocation, iid._invisibleSize, iid._invisibleSize);

/*=====
var TemplatedOverlay = ibm_ilog.diagram.adorners.TemplatedOverlay;
var HandleSet = ibm_ilog.diagram.util.HandleSet;
=====*/

var a = iid.gfxDeclaration(declare('ibm_ilog.diagram.adorners.Adorner', [TemplatedOverlay, HandleSet], {
	//
	//	summary:
	//		A UI overlay associated with a graph entity.
	//
	//	description:
	//		The Adorner object provides a graphical decoration for a
	//		graph entity. The decoration is composed of a graphical 
	//		representation given by the adorner template and also by a set of smaller 
	//		AdornerHandle entities.
	//		Each adorner usually defines a fixed set of handles which can be used. AdornerHandles 
	//		usually provide an interactive service to the user. For example, the handle 
	//		can connect to the onmousedown event of its shapes to perform some kind of 
	//		action on the adorned. If this action leads to an interaction process that 
	//		is not instantaneous, then the AdornerHandle can push an Interactor object 
	//		into the interactors stack, blocking other conflicting interactors 
	//		temporarily while the action is performed. For example, during the creation 
	//		of links some interactions may be disabled.
	//
	//	construction:
	//		Adorners don't use parameterized constructors. Instead, they rely on an 
	//		initialize method. For example:
	//
	//			new ibm_ilog.diagram.editor.ResizeAdorner().initialize(diagram,
	//		                                                    templatePool,
	//			                                                  "ResizeAdorner0");
	//
	//		The reason for this is that the creation is implemented with a template 
	//		method, and thus the template code implemented in the superclass needs the 
	//		methods already overriden. Currently dojo executes superclass constructors 
	//		before overriding methods redeclared in the subclass. 
	//
	//	TODO:
	//    . update extendCreateShape for using deserialization
	//		. change individual props for composite: elemBounds instead of elemLeft, elemTop, elemW, elemH
	//

	//   
	//	_adorned:
	//		The adorned element
	//
	_adorned: null,

	//   
	//	_changeConnections:
	//		The connections handles of the current connections to change events related to the bound shape
	//
	_changeConnections: [],

	//   
	//	_elementBounds:
	//		The bounding box of the bound element, in Graph coordinates
	//
	_elementBounds: null,

	//   
	//	_viewport:
	//		The viewport at which the Adorner resides
	//
	_viewport: null,

	//   
	//	_templatePool:
	//		The dictionary used for assigning templates to the AdornerHandles the Adorner
	//
	_templatePool: null,

	//   
	//	_diagram:
	//		The diagram at which the Adorner resides
	//
	_diagram: null,

	//   
	_onEGDisposeConn: null,

	initialize: function (diagram, templatePool, templateId) {
		//
		//	summary:
		//		Initializes an Adorner after construction.
		//
		//	diagram:
		//		The Diagram Dijit
		//
		//	templatePool:
		//		The template pool. The adorner gets its template from this pool using the 
		//		templateId argument, and also for instantiating its handles with the 
		//		templates from the pool.
		//
		//	templateId:
		//		the Id for the adorner template in the pool
		//
		this._diagram = diagram;
		this._viewport = diagram.getViewport();
		this._templatePool = templatePool;
		
		this._elementBoundsChanged();
		
        if (config.isBidiInDojoDiagrammer) {
		    var tDir = diagram._graph.textDir;          
		    if (tDir)                                   
			    this.setTextDir(tDir);
		}

		var template = templatePool.item(templateId);
		this.applyTemplate(template);
		
		//Added to remove the adorner if binded element is removed
		this._onEGDisposeConn = connect.connect(this._diagram,'beforeGraphElementDispose',this,'_onElementDisposed');
	},

	getAdorned: function () {
		//
		// 	summary:
		//		gets the bounded element
		//
		return this._adorned;
	},

	getViewport: function () {
		//
		// 	summary:
		//		gets the viewport
		//
		return this._viewport;
	},
	
	getDiagram: function () {
		//
		// 	summary:
		//		gets the diagram
		//
		return this._diagram;
	},

	activate: function () {
		//
		// 	summary:
		//		activates the adorner
		//
	},

	deactivate: function () {
		//
		// 	summary:
		//		deactivates the adorner
		//
	},

	_invalidated: 0,
	_invalidationCallbackH: null,
	_invalidationCallback: function() {
		//
		//	summary:
		//		The callback used in the _invalidate() setTimeout. Also called by forceUpdate();
		//
		this._elementBoundsChanged();
		this._invalidationCallbackH = null;
		this._invalidated = 0;
	},
	
	_invalidate: function() {
		//
		// 	summary:
		//		Requests invalidation of the adorner shape. 
		//	description:
		//		Usually based on a change notification. The update is batched with a setTimeout(0).
		//		_invalidate() is used for changes that are reported a lot or those that don't really
		//		need an immediate update.
		//		forceUpdate() can be used to clear the timeout and update immediately.
		//
		if(!this._invalidated) {
			var thiz = this;
			this._invalidationCallbackH = setTimeout(lang.hitch(this,"_invalidationCallback"),0);
		}
		this._invalidated++;
	},
	
	forceUpdate: function() {
		//
		//	summary:
		//		Used to clear the timeout and update the adorner shape immediately.
		//
		if(this._invalidationCallbackH) {
			clearTimeout(this._invalidationCallbackH);
		}
		this._invalidationCallback();
	},
	
	_reconnectNotifications: function () {
		//
		// 	summary:
		//		Reconnect to change notifications related to the bound element. 
		//

		if (this._adorned && !this._isConnected("v")) {
			this._connect("v", this._viewport, "onViewRectChanged", this,"_updateLayout");
		} else if(!this._adorned) {
			this._disconnect("v");
		}
		var cc = this._changeConnections;
		for (var i = 0; i < cc.length; i++) {
			connect.disconnect(cc[i]);
		}
		this._changeConnections = cc = [];
		var e = this._adorned;
		if (e) {
			gu.doAncestors(e, function (sg) {
				if (sg._isIBMDiagramSubgraph) {
					var gr = sg.getGraph();
					cc.push(connect.connect(sg, "onBoundsChanged", this, function (s, reason) {
						this._invalidate();
					}));
					cc.push(connect.connect(sg, "onCollapsedChanged", this, function () {
						this._invalidate();
					}));
					cc.push(connect.connect(sg, "onCollapsedAnimated", this, function () {
						this._invalidate();
					}));
					cc.push(connect.connect(sg, "_setParent", this, function () {
						this._reconnectNotifications();
						this._invalidate();
					}));
				}
			}, this);

			cc.push(connect.connect(e, "_setParent", this, function () {
				if(this._adorned && this._adorned._no_reconnect_on_add) return; // to avoid an infinite event loop
				this._reconnectNotifications();
				this._invalidate();
			}));

			// last shape can receive child updates
			cc.push(connect.connect(e, "onBoundsChanged", this, "forceUpdate"));
		}
	},

	setAdorned: function (element) {
		//
		//	summary:
		//		apply the adorner to the given element
		//
		if (this._adorned !== element) {
			if (this._adorned) {
				this.deactivate();
			}
			this._adorned = element;

			this._reconnectNotifications();
			this._elementBoundsChanged();

			if (this._adorned) {
				this.activate();
			}
		}
	},
	
	_required: function() {
		return this._adorned && gu.isStableVisible(this._adorned); 
	},

	_setFallbackBounds: function() {
		this._elementBounds = null;
		this._elementBaseBounds = null;
	},
	
	_computeElementBoundsChanged: function () {
		if(this._required()) {
			this._elementBounds = this._adorned.getBounds(this._diagram.getGraph().getParent());
			var bs = this._adorned.baseShape;
			if(bs) {
			  var pm = this._diagram.getGraph()._getRealMatrix().inverse();
			  var cm = bs._getRealMatrix() || m.identity;
			  var t = m.multiply(pm,cm);
			  this._elementBaseBounds = t.transformRectangle(bs.getBoundingBox());
			} else {
				this._elementBaseBounds = null;
			}
		} else {
			this._setFallbackBounds();
		}
	},

	_elementBoundsChanged: function () {
		this._computeElementBoundsChanged();
		this._updateLayout();
	},

	_updateLayout: function () {

		var bb = __invisibleLocation, bbb = __invisibleLocation;
		if (this._required()) {
			// There is an adorned, and so this._elementBounds has meaningful data 
			var vt = this._viewport.contentToClient();
			bb = vt.transformRectangle(this._elementBounds);
			bbb = vt.transformRectangle(this._elementBaseBounds || this._elementBounds);
		}
		this.startDTLBatch();
		
		this.setElemWidth(bb.width);
		this.setElemHeight(bb.height);
		this.setElemRight(bb.x + bb.width);
		this.setElemBottom(bb.y + bb.height);
		this.setElemLeft(bb.x);
		this.setElemTop(bb.y);
		this.setElemCenterX(bb.width / 2);
		this.setElemCenterY(bb.height / 2);
		this.setElemBaseWidth(bbb.width);
		this.setElemBaseHeight(bbb.height);
		this.setElemBaseRight(bbb.x + bbb.width);
		this.setElemBaseBottom(bbb.y + bbb.height);
		this.setElemBaseLeft(bbb.x);
		this.setElemBaseTop(bbb.y);
		this.setElemBaseCenterX(bbb.width / 2);
		this.setElemBaseCenterY(bbb.height / 2);

		this.endDTLBatch();
	},
	_onElementDisposed: function(graphElement){
		// Summary:
		//		this method is called when a graph element is 
		if(this._adorned && graphElement===this._adorned){
			this.setAdorned(null);
		}
	},
	
	destroy: function(){
		// summary:
		//		removes the diagram connection
		connect.disconnect(this._onEGDisposeConn);
	},

	// ==============================================================
	//	These are copied from ibm_ilog.diagram.Node to support owning Ports/Links
	//
	getBounds: function(/*dojox.gfx.Group*/parent) { 
	  // summary:
	  //		Returns the bounds of this node in the coordinate space of the specified parent.
	  // parent: dojox.gfx.Group
	  //		The parent object that determines the coordinate space
	  //		the bounds are relative to. If null or undefined, the bounds of the node
	  //		relative to its parent are returned.
	  // returns:
	  //		A rectangle (i.e. an object with x/y/width/height properties) containing
	  //		the bounds of the node in the specified coordinate space.
	
		/*
		  var rect = this.getLocalBoundingBox();
		  if (rect && parent && parent != this.getParent()) {
		      var t = this.getTransformToContainer(parent);
		      rect = t.transformRectangle(rect);
		  }
		  */
		
		// Changed by Eric: the previous implementation seems wrong, it returns {x: ibm_ilog.diagram._invisibleLocation, y: ibm_ilog.diagram._invisibleLocation, etc }...
		// (looks like the _invisibleLocation thing?...)
		// The following, using the bounds of the baseShape, works better.
		// Abel, please check that this will always work...
			
		if(!parent)
			parent = this.getParent();
		
		var baseShape = this.getBaseShape();
		var rect = baseShape.getBoundingBox();
		// t1: transform from surface -> base shape
		var t1 = baseShape._getRealMatrix() || m.identity;
		// t2: transform from surface -> parent
		var t2 = parent._getRealMatrix() || m.identity;
		var t = m.multiply(t2.inverse(), t1);
		rect = t.transformRectangle(rect);
		
		return rect;
	},
	
	getBaseShape: function() {
		return this.baseShape;
	},
	
	onChanged: function() {
		
	},
	
	_onChanged: function() {
		this.onChanged();
	}

}));

templating.declareBindableProperty(a, "elemBaseLeft", null);
templating.declareBindableProperty(a, "elemBaseTop", null);
templating.declareBindableProperty(a, "elemBaseBottom", null);
templating.declareBindableProperty(a, "elemBaseRight", null);
templating.declareBindableProperty(a, "elemBaseWidth", null);
templating.declareBindableProperty(a, "elemBaseHeight", null);
templating.declareBindableProperty(a, "elemBaseCenterX", null);
templating.declareBindableProperty(a, "elemBaseCenterY", null);

templating.declareBindableProperty(a, "elemLeft", null);
templating.declareBindableProperty(a, "elemTop", null);
templating.declareBindableProperty(a, "elemBottom", null);
templating.declareBindableProperty(a, "elemRight", null);
templating.declareBindableProperty(a, "elemWidth", null);
templating.declareBindableProperty(a, "elemHeight", null);
templating.declareBindableProperty(a, "elemCenterX", null);
templating.declareBindableProperty(a, "elemCenterY", null);
templating.declareBindableProperty(a, "textDir", null);      

return a;

});
