/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"../../interactors/DragInteractor",
"../undo/ChangeLinkIntermediatePointsAction",
"../../util/ClippingUtil",
"../../util/Geometry"
], function(
declare,
lang,
DragInteractor,
ChangeLinkIntermediatePointsAction,
ClippingUtil,
g
){

/*=====
var DragInteractor = ibm_ilog.diagram.interactors.DragInteractor;
=====*/

var LinkIntermediatePointsHandleInteractor =
declare("ibm_ilog.diagram.editor.interactors.LinkIntermediatePointsHandleInteractor", [DragInteractor], {
	// Summary:
	//		this class is the interactor associated to the LinkIntermediatePointHandle. 
	// 		It manages the functionality to edit the position of its point, and to delete it.

	//	_handle: /*LinkIntermediatePointsHandle*/
	_handle:null,
	_link:null,
	_targetPosition: null,
	_newPoint: null,
	_oldPoint: null,
	_minimumAngle: null,
	
	_declareStates: function() {
	// Summary:
	//		Add the deleteIntermediatePoint to the original states
		this.inherited(arguments);	
		this._declareState("idle",["start","deleteIntermediatePoint"]);
	},
	
	getDefaultConnections:function(){
		//
		//	summary:
		//		returns the default event mapping
		//
    		var map = this.inherited(arguments);
    		map.deleteIntermediatePoint = {src:this._getInitialEventSource(),srcEvt:"onmousedown",connectTo:"_deleteIntermediatePoint",filter:this._buildInputFilter({shift:true,button:0}), gfxConnect:true};
    		return map;
    },
	
	initialize: function( /* LinkIntermediatePointsHandle */ handle ) {
    	// Summary:
		//		sets the LinkIntermediatePointsHandle
    	this._handle = handle;
		this._viewport = handle.getViewport();
		this._initialize();
		this._minimumAngle = 7;
		return this;
	},
	
	_getInitialEventSource: function() {
		return this._handle;
	},
	
	_deleteIntermediatePoint: function(e) {
		// Summary:
		//		deletes the clicked intermediate point
		var A = this._handle.getAdorner();
		var D = A.getDiagram();
		var link = A.getAdorned();
		var intermediatePoints = link.getIntermediatePoints();
		var n = this._handle.getIndex();
		var point = intermediatePoints[n];
		link.setIntermediatePoints(intermediatePoints.slice(0,n).concat(intermediatePoints.slice(n+1)));
		if(link.getParent() && link.getParent().invalidate) link.getParent().invalidate();
		A.rebindAdorned();
		D.getUndoManager().addAction(this._createRemoveUndoAction(D,link,point,n));
	},
	
    _dragPreStart: function(e) {
		this._handle.interactionBegun(this);
		this._newPoint = null;
		this._newPoint = null;
		this.inherited(arguments);
	},
	
	_dragMove: function(e) {
    	this.inherited(arguments);
		
    	var A = this._handle.getAdorner();
		var V = A.getViewport();
		var D = V.getDiagram();
		var link = A.getAdorned();
		if(link){
			var point = V.eventContentLocation(e);
			var t = link.getShapeToContainerTransform(V._diagram.getGraph().getParent()).inverse();
			var pointT = t.transformPoint(point);
			var intermediatePoints = link.getIntermediatePoints();
			var oldPoint = intermediatePoints[this._handle.getIndex()];
			if(!this._oldPoint){
				this._oldPoint = lang.clone(oldPoint);
			}
			oldPoint.x = pointT.x;
			oldPoint.y = pointT.y;
			this._newPoint = lang.clone(pointT);
			link.setIntermediatePoints(intermediatePoints);
			if(link.getParent() && link.getParent().invalidate) link.getParent().invalidate();
		}
	},

	_dragEnd: function(e) {
		
		this.inherited(arguments);
		if(this._newPoint){
			var A = this._handle.getAdorner();
			var D = A.getDiagram();
			var link = A.getAdorned();
			var index = this._handle.getIndex();
			if(this._reachMinimunAngle(link,index)){
				D.getUndoManager().addAction(this._createModifyUndoAction(D,link,this._oldPoint,this._newPoint,index));
			}else{
				this._restoreOldPoint(link,index);
				this._deleteIntermediatePoint(e);
			}
		}
		this._handle.interactionEnded(this);

	},
	_reachMinimunAngle: function(link,index){
		var p1 = link._pathPoints[index];
		var p = link._pathPoints[index+1];
		var p2 = link._pathPoints[index+2];
		var v1 = g.subPoint(p1,p);
		var v2 = g.subPoint(p,p2);
		var angle = ClippingUtil.vectorsAngle(v1,v2);
		angle = angle*360/(Math.PI*2);
		return angle>this._minimumAngle;
	},
	_restoreOldPoint: function(link,index){
		var intermediatePoints = link.getIntermediatePoints();
		var point = intermediatePoints[index];
		point.x = this._oldPoint.x;
		point.y = this._oldPoint.y;
	},
	_createRemoveUndoAction: function(diagram,link,point,index){
		var action = new ChangeLinkIntermediatePointsAction(diagram, link);
		action.setRemovePointOperation(index,point);
		return action;
	},
	_createModifyUndoAction: function(diagram,link,oldPoint,newPoint,index){
		var action = new ChangeLinkIntermediatePointsAction(diagram, link);
		action.setModifyPointOperation(index,newPoint,oldPoint);
		return action;
	}
});

return LinkIntermediatePointsHandleInteractor;

});
