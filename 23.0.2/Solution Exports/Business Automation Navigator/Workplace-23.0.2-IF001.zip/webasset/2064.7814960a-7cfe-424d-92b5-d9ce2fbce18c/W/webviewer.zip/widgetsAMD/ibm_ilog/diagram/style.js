/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/lang"],
function(lang){

	// TODO: Change to this when AMD conversion is complete:
	// var ids = {};
	var ids = lang.getObject("ibm_ilog.diagram.style", true);
        
    function getSetter(o, p) {
        var uname = p.length > 1 ? (p.substr(0, 1).toUpperCase()) + p.substr(1) : p.toUpperCase();
        var set = lang.getObject('set' + uname, false, o);
        return set;
    };
    
    ids.applyTo = function(/*Object*/mixin, /*Object*/target) {
        // summary: applies the specified style to the given target.
        // mixin: Object: 
        //            A dictionary of property-value pairs that define global properties to apply on the specified target.
        //            Properties must obey the Java get/set naming convention in order to be taken into account (i.e.
        //            for a property 'myProperty', there must be a getMyProperty and a setMyProperty methods defined on
        //            the node). If no setters are found, the property is set to the target as a simple field.
        // target: Object: the target instance.
         
        if (!mixin || !target) 
            return;
        for (var p in mixin) {
            var setter = getSetter(target, p);
            if (setter) {
                var val = mixin[p];
                setter.call(target, val);
            } else {
                // no setter -> add as a simple attribute
				target[p]=val; 
            }
        }
    };
   
   return ids; 
});
