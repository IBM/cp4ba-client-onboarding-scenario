/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"../../base",
"../../templating",
"../../adorners/HighlightedHandle",
"../interactors/AddIntermediatePointHandlerInteractor"
], function(
declare,
iid,
templating,
HighlightedHandle,
AddIntermediatePointHandlerInteractor
){

/*=====
var HighlightedHandle = ibm_ilog.diagram.adorners.HighlightedHandle;
=====*/

	var LinkIntermediatePointsAddHandle =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.LinkIntermediatePointsAddHandle',[HighlightedHandle],{
		// Summary:
		//		this class is the handle that manage the link intermediate points. 
		//		Contains the instance of LinkIntermediatePointsHandleInteractor that enables to remove and edit these points.
		
		//
		//	_location: handle position
		//
		_isAddHandle : true,
		_index: null,
		setUp: function(index) {
		// Summary:
		//		sets the handle Intermediate point index
			
			this._index = index;
			this.addInteractor(new AddIntermediatePointHandlerInteractor().initialize(this));
			return this;
		},
		getIndex: function(){
			// Summary:
			//		returns the index of the adorned link intermediate point
			return this._index;
		},
		changeBindings:function(intermediatePoints){
			// Summary:
			//		modify the handle internal bindings
			var p1 = intermediatePoints[this._index];
			var p2 = intermediatePoints[this._index+1];
			var point = {x: ((p2.x-p1.x)/2+p1.x), y:((p2.y-p1.y)/2+p1.y)};
			this.startDTLBatch();
			this.setAddPointPosX(point.x);
			this.setAddPointPosY(point.y);
			this.endDTLBatch();
		}
	}));

	LinkIntermediatePointsAddHandle.templateId = "LinkIntermediatePointsAddHandle";
	templating.declareBindableProperty(LinkIntermediatePointsAddHandle, "addPointPosX", -99999);
	templating.declareBindableProperty(LinkIntermediatePointsAddHandle, "addPointPosY", -99999);

	return LinkIntermediatePointsAddHandle;
	
});
