/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/lang", "dojo/_base/declare"],
function(lang, declare){
	
	// TODO: Change to this when AMD conversion is complete:
	// var bidiEngine = {};
	var bidiEngine = lang.getObject("ibm_ilog.diagram.util.BidiEngine", true);
	
declare("ibm_ilog.diagram.util.BidiEngine", null, {
    //	summary:
    //		This class provides a bidi transformation engine, i.e.
    //		functions for reordering and shaping bidi text.
    //	description:
    //		The external functions are:
    //			setAttributes
    //			_checkContextual
    //			doBidiReorder
    //			shape
    //			ara_type
    //	All these functions can also be used as stand-alone functions
    //	(not members of an object).

    setAttributes: function (/*String*/inFormat, /*String*/outFormat, /*String*/swap) {
        // Purpose: 	set the bidi attributes of source and result for
        //				later calls to doBidiReorder() which do not override them.
        //				Some of the parameters may be omitted.
        // Parameters:
        //	inFormat:	ordering scheme and base direction of the source text.
        //				Can be "LLTR", "LRTL", "LCLR", "LCRL", "VLTR", "VRTL",
        //				"VCLR", "VCRL".
        //				The first letter is "L" for logical ordering scheme,
        //				"V" for visual ordering scheme.
        //				The other letters specify the base direction.
        //				"CLR" means contextual direction defaulting to LTR if
        //				there is no strong letter.
        //				"CRL" means contextual direction defaulting to RTL if
        //				there is no strong letter.
        //				The initial value is "LLTR".
        //	outFormat:	required ordering scheme and base direction of the
        //				result. Has the same values as inFormat.
        //				The initial value is "VLTR".
        //	swap:		can be "YN", "NY", "YY" and "NN".
        //				The first letter reflects the symmetric swapping attribute
        //				of the source, the second letter that of the result.
        // Return:		None
        setAttributes(inFormat, outFormat, swap);
    },

    _checkContextual: function (/*String*/text) {
        // Purpose: 	determine the base direction of a bidi text according
        //				to its first strong directional character.
        // Parameters:
        //	text:		the text to check.
        // Return:		"ltr" or "rtl" according to the first strong character.
        //				If there is no strong character, returns the value of the
        //				document dir property.
        return _checkContextual(text);
    },

    doBidiReorder: function (/*String*/text, /*String*/inFormat, /*String*/outFormat, /*String*/swap) {
        // Purpose: 	reorder the source text according to the bidi attributes
        //				of source and result.
        // Parameters:
        //	text:		the text to reorder.
        //	inFormat:	ordering scheme and base direction of the source text.
        //				The allowed values are the same as for setAttributes().
        //				If omitted, the last value set by setAttributes() is
        //				used; if none, the initial value is used.
        //	outFormat:	required ordering scheme and base direction of the
        //				result. Has the same format as inFormat.
        //				If omitted, the last value set by setAttributes() is
        //				used; if none, the initial value is used.
        //	swap:		symmetric swapping attributes of source and result.
        //				The allowed values are the same as for setAttributes().
        //				If omitted, the last value set by setAttributes() is
        //				used; if none, the initial value is used.
        // Return:		text reordered according to source and result attributes.
        return doBidiReorder(text, inFormat, outFormat, swap);
    },

    shape: function (/*boolean*/rtl, /*String*/text, /*boolean*/compress) {
        // Purpose: shape the source text.
        // Parameters:
        //	rtl:		flag indicating if the text is in RTL direction (logical
        //				direction for Arabic words).
        //	text:		the text to shape.
        //  compress:   a flag indicates to insert extra space after the lam alef compression
        //				to preserve the buffer size or not insert an extra space which will lead
        //				to decrease the buffer size. this option can be:
        //				- true (default) to not insert extra space after compressing Lam+Alef into one character Lamalef
        //				- false to insert an extra space after compressed Lamalef to preserve the buffer size
        // Return:		text shaped.
        return shape(rtl, text);
    },

    deshape: function (/*String*/text, /*boolean*/rtl, /*boolean*/consume_next_space) {
        // Purpose: deshape the source text.
        // Parameters:
        //	text:		the text to be deshape.
        //	rtl:		flag indicating if the text is in RTL direction (logical
        //				direction for Arabic words).
        //	consume_next_space: 	flag indicating whether to consume the space next to the 
        //				the lam alef if there is a space followed the Lamalef character to preserve the buffer size. 
        //				In case there is no space next to the lam alef the buffer size will be increased due to the
        //				expansion of the lam alef one character into lam+alef two characters
        // Return:		text deshaped.
        return deshape(text, rtl, consume_next_space);
    },

    ara_type: function (/*int*/index, /*String*/text, /*boolean*/rtl) {
        // Purpose: shape the source text around a specific position.
        // Parameters:
        //	index:		position around which to reshape the text.
        //	text:		the text to shape.
        //	rtl:		flag indicating if the text is in RTL direction (logical
        //				direction for Arabic words).
        // Return:		complete source text reshaped around the specified position.
        return ara_type(index, text, rtl);
    },

    _bidiTransform: function (/*String*/text, /*String*/formatIN, /*String*/formatOUT) {

        if (text == '' || text == undefined || text == null)
            return '';

        if (formatIN == '' || formatIN == undefined || formatIN == null)
            return text;

        if (formatOUT == '' || formatOUT == undefined || formatOUT == null)
            return text;

        if (formatIN.length != 5 || formatOUT.length != 5)
            return text;

        if (formatIN == formatOUT)
            return text;

        var orientIN = getOrientation(formatIN.charAt(1));
        var orientOUT = getOrientation(formatOUT.charAt(1));

        var OS_IN = (formatIN.charAt(0) == 'I') ? 'L' : formatIN.charAt(0);
        var OS_OUT = (formatOUT.charAt(0) == 'I') ? 'L' : formatOUT.charAt(0);

        this.setAttributes(OS_IN + orientIN, OS_OUT + orientOUT, formatIN.charAt(2) + formatOUT.charAt(2));

        var stage1_text = this.doBidiReorder(text, OS_IN + orientIN, OS_OUT + orientOUT, formatIN.charAt(2) + formatOUT.charAt(2));

        var isRTL = false;

        if (formatOUT.charAt(1) == 'R')
            isRTL = true;
        else
            if (formatOUT.charAt(1) == 'C' || formatOUT.charAt(1) == 'D')
                isRTL = this._checkContextual(stage1_text);

        if (formatIN.charAt(3) == formatOUT.charAt(3))
            return stage1_text;
        else
            if (formatOUT.charAt(3) == 'S')
                return shape(isRTL, stage1_text, true);
        if (formatOUT.charAt(3) == 'N')
            return deshape(stage1_text, isRTL, true);


    }

});

var bdt = null;

bidiEngine.bidiTransform = function (/*String*/text, /*String*/formatIN, /*String*/formatOUT) {
    if (bdt == null) {
        bdt = new ibm_ilog.diagram.util.BidiEngine();
    }
    return bdt._bidiTransform(text, formatIN, formatOUT);
};

function getOrientation(/*Char*/ oc)
{
    if(oc == 'L')
        return "LTR";
    else
        if(oc == 'R')
            return "RTL";
    else
       if(oc == 'C')
           return "CLR";
    else
        if(oc == 'D')
            return "CRL";
};
var LTR = 0;
var RTL = 1;

function setAttributes(inFormat, outFormat, swap){
    if (inFormat != undefined) {
        bdx.defInFormat = inFormat;
    }
    if (outFormat != undefined) {
        bdx.defOutFormat = outFormat;
    }
    if (swap != undefined) {
        bdx.defSwap = swap;
    }
};

function _checkContextual(text){
    var dir = firstStrongDir(text);
    if (dir != "ltr" && dir != "rtl") {
        dir = document.dir.toLowerCase();
        if (dir != "ltr" && dir != "rtl") {
            dir = "ltr";
        }
    }
    return dir;
};

function firstStrongDir(text){
    var type;
    for (var i = 0; i < text.length; i++) {
        type = getCharacterType(text.charAt(i));
        if (type == UBAT_R || type == UBAT_AL) {
            return "rtl";
        }
        else 
            if (type == UBAT_L) {
                return "ltr";
            }
            else 
                if (type == UBAT_B) {
                    break;
                }
    }
    return "xxx";
};

function lastStrongDir(text){
    var type;
    for (var i = text.length - 1; i >= 0; i--) {
        type = getCharacterType(text.charAt(i));
        if (type == UBAT_R || type == UBAT_AL) {
            return "rtl";
        }
        else 
            if (type == UBAT_L) {
                return "ltr";
            }
            else 
                if (type == UBAT_B) {
                    break;
                }
    }
    return "xxx";
};

function doBidiReorder(text, inFormat, outFormat, swap){
    if (inFormat == undefined) {
        inFormat = bdx.defInFormat;
    }
    if (outFormat == undefined) {
        outFormat = bdx.defOutFormat;
    }
    if (swap == undefined) {
        swap = bdx.defSwap;
    }
    if (inFormat == outFormat) {
        return text;
    }
    var inTL = inFormat.substring(0, 1);
    var inTD = inFormat.substring(1, 4);
    var outTL = outFormat.substring(0, 1);
    var outTD = outFormat.substring(1, 4);
    if (inTD.charAt(0) == "C") {
        var dir = firstStrongDir(text);
        if (dir == "ltr" || dir == "rtl") {
            inTD = dir.toUpperCase();
        }
        else {
            inTD = inFormat.charAt(2) == "L" ? "LTR" : "RTL";
        }
        inFormat = inTL + inTD;
    }
    if (outTD.charAt(0) == "C") {
        var dir = firstStrongDir(text);
        if (dir == "rtl") {
            outTD = "RTL";
        }
        else 
            if (dir == "ltr") {
                dir = lastStrongDir(text);
                outTD = dir.toUpperCase();
            }
            else {
                outTD = outFormat.charAt(2) == "L" ? "LTR" : "RTL";
            }
        outFormat = outTL + outTD;
    }
    if (inFormat == outFormat) {
        return text;
    }
    bdx.inFormat = inFormat;
    bdx.outFormat = outFormat;
    bdx.swap = swap;
    if ((inTL == "L") && (outFormat == "VLTR")) { //core cases
        //cases: LLTR->VLTR, LRTL->VLTR
        if (inTD == "LTR") {
            bdx.dir = LTR;
            return doReorder(text);
        }
        if (inTD == "RTL") {
            bdx.dir = RTL;
            return doReorder(text);
        }
    }
    if ((inTL == "V") && (outTL == "V")) {
        //inTD != outTD
        //cases: VRTL->VLTR, VLTR->VRTL
        return invertStr(text);
    }
    if ((inTL == "L") && (outFormat == "VRTL")) {
        //cases: LLTR->VRTL, LRTL->VRTL
        if (inTD == "LTR") {
            bdx.dir = LTR;
            text = doReorder(text);
        }
        else {
            //inTD == RTL
            bdx.dir = RTL;
            text = doReorder(text);
        }
        return invertStr(text);
    }
    if ((inFormat == "VLTR") && (outFormat == "LLTR")) {
        //case: VLTR->LLTR
        bdx.dir = LTR;
        return doReorder(text);
    }
    if ((inTL == "V") && (outTL == "L") && (inTD != outTD)) {
        //cases: VLTR->LRTL, VRTL->LLTR
        text = invertStr(text);
        if (inTD == "RTL") { //VRTL->LLTR
            return doBidiReorder(text, "LLTR", "VLTR", swap);
        }
        else { //VLTR->LRTL
            return doBidiReorder(text, "LRTL", "VRTL", swap);
        }
    }
    if ((inFormat == "VRTL") && (outFormat == "LRTL")) {
        //case VRTL->LRTL
        return doBidiReorder(text, "LRTL", "VRTL", swap);
    }
    if ((inTL == "L") && (outTL == "L")) {
        //inTD != outTD
        //cases: LRTL->LLTR, LLTR->LRTL
        var saveSwap = bdx.swap;
        bdx.swap = saveSwap.substr(0, 1) + "N";
        if (inTD == "RTL") {
            //LRTL->LLTR
            bdx.dir = RTL;
            text = doReorder(text);
            bdx.swap = "N" + saveSwap.substr(1, 2);
            bdx.dir = LTR;
            text = doReorder(text);
        }
        else { //LLTR->LRTL
            bdx.dir = LTR;
            text = doReorder(text);
            bdx.swap = "N" + saveSwap.substr(1, 2);
            text = doBidiReorder(text, "VLTR", "LRTL", bdx.swap);
        }
        return text;
    }
};

/******************************************************************************/
/* Array in which directional characters are replaced by their symmetric.	  */
/******************************************************************************/
var SwapTable = [["\u0028", "\u0029"], /* Round brackets                   */ ["\u0029", "\u0028"], ["\u003C", "\u003E"], /* Less than/greater than           */ ["\u003E", "\u003C"], ["\u005B", "\u005D"], /* Square brackets                  */ ["\u005D", "\u005B"], ["\u007B", "\u007D"], /* Curly brackets                   */ ["\u007D", "\u007B"], ["\u00AB", "\u00BB"], /* Double angle quotation marks     */ ["\u00BB", "\u00AB"], ["\u2039", "\u203A"], /* single angle quotation mark      */ ["\u203A", "\u2039"], ["\u207D", "\u207E"], /* Superscript parentheses          */ ["\u207E", "\u207D"], ["\u208D", "\u208E"], /* Subscript parentheses            */ ["\u208E", "\u208D"], ["\u2264", "\u2265"], /* Less/greater than or equal       */ ["\u2265", "\u2264"], ["\u2329", "\u232A"], /* Angle brackets                   */ ["\u232A", "\u2329"], ["\uFE59", "\uFE5A"], /* Small round brackets             */ ["\uFE5A", "\uFE59"], ["\uFE5B", "\uFE5C"], /* Small curly brackets             */ ["\uFE5C", "\uFE5B"], ["\uFE5D", "\uFE5E"], /* Small tortoise shell brackets    */ ["\uFE5E", "\uFE5D"], ["\uFE64", "\uFE65"], /* Small less than/greater than     */ ["\uFE65", "\uFE64"]];

function getMirror(c){
    var mid, low, high;
    low = 0;
    high = SwapTable.length - 1;
    while (low <= high) {
        mid = Math.floor((low + high) / 2);
        if (c < SwapTable[mid][0]) {
            high = mid - 1;
        }
        else 
            if (c > SwapTable[mid][0]) {
                low = mid + 1;
            }
            else {
                return SwapTable[mid][1];
            }
    }
    return c;
}

var UBAT_L = 0; /* left to right	   */
var UBAT_R = 1; /* right to left	   */
var UBAT_EN = 2; /* European digit    */
var UBAT_AN = 3; /* Arabic-Indic digit */
var UBAT_ON = 4; /* neutral */
var UBAT_B = 5; /* block separator   */
var UBAT_S = 6; /* segment separator */
var UBAT_AL = 7; /* Arabic Letter		*/
var UBAT_WS = 8; /* white space */
var UBAT_CS = 9; /* common digit separator    */
var UBAT_ES = 10; /* European digit separator  */
var UBAT_ET = 11; /* European digit terminator */
var UBAT_NSM = 12; /* Non Spacing Mark	*/
var UBAT_LRE = 13; /* LRE */
var UBAT_RLE = 14; /* RLE */
var UBAT_PDF = 15; /* PDF */
var UBAT_LRO = 16; /* LRO */
var UBAT_RLO = 17; /* RLO */
var UBAT_BN = 18; /* Boundary Neutral */
var TBBASE = 100;

TB00 = TBBASE + 0;
TB05 = TBBASE + 1;
TB06 = TBBASE + 2;
TB07 = TBBASE + 3;
TB20 = TBBASE + 4;
TBFB = TBBASE + 5;
TBFE = TBBASE + 6;
TBFF = TBBASE + 7;

L = UBAT_L;
R = UBAT_R;
EN = UBAT_EN;
AN = UBAT_AN;
ON = UBAT_ON;
B = UBAT_B;
S = UBAT_S;
AL = UBAT_AL;
WS = UBAT_WS;
CS = UBAT_CS;
ES = UBAT_ES;
ET = UBAT_ET;
NSM = UBAT_NSM;
LRE = UBAT_LRE;
RLE = UBAT_RLE;
PDF = UBAT_PDF;
LRO = UBAT_LRO;
RLO = UBAT_RLO;
BN = UBAT_BN;

var MasterTable = [/*****************************************************************************************************//*		0	  1 	2	  3 	4	  5 	6	  7 	8	  9 	A	  B 	C	  D 	E	  F  */
/*****************************************************************************************************/
/*0-*/
TB00, L, L, L, L, TB05, TB06, TB07, R, L, L, L, L, L, L, L, /*1-*/ L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, /*2-*/ TB20, ON, ON, ON, L, ON, L, ON, L, ON, ON, ON, L, L, ON, ON, /*3-*/ L, L, L, L, L, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, /*4-*/ ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, L, L, ON, /*5-*/ ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, /*6-*/ ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, /*7-*/ ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, /*8-*/ ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, /*9-*/ ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, L, /*A-*/ L, L, L, L, L, L, L, L, L, L, L, L, L, ON, ON, ON, /*B-*/ ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, /*C-*/ ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, /*D-*/ ON, ON, ON, ON, ON, ON, ON, L, L, ON, ON, L, L, ON, ON, L, /*E-*/ L, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, /*F-*/ ON, ON, ON, ON, ON, ON, ON, ON, L, L, L, TBFB, AL, AL, TBFE, TBFF];

delete TB00;
delete TB05;
delete TB06;
delete TB07;
delete TB20;
delete TBFB;
delete TBFE;
delete TBFF;

var UnicodeTable = [[ /*	Table 00: Unicode 00xx */ /*****************************************************************************************************//*		0	  1 	2	  3 	4	  5 	6	  7 	8	  9 	A	  B 	C	  D 	E	  F  */
/*****************************************************************************************************/
/*0-*/
BN, BN, BN, BN, BN, BN, BN, BN, BN, S, B, S, WS, B, BN, BN, /*1-*/ BN, BN, BN, BN, BN, BN, BN, BN, BN, BN, BN, BN, B, B, B, S, /*2-*/ WS, ON, ON, ET, ET, ET, ON, ON, ON, ON, ON, ES, CS, ES, CS, CS, /*3-*/ EN, EN, EN, EN, EN, EN, EN, EN, EN, EN, CS, ON, ON, ON, ON, ON, /*4-*/ ON, L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, /*5-*/ L, L, L, L, L, L, L, L, L, L, L, ON, ON, ON, ON, ON, /*6-*/ ON, L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, /*7-*/ L, L, L, L, L, L, L, L, L, L, L, ON, ON, ON, ON, BN, /*8-*/ BN, BN, BN, BN, BN, B, BN, BN, BN, BN, BN, BN, BN, BN, BN, BN, /*9-*/ BN, BN, BN, BN, BN, BN, BN, BN, BN, BN, BN, BN, BN, BN, BN, BN, /*A-*/ CS, ON, ET, ET, ET, ET, ON, ON, ON, ON, L, ON, ON, BN, ON, ON, /*B-*/ ET, ET, EN, EN, ON, L, ON, ON, ON, EN, L, ON, ON, ON, ON, ON, /*C-*/ L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, /*D-*/ L, L, L, L, L, L, L, ON, L, L, L, L, L, L, L, L, /*E-*/ L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, /*F-*/ L, L, L, L, L, L, L, ON, L, L, L, L, L, L, L, L], [ /*	Table 01: Unicode 05xx */ /*****************************************************************************************************//*		0	  1 	2	  3 	4	  5 	6	  7 	8	  9 	A	  B 	C	  D 	E	  F  */
/*****************************************************************************************************/
/*0-*/
L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, /*1-*/ L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, /*2-*/ L, L, L, L, L, L, L, L, ON, ON, ON, ON, ON, ON, ON, ON, /*3-*/ ON, L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, /*4-*/ L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, /*5-*/ L, L, L, L, L, L, L, ON, ON, L, L, L, L, L, L, L, /*6-*/ ON, L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, /*7-*/ L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, /*8-*/ L, L, L, L, L, L, L, L, ON, L, ON, ON, ON, ON, ON, ON, /*9-*/ ON, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, /*A-*/ NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, /*B-*/ NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, R, NSM, /*C-*/ R, NSM, NSM, R, NSM, NSM, R, NSM, ON, ON, ON, ON, ON, ON, ON, ON, /*D-*/ R, R, R, R, R, R, R, R, R, R, R, R, R, R, R, R, /*E-*/ R, R, R, R, R, R, R, R, R, R, R, ON, ON, ON, ON, ON, /*F-*/ R, R, R, R, R, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON], [ /*	Table 02: Unicode 06xx */ /*****************************************************************************************************//*		0	  1 	2	  3 	4	  5 	6	  7 	8	  9 	A	  B 	C	  D 	E	  F  */
/*****************************************************************************************************/
/*0-*/
AN, AN, AN, AN, ON, ON, ON, ON, AL, ET, ET, AL, CS, AL, ON, ON, /*1-*/ NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, AL, ON, ON, AL, AL, /*2-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*3-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*4-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, NSM, NSM, NSM, NSM, NSM, /*5-*/ NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, /*6-*/ AN, AN, AN, AN, AN, AN, AN, AN, AN, AN, ET, AN, AN, AL, AL, AL, /*7-*/ NSM, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*8-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*9-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*A-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*B-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*C-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*D-*/ AL, AL, AL, AL, AL, AL, NSM, NSM, NSM, NSM, NSM, NSM, NSM, AN, ON, NSM, /*E-*/ NSM, NSM, NSM, NSM, NSM, AL, AL, NSM, NSM, ON, NSM, NSM, NSM, NSM, AL, AL, /*F-*/ EN, EN, EN, EN, EN, EN, EN, EN, EN, EN, AL, AL, AL, AL, AL, AL], [ /*	Table 03: Unicode 07xx */ /*****************************************************************************************************//*		0	  1 	2	  3 	4	  5 	6	  7 	8	  9 	A	  B 	C	  D 	E	  F  */
/*****************************************************************************************************/
/*0-*/
AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, ON, AL, /*1-*/ AL, NSM, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*2-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*3-*/ NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, /*4-*/ NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, ON, ON, AL, AL, AL, /*5-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*6-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*7-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*8-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*9-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*A-*/ AL, AL, AL, AL, AL, AL, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, /*B-*/ NSM, AL, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, /*C-*/ R, R, R, R, R, R, R, R, R, R, R, R, R, R, R, R, /*D-*/ R, R, R, R, R, R, R, R, R, R, R, R, R, R, R, R, /*E-*/ R, R, R, R, R, R, R, R, R, R, R, NSM, NSM, NSM, NSM, NSM, /*F-*/ NSM, NSM, NSM, NSM, R, R, ON, ON, ON, ON, R, ON, ON, ON, ON, ON], [ /*	Table 04: Unicode 20xx */ /*****************************************************************************************************//*		0	  1 	2	  3 	4	  5 	6	  7 	8	  9 	A	  B 	C	  D 	E	  F  */
/*****************************************************************************************************/
/*0-*/
WS, WS, WS, WS, WS, WS, WS, WS, WS, WS, WS, BN, BN, BN, L, R, /*1-*/ ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, /*2-*/ ON, ON, ON, ON, ON, ON, ON, ON, WS, B, LRE, RLE, PDF, LRO, RLO, CS, /*3-*/ ET, ET, ET, ET, ET, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, /*4-*/ ON, ON, ON, ON, CS, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, /*5-*/ ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, WS, /*6-*/ BN, BN, BN, BN, BN, ON, ON, ON, ON, ON, BN, BN, BN, BN, BN, BN, /*7-*/ EN, L, ON, ON, EN, EN, EN, EN, EN, EN, ES, ES, ON, ON, ON, L, /*8-*/ EN, EN, EN, EN, EN, EN, EN, EN, EN, EN, ES, ES, ON, ON, ON, ON, /*9-*/ L, L, L, L, L, L, L, L, L, L, L, L, L, ON, ON, ON, /*A-*/ ET, ET, ET, ET, ET, ET, ET, ET, ET, ET, ET, ET, ET, ET, ET, ET, /*B-*/ ET, ET, ET, ET, ET, ET, ET, ET, ET, ET, ON, ON, ON, ON, ON, ON, /*C-*/ ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, /*D-*/ NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, /*E-*/ NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, /*F-*/ NSM, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON], [ /*	Table 05: Unicode FBxx */ /*****************************************************************************************************//*		0	  1 	2	  3 	4	  5 	6	  7 	8	  9 	A	  B 	C	  D 	E	  F  */
/*****************************************************************************************************/
/*0-*/
L, L, L, L, L, L, L, ON, ON, ON, ON, ON, ON, ON, ON, ON, /*1-*/ ON, ON, ON, L, L, L, L, L, ON, ON, ON, ON, ON, R, NSM, R, /*2-*/ R, R, R, R, R, R, R, R, R, ES, R, R, R, R, R, R, /*3-*/ R, R, R, R, R, R, R, ON, R, R, R, R, R, ON, R, ON, /*4-*/ R, R, ON, R, R, ON, R, R, R, R, R, R, R, R, R, R, /*5-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*6-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*7-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*8-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*9-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*A-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*B-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*C-*/ AL, AL, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, /*D-*/ ON, ON, ON, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*E-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*F-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL], [ /*	Table 06: Unicode FExx */ /*****************************************************************************************************//*		0	  1 	2	  3 	4	  5 	6	  7 	8	  9 	A	  B 	C	  D 	E	  F  */
/*****************************************************************************************************/
/*0-*/
NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, NSM, /*1-*/ ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, /*2-*/ NSM, NSM, NSM, NSM, NSM, NSM, NSM, ON, ON, ON, ON, ON, ON, ON, ON, ON, /*3-*/ ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, /*4-*/ ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, /*5-*/ CS, ON, CS, ON, ON, CS, ON, ON, ON, ON, ON, ON, ON, ON, ON, ET, /*6-*/ ON, ON, ES, ES, ON, ON, ON, ON, ON, ET, ET, ON, ON, ON, ON, ON, /*7-*/ AL, AL, AL, AL, AL, ON, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*8-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*9-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*A-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*B-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*C-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*D-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*E-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, /*F-*/ AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, AL, ON, ON, BN], [ /*	Table 07: Unicode FFxx */ /*****************************************************************************************************//*		0	  1 	2	  3 	4	  5 	6	  7 	8	  9 	A	  B 	C	  D 	E	  F  */
/*****************************************************************************************************/
/*0-*/
ON, ON, ON, ET, ET, ET, ON, ON, ON, ON, ON, ES, CS, ES, CS, CS, /*1-*/ EN, EN, EN, EN, EN, EN, EN, EN, EN, EN, CS, ON, ON, ON, ON, ON, /*2-*/ ON, L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, /*3-*/ L, L, L, L, L, L, L, L, L, L, L, ON, ON, ON, ON, ON, /*4-*/ ON, L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, /*5-*/ L, L, L, L, L, L, L, L, L, L, L, ON, ON, ON, ON, ON, /*6-*/ ON, ON, ON, ON, ON, ON, L, L, L, L, L, L, L, L, L, L, /*7-*/ L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, /*8-*/ L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, /*9-*/ L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, /*A-*/ L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, /*B-*/ L, L, L, L, L, L, L, L, L, L, L, L, L, L, L, ON, /*C-*/ ON, ON, L, L, L, L, L, L, ON, ON, L, L, L, L, L, L, /*D-*/ ON, ON, L, L, L, L, L, L, ON, ON, L, L, L, ON, ON, ON, /*E-*/ ET, ET, ON, ON, ON, ET, ET, ON, ON, ON, ON, ON, ON, ON, ON, ON, /*F-*/ ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON, ON]];

delete L;
delete R;
delete EN;
delete AN;
delete ON;
delete B;
delete S;
delete AL;
delete WS;
delete CS;
delete ES;
delete ET;
delete NSM;
delete LRE;
delete RLE;
delete PDF;
delete LRO;
delete RLO;
delete BN;

function getCharacterType(ch){
    var uc = ch.charCodeAt(0);
    var hi = MasterTable[uc >> 8];
    if (hi < TBBASE) 
        return hi;
    return UnicodeTable[hi - TBBASE][uc & 0xFF];
}

var bdx = {
    dir: 0,
    defInFormat: "LLTR",
    defoutFormat: "VLTR",
    defSwap: "YN",
    inFormat: "LLTR",
    outFormat: "VLTR",
    swap: "YN",
    hiLevel: 0,
    lastArabic: false,
    hasUBAT_AL: false,
    hasBlockSep: false,
    hasSegSep: false
};

var ITIL = 5;
var ITCOND = 6;

var impTab_LTR = [/*   L,	R,	 EN,   AN,	 N,  IL, Cond *//* 0 LTR text	  */
[0, 3, 0, 1, 0, 0, 0], /* 1 LTR+AN 	  */ [0, 3, 0, 1, 2, 2, 0], /* 2 LTR+AN+N	  */ [0, 3, 0, 0x11, 2, 0, 1], /* 3 RTL text	  */ [0, 3, 5, 5, 4, 1, 0], /* 4 RTL cont	  */ [0, 3, 0x15, 0x15, 4, 0, 1], /* 5 RTL+EN/AN	  */ [0, 3, 5, 5, 4, 2, 0]];
var impTab_RTL = [/*   L,	R,	 EN,   AN,	 N,  IL, Cond *//* 0 RTL text	  */
[2, 0, 1, 1, 0, 1, 0], /* 1 RTL+EN/AN	  */ [2, 0, 1, 1, 0, 2, 0], /* 2 LTR text	  */ [2, 0, 2, 1, 3, 2, 0], /* 3 LTR+cont	  */ [2, 0, 2, 0x21, 3, 1, 1]];

function doReorder(str){
    var chars = str.split("");
    var levels = new Array(chars.length);
    computeLevels(chars, levels);
    swapChars(chars, levels);
    invertLevel(2, chars, levels);
    invertLevel(1, chars, levels);
    return chars.join("");
}

function swapChars(chars, levels){
    if (bdx.hiLevel == 0 || bdx.swap[0] == bdx.swap[1]) {
        return;
    };
    for (var i = 0; i < chars.length; i++) {
        if (levels[i] == 1) {
            chars[i] = getMirror(chars[i])
        };
            }
}

function invertLevel(lev, chars, levels){
    if (bdx.hiLevel < lev) {
        return;
    }
    if (lev == 1 && bdx.dir == RTL && !bdx.hasUBAT_B) {
        chars.reverse();
        return;
    }
    var len = chars.length, start = 0, end, lo, hi, tmp;
    while (start < len) {
        if (levels[start] >= lev) {
            end = start + 1;
            while (end < len && levels[end] >= lev) {
                end++;
            }
            for (lo = start, hi = end - 1; lo < hi; lo++, hi--) {
                tmp = chars[lo];
                chars[lo] = chars[hi];
                chars[hi] = tmp;
            }
            start = end;
        }
        start++;
    }
}

function computeLevels(chars, levels){
    var len = chars.length;
    var impTab = bdx.dir ? impTab_RTL : impTab_LTR;
    var prevState, newClass, newLevel, newState = 0;
    var action, cond, condPos = -1, i, ix;
    var types = new Array(len);
    var classes = Array(len);
    bdx.hiLevel = bdx.dir;
    bdx.lastArabic = false;
    bdx.hasUBAT_AL = false; bdx.hasUBAT_B = false;
    bdx.hasUBAT_S = false;
    for (i = 0; i < len; i++) {
        types[i] = getCharacterType(chars[i]);
    }
    for (ix = 0; ix < len; ix++) {
        prevState = newState;
        classes[ix] = newClass = getCharClass(chars, types, classes, ix);
        newState = impTab[prevState][newClass];
        action = newState & 0xF0;
        newState &= 0x0F;
        levels[ix] = newLevel = impTab[newState][ITIL];
        if (action > 0) {
            if (action == 0x10) { // set conditional run to level 1
                for (i = condPos; i < ix; i++) {
                    levels[i] = 1;
                }
                condPos = -1;
            }
            else { // 0x20 confirm the conditional run
                condPos = -1;
            }
        }
        cond = impTab[newState][ITCOND];
        if (cond) {
            if (condPos == -1) {
                condPos = ix;
            }
        }
        else { // unconditional level
            if (condPos > -1) {
                for (i = condPos; i < ix; i++) {
                    levels[i] = newLevel;
                }
                condPos = -1;
            }
        }
        if (types[ix] == UBAT_B) {
            levels[ix] = 0;
        }
        bdx.hiLevel |= newLevel;
    }
    if (bdx.hasUBAT_S) {
        for (i = 0; i < len; i++) {
            if (types[i] == UBAT_S) {
                levels[i] = bdx.dir;
                for (var j = i - 1; j >= 0; j--) {
                    if (types[j] == UBAT_WS) {
                        levels[j] = bdx.dir;
                    }
                    else {
                        break;
                    }
                }
            }
        }
    }
}

function getCharClass(chars, types, classes, ix){
    var cType = types[ix], wType, nType, len, i;
    switch (cType) {
        case UBAT_L:
        case UBAT_R:
            bdx.lastArabic = false;
        case UBAT_ON:
        case UBAT_AN:
            return cType;
        case UBAT_EN:
            return bdx.lastArabic ? UBAT_AN : UBAT_EN;
        case UBAT_AL:
            bdx.lastArabic = true;
            bdx.hasUBAT_AL = true;
            return UBAT_R;
        case UBAT_WS:
            return UBAT_ON;
        case UBAT_CS:
            if (ix < 1 || (ix + 1) >= types.length ||
            ((wType = classes[ix - 1]) != UBAT_EN && wType != UBAT_AN) ||
            ((nType = types[ix + 1]) != UBAT_EN && nType != UBAT_AN)) {
                return UBAT_ON;
            }
            if (bdx.lastArabic) {
                nType = UBAT_AN;
            }
            return nType == wType ? nType : UBAT_ON;
        case UBAT_ES:
            wType = ix > 0 ? classes[ix - 1] : UBAT_B;
            if (wType == UBAT_EN && (ix + 1) < types.length && types[ix + 1] == UBAT_EN) {
                return UBAT_EN;
            }
            return UBAT_ON;
        case UBAT_ET:
            if (ix > 0 && classes[ix - 1] == UBAT_EN) {
                return UBAT_EN;
            }
            if (bdx.lastArabic) {
                return UBAT_ON;
            }
            i = ix + 1;
            len = types.length;
            while (i < len && types[i] == UBAT_ET) {
                i++;
            }
            ;            
if (i < len && types[i] == UBAT_EN) {
                return UBAT_EN;
            }
            return UBAT_ON;
        case UBAT_NSM:
            if (bdx.inFormat == "VLTR") { // visual to implicit transformation
                len = types.length;
                i = ix + 1;
                while (i < len && types[i] == UBAT_NSM) {
                    i++;
                };
                if (i < len) {
                    var c = chars[ix];
                    var rtlCandidate = (c >= 0x0591 && c <= 0x08FF) || c == 0xFB1E;
                    wType = types[i];
                    if (rtlCandidate && (wType == UBAT_R || wType == UBAT_AL)) {
                        return UBAT_R;
                    }
                }
            }
            if (ix < 1 || (wType = types[ix - 1]) == UBAT_B) {
                return UBAT_ON;
            }
            return classes[ix - 1];
        case UBAT_B:
            lastArabic = false;
            bdx.hasUBAT_B = true;
            return bdx.dir;
        case UBAT_S:
            bdx.hasUBAT_S = true;
            return UBAT_ON;
        case UBAT_LRE:
        case UBAT_RLE:
        case UBAT_LRO:
        case UBAT_RLO:
        case UBAT_PDF:
            lastArabic = false;
        case UBAT_BN:
            return UBAT_ON;
    }
}

function invertStr(str){
    var chars = str.split("");
    chars.reverse();
    return chars.join("");
}

// --------------------------------------------------------

//SHAPING ENGINE
// added 'var' to make verifier happy, but these variables seem unused?
// [Eric] 8/29/2011 removed (after asking advice from Helena) since these variables are not used anywhere
//TEXT_SHAPE = 0x000000FF, TEXT_INITIAL = 0x00000011, TEXT_MIDDLE = 0x00000012, TEXT_FINAL = 0x00000013, TEXT_ISOLATED = 0x00000014, TAIL = 0x200B, formatedAttributes = 0;

function setAttribute(name, value){
    formatedAttributes = ((formatedAttributes & (~ (name))) | (value & (name)));
}

function getAttribute(attr, name){
    return ((attr) & (name));
}

var LINKR = 1, LINKL = 2, IRRELEVANT = 4, LAMTYPE = 16, ALEFTYPE = 32, LINKFIELD = 3, lamAlphCount = 0;

var shapeTable = [[[0, 0, 0, 0], [0, 0, 0, 0], [0, 1, 0, 3], [0, 1, 0, 1]], [[0, 0, 2, 2], [0, 0, 1, 2], [0, 1, 1, 2], [0, 1, 1, 3]], [[0, 0, 0, 0], [0, 0, 0, 0], [0, 1, 0, 3], [0, 1, 0, 3]], [[0, 0, 1, 2], [0, 0, 1, 2], [0, 1, 1, 2], [0, 1, 1, 3]]];

var convertFEto06 = [0x64B, 0x64B, 0x64C, 0x64C, 0x64D, 0x64D, 0x64E, 0x64E, 0x64F, 0x64F, 0x650, 0x650, 0x651, 0x651, 0x652, 0x652, 0x621, 0x622, 0x622, 0x623, 0x623, 0x624, 0x624, 0x625, 0x625, 0x626, 0x626, 0x626, 0x626, 0x627, 0x627, 0x628, 0x628, 0x628, 0x628, 0x629, 0x629, 0x62A, 0x62A, 0x62A, 0x62A, 0x62B, 0x62B, 0x62B, 0x62B, 0x62C, 0x62C, 0x62C, 0x62C, 0x62D, 0x62D, 0x62D, 0x62D, 0x62E, 0x62E, 0x62E, 0x62E, 0x62F, 0x62F, 0x630, 0x630, 0x631, 0x631, 0x632, 0x632, 0x633, 0x633, 0x633, 0x633, 0x634, 0x634, 0x634, 0x634, 0x635, 0x635, 0x635, 0x635, 0x636, 0x636, 0x636, 0x636, 0x637, 0x637, 0x637, 0x637, 0x638, 0x638, 0x638, 0x638, 0x639, 0x639, 0x639, 0x639, 0x63A, 0x63A, 0x63A, 0x63A, 0x641, 0x641, 0x641, 0x641, 0x642, 0x642, 0x642, 0x642, 0x643, 0x643, 0x643, 0x643, 0x644, 0x644, 0x644, 0x644, 0x645, 0x645, 0x645, 0x645, 0x646, 0x646, 0x646, 0x646, 0x647, 0x647, 0x647, 0x647, 0x648, 0x648, 0x649, 0x649, 0x64A, 0x64A, 0x64A, 0x64A, 0x65C, 0x65C, 0x65D, 0x65D, 0x65E, 0x65E, 0x65F, 0x65F];

var Link06 = [1 + 32 + 256 * 0x11, 1 + 32 + 256 * 0x13, 1 + 256 * 0x15, 1 + 32 + 256 * 0x17, 1 + 2 + 256 * 0x19, 1 + 32 + 256 * 0x1D, 1 + 2 + 256 * 0x1F, 1 + 256 * 0x23, 1 + 2 + 256 * 0x25, 1 + 2 + 256 * 0x29, 1 + 2 + 256 * 0x2D, 1 + 2 + 256 * 0x31, 1 + 2 + 256 * 0x35, 1 + 256 * 0x39, 1 + 256 * 0x3B, 1 + 256 * 0x3D, 1 + 256 * 0x3F, 1 + 2 + 256 * 0x41, 1 + 2 + 256 * 0x45, 1 + 2 + 256 * 0x49, 1 + 2 + 256 * 0x4D, 1 + 2 + 256 * 0x51, 1 + 2 + 256 * 0x55, 1 + 2 + 256 * 0x59, 1 + 2 + 256 * 0x5D, 0, 0, 0, 0, 0, /* 0x63B - 0x63F */ 1 + 2, 1 + 2 + 256 * 0x61, 1 + 2 + 256 * 0x65, 1 + 2 + 256 * 0x69, 1 + 2 + 16 + 256 * 0x6D, 1 + 2 + 256 * 0x71, 1 + 2 + 256 * 0x75, 1 + 2 + 256 * 0x79, 1 + 256 * 0x7D, 1 + 256 * 0x7F, 1 + 2 + 256 * 0x81, 4, 4, 4, 4, 4, 4, 4, 4, /* 0x64B - 0x652 */ 0, 0, 0, 0, 0, 0, 0, 0, 0, /* 0x653 - 0x65B */ 1 + 256 * 0x85, 1 + 256 * 0x87, 1 + 256 * 0x89, 1 + 256 * 0x8B, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,/* 0x660 - 0x66F */ 4, 0, 1 + 32, 1 + 32, 0, 1 + 32, 1, 1, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1, 1 + 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 + 2, 1, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1, 1];

var LinkFE = [1 + 2, 1 + 2, 1 + 2, 0, 1 + 2, 0, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 1 + 2, 0, 0 + 32, 1 + 32, 0 + 32, 1 + 32, 0, 1, 0 + 32, 1 + 32, 0, 2, 1 + 2, 1, 0 + 32, 1 + 32, 0, 2, 1 + 2, 1, 0, 1, 0, 2, 1 + 2, 1, 0, 2, 1 + 2, 1, 0, 2, 1 + 2, 1, 0, 2, 1 + 2, 1, 0, 2, 1 + 2, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 2, 1 + 2, 1, 0, 2, 1 + 2, 1, 0, 2, 1 + 2, 1, 0, 2, 1 + 2, 1, 0, 2, 1 + 2, 1, 0, 2, 1 + 2, 1, 0, 2, 1 + 2, 1, 0, 2, 1 + 2, 1, 0, 2, 1 + 2, 1, 0, 2, 1 + 2, 1, 0, 2, 1 + 2, 1, 0 + 16, 2 + 16, 1 + 2 + 16, 1 + 16, 0, 2, 1 + 2, 1, 0, 2, 1 + 2, 1, 0, 2, 1 + 2, 1, 0, 1, 0, 1, 0, 2, 1 + 2, 1, 0, 1, 0, 1, 0, 1, 0, 1];

var IrrelevantPos = [0x0, 0x2, 0x4, 0x6, 0x8, 0xA, 0xC, 0xE];

var AlefTable = ['\u0622', '\u0623', '\u0625', '\u0627'];

var LamAlefTable = [0xfef5, 0xfef7, 0xfef9, 0xfefb];

var AlefTableFE = [0xFE81, 0xFE82, 0xFE83, 0xFE84, 0xFE87, 0xFE88, 0xFE8D, 0xFE8E];

var LamTableFE = [0xFEDD, 0xFEDE, 0xFEDF, 0xFEE0];

var LamAlefTableFE = [0xfef5, 0xfef7, 0xfef9, 0xfefb, 0xfef6, 0xfef8, 0xfefa, 0xfefc];
var LamAlefInialTableFE = ['\ufef5', '\ufef7', '\ufef9', '\ufefb'];
var LamAlefMedialTableFE = ['\ufef6', '\ufef8', '\ufefa', '\ufefc'];

function getLamAlefInialFE(alef06){
    for (var i = 0; i < AlefTable.length; i++) {
        if (alef06 == AlefTable[i]) {
            return LamAlefInialTableFE[i];
        }
    }
    return alef06;
}

function getLamAlefMedialFE(alef06){
    for (var i = 0; i < AlefTable.length; i++) {
        if (alef06 == AlefTable[i]) {
            return LamAlefMedialTableFE[i];
        }
    }
    return alef06;
}


function uba_getLink(x){
    if (x >= 0x0622 && x <= 0x06D3) {
        return Link06[x - 0x0622];
    }
    else 
        if (x == 0x200D) {
            return 3;
        }
        else 
            if (x >= 0x206D && x <= 0x206F) {
                return 4;
            }
            else 
                if (x >= 0xFE70 && x <= 0xFEFC) {
                    return LinkFE[x - 0xFE70];
                }
                else 
                    return 0;
}

function LamAlef(alef){
    for (var i = 0; i < AlefTable.length; i++) {
        if (AlefTable[i] == alef) {
            return LamAlefTable[i];
        }
    }
    return 0;
}

function isNextAlef(str06, index, step, nIEnd){
    while (((index) * step) < nIEnd && isArabicDiacritics(str06[index])) {
        index += step;
    }
    var c = ' ';
    if (((index) * step) < nIEnd) {
        c = str06[index];
    }
    else {
        return false;
    }
    for (var i = 0; i < AlefTable.length; i++) {
        if (AlefTable[i] == c) {
            return true;
        }
    }
    return false;
}

function setAlefToSpace(str06, index, step, nIEnd){
    while (((index) * step) < nIEnd && isArabicDiacritics(str06[index])) {
        index += step;
    }
    if (((index) * step) < nIEnd) {
        str06[index] = ' ';
        return true;
    }
    return false;
}

function isAlefFE(c){
    for (var i = 0; i < AlefTableFE.length; i++) {
        if (AlefTableFE[i] == c) {
            return true;
        }
    }
    return false;
}

function isLamFE(c){
    for (var i = 0; i < LamTableFE.length; i++) {
        if (LamTableFE[i] == c) {
            return true;
        }
    }
    return false;
}

function isLamAlefFE(c){
    for (var i = 0; i < LamAlefTableFE.length; i++) {
        if (LamAlefTableFE[i] == c) {
            return true;
        }
    }
    return false;
}

function LamAlefFE(alef){
    for (var i = 0; i < AlefTableFE.length; i++) {
        if (AlefTableFE[i] == alef) {
            return LamAlefTableFE[i / 2];
        }
    }
    return 0;
}

function specialChar(ch){
    if ((ch >= 0x0621 && ch < 0x0626) || (ch == 0x0627) ||
    (ch > 0x062e && ch < 0x0633) ||
    (ch > 0x0647 && ch < 0x064a) ||
    (ch == 0x0629) ||
    (ch >= 0x065C && ch <= 0x065F)) {
        return 1;
    }
    else 
        return 0;
}

function YeehHamzaChar(ch){
    if ((ch == 0xFE89) || (ch == 0xFE8A)) {
        return true;
    }
    else 
        return false;
}

function Lamalef(x){
    if (x == 0x0622) {
        return 0x065C;
    }
    else 
        if (x == 0x0623) {
            return 0x065D;
        }
        else 
            if (x == 0x0625) {
                return 0x065E;
            }
            else 
                if (x == 0x0627) {
                    return 0x065F;
                }
                else 
                    return 0;
}

function SeenChar(ch){
    if ((ch == 0xFEB1) || (ch == 0xFEB2) ||
    (ch == 0xFEB5) ||
    (ch == 0xFEB6) ||
    (ch == 0xFEB9) ||
    (ch == 0xFEBA) ||
    (ch == 0xFEBD) ||
    (ch == 0xFEBE)) {
        return true;
    }
    else 
        return false;
}

function CompressLamAlef(UniBuff, length, bRev){
    var CompressedArray = new Array(length), i = 0, j = 0, Lam = 0x0644;
    for (i = 0; i < length - 1; i++) {
        if ((bRev && isAlef(UniBuff[i]) && UniBuff[i + 1] == Lam) ||
        (!bRev && isAlef(UniBuff[i + 1]) && UniBuff[i] == Lam)) {
            CompressedArray[j++] = LamAlef((bRev) ? UniBuff[i] : UniBuff[i + 1]);
            i++;
        }
        else {
            CompressedArray[j++] = UniBuff[i];
        }
    }
    if (i < length) {
        CompressedArray[j++] = UniBuff[i];
    }
    return CompressedArray;
}

/**
 * Arabic Characters in the base form
 */
var BaseForm = ['\u0627', '\u0628', '\u062A', '\u062B', '\u062C', '\u062D', '\u062E', '\u062F', '\u0630', '\u0631', '\u0632', '\u0633', '\u0634', '\u0635', '\u0636', '\u0637', '\u0638', '\u0639', '\u063A', '\u0641', '\u0642', '\u0643', '\u0644', '\u0645', '\u0646', '\u0647', '\u0648', '\u064A', '\u0625', '\u0623', '\u0622', '\u0629', '\u0649', '\u06CC', '\u0626', '\u0624', '\u064B', '\u064C', '\u064D', '\u064E', '\u064F', '\u0650', '\u0651', '\u0652', '\u0621'];

/**
 * Arabic shaped characters in Isolated form
 */
var IsolatedForm = ['\uFE8D', '\uFE8F', '\uFE95', '\uFE99', '\uFE9D', '\uFEA1', '\uFEA5', '\uFEA9', '\uFEAB', '\uFEAD', '\uFEAF', '\uFEB1', '\uFEB5', '\uFEB9', '\uFEBD', '\uFEC1', '\uFEC5', '\uFEC9', '\uFECD', '\uFED1', '\uFED5', '\uFED9', '\uFEDD', '\uFEE1', '\uFEE5', '\uFEE9', '\uFEED', '\uFEF1', '\uFE87', '\uFE83', '\uFE81', '\uFE93', '\uFEEF', '\uFBFC', '\uFE89', '\uFE85', '\uFE70', '\uFE72', '\uFE74', '\uFE76', '\uFE78', '\uFE7A', '\uFE7C', '\uFE7E', '\uFE80'];

/**
 * Arabic shaped characters in Final form
 */
var FinalForm = ['\uFE8E', '\uFE90', '\uFE96', '\uFE9A', '\uFE9E', '\uFEA2', '\uFEA6', '\uFEAA', '\uFEAC', '\uFEAE', '\uFEB0', '\uFEB2', '\uFEB6', '\uFEBA', '\uFEBE', '\uFEC2', '\uFEC6', '\uFECA', '\uFECE', '\uFED2', '\uFED6', '\uFEDA', '\uFEDE', '\uFEE2', '\uFEE6', '\uFEEA', '\uFEEE', '\uFEF2', '\uFE88', '\uFE84', '\uFE82', '\uFE94', '\uFEF0', '\uFBFD', '\uFE8A', '\uFE86', '\uFE70', '\uFE72', '\uFE74', '\uFE76', '\uFE78', '\uFE7A', '\uFE7C', '\uFE7E', '\uFE80'];

/**
 * Arabic shaped characters in Media form
 */
var MedialForm = ['\uFE8E', '\uFE92', '\uFE98', '\uFE9C', '\uFEA0', '\uFEA4', '\uFEA8', '\uFEAA', '\uFEAC', '\uFEAE', '\uFEB0', '\uFEB4', '\uFEB8', '\uFEBC', '\uFEC0', '\uFEC4', '\uFEC8', '\uFECC', '\uFED0', '\uFED4', '\uFED8', '\uFEDC', '\uFEE0', '\uFEE4', '\uFEE8', '\uFEEC', '\uFEEE', '\uFEF4', '\uFE88', '\uFE84', '\uFE82', '\uFE94', '\uFEF0', '\uFBFF', '\uFE8C', '\uFE86', '\uFE71', '\uFE72', '\uFE74', '\uFE77', '\uFE79', '\uFE7B', '\uFE7D', '\uFE7F', '\uFE80'];

/**
 * Arabic shaped characters in Initial form
 */
var InitialForm = ['\uFE8D', '\uFE91', '\uFE97', '\uFE9B', '\uFE9F', '\uFEA3', '\uFEA7', '\uFEA9', '\uFEAB', '\uFEAD', '\uFEAF', '\uFEB3', '\uFEB7', '\uFEBB', '\uFEBF', '\uFEC3', '\uFEC7', '\uFECB', '\uFECF', '\uFED3', '\uFED7', '\uFEDB', '\uFEDF', '\uFEE3', '\uFEE7', '\uFEEB', '\uFEED', '\uFEF3', '\uFE87', '\uFE83', '\uFE81', '\uFE93', '\uFEEF', '\uFBFE', '\uFE8B', '\uFE85', '\uFE70', '\uFE72', '\uFE74', '\uFE76', '\uFE78', '\uFE7A', '\uFE7C', '\uFE7E', '\uFE80'];

/**
 * Arabic characters that couldn't join to the next character
 */
var StandAlonForm = ['\u0621', '\u0627', '\u062F', '\u0630', '\u0631', '\u0632', '\u0648', '\u0622', '\u0629', '\u0626', '\u0624', '\u0625', '\u0675', '\u0623'];

/** ******************************************************* */
/**
 * Arabic characters that couldn't join to the next character
 */
var StandAlonForm = ['\u0621', '\u0627', '\u062F', '\u0630', '\u0631', '\u0632', '\u0648', '\u0622', '\u0629', '\u0626', '\u0624', '\u0625', '\u0675', '\u0623'];
/** Arabic letter Lam */
var ArabicLamCharacter = '\u0644';

var FETo06Table = ['\u064B', '\u064B', '\u064C', '\u061F', '\u064D', '\u061F', '\u064E', '\u064E', '\u064F', '\u064F', '\u0650', '\u0650', '\u0651', '\u0651', '\u0652', '\u0652', '\u0621', '\u0622', '\u0622', '\u0623', '\u0623', '\u0624', '\u0624', '\u0625', '\u0625', '\u0626', '\u0626', '\u0626', '\u0626', '\u0627', '\u0627', '\u0628', '\u0628', '\u0628', '\u0628', '\u0629', '\u0629', '\u062A', '\u062A', '\u062A', '\u062A', '\u062B', '\u062B', '\u062B', '\u062B', '\u062C', '\u062C', '\u062C', '\u062c', '\u062D', '\u062D', '\u062D', '\u062D', '\u062E', '\u062E', '\u062E', '\u062E', '\u062F', '\u062F', '\u0630', '\u0630', '\u0631', '\u0631', '\u0632', '\u0632', '\u0633', '\u0633', '\u0633', '\u0633', '\u0634', '\u0634', '\u0634', '\u0634', '\u0635', '\u0635', '\u0635', '\u0635', '\u0636', '\u0636', '\u0636', '\u0636', '\u0637', '\u0637', '\u0637', '\u0637', '\u0638', '\u0638', '\u0638', '\u0638', '\u0639', '\u0639', '\u0639', '\u0639', '\u063A', '\u063A', '\u063A', '\u063A', '\u0641', '\u0641', '\u0641', '\u0641', '\u0642', '\u0642', '\u0642', '\u0642', '\u0643', '\u0643', '\u0643', '\u0643', '\u0644', '\u0644', '\u0644', '\u0644', '\u0645', '\u0645', '\u0645', '\u0645', '\u0646', '\u0646', '\u0646', '\u0646', '\u0647', '\u0647', '\u0647', '\u0647', '\u0648', '\u0648', '\u0649', '\u0649', '\u064A', '\u064A', '\u064A', '\u064A', '\uFEF5', '\uFEF6', '\uFEF7', '\uFEF8', '\uFEF9', '\uFEFA', '\uFEFB', '\uFEFC', '\u061F', '\u061F', '\u061F'];

var ArabicAlefBetIntervalsBegine = ['\u0621', '\u0640'];
var ArabicAlefBetIntervalsEnd = ['\u063A', '\u064a'];

function isArabicAlefbet(c){
    for (var i = 0; i < ArabicAlefBetIntervalsBegine.length; i++) {
        if (c >= ArabicAlefBetIntervalsBegine[i] && c <= ArabicAlefBetIntervalsEnd[i]) {
            return true;
        }
    }
    return false;
}

function isArabicDiacritics(c){
    if (c >= '\u064b' && c <= '\u0655') {
        return true;
    }
    return false;
}

function isStandAlonCharacter(c){
    for (var i = 0; i < StandAlonForm.length; i++) {
        if (StandAlonForm[i] == c) {
            return true;
        }
    }
    return false;
}

function getMedialFormCharacterFE(c){
    for (var i = 0; i < BaseForm.length; i++) {
        if (c == BaseForm[i]) {
            return MedialForm[i];
        }
    }
    return c;
}

function getFinalFormCharacterFE(c){
    for (var i = 0; i < BaseForm.length; i++) {
        if (c == BaseForm[i]) {
            return FinalForm[i];
        }
    }
    return c;
}

function getInitialFormCharacterFE(c){
    for (var i = 0; i < BaseForm.length; i++) {
        if (c == BaseForm[i]) {
            return InitialForm[i];
        }
    }
    return c;
}

function getIsolatedFormCharacterFE(c){
    for (var i = 0; i < BaseForm.length; i++) {
        if (c == BaseForm[i]) {
            return IsolatedForm[i];
        }
    }
    return c;
}

function isNextArabic(str06, index, step, nIEnd){
    while (((index) * step) < nIEnd && isArabicDiacritics(str06[index])) {
        index += step;
    }
    if (((index) * step) < nIEnd && isArabicAlefbet(str06[index])) {
        return true;
    }
    return false;
}

function shape(rtl, text, compress){
    if (rtl == undefined) {
        rtl = true;
    }
    if (compress == undefined) {
        compress = true;
    }
    if (text.length == 0) {
        return;
    }
    text = new String(text);
    var step, Ix;
    var str06;
    str06 = text.split("");
    var nIEnd = 0;
    if (rtl) {
        Ix = 0;
        step = +1;
        nIEnd = str06.length;
    }
    else {
        Ix = str06.length - 1;
        step = -1;
        nIEnd = 1;
    }
    var previousCursive = 0;
    var compressArray = [];
    var compressArrayIndx = 0;
    for (var index = Ix; index * step < nIEnd; index = index + step) {
        if (isArabicAlefbet(str06[index]) || isArabicDiacritics(str06[index])) {
            if (str06[index] == ArabicLamCharacter) {
                if (isNextAlef(str06, (index + step), step, nIEnd)) {
                    if (previousCursive == 0) {
                        str06[index] = getLamAlefInialFE(str06[index + step]);
                    }
                    else {
                        str06[index] = getLamAlefMedialFE(str06[index + step]);
                    }
                    index += step;
                    setAlefToSpace(str06, index, step, nIEnd);
                    if (compress) {
                        compressArray[compressArrayIndx] = index;
                        compressArrayIndx++;
                    }
                    previousCursive = 0;
                    continue;
                }
            }
            var currentChr = str06[index];
            if (previousCursive == 1) {
                if (isNextArabic(str06, (index + step), step, nIEnd)) { // next is Arabic
                    //Character is in medial form
                    str06[index] = getMedialFormCharacterFE(str06[index]);
                }
                else {
                    //character is in final form
                    str06[index] = getFinalFormCharacterFE(str06[index]);
                }
            }
            else {
                if (isNextArabic(str06, (index + step), step, nIEnd) == true) {
                    //character is in Initial form
                    str06[index] = getInitialFormCharacterFE(str06[index]);
                }
                else {
                    str06[index] = getIsolatedFormCharacterFE(str06[index]);
                }
            }
            //exam if the current character is cursive
            if (!isArabicDiacritics(currentChr)) {
                previousCursive = 1;
            }
            if (isStandAlonCharacter(currentChr) == true) {
                previousCursive = 0;
            }
        }
        else {
            previousCursive = 0;
        }
    }
    var outBuf = "";
    for (idx = 0; idx < str06.length; idx++) {
        if (!(compress && indexOf(compressArray, compressArray.length, idx) > -1)) {
            outBuf += str06[idx];
        }
    }
    return outBuf;
}

function indexOf(cArray, cLength, idx){
    var counter = -1;
    for (var i = 0; i < cLength; i++) {
        if (cArray[i] == idx) {
            return i;
        }
    }
    return -1;
}

function deshape(text, rtl, consume_next_space){
    if (consume_next_space == undefined) {
        consume_next_space = true;
    }
    if (rtl == undefined) {
        rtl = true;
    }
    if (text.length == 0) {
        return;
    }
    text = new String(text);
    var outBuf = "";
    var strFE = [];
	var textBuff = "";
    if (consume_next_space) {
        for (var j = 0; j < text.length; j++) {
            if (text.charAt(j) == ' ') {
                if (rtl) {
                    if (j > 0) {
                        if (text.charAt(j - 1) >= '\uFEF5' && text.charAt(j - 1) <= '\uFEFC') {
                            continue;
                        }
                    }
                }
                else {
					if(j+1 < text.length){
						if (text.charAt(j + 1) >= '\uFEF5' && text.charAt(j + 1) <= '\uFEFC') {
                            continue;
                        }
					}                
                }
            }
			textBuff += text.charAt(j);
        }
    }else{
		textBuff = new String(text);
	}
	strFE = textBuff.split("");
    for (var i = 0; i < textBuff.length; i++) {
        if (strFE[i] >= '\uFE70' && strFE[i] < '\uFEFF') {
            var chNum = textBuff.charCodeAt(i);
            if (strFE[i] >= '\uFEF5' && strFE[i] <= '\uFEFC') {
                //expand the LamAlef
                if (rtl) {
                    //Lam + Alef
                    outBuf += '\u0644';
                    outBuf += AlefTable[parseInt((chNum - 65269) / 2)];
                }
                else {
                    outBuf += AlefTable[parseInt((chNum - 65269) / 2)];
                    outBuf += '\u0644';
                }
            }
            else {
                outBuf += FETo06Table[chNum - 65136];
            }
        }
        else {
            outBuf += strFE[i];
        }
    }
    return outBuf;
}

function ara_type(index, inString, rtl){
    if (inString == null || inString.length == 0) {
        return "";
    }
    if (index >= inString.length) {
        return inString;
    }
    if (index < 0) {
        index = 0;
    }
    
    var str = new String(inString);
    
    var sub = str.substr(index, (inString.length - index));
    sub = shape(rtl, sub, true);
    
    var outBuf = "";
    for (var i = 0; i < index; i++) {
        outBuf += str.charAt(i);
    }
    for (var i = 0; i < sub.length; i++) {
        outBuf += sub.charAt(i);
    }
    
    return outBuf;
    
    var len = text.length, idx, ids;
    var displayStart = index - 2;
    if (displayStart < 0) {
        displayStart = 0;
    }
    if (displayStart >= len) {
        return text;
    }
    var shapeStart = index - 4;
    if (shapeStart < 0) {
        shapeStart = 0;
    }
    var shapeBuf = shape(rtl, text.substring(shapeStart, index + 5));
    var displayEnd = index + 3;
    if (displayEnd > len) {
        displayEnd = len;
    }
    var outBuf = "";
    for (idx = 0; idx < displayStart; idx++) {
        outBuf += text[idx];
    }
    for (ids = displayStart - shapeStart; idx < displayEnd; idx++, ids++) {
        outBuf += shapeBuf[ids];
    }
    for (; idx < len; idx++) {
        outBuf += text[idx];
    }
    return outBuf;
}

return bidiEngine;

});
