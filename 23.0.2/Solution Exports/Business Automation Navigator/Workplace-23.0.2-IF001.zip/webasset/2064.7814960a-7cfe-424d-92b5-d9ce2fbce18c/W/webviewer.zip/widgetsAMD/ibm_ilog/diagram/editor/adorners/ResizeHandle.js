/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"../../base",
"../../adorners/HighlightedHandle",
"../interactors/ResizeHandleInteractor",
"../undo/UndoManager",
"../undo/SimpleAction",
"../undo/UndoActionList",
"../../util/Geometry"
], function(
declare,
iid,
HighlightedHandle,
ResizeHandleInteractor,
UndoManager,
SimpleAction,
UndoActionList,
g
){

/*=====
var HighlightedHandle = ibm_ilog.diagram.adorners.HighlightedHandle;
=====*/

	var ResizeHandle =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.ResizeHandle',[HighlightedHandle],{
	//
	//	summary:
	//		A handle that is associated with a corner of the adorner 
	//		bouding box and allows to resize the adorned by grabbing that 
	//		corner.
	//
	
	//
	//	_location: Point
	//		The corner of the adorned BB associated with the handle. Each 
	//		coord may have a value of 0 or 1 indicating the left or right 
	//		and top or down respectively. 
	//
	location: null,

	//
	//	_startBB:
	//		The original BB of the adorned
	//
	_startBB: null,
	_endBB: null,
	
	setup: function(location) {
		this.location = location;
		this.addInteractor(new ResizeHandleInteractor().initialize(this));
		return this;
	},

	interactionBegun: function() {
		this.inherited(arguments);
		this._startBB = this._adorner._adorned.getBounds();
		this._endBB = this._startBB;
	},

	resize: function(delta) {

		var ge = this._adorner._adorned;
		var bb = g.cloneRect(this._startBB);
		var min = ge.minimumSize;
		
		switch(this.location.x) {
		case 0:
			delta.x = bb.width-Math.max(bb.width-delta.x,min.width);
			bb.x = bb.x + delta.x;
			bb.width = bb.width - delta.x;
			break;
		case 1:
			bb.width = Math.max(min.width,bb.width + delta.x);
			break;
		}			
		
		switch(this.location.y) {
		case 0:
			delta.y = bb.height-Math.max(bb.height-delta.y,min.height);
			bb.y = bb.y + delta.y;
			bb.height = bb.height - delta.y;
			break;
		case 1:
			bb.height = Math.max(min.height,bb.height + delta.y);
			break;
		}			
		
		ge.setBounds(bb);
		this._endBB = bb;
	},
	
	createUndoAction: function(){
		
		var action = new SimpleAction(UndoActionList.Resize);
		
		action.setOldValue(this._startBB);
		action.setNewValue(this._endBB);
		action.setMethodOrProperty('setBounds');
		action.setModifiedElementId(this._adorner._adorned.getId());
		return action;
	}

}));

ResizeHandle.templateId = "ResizeHandle";

return ResizeHandle;

});
