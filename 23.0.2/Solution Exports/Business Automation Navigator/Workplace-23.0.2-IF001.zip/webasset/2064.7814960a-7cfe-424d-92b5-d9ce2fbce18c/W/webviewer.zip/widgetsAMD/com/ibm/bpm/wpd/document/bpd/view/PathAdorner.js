/**
 * A set of PathElements that should be adorned.
 * 
 */
define([
   "dojo/_base/declare", "dojo/_base/lang", "dojo/aspect", "./AdornerTarget"
], function(declare, lang, aspect, AdornerTarget) {
   return declare([], {

      pathElements : null,
      adornerListeners : null,
      data: null,

      constructor : function() {
         this.pathElements = [];
         this.adornerListeners = [];
         this.data = {};
      },
      
      getData: function() {
         return this.data; 
      },

      addElement : function(pathElement) {
         if (!pathElement)
            return;
         this.pathElements.push(pathElement);
         this.adornerListeners.push(aspect.after(pathElement, "onAdornerEvent", lang.hitch(this, function(pathElement, adorner, eventName, data) {
            this.onAdornerEvent(this, pathElement, adorner, eventName, data);
         }), true));

      },
      
      addElements : function(pathElements) {
         if (!pathElements)
            return;
         for (var i = 0; i < pathElements.length; i++) {
            this.addElement(pathElements[i]);
         }
      },

      removeElement : function(pathElement) {
         if (!pathElement)
            return;
         var index = this.pathElements.indexOf(pathElement);
         if (index === -1)
            return;
         this.pathElements.splice(index, 1);
      },
      
      removeElements : function(pathElements) {
         if (!pathElements)
            return;
         for (var i = 0; i < pathElements.length; i++) {
            this.removeElement(pathElements[i]);
         }
      },
      
      removeAllElements : function() {
         var elements = this.pathElements.concat([]);
         this.removeElements(elements);
      },

      findElement : function(id) {
         if (!id)
            return null;
         for ( var i = 0; i < this.pathElements.length; i++) {
            if (this.pathElements[i].id === id) {
               return this.pathElements[i];
            }
         }
         return null;
      },

      adorn : function() {
         for ( var i = 0; i < this.pathElements.length; i++) {
            this.pathElements[i].adorn();
         }
      },

      unAdorn : function() {
         for ( var i = 0; i < this.pathElements.length; i++) {
            this.pathElements[i].unAdorn();
         }
      },
      
      onAdornerEvent: function(pathAdorner, pathElement, adorner, eventName, data) {
         
      },

      destroy : function() {
         this.deregisterAllAdornerListeners();
         for ( var i = 0; i < this.pathElements.length; i++) {
            this.pathElements[i].destroy();
         }
         this.pathElements.length = 0; // Clear the path
      },

      deregisterAllAdornerListeners : function() {
         if (!this.adornerListeners)
            return;
         for ( var i = 0; i < this.adornerListeners.length; i++) {
            this.adornerListeners[i].remove();
         }
         this.adornerListeners.length = 0;
      }

   });

});