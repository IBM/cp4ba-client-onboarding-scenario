/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"../main",
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"dojo/_base/connect",
"dojo/_base/event",
"dojox/gfx",
"../templating",
"./TemplatedOverlay",
"./Adorner",
"./AdornerWithHandles",
"../util/Geometry",
"../util/ErrorReporter"
],
function(
iid,
declare,
lang,
array,
connect,
event,
gfx,
templating,
TemplatedOverlay,
Adorner,
AdornerWithHandles,
g,
R
){

/*=====
var AdornerWithHandles = ibm_ilog.diagram.adorners.AdornerWithHandles;
=====*/

var par = Adorner.prototype;

var LinkAdorner =
iid.gfxDeclaration(declare('ibm_ilog.diagram.adorners.LinkAdorner', [AdornerWithHandles], {
	//
	//	summary:
	//		A UI overlay associated with a link graph entity.
	//
	//	description:
	//		The LinkAdorner object provides a graphical decoration for a
	//		link graph entity. See Adorner for further
	//
	_elementPath: null,
	_echoConnections: null,
	
	initialize: function (diagram, templatePool, templateId) {
		// Summary:
		//		initialize the adorner. Adds some mouse listeners to mouseup and mousedownto push the events to the links
		this.inherited(arguments);
		this._echoConnect();
	},
	
	_buildEchoConnection: function(eventName){
		try {
			this._echoConnections.push(this._path.connect(eventName, this, 'echoEvent'));
		} catch(e) {
			R.warn("EventConnectionFailed",eventName);
		}
	},
	
	_echoConnect: function(){
		if(this._echoConnections){
			array.forEach(this._echoConnections,function(conn){connect.disconnect(conn);});
		}
		this._echoConnections = [];
		if (this['_path']) {
			this._buildEchoConnection('onmousedown');
			this._buildEchoConnection('onmouseup');
			this._buildEchoConnection('onclick');
			this._buildEchoConnection('oncontextmenu');
		}
	},
	
	echoEvent: function (e) {
		// Summary:
		//		Push the recieved event to the binded link
		 if (e.initMouseEvent) {        // Firefox, Google Chrome, Safari, Opera
			  var evt = document.createEvent('MouseEvents');
			  evt.initMouseEvent(e.type, e.bubbles, e.cancelable, e.view, e.detail, e.screenX, e.screenY, e.clientX, e.clientY, e.ctrlKey, e.altKey, e.shiftKey, e.metaKey, e.button, e.relatedTarget);
			  this.getAdorned().rawNode.dispatchEvent(evt);
		 }else{
			  if (document.createEventObject) {        //Internet Explorer
                  var mouseEvent = document.createEventObject (e);
                  mouseEvent.button = e.button;
                  this.getAdorned().rawNode.fireEvent('on'+e.type,mouseEvent);
              }
		}
		event.stop(e);
	},
	
	_reconnectNotifications: function () {
		//
		// 	summary:
		//		Reconnect to change notifications related to the bound element. 
		//
		this.inherited(arguments);
		var e = this._adorned;
		if (e) {
			this._changeConnections.push(connect.connect(e, "_updatePath", this, "_elementBoundsChanged"));
		}
	},

	_setFallbackBounds: function() {
		this._elementPath = [{
			x: iid._invisibleLocation,
			y: iid._invisibleLocation
		}, {
			x: iid._invisibleLocation,
			y: iid._invisibleLocation
		}]; // by default construct adorner out of sight 
		par._setFallbackBounds.apply(this,arguments);
	},
	
	_computeElementBoundsChanged: function () {
		//
		// 	summary:
		//		gets the Element Path from the bounded element
		//
		if (this._required()) {
			this._elementPath = this._adorned._pathPoints;
		}
		par._computeElementBoundsChanged.apply(this,arguments);
	},

	_updateLayout: function () {
		
		this.startDTLBatch();
		this.inherited(arguments);
		var path = lang.clone(this._elementPath);
		if (this._required()) {
			var v = this._viewport,
				z = v.getZoom(),
				vr = v.getViewRect();
			var t = this._adorned.getShapeToContainerTransform(this._diagram.getGraph().getParent());

			path[0] = t.transformPoint(path[0]);
			path[0] = g.moveRect(path[0], g.negPoint(vr));
			path[0].x = path[0].x * z;
			path[0].y = path[0].y * z;

			path[path.length - 1] = t.transformPoint(path[path.length - 1]);
			path[path.length - 1] = g.moveRect(path[path.length - 1], g.negPoint(vr));
			path[path.length - 1].x = path[path.length - 1].x * z;
			path[path.length - 1].y = path[path.length - 1].y * z;
		}

		this.setLinkStartX(path[0].x);
		this.setLinkStartY(path[0].y);
		this.setLinkEndX(path[path.length - 1].x);
		this.setLinkEndY(path[path.length - 1].y);
		this.endDTLBatch();

		//update path
		if (this['_path'] != undefined) {
			if (this.getAdorned() != null) {
				var transformationFunction = lang.hitch(this, function (point, list) {
					var v = this._viewport,
						z = v.getZoom(),
						vr = v.getViewRect();
					var t = this._adorned.getShapeToContainerTransform(v._diagram.getGraph().getParent());
					point = t.transformPoint(point);
					point = g.moveRect(point, g.negPoint(vr));
					point.x = point.x * z;
					point.y = point.y * z;
					return point;
				});
				var curveTension = this.getAdorned().getCurveTension();
				this._updatePathShape(curveTension);
				var points = array.map(this.getAdorned()._pathPoints,transformationFunction);
				this.getAdorned().applyPath(this._path, points,curveTension);
			} else {
				if (this._path instanceof gfx.Polyline) {
					this._path.setShape(path);
					this._path.bbox = null; // patch for GFX bug...
				} else {
					this._path.setShape("");
				}
			}
		}
	},
	
	_updatePathShape: function(curveTension){
		if (curveTension > 0 && !(this._path instanceof gfx.Path)) {
			var stroke, selectedStyle, parent;
			if (this._path) {
				stroke = this._path.getStroke();
				parent = this._path.getParent();
				this._path.removeShape();
			}
			this._path = (parent || this).createPath();
			this._echoConnect();
			if(stroke)
				this._path.setStroke(stroke);
		}
	}

}));

templating.declareBindableProperty(LinkAdorner, "linkStartX", null);
templating.declareBindableProperty(LinkAdorner, "linkStartY", null);
templating.declareBindableProperty(LinkAdorner, "linkEndX", null);
templating.declareBindableProperty(LinkAdorner, "linkEndY", null);

return LinkAdorner;

});
