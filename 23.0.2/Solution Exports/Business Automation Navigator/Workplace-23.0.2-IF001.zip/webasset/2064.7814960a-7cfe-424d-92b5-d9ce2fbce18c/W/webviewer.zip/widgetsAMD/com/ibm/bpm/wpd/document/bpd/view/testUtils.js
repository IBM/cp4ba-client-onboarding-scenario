/**
 * Test utilities used to test the adorner functionality.
 * 
 */
define([
   "dojo/_base/declare",
   "dojo/_base/lang",
   "dojo/aspect",
   "./PathAdorner",
   "./PathElement",
   "./PathExplorer",
   "./TaskStatsNodeAdorner",
   "./ilogDiagramUtils",
   "./adornerConstants",
   "./adornerUtils"
], function(declare, lang, aspect, PathAdorner, PathElement, PathExplorer, TaskStatsNodeAdorner, ilogDiagramUtils, adornerConstants, adornerUtils) {

   var PathAdornerUtils = declare([], {

      count : 0,

      /**
       * Create an adorner that will show halos of graduating intensity around all activities in the
       * provided diagram.
       * 
       * @param bpdViewer
       * @returns
       */
      createGraduatedHighlightBorderPathAdorner : function(bpdViewer) {
         if (!bpdViewer)
            return null;
         var pathAdorner = new PathAdorner();
         var nodeIds = ilogDiagramUtils.getNodeIds(bpdViewer.ilogDiagrammer, function(item) {
            return item && item.type[0] === adornerConstants.TYPE_ACTIVITY;
         });
         var opacity = 0.6;
         var width = 8;
         var color = "red";
         for ( var i = 0; i < nodeIds.length; i++) {
            var target = new PathElement({
               ilogDiagram : bpdViewer.ilogDiagrammer,
               id : nodeIds[i],
               type : adornerConstants.TYPE_ACTIVITY
            });
            var adorner = adornerUtils.createHighlightBorderNodeAdorner(target, color, width, opacity);
            target.addAdorner(adorner);
            pathAdorner.addElement(target);
            if (opacity > 0.2)
               opacity = opacity - 0.1;
         }
         return pathAdorner;
      },

      /**
       * Create an adorner that will show random statistics under all activities in the provided
       * diagram.
       * 
       * @param bpdViewer
       * @returns
       */
      createRandomTaskStatsPathAdorner : function(bpdViewer) {
         if (!bpdViewer)
            return null;
         var pathAdorner = new PathAdorner();
         var nodeIds = ilogDiagramUtils.getNodeIds(bpdViewer.ilogDiagrammer, function(item) {
            return item && item.type[0] === adornerConstants.TYPE_ACTIVITY;
         });
         for ( var i = 0; i < nodeIds.length; i++) {
            var target = new PathElement({
               ilogDiagram : bpdViewer.ilogDiagrammer,
               id : nodeIds[i],
               type : adornerConstants.TYPE_ACTIVITY
            });
            var adorner = adornerUtils
               .createTaskStatsNodeAdorner(target, this.random(), this.random(), this.random(), "MODE_AUTO");
            target.addAdorner(adorner);
            pathAdorner.addElement(target);
         }
         // Registers listener. When a task adorner is selected we have to make sure that any other
         // adorners in the path are unselected.
         aspect.after(pathAdorner, "onAdornerEvent", function(path, pathElement, adorner, eventName, data) {
            if (eventName === "STAT_TYPE_SELECTED") {
               // If it's a different adorner, then we need to unselect it.
               if (pathAdorner.getData().selectedAdorner && adorner != pathAdorner.getData().selectedAdorner) {
                  pathAdorner.getData().selectedAdorner.unselect();
               }
               pathAdorner.getData().selectedAdorner = adorner;
               console.log("Selected stat: " + data + " for node:" + pathElement.id);
            }
         }, true);
         return pathAdorner;
      },

      /**
       * Create a set of adorners. The first will highlight a random path in the provided diagram.
       * The second will add reroute buttons on all of the reroutable links in the diagram (from the
       * computed path). The reroute buttons will create a rerouted path and recompute the possible
       * forks.
       * 
       * @param bpdViewer
       * @returns
       */
      createRandomPathAndForksAdorners : function(bpdViewer) {
         if (!bpdViewer)
            return null;
         var coloredPathAdorner = null;
         var alternateForksAdorner = null;
         var adorner = null;
         var alternateForks = null;
         var afterHandle = null;
         // Function that will be called when a fork button is pressed
         var selectFork = function(pathElement) {
            // Recompute the path going through the selected link.
            var pathElements = pe.computeNewPathTakingFork(pathElement, true);
            pe.setBasePath(pathElements);
            coloredPathAdorner.unAdorn();
            coloredPathAdorner.removeAllElements();
            for ( var i = 0; i < pathElements.length; i++) {
               if (pathElements[i].type === adornerConstants.TYPE_LINK) {
                  adorner = adornerUtils.createColorLinkAdorner(pathElements[i]);
                  pathElements[i].addAdorner(adorner);
                  coloredPathAdorner.addElement(pathElements[i]);
               }
            }
            coloredPathAdorner.adorn();
            // Compute the forks
            pathElements = pe.computeAlternateForks(true);
            alternateForksAdorner.unAdorn();
            alternateForksAdorner.removeAllElements();
            // If there are forks
            for ( var i = 0; i < pathElements.length; i++) {
               adorner = adornerUtils.createRerouteToLinkAdorner(pathElements[i]);
               pathElements[i].addAdorner(adorner);
               alternateForksAdorner.addElement(pathElements[i]);
            }
            if (afterHandle)
               afterHandle.remove();
            afterHandle = aspect.after(alternateForksAdorner, "onAdornerEvent", function(path, pathElement, adorner, eventName, data) {
               if (eventName === "ADORNER_CLICKED") {
                  console.log("Button clicked for link:" + pathElement.id);
                  selectFork(pathElement);
               }
            }, true);
            alternateForksAdorner.adorn();

         };

         // Create the path explorer. Used to compute paths.
         var pe = new PathExplorer(bpdViewer.ilogDiagrammer);
         // Compute an arbitrary path
         var pathElements = pe.computeAPath();
         // If we were able to create a path then add the adorners to the path.
         if (pathElements && pathElements.length > 0) {
            // Was able to compute some path. Produce an adorner that will
            // color it blue
            pe.setBasePath(pathElements);
            coloredPathAdorner = new PathAdorner();
            for ( var i = 0; i < pathElements.length; i++) {
               if (pathElements[i].type === adornerConstants.TYPE_LINK) {
                  adorner = adornerUtils.createColorLinkAdorner(pathElements[i]);
                  pathElements[i].addAdorner(adorner);
                  coloredPathAdorner.addElement(pathElements[i]);
               }
            }
            // Create the forks adorner. First compute the possible forks.
            pathElements = pe.computeAlternateForks(true);
            // If there are forks...
            if (pathElements && pathElements.length > 0) {
               // Adorn the path
               alternateForksAdorner = new PathAdorner();
               for ( var i = 0; i < pathElements.length; i++) {
                  adorner = adornerUtils.createRerouteToLinkAdorner(pathElements[i]);
                  pathElements[i].addAdorner(adorner);
                  alternateForksAdorner.addElement(pathElements[i]);
               }
               // When the click button is pressed, set up the new path.
               afterHandle = aspect.after(alternateForksAdorner, "onAdornerEvent", function(path, pathElement, adorner, eventName, data) {
                  if (eventName === "ADORNER_CLICKED") {
                     console.log("Button clicked for link:" + pathElement.id);
                     selectFork(pathElement);
                  }
               }, true);
            }
         }
         return [
            coloredPathAdorner, alternateForksAdorner
         ];

      },

      random : function() {
         var num = 0;
         if (this.count === 0) {
            num = Math.floor((Math.random() * 10));
         } else if (this.count === 1) {
            num = Math.floor((Math.random() * 100));
         } else if (this.count === 2) {
            num = Math.floor((Math.random() * 1000));
         } else if (this.count === 3) {
            num = Math.floor((Math.random() * 100000));
         } else if (this.count === 4) {
            this.count = -1;
            num = 0;
         }
         this.count = this.count + 1;
         return num;
      }

   });
   return new PathAdornerUtils();
});