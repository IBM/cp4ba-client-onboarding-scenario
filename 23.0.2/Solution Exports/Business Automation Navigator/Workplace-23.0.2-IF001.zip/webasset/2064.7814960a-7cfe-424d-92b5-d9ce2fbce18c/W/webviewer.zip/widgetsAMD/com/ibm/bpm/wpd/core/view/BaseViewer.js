define(["require",
        "dojo/parser",
        "dojo/_base/connect",
        "dijit/_Widget",
        "dijit/_TemplatedMixin",
        "dijit/_WidgetsInTemplateMixin",
        "dijit/_WidgetBase",
        "dojo/_base/declare"],
function(require,
        parser,
        connect,
        _Widget,
        _TemplatedMixin,
        _WidgetsInTemplateMixin,
        _WidgetBase,
        declare) {

/**
 * BaseViewer
 */
return declare([ _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {

	widgetsInTemplate : true,
	
	//The ViewStateModel for this viewer
	viewStateModel:null,
		
	constructor : function(args) {
		// dojo.safeMixin(this, args); //Use this when there are lots of them
		 this.viewStateModel = args.viewStateModel;
	},

	postCreate:function(){
		
		
	},
	
	/**
	 * The viewer become visible
	 * Override this function if you have anything to do onshow
	 */
	onShow : function() {
		//change css class for print
	},
	
	
	/**
	 * The viewer become invisible
	 * Override this function if you have anything to do here
	 */
	onHide: function(){
		
	},

	/**
	 * Set the viewStateModel for this viewer
	 * @param viewStateModel
	 */
	setViewStateModel : function(viewStateModel) {
		this.viewStateModel = viewStateModel;
	}
});

});

/*
dojo.global.copyLinkTooltipDialog =null;

com.ibm.bpm.wpd.core.view.BaseViewer.createCopyLinkHref = function(copyLinkHref) {
	
	
	var copyLinkTooltipDialogName =    "copyLinkTooltipDialog";
	var copyLinkConnectorName =        "copyLinkConnector";	
	var copyLinkTooltipFocusNodeName = "copyLinkTooltipFocusNode";
	var copyLinkTooltipContainerName = "copyLinkTooltipContainer";
	var containerNodeCopyLink = null;
	var domeNodeTooltipDialog = null;
	var connectorNodeCopyLink = null;	
	
	dojo.requireLocalization("com.ibm.bpm.wpd.base", "DocumentationViewerResources");
	this.messages = dojo.i18n.getLocalization("com.ibm.bpm.wpd.base", "DocumentationViewerResources");
	
	/*
	 *  for proxy, IHS, etc. web server, URL will have no port
	 * /
	
	if(copyLinkHref.port.length == 0){ 
		port = copyLinkHref.port;
	}else{
		port = ":" + copyLinkHref.port; 
	}
	var href= copyLinkHref.protocol + "//" + copyLinkHref.hostname + port
    + "/bpmasset/" + (com.ibm.bpm.wpd.core.model.shellstate.ShellStateModel.getInstance().getActiveViewStateModel()).documentId
    + "?";

    var branchId=(com.ibm.bpm.wpd.core.model.shellstate.ShellStateModel.getInstance()).branchId;

    branchId ? href = href + "branchId=" +branchId:
    	href = href + "snapshotId=" +((com.ibm.bpm.wpd.core.model.shellstate.ShellStateModel.getInstance()).snapshotId);
       
    copyLinkHref.protocol= "javascript:";   /// disable opening copy link onclick even 
   

    /*
     *  Create TooltipDialog for copy link
     * /
    var content= "<p ><strong>" + href +"</strong></p><p style=\"margin-bottom : 0em;\">" + this.messages.COPY_LINK_TOOLTIP_DIALOG + "</p>";
    
    if( !dojo.global.copyLinkTooltipDialog){
	    var _copyLinkToolTip = dojo.declare("_copyLinkToolTip",[dijit.TooltipDialog], {
			templateString: '<div role="presentation" tabIndex="-1">' +
							'	<div class="dijitTooltipContainer"  role ="presentation">' +		
							'		<div class ="dijitTooltipContents dijitTooltipFocusNode '+ 
							      copyLinkTooltipFocusNodeName + "\""+
							'  data-dojo-attach-point="containerNode" role="dialog"></div>' +
							'	</div>' +
							'	<div class="dijitTooltipConnector" role="presentation" data-dojo-attach-point="connectorNode" ></div>' +
							'</div>' 
		});
	    dojo.global.copyLinkTooltipDialog = new _copyLinkToolTip({
	        id: copyLinkTooltipDialogName,
	        });
	    
	    containerNodeCopyLink = dojo.global.copyLinkTooltipDialog.containerNode.parentNode;
	    if(containerNodeCopyLink != null) {
	        dojo.attr(containerNodeCopyLink, "style", {background: "#FFC"});
	        dojo.attr(containerNodeCopyLink, "style", {fontsize:  "8pt"});
	        dojo.attr(containerNodeCopyLink, "style", {border:  "2px #C0C09F solid"});        
	        dojo.addClass(containerNodeCopyLink,copyLinkTooltipContainerName);
	    }
	    
	    domeNodeTooltipDialog = dojo.global.copyLinkTooltipDialog.domNode;
	    if( domeNodeTooltipDialog != null){        
	        dojo.addClass(domeNodeTooltipDialog,copyLinkTooltipDialogName);
	        dojo.attr( domeNodeTooltipDialog, "style", {width:  "500px"});
	        
	       
	    }
	    
	
	    connectorNodeCopyLink= dojo.global.copyLinkTooltipDialog.connectorNode;
	    if( connectorNodeCopyLink != null){      
	        dojo.attr(connectorNodeCopyLink, "style", {background: "url(/WebViewer/widgets/com/ibm/bpm/wpd/images/tooltiparrow.png) no-repeat top left"});
	        dojo.attr(connectorNodeCopyLink, "style", {width:  "26px"});
	        dojo.attr(connectorNodeCopyLink, "style", {height:  "15px"});	 
	    	dojo.addClass(connectorNodeCopyLink,copyLinkConnectorName);
	    }
    }
   
     /*
      *  Display TooltipDialog for copy link
     * /
    
    dojo.connect(copyLinkHref, "onclick", function(){
    	
    	copyLinkHrefPosition = dojo.position(copyLinkHref,true); 
    	dojo.global.copyLinkTooltipDialog.containerNode.innerHTML = content; /// set TooltipDialog content
		dijit.popup.open({
             popup: dojo.global.copyLinkTooltipDialog,
             around: copyLinkHref
         });		
		
	  });  
    
    dojo.connect(copyLinkTooltipDialog, "onOpen", function(event){     ///  set connector location
    	 if(copyLinkHrefPosition.x==event.x){
    	   dojo.attr(connectorNodeCopyLink, "style", {left:  "15px"});
    	 }else{
    	   dojo.attr(connectorNodeCopyLink, "style", {right:  "15px"}); 
    	 }
	  }); 
    
    dojo.connect(copyLinkHref, "onmouseout", function(event){
    	
    	if(event.relatedTarget!= null ){
    	
    	if(((event.relatedTarget.className).indexOf(copyLinkTooltipDialogName)==-1) && 
    			((event.relatedTarget.className).indexOf(copyLinkConnectorName)==-1) &&
    			((event.relatedTarget.className).indexOf(copyLinkTooltipFocusNodeName)==-1)&&
    			((event.relatedTarget.className).indexOf(copyLinkTooltipContainerName)==-1))
    		
    			dijit.popup.close(copyLinkTooltipDialog); 
    	}
    	
	  });
    
 
    dojo.connect(copyLinkTooltipDialog, "onMouseLeave", function(){  	
    	dijit.popup.close(copyLinkTooltipDialog);
    	
	  }); 

};

*/
