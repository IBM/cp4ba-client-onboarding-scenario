/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["../base", "dojo/_base/lang", "dojo/_base/config", "dojox/gfx/_base", "dojox/gfx/matrix", "dojox/gfx/shape"],
function(iid, lang, config, gfx, matrix, shape){
	
/*=====
var gfx = dojox.gfx;
=====*/

var MultilineText = iid.gfxDeclare("ibm_ilog.diagram.util.MultilineText", [ gfx.Group ], {
	// summary:
	//		A multi-line text shape for GFX.
	// description:
	//		The MultilineText shape is similar to a Text shape, except that it can display multiple lines of text.
	//		<p>
	//		The shape object of the MultilineText accepts the same attributes as a plain Text shape
	//		("text", "x", "y", "align", etc). The "type" property must be "mltext".
	//		</p>
	//		<p>
	//		The MultilineText shape also accepts an additional "separator" attribute, that
	//		defines the line separator. The default separator is "\n". You can specify a simple string, or
	//		a RegExp as separator (for example, "[ \t]+"). When the text contains one or more
	//		occurrences of the line separator, the text is broken into several lines. The first line is placed
	//		normally according to the x and y properties of the shape, and subsequent lines are stacked vertically
	//		below the first line, that is, the baseline of the second line is at (x, y+h), where h is the font height.
	//		You can also specify an additional spacing using the "spacing" property of the shape (0 by default).
	//		</p>
	//		<p>
	//		The MultilineText supports simple text wrapping. To enable text wrapping, set the "wrap" property of the shape to true.
	//		When text wrapping is enabled, the text will be automatically broken into lines if necessary to fit the width of the text.
	//		This will work only if the width of the shape is constrained in one of the following ways:
	//		<ul>
	//		<li>You can specify the "width" property of the shape to a fixed width.</li>
	//		<li>The shape can be contained in a Group that has a GFX layout, and that constrains the width of the shape.
	//		For example, if the MultilineText shape is contained in a Group with a GridLayout with a fixed column width,
	//		then the text will be wrapped to fit the column width. (Note: the width determined by the GFX layout has precedence
	//		over the "width" shape property.)</li>
	//		</ul>
	//		In addition to wrapping text, you can also wrap single words if they do not fit the text width. To do this,
	//		set the "wordWrap" property of the shape to true (word-wrapping is false by default).
	//		</p>
	//		<p>
	//		<strong>Note:</strong> The built-in text wrapping method is a simplistic convenience placeholder that only breaks lines at space characters.
	//		To wrap text correctly according to globalization rules, you will need to provide a more complete implementation.
	//		To do this, you should override the <code>split</code> and <code>join</code> methods (to use different word breaking rules)
	//		or the <code>wrap</code> method (to completely replace the text wrapping algorithm), through a <code>dojo.extend</code> call.
	//		</p>
	//		<p>
	//		The MultilineText shape is actually a GFX Group shape containing Text shapes that display the lines.
	//		Each Text line has the same attributes as the MultilineText shape: align, font, fill, etc. For example,
	//		if the MultilineText has align: 'left', then all the lines will be aligned on the left. Similarly,
	//		calling setFont() on the MultilineText shape sets the font of all the lines.
	//		</p>
	
	_isIBMDiagramMultilineText: true,
	
	_font: null,
	
	_lastWrapWidth: -1,
	
	textDir: "",
	
	setTextDir: function(/*String*/textdir) {
	   // summary:
	   //       set text direction property, need for runtime change of text direction  
	   
	   this.textDir = textdir; 
	},	
	
	constructor: function(){
		// summary:
		//		Creates an empty MultilineText instance.
		
		this.shape = lang.clone(iid.util.MultilineText.defaultMultilineText);
	},
	
	setShape: function(shape){
		// summary:
		//		Sets the attributes of the MultilineText shape.
		// description:
		//		The <code>shape</code> parameter is an object with the following properties:
		//		<table style="border-collapse:collapse;" border="1">
		//			<tr>
		//				<th><b>Property</b></th>	<th><b>Description</b></th>
		//			</tr>
		//			<tr>
		//				<td>type</td>				<td>must be <code>'mltext'</code></td>
		//			</tr>
		//			<tr>
		//				<td>text</td>				<td>The text string to display.</td>
		//			</tr>
		//			<tr>
		//				<td>x</td>					<td>Defines the horizontal position of the text.</td>
		//			</tr>
		//			<tr>
		//				<td>y</td>					<td>Defines the vertical position of the baseline of the first line of text.</td>
		//			</tr>
		//			<tr>
		//				<td>align</td>				<td>The horizontal alignment (see dojox.gfx.Text).</td>
		//			</tr>
		//			<tr>
		//				<td>decoration</td>			<td>(see dojox.gfx.Text)</td>
		//			</tr>
		//			<tr>
		//				<td>rotated</td>			<td>(see dojox.gfx.Text) Not supported for multi-line text.</td>
		//			</tr>
		//			<tr>
		//				<td>kerning</td>			<td>(see dojox.gfx.Text)</td>
		//			</tr>
		//			<tr>
		//				<td>separator</td>			<td>The line separator character or regular expression.</td>
		//			</tr>
		//			<tr>
		//				<td>spacing</td>			<td>The vertical line spacing.</td>
		//			</tr>
		//			<tr>
		//				<td>wrap</td>				<td>If <code>true</code>, enables text wrapping. The value can also be a custom text wrapping function.</td>
		//			</tr>
		//			<tr>
		//				<td>wordWrap</td>			<td>If <code>true</code>, enables word-wrapping, that is, breaking single-word lines that do not fit the specified width.</td>
		//			</tr>
		//			<tr>
		//				<td>width</td>				<td>Specifies a default width for text wrapping. Can be overridden by a GFX layout.</td>
		//			</tr>
		//		</table>
		// shape: Object
		//		A hash that contains the properties of the shape.
		
		if(this._noSetShape) return this; // see comment in _createLine before this.createText...
		if(iid._inContainerAdd) return this;
		
		var sh = this.shape = lang.mixin(lang.clone(iid.util.MultilineText.defaultMultilineText), shape);
		
		this._lastWrapWidth = -1;
		
		if(sh.wrap && sh.width > 0)
			this._doWrap(sh.width);
		else {
			var sep = sh.separator;
			if(sep.length > 1)
				sep = new RegExp(sep, "g");

			var lines = sh.text.split(sep);

			this._createLines(lines);
		}
		// propagate changes and invalidate
		iid._base.gfxext.onChangePatch.call(this, 'setShape');
		return this;
	},
	
	_createLines: function(lines)
	{
		// summary:
		//		Creates the Text shapes displaying the lines of text.
		
		if(this.children && this.children.length > 0)
			this.clear();
		
		var sh = this.shape;
		
		var y = sh.y;
		for(var i = 0; i < lines.length; i++){
			var textObj = this._createLine(lines[i], y);
			if(textObj){
				var bb = textObj.getBoundingBox();
				if(bb)
					y += bb.height + sh.spacing;
			}
		}
	},
	
	_createLine: function(text, y)
	{
		var sh = this.shape;
		
		var textShape = lang.clone(gfx.defaultText);
		for(var p in textShape)
			if(p != "type" && sh[p])
				textShape[p] = sh[p];
		textShape.y = y;
		textShape.text = text;
		
		if (config.isBidiInDojoDiagrammer && sh.textDir)                            
			textShape.textDir = sh.textDir;	
		
		// This is a workaround for a very nasty bug with Dojo 1.6:
		// when adding a text child, Dojo now resets the shape and text of all other text children,
		// but it does so using a dojox.gfx.utils.forEach, which iterates also on the multiline shape itself
		// (because the forEach just tests if the shape has a getFont method, which the parent multiline shape
		// happens to have too...).
		// So to avoid this we disable setShape by a flag.
		this._noSetShape = true;
		var textObj = this.createText(textShape);
		delete this._noSetShape;
		if(textObj){
			// copy font and fill:
			var s;
			s = this.getFont(); if(s) textObj.setFont(s);
			s = this.getFill(); if(s) textObj.setFill(s);
		}	
		return textObj;
	},
	
	setFont: function(font){
		// summary: 
		//		Sets the font for text.
		// font: Object
		//		A font object (see dojox.gfx.defaultFont) or a font string
		
		if(iid._inContainerAdd) return this;
		
		this._font = font;
		
		var y = this.shape.y;
		for(var i = 0; i < this.children.length; i++){
			this.children[i].setFont(font);
		}
		// propagate changes and invalidate
		iid._base.gfxext.onChangePatch.call(this, 'setShape');
		return this;
	},
	
	getFont: function(){
		// summary:
		//		Returns the current font object or null.
		
		return this._font;
	},
	
	setFill: function(fill){
		// summary: 
		//		Sets the color for text.
		// fill: Object
		//		A fill object (see dojox.gfx.defaultFill) or a color string.
		
		this.inherited(arguments);
		for(var i = 0; i < this.children.length; i++)
			this.children[i].setFill(fill);
	},
	
	_computeBoundingBox: function(){
		// summary: Better fix than the old getBoundingBox override, since the previous fix
		//		did not store the bbox in the cache, so direct calls to _computeBoundingBox (from gfxlayout/_base)
		//		still returned null...
		gfx.Group.prototype._computeBoundingBox.call(this);
		if(!this._bbCache){
			this._bbCache = { x:0, y:0, width:1, height:1 };
			var lbb = { x:0, y:0, width:1, height:1 };
			var t = this.getTransform();
			this._lbbCache = t ? t.transformRectangle(lbb) : lbb;
		}
	},
	
	_computePreferredSize: function(/*Size*/proposedSize) {
		// summary:
		//     Computes the preferred size of this shape. 
		// description:
		//     This method wraps the text if required.
		
		var width = proposedSize.width;
		if(width <= 0)
			width = this.shape.width;

    	if(this.shape.wrap && width > 0)
    		this._doWrap(width);
		
    	var sz = this.inherited(arguments);
    	
    	return sz;
	},
	
    applyLayout: function(/*Rectangle*/rect) {
    	// summary:
    	//		Layout this text in the given rectangle.
    	
    	if (this.shape.wrap) {
			var w = rect.width;
			var t = this.getTransform();
			if(t && !t.isTranslation())
				w = t.inverse().transformRectangle(rect).width;
			this._doWrap(w);
		}
    	
    	var x = rect.x;
    	var y = rect.y;
        var oldBounds = this.getLocalBoundingBox();
        if (oldBounds){
        	// horizontal alignment:
        	switch(this.shape.align){
        	case 'middle':
        		x += (rect.width - oldBounds.width)/2;
        		break;
        	case 'end':
        		x += (rect.width - oldBounds.width);
        		break;
        	}
        	// vertical alignment:
        	switch(this.valign || 'stretch'){
        	case 'center':
        	case 'stretch':
        		y += (rect.height - oldBounds.height)/2;
        		break;
        	case 'bottom':
        		y += rect.height - oldBounds.height;
        		break;
        	}
        	
            this.applyLeftTransform(matrix.translate(x-oldBounds.x, y-oldBounds.y));
        } else {
            this.setTransform(matrix.translate(x, y));
        }
    },
    
    _doWrap: function(width)
    {
    	if(width == this._lastWrapWidth)
    		return;
   		this._lastWrapWidth = width; // may be reset to -1 below if we see that bboxes can't be computed
    	
    	if(this.shape.text == ""){
    		this._createLines([""]);
    		return;
    	}
    	
		var wrap = this.shape.wrap;
		
		if(wrap){
			try {
				if(this.suspendInvalidate) this.suspendInvalidate();
				this._noOnChanged=true;
				var lines = this.wrap(this.shape.text, width);
				this._createLines(lines);
			} catch(e){
			} finally {
				if(this.resumeInvalidate) this.resumeInvalidate(false);
				delete this._noOnChanged;
				this._bbCacheValid = false;
			}
		}
    },
    
    wrap: function(text, width)
    {
		// summary:
		//		Breaks the text into lines to fit the specified width.
		// description:
		//		This method implements a simplistic text wrapping algorithm that breaks 
		//		the specified text into lines to fit the specified width.
		//		This simple implementation breaks the text into words by calling the
		//		<code>split</code> and <code>join</code> methods.
		//		When using Dojo Diagrammer in a globalized application, you should override
		//		the default algorithm (through a <code>dojo.extend</code> call) and provide a more complete implementation.
		//		You can just override the <code>split</code> and <code>join</code> methods if this fits your needs, 
		//		or you can completely override the <code>wrap</code> method if necessary.
		// text: string
		//		The text to break into lines fitting the specified width.
		// width: Number
		//		The width in which the wrapped text should fit.
		// returns:
		//		An array of strings representing the wrapped lines of text.
		
        var lines = [];
        var sh = this.shape;
        
        // Keep "hard" line breaks: split the text into paragraphs first,
        // then wrap each paragraph separately.
		var sep = sh.separator;
		if(sep.length > 1)
			sep = new RegExp(sep, "g");
		var paragraphs = text.split(sep);
		
		var tmpText = null;
		
		for(var pi = 0; pi < paragraphs.length; pi++){
			// split into words
			var words = this.split(paragraphs[pi]);
			if (words.length > 0) {
				var line = null;
				// join words into lines until max width is exceeded
				var i0 = 0;
				tmpText = this._createLine("", 0);
				var bb;
				for (var i = 0; i < words.length; i++) {
					var word = words[i];
					if (!line) {
						line = word;
						// Do word-wrapping?
						if (sh.wordWrap) {
							tmpText.setShape({
								text: line
							});
							bb = tmpText.getBoundingBox();
							if(!bb || (bb.width == 0 && bb.height == 0)) this._lastWrapWidth = -1;
							if (bb && bb.width > width) {
								var cutIndex = this.next(word, 0);
								if (cutIndex > 0) {
									for (var j = this.next(word, cutIndex); j >= 0; j = this.next(word, j)) {
										var w = word.substring(0, j);
										tmpText.setShape({
											text: w
										});
										bb = tmpText.getBoundingBox();
										if(!bb || (bb.width == 0 && bb.height == 0)) this._lastWrapWidth = -1;
										if (bb && bb.width > width) 
											break;
										cutIndex = j;
									}
									lines.push(word.substring(0, cutIndex));
									words[i] = word.substring(cutIndex);
									line = null;
									i--;
								}
							}
						}
					} else {
						var newline = this.join(words.slice(i0, i + 1));
						tmpText.setShape({
							text: newline
						});
						bb = tmpText.getBoundingBox();
						if(!bb || (bb.width == 0 && bb.height == 0)) this._lastWrapWidth = -1;
						if (bb && bb.width > width) {
							lines.push(line);
							i0 = i;
							line = null;
							i--;
						}
						else {
							line = newline;
						}
					}
				}
				if (line) 
					lines.push(line);
			}
		}
        
		if(tmpText) this.remove(tmpText);
		
        return lines; // Array
    },
    
    split: function(text)
    {
		// summary:
		//		Splits the text using a space character delimiter.
		// description:
		//		The default method used to break the text into words for text wrapping.
		//		This default implementation splits the text using a space character delimiter.
		//		When using Dojo Diagrammer in a globalized application, you should override
		//		the default algorithm (through a <code>dojo.extend</code> call) and provide a more complete implementation.
		//		You can just override the <code>split</code> and <code>join</code> methods if this fits your needs, 
		//		or you can completely override the <code>wrap</code> method if necessary.
		// text: string
		//		The text to split into words.
		// returns:
		//		An array of strings representing the possible line break positions.
		
    	return text.split(" "); // Array
    },
    
    join: function(words)
    {
		// summary:
		//		Joins the words using a space character delimiter.
		// description:
		//		The default method used to join word into lines for text wrapping.
		//		This default implementation joins the words using a space character delimiter.
		//		When using Dojo Diagrammer in a globalized application, you should override
		//		the default algorithm (through a <code>dojo.extend</code> call) and provide a more complete implementation.
		//		You can just override the <code>split</code> and <code>join</code> methods if this fits your needs, 
		//		or you can completely override the <code>wrap</code> method if necessary.
		// words: Array
		//		The array of words to join into a line string.
		// returns:
		//		The specified words joined into a string.
		
    	return words.join(" "); // string
    },
	
	next: function(word, index)
	{
		// summary:
		//		Returns the next character in the word after index where word-wrapping is allowed.
		// description:
		//		This method is called during word-wrapping, to get the next character position where word-wrapping would be allowed.
		//		The default implementation just increments the index. You can override this method to forbid word breaks on particular
		//		characters, or for globalization.
		// word: string
		//		The word that is being wrapped.
		// index: int
		//		The start index from which the next character if required.
		// returns:
		//		The index of the next character where a word break may occur, or -1 if the end of the string was reached.
		
		index++;
		return index < word.length ? index : -1; // int
	}
});

iid.util.MultilineText._nextId = 1;
iid.util.MultilineText.defaultMultilineText = lang.mixin(lang.clone(gfx.defaultText),
										{ type: 'mltext', separator: '\n', spacing: 0, wrap: false, wordWrap: false, width: -1 });
iid.util.MultilineText.nodeType = gfx.Group.nodeType;

//
// Extends createShape to support our own shape types
//

function extendCreateShape(shapeType) {
    var method = "createShape";
    var old = shapeType.prototype[method];
    shapeType.prototype[method] = function() {
        var ret = old.apply(this, arguments);
        if (!ret) {
            var sh = arguments[0];
            switch (sh.type) {
                case 'mltext':
                    ret = this.createObject(iid.util.MultilineText, sh);
                    if (config.isBidiInDojoDiagrammer) {
                        var sp = this;
    				    while (sp) {
    					    if (sp.textDir) {
    						    ret.textDir = sp.textDir;
    						    break;
    					    }
    					    else if(sp.getTextDir) {
    						    ret.textDir = sp.getTextDir();
    						    break;
    					    }
    					    if (!sp.parent)
    						    break;
    					    sp = sp.getParent();
    				    }
                    }                    
                    break;
            }
        }
        return ret;
    };
}
extendCreateShape(gfx.Surface);
extendCreateShape(gfx.Group);

return MultilineText;

});
