/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
	"dojo/_base/lang",
	"dojo/has!config-diagramForMobile?:dojo/number",	// #1 (for dojo.number.round)
	"./ErrorReporter"	// #2
	],
	function(
		lang,
		NumberUtils, // #1
		ErrorReporter	// #2
		) {

	// TODO: Change to this when AMD conversion is complete:
	// var g = {};
	var g = lang.getObject("ibm_ilog.diagram.util.Geometry", true);
	
	//
	//	Representation for the empty rectangle
	//		
	g.EmptyRect = { x: 0, y: 0, width: 0, height: 0 };

	
  g.isEmptyRect = function( /*dojox.gfx.Rectangle*/ r ) {
	//	returns:
	//		true when r is the empty rectangle.
      return r.x === 0 && r.y === 0 && r.width === 0 && r.height === 0;
  };

  g.equalRect = function( /*dojox.gfx.Rectangle*/ r1, /*dojox.gfx.Rectangle*/ r2) {
  	//	returns:
  	//		true when the two rects are equal
      return (r1.x === r2.x) &&
         (r1.y === r2.y) &&
         (r1.width === r2.width) &&
         (r1.height === r2.height);
  };

	g.cloneRect = function ( /*dojox.gfx.Rectangle*/ r) {
    	return {
    		x:r.x,
    		y:r.y,
    		width:r.width,
    		height:r.height
    		};
		};
		
  g.Rect = function(x,y,w,h) {
  	//	x: Number
  	//	y: Number
  	//	w: Number
  	//	h: Number
  	var r = {};

  	if(x!==undefined) {
  		r.x = x;
  	}
  	
  	if(y!==undefined) {
  		r.y = y;
  	}
  	
  	if(w!==undefined) {
  		r.width = w;
  	}
  	
  	if(h!==undefined) {
  		r.height = h;
  	}
  	
  	return r;
  };
  
  g.standarizeRect = function(r) {
  	//	r:	dojox.gfx.Rectangle
  	return {
  		x:r.x||0,
  		y:r.y||0,
  		width:r.width||r.w||0,
  		height:r.height||r.h||0
  		};
  };
  
  g.rectAssign = function(a,b) {
  	a.x = b.x;
  	a.y = b.y;
  	a.width = b.width;
  	a.height = b.height;
  };
  
  g.rectIncomplete = function( r ) {
  	//	r:	dojox.gfx.Rectangle
      return r.x===undefined || r.y===undefined || r.width===undefined || r.height===undefined;
  };
  
  g.getRectCenter = function( r ) {
  	//	r:	dojox.gfx.Rectangle
  	//	returns:
  	//		a point equal to the center of the rectangle r
      if(g.rectIncomplete(r)) {
      	return null;
      } else {
      	return { x: r.x + r.width / 2, y: r.y + r.height / 2 };
      }
  };

  g.rectCenteredAt = function( r, p, center ) {
  	//	r:	dojox.gfx.Rectangle
  	//	p:	dojox.gfx.Point
  	//	center: dojox.gfx.Point? 
  	//	returns:
  	//		a copy of r but centered at p
  	center = center || { x:r.width / 2, y:r.height / 2 };
      return { x: p.x - center.x, y: p.y - center.y, width:r.width, height:r.height};
  };

  g.rectIntersects = function(rect1,rect2) {
      return (rect1.x < (rect2.x + rect2.width)) &&
             (rect2.x < (rect1.x + rect1.width)) &&
             (rect1.y < (rect2.y + rect2.height)) &&
             (rect2.y < (rect1.y + rect1.height));        
  };
  
  g.addRect = function( /*dojox.gfx.Rectangle*/ a, /*dojox.gfx.Rectangle*/ b) {
  	//	returns:
  	//		a rectangle representing the addition of the two given.
      if (a === null && b === null) {
          return null;
      }
      if (a === null && b !== null) {
          return b;
      }
      if (b === null) {
          return a;
      }
      var single1 = Math.min(a.x, b.x);
      var single2 = Math.max(a.x + a.width, b.x + b.width);
      var single3 = Math.min(a.y, b.y);
      var single4 = Math.max(a.y + a.height, b.y + b.height);
      return { x: single1, y: single3, width: single2 - single1, height: single4 - single3 };
  };
  
  g.createRect = function(p1,p2){
  	var x = Math.min(p2.x,p1.x);
      var y = Math.min(p2.y,p1.y);
      var width = Math.abs(p2.x-p1.x);
      var height = Math.abs(p2.y-p1.y);
  	return {x:x,y:y,width:width,height:height};
  };
  
  g.containsRect = function(cr,r){
  	if(cr.x<=r.x && cr.y<=r.y 
  			&& (cr.width+cr.x)>=(r.x+r.width) && (cr.height+cr.y)>=(r.y+r.height)){
  		return true;
  	}
  	return false;
  };
  
  g.clipRect = function(cr,r){
  	// cr: clipping rectangle
  	// r: clipee
  	var res = {
  		x:Math.min(Math.max(cr.x,r.x),cr.x+cr.width),
  		y:Math.min(Math.max(cr.y,r.y),cr.y+cr.height)
  	};
  	
  	res.width = Math.max(0,Math.min(cr.x+cr.width,r.x+r.width)-res.x);
  	res.height= Math.max(0,Math.min(cr.y+cr.height,r.y+r.height)-res.y);

  	return res;
  };

  g.moveRect = function( /*dojox.gfx.Rectangle*/ r, /*dojox.gfx.Point*/ delta ) {
  	return { x: (r.x||0)+delta.x,
		     y: (r.y||0)+delta.y,
		 width: r.width,
		height: r.height };
  };
  
  g.relocateRect = function( /*dojox.gfx.Rectangle*/ r, /*dojox.gfx.Point*/ p ) {
  	return { x: p.x,
		     y: p.y,
		 width: r.width,
		height: r.height };
  };
  
  g.growRect = function( /*dojox.gfx.Rectangle*/ r, /*ibm_ilog.diagram.util.Geometry.Size*/ minSize ) {
  	return { x: r.x,
	         y: r.y,
	     width: Math.max(r.width,minSize.width),
	    height: Math.max(r.height,minSize.height) };
	};

	g.expandRect = function(rect,l,t,r,b) {
		switch(arguments.length) {
		case 2:
			t = r = b = l;
			break;
		case 3:
			b = t;
			r = l;
			break;
		case 5:
			break;
		default:
			ErrorReporter.error("InvalidNumberOfArguments",arguments,2,3,5);
			
			break;
		}
    	return { x: rect.x-l,
		         y: rect.y-t,
		     width: rect.width+l+r,
		    height: rect.height+t+b };
	};
	
	g.printRect = function(r) {
		var f = function (n){ return g._round(n,1); };
		return f(r.width)+" x "+f(r.height)+": ["+f(r.x)+","+f(r.x+r.width)+"] x ["+f(r.y)+","+f(r.y+r.height)+"]";
	};
    
	g.rectEqualSize = function(r1,r2,resolution) {
  	return Math.abs(r1.width - r2.width) < resolution && Math.abs(r1.height - r2.height) < resolution;
  };
  
  g.rectEqualOrigin = function(r1,r2,resolution) {
  	return Math.abs(r1.x - r2.x) < resolution && Math.abs(r1.y - r2.y) < resolution;
  };
  
  g._rangeCenteredOverride = function(result,oldv,newv,x,l) {
  	//
  	//	summary:    	
  	//		Returns new range based on the overriding of a base range with override values from newr.
  	//		Used as a helper function for rectCenteredOverride.
  	//
  	//	tags:
  	//		private
  	//
  	//	description:
  	//		Receives an incomplete range newr and assigns its values to oldr, returning the result. 
  	//		It does not change the original range. The semantics are fairly straighforward except for
  	//		one case: if the newr specifies a new [w] and does not specify the corresponding
  	//		[x], then the resulting rectangle is resized centered, instead of keeping its original 
  	//		location.
  	//
  	//	returns: ibm_ilog.diagram.Rectangle
  	//		The result 
  	//	result: ibm_ilog.diagram.Rectangle
  	//		Where the result will be stored 
  	//	newr: ibm_ilog.diagram.Rectangle
  	//		The incomplete rectangle that holds the new values
  	//	oldr: ibm_ilog.diagram.Rectangle
  	//		The fake asignee it will not be changed
  	//	x:	String
  	//		The name of the attribute representing the range origin
  	//	w:	String
  	//		The name of the attribute representing the range length
  	//
	if( newv[l] === undefined ) {
    	if( newv[x] === undefined ) {
    		result[x]=oldv[x];
    	} else {
  			result[x]=newv[x];
    	}
  		result[l]=oldv[l];
	} else {
    	if( newv[x] === undefined ) {
    		// keeps range center
    		result[x]=oldv[x]-(newv[l]-oldv[l])/2;
			
    		// TODO use pivot instead:
    		//
			//if(!newv.scalePivot)
			//	newv.scalePivot = {};
			//var p = newv.scalePivot[x] = newv.scalePivot[x] || (newv[x]+(newv[l]/2));
			//
			//result[x]= p-(newv[w]/oldv[w])*(p-oldv[x]);

			
    	} else {
  			result[x]=newv[x];
    	}
		result[l]=newv[l];
	}    	
  	return result;
  };
  
  g.rectCenteredOverride = function(oldr,newr) {
  	//
  	//	summary:    	
  	//		Returns new rectangle based on the overriding of a base rectangle with override values from newr.
  	//
  	//	description:
  	//		Receives an incomplete rectangle newr and assigns its values to oldr, returning the result. 
  	//		It does not change the original rectangle. The semantics are fairly straighforward except for
  	//		one case: if the newr specifies a new width or height and does not specify the corresponding
  	//		x or y, then the resulting rectangle is resized centered, instead of keeping its original 
  	//		location.
  	//
  	//	newr:
  	//		The incomplete rectangle that holds the new values
  	//	oldr:
  	//		The fake asignee it will not be changed
  	//
  	var result = newr.scalePivot?{scalePivot:newr.scalePivot}:{};
  	this._rangeCenteredOverride(result,oldr,newr,'y','height');
  	this._rangeCenteredOverride(result,oldr,newr,'x','width');
  	return result;
  };
  
  g.constrainRect = function(r,area,resize) {
  	var w = resize?Math.min(r.width,area.width):r.width;
  	var h = resize?Math.min(r.height,area.height):r.height;
		return {
			x:      Math.max(Math.min(r.x,area.x+area.width-w),area.x),
			y:      Math.max(Math.min(r.y,area.y+area.height-h),area.y),
			width:  w,
			height: h
		};
  };
  
  g.visitMembers = function(obj,visitor) {
  	// probably should be moved to a generic set of utils
	var r = {};
	for( _i in obj ) {
		r[_i]=visitor(obj[_i]);
	}
	return r;
  };
  
  g.getRectRatio = function(r) {
  	return 	r.width/r.height;
  };
  
  g.rectBlend = function(r1,r2,factor) {
	var cx = r1.x + (r2.x - r1.x) * factor;
	var cy = r1.y + (r2.y - r1.y) * factor;
	var cwidth = r1.width + (r2.width - r1.width) * factor;
	var cheight = r1.height + (r2.height - r1.height) * factor;
	return {x:cx,y:cy,width:cwidth,height:cheight};
  };
  
  g.containsPoint = function(r,p) {
  	return r.x<=p.x && r.y<=p.y && p.x<=(r.x+r.width) && p.y<=(r.y+r.height);
  };

  
/*=====
	dojo.declare("ibm_ilog.diagram.util.Geometry.Size", null, {
		// summary:
		//		An object with 'width' and 'height' properties used as argument for various ibm_ilog.diagram.util.Geometry methods.
		
		constructor: function( width, height ) {
			// width: Number
			// height: Number
			this.width = width;
			this.height = height;
		}
	});
=====*/
    
  g.printSize = function(p) {
  	//	p: ibm_ilog.diagram.util.Geometry.Size
  	return "("+p.width+","+p.height+")"
  };

  g.sizeLongestSide = function( /*ibm_ilog.diagram.util.Geometry.Size*/ sz ) {
  	return Math.max(sz.width,sz.height);
  };

  g.visitSize = function( /*Function*/ op, /*ibm_ilog.diagram.util.Geometry.Size*/ size ) {
  	return op(size.width,size.height);
  };

  g.isNullSize = function( /*dojox.gfx.Rectangle*/ r ) {
  	//
  	//	summary:
	//		returns true when r is a "null" rectangle: width and height are 0 or undefined
  	//
      return !r.width && !r.height;
  };

  g.Size = function(width,height) {
  	return {width:width,height:height};
  };

  g.equalSize = function(p1, p2) {
  	//	returns:
  	//		true when the two rects are equal
      return (p1.width === p2.width) &&
         (p1.height === p2.height);
  };
  
  g.floorSize = function( sz ) {
  	return {width:Math.floor(sz.width),height:Math.floor(sz.height)};
  };

  g.mulSize = function(p1, s) {
    return { width: p1.width*s, height: p1.height*s };
  };

  g.Point = function( /*Number*/ x, /*Number*/ y ) {
  	// x: Number
  	// y: Number
  	// returns: dojox.gfx.Point
  	return {x:x,y:y};
  };

  g.floorPoint = function( p ) {
  	// p: dojox.gfx.Point
  	// returns: dojox.gfx.Point
  	return {x:Math.floor(p.x),y:Math.floor(p.y)};
  };
  
  g.printPoint = function(p) {
  	// p: dojox.gfx.Point
  	// returns: dojox.gfx.Point
  	return "("+p.x+","+p.y+")"
  };

  g.InvalidPoint = function() {
  	// returns: dojox.gfx.Point
  	return { x: Number.NEGATIVE_INFINITY, y: Number.POSITIVE_INFINITY };
  };

  g.EmptyPoint = function() {
  	// returns: dojox.gfx.Point
  	return { x: NaN, y: NaN };
  };
  
  g.PointZero = function() {
  	// returns: dojox.gfx.Point
  	return { x: 0, y: 0 };
  };
  
  g.getDistance = function(p1, p2) {
  	// p1: dojox.gfx.Point
  	// p2: dojox.gfx.Point
  	// returns: Number
      var a = p2.x - p1.x;
      var b = p2.y - p1.y;
      return Math.sqrt(a * a + b * b);
  };
  
  g.getPointToSegmentDistance = function(A,B,C){
  	// Summary:
  	//		return the distance between a segment and a point
  	//		A and B are the segment points
  	
  	// special case where A = B
  	if(this.equalPoint(A,B)){
  		return this.getDistance(A,C);
  	}
  	
  	var u = ((C.x-A.x)*(B.x-A.x)+(C.y-A.y)*(B.y-A.y))/(Math.pow(B.x-A.x,2)+Math.pow(B.y-A.y,2));
  	
  	// P is the nearest point of the segment line
  	var P = {};
  	
  	if(u>1){
  		// the point P is over the point B - distance = B-C
  		return this.getDistance(B,C);
  	}else{
  		if(u<0){
  			// the point P is behind the point A - distance = A-C
  			return this.getDistance(A,C);
  		}else{
  			// the point P is in between A and B - distance = C-P
  			P.x = A.x + u * ( B.x - A.x);
  			P.y = A.y + u * ( B.y - A.y);
  			return this.getDistance(P,C);
  		}
  	}
  };
  
  g.isInvalidPoint = function(p) {
  	// p: dojox.gfx.Point
  	// returns: Boolean
      return p.x === Number.NEGATIVE_INFINITY && p.y === Number.POSITIVE_INFINITY;
  };
  
  g.isEmptyPoint = function(p) {
  	// p: dojox.gfx.Point
  	// returns: Boolean
      return isNaN(p.x) && isNaN(p.y);
  };

  g.addPoint = function(p1, p2) {
  	//	p1: dojox.gfx.Point
  	//	p2: dojox.gfx.Point
  	//	returns: dojox.gfx.Point
      return { x: p1.x+p2.x, y: p1.y+p2.y };
  };

  g.subPoint = function(p1, p2) {
  	//	p1: dojox.gfx.Point
  	//	p2: dojox.gfx.Point
  	//	returns: dojox.gfx.Point
      return { x: p1.x-p2.x, y: p1.y-p2.y };
  };

  g.negPoint = function(p) {
  	//	p: dojox.gfx.Point
  	//	returns: dojox.gfx.Point
      return { x: -p.x, y: -p.y };
  };
  
  g.mulPoint = function(p1, s) {
  	//	p: dojox.gfx.Point
  	//	s: Number
  	//	returns: dojox.gfx.Point
      return { x: p1.x*s, y: p1.y*s };
  };

  g.equalPoint = function(p1, p2) {
  	//	p1: dojox.gfx.Point
  	//	p2: dojox.gfx.Point
  	//	returns: Boolean
  	//		true when the two rects are equal
    return (p1.x === p2.x) &&
       (p1.y === p2.y);
  };

//
//	MISCELANEOUS OPERATIONS
//
    
  g.getScale = function(x, y) {
  	//	x: Number
  	//	y: Number
  	//	returns: Number
		if (x === 0) {
		    return y;
		} else if (y === 0) {
		    return x;
		} else {
		    return Math.sqrt(x * x + y * y);
		}
  };
  
  g.getStrokeWidth = function(stroke, t) {
		var w = stroke.width || 1;
		var zoom = Math.min(t.xx, t.yy);
		var realWidth = w * zoom;
		//            if (_minWidth >= 0f && realWidth < _minWidth)
		//                realWidth = _minWidth;
		//            if (_maxWidth >= 0f && realWidth > _maxWidth)
		//                realWidth = _maxWidth;
		w = (zoom === 0) ? 0 : (realWidth / zoom);
		return w;
  };

  g._round = function(value, places) {
		if(NumberUtils && NumberUtils.round)
			return NumberUtils.round(value, places); // Number
		return (+value).toFixed(places)*1; // Number
  };
	
  return g;
});
