define({      
//begin v1.x content
    errorDialogTitle: "IBM BPM-fout",
    moreDetails: "Meer gegevens...",
    closeMessage: "Alle foutberichten sluiten",
    contentMessage: "Er is een fout opgetreden."
//end v1.x content
});

