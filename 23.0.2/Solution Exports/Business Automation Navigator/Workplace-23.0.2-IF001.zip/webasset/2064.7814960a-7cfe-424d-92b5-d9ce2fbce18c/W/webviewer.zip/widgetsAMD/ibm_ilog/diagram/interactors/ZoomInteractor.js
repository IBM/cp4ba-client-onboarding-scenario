/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"../main",
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/sniff",
"./Interactor"
],
function(
iid,
declare,
lang,
has,
Interactor
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var ZoomInteractor =
declare("ibm_ilog.diagram.interactors.ZoomInteractor", [Interactor], {
	//
	//	summary:
	//		A ZoomInteractor controls the process of viewport panning and zooming
	//

	
	//
	//	_viewport: ibm_ilog.diagram.widget.Viewport
	//		The diagram viewport 
	//
	_viewport: null,

	//
	//	_diagram: ibm_ilog.diagram.widget.Diagram
	//		The diagram to pan
	//
	_diagram: null,
	
	//
	//	_incrementFactor: Number
	//		The factor at which the zoom is incremented at each discrete step
	//
	_incrementFactor: 1.5,
	
	_p0X:0,_p0Y:0,_p1X:0,_p1Y:0,

	_startDistance: 0,
	
	_declareStates: function() {
		var idleStates = ["wheelZoom"];
		if (iid.mobileEnabled)
			idleStates.push("touchStart");
		this._declareState("idle",idleStates);
		if (iid.mobileEnabled)
			this._declareState("activeTouch",["touchMove","touchEnd"]);
	},
	
	activate: function() {
		this._goStateId("idle");
	},
	
	setIncrementFactor: function( /*Number*/ factor ) {
		//
		//	summary:
		//		Sets the increment factor for zooming discrete operations
		//
		this._incrementFactor = factor;
	},
	
	getIncrementFactor: function() {
		//
		//	summary:
		//		Returns the increment factor for zooming discrete operations
		//
		return this._incrementFactor;
	},
	
    initialize: function( /*ibm_ilog.diagram.widget.Diagram*/ diagram ) {
		//
		//	summary:
		//		Zoom interactor constructor, based on a target Diagram widget.
		//
		this._diagram = diagram;
		this._viewport = diagram.getViewport();
		this._initialize();
		return this;
	},
    
    getDefaultConnections:function(){
		//
		//	summary:
		//		Returns the default event mapping
		//
    	var defaultConnections = {
    		wheelZoom:{
    			src:this._diagram.domNode,
    			srcEvt:this.eventNameWheel,
    			connectTo:"_wheelZoom",
    			filter:this._buildInputFilter(has("webkit")?{shift:true}:{ctrl:true})}
    	};
    	
		if (iid.mobileEnabled){
			var mobileDefaultConnections = {
				touchStart : {
					src: this._diagram.domNode,
					srcEvt: "ontouchstart",
					connectTo: "_touchStart"
				}, touchMove :{
					src: this._diagram.domNode,
					srcEvt: "ontouchmove",
					connectTo: "_touchMove"
				}, touchEnd: {
					src: this._diagram.domNode,
					srcEvt: "ontouchend",
					connectTo: "_touchEnd"
				}

			};
			lang.mixin(defaultConnections,mobileDefaultConnections);
		};
    	return defaultConnections;
    },
    
    _wheelZoom: function( /*Event*/ e ) {
		//
		//	summary:
		//		Handles the wheel mouse event and dispatchs the appropriate zooming operations
		//

		var v = this._incrementFactor;
		
		if(this.eventWheelAmmount(e)<0) {
			v = 1/v;
		}

		this._zoomAt(this._viewport.eventClientLocation(e),v);

		if (e.preventDefault) {
			e.preventDefault();
		}
		//	TODO: do we need this?
		e.returnValue = false;

    },
    
    _zoomAt: function( /*Point*/ p, /*Number*/z ) {
		//
		//	summary:
		//		Performs a zoom operation maitaining a pivot point p in the same 
    	//		fixed position relative to the viewport.
		//
    	var V = this._viewport;
    	var cp = V.pointClientToContent(p); // content p    	
    	V.zoomAt(cp,z);
    },
    
    _touchStart: function (/*Event*/ e) {
    	e.preventDefault();
    	if (e.touches.length != 2)
    		return false;
    	
    	this._p0X = e.touches[0].pageX;
    	this._p0Y = e.touches[0].pageY;
    	this._p1X = e.touches[1].pageX;
    	this._p1Y = e.touches[1].pageY;
    	
    	this._startDistance = Math.sqrt(Math.pow(this._p1X - this._p0X,2) + Math.pow(this._p1Y - this._p0Y,2));
    	
		this._goStateId("activeTouch");
		
    },
    _touchMove: function (/*Event*/ e) {
    	e.preventDefault();
    	if (e.touches.length < 2)
    		return false;
    	
    	this._p0X = e.touches[0].pageX;
    	this._p0Y = e.touches[0].pageY;
    	this._p1X = e.touches[1].pageX;
    	this._p1Y = e.touches[1].pageY;
    	
    	var distance = Math.sqrt(Math.pow(this._p1X - this._p0X,2) + Math.pow(this._p1Y - this._p0Y,2));
    	var scale = distance / this._startDistance;
    	this._startDistance = distance;
    	
    	var p = {
        		pageX : (this._p0X + this._p1X)/2,
        		pageY : (this._p0Y + this._p1Y)/2
        	};
        	
    	this._zoomAt(this._viewport.eventClientLocation(p),scale);
    	
    },
    _touchEnd: function (/*Event*/ e) {
    	e.preventDefault();
    	if (e.touches.length < 2)
    		this._goStateId("idle");
    	return false;
    	
    }

    
});

return ZoomInteractor;

});
