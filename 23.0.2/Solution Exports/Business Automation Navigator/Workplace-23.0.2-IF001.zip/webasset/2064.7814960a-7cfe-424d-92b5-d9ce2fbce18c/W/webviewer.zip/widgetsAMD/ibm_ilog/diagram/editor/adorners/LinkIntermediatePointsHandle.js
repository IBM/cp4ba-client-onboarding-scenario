/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"../../base",
"../../templating",
"../../adorners/HighlightedHandle",
"../interactors/LinkIntermediatePointsHandleInteractor"
], function(
declare,
iid,
templating,
HighlightedHandle,
LinkIntermediatePointsHandleInteractor
){
	
/*=====
var HighlightedHandle = ibm_ilog.diagram.adorners.HighlightedHandle;
=====*/

	var LinkIntermediatePointsHandle =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.LinkIntermediatePointsHandle',[HighlightedHandle],{
		// Summary:
		//		this class is the handle that manage the link intermediate points. 
		//		Contains the instance of LinkIntermediatePointsHandleInteractor that enables to remove and edit these points.
		
		//
		//	_location: handle position
		//
		_index: null,
		setUp: function(index) {
		// Summary:
		//		sets the handle Intermediate point index
			
			this._index = index;
			this.addInteractor(new LinkIntermediatePointsHandleInteractor().initialize(this));
			return this;
		},
		getIndex: function(){
			// Summary:
			//		returns the index of the adorned link intermediate point
			return this._index;
		},
		changeBindings:function(intermediatePoints){
			// Summary:
			//		modify the handle internal bindings
			var point = intermediatePoints[this._index];
			this.startDTLBatch();
			this.setIntPointPosX(point.x);
			this.setIntPointPosY(point.y);
			this.endDTLBatch();
		}
	}));

	LinkIntermediatePointsHandle.templateId = "LinkIntermediatePointsHandle";
	templating.declareBindableProperty(LinkIntermediatePointsHandle, "intPointPosX", -99999);
	templating.declareBindableProperty(LinkIntermediatePointsHandle, "intPointPosY", -99999);

	return LinkIntermediatePointsHandle;
	
});
