define(["require",
        "dojo/parser",
        "dojo/_base/connect",
        "dijit/_Widget",
        "dijit/_TemplatedMixin",
        "dijit/_WidgetsInTemplateMixin",
        "dijit/_WidgetBase",
        "dijit/registry",
        "dojo/_base/declare",
        "dojo/dom",
        "dojo/dom-class",
        "../model/providers/ModelTypeProviderRegistry",
        "../model/shellstate/ShellStateModel",
        "../control/commands/OpenDocumentCommand",
        "./ViewerContentPane",
        "../../base/errorhandling/WpdLogger",
        "../../base/bootstrap",
        "dijit/layout/StackContainer",
        "dijit/layout/BorderContainer",
        "dijit/layout/ContentPane",
        "dojo/text!./templates/ViewManager.html"],
function(require,
        parser,
        connect,
        _Widget,
        _TemplatedMixin,
        _WidgetsInTemplateMixin,
        _WidgetBase,
        registry,
        declare,
        dom,
        domClass,
        ModelTypeProviderRegistry,
        ShellStateModel,
        OpenDocumentCommand,
        ViewerContentPane,
        WpdLogger,
        WpdBootstrap,
        StackContainer,
        BorderContainer,
        ContentPane,
        template) {

/**
 * ViewManager is used to control the open/close/show/hide/setModel for all viewers 
 */
return declare("com.ibm.bpm.wpd.core.view.ViewManager", [ _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin, StackContainer], {

	// Path to the template
	templateString : template,
	
	widgetsInTemplate : true,
	_subscriptionHandles : null,

	constructor : function(params) {		
		this._subscriptionHandles = [];
	},
	
	postCreate : function() {		
		this._subscriptionHandles.push(connect.subscribe("com.ibm.bpm.wpd.core.model.shellstate.ShellStateModel" + "::" + "_openViewStateModels", this, this.modelChanged));
		this._subscriptionHandles.push(connect.subscribe("com.ibm.bpm.wpd.core.model.shellstate.ShellStateModel" + "::" + "_activeViewStateModel", this, this.modelChanged));
	},
	
	/**
	 * Receives notifications, either via dojo subscription or direct listening at the instance level
	 */
	modelChanged : function(notification) {
	
		if (notification.attributeName == "_openViewStateModels" && notification.changeType == 3){
			//do we want to remove the content pane for it? it is cached now for fast response time
			//TODO Remove some cached content pane (with editor) based on  based on some performance measurement
		}
		else if (notification.attributeName == "_activeViewStateModel"){		
			if(!!notification.newValue){
				try{ 
					this._openViewer(notification.newValue);
				}
				catch(err){
					//1. log error to server, log into debug console,  and show error dialog if it is severe					
					var className = this.declaredClass;
					var methodName = "_openViewer";
					var message = " Catch error when opening viewer of type (" + notification.newValue.type + ")" +
					    ' \n Error Type: ' + err.name +
						' \n Error Message: ' + err.message;
						
					var loadingImg = dom.byId("wpdLoadingImag");
					if (!!loadingImg) {
						loadingImg.style.display = "none";
					}
										
					WpdLogger.logError(className, methodName, message, err.level);
				}
			}
		}
	},

    /**
     * Finds/Creates and shows a viewer for the viewStateModel
     * @param viewStateModel It contains the information to be displayed by the viewer
     */
    _openViewer : function(viewStateModel /* IViewStateModel */) {

		// 1. Hide the current viewer
		var cpToHide = this.selectedChildWidget;					
		if (!!cpToHide && !!cpToHide.viewer) {	
			if(!!domClass.contains(cpToHide.domNode, "bpmPrintShow")){
			    domClass.remove(cpToHide.domNode, "bpmPrintShow");
			}

			cpToHide.viewer.onHide();
		}
			
		// 2. find whether an viewer for this ViewStateModel already exists. This depends on the implementation
		var viewer, viewerCp;
		var viewerCps = this.getChildren();
		var i;
		for (i=0; i<viewerCps.length; i++){
			viewerCp = viewerCps[i];
			//note that the keyId maybe null when view the top level process instance
			if (!!viewerCp.viewStateModel && viewerCp.viewStateModel.type == viewStateModel.type 
					&& viewerCp.viewStateModel.documentId == viewStateModel.documentId 
					&& viewerCp.viewStateModel.keyId == viewStateModel.keyId){
				viewer = viewerCp.viewer;
				console.debug("found for vsm: " + viewStateModel.type + " " + viewStateModel.name);
				
				//we found the cached pane, so the response time here is good. let us use this time for some cleaning up work
				this._removeCachedPanes();
				break;
			}
		}
		
		var newlyCreated = false;
		var docType = viewStateModel.type;		
		var provider = ModelTypeProviderRegistry.getInstance().getDocTypeProvider(docType);
		provider.setViewStateModel(viewStateModel);
		/*3. if a viewer for this ViewStateModel does not exist,  
		 */
		if (!viewer) {			
			
			//if reuse, then find the viewer for this doctype and reuse it if one exist
			if (provider.reuseViewer()){
				for (i=0; i<viewerCps.length; i++){
					viewerCp = viewerCps[i];
					if (!!viewerCp.viewStateModel && viewerCp.viewStateModel.type == viewStateModel.type){
						viewer = viewerCp.viewer;
						break;
					}
				}
			}
			
			if(!!viewer ){			
				viewer.setViewStateModel(viewStateModel);
				viewerCp.viewStateModel = viewStateModel;
			}
			//if not reuse or no existing one, then create one
			else{							
				viewerCp = new ViewerContentPane({ parseOnLoad: false, style: "height:98%;width:900px;"});
				newlyCreated = true;
				var viewerAttachPoint = document.createElement("div");
				viewerAttachPoint.style.height = "100%";
				viewerAttachPoint.style.width = "100%";
				viewerCp.set("content", viewerAttachPoint);
				this.addChild(viewerCp);
				this.selectChild(viewerCp);
				this.resize();	
				viewer = provider.createViewer(viewStateModel, viewerAttachPoint);	
			
				if (viewStateModel.type == 'assetListModel'){
					var self = this;				
					window.setTimeout(function() {
						dom.byId("wpdLoadingImag").style.display = "none";
					},0);
				}
					
				viewerCp.viewStateModel = viewStateModel;
				viewerCp.viewer = viewer;								
			}
		}
		
		// 4 show it in the pane // select the pane for the viewer just opened.		
		if(!newlyCreated){
			this.selectChild(viewerCp);
			this.resize();	
		}

		// 5. ask viewer to show itself
		viewer.onShow();
		if(!domClass.contains(viewerCp.domNode, "bpmPrintShow")){
		    domClass.add(viewerCp.domNode, "bpmPrintShow");
		}
	
	},

	setZoom : function(zoomLevel){
		var cpToZoom = this.selectedChildWidget;					
		if (!!cpToZoom && !!cpToZoom.viewer) {	
//			cpToZoom.viewer.setZoom(zoomLevel);
		}
		var viewer, viewerCp;
		var viewerCps = this.getChildren();
		var i;
		for (i=0; i<viewerCps.length; i++){
			viewerCp = viewerCps[i];
			//note that the keyId maybe null when view the top level process instance
			if (!!viewerCp.viewStateModel) {
				console.log("viewerCp.viewStateModel: ",viewerCp.viewStateModel);
				viewer = viewerCp.viewer;
				viewer.setZoom(zoomLevel);
			}
/*
			if (!!viewerCp.viewStateModel && viewerCp.viewStateModel.type == viewStateModel.type 
					&& viewerCp.viewStateModel.documentId == viewStateModel.documentId 
					&& viewerCp.viewStateModel.keyId == viewStateModel.keyId){
				viewer = viewerCp.viewer;
				console.debug("found for vsm: " + viewStateModel.type + " " + viewStateModel.name);
				
				//we found the cached pane, so the response time here is good. let us use this time for some cleaning up work
				this._removeCachedPanes();
				break;
			}
*/
		}
		
	},

	_removeCachedPanes : function(){
		try{
			//debugger;
			//var viewers =  registry.byId("com.ibm.bpm.wpd.document.bpd.view.BPMNViewer");		
			//var panes =  registry.byId("com.ibm.bpm.wpd.core.view.ViewerContentPane");			
			//console.debug("before: " + viewers.length + " panes: " + panes.length);
			console.debug("before registry.length", registry.length);
			
			 	var viewerCps = this.getChildren();			
				var ssm = ShellStateModel.getInstance();	
				var nodesNumber = this._countNotesNumber(ssm);
				
				//TODO: need to do some performance measurement to get more reasonable numbers
				if (viewerCps.length > 20 ||  nodesNumber > 1000){	
					console.debug("measurement: " + viewerCps.length  + " " + nodesNumber);
					var vsm, i;					
					/*remove one cached pane, using oldest out algorithm. 
					 *of course, not asset list view, nor remove the ones on breadcrumb path
					 */
					for (i=0; i < viewerCps.length; i++){
						vsm = viewerCps[i].viewStateModel;
						if(vsm.type != 'assetListModel'){				
							//first try to find it in the list of openViewStateModels, ie, in the breadcrum
							if(! ssm.findOpenViewStateModelForDocId(vsm.documentId, vsm.keyId)){							
								viewerCp = viewerCps[i];	
								console.debug("remove pane for vsm: " + vsm.type + " " + vsm.name);
								this._removeViewerAndCp(viewerCp);
								ssm.removeCachedViewStateModel(vsm);
							    break;  //remove 1
							}				
						}			
					}
			    }		
				//viewers =  registry.byId("com.ibm.bpm.wpd.document.bpd.view.BPMNViewer");		
				//panes =  registry.byId("com.ibm.bpm.wpd.core.view.ViewerContentPane");
				//console.debug("after: " + viewers.length + " panes: " + panes.length);	
				console.debug("before registry.length", registry.length);
		}
		catch(err){
			var className = this.declaredClass;
			var methodName = "_removeCachedPanes";
			var message = " Catch error when remove cached viewers" +
			    ' \n Error Type: ' + err.name +
				' \n Error Message: ' + err.message;
			WpdLogger.logError(className, methodName, message, err.level);
		}	
	},
	
	_countNotesNumber : function(ssm){
		var i;
		var count=0;
		var dm;
		var vm;
		for (i=0; i<ssm._cachedViewStateModels.length; i++){
			if( !!ssm._cachedViewStateModels[i].getDocumentModel && !! ssm._cachedViewStateModels[i].getDocumentModel() &&  !!ssm._cachedViewStateModels[i].getDocumentModel()["items"]){
				count += ssm._cachedViewStateModels[i].getDocumentModel()["items"].length;
			}
		}
		return count;
	},
	
	_removeViewerAndCp : function (cp){
		var viewer = cp.viewer;
		//debugger;
		try{
			this.removeChild(cp);
			cp.destroyRecursive();			
		}
		catch(err){
		    throw {
		    		name : err.name,
		    		message: "Error when destroy viewer and its content pane: " + viewer.declaredClass
		    };
		}
	},
	
	destroyFlashPlayer : function (){
		var viewerCps = this.getChildren();
		for (i=0; i<viewerCps.length; i++){
			viewerCp = viewerCps[i];	
			viewer = viewerCp.viewer;
			if (!! viewer && viewer["destroyFlashPlayer"]){
				viewer.destroyFlashPlayer();
			}
		}
	}, 
	
	
	/**
	 * Destroy the widget
	 */
	destroy : function() {
		for ( var i = 0; i < this._subscriptionHandles.length; i++) {
			if(!!this._subscriptionHandles[i]){
				connect.unsubscribe(this._subscriptionHandles[i]);
			}
		}
		this.inherited(arguments);
		WpdBootstrap.cleanUpWebViewerGlobal();
	}
});

});
