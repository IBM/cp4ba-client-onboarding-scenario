/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/connect",
"dojo/dnd/Target",
"dojo/dnd/Manager",
"../EditingUtils"
], function(
declare,
lang,
connect,
Target,
Manager,
eu
){

var DropInteractor =
declare("ibm_ilog.diagram.editor.interactors.DropInteractor",[], {
	//
	//	summary:
	//		this interactor manage the drop actions on the DiagramEditor. For Simplicity,
	//		this interactor relies on dojo.dnd.manager() to manage all this behavior with a
	//		standard dojo method.
	//
	_diagram: null,
	_droppedItem: null,
	_connectorHandle: null,
	_dropable: null,
	_acceptedTypes:{},
	_onDropFunction: null,
	_onDropTemplateFunction: null,
	
	constructor: function(diagram,onDropFunction,onDropTemplateFunction){
		// Summary:
		//		Creates a new instance of dojo.dnd.Target associated to the diagram DOM node.
		//		Also sets the diagram, the onDropFunction and the onDropTemplateFunction
		this._diagram = diagram;
		this._dropable = new Target(this._diagram.domNode, {accept: []});
		this._dropable.onDrop = lang.hitch(this,this._onDropNode);
		this.setOnDropFunction(onDropFunction);
		this.setOnDropTemplateFunction(onDropTemplateFunction);
	},
	activate: function(){
		// Summary:
		//		connects this class to the dojo.dnd.manager() onMouseUp function, to catch the event point.
		//		Sets the accepted types
		this._connectorHandle = connect.connect( Manager.manager(),"onMouseUp",this,"_onMouseUpManager");
		this._dropable.accept = this._acceptedTypes;
		
	},
	deactivate: function(){
		// Summary:
		//		disconnects this class to the dojo.dnd.manager() onMouseUp function.
		//		Sets the accepted types to empty, to avoid any drop action
		connect.disconnect(this._connectorHandle);
		this._dropable.accept = {};
	},
	isDropAction: function(){
		// Summary:
		//		return if a drop action is taking place
		return this._droppedItem != null;
	},
	setAcceptedTypes: function(types /*array*/){
		// Summary:
		//		sets the accepted types to be used in the Target element.
		//		The change take place when reactivating this class
		this._acceptedTypes = {};
			for(var i = 0; i < types.length; ++i){
				this._acceptedTypes[types[i]] = 1;
			}
	},
	setOnDropFunction: function(onDropFunction){
		// Summary:
		//		sets the onDropFunction. This function is called when a drop action occurs.
		this._onDropFunction = onDropFunction;
	},
	setOnDropTemplateFunction: function(onDropTemplateFunction){
		// Summary:
		//		sets the onDropTemplateFunction. This function is called to resolve the template when a drop action is taking place.
		this._onDropTemplateFunction = onDropTemplateFunction;
	},
	resolveNodeTemplate: function(dataItem){
		// Summary:
		//		called the onDropTemplateFunction with the given item, and the dropped item
		return this._onDropTemplateFunction?this._onDropTemplateFunction.call(null,this._droppedItem,dataItem,this._diagram):null;
	},
	setDroppedItem: function(droppedItem){
		this._droppedItem = droppedItem;
	},
	_onDropNode: function(source, nodes, copy){
		// Summary:
		//		function called when Target.onDrop is called
		//		Override that method
		this._droppedItem = source.getItem(nodes[0].id);
	},
	_onMouseUpManager: function(e){
		// Summary:
		//		function called when dojo.dnd.manager() "onMouseUp" is called
		//		In this method, the onDropFunction is called
		if(this.isDropAction()){
			var D = this._diagram;
			var V = D.getViewport();
			var GR = D.getGraph();
			var p = V.eventContentLocation(e);
			var elements = D.getGraph().hitTest(p);
			eu.startDropAction(this._droppedItem,p,D,elements,eu.createOnDropAction(D,this._droppedItem,p,elements));
			this._droppedItem = null;
		}
	},
	
	getDiagram: function(){
		return this._diagram;
	}
});

return DropInteractor;

});
