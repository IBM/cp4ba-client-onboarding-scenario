define({      
//begin v1.x content
    errorDialogTitle: "IBM BPM-fel",
    moreDetails: "Mer information...",
    closeMessage: "Stäng alla felmeddelanden",
    contentMessage: "Ett fel har inträffat."
//end v1.x content
});

