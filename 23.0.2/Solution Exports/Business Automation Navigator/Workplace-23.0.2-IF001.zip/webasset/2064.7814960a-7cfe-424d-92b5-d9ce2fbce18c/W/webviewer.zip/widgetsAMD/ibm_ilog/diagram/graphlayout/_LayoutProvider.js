/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"ibm_ilog/graphlayout/DefaultLayoutProvider",
"ibm_ilog/graphlayout/MultipleLayout",
"ibm_ilog/graphlayout/internalutil/TranslateUtil"
],
function(
declare,
DefaultLayoutProvider,
MultipleLayout,
TranslateUtil
){
	
/*=====
var DefaultLayoutProvider = ibm_ilog.graphlayout.DefaultLayoutProvider;
=====*/

var _LayoutProvider =
declare("ibm_ilog.diagram.graphlayout._LayoutProvider", DefaultLayoutProvider, {
	// summary:
	//		The layout provider that determines the layout to perform for each graph or subgraph.
	// tags:
	//		private

	constructor: function(graph){
		this._graph = graph;
	},
	
	getGraphLayout: function(graphModel){
	
		// Did we already create a layout for this container?
		// If yes, reuse it. This means that, whenever the layout must be
		// recreated (for example, because a property of the toplevel layout
		// is modified), we must clear all the layouts allocated by this provider
		// so that they are recreated next time. This is done by the refreshSubLayouts()
		// method.
		//
		var ml = this.getPreferredLayout(graphModel);
		if (ml) 
			return ml;
		
		// OK, no layout to reuse: create a new one, which must be a MultipleLayout
		// whose first layout is the GraphLayout property of this container or one
		// of its ancestors, and the second layout is the LinkLayout property.
		//
		// We determine which graph/link layout to use by looking
		// up the container hierarchy, and take the first non-null GraphLayout/LinkLayout
		// property.
		//
		var nodeLayout = null;
		var linkLayout = null;
		var nodeLayoutActive = true;
		var linkLayoutActive = true;
		
		var adapter;
		
		for (var adapter = graphModel; adapter != null; adapter = adapter.getParent()) {
		
			var graph = adapter.getGraph();
			
			// The Graph/LinkLayout is active iff the Graph/LinkLayoutActive
			// flag is true for all ancestors.
			//
			if (!graph._nodeLayoutActive) 
				nodeLayoutActive = false;
			if (!graph._linkLayoutActive) 
				linkLayoutActive = false;
			
			// Take the first non-null Graph/LinkLayout up in the hierarchy.
			//
			if (!nodeLayout && graph._nodeLayout) 
				nodeLayout = graph._nodeLayout;
			if (!linkLayout && graph._linkLayout) 
				linkLayout = graph._linkLayout;
			if (graph == this._graph) 
				break;
		}
		
		// We must copy the layouts for sub-graphs, but not for the container
		// that owns them, because the layout holds the node/link extended properties.
		//
		var copy = graphModel == null || graphModel._graph != this._graph;
		if (copy) {
			if (nodeLayout) 
				nodeLayout = nodeLayout.copy();
			if (linkLayout) 
				linkLayout = linkLayout.copy();
		}
		
		// Create and attach the MultipleLayout. This will attach the first and second layouts
		// automatically.
		//
		ml = new MultipleLayout(nodeLayout, linkLayout);
		
		var data = TranslateUtil.GraphModelData.getData(graphModel);
		data.setInternalGraphModelChecking(false);
		ml.attach(graphModel);
		this.setPreferredLayout(graphModel, ml);
		data.setInternalGraphModelChecking(false);
		ml.setFirstGraphLayoutActive(nodeLayoutActive);
		ml.setSecondGraphLayoutActive(linkLayoutActive);
		
		return ml;
	}
});

return _LayoutProvider;

});
