/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare"
], function(
declare
){
	
	var Action =
	declare("ibm_ilog.diagram.editor.undo.Action", [], {
		//
		//	summary:
		//		this is the base Undo action. This contains the base components to apply all undo/redo actions on the UndoManager.
		//		Any Undo Action should inherit from this class
		_undoFunction:null,
		_redoFunction: null,
		_label: null,
		_undoManager: null,
		_isRedoing: null,
		_isUndoing: null,
		
	constructor:function(label){
		//
		//	summary:
		//		creates a new instance, setting up the label	
		//
		this._label = label;
		this._isRedoing = false;
		this._isUndoing = false;
	},
		
	initialize: function(undoFunction,redoFunction){
		//
		//	summary:
		//		initialize the action, by setting the undo and redo functions
		this._undoFunction = undoFunction;
		this._redoFunction = redoFunction;
	},
	
	undo: function(){
		//
		//	summary:
		//		call the undo function
		this._isUndoing = true;
		if(this._undoFunction){
			this._undoFunction();
		}
		this._isUndoing = false;
	},
	
	redo: function(){
		//
		//	summary:
		//		call the redo function
		this._isRedoing = true;
		if(this._redoFunction){
			this._redoFunction();
		}
		this._isRedoing = false;
	},
	
	getLabel: function(){
		//
		//	summary:
		//		return the label. This should be used to be shown in the UI
		return this._label;
	},
	setLabel: function(label){
		//
		//	summary:
		//		sets the label that should be used to be shown in the UI
		this._label = label;
	},
	setUndoManager: function(undoManager){
		//
		//	summary:
		//		Sets the undo Manager
		this._undoManager = undoManager;
	},
	
	getUndoManager: function(){
		//
		//	summary:
		//		Gets the undo Manager. The UndoManager is set in the Action automatically when it is added to the undo stack
		return this._undoManager;
	},
	
	isUndoing: function(){
		//
		//	summary:
		//		return true if the action is executing an undo action
		return this._isUndoing;
	},
	
	isRedoing: function(){
		//
		//	summary:
		//		return true if the action is executing a redo action
		return this._isRedoing;
	}
	});
	
	return Action;
	
});
