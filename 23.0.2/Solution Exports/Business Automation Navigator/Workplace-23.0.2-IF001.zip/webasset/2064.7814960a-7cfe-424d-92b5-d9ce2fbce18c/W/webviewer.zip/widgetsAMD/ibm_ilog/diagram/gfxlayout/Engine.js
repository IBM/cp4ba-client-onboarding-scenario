/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/array", "./_base", "../util/Batch"],
function(array, gfxlayout, Batch){

//
// public interface to the layout engine singleton.
//

gfxlayout.postInvalidate = function(/*dojox.gfx.Group*/obj) {
    // summary:
    //     Posts an asynchronous validation request for the specified Panel.
    gfxlayout.Engine.invalidate(/*dojox.gfx.Shape*/obj);
};

gfxlayout.doPendingValidate=function(/*dojox.gfx.Group*/obj){
    // summary:
    //     Processes immediately any validation request registered for the specified panel.
    gfxlayout.Engine.doPendingValidate(obj);
};

//
// Layout engine (Singleton).
// 
gfxlayout.Engine = (function() {
    // the singleton instance
    var instance = null;
    
    function Ctor() {
        
        // the validation requests queue
        var _queue = [];
        
        // Posts an asynchronous validation request for the specified shape.
        this.invalidate = function(/*dojox.gfx.Shape*/obj) {
            
            // ensures the shape is in the hierarchy
            if (this._isOrphan(obj)) {
                return;
            }
            // find the top-level parent
            var topPnl = obj;
            while (topPnl.getParent() &&
                   topPnl.getParent().getLayout &&
                   topPnl.getParent().getLayout()) {
                topPnl = topPnl.getParent();
            }
            // no -panel- found (ie Group with a layout mgr)
            if (!topPnl.getLayout || !topPnl.getLayout()) {
                return;
            }
            // invalidate() invoked during the layout process ?
            if (topPnl.getLayout().inLayout()) 
                return;
            // if the top panel found is already in the pending queue,
            // do nothing
            if (array.some(_queue, function(item) {
                if (item === topPnl) 
                    return true; // stop loop
                })) {
                return; // already in the queue, do nothing
            }
            // add it to the pending validation queue
            _queue.push(topPnl);
            // add a layout() request to the Batch
            Batch.add(this);
        };
        
        // Processes immediately the validation requests registered for the specified shape.
        this.doPendingValidate=function(/*dojox.gfx.Shape*/obj){
            var topPnl = obj;
            while (topPnl.getParent() &&
                   topPnl.getParent().getLayout()) {
                topPnl = topPnl.getParent();
            }
            if (topPnl && topPnl.getLayout()){
                if (topPnl.getLayout().inLayout()) 
                    return;
                // look up the panel in the queue
                var ql = _queue.length;
				for (var i=0;i<ql;++i){
                    if (_queue[i] === topPnl) {
                        _queue[i] = null;
                        // Layout it
                        this._layout(topPnl);
                        break;
                    }
                }
            }            
        };
        
        // Invoked by the Batch to trigger the pending layout() request
        this._endBatch = function() {
            this.layout();
        };
        
        this.layout = function() {
            // init a new pending queue
            var queue = _queue;
            _queue = [];
			var fl = this._layout;
            var ql = queue.length;
            for (var i = 0; i < ql; ++i) {
                var panel = queue[i];
                if (!panel) // may have been removed by a doPendingValidate()
                    continue;
                fl.call(this, panel);
            }
        };
        
        this._layout = function(/*dojox.gfx.Group*/panel){
            //console.log("Engine layout");
            // is it still in the hierarchy ? may have been removed since then
            if (this._isOrphan(panel)) {
                return;
            }
            // get the explicit size of the top level panel to validate.
            // by default it's w=-1 (auto) and h=-1 (auto)
            var size = panel.getExplicitSize();
            // computes children size
            size = panel.computePreferredSize(size);
            // layout the panel
            panel.layout({x:0, y:0, width:size.width, height:size.height});
        };
        
        this._isOrphan = function(shape){
            // a Surface does not have getParent() method.
            for (var p = shape.getParent();p && p.getParent; p=p.getParent()){
            }
            return p === null;
        };
        
    };
    
    return new function() {
        if (instance == null) {
            instance = new Ctor();
            instance.constructor = null;
        }
        return instance;
    };
})();

	return gfxlayout;
	
});
