/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"../main",
"dojo/_base/declare",
"dojo/_base/array",
"./AdornerHandle",
"../util/HandleSet"
],
function(
iid,
declare,
array,
AdornerHandle,
HandleSet
){

/*=====
var HandleSet = ibm_ilog.diagram.util.HandleSet;
var AdornerHandle = ibm_ilog.diagram.adorners.AdornerHandle;
=====*/

var gfxCon = HandleSet.gfxConnector;
var gfxDis = HandleSet.gfxDisconnector;
	
var HighlightedHandle =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.adorners.HighlightedHandle', [AdornerHandle, HandleSet],{
		
		_interactors: null,
		
		_state: "",
		
		_hovered: false,
		
		_active: false,
		
		constructor: function(){
			this._interactors = [];
		},
		
		initialize: function(adorner,template) {
			this._adorner = adorner;
			this._template = template;
			this.applyTemplate(this._template);
			
			this.remove(this.stNormal);
			this.remove(this.stHighlighted);
			this.remove(this.stActive);
			
			this._active = false;
			this._hovered = false;
			
			this.refreshState();
		},

		interactionBegun: function(interactor) {
			this._active = true;
			this.refreshState();
		},

		interactionEnded: function(interactor) {
			this._active = false;
			this.refreshState();
		},

		changeState: function(stId) {
			if(this._state !== stId) {
				if(this[this._state])
					this.remove(this[this._state]);
				//console.log(stId)
				this._state = stId;
				if(this[this._state])
					this.add(this[this._state]);
			}
		},
		
		addInteractor: function(interactor){
			this._interactors.push(interactor);
			interactor.setManager(this._adorner._diagram._interactors);
		},

		refreshState: function() {
			if(this._active) {
				this.changeState("stActive");
			} else {
				if(this._hovered) {
					this.changeState("stHighlighted");
				} else {
					this.changeState("stNormal");
				}
			}
		},

		onMouseOver: function(){
			this._hovered = true;
			this.refreshState();
		},
		
		onMouseOut: function(){
			this._hovered = false;
			this.refreshState();
		},		
		
		activate:function() {
			this._active = false;
			this._hovered = false;
			this.changeState("stNormal");
			array.forEach(this._interactors,function(item){item.activate();});
			this._connect("hoverStart",this,"onmouseover",this,"onMouseOver",gfxCon,gfxDis);
			this._connect("hoverEnd",this,"onmouseout",this,"onMouseOut",gfxCon,gfxDis);
		},
		
		deactivate:function() {
			array.forEach(this._interactors,function(item){item.deactivate();});
			this.changeState("");
			this._disconnect("hoverStart");
			this._disconnect("hoverEnd");
		}
	}));
	
	/* This must be added in each class that implements this class
	 * 
	 * HighlightedHandle.templateId = "TemplateName";
	 */

return HighlightedHandle;

});
