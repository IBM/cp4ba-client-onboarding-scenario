/**
 * Reimplementation of the ILog LinkAdorner to provide bindable linkCenterX, linkCenterY,
 * linkCenteredX and linkCenteredY properties. The purpose is to allow the placement of a shape (or
 * shapes) on the link.
 * 
 */
define([
   "ibm_ilog/diagram/main",
   "dojo/_base/declare",
   "dojo/_base/lang",
   "dojo/_base/array",
   "dojo/_base/connect",
   "dojo/_base/event",
   "dojox/gfx",
   "ibm_ilog/diagram/templating",
   "ibm_ilog/diagram/adorners/TemplatedOverlay",
   "ibm_ilog/diagram/adorners/Adorner",
   "ibm_ilog/diagram/adorners/AdornerWithHandles",
   "ibm_ilog/diagram/util/Geometry",
   "ibm_ilog/diagram/util/ErrorReporter"
], function(iid, declare, lang, array, connect, event, gfx, templating, TemplatedOverlay, Adorner, AdornerWithHandles, g, R) {

   /*
    * ===== var AdornerWithHandles = ibm_ilog.diagram.adorners.AdornerWithHandles; =====
    */

   var par = Adorner.prototype;

   var CenteredILogLinkAdorner = iid.gfxDeclaration(declare('ibm_ilog.diagram.adorners.CenteredILogLinkAdorner', [
      AdornerWithHandles
   ], {
      //
      // summary:
      // A UI overlay associated with a link graph entity.
      //
      // description:
      // The LinkAdorner object provides a graphical decoration for a
      // link graph entity. See Adorner for further
      //
      _elementPath : null,
      _echoConnections : null,

      // The Adorner can set the bindable properties appropriately depending on the
      // shape that will be placed on the link.
      centeredElementWidth : null,
      centeredElementHeight : null,

      initialize : function(diagram, templatePool, templateId) {
         // Summary:
         // initialize the adorner. Adds some mouse listeners to mouseup and mousedownto push the
         // events to the links
         this.inherited(arguments);
         this._echoConnect();
      },

      _buildEchoConnection : function(eventName) {
         try {
            this._echoConnections.push(this._path.connect(eventName, this, 'echoEvent'));
         } catch (e) {
            R.warn("EventConnectionFailed", eventName);
         }
      },

      _echoConnect : function() {
         if (this._echoConnections) {
            array.forEach(this._echoConnections, function(conn) {
               connect.disconnect(conn);
            });
         }
         this._echoConnections = [];
         if (this['_path']) {
            this._buildEchoConnection('onmousedown');
            this._buildEchoConnection('onmouseup');
            this._buildEchoConnection('onclick');
            this._buildEchoConnection('oncontextmenu');
         }
      },

      echoEvent : function(e) {
         // Summary:
         // Push the recieved event to the binded link
         if (e.initMouseEvent) { // Firefox, Google Chrome, Safari, Opera
            var evt = document.createEvent('MouseEvents');
            evt.initMouseEvent(e.type, e.bubbles, e.cancelable, e.view, e.detail, e.screenX, e.screenY, e.clientX, e.clientY, e.ctrlKey, e.altKey,
               e.shiftKey, e.metaKey, e.button, e.relatedTarget);
            this.getAdorned().rawNode.dispatchEvent(evt);
         } else {
            if (document.createEventObject) { // Internet Explorer
               var mouseEvent = document.createEventObject(e);
               mouseEvent.button = e.button;
               this.getAdorned().rawNode.fireEvent('on' + e.type, mouseEvent);
            }
         }
         event.stop(e);
      },

      _reconnectNotifications : function() {
         //
         // summary:
         // Reconnect to change notifications related to the bound element.
         //
         this.inherited(arguments);
         var e = this._adorned;
         if (e) {
            this._changeConnections.push(connect.connect(e, "_updatePath", this, "_elementBoundsChanged"));
         }
      },

      _setFallbackBounds : function() {
         this._elementPath = [
            {
               x : iid._invisibleLocation,
               y : iid._invisibleLocation
            }, {
               x : iid._invisibleLocation,
               y : iid._invisibleLocation
            }
         ]; // by default construct adorner out of sight
         par._setFallbackBounds.apply(this, arguments);
      },

      _computeElementBoundsChanged : function() {
         //
         // summary:
         // gets the Element Path from the bounded element
         //
         if (this._required()) {
            this._elementPath = this._adorned._pathPoints;
         }
         par._computeElementBoundsChanged.apply(this, arguments);
      },

      _updateLayout : function() {

         this.startDTLBatch();
         this.inherited(arguments);
         var path = lang.clone(this._elementPath);
         if (this._required()) {
            var v = this._viewport, z = v.getZoom(), vr = v.getViewRect();
            var t = this._adorned.getShapeToContainerTransform(this._diagram.getGraph().getParent());
            // Changed from base since we may want to look at all paths
            for ( var i = 0; i < path.length; i++) {
               path[i] = t.transformPoint(path[i]);
               path[i] = g.moveRect(path[i], g.negPoint(vr));
               path[i].x = path[i].x * z;
               path[i].y = path[i].y * z;
            }

            /*
             * path[0] = t.transformPoint(path[0]); path[0] = g.moveRect(path[0], g.negPoint(vr));
             * path[0].x = path[0].x * z; path[0].y = path[0].y * z;
             * 
             * path[path.length - 1] = t.transformPoint(path[path.length - 1]); path[path.length -
             * 1] = g.moveRect(path[path.length - 1], g.negPoint(vr)); path[path.length - 1].x =
             * path[path.length - 1].x * z; path[path.length - 1].y = path[path.length - 1].y * z;
             */
         }
         
         this.setLinkStartX(path[0].x);
         this.setLinkStartY(path[0].y);
         this.setLinkEndX(path[path.length - 1].x);
         this.setLinkEndY(path[path.length - 1].y);
         // Find the center point taking into consideration the widht and height
         // of the element that we want to center.
         var numPaths = path.length;
         var pe1Idx = Math.ceil(numPaths/2)-1;
         var pe1 = path[pe1Idx];
         var pe2 = path[pe1Idx+1];
         this.setLinkCenterX(pe1.x + ((pe2.x - pe1.x) / 2));
         this.setLinkCenterY(pe1.y + ((pe2.y - pe1.y) / 2));
         var zoom = this._viewport.getZoom();
         if (this.centeredElementWidth && this.centeredElementHeight) {
            this.setLinkCenteredX(this.getLinkCenterX() - (Math.round(this.centeredElementWidth * zoom) / 2));
            this.setLinkCenteredY(this.getLinkCenterY() - (Math.round(this.centeredElementHeight * zoom) / 2));
         } else {
            this.setLinkCenteredX(this.getLinkCenterX());
            this.setLinkCenteredY(this.getLinkCenterY());
         }
         this.setZoom(zoom);
         this.endDTLBatch();

         // update path
         if (this['_path'] != undefined) {
            if (this.getAdorned() != null) {
               var transformationFunction = lang.hitch(this, function(point, list) {
                  var v = this._viewport, z = v.getZoom(), vr = v.getViewRect();
                  var t = this._adorned.getShapeToContainerTransform(v._diagram.getGraph().getParent());
                  point = t.transformPoint(point);
                  point = g.moveRect(point, g.negPoint(vr));
                  point.x = point.x * z;
                  point.y = point.y * z;
                  return point;
               });
               var curveTension = this.getAdorned().getCurveTension();
               this._updatePathShape(curveTension);
               var points = array.map(this.getAdorned()._pathPoints, transformationFunction);
               this.getAdorned().applyPath(this._path, points, curveTension);
            } else {
               if (this._path instanceof gfx.Polyline) {
                  this._path.setShape(path);
                  this._path.bbox = null; // patch for GFX bug...
               } else {
                  this._path.setShape("");
               }
            }
         }
      },

      _updatePathShape : function(curveTension) {
         if (curveTension > 0 && !(this._path instanceof gfx.Path)) {
            var stroke, selectedStyle, parent;
            if (this._path) {
               stroke = this._path.getStroke();
               parent = this._path.getParent();
               this._path.removeShape();
            }
            this._path = (parent || this).createPath();
            this._echoConnect();
            if (stroke)
               this._path.setStroke(stroke);
         }
      }

   }));

   templating.declareBindableProperty(CenteredILogLinkAdorner, "linkStartX", null);
   templating.declareBindableProperty(CenteredILogLinkAdorner, "linkStartY", null);
   templating.declareBindableProperty(CenteredILogLinkAdorner, "linkCenterX", null);
   templating.declareBindableProperty(CenteredILogLinkAdorner, "linkCenterY", null);
   templating.declareBindableProperty(CenteredILogLinkAdorner, "linkCenteredX", null);
   templating.declareBindableProperty(CenteredILogLinkAdorner, "linkCenteredY", null);
   templating.declareBindableProperty(CenteredILogLinkAdorner, "linkEndX", null);
   templating.declareBindableProperty(CenteredILogLinkAdorner, "linkEndY", null);
   templating.declareBindableProperty(CenteredILogLinkAdorner, "zoom", null);

   return CenteredILogLinkAdorner;

});
