/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/lang", "dojo/has", "dojox/gfx", "dojox/gfx/shape", "dojox/gfx/matrix", "../util/Geometry"],
function(lang, has, gfx, shape, matrix, geom){

	// TODO:
	// For now we must create a global object since there are still references to ibm_ilog.diagram._base.gfxext
	// in the rest of the code, but when AMD migration is finished all global references should be replaced
	// by module references and this will be replaced by a simple object creation:
	// var de = {};
	var de = lang.getObject("ibm_ilog.diagram._base.diagext", true);
	
    //
	// Add transform functions to all shapes:
	//
	lang.extend(shape.Shape, {
		// summary:
		//		Provides additional methods on GFX shapes to compute transforms.
		// tags:
		//		private
		
		getTransformToContainer: function(/*dojox.gfx.Group*/container){
			// summary:
			//        Gets the transform from the parent coordinate system
			//        to the specified container coordinate system.
			// container: dojox.gfx.Group:
			//        the target container.
			
			if (container === null) {
				//TODO: ErrorReporter
				throw {
					'name': 'ArgumentNullException',
					message: "Null parameter: container"
				};
			}
			var m = matrix;
			if (container === this) {
				return m.identity;
			}
			var t1 = m.identity;
			// does not take into account shape transform
			var p = this.getParent();
			// TODO: no need to go up till the surface. Should stop to 
			// 1st common ancestor. check perf gain ?
			if (p !== null) {
				t1 = p._getRealMatrix() || m.identity;
			}
			var t2 = container._getRealMatrix() || m.identity;
			var t = m.multiply(t2.inverse(), t1);
			return t;
		},
		
		getShapeToContainerTransform: function(container){
			// summary:
			//        Gets the transform from this shape coordinate system
			//        to the specified container coordinate system.
			// description:
			//        This method takes into account the shape transform.
			// container: dojox.gfx.Group:
			//        the target container.
			if (container === null) {
				//TODO: ErrorReporter
				throw {
					'name': 'ArgumentNullException',
					message: "Null parameter: container"
				};
			}
			var m = matrix;
			if (container === this) {
				return m.identity;
			}
			// TODO: no need to go up till the surface. Should stop to 
			// 1st common ancestor. check perf gain ? 
			// t1: transform from surface -> shape
			var t1 = this._getRealMatrix() || m.identity;
			// t2: transform from surface -> container
			var t2 = container._getRealMatrix() || m.identity;
			return m.multiply(t2.inverse(), t1);
		}
	});
	
	//
	// BoundingBox fix
	//
	
	var eq = geom.equalRect;
	
	de.BoundingBoxFix = {
		// summary:
		//		Fixes/provides additional methods on GFX groups for bounding box computations.
		// tags:
		//		private
		
		_computeBoundingBox: function(){
			var bb = null;
			var cs = this.children;
			var ncs = this.children.length;
			var c;
			for (var i = 0; i < ncs; ++i) {
				var c = cs[i];
				var cbb = c.getBoundingBox();
				if (!cbb) {
					continue;
				}
				var ct = c.getTransform();
				if (ct && !ct.isIdentity()) {
					cbb = ct.transformRectangle(cbb);
				}
				bb = bb ? geom.addRect(bb, cbb) : cbb;
			}
			
			this._bbCache = bb;
			if (bb) {
				var t = this.getTransform() || matrix.identity;
				if (t) 
					bb = t.transformRectangle(bb);
			}
			this._lbbCache = bb;
		},
		
		_prepareBoundingBoxCache: function(){
			var oldbb = this._bbCache;
			var oldlbb = this._lbbCache;
			
			if (!oldbb || !this._bbCacheValid) {
				this._computeBoundingBox();
				this._bbCacheValid = true;
			}
		},
		
		getBoundingBox: function(){
			// summary:
			//        Gets the bounding box of this dojox.gfx.Group. Returns null if the group is empty.
			// description:
			//        This method returns the global children bounding box without
			//        taken into account the transform of this Group.
			this._prepareBoundingBoxCache();
			
			return this._bbCache;
		},
		
		_onChanged: function(source, reason){
			this._bbCacheValid = false;
			// 	[av]
			// 	this method became an "inlined inherited" at:
			//	- Node.js
			//	- Graph.js
		},
		
		getLocalBoundingBox: function(){
			// summary:
			//        Gets the bounding box of this dojox.gfx.Group in the local coordinate system.
			// description:
			//        This method returns the global children bounding box 
			//        taken into account the transform of this Group.        
			this._prepareBoundingBoxCache();
			
			return this._lbbCache;
		}
	};
	
	lang.extend(gfx.Group, de.BoundingBoxFix);
	
	return de;
});
