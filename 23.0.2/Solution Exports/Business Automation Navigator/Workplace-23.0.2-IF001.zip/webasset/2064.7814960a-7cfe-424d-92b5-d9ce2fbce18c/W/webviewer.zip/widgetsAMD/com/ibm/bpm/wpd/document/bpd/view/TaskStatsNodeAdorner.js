/**
 * An adorner that specifies statistics about an activity. The statistics are the number of
 * activities that are OK, at risk and critical. The stats are presented in a rounded, shaded
 * rectangle below the activity. The counts can be "clicked" and an event will be thrown.
 */

define([
   "dojo/_base/declare",
   "dojo/_base/lang",
   "dojo/_base/event",
   "dojo/_base/Color",
   "dojo/string",
   "dojox/gfx/_base",
   "dijit/Tooltip",
   "dojox/collections/Dictionary",
   "dojo/i18n!./nls/BPDViewerResources",
   "./ComponentILogAdorner",
   "./TemplatedAdorner",
   "./adornerConstants",
   "com.ibm.bpm.wpd/base/bootstrap",
   "./ilogDiagramUtils"
], function(
   declare,
   lang,
   event,
   Color,
   string,
   gfx,
   Tooltip,
   Dictionary,
   nls,
   ComponentILogAdorner,
   TemplatedAdorner,
   adornerConstants,
   bootstrap,
   ilogDiagramUtils) {
   return declare([
      TemplatedAdorner
   ], {

      atRiskCount : null,
      criticalCount : null,
      okCount : null,
      selected : null,
      baseTemplate : null,
      previousZoom : null,
      groupBaseXOffset : null,
      groupBaseYOffset : null,
      mode : null,

      MODE_VERT : "MODE_VERT",
      MODE_HORZ : "MODE_HORZ",
      MODE_AUTO : "MODE_AUTO",

      TEXT_WIDTHS : [
         0, 18, 22, 30, 38
      ],

      HIGHLIGHT_COLOR : [
         222, 232, 238
      ],

      UN_HIGHLIGHT_COLOR : [
         0, 0, 0, 0.0
      ],

      SELECTED_COLOR : [
         27, 117, 188
      ],

      SELECTED_TEXT_COLOR : [
         250, 250, 250
      ],

      UN_SELECTED_TEXT_COLOR : [
         0, 0, 0
      ],

      SHADOW_X_OFFSET : 1,
      SHADOW_Y_OFFSET : 3,
      ICON_SIZE : 16,
      CHAR_WIDTH : 9,
      VERT_LEFT_RIGHT_SPACING : 5,
      VERT_TOP_BOTTOM_SPACING : 4,
      VERT_ROW_HEIGHT : 24,
      SPACING_BETWEEN_TOKEN_TEXT : 3,

      ICON_PATHS : {
          CRITICAL : ilogDiagramUtils.toUrl("com.ibm.bpm.wpd/images/") + "task_Overdue_unselected.png",
          AT_RISK : ilogDiagramUtils.toUrl("com.ibm.bpm.wpd/images/") + "task_AtRisk_unselected.png",
          OK : ilogDiagramUtils.toUrl("com.ibm.bpm.wpd/images/") + "task_OnTrack_unselected.png",
          CRITICAL_SELECTED : ilogDiagramUtils.toUrl("com.ibm.bpm.wpd/images/") + "task_Overdue_selected.png",
          AT_RISK_SELECTED : ilogDiagramUtils.toUrl("com.ibm.bpm.wpd/images/") + "task_AtRisk_selected.png",
          OK_SELECTED : ilogDiagramUtils.toUrl("com.ibm.bpm.wpd/images/") + "task_OnTrack_selected.png"
       },

      BASE_RECT_ATTACH_POINTS : null,
      TEXT_ATTACH_POINTS : null,
      ICON_ATTACH_POINTS : null,
      EVENT_ATTACH_POINTS : null,

      // PUBLIC CONSTANTS
      AT_RISK : "AT_RISK",
      CRITICAL : "CRITICAL",
      OK : "OK",
      STAT_TYPE_SELECTED : "STAT_TYPE_SELECTED",
      STAT_TYPE_UNSELECTED : "STAT_TYPE_UNSELECTED",
      // END PUBLIC CONSTANTS

      activityTaskStatsAdornerTemplate : [
         {
            dojoAttachPoint : 'baseGroup',
            transform : {
               dx : $bind("{{elemBaseLeft}}"),
               dy : $bind("{{elemBaseBottom}}")
            },
            children : [
               // Bottom Shadow
               {
                  dojoAttachPoint : 'shadow',
                  // Offset gives it the shadow look
                  transform : {
                     dx : 1,
                     dy : 3
                  },
                  shape : {
                     x : 0,
                     y : 0,
                     width : 150,
                     height : 30,
                     r : 10,
                     type : 'rect'
                  },
                  fill : {
                     r : 192,
                     g : 192,
                     b : 192,
                     a : 0.8
                  }
               },
               // Base rectangle
               {
                  dojoAttachPoint : 'baseShape',
                  minimumSize : {
                     width : 80,
                     height : 30
                  },
                  shape : {
                     x : 0,
                     y : 0,
                     width : 150,
                     height : 30,
                     r : 10,
                     type : 'rect'
                  },
                  fill : {
                     r : 240,
                     g : 243,
                     b : 247,
                     a : 1.0
                  },
                  stroke : {
                     color : [
                        0, 0, 0, 0.50
                     ],
                     width : 0
                  }
               },
               // Group that will show the base color when selected
               {
                  dojoAttachPoint : 'statsBaseRectangles',
                  children : []
               },
               // Group that will show the icons and count
               {
                  dojoAttachPoint : 'statsGroup',
                  children : []
               },
               // Group that capture events when the user clicks on the text or
               {
                  dojoAttachPoint : 'statsEventRectangles',
                  children : []
               }
            ]

         }
      ],

      statsBaseRectTemplate : {
         dojoAttachPoint : 'statsBaseRects_X',
         shape : {
            x : 0,
            y : 0,
            width : 50,
            height : 30,
            r : 8,
            type : 'rect'
         },
         fill : {
            r : 0,
            g : 250,
            b : 250,
            a : 0.0
         }

      },

      statsIconTemplate : {
         dojoAttachPoint : 'statsIcon_X',
         shape : {
            x : 1,
            y : 7,
            width : 16,
            height : 16,
            src : bootstrap.getEndPointAndContextRootForModule(bootstrap.wpdConstant.BPM_WARNAME_WEBVIEWER) + '/widgets/com/ibm/bpm/wpd/images/assetview/key-performance-indicator-16.png',
            type : 'image'
         }

      },

      statsTextTemplate : {
         dojoAttachPoint : 'statsText_X',
         shape : {
            align : "center",
            x : 0,
            y : 20,
            // fontPxSize : 11.5,
            // fontPxMinSize : 6,
            width : 22,
            text : "999m",
            type : 'text'
         },
         fill : {
            r : 0,
            g : 0,
            b : 0,
            a : 1
         },
         font : {
            type : 'font',
            size : 15,
            family : 'arial',
            weight : "bold"
         }
      },

      statsEventRectTemplate : {
         dojoAttachPoint : 'statsEventRects_X',
         shape : {
            x : 0,
            y : 0,
            width : 50,
            height : 30,
            r : 8,
            type : 'rect'
         },
         fill : {
            r : 0,
            g : 0,
            b : 0,
            a : 0.0
         }
      },

      constructor : function(args) {
         lang.mixin(this, args);
         if (!this.atRiskCount)
            this.atRiskCount = 0;

         if (!this.criticalCount)
            this.criticalCount = 0;

         if (!this.okCount)
            this.okCount = 0;

         if (!this.mode)
            this.mode = this.MODE_AUTO;

         this.previousZoom = 0;
         this.groupBaseXOffset = 0;
         this.groupBaseYOffset = 0;

         this.BASE_RECT_ATTACH_POINTS = {};
         this.BASE_RECT_ATTACH_POINTS[this.AT_RISK] = "statsBaseRect_RISK";
         this.BASE_RECT_ATTACH_POINTS[this.CRITICAL] = "statsBaseRect_CRIT";
         this.BASE_RECT_ATTACH_POINTS[this.OK] = "statsBaseRect_OK";

         this.TEXT_ATTACH_POINTS = {};
         this.TEXT_ATTACH_POINTS[this.AT_RISK] = "statsText_RISK";
         this.TEXT_ATTACH_POINTS[this.CRITICAL] = "statsText_CRIT";
         this.TEXT_ATTACH_POINTS[this.OK] = "statsText_OK";

         this.ICON_ATTACH_POINTS = {};
         this.ICON_ATTACH_POINTS[this.AT_RISK] = "statsIcon_RISK";
         this.ICON_ATTACH_POINTS[this.CRITICAL] = "statsIcon_CRIT";
         this.ICON_ATTACH_POINTS[this.OK] = "statsIcon_OK";

         this.EVENT_ATTACH_POINTS = {};
         this.EVENT_ATTACH_POINTS[this.AT_RISK] = "statsEventRect_RISK";
         this.EVENT_ATTACH_POINTS[this.CRITICAL] = "statsEventRect_CRIT";
         this.EVENT_ATTACH_POINTS[this.OK] = "statsEventRect_OK";
      },

      adorn : function() {
         try {
            // If already adorned, nothing to do.
            if (this.adorned)
               return;
            // If not a node (not an event or gateway), then don't know what to do.
            if (this.adornerTarget.type != adornerConstants.TYPE_ACTIVITY)
               return;
            // If the counts are all 0, then nothing to do.
            if (!this.atRiskCount && !this.criticalCount && !this.okCount)
               return;
            // Resolve the node.
            var gfxNode = ilogDiagramUtils.getGfxNodeById(this.adornerTarget.ilogDiagram, this.adornerTarget.id);
            if (!gfxNode)
               return;
            // Create and populate the template which contains all of the
            // elements.
            var template = null;
            var mode = this.computeMode();
            if (mode === this.MODE_VERT) {
               template = this.createAndPopulateVerticalBaseTemplate();
            } else {
               template = this.createAndPopulateHorizontalBaseTemplate();
            }
            var xOffset = 95 - template.children[0].shape.width;
            var xOffsetString = "";
            if (xOffset < 0) {
               xOffsetString = "-" + Math.floor((xOffset * -1) / 2);
            } else if (xOffset > 0) {
               xOffsetString = "+" + Math.floor(xOffset / 2);
            }
            template.transform.dx = $bind("{{elemBaseLeft}}" + xOffsetString);
            template.transform.dy = $bind("{{elemBaseBottom}}+12");
            this.groupBaseXOffset = Math.floor(xOffset / 2);
            this.groupBaseYOffset = 12;
            // Create the ILog adorner and use that
            var dic = new Dictionary();
            dic.add("TaskStatsAdorner", template);
            this.ilogAdorner = this.adornerTarget.ilogDiagram.createAdorner(ComponentILogAdorner, dic, "TaskStatsAdorner");
            this.ilogAdorner.setComponent("_baseShape");
            this.ilogAdorner.setAdorned(gfxNode);
            var node =  this.ilogAdorner.getNode();
            if (!!node) {
               // This "disables" BIDI for this adorner which is what we want since
               // all of the calculations are based on X being the start of the text
               // string i.e. the counts
               node.setAttribute("direction", "ltr");
            }
            this.createTooltips();
            this.registerEventListeners();
            this.baseTemplate = template;
            this.inherited(arguments);
         } catch (e) {
            console.error(e);
         }
      },

      createAndPopulateHorizontalBaseTemplate : function() {
         // Ccale what needs to be scaled
         var baseTemplate = lang.clone(this.activityTaskStatsAdornerTemplate)[0];
         // Create the first layer i.e. the base rectangles that will show selection
         // status
         var currTemplate = null;
         var currStringValue = "";
         var currTotalWidth = 1;
         var currWidth = 0;
         var currX = 1;
         if (this.criticalCount) {
            // First build the base rectangle
            currTemplate = lang.clone(this.statsBaseRectTemplate);
            currStringValue = this.convertNumToString(this.criticalCount);
            currWidth = this.computeStatWidth(currStringValue);
            currTemplate.dojoAttachPoint = this.BASE_RECT_ATTACH_POINTS[this.CRITICAL];
            currTemplate.shape.width = currWidth;
            currTemplate.shape.x = currX;
            baseTemplate.children[2].children.push(currTemplate);
            // Then add the icon and text on top of that
            currTemplate = this.createStatsIconTemplate(this.ICON_ATTACH_POINTS[this.CRITICAL], currX + 1, 7, this.ICON_PATHS[this.CRITICAL]);
            baseTemplate.children[3].children.push(currTemplate);
            currTemplate = this.createStatsTextTemplate(this.TEXT_ATTACH_POINTS[this.CRITICAL], currX + this.ICON_SIZE + 3, 20, currStringValue);
            baseTemplate.children[3].children.push(currTemplate);
            currTotalWidth = currTotalWidth + currWidth;
            // Then add the event rectangle
            currTemplate = lang.clone(this.statsEventRectTemplate);
            currTemplate.dojoAttachPoint = this.EVENT_ATTACH_POINTS[this.CRITICAL];
            currTemplate.shape.width = currWidth;
            currTemplate.shape.x = currX;
            baseTemplate.children[4].children.push(currTemplate);
         }
         if (this.atRiskCount) {
            currX = currTotalWidth;
            // First build the base rectangle
            currTemplate = lang.clone(this.statsBaseRectTemplate);
            currStringValue = this.convertNumToString(this.atRiskCount);
            currWidth = this.computeStatWidth(currStringValue);
            currTemplate.dojoAttachPoint = this.BASE_RECT_ATTACH_POINTS[this.AT_RISK];
            currTemplate.shape.width = currWidth;
            currTemplate.shape.x = currX;
            baseTemplate.children[2].children.push(currTemplate);
            // Then add the icon and text on top of that
            currTemplate = this.createStatsIconTemplate(this.ICON_ATTACH_POINTS[this.AT_RISK], currX + 1, 7, this.ICON_PATHS[this.AT_RISK]);
            baseTemplate.children[3].children.push(currTemplate);
            currTemplate = this.createStatsTextTemplate(this.TEXT_ATTACH_POINTS[this.AT_RISK], currX +  this.ICON_SIZE + 3, 20, currStringValue);
            baseTemplate.children[3].children.push(currTemplate);
            currTotalWidth = currTotalWidth + currWidth;
            // Then add the event rectangle
            currTemplate = lang.clone(this.statsEventRectTemplate);
            currTemplate.dojoAttachPoint = this.EVENT_ATTACH_POINTS[this.AT_RISK];
            currTemplate.shape.width = currWidth;
            currTemplate.shape.x = currX;
            baseTemplate.children[4].children.push(currTemplate);
         }
         if (this.okCount) {
            currX = currTotalWidth;
            // First build the base rectangle
            currTemplate = lang.clone(this.statsBaseRectTemplate);
            currStringValue = this.convertNumToString(this.okCount);
            currWidth = this.computeStatWidth(currStringValue);
            currTemplate.dojoAttachPoint = this.BASE_RECT_ATTACH_POINTS[this.OK];
            currTemplate.shape.width = currWidth;
            currTemplate.shape.x = currX;
            baseTemplate.children[2].children.push(currTemplate);
            // Then add the icon and text on top of that
            currTemplate = this.createStatsIconTemplate(this.ICON_ATTACH_POINTS[this.OK], currX + 1, 7, this.ICON_PATHS[this.OK]);
            baseTemplate.children[3].children.push(currTemplate);
            currTemplate = this.createStatsTextTemplate(this.TEXT_ATTACH_POINTS[this.OK], currX +  this.ICON_SIZE + 3, 20, currStringValue);
            baseTemplate.children[3].children.push(currTemplate);
            currTotalWidth = currTotalWidth + currWidth;
            // Then add the event rectangle
            currTemplate = lang.clone(this.statsEventRectTemplate);
            currTemplate.dojoAttachPoint = this.EVENT_ATTACH_POINTS[this.OK];
            currTemplate.shape.width = currWidth;
            currTemplate.shape.x = currX;
            baseTemplate.children[4].children.push(currTemplate);
         }
         // Adjust the base template
         baseTemplate.children[0].shape.width = currTotalWidth + 1;
         baseTemplate.children[1].shape.width = currTotalWidth + 1;
         return baseTemplate;
      },

      createAndPopulateVerticalBaseTemplate : function() {
         // Create the base template.
         var baseTemplate = lang.clone(this.activityTaskStatsAdornerTemplate)[0];
         // Create the first layer i.e. the base rectangles that will show selection
         // status
         var currTemplate = null;
         var currStringValue = "";
         var totHeight = this.computeVertStackHeight();
         var totWidth = this.computeVertStackWidth();
         baseTemplate.children[0].shape.width = totWidth;
         baseTemplate.children[0].shape.height = totHeight;
         baseTemplate.children[1].shape.width = totWidth;
         baseTemplate.children[1].shape.height = totHeight;
         var currX = 0;
         var currY = 0;
         if (this.criticalCount) {
            // First build the base rectangle
            currTemplate = lang.clone(this.statsBaseRectTemplate);
            currStringValue = "" + this.criticalCount;
            currTemplate.dojoAttachPoint = this.BASE_RECT_ATTACH_POINTS[this.CRITICAL];
            currTemplate.shape.width = totWidth;
            currTemplate.shape.height = this.VERT_ROW_HEIGHT;
            currTemplate.shape.x = currX;
            currTemplate.shape.y = currY;
            baseTemplate.children[2].children.push(currTemplate);
            currX = this.VERT_LEFT_RIGHT_SPACING;
            currY = currY + this.VERT_TOP_BOTTOM_SPACING;
            // Then add the icon and text on top of that
            currTemplate = this.createStatsIconTemplate(this.ICON_ATTACH_POINTS[this.CRITICAL], currX + 1, currY, this.ICON_PATHS[this.CRITICAL]);
            baseTemplate.children[3].children.push(currTemplate);
            currTemplate = this.createStatsTextTemplate(this.TEXT_ATTACH_POINTS[this.CRITICAL], currX +  this.ICON_SIZE + 3, currY + 13, currStringValue);
            baseTemplate.children[3].children.push(currTemplate);
            currX = 0;
            currY = currY - this.VERT_TOP_BOTTOM_SPACING;
            // Then add the event rectangle
            currTemplate = lang.clone(this.statsEventRectTemplate);
            currTemplate.dojoAttachPoint = this.EVENT_ATTACH_POINTS[this.CRITICAL];
            currTemplate.shape.height = this.VERT_ROW_HEIGHT;
            currTemplate.shape.width = totWidth;
            currTemplate.shape.x = currX;
            currTemplate.shape.y = currY;
            baseTemplate.children[4].children.push(currTemplate);
            currY = currY + this.VERT_ROW_HEIGHT;
         }
         if (this.atRiskCount) {
            // First build the base rectangle
            currTemplate = lang.clone(this.statsBaseRectTemplate);
            currStringValue = "" + this.atRiskCount;
            currTemplate.dojoAttachPoint = this.BASE_RECT_ATTACH_POINTS[this.AT_RISK];
            currTemplate.shape.width = totWidth;
            currTemplate.shape.height = this.VERT_ROW_HEIGHT;
            currTemplate.shape.x = currX;
            currTemplate.shape.y = currY;
            baseTemplate.children[2].children.push(currTemplate);
            currX = this.VERT_LEFT_RIGHT_SPACING;
            currY = currY + this.VERT_TOP_BOTTOM_SPACING;
            // Then add the icon and text on top of that
            currTemplate = this.createStatsIconTemplate(this.ICON_ATTACH_POINTS[this.AT_RISK], currX + 1, currY, this.ICON_PATHS[this.AT_RISK]);
            baseTemplate.children[3].children.push(currTemplate);
            currTemplate = this.createStatsTextTemplate(this.TEXT_ATTACH_POINTS[this.AT_RISK], currX +  this.ICON_SIZE + 3, currY + 13, currStringValue);
            baseTemplate.children[3].children.push(currTemplate);
            currX = 0;
            currY = currY - this.VERT_TOP_BOTTOM_SPACING;
            // Then add the event rectangle
            currTemplate = lang.clone(this.statsEventRectTemplate);
            currTemplate.dojoAttachPoint = this.EVENT_ATTACH_POINTS[this.AT_RISK];
            currTemplate.shape.width = totWidth;
            currTemplate.shape.height = this.VERT_ROW_HEIGHT;
            currTemplate.shape.x = currX;
            currTemplate.shape.y = currY;
            baseTemplate.children[4].children.push(currTemplate);
            currY = currY + this.VERT_ROW_HEIGHT;
         }
         if (this.okCount) {
            // First build the base rectangle
            currTemplate = lang.clone(this.statsBaseRectTemplate);
            currStringValue = "" + this.okCount;
            currTemplate.dojoAttachPoint = this.BASE_RECT_ATTACH_POINTS[this.OK];
            currTemplate.shape.width = totWidth;
            currTemplate.shape.height = this.VERT_ROW_HEIGHT;
            currTemplate.shape.x = currX;
            currTemplate.shape.y = currY;
            baseTemplate.children[2].children.push(currTemplate);
            currX = this.VERT_LEFT_RIGHT_SPACING;
            currY = currY + this.VERT_TOP_BOTTOM_SPACING;
            // Then add the icon and text on top of that
            currTemplate = this.createStatsIconTemplate(this.ICON_ATTACH_POINTS[this.OK], currX + 1, currY, this.ICON_PATHS[this.OK]);
            baseTemplate.children[3].children.push(currTemplate);
            currTemplate = this.createStatsTextTemplate(this.TEXT_ATTACH_POINTS[this.OK], currX +  this.ICON_SIZE + 3, currY + 13, currStringValue);
            baseTemplate.children[3].children.push(currTemplate);
            currX = 0;
            currY = currY - this.VERT_TOP_BOTTOM_SPACING;
            // Then add the event rectangle
            currTemplate = lang.clone(this.statsEventRectTemplate);
            currTemplate.dojoAttachPoint = this.EVENT_ATTACH_POINTS[this.OK];
            currTemplate.shape.width = totWidth;
            currTemplate.shape.height = this.VERT_ROW_HEIGHT;
            currTemplate.shape.x = currX;
            currTemplate.shape.y = currY;
            baseTemplate.children[4].children.push(currTemplate);
            currY = currY + this.VERT_ROW_HEIGHT;
         }
         // Adjust the base template
         // baseTemplate.children[0].shape.width = currTotalWidth + 1;
         // baseTemplate.children[1].shape.width = currTotalWidth + 1;
         return baseTemplate;
      },

      computeVertStackHeight : function() {
         var height = 0;
         var numRows = 0;
         if (this.criticalCount)
            numRows++;
         if (this.atRiskCount)
            numRows++;
         if (this.okCount)
            numRows++;
         return numRows * this.VERT_ROW_HEIGHT;
      },

      computeVertStackWidth : function() {
         var width = 0;
         var largestNumChars = 0;
         var currNumChars = 0;
         var numRows = 0;
         if (this.criticalCount) {
            currNumChars = ("" + this.criticalCount).length;
            if (currNumChars > largestNumChars)
               largestNumChars = currNumChars;
         }
         if (this.atRiskCount) {
            currNumChars = ("" + this.atRiskCount).length;
            if (currNumChars > largestNumChars)
               largestNumChars = currNumChars;
         }
         if (this.okCount) {
            currNumChars = ("" + this.okCount).length;
            if (currNumChars > largestNumChars)
               largestNumChars = currNumChars;
         }
         width = width +  this.ICON_SIZE; // Token
         width = width + largestNumChars * this.CHAR_WIDTH; // Text
         width = width + this.VERT_LEFT_RIGHT_SPACING * 2; // Spacing
         return width;
      },

      computeStatWidth : function(numString) {
         var width = 0;
         if (numString) {
            width = width +  this.ICON_SIZE; // Token
            width = width + this.TEXT_WIDTHS[numString.length];
            width = width + 3; // Spacing
         }
         return width;
      },

      createStatsTextTemplate : function(name, x, y, text) {
         if (!name || !x || !y || !text)
            return null;
         var template = lang.clone(this.statsTextTemplate);
         template.dojoAttachPoint = name;
         template.shape.x = x;
         template.shape.y = y;
         template.shape.text = text;
         template.shape.width = this.TEXT_WIDTHS[text.length];
         return template;
      },

      createStatsIconTemplate : function(name, x, y, iconPath) {
         if (!name || !x || !y || !iconPath)
            return null;
         var template = lang.clone(this.statsIconTemplate);
         template.dojoAttachPoint = name;
         template.shape.x = x;
         template.shape.y = y;
         template.shape.src = iconPath;
         return template;
      },

      /**
       * We only allow 4 chars for the count, so abbreviate the number. (4123 becomes 4.1K)
       */
      convertNumToString : function(number) {
         if (!number)
            return null;
         if (number < 10000)
            return "" + number;
         if (number < 1000000)
            return this.adjustToAtMost3Chars("" + number / 1000) + "K";
         if (number < 1000000000)
            return this.adjustToAtMost3Chars("" + number / 1000000) + "M";
         return this.adjustToAtMost3Chars("" + number / 1000000000) + "B";
      },

      adjustToAtMost3Chars : function(numString) {
         if (!numString)
            return null;
         if (numString.length <= 3)
            return numString;
         var str = numString.substr(0, 3);
         if (str.substr(2, 1) === ".") {
            return str.substr(0, 2);
         } else {
            return str;
         }
      },

      registerEventListeners : function() {
         if (!this.ilogAdorner)
            return;
         var currEvt = null;
         if (this.criticalCount) {
            this.registerEventListenersFor(this.CRITICAL);
         }
         if (this.atRiskCount) {
            this.registerEventListenersFor(this.AT_RISK);
         }
         if (this.okCount) {
            this.registerEventListenersFor(this.OK);
         }
      },

      registerEventListenersFor : function(type) {
         var currEvt = this.ilogAdorner[this.EVENT_ATTACH_POINTS[type]].connect("onmouseover", this, function(e) {
            this.setHighlighted(type);
         });
         this.eventHandles.push(currEvt);
         currEvt = this.ilogAdorner[this.EVENT_ATTACH_POINTS[type]].connect("onmouseout", this, function(e) {
            this.setUnhighlighted(type);
         });
         this.eventHandles.push(currEvt);
         currEvt = this.ilogAdorner[this.EVENT_ATTACH_POINTS[type]].connect("onclick", this, function(e) {
            event.stop(e);
            this.select(type);
         });
         this.eventHandles.push(currEvt);
         currEvt = this.ilogAdorner[this.EVENT_ATTACH_POINTS[type]].connect("ontouchstart", this, function(e) {
            event.stop(e);
            this.select(type);
         });
         this.eventHandles.push(currEvt);
      },

      setHighlighted : function(type) {
         if (!type)
            return;
         if (this.selected === type)
            return;
         this.ilogAdorner[this.BASE_RECT_ATTACH_POINTS[type]].setFill(new Color(this.HIGHLIGHT_COLOR));
      },

      setUnhighlighted : function(type) {
         if (!type)
            return;
         if (this.selected === type)
            return;
         this.ilogAdorner[this.BASE_RECT_ATTACH_POINTS[type]].setFill(new Color(this.UN_HIGHLIGHT_COLOR));
      },

      select : function(type) {
         if (!type)
            return;
         if (this.selected === type) {
            this.unselect();
            return;
         }
         this.unselect();
         this.ilogAdorner[this.BASE_RECT_ATTACH_POINTS[type]].setFill(new Color(this.SELECTED_COLOR));
         this.ilogAdorner[this.TEXT_ATTACH_POINTS[type]].setFill(new Color(this.SELECTED_TEXT_COLOR));
         var iconShape = this.ilogAdorner[this.ICON_ATTACH_POINTS[type]].getShape();
         iconShape.src = this.ICON_PATHS[type+"_SELECTED"];
         this.ilogAdorner[this.ICON_ATTACH_POINTS[type]].setShape(iconShape);
         this.selected = type;
         this.onEvent(this, this.STAT_TYPE_SELECTED, type);
      },

      unselect : function() {
         if (!this.selected)
            return;
         this.ilogAdorner[this.BASE_RECT_ATTACH_POINTS[this.selected]].setFill(new Color(this.UN_HIGHLIGHT_COLOR));
         this.ilogAdorner[this.TEXT_ATTACH_POINTS[this.selected]].setFill(new Color(this.UN_SELECTED_TEXT_COLOR));
         var type = this.selected;
         var iconShape = this.ilogAdorner[this.ICON_ATTACH_POINTS[type]].getShape();
         iconShape.src = this.ICON_PATHS[type];
         this.ilogAdorner[this.ICON_ATTACH_POINTS[type]].setShape(iconShape);
         this.selected = null;
         this.onEvent(this, this.STAT_TYPE_UNSELECTED, type);
      },

      createTooltips : function() {
         if (this.criticalCount) {
            this.createTooltip(this.CRITICAL, string.substitute(nls.CRITICAL_TASK_COUNT, {"count": this.criticalCount}));
         }
         if (this.atRiskCount) {
            this.createTooltip(this.AT_RISK, string.substitute(nls.AT_RISK_TASK_COUNT, {"count": this.atRiskCount}));
         }
         if (this.okCount) {
            this.createTooltip(this.OK, string.substitute(nls.OK_TASK_COUNT, {"count": this.okCount}));
         }
      },

      createTooltip : function(type, text) {
         var node = this.ilogAdorner[this.EVENT_ATTACH_POINTS[type]].rawNode;
         node["offsetWidth"] = 0; // Kludge to get FF working (See
                                    // http://trac.dojotoolkit.org/ticket/16310
         var tt =  new Tooltip({
            connectId : [
               node
            ],
            label : text,
            position : [
               "below"
            ],
            showDelay : 900
         // Tried all sorts of delays. This is the best.
         });
         this.tooltips.push(tt);
      },

      computeMode : function() {
         if (!this.mode)
            return this.MODE_HORZ;
         if (this.mode != this.MODE_AUTO)
            return this.mode;
         // Auto mode. If largest task count > 9999 (five digits or mode) then
         // its vertical, otherwise it's horizontal
         if (this.criticalCount > 9999 || this.atRiskCount > 9999 || this.okCount > 9999) {
            return this.MODE_VERT;
         }
         return this.MODE_HORZ;

      },

      /**
       * Called as part of adorn and when the viewer is resized.
       * 
       */
      updateLayout : function() {
         try {
            if (!this.ilogAdorner)
               return;
            // Scale what needs to be scaled
            var zoom = this.ilogAdorner.getZoom();
            if (zoom === 1.0 && zoom === this.previousZoom)
               return;
            this.previousZoom = zoom;
            // Scale the base transform
            var transform = this.ilogAdorner.baseGroup.getTransform();
            transform.dx = this.ilogAdorner.getElemBaseLeft() + Math.round(this.groupBaseXOffset * zoom);
            transform.dy = this.ilogAdorner.getElemBaseBottom() + Math.round(this.groupBaseYOffset * zoom);
            this.ilogAdorner.baseGroup.setTransform(transform);
            // Scale shadow and base
            this.ilogAdorner.shadow.setShape(this.scaleShape(this.baseTemplate.children[0].shape, zoom));
            this.ilogAdorner.shadow.setTransform(this.scaleTransform(this.baseTemplate.children[0].transform, zoom));
            this.ilogAdorner.baseShape.setShape(this.scaleShape(this.baseTemplate.children[1].shape, zoom));
            // Scale the tasks
            baseIdx = 0;
            if (this.criticalCount) {
               this.scaleTask(this.CRITICAL, baseIdx, zoom);
               baseIdx++;
            }
            if (this.atRiskCount) {
               this.scaleTask(this.AT_RISK, baseIdx, zoom);
               baseIdx++;
            }
            if (this.okCount) {
               this.scaleTask(this.OK, baseIdx, zoom);
            }

         } catch (e) {
            console.error(e);
         }
      },

      scaleTask : function(type, baseIdx, zoom) {
         try {
            // Scale Base
            this.ilogAdorner[this.BASE_RECT_ATTACH_POINTS[type]].setShape(this
               .scaleShape(this.baseTemplate.children[2].children[baseIdx].shape, zoom));
            // Scale Token
            var tkShape = this.baseTemplate.children[3].children[baseIdx * 2].shape;
            if (this.selected === type) {
               tkShape.src = this.ICON_PATHS[type+"_SELECTED"];
            } else {
               tkShape.src = this.ICON_PATHS[type];
            }
            this.ilogAdorner[this.ICON_ATTACH_POINTS[type]]
               .setShape(this.scaleShape(tkShape, zoom));
            // Scale Text
            this.ilogAdorner[this.TEXT_ATTACH_POINTS[type]].setShape(this.scaleShape(this.baseTemplate.children[3].children[baseIdx * 2 + 1].shape,
               zoom));
            this.ilogAdorner[this.TEXT_ATTACH_POINTS[type]].setFont(this
               .scaleFont(this.baseTemplate.children[3].children[baseIdx * 2 + 1].font, zoom));
            // Scale Event Rectangle
            this.ilogAdorner[this.EVENT_ATTACH_POINTS[type]].setShape(this.scaleShape(this.baseTemplate.children[4].children[baseIdx].shape, zoom));
         } catch (e) {
            console.error(e);
         }
      },

      scaleShape : function(shape, zoom) {
         try {
            if (!shape)
               return null;
            var newShape = lang.clone(shape);
            if (!zoom)
               return newShape;
            newShape.x = Math.round(newShape.x * zoom);
            newShape.y = Math.round(newShape.y * zoom);
            newShape.width = Math.round(newShape.width * zoom);
            newShape.height = Math.round(newShape.height * zoom);
            if (newShape.r)
               newShape.r = Math.round(newShape.r * zoom);
            return newShape;
         } catch (e) {
            console.error(e);
         }
      },

      scaleFont : function(font, zoom) {
         try {
            if (!font)
               return null;
            var newFont = lang.clone(font);
            if (!zoom)
               return newFont;
            newFont.size = Math.round(newFont.size * zoom);
            return newFont;
         } catch (e) {
            console.error(e);
         }
      },

      scaleTransform : function(transform, zoom) {
         try {
            if (!transform)
               return null;
            var newTrans = lang.clone(transform);
            if (!zoom)
               return newTrans;
            newTrans.dx = Math.round(newTrans.dx * zoom);
            newTrans.dy = Math.round(newTrans.dy * zoom);
            return newTrans;
         } catch (e) {
            console.error(e);
         }
      }

   });

});
