/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/declare", "./Layout"],
function(declare, Layout){

/*=====
var Layout = ibm_ilog.diagram.gfxlayout.Layout;
=====*/

var FillLayout =
declare('ibm_ilog.diagram.gfxlayout.FillLayout', Layout, {
	
	getConfig:function(){
		// summary:
		// Gets the current configuration of this layout instance.
		// returns: Object
		//	An object that represents the layout current configuration.
		return {type:'ibm_ilog.diagram.gfxlayout.FillLayout'}; /*Object*/
	},

    computePreferredSize: function(proposedSize) {
        var children = this._container.children, count = children.length, o, i, maxW = 0, maxH = 0;
        for (i = 0; i < count; ++i) {
            if (children[i].filler) 
                continue;
            var sz = children[i].computePreferredSize(proposedSize);
            if (sz.width > maxW) 
                maxW = sz.width;
            if (sz.height > maxH)
                maxH = sz.height;
        }
        return {
            width: proposedSize.width === -1 ? maxW : proposedSize.width,
            height: proposedSize.height === -1 ? maxH : proposedSize.height
        }
    },
    
    layoutChildren: function(contBounds) {
        var children = this._container.children, count = children.length, o, i;
        for (i = 0; i < count; ++i) {
            children[i].layout(contBounds);
        }
    }
});

return FillLayout;

});
