/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
// This file is what is executed by the Web Worker when graph layout is executed asynchronously
// using the WebWorkerLayout class.

importScripts("_dojo.js");

var RecursiveLayout, _LayoutProvider, _GraphAdapter;

console = {
	log: function(message){
		postMessage("{_info: true, message: '"+message+"'}");
	}
};

var baseUrl, graphlayoutUrl, diagramUrl;

self.onmessage = function(e){
	var data = e.data;
	
	// The first 3 messages we receive contain the Urls of dojo, ibm_ilog/graphlayout and ibm_ilog/diagram
	if(!baseUrl) {
		baseUrl = data;
		return;
	}
	if(!graphlayoutUrl) {
		graphlayoutUrl = data;
		return;
	}
	if(!diagramUrl) {
		diagramUrl = data;
		 
		_loadDojo(baseUrl, graphlayoutUrl, diagramUrl);
		
		// Define a fake dojox/gfx/_base module so that dojox/gfx/matrix does not load the real one,
		// which would require window, etc...
		define("dojox/gfx/_base", ["dojo/_base/lang"], function(lang) { return lang.getObject("dojox/gfx", true); });
		define("dojox/gfx", ["dojo/_base/lang"], function(lang) { return lang.getObject("dojox/gfx", true); });
		
		// Define a fake dojo/number module so that ibm_ilog/diagram/util/Geometry does load the real one.
		// (Geometry is prepared to have number but not number._round).
		define("dojo/number", ["dojo/_base/lang"], function(lang) { return {}; });
		
		// load the  modules that we will need:
		require([
			"ibm_ilog/diagram/graphlayout/webworker/_matrix", // to extend matrix2D with methods used in GL
			"ibm_ilog/graphlayout/RecursiveLayout",
			"ibm_ilog/diagram/graphlayout/webworker/_LayoutProvider",
			"ibm_ilog/diagram/graphlayout/webworker/_GraphAdapter"
		],
		function(
			m,
			r,
			l,
			g
		){
			RecursiveLayout = r;
			_LayoutProvider = l;
			_GraphAdapter = g;
		});
		return;
	}
		
	// All subsequent messages are actual layout requests,
	// the data sent is the JSON graph description
	
	try {
		var graphData = dojo.fromJson(data);
	
		_GraphAdapter.prepareGraph(graphData);

		var provider = new _LayoutProvider();
		var layout = new RecursiveLayout(null, provider);
		var model = new _GraphAdapter(graphData);
		layout.attach(model);

		layout.performLayout(true);

		_GraphAdapter.cleanupGraph(graphData);

		self.postMessage(dojo.toJson(graphData));
	} catch(e){
		postMessage("{ _error: true, responseText: '" + e.message + "' }");
	}
};
