/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"./UserCustomizedAction",
"./UndoActionList"
], function(
declare,
UserCustomizedAction,
UndoActionList
){
	
/*=====
var UserCustomizedAction = ibm_ilog.diagram.editor.undo.UserCustomizedAction;
=====*/

	var GroupAction =
	declare("ibm_ilog.diagram.editor.undo.GroupAction", [UserCustomizedAction], {
		//	
		// summary:
		//		this action undo/redo any Group action.
		//		This action must be modified for the user if any user defined action is done on a Group action.
		//
		
	_elements: null,
	_subgraph: null,
	_subgraphName: null,
	constructor:function(){
		//	
		// summary:
		//		creates a new instance, setting the corresponding label
		this._label = UndoActionList.Group;
	},
	setElements: function(elements){
		//	
		// summary:
		//		sets the elements list to be group
		this._elements = [];
		dojo.forEach(elements,function(ge){this._elements.push(ge.getId());},this);
	},
	getElements: function(){
		//	
		// summary:
		//		gets the elements list to be group
		return this._elements;
	},
	setSubgraph: function(subgraph){
		//	
		// summary:
		//		sets the subgraph where to group
		this._subgraph = subgraph.getId();
	},
	getSubgraph: function(){
		//	
		// summary:
		//		gets the subgraph where to group
		return this._subgraph;
	},
	redoFunction: function(){
		var elements = this._getNewList();
		var D = this.getUndoManager().getDiagram();
		var result = GroupAction.EditingUtils.groupElements(D,elements,this._subgraphName);
		this.getUndoManager().registerGraphElementReplacement(this._subgraph,result.subgraph.getId());
		this._subgraph = result.subgraph.getId();
	},
	undoFunction: function(){
		var newElements = this._getNewList();
		var D = this.getUndoManager().getDiagram();
		var sg = this.getUndoManager().getRegisteredGraphElement(this._subgraph);
		GroupAction.EditingUtils.groupReparent(D,newElements,sg.getParent(),sg);
		this._subgraphName = sg.getLabel();
		sg.getParent().remove(sg); 
		sg.dispose();
	},
	_getNewList: function(){
		var newElements = [];
		var elements = this.getElements();
		dojo.forEach(elements, dojo.hitch(this, function(item){
			var newItem = this.getUndoManager().getRegisteredGraphElement(item);
			newElements.push(newItem);
		}));
		return newElements;
	}
	});
	
	return GroupAction;
	
});
