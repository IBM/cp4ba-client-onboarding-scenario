define(["dojo/_base/declare",
        "dojo/_base/connect",
        "dojo/_base/json",
        //"./WpdErrorDialog",
        "./ErrorDialog",
        "dojo/i18n!./nls/WpdErrorDialogResources",
        "com.ibm.bpm.wpd/base/bootstrap",
        "../../core/control/WpdRestHandler"],
function(declare,
		connect,
		json,
		//WpdErrorDialog,
		ErrorDialog,
		nlMessages,
		bootstrap,
		WpdRestHandler) {

return {

logError : function(classOrFileName, functionOrLineNumber, message, level){
	var url = bootstrap.getEndPointAndContextRootForModule(bootstrap.wpdConstant.BPM_WARNAME_WEBVIEWER) + "/service/v1/UITrace?traceLevel=SEVERE";
	var contentObj = {};
	contentObj.className = classOrFileName;
	contentObj.methodName = functionOrLineNumber;
	contentObj.message = message;
	var content = json.toJson(contentObj);
	var loadFn = function(response){
		//do nothing
	};
	
	var headers = { "Content-Type": "application/json"};
	//(verb, requestUrl, loadFn, errorFn, headers, isSync, message, deferred, handleAsType, xMethodOverride, user, password) {		
		try{
			WpdRestHandler.getInstance()._performRequest("post", url, loadFn, null, headers, false, content, null, 'json');
		}
		 catch (err){
		}

	if(!!level && level.toUpperCase() == "SEVERE"){
		//WpdErrorDialog.showError(message);
		ErrorDialog.showError(nlMessages.contentMessage, message);
	}	
	console.error(message);
},

traceMessage : function(classOrFileName, functionOrLineNumber, message, level){
	
	var url = bootstrap.getEndPointAndContextRootForModule(bootstrap.wpdConstant.BPM_WARNAME_WEBVIEWER) + "/service/v1/UITrace?traceLevel=INFO";
	var content = {};
	content.className = classOrFileName;
	content.methodName = functionOrLineNumber;
	content.message = message;
	var loadFn = function(response){
		//do nothing
	};
	var headers = { "Content-Type": "application/json"};
	//verb, url, loadFn, errorFn, headers, isSync, message,
	try{
		WpdRestHandler.getInstance().performRequest("post", url, loadFn, null, null, false, content);
	}
	catch (err){
	}

}

}

});

