/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"require",
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"dojox/gfx/matrix",
"ibm_ilog/graphlayout/AbstractGraphLayoutModel",
"ibm_ilog/graphlayout/internalutil/GraphModelUtil"
], function(
require,
declare,
lang,
array,
matrix,
AbstractGraphLayoutModel,
GraphModelUtil
){

/*=====
var AbstractGraphLayoutModel = ibm_ilog.graphlayout.AbstractGraphLayoutModel;
=====*/

var _GraphAdapter =
declare("ibm_ilog.diagram.graphlayout.webworker._GraphAdapter", AbstractGraphLayoutModel,
{
	// summary:
	//		The implementation of the graph model interface to layout the contents of a Graph.
	
	_graph: null, // a JS object actually
	
	getGraph: function(){
		return this._graph;
	},
	
	constructor: function(graph, layout) {
		this._graph = graph;
		this._originatingLayout = layout;
	},
	
    isNode: function(o) {
		return o._isNode;
	},
	
    getNodes: function() { 
    	return this._graph.nodes;
	},
	
    isLink: function(o) {
    	return o._isLink;
	},
	
    getLinks: function() { 
    	return array.filter(this._graph.links, function(o){ return o._isLink; });
	},

    isIntergraphLink: function(o) {
    	return o._isIntergraphLink;
	},
	
    getIntergraphLinks: function() { 
    	return array.filter(this._graph.links, function(o){ return o._isIntergraphLink; });
	},
	
    isSubgraph: function(o) {
    	return o._isSubgraph;
	},
	
    getSubgraphs: function(){
    	return array.filter(this._graph.nodes, function(o){ return o._isSubgraph; });
	},
	
    getLinksFrom: function(node) { 
		var linksFrom = node._fromLinks; 
		if (!linksFrom)
			return [];
		return array.filter(linksFrom, function(o) { return o._isLink; }); 
	},
	
    getLinksTo: function(node) { 
		var linksTo = node._toLinks; 
		if (!linksTo)
			return [];
		return array.filter(linksTo, function(o) { return o._isLink; }); 
	},
	
    getFrom: function(link) { return link._from; },
    getTo: function(link) { return link._to; },
	
	getAllLinks : function() {
		// summary:
		//		Gets all the links and intergraph links contained in the graph associated with this graph model.
		// description:
		//		Gets all the links and intergraph links contained in the graph associated with this graph model.
		//		This method is used only in the ibm_ilog.diagram.graphlayout.Animation class, it is not part of the
		//		base graph model interface.
    	return array.filter(this._graph.links, function(o){ return o._isLink || o._isIntergraphLink; });
	},
	
    boundingBox: function(nodeOrLink){
    	var b = nodeOrLink.b;
    	if(b)
    		return { x:b[0], y:b[1], width:b[2], height:b[3] };
   		else
       		return { x:0, y:0, width:0, height:0 };
	},
	
    moveNode: function(node, x, y) {
    	node.b[0] = x;
    	node.b[1] = y;
	},
	
    getLinkPoints: function(link) {
    	var points = [];
    	var p;
    	
    	if(link.fp)
    		p = { x:link.fp[0], y: link.fp[1] };
    	else
    		p = { x:link._from.b[0]+link._from.b[2]/2, y:link._from.b[1]+link._from.b[3]/2 };
    	points.push(p);
    	
    	if(link.ip)
    		for(var i = 0; i < link.ip.length; i++)
    			points.push({ x:link.ip[i][0], y:link.ip[i][1] });
    	
    	if(link.tp)
    		p = { x:link.tp[0], y: link.tp[1] };
    	else
    		p = { x:link._to.b[0]+link._to.b[2]/2, y:link._to.b[1]+link._to.b[3]/2 };
    	points.push(p);
    	
    	return points;
	},
	
    reshapeLink: function(link, style, fromPoint, fromPointMode, points, startIndex, length, toPoint, toPointMode){
		/* DEBUG. To active it, also activate the DEBUG code in WebWorkerLayout.
		self.postMessage({
        type: "debug",
        message: "reshapeLink..."
    });
    */
    
		// start point:
		switch(fromPointMode){
			case GraphModelUtil.ReshapeLinkMode.IGNORE:
			case GraphModelUtil.ReshapeLinkMode.FIX:
				break;
			case GraphModelUtil.ReshapeLinkMode.MOVE:
				link.fp = [ fromPoint.x, fromPoint.y ];
				link.fromMoved = true;
			 	break;
			case GraphModelUtil.ReshapeLinkMode.CLIP:
			 	delete link.fp;
			 	break;
			case GraphModelUtil.ReshapeLinkMode.MOVE_AND_CLIP:
				link.fp = [ fromPoint.x, fromPoint.y ];
				link.fromMoved = true;
			 	break;
		}
		
		// end point:
		switch(toPointMode){
			case GraphModelUtil.ReshapeLinkMode.IGNORE:
			case GraphModelUtil.ReshapeLinkMode.FIX:
				break;
			case GraphModelUtil.ReshapeLinkMode.MOVE:
				link.tp = [ toPoint.x, toPoint.y ];
				link.toMoved = true;
			 	break;
			case GraphModelUtil.ReshapeLinkMode.CLIP:
			 	delete link.tp;
			 	break;
			case GraphModelUtil.ReshapeLinkMode.MOVE_AND_CLIP:
				link.tp = [ toPoint.x, toPoint.y ];
				link.toMoved = true;
			 	break;
		}
		
		// intermediate points:
		
		if(length > 0){
			link.ip = [];
			for(var i = startIndex; i < startIndex + length; i++){
				link.ip.push([ points[i].x, points[i].y ]);
			}
		} else {
			delete link.ip;
		}
	},
	
    hasMoveableConnectionPoint: function(link, origin) {
    	return true;
	},
	
    hasPinnedConnectionPoint: function(link, origin) { 
    	return origin ? link.sp : link.ep;
	},
	
    getLinkWidth: function(link) { return link.w; },
	
    createGraphModel: function(subgraph) { 
		return new _GraphAdapter(subgraph);
	},
	
	getParent: function() {
		var root = this.getRoot();
		if(root == null || root == this)
			return null;
		var parentGraph = this._graph._parent;
		if (parentGraph) {
			if(parentGraph == root._graph)
				return root;
			return root.getGraphModel(parentGraph);
		}
		return null;
	},
	
    setOriginatingLayout: function(layout) {
        this._originaringLayout = layout;
    },
    
    getOriginatingLayout: function() {
        return this._originaringLayout;
    },
	
	getTransform: function(subModel)
	{
		var m = subModel._graph.m;
		var t;
		if(m)
			t = { xx:m[0], xy:m[1], yx:m[2], yy:m[3], dx:m[4], dy:m[5] };
		else
			t = { xx:1, xy:0, yx:0, yy:1, dx:0, dy:0 };
		return new matrix.Matrix2D(t);
	}
});

var HierarchicalLayout, HierarchicalSwimLaneConstraint;

lang.mixin(_GraphAdapter, {
	
	prepareGraph: function(graph)
	{
		var idToNode = {};
		_GraphAdapter._prepareNodes(graph, idToNode);
		_GraphAdapter._prepareLinks(graph, idToNode);
		graph._idToNode = idToNode; // for later use by constraints
	},
	
	_prepareNodes: function(graph, idToNode)
	{
		var i;
		if(graph.nodes){
			for(i = 0; i < graph.nodes.length; i++){
				var node = graph.nodes[i];
				idToNode[node.id] = node;
				node._isNode = true;
				node._parent = graph;
				if(node.gb){
					node._isSubgraph = true;
					_GraphAdapter._prepareNodes(node, idToNode);
				}
			}
		}
	},
	
	_prepareLinks: function(graph, idToNode)
	{
		var i;
		if(graph.links){
			for(i = 0; i < graph.links.length; i++){
				var link = graph.links[i];

				link._from = idToNode[link.f];
				link._to = idToNode[link.t];

				if(!link._from._fromLinks) link._from._fromLinks = [];
				link._from._fromLinks.push(link);

				if(!link._to._toLinks) link._to._toLinks = [];
				link._to._toLinks.push(link);

				link._isIntergraphLink =
					link._from._parent != graph ||
					link._to._parent != graph;
				link._isLink = !link._isIntergraphLink;
			}
		}
		if(graph.nodes){
			for(i = 0; i < graph.nodes.length; i++){
				var node = graph.nodes[i];
				if(node._isSubgraph)
					_GraphAdapter._prepareLinks(node, idToNode);
			}
		}
	},
	
	cleanupGraph: function(graph)
	{
		// Add calculated bboxes of swim lanes if hierarchical
		
		if(HierarchicalLayout === undefined){
			try {
				HierarchicalLayout = require("ibm_ilog/graphlayout/hierarchical/HierarchicalLayout");
				HierarchicalSwimLaneConstraint = require("ibm_ilog/graphlayout/hierarchical/HierarchicalSwimLaneConstraint");
			} catch(err){
				HierarchicalLayout = null;
				HierarchicalSwimLaneConstraint = null;
			}
		}
		
		if(graph.nodeLayout &&
		   graph.nodeLayout._layout &&
		   HierarchicalLayout && HierarchicalSwimLaneConstraint &&
		   graph.nodeLayout._layout instanceof HierarchicalLayout){
		   	var bboxes = [];
		   	var constraints = graph.nodeLayout._layout.getConstraints();
			while(constraints.hasNext()){
				var c = constraints.next();
				if(c instanceof HierarchicalSwimLaneConstraint){
					var bbox = c.getCalcBoundingBox();
					bboxes.push([ bbox.x, bbox.y, bbox.width, bbox.height ]);
				}
			}
			if(bboxes.length > 0)
				graph.swimLaneCalcBBoxes = bboxes;
		}
		
		// clear cached layout instances
		if(graph.nodeLayout)
			delete graph.nodeLayout._layout;
		if(graph.linkLayout)
			delete graph.linkLayout._layout;
		
		delete graph._idToNode;
		
		// clear all node/link properties,
		// including those stored by _prepareNodes/Links
		var i;
		var p;
		if(graph.nodes){
			for(i = 0; i < graph.nodes.length; i++){
				var node = graph.nodes[i];
				if(node._isSubgraph)
					_GraphAdapter.cleanupGraph(node);
				for(p in node)
					if(p.charAt(0) == "_")
						delete node[p];

			}
		}
		if(graph.links){
			for(i = 0; i < graph.links.length; i++){
				var link = graph.links[i];
				if (!link.fromMoved)
					delete link.fp;
			  if (!link.toMoved)
					delete link.tp;
				for(p in link)
					if(p.charAt(0) == "_")
						delete link[p];
			}
		}
	}
});

return _GraphAdapter;

});
