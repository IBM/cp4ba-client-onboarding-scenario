/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/lang", "dojo/_base/declare", "dojo/_base/array", "dojo/_base/json", "dojo/_base/connect", "dojox/collections/ArrayList", "dojox/collections/Dictionary", "../Port", "../util/ErrorReporter", "../data/StoreApi"], function(lang, declare, array, json, connect, ArrayList, Dictionary, port, R, StoreApi){

	var nodesBindingProperties = ["_successorsBinding", "_predecessorsBinding", "_parentBinding", "_childBinding", "_nodesGraphBinding", "_xBinding", "_yBinding"];
	var linksBindingProperties = ["_startNodeBinding", "_endNodeBinding", "_linksGraphBinding"];
	
	/*
	 * @author John Kelly
	 *
	 */
	var DataConnector = declare('ibm_ilog.diagram.widget.DataConnector', null, {
		//
		//	summary: 
		//
		//		The Data Connector class encapsulates the relationship
		//		between data stores, nodes and links.
		//
		//	description:
		//		
		//		Based on information provided through setters, the Data Connector reads in
		//      information from one or two data stores, then builds a model of the relationship
		//      between the items. When the model is complete, the Data Connector creates
		//      Subgraphs, Nodes and Links as appropriate.
		//
		//      There may be up to two stores involved. 
		//      - A nodesStore whose items represent subgraphs or nodes.
		//      - A linksStore whose items describe the relationship between nodeStore items.
		//      Both stores must, at least, support both dojo.data.api.Read and dojo.data.api.Identity
		//      data store features, as defined at http://docs.dojocampus.org/dojo/data
		//
		//      The basic flow is as follows:
		//      1.Based on the nodesStore query and queryOptions provided, load all matching items
		//        into the model.
		//      2.If defined, load in items from the linksStore. Each item will then be examined for 
		//        attributes "start" and "end". The values of these attributes are the identities 
		//        of items in the nodesStore. This inter-item relationship information is added to the
		//        model. If any the items referred to has not already been loaded from the 
		//        nodesStore it is done so now.
		//      3.Based on any to/from relationship functions or fields defined, add inter-item 
		//        relationship information to the model.If any the items referred to has not 
		//        already been loaded from the nodesStore it is done so now. Repeat step 3 until
		//        all items that have been loaded have had there inter-item relationships resolved.
		//      4.Now the model is fully populated, any final information needed can be deduced directly
		//        from the model.
		//      5.Based on information in the model, and options provided to the class instance, Subgraphs
		//        Nodes and links are created.
		//
		//	unit test:
		//
		//      The associated unit testcase is ibm_diagram/tests/widget/DataConnector.html
		//  
		
		// Private properties   
		
		// ------------------------------------
		// Node-related
		// ------------------------------------
		
		//
		// The validated nodes query
		//
		_nodesQuery: null,
		
		//
		// The validated nodes query options object
		//
		_nodesQueryOptions: null,
		
		// A string that indicates either the data item field name defining the child
		// relationship or a function name that returns the origin of a link 
		// for the specified data item    
		_childBinding: null,
		_childBindingFunction: null,
		
		// A string that indicates either the data item field name 
		// defining the parent relationship or a function name that returns
		// the destination of a link for the specified data item.    
		_parentBinding: null,
		_parentBindingFunction: null,
		
		// A string that indicates either the data item field name defining the from
		// relationship or a function name that returns the origin of a link 
		// for the specified data item    
		_predecessorsBinding: null,
		_predecessorsBindingFunction: null,
		
		// A string that indicates either the data item field name 
		// defining the to relationship or a function name that returns
		// the destination of a link for the specified data item.    
		_successorsBinding: null,
		_successorsBindingFunction: null,
		
		// A string that indicates either the data item field name defining the
		// "x location" associated with a nodesStore data item or a named function that 
		// returns the "x location" associated with a nodesStore data item.    
		_xBinding: null,
		_xBindingFunction: null,
		
		// A string that indicates either the data item field name defining the
		// "y location" associated with a nodesStore data item or a named function that 
		// returns the "y location" associated with a nodesStore data item.    
		_yBinding: null,
		_yBindingFunction: null,
		
		// A string that indicates either the data item field name defining the
		// "node graph data" associated with a nodesStore data item or a named function that 
		// returns the "node graph data" associated with a nodesStore data item.    
		_nodesGraphBinding: null,
		_nodesGraphBindingFunction: null,
		
		// A string that indicates either the data item field name defining the
		// "link graph data" associated with a linksStore data item or a named function that 
		// returns the "link graph data" associated with a linksStore data item.    
		_linksGraphBinding: null,
		_linksGraphBindingFunction: null,
		
		// A boolean to determine what xBinding/yBinding values represent
		//  - If true, the values provided by xBinding/yBinding atributes represent the center of the node.
		//  - If false, the values provided by xBinding/yBinding atributes represent the top left-hand corner of the node.
		_centerOnLocation: false,
		
		//
		// An array of node object functions which will be used to persist
		// graphical information to the store, if required.
		//
		
		_nodesGraphFuncMap: null,
		_nodesGraphProperties: null,
		
		//
		// The validated node data store
		//
		_nodesStore: null,
		
		//
		// Flag to indicate how hierarchical data should be represented visually.
		// If true, it will represent the nodesStore items as ibm_ilog.diagram.Node instances 
		// connected by links. If false, it will represent non-leaf items as ibm_ilog.diagram.Subgraph 
		// instances and leaf items as ibm_ilog.diagram.Node instances.
		_createLinksForHierarchy: true,
		
		// Defines which of the dojo.data.api that the store supports
		// See http://docs.dojocampus.org/dojo/data/api
		_nodesStoreFeatures: null,
		
		//
		// the map of store items to shapes nodes
		//
		_model: null,
		
		// ------------------------------------
		// Link-related
		// ------------------------------------
		
		//
		// An array of link object functions which will be used to persist
		// graphical information to the store, if required.
		//
		_linksGraphFuncMap: null,
		_linksGraphProperties: null,
		
		//
		// The validated link data store
		//
		_linksStore: null,
		
		// Defines which of the dojo.data.api that the store supports
		// See http://docs.dojocampus.org/dojo/data/api
		_linksStoreFeatures: null,
		
		//
		// The validated links query object
		//
		_linksQuery: null,
		
		//
		// The validated links query options object
		//
		_linksQueryOptions: null,
		
		// A string that indicates either the data item field name defining the start
		// item in a link or a function name that returns the origin of a link 
		// for the specified data item    
		_startNodeBinding: null,
		_startNodeBindingFunction: null,
		
		// A string that indicates either the data item field name 
		// defining the end item in a link or a function name that returns
		// the destination of a link for the specified data item.    
		_endNodeBinding: null,
		_endNodeBindingFunction: null,
		
		//
		// Array of notification handles
		_nodesStoreConnectHandles: null,
		_linksStoreConnectHandles: null,
		
		
		constructor: function(){
			// summary: 
			//     Construct and instance of ibm_ilog.diagram.widget.DataConnector and 
			//     initialise it.              
			// tags:
			//	    private      
			this._initAttributes();
			this._startNodeBinding = DataConnector.StartLinkFieldname;
			this._endNodeBinding = DataConnector.EndLinkFieldname;
			this._model = new _DataModel();
			
		},
		
		_initAttributes: function(){
			// summary: 
			//     initialise attributes              
			// tags:
			//	    private      
			this._nodesStoreConnectHandles = null;
			this._linksStoreConnectHandles = null;
			this._createLinksForHierarchy = true;
			this._nodesQuery = null;
			this._nodesQueryOptions = null;
			this._parentBinding = null;
			this._parentBindingFunction = null;
			this._childBinding = null;
			this._childBindingFunction = null;
			this._predecessorsBinding = null;
			this._predecessorsBindingFunction = null;
			this._successorsBinding = null;
			this._successorsBindingFunction = null;
			this._xBinding = null;
			this._xBindingFunction = null;
			this._yBinding = null;
			this._yBindingFunction = null;
			this._nodesGraphBinding = null;
			this._nodesGraphBindingFunction = null;
			this._centerOnLocation = false;
			this._nodesGraphFuncMap = null;
			this._nodesGraphProperties = "";
			this._nodesStore = null;
			this._nodesStoreFeatures = null;
			this._linksGraphFuncMap = null;
			this._linksGraphProperties = "";
			this._linksStore = null;
			this._linksStoreFeatures = null;
			this._linksQuery = null;
			this._linksQueryOptions = null;
			this._linksGraphBinding = null;
			this._linksGraphBindingFunction = null;
			this._startNodeBinding = null;
			this._startNodeBindingFunction = null;
			this._endNodeBinding = null;
			this._endNodeBindingFunction = null;
		},
		
		_load: function(){
			// summary: 
			//     Validate options, loads data and creates the graph
			// tags:
			//	    private 
			if (this._isValidModel()) {
				this._reset();
				this._buildModelFromStores();
			}
		},
		
		_destroyDataConnector: function(){
			// summary: 
			//     Clear up all resources used by the DataConnector
			// tags:
			//	    private 
			this._reset();
			delete this._model;
			this._initAttributes();
		},
		
		_reset: function(){
			// summary: 
			//     Reset the current collection of nodes and links.
			// tags:
			//	    private 
			
			//this._model.initLinks();
			//this._model.initNodes();
			this._clearNodes();
		},
		
		_clearNodes: function(){
			// summary: 
			//     Clear the current collection of nodes created from the nodes store.
			// tags:
			//	    private
			
			// clear graphical shapes			
			this._model.forEachEntry(function(e){
				// remove all links attached to this node (both linksStore and implicits)
				var links = e.node.getLinks();
				array.forEach(links, function(link){
					this._linkDispose(link);
				}, this);
				// and dispose the node
				this._nodeDispose(e.node);
			}, this);
			// clear data model
			this._model.initNodes();
			// also the links since all the links shapes have been removed
			this._model.initLinks();
		},
		
		_clearLinks: function(){
			// summary: 
			//     Clear the current collection of links created from the link store
			// tags:
			//	    private
			
			this._model.forEachLinkEntry(function(e){
				var link = e.link;
				var ld = link.getData();
				if (ld && ld.store && ld.store === this._linksStore) {
					this._linkDispose(link);
				}
			}, this);
			this._model.initLinks();
		},
		
		
		// ===============================================================
		// Internal child/parent binding functions
		// ===============================================================
		
		_childBindingByNodesStoreFieldName: function(/* dojo.data.api.Read */nodesStore, /* store item */ item){
			// summary: 
			//     Find the items which are associated with the childBinding field.
			// tags:
			//	    private 
			return StoreApi.getValues(nodesStore, item, this._childBinding);
		},
		
		_parentBindingByNodesStoreFieldName: function(/* dojo.data.api.Read */nodesStore, /* store item */ item){
			// summary: 
			//     Find the items which are associated with the parentBinding field.
			// tags:
			//	    private   
			return StoreApi.getValues(nodesStore, item, this._parentBinding);
		},
		
		
		// ===============================================================
		// Internal successors/from binding functions
		// ===============================================================
		
		_successorsBindingByNodesStoreFieldName: function(/* dojo.data.api.Read */nodesStore, /* store item */ item){
			// summary: 
			//     Find the items which are associated with the successorsBinding field.
			// tags:
			//	    private 
			return StoreApi.getValues(nodesStore, item, this._successorsBinding);
		},
		
		_predecessorsBindingByNodesStoreFieldName: function(/* dojo.data.api.Read */nodesStore, /* store item */ item){
			// summary: 
			//     Find the items which are associated with the predecessorsBinding field.
			// tags:
			//	    private   
			return StoreApi.getValues(nodesStore, item, this._predecessorsBinding);
		},
		
		// ===============================================================
		// Internal x/y binding functions
		// ===============================================================
		
		_xBindingByNodesStoreFieldName: function(/* dojo.data.api.Read */nodesStore, /* store item */ item,/* new value */ value){
			// summary: 
			//     Get/Set the value of the xBinding field.
			// tags:
			//	    private
			var retVal;
			if (value) {
				retVal = StoreApi.setValue(nodesStore, item, this._xBinding, value);
			} else {
				retVal = StoreApi.getValue(nodesStore, item, this._xBinding);
				if (!retVal) {
					retVal = 0;
				}
			}
			return retVal;
		},
		
		_yBindingByNodesStoreFieldName: function(/* dojo.data.api.Read */nodesStore, /* store item */ item, /* new value */ value){
			// summary: 
			//     Get/Set the value of the yBinding field.
			// tags:
			//	    private   
			var retVal;
			if (value) {
				retVal = StoreApi.setValue(nodesStore, item, this._yBinding, value);
			} else {
				retVal = StoreApi.getValue(nodesStore, item, this._yBinding);
				if (!retVal) {
					retVal = 0;
				}
				
			}
			return retVal;
			
		},
		
		// ===============================================================
		// Internal nodes/links graphical binding functions
		// ===============================================================
		
		_graphBindingByNodesStoreFieldName: function(/* dojo.data.api.Read */nodesStore, /* store item */ item,/* new value */ value){
			// summary: 
			//     Get/Set the value of the nodesGraphBinding field.
			// tags:
			//	    private
			var retVal;
			if (value) {
				var jvalue = json.toJson(value);
				retVal = StoreApi.setValue(nodesStore, item, this._nodesGraphBinding, jvalue);
			} else {
				var retValj = StoreApi.getValue(nodesStore, item, this._nodesGraphBinding);
				retVal = json.fromJson(retValj);
			}
			return retVal;
		},
		
		_graphBindingByLinksStoreFieldName: function(/* dojo.data.api.Read */nodesStore, /* store item */ item, /* new value */ value){
			// summary: 
			//     Get/Set the value of the linksGraphBinding field.
			// tags:
			//	    private   
			var retVal;
			if (value) {
				var jvalue = json.toJson(value);
				retVal = StoreApi.setValue(nodesStore, item, this._linksGraphBinding, jvalue);
			} else {
				var retValj = StoreApi.getValue(nodesStore, item, this._linksGraphBinding);
				retVal = json.fromJson(retValj);
			}
			return retVal;
		},
		
		// ===============================================================
		// Setters and Getters
		// ===============================================================
		
		_setCreateLinksForHierarchy: function(/* Boolean */value){
			// summary: 
			//     Sets the render mode.
			// tags:
			//	    private 
			this._createLinksForHierarchy = value;
			return value;
		},
		
		_getCreateLinksForHierarchy: function(){
			// summary: 
			//     Returns the render mode.
			// tags:
			//	    private 
			return this._createLinksForHierarchy;
		},
		
		_setNodesStore: function(/* dojo.data.api.Read */value){
			// summary: 
			//     Sets the nodes store. The nodes store provides data item to be 
			//     represented as nodes in the diagram. It must implement, at least, 
			//     the dojo.data.api.Read and dojo.data.api.Indentity interfaces.
			// tags:
			//	    private 
			
			// If there is already a store associated already...
			if (this._nodesStore) {
				// clear graphical shapes
				this._clearNodes();
				// drop notifications from it
				this._unwireNodesStore();
				this._nodesStoreFeatures = null;
				StoreApi.dispose(this._nodesStore);
			}
			
			if (value) {
				StoreApi.bridge(value);
				this._nodesStoreFeatures = StoreApi.getFeatures(value);
				if (this._isSupportedStore(this._nodesStoreFeatures)) {
					this._nodesStore = value;
				} else {
					StoreApi.dispose(value);
					this._nodesStore = null;
					this._nodesStoreFeatures = null;
				}
			} else {
				this._nodesStore = null;
			}
			
			// wire notifications in 
			if (this._nodesStore) {
				this._wireNodesStore();
			}
			
			return this._nodesStore;
		},
		
		_getNodesStore: function(){
			// summary: 
			//     Returns the nodes store.
			// tags:
			//	    private 
			return this._nodesStore;
		},
		
		_setLinksStore: function(/* dojo.data.api.Read */value){
			// summary: 
			//     Sets the links store. The links store provides data item to be represented
			//     as links in the diagram. It must implement at least the dojo.data.api.Read and
			//     dojo.data.api.Indentity interfaces. If no links store is specified, links
			//     are created implicitly from the nodes data store via the connections 
			//     definition as defined by the predecessorsBinding/successorsBinding properties.
			// tags:
			//	    private 
			
			// If there is already a store associated already......
			if (this._linksStore) {
				// clear graphical shapes
				this._clearLinks();
				// drop notifications from it
				this._unwireLinksStore();
				this._linksStoreFeatures = null;
				StoreApi.dispose(this._linksStore);
			}
			
			if (value) {
				StoreApi.bridge(value);
				this._linksStoreFeatures = StoreApi.getFeatures(value);
				if (this._isSupportedStore(this._linksStoreFeatures)) {
					this._linksStore = value;
				} else {
					StoreApi.dispose(value);
					this._linksStore = null;
					this._linksStoreFeatures = null;
				}
			} else {
				this._linksStore = null;
			}
			// wire notifications in 
			if (this._linksStore) {
				this._wireLinksStore();
			}
			
			
			return this._linksStore;
		},
		
		_getLinksStore: function(){
			// summary: 
			//     Returns the links store.
			// tags:
			//	    private 
			return this._linksStore;
		},
		
		_setNodesQuery: function(value){
			// summary: 
			//     Sets the nodes query.
			// tags:
			//	    private 
			var validatedQuery = null;
			if (!value || typeof value === 'string' || value instanceof Object) {
				validatedQuery = this._nodesQuery = value;
			} else {
				R.error("CannotUseAStringForAQuery");
			}
			return validatedQuery;
		},
		
		_getNodesQuery: function(){
			// summary: 
			//     Returns the nodes query.
			// tags:
			//	    private 
			return this._nodesQuery;
		},
		
		_setNodesQueryOptions: function(value){
			// summary: 
			//     Sets the nodes query options.
			// tags:
			//	    private 
			var validatedQueryOptions = null;
			validatedQueryOptions = this._nodesQueryOptions = value;
			return validatedQueryOptions;
		},
		
		_getNodesQueryOptions: function(){
			// summary: 
			//     Returns the nodes query options.
			// tags:
			//	    private 
			return this.validatedQueryOptions;
		},
		
		_setChildBinding: function(value){
			// summary: 
			//     Sets the information to tell us now to discover child items.
			// tags:
			//	    private 
			this._childBinding = value;
			if (this._childBinding instanceof Function) {
				this._childBindingFunction = value;
			} else {
				if (!this._childBinding || this._childBinding === "") {
					this._childBindingFunction = null;
				} else {
					this._childBindingFunction = this._childBindingByNodesStoreFieldName;
				}
			}
			return value;
		},
		
		_getChildBinding: function(){
			// summary: 
			//     Returns the childBinding.
			// tags:
			//	    private 
			return this._childBinding;
		},
		
		_setParentBinding: function(value){
			// summary: 
			//     Sets the information to tell us now to discover parent items.
			// tags:
			//	    private 
			this._parentBinding = value;
			if (this._parentBinding instanceof Function) {
				this._parentBindingFunction = value;
			} else {
				if (!this._parentBinding || this._parentBinding === "") {
					this._parentBindingFunction = null;
				} else {
					this._parentBindingFunction = this._parentBindingByNodesStoreFieldName;
				}
			}
			return value;
		},
		
		_getParentBinding: function(){
			// summary: 
			//     Returns the parentBinding.
			// tags:
			//	    private 
			return this._parentBinding;
		},
		
		_setPredecessorsBinding: function(value){
			// summary: 
			//     Sets the information to tell us now to discover items predecessors.
			// tags:
			//	    private 
			this._predecessorsBinding = value;
			if (this._predecessorsBinding instanceof Function) {
				this._predecessorsBindingFunction = value;
			} else {
				if (!this._predecessorsBinding || this._predecessorsBinding === "") {
					this._predecessorsBindingFunction = null;
				} else {
					this._predecessorsBindingFunction = this._predecessorsBindingByNodesStoreFieldName;
				}
			}
			return value;
		},
		
		_getPredecessorsBinding: function(){
			// summary: 
			//     Returns the predecessorsBinding.
			// tags:
			//	    private 
			return this._predecessorsBinding;
		},
		
		_setSuccessorsBinding: function(value){
			// summary: 
			//     Sets the information to tell us now to discover items to link TO.
			// tags:
			//	    private 
			this._successorsBinding = value;
			if (this._successorsBinding instanceof Function) {
				this._successorsBindingFunction = value;
			} else {
				if (!this._successorsBinding || this._successorsBinding === "") {
					this._successorsBindingFunction = null;
				} else {
					this._successorsBindingFunction = this._successorsBindingByNodesStoreFieldName;
				}
			}
			return value;
		},
		
		_getSuccessorsBinding: function(){
			// summary: 
			//     Returns the successorsBinding.
			// tags:
			//	    private 
			return this._successorsBinding;
		},
		
		_setXBinding: function(value){
			// summary: 
			//     Sets the information to tell us now to discover an items x position.
			// tags:
			//	    private 
			this._xBinding = value;
			if (this._xBinding instanceof Function) {
				this._xBindingFunction = value;
			} else {
				if (!this._xBinding || this._xBinding === "") {
					this._xBindingFunction = null;
				} else {
					this._xBindingFunction = this._xBindingByNodesStoreFieldName;
				}
			}
			return value;
		},
		
		_getXBinding: function(){
			// summary: 
			//     Returns the xBinding.
			// tags:
			//	    private 
			return this._xBinding;
		},
		
		_setYBinding: function(value){
			// summary: 
			//     Sets the information to tell us now to discover an items y position.
			// tags:
			//	    private 
			this._yBinding = value;
			if (this._yBinding instanceof Function) {
				this._yBindingFunction = value;
			} else {
				if (!this._yBinding || this._yBinding === "") {
					this._yBindingFunction = null;
				} else {
					this._yBindingFunction = this._yBindingByNodesStoreFieldName;
				}
			}
			return value;
		},
		
		_getYBinding: function(){
			// summary: 
			//     Returns the yBinding.
			// tags:
			//	    private 
			return this._yBinding;
		},
		
		_setNodesGraphBinding: function(value){
			// summary: 
			//     Sets the information to tell us now to discover an node item's graph data.
			// tags:
			//	    private 
			this._nodesGraphBinding = value;
			if (this._nodesGraphBinding instanceof Function) {
				this._nodesGraphBindingFunction = value;
			} else {
				if (!this._nodesGraphBinding || this._nodesGraphBinding === "") {
					this._nodesGraphBindingFunction = null;
				} else {
					this._nodesGraphBindingFunction = this._graphBindingByNodesStoreFieldName;
				}
			}
			return value;
		},
		
		_getNodesGraphBinding: function(){
			// summary: 
			//     Returns the _nodesGraphBinding.
			// tags:
			//	    private 
			return this._nodesGraphBinding;
		},
		
		_setNodesGraphProperties: function(nodesGraphProperties){
			// summary: 
			//     Set the list of nodes properties to save
			// tags:
			//	    private
			this._nodesGraphProperties = nodesGraphProperties;
			// Set map to null so it can be-evaluated the next time it it needed.
			this._nodesGraphFuncMap = null;
		},
		
		_getNodesGraphProperties: function(){
			// summary: 
			//     Get the list of nodes properties
			// tags:
			//	    private            
			return this._nodesGraphProperties;
		},
		
		_setCenterOnLocation: function(value){
			// summary: 
			//     Sets the centerOnLocation value.
			// tags:
			//	    private 
			this._centerOnLocation = value;
			return value;
		},
		
		_getCenterOnLocation: function(value){
			// summary: 
			//     Returns the centerOnLocation value.
			// tags:
			//	    private 
			return this._centerOnLocation;
		},
		
		
		_setLinksQuery: function(value){
			// summary: 
			//     Sets the links query.
			// tags:
			//	    private 
			var validatedQuery = null;
			if (!value || typeof value === 'string' || value instanceof Object) {
				validatedQuery = this._linksQuery = value;
			} else {
				R.error("CannotUseAStringForAQuery");
			}
			return validatedQuery;
		},
		
		_getLinksQuery: function(){
			// summary: 
			//     Returns the links query.
			// tags:
			//	    private 
			return this._linksQuery;
		},
		
		_setLinksQueryOptions: function(value){
			// summary: 
			//     Sets the links query options.
			// tags:
			//	    private 
			var validatedQueryOptions = null;
			validatedQueryOptions = this._linksQueryOptions = value;
			return validatedQueryOptions;
		},
		
		_getLinksQueryOptions: function(){
			// summary: 
			//     Returns the links query options.
			// tags:
			//	    private 
			return this.validatedQueryOptions;
		},
		
		_setLinksGraphBinding: function(value){
			// summary: 
			//     Sets the information to tell us now to discover an link item's graph data.
			// tags:
			//	    private 
			this._linksGraphBinding = value;
			if (this._linksGraphBinding instanceof Function) {
				this._linksGraphBindingFunction = value;
			} else {
				if (!this._linksGraphBinding || this._linksGraphBinding === "") {
					this._linksGraphBindingFunction = null;
				} else {
					this._linksGraphBindingFunction = this._graphBindingByLinksStoreFieldName;
				}
			}
			return value;
		},
		
		_getLinksGraphBinding: function(){
			// summary: 
			//     Returns the _linksGraphBinding.
			// tags:
			//	    private 
			return this._linksGraphBinding;
		},
		
		_setLinksGraphProperties: function(linksGraphProperties){
			// summary: 
			//     Set the list of links properties to save
			// tags:
			//	    private
			
			this._linksGraphProperties = linksGraphProperties;
			// Set map to null so it can be-evaluated the next time it it needed.
			this._linksGraphFuncMap = null;
			
		},
		
		_getLinksGraphProperties: function(){
			// summary: 
			//     Get the list of links properties
			// tags:
			//	    private
			return this._linksGraphProperties;
		},
		
		_setStartNodeBinding: function(value){
			// summary: 
			//     Sets the information to tell us now to discover an item which starts a link.
			// tags:
			//	    private 
			this._startNodeBinding = value;
			if (this._startNodeBinding instanceof Function) {
				this._startNodeBindingFunction = value;
			}
			return value;
		},
		
		_getStartNodeBinding: function(){
			// summary: 
			//     Returns the startNodeBinding.
			// tags:
			//	    private 
			return this._startNodeBinding;
		},
		
		_setEndNodeBinding: function(value){
			// summary: 
			//     Sets the information to tell us now to discover an item which ends a link.
			// tags:
			//	    private 
			this._endNodeBinding = value;
			if (this._endNodeBinding instanceof Function) {
				this._endNodeBindingFunction = value;
			}
			return value;
		},
		
		_getEndNodeBinding: function(){
			// summary: 
			//     Returns the endNodeBinding.
			// tags:
			//	    private 
			return this._endNodeBinding;
		},
		
		// ===============================================================
		// Validation functions
		// ===============================================================
		
		_isValidModel: function(){
			// summary: 
			//     Validates if we have enough information available
			//     to build a coherent collection of nodes and links
			// tags:
			//	    private 
			var isValid = false;
			
			if (this._nodesStore) {
				isValid = true;
			} else {
				R.error("NodesStoreRequired");
			}
			return isValid;
		},
		
		
		_isSupportedStore: function(features){
			// summary:
			//     Validates if the store features presented are enough to
			//     provide minimum level of functionality.
			// tags:
			//	    private 
			var isSupported = false;
			
			// ensure required interfaces are supported by the model
			if (!features.identity) {
				R.error("StoresMustSupportIdentity");
			} else {
				if (!features.canRead) {
					R.error("StoresMustSupportRead");
				} else {
					isSupported = true;
				}
			}
			return isSupported;
		},
		
		// ===============================================================
		// Node store loading functions
		// ===============================================================
		
		_buildModelFromStores: function(){
			// summary: 
			//     If nodesStore available and query supplied, load items based on the 
			//     nodesQuery and nodesQueryOptions. Then attempt to 
			//     resolve  connections from links store.
			// tags:
			//	    private 
			
			if (this._nodesStore && this._nodesQuery) {
				StoreApi.fetch(this._nodesStore, {
					query: this._nodesQuery,
					queryOptions: this._nodesQueryOptions,
					scope: this,
					onError: function(error, request){
						this.onNodesStoreFetchError.apply(this, arguments);
					},
					onComplete: function(items, request){
						for (var i = 0; i < items.length; i++) {
							this._addStoreItemToModel(items[i]);
						}
						this._resolveConnectionsFromLinksStore();
					}
				});
			} else {
				this._resolveConnectionsFromLinksStore();
			}
		},
		
		onStoreFetchError: function(error, request){
		
		},
		
		onNodesStoreFetchError: function(error, request){
			// if not on debugAtAllCosts, we won't see this
			R.warn("UnexpectedErrorOnNodesStoreFetch", error);
			this.onStoreFetchError.apply(this, arguments);
		},
		
		onLinksStoreFetchError: function(error, request){
			// if not on debugAtAllCosts, we won't see this
			R.warn("UnexpectedErrorOnLinksStoreFetch", error);
			this.onStoreFetchError.apply(this, arguments);
		},
		
		_loadNodesStoreItem: function(itemToLoad){
			// summary: 
			//     Load individual item from the nodesStore
			//     and add it to the model.
			// tags:
			//	    private 
			StoreApi.loadItem(this._nodesStore, {
				item: itemToLoad,
				scope: this,
				onError: function(error, request){
					throw error;
				},
				onItem: function(item, request){
					this._addStoreItemToModel(item);
				}
			});
		},
		
		_loadNodesStoreItemById: function(ident){
			// summary: 
			//     Load individual item from the nodesStore
			//     by it's identity and add it to the model.
			// tags:
			//	    private 
			StoreApi.fetchItemByIdentity(this._nodesStore, {
				identity: ident,
				scope: this,
				onError: function(error, request){
					this.onNodesStoreFetchError.apply(this, arguments);
				},
				onItem: function(item, request){
					this._addStoreItemToModel(item);
				}
			});
		},
		
		// ===============================================================
		// Link store loading functions
		// ===============================================================
		_getStartLinkItemId: function(linkStoreItem){
			// tags:
			//	    private 
			var startLinkItemId = null;
			
			if (this._startNodeBindingFunction) {
				var startLinkItem = this._startNodeBindingFunction.call(this, this._linksStore, linkStoreItem, this._nodesStore);
				startLinkItemId = StoreApi.getIdentity(this._nodesStore, startLinkItem);
			} else {
				startLinkItemId = StoreApi.getValue(this._linksStore, linkStoreItem, this._startNodeBinding);
			}
			return startLinkItemId;
		},
		
		_getEndLinkItemId: function(linkStoreItem){
			// tags:
			//	    private 
			var endLinkItemId = null;
			
			if (this._endNodeBindingFunction) {
				var endLinkItem = this._endNodeBindingFunction.call(this, this._linksStore, linkStoreItem, this._nodesStore);
				endLinkItemId = StoreApi.getIdentity(this._nodesStore, endLinkItem);
			} else {
				endLinkItemId = StoreApi.getValue(this._linksStore, linkStoreItem, this._endNodeBinding);
			}
			return endLinkItemId;
		},
		
		_resolveConnectionsFromLinksStore: function(){
			// summary: 
			//     If linksStore available, load items based on the 
			//     linksQuery and linksQueryOptions. Add information
			//     about the item relationships into the model, Then 
			//     attempt to resolve connections from nodes store.
			// tags:
			//	    private 
			if (this._linksStore) {
				StoreApi.fetch(this._linksStore, {
					query: this._linksQuery,
					queryOptions: this._linksQueryOptions,
					scope: this,
					onError: function(error, request){
						this.onLinksStoreFetchError.apply(this, arguments);
					},
					onComplete: function(items, request){
					
						for (var i = 0; i < items.length; i++) {
							var currentLinkStoreItem = items[i];
							var linkEntry = this._addLinkStoreItemToModel(currentLinkStoreItem);
							linkEntry.startId = this._getStartLinkItemId(currentLinkStoreItem);
							linkEntry.endId = this._getEndLinkItemId(currentLinkStoreItem);
							
							// If we have enough information to describe a link then
							// update the model. 
							if (linkEntry.startId !== null) {
								linkEntry.start = this._model.getEntry(linkEntry.startId);
							}
							if (linkEntry.endId !== null) {
								linkEntry.end = this._model.getEntry(linkEntry.endId);
							}
							
							if (!linkEntry.start || !linkEntry.end) {
								linkEntry.pending = true;
							}
						}
						this._resolveConnectionsFromNodesStore();
					}
				});
			} else {
				this._resolveConnectionsFromNodesStore();
			}
		},
		
		// ===============================================================
		// NodeStore Notification-related functions
		// ===============================================================
		
		_wireNodesStore: function(){
			// summary: 
			//     If the nodesStore supports notification, register to be informed of any changes
			// tags:
			//	    private  
			if (this._nodesStore) {
				var features = this._nodesStoreFeatures, args;
				if (features.canNotify) {
					args = {
						scope: this,
						onNew: this._onNewNodeItem,
						onUpdate: this._onSetNodeItem,
						onRemove: this._onDeleteNodeItem
					};
					/*
					
					 this._nodesStoreConnectHandles = new ArrayList();
					
					 this._nodesStoreConnectHandles.add(connect.connect(this._nodesStore, "onNew", this, "_onNewNodeItem"));
					
					 this._nodesStoreConnectHandles.add(connect.connect(this._nodesStore, "onSet", this, "_onSetNodeItem"));
					
					 this._nodesStoreConnectHandles.add(connect.connect(this._nodesStore, "onDelete", this, "_onDeleteNodeItem"));
					
					 */
					
				}
				
				if (features.canWrite) {
					if (!args) {
						args = {
							scope: this
						}
					}
					lang.mixin(args, {
						onSave: this._onSaveNodesStore,
						onRevert: this._onRevertNodesStore
					})
					/*
					 this._nodesStoreConnectHandles.add(connect.connect(this._nodesStore, "save", this, "_onSaveNodesStore"));
					 this._nodesStoreConnectHandles.add(connect.connect(this._nodesStore, "revert", this, "_onRevertNodesStore"));
					 */
					// the connections to _onChanged and onBoundsChanged node events
					this._onNodeChangedHandlers = {};
				}
				if (args) {
					var h = StoreApi.listen(this._nodesStore, args);
					this._nodesStoreConnectHandles = new ArrayList(h);
				}
				
			}
		},
		
		_unwireNodesStore: function(){
			// summary:
			//     unregister any nodesStore notifications we may have set.
			// tags:
			//	    private 
			if (this._nodesStoreConnectHandles && this._nodesStoreConnectHandles.count > 0) {
				this._nodesStoreConnectHandles.forEach(function(entry){
					//connect.disconnect(entry);
					entry.remove();
				}, this);
				this._nodesStoreConnectHandles = null;
			}
			// the content of _onNodeChangedHandlers is disposed on a per-node basis, in _nodeDispose()
			this._onNodeChangedHandlers = null;
		},
		
		_connectItemsInExistingDiagram: function(parentItem, childItem, isHierarchicalConnection){
			// summary:
			//     utility function which connects a new node into an existing diagram.
			// tags:
			//	    private 
			
			// console.info("_connectItemsInExistingDiagram");
			// console.info("\tparentItem=" + parentItem ? this._nodesStore.getIdentity(parentItem) : "null");
			// console.info("\childItem=" + childItem ? this._nodesStore.getIdentity(childItem) : "null");
			
			var parentNode = this._getNodeFromStoreItem(parentItem);
			var childNode = this._getNodeFromStoreItem(childItem);
			
			
			if (this._createLinksForHierarchy || !isHierarchicalConnection) {
				// console.info("_createLinksForHierarchy=true");
				if (!childNode) {
					var entry = this._addStoreItemToModel(childItem);
					childNode = entry.node = this.createNode(null, childItem);
					this._applyNodeStoreItemGraphics(entry.node);
				}
				if (!parentNode) {
					var entry = this._addStoreItemToModel(parentItem);
					parentNode = entry.node = this.createNode(null, parentItem);
					this._applyNodeStoreItemGraphics(entry.node);
				}
				var link = this.connectNodes(parentNode, childNode);
			} else {
				// console.info("_createLinksForHierarchy=false");
				if (!childNode) {
				
					if (parentNode && parentNode._isIBMDiagramSubgraph) {
						// console.info("parentNode is Subgraph");
						var entry = this._addStoreItemToModel(childItem);
						childNode = entry.node = this.createNode(null, childItem, parentNode.getGraph());
						this._applyNodeStoreItemGraphics(entry.node);
					} else {
						// console.info("parentNode is Node");
						// parent node needs to change from node to subgraph
						//
						var entry = this._addStoreItemToModel(childItem);
						var parentSubgraph = this.createSubgraph(null, parentItem, parentNode.getParent());
						// Set this subgraph in the the model
						this._setNodeFromStoreItem(parentItem, parentSubgraph);
						childNode = entry.node = this.createNode(null, childItem, parentSubgraph.getGraph());
						// then re-wire linked node to the new subgraph                        
						array.forEach(parentNode.getLinks(true, false), function(link){
							var port = new port.AutomaticPort();
							parentSubgraph.addPort(port);
							link.setStartPort(port);
						});
						array.forEach(parentNode.getLinks(false, true), function(link){
							var port = new port.AutomaticPort();
							parentSubgraph.addPort(port);
							link.setEndPort(port);
						});
						// dispose of the old parentNode
						this._nodeDispose(parentNode, parentItem);
						
						// position child node, then parent subgraph
						this._applyNodeStoreItemGraphics(childNode);
						this._applyNodeStoreItemGraphics(parentSubgraph);
						
					}
				} else {
					// Situation does not occur in current function usage..
				}
			}
		},
		
		_onNodeChangedHandlers: null,
		
		_addOnChangedHandler: function(node, event, handler){
			var h = connect.connect(node, event, this, handler);
			var hl = this._onNodeChangedHandlers[node.getId()];
			if (!hl) {
				hl = [];
				this._onNodeChangedHandlers[node.getId()] = hl;
			}
			hl.push(h);
		},
		
		_clearOnChangedHandlers: function(node){
			if (!this._onNodeChangedHandlers) 
				return;
			var id = node.getId(), hl = this._onNodeChangedHandlers[id];
			if (!hl) 
				return;
			array.forEach(hl, function(h){
				connect.disconnect(h);
			});
			hl.length = 0;
			delete this._onNodeChangedHandlers[id];
		},
		
		// ===============================================================
		//  Function to extract/store graphical information in the nodes 
		//  store itself
		// ===============================================================
		_applyNodeStoreItemGraphics: function(node){
			// summary:
			//     Applies any graphical information to a node/subgraph
			//     that is stored in the nodesStore item, specifically..
			//     (a) TBD from the specified function
			//     (b) x/y positioning.
			// tags:
			//	    private 
			if (this._nodesGraphBindingFunction || this._xBindingFunction || this._yBindingFunction) {
			
				var item = node.getData().item, isWrite = this._nodesStoreFeatures.canWrite;
				
				if (this._nodesGraphBindingFunction) {
					var gfxInfo = this._nodesGraphBindingFunction.call(this, this._nodesStore, item);
					if (gfxInfo) {
						this._applyProperties(node, gfxInfo);
					}
					
					// If store supports write then monitor node for changes
					if (isWrite) {
						this._addOnChangedHandler(node, '_onChanged', function(){
							if (this._nodesGraphBindingFunction && node.getData && node.getData()) {
							
								var nitem = node.getData().item;
								if (nitem && StoreApi.isItem(this._nodesStore, nitem)) {
									try {
										this._internalSet = true;
										
										var gfxInfo = this._extractProperties(node, this._nodesGraphProperties);
										this._nodesGraphBindingFunction.call(this, this._nodesStore, nitem, gfxInfo);
									} finally {
										this._internalSet = false;
									}
								}
							}
						});
					}
				}
				if (this._xBindingFunction || this._yBindingFunction) {
				
					var posx = 0;
					var posy = 0;
					
					if (this._xBindingFunction) {
						posx = this._xBindingFunction.call(this, this._nodesStore, item);
					}
					if (this._yBindingFunction) {
						posy = this._yBindingFunction.call(this, this._nodesStore, item);
					}
					if (this._centerOnLocation) {
						var bounds = node.getBounds();
						posx = posx - (bounds.width / 2);
						posy = posy - (bounds.height / 2);
					}
					
					node.move(posx, posy);
					
					// If store supports write then monitor node for changes
					if (isWrite) {
						this._addOnChangedHandler(node, "onBoundsChanged", function(shape, reason){
							if (reason === "setTransform" && shape.getData && shape.getData()) {
							
								var posx = 0;
								var posy = 0;
								
								var bounds = shape.getBounds();
								
								if (this._centerOnLocation) {
									posx = bounds.x + (bounds.width / 2);
									posy = bounds.y + (bounds.height / 2);
								} else {
									posx = bounds.x;
									posy = bounds.y;
								}
								
								var sitem = shape.getData().item;
								if (sitem && StoreApi.isItem(this._nodesStore, sitem)) {
									if (this._xBindingFunction) {
										// read the current x value and only write new one if they are different
										var curposx = this._xBindingFunction.call(this, this._nodesStore, sitem);
										if (curposx !== posx) {
											try {
												this._internalSet = true;
												this._xBindingFunction.call(this, this._nodesStore, sitem, posx);
											} finally {
												this._internalSet = false;
												
											}
										}
									}
									if (this._yBindingFunction) {
										// read the current y value and only write new one if they are different
										var curposy = this._yBindingFunction.call(this, this._nodesStore, sitem);
										if (curposy !== posy) {
											try {
												this._internalSet = true;
												this._yBindingFunction.call(this, this._nodesStore, sitem, posy);
											} finally {
												this._internalSet = false;
											}
										}
									}
								}
							}
						});
					}
				}
			}
		},
		
		_connectItems: function(item, filteritem){
			// summary:
			//     Resolve and links through to/from/parent/child bindings
			//     filternode can be specified to limit resolution 
			//     between just the "item" node and a filter node
			// tags:
			//	    private 
			if (this._successorsBindingFunction) {
				var connectingItems = this._successorsBindingFunction.call(this, this._nodesStore, item);
				if (connectingItems) {
					array.forEach(connectingItems, function(connectingItem){
						if (!filteritem || filteritem === connectingItem) {
							this._connectItemsInExistingDiagram(item, connectingItem, false);
						}
					}, this);
				}
			}
			
			if (this._predecessorsBindingFunction) {
				var connectingItems = this._predecessorsBindingFunction.call(this, this._nodesStore, item);
				if (connectingItems) {
					array.forEach(connectingItems, function(connectingItem){
						if (!filteritem || filteritem === connectingItem) {
							this._connectItemsInExistingDiagram(connectingItem, item, false);
						}
					}, this);
				}
			}
			
			if (this._parentBindingFunction) {
				var connectingItems = this._parentBindingFunction.call(this, this._nodesStore, item);
				if (connectingItems) {
					array.forEach(connectingItems, function(connectingItem){
						if (!filteritem || filteritem === connectingItem) {
							this._connectItemsInExistingDiagram(connectingItem, item, true);
						}
					}, this);
				}
			}
			
			if (this._childBindingFunction) {
				var connectingItems = this._childBindingFunction.call(this, this._nodesStore, item);
				if (connectingItems) {
					array.forEach(connectingItems, function(connectingItem){
						if (!filteritem || filteritem === connectingItem) {
							this._connectItemsInExistingDiagram(item, connectingItem, true);
						}
					}, this);
				}
			}
			
		},
		
		acceptNewItem:function(item, isNode){
			// summary:
			//		Returns whether the specified new item should be processed. 
			// description:
			//		This method is invoked when a new item has been added to the data store.
			//		The default implementation returns true, meaning that a corresponding Node or Link
			//		instance is created for every new items.
			// item: Object
			//		the new data item.
			// isNode: Boolean
			//		Whether the item represents a Node or a Link item.
			// returns:
			//		A Boolean indicating whether the specified new item should be processed.
			return true; // Boolean
		},
		
		_onNewNodeItem: function(newItem, parentInfo){
			// summary:
			//		called when a new item is added to the nodesStore.
			// tags:
			//		private 
			
			// console.info("DataConnector._onNewNodeItem id=" + this._nodesStore.getIdentity(newItem) + ",parentInfo=" + (parentInfo ? this._nodesStore.getIdentity(parentInfo.item) : "no parent"));
			
			if (!this.acceptNewItem(newItem, true /* true = node*/)){
				return;
			}
			
			// connect this item to others, possibly creating a node/subgraph in the process
			this._connectItems(newItem, null);
			
			// Check if a parent has been defined
			if (parentInfo) {
				var parentNode = this._getNodeFromStoreItem(parentInfo.item);
				if (parentNode) {
					this._connectItems(parentInfo.item, newItem);
				}
			}
			
			// if a node/subgraph is not yet created for this item. then create one
			if (!this._getNodeFromStoreItem(newItem)) {
				var entry = this._addStoreItemToModel(newItem);
				entry.node = this.createNode(null, newItem);
				this._applyNodeStoreItemGraphics(entry.node);
			}
			
			// Check if this item completes any pending links
			// Create links from lists in the link model 
			var nodeEntry = this._model.getEntry(StoreApi.getIdentity(this._nodesStore, newItem));
			this._model.forEachPendingLinkEntry(function(linkEntry, nodeEntry){
				if (!linkEntry.start) {
					if (nodeEntry.id === linkEntry.startId) {
						linkEntry.start = nodeEntry;
					}
					
				}
				if (!linkEntry.end) {
					if (nodeEntry.id === linkEntry.endId) {
						linkEntry.end = nodeEntry;
					}
				}
				if (linkEntry.start && linkEntry.end) {
					// We have found a pending link which can be completed with this item 
					linkEntry.link = this.connectNodes(linkEntry.start.node, linkEntry.end.node, null, linkEntry.item);
					this._applyLinkStoreItemGraphics(linkEntry.link);
					linkEntry.pending = false;
				}
			}, nodeEntry, this);
		},
		
		_onDeleteNodeItem: function(item){
			// summary:
			//     called when an item is deleted from the nodesStore.
			// tags:
			//	    private 
			
			// console.info("DataConnector._onDeleteNodeItem id=" + this._nodesStore.getIdentity(item));
			// We first need to iteratively process any child items, as these
			// would not have been loaded if this potential parent 
			// not existed originally. Unfortunately we can't use the _childBindingFunction
			// to achieve this, as the datastore considers that the item currently being 
			// processed has been deleted. We'll need to find the children from the model instead.
			var id = StoreApi.getIdentity(this._nodesStore, item);
			var shape = this._getNodeFromStoreItem(item);
			var dc = this;
			if (shape) {
				array.forEach(shape.getLinks(), function(link){
					dc._linkDispose(link);
				});
				this._nodeDispose(shape, item);
			}
			this._model.removeEntry(id);
			
		},
		
		_getExtraElements: function(Array1, Array2){
			// tags:
			//	    private 
			var extras = [];
			for (var i = 0; i < Array2.length; i++) {
				var arrlen = Array1.length;
				var j = 0;
				for (j = 0; j < arrlen; j++) {
					if (Array2[i] === Array1[j]) {
						break;
					}
				}
				if (j === arrlen) {
					// this element was not found
					extras.push(Array2[i]);
				}
			}
			return extras;
		},
		
		_onSetNodeItem: function(modifiedItem, attribute, oldValue, newValue){
			// summary:
			//     called when an item in nodesStore changes.
			//     This code is only interested in changes in attributes related to
			//     - store item relationships.
			//     - store item label.
			//     - x/y position
			//
			// tags:
			//	    private 
			
			// console.info("DataConnector._onSetNodeItem id=" + this._nodesStore.getIdentity(modifiedItem) + ",attribute=" + attribute + ",old=" + oldValue + ",new=" + newValue);
			
			if (this._internalSet) 
				return;
			
			if (StoreApi.fromDojoStore(this._nodesStore)) {
				var entry = this._model.getEntry(StoreApi.getIdentity(this._nodesStore, modifiedItem));
				if (entry._bindingBackup) {
					var bo = this._getChangedNodeBindingValues(entry, true /*update backup val with new val*/);
					if (bo) {
						attribute = bo.p;
						oldValue = bo.o;
						newValue = bo.n;
					}
				}
			}
			
			var shape = this._getNodeFromStoreItem(modifiedItem);
			if (shape) {
			
				var oldState;
				var newState;
				
				if (StoreApi.isItem(this._nodesStore, oldValue)) {
					oldState = [oldValue];
				} else {
					oldState = oldValue || [];
				}
				
				if (StoreApi.isItem(this._nodesStore, newValue)) {
					newState = [newValue];
				} else {
					newState = newValue || [];
				}
				
				if (oldState instanceof Array && newState instanceof Array) {
					var newItems = this._getExtraElements(oldState, newState);
					var deletedItems = this._getExtraElements(newState, oldState);
					// Look to remove links between this shape and the deleted items
					// console.info("deletedItems.length=" + deletedItems.length);
					for (var i = 0; i < deletedItems.length; i++) {
						var shape2 = this._getNodeFromStoreItem(deletedItems[i]);
						// console.info("\titem=" + i + " shape2=" + shape2 + " item=" + deletedItems[i].name);
						var connections = shape.getLinks();
						for (var j = 0; j < connections.length; j++) {
							var link = connections[j];
							if (link.getEndNode() === shape2) {
								this._linkDispose(link);
							}
						}
						connections = shape2.getLinks();
						for (var j = 0; j < connections.length; j++) {
							var link = connections[j];
							if (link.getEndNode() === shape) {
								this._linkDispose(link);
							}
						}
					}
					// console.info("newItems.length=" + newItems.length);
					// Add links between this shape and the new item					
					for (var i = 0; i < newItems.length; i++) {
						this._connectItems(newItems[i], modifiedItem);
						this._connectItems(modifiedItem, newItems[i]);
					}
					
				}
				
				// Update Node label
				// check if the updated attribute is involved in the label
				var attr = StoreApi.getLabelAttributes(this._nodesStore, modifiedItem);
				if (attr) {
					for (var i = 0; i < attr.length; ++i) {
						if (attr[i] === attribute) {
							var label = StoreApi.getLabel(this._nodesStore, modifiedItem);
							shape.setLabel(newValue);
							break;
						}
					}
				}
				
				// Update Node position
				this._applyNodeStoreItemGraphics(shape);
			}
		},
		
		_onSaveNodesStore: function(){
			// summary:
			//     called after the nodesStore has been saved.
			//     we simply request a complete redraw of the diagram.
			// tags:
			//	    private 
			
			// console.info("DataConnector._onSaveNodesStore");
			this.reset();
			this._load();
		},
		
		_onRevertNodesStore: function(){
			// summary:
			//     called after the nodesStore has reverted back to the last "saved" state.
			//     we simply request a complete redraw of the diagram.
			// tags:
			//	    private 
			
			// console.info("DataConnector._onRevertNodesStore");
			this.reset();
			this._load();
		},
		
		// ===============================================================
		// LinkStore Notification-related functions
		// ===============================================================
		
		_wireLinksStore: function(){
			// summary: 
			//     If the nodesStore supports notification, register to be informed of any changes
			// tags:
			//	    private    
			if (this._linksStore) {
				var features = this._linksStoreFeatures, args;
				if (features.canNotify) {
					args = {
						scope: this,
						onNew: this._onNewLinkItem,
						onUpdate: this._onSetLinkItem,
						onRemove: this._onDeleteLinkItem
					};
					/*
					
					 this._linksStoreConnectHandles = new ArrayList();
					
					 this._linksStoreConnectHandles.add(connect.connect(this._linksStore, "onNew", this, "_onNewLinkItem"));
					
					 this._linksStoreConnectHandles.add(connect.connect(this._linksStore, "onSet", this, "_onSetLinkItem"));
					
					 this._linksStoreConnectHandles.add(connect.connect(this._linksStore, "onDelete", this, "_onDeleteLinkItem"));
					
					 */
					
				}
				
				if (features.canWrite) {
					if (!args) {
						args = {
							scope: this
						}
					}
					lang.mixin(args, {
						onSave: this._onSaveLinksStore,
						onRevert: this._onRevertLinksStore
					})
					/*
					 this._linksStoreConnectHandles.add(connect.connect(this._linksStore, "save", this, "_onSaveLinksStore"));
					 this._linksStoreConnectHandles.add(connect.connect(this._linksStore, "revert", this, "_onRevertLinksStore"));
					 */
					this._onLinkShapeHandlers = {};
				}
				if (args) {
					var h = StoreApi.listen(this._linksStore, args);
					this._linksStoreConnectHandles = new ArrayList(h);
				}
				
			}
		},
		
		_unwireLinksStore: function(){
			// summary:
			//     unregister any nodesStore notifications we may have set.
			// tags:
			//	    private 
			if (this._linksStoreConnectHandles && this._linksStoreConnectHandles.count > 0) {
				this._linksStoreConnectHandles.forEach(function(entry){
					//connect.disconnect(entry);
					entry.remove();
				}, this);
				this._linksStoreConnectHandles = null;
			}
			this._onLinkShapeHandlers = null;
		},
		
		_onNewLinkItem: function(newitem, parentInfo){
			// summary:
			//     called when a new item added to the linksStore.
			// tags:
			//	    private 

			if (!this.acceptNewItem(newitem, false /* false = link*/)){
				return;
			}
			
			var id = StoreApi.getIdentity(this._linksStore, newitem);
			// console.info("DataConnector._onNewLinkItem id=" + id + " parentInfo=" + parentInfo);
			var linkEntry = this._addLinkStoreItemToModel(newitem);
			linkEntry.startId = this._getStartLinkItemId(newitem);
			linkEntry.endId = this._getEndLinkItemId(newitem);
			if (linkEntry.startId !== null && linkEntry.endId !== null) {
				linkEntry.start = this._model.getEntry(linkEntry.startId);
				linkEntry.end = this._model.getEntry(linkEntry.endId);
				if (linkEntry.start && linkEntry.end) {
					linkEntry.pending = false;
					linkEntry.link = this.connectNodes(linkEntry.start.node, linkEntry.end.node, null, newitem);
					this._applyLinkStoreItemGraphics(linkEntry.link);
				} else {
					linkEntry.pending = true;
				}
			}
		},
		
		_onDeleteLinkItem: function(item){
			// summary:
			//     called when an item is deleted from the linksStore.
			// tags:
			//	    private 
			
			// console.info("DataConnector._onDeleteLinkItem id=" + id);
			var link = this._getLinkFromStoreItem(item);
			this._linkDispose(link, item);
		},
		
		_onSetLinkItem: function(item, attribute, oldValue, newValue){
			// summary:
			//     called when an item in linksStore changes. 
			// tags:
			//	    private 
			
			// console.info("DataConnector._onSetLinkItem id=" + this._linksStore.getIdentity(item) + ",attribute=" + attribute + ",old=" + oldValue + ",new=" + newValue);
			
			if (this._internalSet) 
				return;
			
			var id = StoreApi.getIdentity(this._linksStore, item);
			var linkEntry = this._model.getLinkEntry(id);
			if (linkEntry) {
				var oldStartLinkItemId = linkEntry.startId;
				var oldEndLinkItemId = linkEntry.endId;
				var newStartLinkItemId = this._getStartLinkItemId(item);
				var newEndLinkItemId = this._getEndLinkItemId(item);
				
				if ((oldStartLinkItemId !== newStartLinkItemId) || (oldEndLinkItemId !== newEndLinkItemId)) {
					// The start and/or end point for this link has been changed
					this._linkDispose(linkEntry.link, item);
					linkEntry.link = null;
					
					if (oldStartLinkItemId !== newStartLinkItemId) {
						linkEntry.startId = newStartLinkItemId;
						linkEntry.start = this._model.getEntry(newStartLinkItemId);
					}
					if (oldEndLinkItemId !== newEndLinkItemId) {
						linkEntry.endId = newEndLinkItemId;
						linkEntry.end = this._model.getEntry(newEndLinkItemId);
					}
					
					if (linkEntry.start && linkEntry.end) {
						linkEntry.pending = false;
						linkEntry.link = this.connectNodes(linkEntry.start.node, linkEntry.end.node, null, item);
						this._applyLinkStoreItemGraphics(linkEntry.link);
					} else {
						linkEntry.pending = true;
					}
				}
			}
		},
		
		_onSaveLinksStore: function(){
			// summary:
			//     called after the linksStore has been saved.
			//     we simply request a complete redraw of the diagram.
			// tags:
			//	    private 
			
			// console.info("DataConnector._onSaveLinksStore");
			this.reset();
			this._load();
		},
		
		_onRevertLinksStore: function(){
			// summary:
			//     called after the linksStore has reverted back to the last "saved" state.
			//     we simply request a complete redraw of the diagram.
			// tags:
			//	    private 
			
			// console.info("DataConnector._onRevertLinksStore");
			this.reset();
			this._load();
		},
		
		// a simple hashtable (ie {} ) for invalidateLinkShape connect handlers
		_onLinkShapeHandlers: null,
		
		_addLinkShapeHandler: function(link, handler){
			var h = connect.connect(link, 'invalidateLinkShape', this, handler);
			this._onLinkShapeHandlers[link.getId()] = h;
		},
		
		_clearLinkShapeHandlers: function(link){
			if (!this._onLinkShapeHandlers) 
				return;
			var id = link.getId(), h = this._onLinkShapeHandlers[id];
			if (h) 
				connect.disconnect(h);
			delete this._onNodeChangedHandlers[id];
		},
		
		// ===============================================================
		//  Function to extract/store graphical information in the Links 
		//  datastore itself
		// ===============================================================
		_applyLinkStoreItemGraphics: function(link){
			// summary:
			//     Applies any graphical information to a node/subgraph
			//     that is stored in the nodesStore item, specifically..
			//     (a) TBD from the specified function
			//     (b) x/y positioning.
			// tags:
			//	    private 
			
			if (link.getData) {
			
				var item = link.getData().item;
				
				if (this._linksGraphBindingFunction) {
					var gfxInfo = this._linksGraphBindingFunction.call(this, this._linksStore, item);
					if (gfxInfo) {
						this._applyProperties(link, gfxInfo);
					}
					
					// If store supports write then monitor link for changes
					if (this._linksStoreFeatures.canWrite) {
						this._addLinkShapeHandler(link, function(){
							if (this._linksGraphBindingFunction && link.getData()) {
								var litem = link.getData().item;
								if (litem && StoreApi.isItem(this._linksStore, litem)) {
									try {
										this._internalSet = true;
										var gfxInfo = this._extractProperties(link, this._linksGraphProperties);
										this._linksGraphBindingFunction.call(this, this._linksStore, litem, gfxInfo);
									} finally {
										this._internalSet = false;
									}
								}
							}
						});
					}
				}
			}
		},
		
		// ===============================================================
		// Graphics-properties-related functions
		// ===============================================================
		
		_getPropFuncMap: function(o, proplist){
			// summary: 
			//     For a particular list of properties return a map 
			//     of property names to function names
			// tags:
			//	    private         
			var funcMap = o._isIBMDiagramNode ? this._nodesGraphFuncMap : this._linksGraphFuncMap;
			if (!funcMap) {
				var props = proplist.split(",");
				funcMap = {};
				for (var i = 0; i < props.length; i++) {
					var getName = "get" + props[i].charAt(0).toUpperCase() + props[i].substring(1);
					if (o[getName] && (o[getName] instanceof Function)) {
						funcMap[props[i]] = getName;
					} else {
						var isName = "is" + props[i].charAt(0).toUpperCase() + props[i].substring(1);
						if (o[isName] && (o[isName] instanceof Function)) {
							funcMap[props[i]] = isName;
						}
					}
				}
				
				if (o._isIBMDiagramNode) 
					this._nodesGraphFuncMap = funcMap;
				else this._linksGraphFuncMap = funcMap;
			}
			return funcMap;
		},
		
		_extractProperties: function(o, props){
			// summary: 
			//     Extracts a subset of properties of an object, given a 
			//     list of getter functions. Function names are assumed to
			//     be of the form isXXX or getXXX
			// tags:
			//	    private 
			var extracted = {};
			
			var funcMap = this._getPropFuncMap(o, props);
			for (var pname in funcMap) {
				extracted[pname] = o[funcMap[pname]]();
			}
			return extracted;
		},
		
		_applyProperties: function(o, props){
			// summary: 
			//     Applies properties to an object. Setter functions are 
			//     determined, based on the property names.
			//     for property name xxxx, setter function is setXxxx.
			// tags:
			//	    private 
			for (var prop in props) {
				if (props.hasOwnProperty(prop)) {
					var setfunc = 'set' + prop.charAt(0).toUpperCase() + prop.substring(1);
					if (o[setfunc] && (o[setfunc] instanceof Function)) {
						o[setfunc](props[prop]);
					}
				}
			}
		},
		
		// ===============================================================
		// Model-related functions
		// ===============================================================
		
		_addStoreItemToModel: function(item){
			// summary: 
			//     Add a store item into the model.
			// tags:
			//	    private 
			
			var id = StoreApi.getIdentity(this._nodesStore, item);
			
			var entry = this._model.getEntry(id);
			
			if (!entry) {
				entry = this._model.addEntry(id);
			}
			this._model.setEntryItem(entry, item);
			if (StoreApi.fromDojoStore(this._nodesStore)) {
				this._backupNodeBindingValues(entry);
			}
			
			this._completeModelConstruction();
			
			return entry;
		},
		
		_addLinkStoreItemToModel: function(item){
			// summary: 
			//     Add a store item into the model.
			// tags:
			//	    private 
			
			var id = StoreApi.getIdentity(this._linksStore, item);
			
			var entry = this._model.getLinkEntry(id);
			
			if (!entry) {
				entry = this._model.addLinkEntry(id);
			}
			this._model.setLinkEntryItem(entry, item);
			return entry;
		},
		
		_backupNodeBindingValues: function(entry){
			this._backupBindingValues(this._nodesStore, entry, nodesBindingProperties)
		},
		
		_backupLinkBindingValues: function(entry){
			this._backupBindingValues(this._linksStore, entry, linksBindingProperties)
		},
		
		_backupBindingValues:function(store, entry, properties){
			entry._bindingBackup = {};
			array.forEach(properties, function(p){
				var v = this[p];
				if (typeof v !== 'undefined' && !(this[p] instanceof Function)) {
					entry._bindingBackup[p] = StoreApi.getValue(store, entry.item, v);
				}
			}, this);
		},
		_getChangedNodeBindingValues: function(entry, update){
		
			return this._getChangedBindingValues(this._nodesStore, entry, nodesBindingProperties, update);
		},
		
		_getChangedLinkBindingValues: function(entry, update){
			return this._getChangedBindingValues(this._linksStore, entry, linksBindingProperties, update);
		},
		
		_getChangedBindingValues: function(store, entry, properties, update){
			if (entry._bindingBackup) {
				var t = properties;
				for (var i = 0; i < t.length; ++i) {
					var v = this[t[i]], val;
					if (typeof v !== 'undefined' &&
						!(this[t[i]] instanceof Function) &&
						entry._bindingBackup[t[i]] !== (val = StoreApi.getValue(store, entry.item, v))) {
						var result = {
							p: t[i], // changed attribute
							o: entry._bindingBackup[t[i]], // old val
							n: val //new val
						};
						if (update) {
							entry._bindingBackup[t[i]] = val;
						}
						return result;
					}
				};
			}
		},
		
		_completeModelConstruction: function(){
			// summary: 
			//     Called after the all model entries have been created
			// tags:
			//	    private 
			
			// When all model entries have been creates and their items loaded..            
			if (this._model.isModelComplete()) {
				//                
				// Assumptions made for hierarchies
				// - An entry with an empty to-list is a leaf node 
				// - The from-list length will by not longer than 1
				
				this._model.forEachEntry(function(entry){
					var childlist = entry.childlist;
					var parentlist = entry.parentlist;
					if (childlist.length > 0) {
					
						for (var t = 0; t < childlist.length; t++) {
							var childEntry = this._model.getEntry(childlist[t]);
							childEntry.parent = entry;
							entry.children.push(childEntry);
						}
					}
					if (parentlist.length === 1) {
						var parentEntry = this._model.getEntry(parentlist[0]);
						entry.parent = parentEntry;
						parentEntry.children.push(entry);
					}
				}, this);
				
				this._onModelCreated(this._model);
				this._createShapesFromModel();
			}
		},
		
		_onModelCreated: function(/* ibm_ilog.diagram.widget._DataModel */model){
			// summary: 
			//     Function which is called when the model is complete.
			// tags:
			//	    private 
		
			// model.dumpToConsole();
		},
		
		_resolveConnectionsFromNodesStore: function(){
			// summary: 
			//     Attempt to resolve (discover relationship information for) 
			//     nodesStore items. Add information about the item relationships
			//     into the model. Repeat until all are resolved.
			//     Note that item-connecting information can be provided either
			//     by registered binding functions or from the link store.
			// tags:
			//	    private        
			var unresolved = [];
			
			this._model.forEachUnresolvedEntry(function(entry){
			
				var currentItem = entry.item;
				
				if (this._parentBindingFunction) {
					var connectingItems = this._parentBindingFunction.call(this, this._nodesStore, currentItem);
					array.forEach(connectingItems, function(connectingItem){
						var ident = StoreApi.getIdentity(this._nodesStore, connectingItem);
						
						if (this._model.containsEntry(ident)) {
							entry.parentlist.push(ident);
						}
					}, this);
				}
				
				if (this._childBindingFunction) {
					var connectingItems = this._childBindingFunction.call(this, this._nodesStore, currentItem);
					array.forEach(connectingItems, function(connectingItem){
						var ident = StoreApi.getIdentity(this._nodesStore, connectingItem);
						if (this._model.containsEntry(ident)) {
							entry.childlist.push(ident);
							
						}
					}, this);
				}
				
				if (this._successorsBindingFunction) {
					var connectingItems = this._successorsBindingFunction.call(this, this._nodesStore, currentItem);
					array.forEach(connectingItems, function(connectingItem){
						var ident = StoreApi.getIdentity(this._nodesStore, connectingItem);
						if (this._model.containsEntry(ident)) {
							entry.tolist.push(ident);
						}
					}, this);
				}
				
				if (this._predecessorsBindingFunction) {
					var connectingItems = this._predecessorsBindingFunction.call(this, this._nodesStore, currentItem);
					array.forEach(connectingItems, function(connectingItem){
						var ident = StoreApi.getIdentity(this._nodesStore, connectingItem);
						if (this._model.containsEntry(ident)) {
							entry.fromlist.push(ident);
						}
					}, this);
				}
				
				entry.resolved = true;
			}, this);
			
			// If all items are resolved and the model is fully populated, otherwise add 
			// new entries in the model 
			if (unresolved.length === 0) {
				this._model.setAllEntriesAdded();
				this._completeModelConstruction();
			} else {
				for (var i = 0; i < unresolved.length; i++) {
					if (StoreApi.isItemLoaded(this._nodesStore, unresolved[i])) {
						this._addStoreItemToModel(unresolved[i]);
					} else {
						this._loadNodesStoreItem(unresolved[i]);
					}
				}
				this._resolveConnectionsFromNodesStore();
			}
		},
		
		// ===============================================================
		// Shape mapping functions
		// ===============================================================
		
		_getNodeFromStoreItem: function(item){
			// summary:
			//        Gets the GFX object, for the given Node Data Item.
			// tags:
			//	    private 
			
			var node = null;
			var id = StoreApi.getIdentity(this._nodesStore, item);
			var nodeModelEntry = this._model.getEntry(id);
			if (nodeModelEntry) {
				node = nodeModelEntry.node;
			}
			return node;
		},
		
		_setNodeFromStoreItem: function(item, node){
			// summary:
			//        Sets the GFX object, associating it with the given Node Data Item.
			// tags:
			//	    private 
			
			var id = StoreApi.getIdentity(this._nodesStore, item);
			var nodeModelEntry = this._model.getEntry(id);
			if (nodeModelEntry) {
				nodeModelEntry.node = node;
			}
		},
		
		
		_getLinkFromStoreItem: function(item){
			// summary:
			//        Gets the GFX object, for the given Link Data Item.
			// tags:
			//	    private 
			var link = null;
			var id = StoreApi.getIdentity(this._linksStore, item);
			var linkModelEntry = this._model.getLinkEntry(id);
			if (linkModelEntry) {
				link = linkModelEntry.link;
			}
			return link;
		},
		
		// ===============================================================
		// Nodes, Subgraphs and Links creation
		// ===============================================================
		_createLinksFromModel: function(){
			// summary: 
			//     Based on options provided, create explicit links objects
			//     associated with the nodeStore items and their
			//     relationships.
			// tags:
			//	    private 
			
			// Create links from lists in the node model 
			this._model.forEachEntry(function(entry){
				var currentNode;
				var childlist = entry.childlist;
				var parentlist = entry.parentlist;
				var tolist = entry.tolist;
				var fromlist = entry.fromlist;
				if (this._createLinksForHierarchy) {
				
					if (childlist.length + parentlist.length > 0) {
						currentNode = entry.node;
						var link;
						for (var t = 0; t < childlist.length; t++) {
							var childNode = this._model.getEntry(childlist[t]).node;
							link = this.connectNodes(currentNode, childNode);
						}
						for (var f = 0; f < parentlist.length; f++) {
							var parentNode = this._model.getEntry(parentlist[f]).node;
							link = this.connectNodes(parentNode, currentNode);
						}
					}
				}
				if (tolist.length + fromlist.length > 0) {
					currentNode = entry.node;
					var link;
					for (var t = 0; t < tolist.length; t++) {
						var toNode = this._model.getEntry(tolist[t]).node;
						link = this.connectNodes(currentNode, toNode);
					}
					for (var f = 0; f < fromlist.length; f++) {
						var fromNode = this._model.getEntry(fromlist[f]).node;
						link = this.connectNodes(fromNode, currentNode);
					}
				}
			}, this);
			
			// Create links from lists in the link model 
			this._model.forEachCompleteLinkEntry(function(entry){
				entry.link = this.connectNodes(entry.start.node, entry.end.node, null, entry.item);
				this._applyLinkStoreItemGraphics(entry.link);
			}, this);
			
		},
		
		_createShapesFromModel: function(){
			// summary: 
			//     Based on options provided, create graphical objects
			//     associated with the nodeStore items and their
			//     relationships.
			// tags:
			//	    private 
			if (this._createLinksForHierarchy) {
				// Create nodes
				this._model.forEachEntry(function(entry){
					entry.node = this.createNode(null, entry.item);
					this._applyNodeStoreItemGraphics(entry.node);
				}, this);
				this._createLinksFromModel();
			} else {
				// Create subgraphs/nodes
				this._model.forEachTopEntry(function(entry){
					if (entry.isLeaf()) {
						entry.node = this.createNode(null, entry.item);
						this._applyNodeStoreItemGraphics(entry.node);
					} else {
						entry.node = this.createSubgraph(null, entry.item);
						this.createChildGraphics(entry);
						this._applyNodeStoreItemGraphics(entry.node);
					}
				}, this);
				this._createLinksFromModel();
			}
			
			this.onLoaded();
		},
		
		createChildGraphics: function(parent){
			// summary: 
			//     For hierarchical data, recursively go through the tree
			//     and create subgraphs and nodes accordingly
			// tags:
			//	    private         
			var children = parent.children;
			for (var i = 0; i < children.length; i++) {
				var child = children[i];
				if (child.isLeaf()) {
					child.node = this.createNode(null, child.item, parent.node.getGraph());
					this._applyNodeStoreItemGraphics(child.node);
				} else {
					child.node = this.createSubgraph(null, child.item, parent.node.getGraph());
				}
				
				this.createChildGraphics(child);
			}
			this._applyNodeStoreItemGraphics(parent.node);
		},
		
		// ===============================================================
		// Nodes and Links disposal
		// ===============================================================
		_nodeDispose: function(node, item){
			// summary:
			//     dispose of a node. 
			// tags:
			//	    private 
			
			if (node) {
				this._clearOnChangedHandlers(node);
				node.removeShape();
				node.dispose();
			}
		},
		
		_linkDispose: function(link, item){
			// summary:
			//     dispose of a link. 
			// tags:
			//	    private 
			
			if (link) {
				this._clearLinkShapeHandlers(link);
				link.removeShape();
				link.dispose();
			}
		}
		
	});
	
	//
	//	ibm_ilog.diagram.widget.DataConnector.StartLinkFieldname: String
	//		The name of a field in a linksStore item which defines the start node of a link
	//      The value associated with this field is a String which represents the 
	//      identity of an item in the nodesStore.
	//
	DataConnector.StartLinkFieldname = "start";
	
	//
	//	ibm_ilog.diagram.widget.DataConnector.EndLinkFieldname: String
	//		The name of a field in a linksStore item which defines the end node of  a link
	//      The value associated with this field is a String which represents the 
	//      identity of an item in the nodesStore.
	//
	DataConnector.EndLinkFieldname = "end";
	
	var _DataModel = declare('ibm_ilog.diagram.widget._DataModel', null, {
		//
		//	summary:
		//
		//		A _DataModel is a collection of _NodeModelEntry items.
		//
		//	description:
		//		
		//		The _DataModel is a half-way house between the store and canvas.
		// tags:
		//	    private 
		
		// nmodel : dojox.collections.Dictionary
		//          A collection of entries, each representing a nodesStore item, associated 
		//          graphical objects and its relationships between other nodes
		//          It is not considered complete until all entries have been added
		//          and the item for each entry has loaded, I.e. no pending loads  
		nmodel: null,
		
		// lmodel : dojox.collections.Dictionary
		//          A collection of entries, each representing a linksStore item, associated 
		//          graphical objects  
		lmodel: null,
		
		// pendingLoads : Integer
		//                Number of model entries which don't have associated items 
		pendingLoads: 0,
		
		// allEntriesAdded : Boolean
		//                When true, all datastores have been parsed and model entries
		//                have been created.
		
		allEntriesAdded: false,
		
		// initialLoadComplete : Boolean
		//                When true, it means all items loaded and associated graphics
		//                have been created.
		
		initialLoadComplete: false,
		
		constructor: function(){
			// summary:
			//     Creates an instance of a data model
			//
			// tags:
			//	    private 
			this.nmodel = new Dictionary();
			this.lmodel = new Dictionary();
			this.init();
		},
		
		init: function(){
			// tags:
			//	    private 
			
			this.initNodes();
			this.initLinks();
			
			
			this.pendingLoads = 0;
			
			
		},
		
		initNodes: function(){
			// tags:
			//	    private 
			array.forEach(this.nmodel.getKeyList(), function(key){
				this.nmodel.remove(key);
			}, this);
			this.nmodel.clear();
			this.allEntriesAdded = false;
			this.initialLoadComplete = false;
		},
		
		initLinks: function(){
			// tags:
			//	    private 
			array.forEach(this.lmodel.getKeyList(), function(key){
				this.lmodel.remove(key);
			}, this);
			this.lmodel.clear();
		},
		
		isModelComplete: function(){
			// summary:
			//     Check if the model is "complete" - I.e. all entries have been added
			//     and each entry has an associated item. 
			//     We only want this to return true for the first call.
			// tags:
			//	    private 
			var isComplete = (this.pendingLoads === 0 && this.allEntriesAdded && !this.initialLoadComplete);
			if (isComplete) {
				this.initialLoadComplete = true;
			}
			return isComplete;
		},
		
		setAllEntriesAdded: function(){
			// summary:
			//     Indicate to the model that all entries have been added.
			// tags:
			//	    private 
			this.allEntriesAdded = true;
		},
		
		incrPendingLoads: function(){
			// summary:
			//     Increase the count of item loads pending.
			// tags:
			//	    private 
			this.pendingLoads++;
		},
		
		decrPendingLoads: function(){
			// summary:
			//     Decrease the count of item loads pending.
			// tags:
			//	    private            
			this.pendingLoads--;
		},
		
		clear: function(){
			// summary:
			//     Clears the data model
			// tags:
			//	    private 
			this.init();
		},
		
		getEntry: function(id){
			// summary:
			//     Get an entry, based on the nodeStore Identity
			// tags:
			//	    private         
			return this.nmodel.item(id);
		},
		
		getLinkEntry: function(id){
			// summary:
			//     Get an entry, based on the linksStore Identity
			// tags:
			//	    private         
			return this.lmodel.item(id);
		},
		
		containsEntry: function(id){
			// summary:
			//     Enquire if there is an entry in the data model which relates
			//     to a specified nodeStore Identity
			// tags:
			//	    private  
			return this.nmodel.containsKey(id);
		},
		
		addEntry: function(id){
			// summary:
			//     Creates a _NodeModelEntry, associates it with a specified
			//     nodeStore Identity then adds it to the model
			// tags:
			//	    private    
			var entry = new _NodeModelEntry();
			
			this.nmodel.add(id, entry);
			entry.id = id;
			
			// Track the number of item loads pending
			this.incrPendingLoads();
			return entry;
		},
		
		removeEntry: function(id){
			// summary:
			//     Removes the _NodeModelEntry, associated with a specified
			//     nodeStore Identity, from model
			// tags:
			//	    private    
			var entry = this.getEntry(id);
			this.nmodel.remove(id);
		},
		
		addLinkEntry: function(id){
			// summary:
			//     Creates a _LinkModelEntry, associates it with a specified
			//     linkStore Identity then adds it to the model
			// tags:
			//	    private    
			var entry = new _LinkModelEntry();
			
			this.lmodel.add(id, entry);
			entry.id = id;
			return entry;
		},
		
		removeLinkEntry: function(id){
			// summary:
			//     Removes the _LinkModelEntry, associated with a specified
			//     linkStore Identity, from model
			// tags:
			//	    private    
			var entry = this.getLinkEntry(id);
			this.lmodel.remove(id);
		},
		
		
		
		setEntryItem: function(entry, item){
			// summary:
			//     Associates and entry with a datastore item
			//     and tracks the number of item loads pending.   
			//     IT IS VERY IMPORTANT THAT setEntryItem (rather than entry.item = item;)
			//     IS USED SO THE MODEL CAN KEEP TRACK OF WHICH ENTRIES DON'T HAVE ITEMS
			// tags:
			//	    private         
			entry.item = item;
			this.decrPendingLoads();
		},
		
		setLinkEntryItem: function(entry, item){
			// summary:
			//     Associates and entry with a datastore item
			// tags:
			//	    private     
			entry.item = item;
		},
		
		forEachLinkEntry: function(func, scope){
			// summary:
			//     Loops through each link entry in the model, calling a named function, in
			//     the context of the specified scope.
			//     The prototype of the function must be of the form "funct(entry)"
			// tags:
			//	    private     
			var e = this.lmodel.getIterator();
			while (e.get()) {
				func.call(scope, e.element.value);
			}
		},
		
		forEachCompleteLinkEntry: function(func, scope){
			// summary:
			//     Loops through each link entry in the model which is not 'pending', calling
			//     a named function, in the context of the specified scope.
			//     The prototype of the function must be of the form "funct(entry)".
			// tags:
			//	    private     
			var e = this.lmodel.getIterator();
			while (e.get()) {
				if (!e.element.value.pending) {
					func.call(scope, e.element.value);
				}
			}
		},
		
		forEachPendingLinkEntry: function(func, nodeEntry, scope){
			// summary:
			//     Loops through each link entry in the model which is 'pending', calling
			//     a named function, in the context of the specified scope.
			//     The prototype of the function must be of the form "funct(entry)".
			// tags:
			//	    private     
			var e = this.lmodel.getIterator();
			while (e.get()) {
				if (e.element.value.pending) {
					func.call(scope, e.element.value, nodeEntry);
				}
			}
		},
		
		forEachEntry: function(func, scope){
			// summary:
			//     Loops through each entry in the model, calling a named function, in
			//     the context of the specified scope.
			//     The prototype of the function must be of the form "funct(entry)"
			// tags:
			//	    private     
			var e = this.nmodel.getIterator();
			while (e.get()) {
				func.call(scope, e.element.value);
			}
		},
		
		forEachTopEntry: function(func, scope){
			// summary:
			//     Loops through each entry in the model which have no parents, 
			//     calling a named function, in the context of the specified scope.
			//     The prototype of the function must be of the form "funct(entry)"
			// tags:
			//	    private     
			var e = this.nmodel.getIterator();
			while (e.get()) {
				if (!e.element.value.parent) {
					func.call(scope, e.element.value);
				}
			}
		},
		
		forEachUnresolvedEntry: function(func, scope){
			// summary:
			//     Loops through each entry in the model which is not marked as resolved, calling
			//     a named function, in the context of the specified scope.
			//     The prototype of the function must be of the form "funct(entry)".
			// tags:
			//	    private     
			var e = this.nmodel.getIterator();
			while (e.get()) {
				if (!e.element.value.resolved) {
					func.call(scope, e.element.value);
				}
			}
		},
		
		dumpToConsole: function(){
			// summary:
			//     Debug facility to dump the contents of the data model to the console.
			// tags:
			//	    private 
			
			// console.info("Model dump =================================Nodes and their relationships");
			
			this.forEachEntry(function(entry){
				var leafStatus = entry.isLeaf() ? "(+leaf)" : "";
				var itemStatus = entry.item ? "(+item)" : "";
				var resolvedStatus = entry.resolved ? "(+resolved)" : "";
				// console.info("Item - " + entry.id + " " + itemStatus + " " + resolvedStatus + " " + leafStatus);
				var childlist = entry.childlist;
				for (var t = 0; t < childlist.length; t++) {
					// console.info("       Children : " + childlist[t]);
				}
				var parentlist = entry.parentlist;
				for (var f = 0; f < parentlist.length; f++) {
					// console.info("       Parent   : " + parentlist[f]);
				}
				
				var tolist = entry.tolist;
				for (var t = 0; t < tolist.length; t++) {
					// console.info("       To       : " + tolist[t]);
				}
				var fromlist = entry.fromlist;
				for (var f = 0; f < fromlist.length; f++) {
					// console.info("       From     : " + fromlist[f]);
				}
			}, this);
			
			// console.info("Model dump =================================Links");
			this.forEachLinkEntry(function(entry){
				// console.info("Item - " + entry.id);
			}, this);
		}
	});
	
	var _NodeModelEntry = declare('ibm_ilog.diagram.widget._NodeModelEntry', null, {
		//
		//	summary:
		//
		//		A DataModelEntry collects attributes related to a nodesStore item.
		//
		//	description:
		//		
		//		When completely populated, it forms a logical representation of a
		//      nodeStore item and its relationship with other items.
		
		id: "",
		item: null,
		node: null,
		resolved: false,
		childlist: [],
		parentlist: [],
		tolist: [],
		fromlist: [],
		parent: null,
		children: [],
		
		
		constructor: function(){
			// summary:
			//     Creates an instance of a data model entry.
			// tags:
			//	    private 
			this.id = "";
			this.item = null;
			this.node = null;
			this.resolved = false;
			this.childlist = [];
			this.parentlist = [];
			this.fromlist = [];
			this.tolist = [];
			this.parent = null;
			this.children = [];
		},
		
		isLeaf: function(){
			return (this.children.length === 0);
		}
		
	});
	
	var _LinkModelEntry = declare('ibm_ilog.diagram.widget._LinkModelEntry', null, {
		//
		//	summary:
		//
		//		A DataModelEntry collects attributes related to a linksStore item.
		//
		//	description:
		//		
		//		When completely populated, it forms a logical representation of a
		//      nodeStore item and its relationship with other items.
		
		id: "",
		item: null,
		link: null,
		startId: null,
		start: null,
		endId: null,
		end: null,
		pending: false,
		
		constructor: function(){
			// summary:
			//     Creates an instance of a data model entry.
			// tags:
			//	    private 
			this.id = "";
			this.item = null;
			this.link = null;
			this.startId = null;
			this.start = null;
			this.endId = null;
			this.end = null;
			this.pending = false;
		}
		
	});
	
	return DataConnector;
});
