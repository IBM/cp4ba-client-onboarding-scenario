/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"../../base",
"../../Link",
"../../adorners/LinkAdorner",
"../adorners/LinkIntermediatePointsHandle",
"../adorners/LinkIntermediatePointsAddHandle",
"../interactors/AddIntermediatePointInteractor",
"../../util/Geometry"
], function(
declare,
lang,
array,
iid,
Link,
LinkAdorner,
LinkIntermediatePointsHandle,
LinkIntermediatePointsAddHandle,
AddIntermediatePointInteractor,
g
){

/*=====
var LinkAdorner = ibm_ilog.diagram.adorners.LinkAdorner;
=====*/

	var LinkIntermediatePointsAdorner =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.LinkIntermediatePointsAdorner',[LinkAdorner],{
		// Summary:
		//		this class is the adorner that contains the LinkIntermediatePointsHandler. 
		//		These handles enables the user to delete and edit link intermediate points.
		//		Also, it creates an instance of the AddIntermediatePointInteractor that enables 
		//		to create new intermediate point at the adorned link
		_intermediatePoints: null,
		_addPointInteractor: null,
		_useHandleInteractorToAdd: null,
		initialize: function(){
		// Summary:
		//		initialize the Adorner and create the instance of the AddIntermediatePointInteractor.
			this.inherited(arguments);
			this.enableHandleInteractorToAdd(true);
			this._addPointInteractor = new AddIntermediatePointInteractor();
		},
		enableHandleInteractorToAdd: function(enabled){
			// Summary:
			//		This method set the use of individual Interactors to add intermediate points (click over handles), or use the general Interactor (Shift+click over link).
			this._useHandleInteractorToAdd = enabled;
		},
		setAdorned: function (element) {
			//	summary:
			//		apply the adorner to the given element. This method creates all the necessary LinkIntermediatePointsHandler and deletes any previously created instances.
			//
			
			if(element){
				var shapeType = element.getShapeType();
				if (shapeType != Link.LinkShapeType.Free &&
				        this._shapeType != Link.LinkShapeType.OrthogonalEditable){
					return; // do not set the adorner
				}
				
				this._intermediatePoints = [];
				this.createAllHandles(element);
				if(!this._useHandleInteractorToAdd){
					this._addPointInteractor.initialize(this);
					this._addPointInteractor.reactivate();
				}
			}else{
				this._clearHandles();
				if(!this._useHandleInteractorToAdd){
					this._addPointInteractor.deactivate();
				}
			}
			this.inherited(arguments);
			this._path.moveToBack();
			this.moveToFront();
		},
		rebindAdorned: function(){
			//	summary: 
			//		rebind the adornet to the same adorned link.
			//		This method should be called when the number of intermediate links varies.

			var link = this.getAdorned();
			this.setAdorned(null);
			this.setAdorned(link);
		},
    	createAllHandles: function(element){
			//	summary: 
			//		This method creates all the necessary LinkIntermediatePointsHandler
			var size = element.getIntermediatePoints().length;
			if(this._useHandleInteractorToAdd){
				this._createDynamicHandle(LinkIntermediatePointsAddHandle,"addPointGroup").setUp(0);
			}
			for(var index = 0;index<size;index++){
    			this._createDynamicHandle(LinkIntermediatePointsHandle,"currentPointGroup").setUp(index);
    			if(this._useHandleInteractorToAdd){
    				this._createDynamicHandle(LinkIntermediatePointsAddHandle,"addPointGroup").setUp(index+1);
    			}
    		}
    	},
    	_createDynamicHandle: function (clazz,attachPointName) {
			if (this[attachPointName]) {
				var template = this._templatePool.item(this[attachPointName].template || clazz.templateId);
				var handle = this[attachPointName].createObject(clazz);
				handle.initialize(this, template);
				this._handles.add(handle);
				return handle;
			} else {
				return null;
			}
		},
		_clearHandles: function(){
			//	summary: 
			//		This method deletes any previously created LinkIntermediatePointsHandler instances.
			this._handles.forEach(function(handle){
				handle.getParent().remove(handle);
			});
			this._handles.clear();
		},
    	_updateLayout: function () {

    		// [AV] updates from "updateShapeBoundProperty" dont work with composite properties
    		// e.g. bounds.width   
    		//      bounds.height
    		//
    		// Correcting this may also be faster, only one rebinding process is needed
    		
    		this.inherited(arguments);
    		if (this.getAdorned()) {
        		var transformationFunction = lang.hitch(this, function (point, list) {
					var v = this._viewport,
						z = v.getZoom(),
						vr = v.getViewRect();
					var t = this._adorned.getShapeToContainerTransform(v._diagram.getGraph().getParent());
					point = t.transformPoint(point);
					point = g.moveRect(point, g.negPoint(vr));
					point.x = point.x * z;
					point.y = point.y * z;
					return point;
				});
				var points = array.map(this.getAdorned().getIntermediatePoints(),transformationFunction);
				this._intermediatePoints = points;
				this._notifyHandles();
    		}
    	},
    	_notifyHandles: function(){
    		// summary:
    		//		notify all the handles of the point modification
    		this._handles.forEach(function(handle){
    			if(handle._isAddHandle){
    				handle.changeBindings([{x:this.getLinkStartX(),y:this.getLinkStartY()}].concat(this._intermediatePoints).concat({x:this.getLinkEndX(),y:this.getLinkEndY()}));
    			}else{
    				handle.changeBindings(this._intermediatePoints);
    			}
    		},this);
    	}

    }));

	return LinkIntermediatePointsAdorner;
	
});
