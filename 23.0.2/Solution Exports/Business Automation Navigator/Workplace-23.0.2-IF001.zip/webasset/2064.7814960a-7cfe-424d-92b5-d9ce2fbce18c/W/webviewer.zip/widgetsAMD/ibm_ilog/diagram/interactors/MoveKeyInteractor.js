/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/array",
"dojo/keys",
"require",
"dojox/gfx/matrix",
"./Interactor",
"../Selection",
"../util/Geometry",
"../util/GraphUtil",
"../util/Batch"
],
function(
declare,
array,
keys,
require,
m,
Interactor,
Selection,
g,
gu,
Batch
){

// The following classes are loaded dynamically if the editor modules are loaded.

var MultipleAction = null;
var UndoActionList = null;
var EditingUtils = null;
var _classesRequired = false;

var _requireClasses = function()
{
	if(!_classesRequired){
		// no try/catch, if we are in the editor these classes must be there.
		MultipleAction = require("../editor/undo/MultipleAction");
		UndoActionList = require("../editor/undo/UndoActionList");
		EditingUtils = require("../editor/EditingUtils");
	}
	_classesRequired = true;
}

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var MoveKeyInteractor =
declare("ibm_ilog.diagram.interactors.MoveKeyInteractor", [Interactor], {
	//summary:
	//		This Interactor manages the graphElements movement through the keyboard interaction.
	//		This Interactor have 8 connections: moveLeft, moveRigth, moveUp, moveDown, fineMoveLeft, fineMoveRigth, fineMoveUp, fineMoveDown.
	
	_diagram: null,
	_increment: null,
	_fineIncrement: null,
	
	initialize: function (diagram) {
	// summary:
    //		initialize the new instance.
    // diagram: ibm_ilog.diagram.widget.Diagram
    //		the associated diagram.		
		this._diagram = diagram;
		this.setIncrement(10);
		this.setFineIncrement(1);
		return this._initialize();
	},
	setIncrement: function(increment){
		// summary: 
		//		sets the move increment
		// increment: integer
		//		the increment to be set
		this._increment = increment;
	},
	getIncrement: function(){
		// summary: 
		//		gets the move increment
		return this._increment;
	},
	setFineIncrement: function(increment){
		// summary: 
		//		sets the move fine increment
		// increment: integer
		//		the fine increment to be set
		this._fineIncrement = increment;
	},
	getFineIncrement: function(){
		// summary: 
		//		gets the move fine increment
		return this._fineIncrement;
	},
	moveUp: function(e){
		// summary:
	    //		This method moves the selected elements up
	    // e: Event object
	    //		the event to be treated.
		this._move({x:0,y:-this._increment});
	},
	moveDown: function(e){
		// summary:
	    //		This method moves the selected elements down
	    // e: Event object
	    //		the event to be treated.
		this._move({x:0,y:this._increment});
	},
	moveRight: function(e){
		// summary:
	    //		This method moves the selected elements rigth
	    // e: Event object
	    //		the event to be treated.
		this._move({x:this._increment,y:0});
	},
	moveLeft: function(e){
		// summary:
	    //		This method moves the selected elements left
	    // e: Event object
	    //		the event to be treated.
		this._move({x:-this._increment,y:0});
	},
	fineMoveUp: function(e){
		// summary:
	    //		This method finely moves the selected elements up
	    // e: Event object
	    //		the event to be treated.
		this._move({x:0,y:-this._fineIncrement});
	},
	fineMoveDown: function(e){
		// summary:
	    //		This method finely moves the selected elements down
	    // e: Event object
	    //		the event to be treated.
		this._move({x:0,y:this._fineIncrement});
	},
	fineMoveRight: function(e){
		// summary:
	    //		This method finely moves the selected elements rigth
	    // e: Event object
	    //		the event to be treated.
		this._move({x:this._fineIncrement,y:0});
	},
	fineMoveLeft: function(e){
		// summary:
	    //		This method finely moves the selected elements left
	    // e: Event object
	    //		the event to be treated.
		this._move({x:-this._fineIncrement,y:0});
	},
	getKeyInteractorId: function(){
		// summary:
	    //		returns the Interactor Id
		return MoveKeyInteractor.KeyInteractorId;
	},
	getDefaultConnections: function () {
		// summary:
		//		returns the default event mapping
		
		return {
			moveLeft: {
				hotKey: keys.LEFT_ARROW,
				connectTo: "moveLeft",
				filter: this._buildInputFilter({ctrl:false,shift:false})
			}, fineMoveLeft: {
				hotKey: null,
				connectTo: "fineMoveLeft",
				filter: this._buildInputFilter({ctrl:false,shift:true})
			}, moveRight: {
				hotKey: keys.RIGHT_ARROW,
				connectTo: "moveRight",
				filter: this._buildInputFilter({ctrl:false,shift:false})
			}, fineMoveRight: {
				hotKey: null,
				connectTo: "fineMoveRight",
				filter: this._buildInputFilter({ctrl:false,shift:true})
			}, moveUp: {
				hotKey: keys.UP_ARROW,
				connectTo: "moveUp",
				filter: this._buildInputFilter({ctrl:false,shift:false})
			}, fineMoveUp: {
				hotKey: null,
				connectTo: "fineMoveUp",
				filter: this._buildInputFilter({ctrl:false,shift:true})
			}, moveDown: {
				hotKey: keys.DOWN_ARROW,
				connectTo: "moveDown",
				filter: this._buildInputFilter({ctrl:false,shift:false})
			}, fineMoveDown: {
				hotKey: null,
				connectTo: "fineMoveDown",
				filter: this._buildInputFilter({ctrl:false,shift:true})
			}
		};
	},
	_move: function(delta){
		var targetSet = this._buildTargetSet();
		
		if(targetSet.length == 0){
			return false;
		}
		
		// check move limits defined on the Graph if any:
		array.forEach(targetSet,function(s){
			var p = s.e.getParent();
			if (p && p.onElementMoving) {
				var oldx = delta.x;
				var oldy = delta.y;
				p.onElementMoving.call(p, s.e, s.t1, delta);
			}
		},this);
		
		array.forEach(targetSet,function(s){
			this._doMove(s.e,s.t1,delta);
		},this);
		
		Batch.endBatch(); // update links immediately for better visual result
		
		if(this._diagram._isIBMDiagramEditor){
			var um = this._diagram.getUndoManager();
			um.addAction(this._createUndoAction(targetSet));
		}
		return true;
	},
	_doMove: function(graphElement,originalTransform,delta) {
		//	summary:
		//		Concrete the movement to a graph element.
		//	graphElement:
		//		The graph element to move.
		//	originalTransform:
		//		The matrix representing the location from which the delta is computed.
		//	delta:
		//		The ammount to translate the entity from its original location.
		graphElement.setTransform(m.multiply(originalTransform,m.translate(delta)));
	},
	_isMovable: function(ge) {
		return !(ge._isIBMDiagramLink);
	},
	getTransformToElement: function(e) {
		//	returns:
		//		a transform from viewport coords to element coords
		var rm = e._getRealMatrix();
		return (rm && rm.inverse());
	},
	_buildTargetSet: function() {
		//
		//	summary:
		//		Builds the set of entities that are going to be affected by the drag.
		//
		//	description:
		//		Grab Nodes and Subgraphs from the _selection object. Their original 
		//    transforms are saved to be used in the drag process. We also store 
		//		viewport-to-element transforms since they are not likely to change
		//		while dragging (would require modifying the transformation of some
		//		of the parents of the selected shape). This might change if we plan
		//		to provide pan-while-moving.
		//

		var selection = this._diagram.getSelection();
		var s = selection.fastGet();
		var gs = [];
		
		s.forEach(function(e){
			var ge = selection._asGraphElement(e);
			if(ge && this._isMovable(ge)) {
				// no link moving for now
				gs.push(ge);
			}
		},this);
		
		//if no selection, add the focused element
		if(gs.length == 0){
			var c = this._diagram.getFocusedElement();
			if(c && this._isMovable(c)){
				gs.push(c);
			}
		}
		
		var targetSet = array.map(gu.maximals(gs),function(e){
			return { t1:e.getTransform(), e:e, t:this.getTransformToElement(e) };
		},this);
		
		return targetSet;
	},
	_createUndoAction: function(targetSet){
		// summary:
		//		creates the undo action, based on the targetSet
		
		_requireClasses();
		
		var mAction = new MultipleAction(UndoActionList.Move);
		
		array.forEach(targetSet, function(s){
			var action = EditingUtils.createMoveUndoAction(s.e, s.t1, s.e.getTransform());
			mAction.addAction(action);
		});
		
		return mAction;
	}
});

MoveKeyInteractor.KeyInteractorId = "Move";

return MoveKeyInteractor;

});
