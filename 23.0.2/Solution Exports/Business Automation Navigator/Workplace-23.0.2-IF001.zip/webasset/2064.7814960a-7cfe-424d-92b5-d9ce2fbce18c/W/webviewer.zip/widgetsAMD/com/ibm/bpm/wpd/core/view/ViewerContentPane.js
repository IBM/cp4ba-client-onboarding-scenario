define(["dojo/_base/declare",
        "dijit/layout/ContentPane"],
function(declare,
		ContentPane) {
return declare([ContentPane], {
	
	viewStateModel:null,
	viewer: null,
	constructor : function() {
	},
	
   // Kludge to properly propagate resize events to the base viewer
   resize : function(changeSize, resultSize) {
      this.inherited(arguments);
      if (this.viewer && this.viewer.ilogDiagrammer) this.viewer.ilogDiagrammer.resize(changeSize, resultSize);
   },

	destroyRecursive : function(){
		console.debug ("destroyrecursive in viewerContentPane");
		this.viewStateModel = null;
		this.viewer.destroyRecursive();
		this.viewer = null;
		this.inherited(arguments);
	}
});

});
