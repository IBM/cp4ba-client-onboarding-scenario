define({      
//begin v1.x content
    errorDialogTitle: "Błąd produktu IBM BPM",
    moreDetails: "Więcej szczegółów...",
    closeMessage: "Zamknij wszystkie komunikaty o błędach",
    contentMessage: "Wystąpił błąd."
//end v1.x content
});

