/**
 * Utilities to create various PathAdorner types.
 * 
 */
define([
      "dojo/_base/declare", "dojo/_base/lang", "./PathAdorner", "./PathElement", "./adornerConstants", "./adornerUtils"
], function(declare, lang, PathAdorner, PathElement, adornerConstants, adornerUtils) {

   var PathAdornerUtils = declare([], {

      /**
       * Create a PathAdorner that will color all of the specified links of a diagram
       * the specified color.
       * 
       * @param bpdViewer
       * @param linkIds
       * @param color
       * @param width
       * @returns
       */
      createColorLinksPathAdorner : function(bpdViewer, linkIds, color, width) {
         if (!bpdViewer || !linkIds || !color)
            return null;
         var pathAdorner = new PathAdorner();
         for ( var i = 0; i < linkIds.length; i++) {
            var target = new PathElement({
               ilogDiagram : bpdViewer.ilogDiagrammer,
               id : linkIds[i],
               type : adornerConstants.TYPE_LINK
            });
            var adorner = adornerUtils.createColorLinkAdorner(target, color, width);
            target.addAdorner(adorner);
            pathAdorner.addElement(target);
         }
         return pathAdorner;
      }

   });
   return new PathAdornerUtils();
});
