define(["require",
        "dojo/parser",
        "dojo/_base/connect",
        "dijit/_Widget",
        "dijit/_TemplatedMixin",
        "dijit/_WidgetsInTemplateMixin",
        "dijit/_WidgetBase",
        "dojo/_base/declare",
        "../breadcrumb/view/WebViewerBreadcrumb",
        "../model/shellstate/ShellStateModel",
//		"../../search/view/Search",
		"../../base/bootstrap",
		"./ViewManager",
        "dojo/text!./templates/BreadcrumbView.html"],
function(require,
        parser,
        connect,
        _Widget,
        _TemplatedMixin,
        _WidgetsInTemplateMixin,
        _WidgetBase,
        declare,
        WebViewerBreadcrumb,
        ShellStateModel,
//        Search,
        bootstrap,
        ViewManager,
        template) {

/**
 * Breadcrumb and the ViewManager
 */
return declare([ _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {
	
	// Path to the template
	templateString : template,
	
	widgetsInTemplate : true,
	_subscriptionHandles : null,
	contextRootForWebViewer: null,
//	searchView: null,
	
	constructor : function(params) {
		//if (!!params.initializeNeeded){
			//com.ibm.bpm.wpd.base.initializeWebViewerGlobal();		
			//flag for developing using wle server or sandbox server
		//	if(!!dojo.global.BPM.WPD_useWLEServer)
			//	com.ibm.bpm.wpd.core.model.shellstate.ShellStateModel.getInstance().setSnapshotInfor(params);
			//else
				//com.ibm.bpm.wpd.core.model.shellstate.ShellStateModel.getInstance().setSnapshotInfor({projectId: "app", projectName: "app", snapshotId: "snapshot", snapshotName :"snapshot"});
		//}		
		this._subscriptionHandles = [];
		this.contextRootForWebViewer = bootstrap.getEndPointAndContextRootForModule(bootstrap.wpdConstant.BPM_WARNAME_WEBVIEWER);
		
	},
	
	postCreate : function() {
		this._instantiateBreadcrumb();
/*
		if (ShellStateModel.getInstance().state == ShellStateModel.getInstance().STATE_PROCESS_CENTER){
			this.searchView = new Search({}, this.searchViewAttachPoint);
		} else {
			this.searchViewCell.style.display = "none";
			this.breadcrumbCell.removeAttribute("width");
			this.breadcrumbCell.style.width = "100%";
		}
*/		
		this.outerBC.startup();
		this._subscriptionHandles.push(connect.subscribe("com.ibm.bpm.wpd.core.model.shellstate.ShellStateModel" + "::" + "_activeViewStateModel", this, this.modelChanged));
	},
	

	/**
	 * breadcrumb instantiation
	 */
	_instantiateBreadcrumb:function(){		
		
		//var filterTypes = ["bpdDocType", "assetListView"];
		var breadcrumb = new WebViewerBreadcrumb({className:"viewerBreadcrumbBar"}, this.breadcrumbAttachPoint);
		
		if(ShellStateModel.getInstance().state == ShellStateModel.getInstance().STATE_PROCESS_CENTER){
			var displayName = ShellStateModel.getInstance().projectName;
			var iconPath = "images/process-app-16.png";
			if (!!ShellStateModel.getInstance().breadCrumbName) {
				displayName = ShellStateModel.getInstance().breadCrumbName;
				iconPath = ShellStateModel.getInstance().breadCrumbImage;
			}		
			var viewModel = {name : displayName, type:"app", id: "app"};

			breadcrumb.addBreadcrumbEntry(viewModel, this._backToPC, true,  iconPath);
		}
		
		//breadcrumb.onShow();
	},
	
	_backToPC:function(){
		cleanupWebViewer();
	},

	setZoom : function(zoomLevel) {
		this.viewersContainer.setZoom(zoomLevel);
	},

	getActiveViewer : function() {
	    if (!!this.viewersContainer && 
	            !!this.viewersContainer.selectedChildWidget &&
	            !!this.viewersContainer.selectedChildWidget.viewer) {
	        return this.viewersContainer.selectedChildWidget.viewer;
	    }
        return null;
	},

	/**
	 * Receives notifications, either via dojo subscription or direct listening at the instance level
	 */
	modelChanged : function(notification) {
		
//		this.toggleSearch(notification);
		
		if (notification.attributeName == "_activeViewStateModel"){
			if(!!notification.newValue){	
				this.outerBC.resize();
			}
		}
	},
	
	/**
	 * Determine whether the search field should be hidden or shown
	 * @param notification
	 */
/*
	toggleSearch: function(notification) {
		if (notification.newValue.documentId == "assetListModel") {
			if (!!this.searchView){
				this.searchView.toggleShow(true);
			}
		}
		//Defect 68873
		//else if (notification.oldValue && notification.oldValue.documentId == "assetListModel") {
		else {
			if (!!this.searchView){
				this.searchView.toggleShow(false);
			}
		}
		
	},
*/
	resize : function(){
		//have to explicilty call this otherwise the pane does not resize on browser resize
		this.outerBC.resize();
		this.inherited(arguments);
		//console.debug("after breadcrumbview" + arguments[0].h + " " + arguments[0].w);
	},
	
	/**
	 * Clean up stored data
	 */
	cleanup:function(){	
		for ( var i = 0; i < this._subscriptionHandles.length; i++) {
			if(!!this._subscriptionHandles[i]){
				connect.unsubscribe(this._subscriptionHandles[i]);
			}
		}
	},
	
	destroyFlashPlayer : function (){
		this.viewersContainer.destroyFlashPlayer();
	}, 
	
	/**
	 * Destroy the widget
	 */
	destroy : function() {
		this.cleanup();
		this.inherited(arguments);
		bootstrap.cleanUpWebViewerGlobal();
	}
});

});
