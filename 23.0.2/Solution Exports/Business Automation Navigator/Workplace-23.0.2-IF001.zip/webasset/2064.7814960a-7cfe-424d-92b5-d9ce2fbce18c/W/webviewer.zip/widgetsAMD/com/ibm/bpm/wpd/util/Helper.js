define([
        "dojo/has",
        "dojo/_base/sniff"
], function(
        has,
        sniff
        ) {


var _helper = {};

_helper.text2htmlText = function(s)
{
	if(s ==null || s.length <= 0) 
		return s;

	s = s.replace(/&/g,"&amp;");
	s = s.replace(/>/g,"&gt;");
	s = s.replace(/</g,"&lt;");
	s = s.replace(/\"/g,"&quot;");
	s = s.replace(/'/g,"&#39;");
			   
	if (s.indexOf("&amp;amp;") != -1)
		s = s.replace("&amp;amp;","&amp;");
	
	return s;
}

_helper.text2htmlText_1 = function(s)
{
	if(s ==null || s.length <= 0) 
		return s;

	s = s.replace(/&/g,"&amp;");
	s = s.replace(/>/g,"&gt;");
	s = s.replace(/</g,"&lt;");
	s = s.replace(/\"/g,"&quot;");
	s = s.replace(/'/g,"&#39;");
	s = s.replace(/(\r\n|\n|\r)/gm,"");
			   
	if (s.indexOf("&amp;amp;") != -1)
		s = s.replace("&amp;amp;","&amp;");
	
	return s;
}

_helper.text2htmlTextWeakEncoding = function(s) // add this method for rich text format supporting
{
	if(s == null || s.length <= 0) 
		return s;

//	s = s.replace(/&/g,"&amp;");
//	s = s.replace(/>/g,"&gt;");
//	s = s.replace(/</g,"&lt;");
//	s = s.replace(/\"/g,"&quot;");
	s = s.replace(/'/g,"&#39;");
			   
	if (s.indexOf("&amp;amp;") != -1)
		s = s.replace("&amp;amp;","&amp;");
	
	s = this.richTextFilter(s);
	
	return s;
}

_helper.richTextFilter = function(s) // add this method for rich text format supporting
{
	if(s == null || s.length <= 0) 
		return s;

	s = s.replace(/<br>/g, "");
	
	return s;
}

_helper.format = function( text )
{
	//check if there are two arguments in the arguments list
  	if ( arguments.length <= 1 )
  	{
 			//if there are not 2 or more arguments there's nothing to replace
        //just return the original text

        return text;

    }

    //decrement to move to the second argument in the array

    var tokenCount = arguments.length - 2;

    for( var token = 0; token <= tokenCount; token++ )

    {

        //iterate through the tokens and replace their placeholders from the original text in order

        text = text.replace( new RegExp( "\\{" + token + "\\}", "gi"),

                                                arguments[ token + 1 ] );

    }

    return text;

}

/**
 * Checks to see if the href matches that of the url
 */
_helper._checkStyleSheetForURL = function(styleSheet,url) {
	

	var found = false;
	try 
	{
		found = (styleSheet.href == url);
		if (!found && styleSheet.imports)
		{
			for (var i=0; !found && (i<styleSheet.imports.length); i++)
			{
				found = this._checkStyleSheetForURL(styleSheet.imports[i], url);
			}
		}
	} catch (err) {

	}
	return found;
}

/**
 * Checks to see if the style sheet defined by the given url is currently loaded
 */
_helper.isStyleSheetLoaded = function(url) {

	var loaded = false;
	for (var i=0; !loaded && (i<document.styleSheets.length); i++)
	{
 		loaded = this._checkStyleSheetForURL(document.styleSheets[i], url);
	}
	return loaded;
}

/**
 * Load the stylesheet for the given url if it hasn't already been loaded
 * @param url
 * @returns {Boolean}
 */
_helper.loadStyleSheet = function(url) {
	var loaded = false;
		
	var link = document.createElement('link');
	link.rel = 'stylesheet';
	link.href = url;
	link.type = 'text/css';
	link.media = 'screen';
	link.charset = 'utf-8';
	loaded = this.isStyleSheetLoaded(link.href);
	
	if (!loaded) {
		if (!has("ie")) {
			document.getElementsByTagName('head')[0].appendChild(link);
			loaded = true;
		}
		else {
			if (has("ie"))
			{
				// IE only allows 31 style sheets, fudge around to allow more
				var styleId = 'WebSphereBusinessSpaceStyleSheet';
				if (!document.getElementById(styleId))
				{
					var s = document.createElement('style');
					s.id = styleId;
					document.getElementsByTagName('head')[0].appendChild(s);
				}
				var sheet = null;
				for (var i=0; !sheet && (i<document.styleSheets.length); i++)
				{
					if (document.styleSheets[i].id == styleId)
					{
						sheet = document.styleSheets[i];
					}
				}
				if (sheet)
				{
					// check if room at depth of 1
					if (sheet.imports.length < 31)
					{
						sheet.addImport(url);
						loaded = true;
					}
					// check if room at depth of 2 (if not loaded yet)
					for (var j=0; !loaded && (j<sheet.imports.length); j++)
					{
						var child = sheet.imports[j];
						if (child.imports.length < 31)
						{
							child.addImport(url);
							loaded = true;
						}
					}
					// check if room at depth of 3 (if not loaded yet)
					for (var j=0; !loaded && (j<sheet.imports.length); j++)
					{
						var child = sheet.imports[j];
						for (var k=0; !loaded && (k<child.imports.length); k++)
						{
							var grandchild = child.imports[k];
							if (grandchild.imports.length < 31)
							{
								grandchild.addImport(url);
								loaded = true;
							}
						}
					}
				}
			}
		}
	}
	
	return loaded;
}

return _helper;
});
