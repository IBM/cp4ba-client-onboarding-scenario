/**
 * Defines values for the type field in the AdornerTarget class.
 * 
 */
define([
   "dojo/_base/declare", "dojo/_base/lang"
], function(declare, lang) {

   var AdornerConstants = declare([], {

      // These map directly to the model types.
      TYPE_LINK : "link",
      TYPE_ACTIVITY : "activity",
      TYPE_GATEWAY : "gateway",
      TYPE_GATEWAY_AND : "gatewayAnd",
      TYPE_GATEWAY_OR : "gatewayOr",
      TYPE_GATEWAY_EVENT : "gatewayEvent",
      TYPE_START : "start",
      TYPE_END : "end",
      TYPE_END_MESSAGE : "messageEndEvent",
      TYPE_END_TERMINATE : "terminate",
      TYPE_END_ERROR : "errorEndEvent",
      TYPE_NOTE : "note",
      TYPE_START_MESSAGE : "msgStartEventInterrupting",
      TYPE_START_CONTENT : "contentStartEventInterrupting",
      TYPE_START_ADHOC : "adhocStartEvent",
      TYPE_INTERM_TIMER : "intermedCatchTimerEventNonBoundary",
      TYPE_INTERM_MESSAGE : "intermedCatchMsgEventNonBoundary",
      TYPE_INTERM_TRACKING : "intermedCatchTrackingEventNonBoundary",

      TYPES_START : null,
      TYPES_END : null,
      TYPES_GATEWAY : null,
      TYPES_ACTIVITY : null,
      TYPES_INTERM : null,

      constructor : function() {
         this.TYPES_START = [
            this.TYPE_START, this.TYPE_START_MESSAGE, this.TYPE_START_CONTENT, this.TYPE_START_ADHOC
         ];
         this.TYPES_END = [
            this.TYPE_END, this.TYPE_END_MESSAGE, this.TYPE_END_TERMINATE, this.TYPE_END_ERROR
         ];
         this.TYPES_GATEWAY = [
            this.TYPE_GATEWAY, this.TYPE_GATEWAY_AND, this.TYPE_GATEWAY_OR, this.TYPE_GATEWAY_EVENT

         ];
         this.TYPES_INTERM = [
            this.TYPE_INTERM_TIMER, this.TYPE_INTERM_MESSAGE, this.TYPE_INTERM_TRACKING
         ];
         this.TYPES_ACTIVITY = [
            this.TYPE_ACTIVITY
         ];
      },

      isStartType : function(type) {
         if (!type)
            return false;
         return this.TYPES_START.indexOf(type) >= 0;
      },

      isEndType : function(type) {
         if (!type)
            return false;
         return this.TYPES_END.indexOf(type) >= 0;
      },

      isGatewayType : function(type) {
         if (!type)
            return false;
         return this.TYPES_GATEWAY.indexOf(type) >= 0;
      },

      isActivityType : function(type) {
         if (!type)
            return false;
         return this.TYPES_ACTIVITY.indexOf(type) >= 0;
      },
      
      isIntermType : function(type) {
         if (!type)
            return false;
         return this.TYPES_INTERM.indexOf(type) >= 0;
      },

      isNonEventNode : function(type) {
         return this.isGatewayType(type) || this.isActivityType(type) || this.isIntermType(type);
      },

      isNodeType : function(type) {
         return this.isStartType(type) || this.isEndType(type) || this.isGatewayType(type) || this.isActivityType(type) || this.isIntermType(type);
      }

   });
   return new AdornerConstants();
});