/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/connect",
"dojo/keys",
"dojox/collections/Stack",
"./Interactor"
],
function(
declare,
connect,
keys,
Stack,
Interactor
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var Navigator =
declare("ibm_ilog.diagram.interactors.Navigator",Interactor,{
	//summary:
	//		This Interactor manages the naviagation of the graph through the keyboard interaction.
	//		This Interactor have 5 connections: changeNavigatorStyle, clearFocusedElement, backward, forward, previous, next.
	
	_diagram: null,
	_strategy: null,
	_strategyNumber: null,
	
	initialize: function(diagram){
	// summary:
    //		initialize the new instance.
    // diagram: ibm_ilog.diagram.widget.Diagram
    //		the associated diagram.		
		this._diagram = diagram;
		this.setNavigationStyle(Navigator.TreeStyle);
		return this._initialize();
	},
	changeNavigatorStyle: function(e){
		// summary:
		//		switches the navigation style
		this.setNavigationStyle((this._strategyNumber+1)%2);
	},
	clearFocusedElement: function(){
		// summary:
		//		clears the focus.
		this._diagram.setFocusedElement(null);
	},
	next: function(e){
		// Summary:
		//		apply the next operation according to the navigation style.
		this._strategy.next(e);
	},
	previous: function(e){
		// Summary:
		//		apply the previous operation according to the navigation style.
		this._strategy.previous(e);
	},
	forward: function(e){
		// Summary:
		//		apply the forward operation according to the navigation style.
		this._strategy.forward(e);
	},
	backward: function(e){
		// Summary:
		//		apply the backward operation according to the navigation style.
		this._strategy.backward(e);
	},
	getKeyInteractorId: function(){
		// summary:
	    //		returns the Interactor Id
		return Navigator.KeyInteractorId;
	},
	getDefaultConnections: function () {
		// summary:
		//		returns the default event mapping
		
		return {
			backward: {
				hotKey: keys.LEFT_ARROW,	
				connectTo: "backward",
				filter: this._buildInputFilter({ctrl:false,shift:false})
			}, forward: {
				hotKey: keys.RIGHT_ARROW,	
				connectTo: "forward",
				filter: this._buildInputFilter({ctrl:false,shift:false})
			}, previous: {
				hotKey: keys.UP_ARROW,	
				connectTo: "previous",
				filter: this._buildInputFilter({ctrl:false,shift:false})
			}, next: {
				hotKey: keys.DOWN_ARROW,	
				connectTo: "next",
				filter: this._buildInputFilter({ctrl:false,shift:false})
			}, changeNavigatorStyle: {
				hotKey: keys.F8,	
				connectTo: "changeNavigatorStyle"
			},clearFocusedElement: {
				hotKey: keys.ESCAPE,	
				connectTo: "clearFocusedElement"
			}
		};
	},
	setNavigationStyle: function(style){
		// Summary:
		//		sets the navigation style.
		// style: number
		//		one of the navigation styles
		this._strategyNumber = style;
		switch(style){
			case Navigator.TreeStyle: this._strategy = new TreeNavigator(this._diagram);break;
			case Navigator.GraphStyle: this._strategy = new GraphNavigator(this._diagram);break;
			default: this._strategy = new NullNavigator(this._diagram); this._strategyNumber = Navigator.NullStyle;break;
		}
	}
});

var NullNavigator =
declare("ibm_ilog.diagram.interactors.NullNavigator",null,{
	//summary:
	//		This class implements the disabled Navigation style. Also works as the superclass for others Navigation-Styles
	next: function(e){
		// Summary:
		//		do Nothing
	},
	previous: function(e){
		// Summary:
		//		do Nothing
	},
	forward: function(e){
		// Summary:
		//		do Nothing
	},
	backward: function(e){
		// Summary:
		//		do Nothing
	},
	_getFirstNode: function(){
		var children = this._diagram.getGraph().children;
		for(var i = 0;i<children.length;i++){
			if(children[i]._isIBMDiagramNode){
				return children[i];
			}
		}
		return null;
	},
	_getLastNode: function(){
		var children = this._diagram.getGraph().children;
		for(var i = (children.length-1);i>=0;i--){
			if(children[i]._isIBMDiagramNode){
				return children[i];
			}
		}
		return null;
	},
	_getChildIndex: function(array,element){
		for(index in array){
			if(element == array[index]){
				return parseInt(index);
			}
		}
		return -1;
	},
	_getVisibleParent: function(ge){
		// summary: 
		//		gets the lowest level visible element. If the Graph element is visible, return the same argument.
		// return: ibm_ilog.diagram.GraphElement
		var topMostCollapsedNode = null;
		var graph = this._diagram.getGraph();
		for(var p = ge.getParent(); p && p.getParent && p != graph; p = p._collapsedParent || p.getParent()){
			if(p._collapsedParent){
				for (var pp = p._collapsedParent; pp && pp.getParent; pp = pp.getParent()) {
					if (pp._isIBMDiagramSubgraph) {
						topMostCollapsedNode = pp;
						break;
					}
				}
			}
		}
		return topMostCollapsedNode || ge;
	},
	setFocusedElement: function(ge){
		// Summary:
		//		sets the ge to the diagram
		this._diagram.setFocusedElement(ge);
	}
});

/*=====
var NullNavigator = ibm_ilog.diagram.interactors.NullNavigator;
=====*/

var GraphNavigator =
declare("ibm_ilog.diagram.interactors.GraphNavigator",[NullNavigator],{
	//summary:
	//		This class implements the Graph Navigation style. The navigation is done througth 
	//		connections and record the path to enable backward navigation.
	_diagram: null,
	_stack: null,
	_clearOnNotification: null,
	_connections: null,
	
	constructor: function(diagram){
		this._diagram = diagram;
		this._stack = new Stack();
		this._clearOnNotification = true;
		this._connections = [];
		this._connections.push(connect.connect(this._diagram,'onFocusedElementChanged',this, function(){
			if(this._clearOnNotification){
				this.resetStack();
			}
		}));
	},
	next: function(e){
		// description:
		//		If Node focused: focus the first link of the focused node, and remember the 
		//		focused node as being the owner of the links being navigated.
		//		If Link focused: focus the previous link of previously focused node 
		//		(the node whose links are being navigated). If the currently focused link is 
		//		the first of the list, it does nothing.
		var ge = this.getFocusedElement();
		if(this._validateFocusedElement(ge)){
			this._nextConnection(ge);
		}
	},
	previous: function(e){
		// description:
		//		If Node focused: focus the last link of the focused node and remember 
		//		the focused node as being the owner of the links being navigated.
		//		If Link focused: focus the next link of previously focused node (the node 
		//		whose links are being navigated). If the currently focused link is the last 
		//		of the list, it does nothing.		
		var ge = this.getFocusedElement();
		if(this._validateFocusedElement(ge)){
			this._previousConnection(ge);
		}
	},
	forward: function(e){
		// description:
		//		If Node focused: focus the last link that was followed backwards (if any) 
		//		to get to that node. It is then possible to keep on browsing other links of 
		//		the previous node that was focused before ending up on the current one (navigating backwards).
		//		If Link focused: focus the endNode of the currently focused link, if any.		
		var ge = this.getFocusedElement();
		if(this._validateFocusedElement(ge)){
			this._followConnectionForward(ge);
		}
	},
	backward: function(e){
		// Summary:
		//		If Node focused: focus the last link that was followed forward (if any) to 
		//		get to that node. It is then possible to keep on browsing other links of the 
		//		previous node that was focused before ending up on the current one (navigating forward).
		//		If Link focused: focus the startNode of the currently focused link, if any.		
		
		var ge = this.getFocusedElement();
		if(this._validateFocusedElement(ge)){
			this._followConnectionBackwards(ge);
		}
	},
	_validateFocusedElement: function(ge){
		if(ge){
			var vp = this._getVisibleParent(ge);
			if(vp == ge){
				return true;
			}else{
				this.resetStack();
				this.setFocusedElement(vp);
				return false;
			}
		}else{
			this.resetStack();
			this.setFocusedElement(this._getFirstNode());
			return false;
		}
	},
	getFocusedElement: function(){
		// summary: 
		//		gets the focused GraphElement from the diagram
		// return: ibm_ilog.diagram.GraphElement
		return this._diagram.getFocusedElement();
	},
	_followConnectionBackwards: function(ge){
		if(ge._isIBMDiagramNode){
			if(this._stack.peek() && this._stack.peek()._isIBMDiagramLink){
				this.setFocusedElement(this._stack.pop());
			}
		}else{
			var node = this._getLinkedNode(ge,true);
			this.setFocusedElement(node);
			if(this._stack.peek() == node){
				this._stack.pop();
			}else{
				this._stack.push(ge);
			}
		}
	},
	_followConnectionForward: function(ge){
		if(ge._isIBMDiagramNode){
			if(this._stack.peek() && this._stack.peek()._isIBMDiagramLink){
				this.setFocusedElement(this._stack.pop());
			}
		}else{
			var node = this._getLinkedNode(ge,false);
			this.setFocusedElement(node);
			if(this._stack.peek() == node){
				this._stack.pop();
			}else{
				this._stack.push(ge);
			}
		}		
	},
	_nextConnection: function(ge){
		if(ge._isIBMDiagramNode){
			var links = this._getElementLinks(ge);
			if(links.length>0){
				this.setFocusedElement(links[0]);
				this._stack.push(ge);
			}
		}else{
			var link = this._getFollowingLink(ge,1);
			if(link){
				this.setFocusedElement(link);
			}
		}
	},
	_previousConnection: function(ge){
		if(ge._isIBMDiagramNode){
			var links = this._getElementLinks(ge);
			if(links.length>0){
				this.setFocusedElement(links[links.length-1]);
				this._stack.push(ge);
			}
		}else{
			var link = this._getFollowingLink(ge,-1);
			if(link){
				this.setFocusedElement(link);
			}
		}
	},
	resetStack: function(){
		// summary:
		//		clears the navigation stack
		this._stack.clear();
	},
	_getFollowingLink: function(ge,increment){
		var links = this._getElementLinks(this._stack.peek());
		var index = this._getChildIndex(links,ge); 
		for(var i = index+increment;i>=0 && i<links.length;i=i+increment){
			return links[i];
		}
		return null;
	},
	setFocusedElement: function(ge){
		// summary:
		//		calls the superclass method, but disable the clearNotification
		this._clearOnNotification = false;
		this.inherited(arguments);
		this._clearOnNotification = true;
	},
	_getLinkedNode: function(link,start){
		var port;
		if(start){
			port = link.getStartPort();
		}else{
			port = link.getEndPort();
		}
		port = link._getVisiblePort(port);
		return port.getOwner();
	},
	_getElementLinks: function(ge){
		var result = ge.getLinks();
		if(ge._isIBMDiagramSubgraph){
			result = result.concat(ge.getIntergraphLinks());
		}
		return result;
	}
});

var TreeNavigator =
declare("ibm_ilog.diagram.interactors.TreeNavigator",[NullNavigator],{
	//summary:
	//		This class implements the Tree Navigation style.
	_diagram: null,
	constructor: function(diagram){
		this._diagram = diagram;
	},
	next: function(e){
		// description:
		//		focus the next sibling of the currently selected Node. If there is no such sibling, 
		//		it focus the next sibling of the parent of the currently selected node, provided that the 
		//		parent it not the root graph. In this case, it does nothing.
				
		var ge = this.getFocusedElement();
		if(this._validateFocusedElement(ge)){
			this.nextNode(ge);
		}
	},
	previous: function(e){
		// description:
		//		focus the next sibling of the currently selected Node. If there is no such sibling, 
		//		it focus the next sibling of the parent of the currently selected node, provided that the 
		//		parent it not the root graph. In this case, it does nothing.	
		var ge = this.getFocusedElement();
		if(this._validateFocusedElement(ge)){
			this.previousNode(ge);
		}
	},
	forward: function(e){
		// description:
		//		opens the currently selected Node if it is a closed Subgraph. 
		//		If it is an opened Subgraph, or if it is not a Subgraph, it does nothing.		
		var ge = this.getFocusedElement();
		if(this._validateFocusedElement(ge)){
			this._openNode(ge);
		}
	},
	backward: function(e){
		// description:
		//		closes the currently selected Node if it is an opened Subgraph. If is is a closed subgraph,
		//		or if it is not a Subgraph, it focus the parent of the currently selected node, provided 
		//		that the parent it not the root graph. In this case, it does nothing.	
		var ge = this.getFocusedElement();
		if(this._validateFocusedElement(ge)){
			this._closeNode(ge);
		}
	},
	_validateFocusedElement: function(ge){
		if(ge){
			var vp = this._getVisibleParent(ge);
			if(vp == ge){
				return true;
			}else{
				this.setFocusedElement(vp);
				return false;
			}
		}else{
			this.setFocusedElement(this._getFirstNode());
			return false;
		}
	},
	nextNode: function(ge){
		this._nextNode(ge,1);
	},
	previousNode: function(ge){
		this._nextNode(ge,-1);
	},
	_nextNode: function(c,increment){
		if(c){
			if(c._isIBMDiagramNode){
				var p = c.getParent();
				var next = this._getFollowingNode(p.children,c,increment);
				if(next){
					this.setFocusedElement(next);
				}else{
					this._nextNode(p._owningSubgraph,increment);
				}
			}
		}else{
			if(increment>0){
				this.setFocusedElement(this._getFirstNode());
			}else{
				this.setFocusedElement(this._getLastNode());
			}
		}
	},
	_openNode: function(ge){
		if(ge && ge._isIBMDiagramSubgraph){
			if(ge.isCollapsed() && ge.canCollapse()){
				ge.setCollapsed(false);	
			}else{
				var children = ge.getGraph().children;
				if(children.length>0){
					this.setFocusedElement(children[0]);
					return;
				}
			}
		}
	},
	_closeNode: function(ge){
		var ge = this.getFocusedElement();
		if(ge && ge._isIBMDiagramNode){
			if(ge._isIBMDiagramSubgraph && !ge.isCollapsed() && ge.canCollapse()){
				ge.setCollapsed(true);	
			}else{
				var parent = ge.getParent()._owningSubgraph;
				if(parent){
					this.setFocusedElement(parent);
				}
			}
		}
	},
	getFocusedElement: function(){
		// summary: 
		//		gets the focused Node from the diagram
		// return: ibm_ilog.diagram.Node
		var ge = this._diagram.getFocusedElement();
		if(ge && !ge._isIBMDiagramLink) {
			return ge;
		}
		return null;
	},
	_getFollowingNode: function(array,element,increment){
		var index = this._getChildIndex(array,element); 
		for(var i = index+increment;i>=0 && i<array.length;i=i+increment){
			if(array[i]._isIBMDiagramNode){
				return array[i];
			}
		}
		return null;
	}
});
// null navigation style
Navigator.NullStyle = -1;
// tree navigation style
Navigator.TreeStyle = 0;
// graph navigation style
Navigator.GraphStyle = 1;

// the interactor Id
Navigator.KeyInteractorId = "Navigator";

return Navigator;

});
