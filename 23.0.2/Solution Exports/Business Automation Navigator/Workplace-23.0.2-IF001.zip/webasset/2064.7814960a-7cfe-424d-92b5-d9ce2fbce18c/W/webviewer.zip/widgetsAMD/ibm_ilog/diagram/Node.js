/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["./main",
"dojo/_base/declare", "dojo/_base/array", "dojo/_base/config",
"dojox/gfx", "dojox/gfx/matrix",
"./GraphElement", "./templating", "./templates/templates", "./gfxlayout",
"./util/Geometry", "./util/ClippingUtil"
],
function(iid, declare, array, config, gfx, matrix, GraphElement, templating, templates, gfxlayout, g, ClippingUtil){
	
	var Rect = g.Rect, EmptyRect = g.EmptyRect, Size = g.Size, PointZero = g.PointZero, Point = g.Point;
	
/*=====
var GraphElement = ibm_ilog.diagram.GraphElement;
=====*/

var Node = 
declare("ibm_ilog.diagram.Node", [GraphElement], {
    // summary:
    //		A Node is a graphic object that can be connected to other nodes using Link objects.
    
    // Allows to test the class faster that testing declaredClass
    _isIBMDiagramNode: true,

  	//
  	//	TID: String
  	//		Graph element Type ID, used to distinguish basic graph 
    //		element types:
    //	
    //			N = Node
    //			S = Subgraph
    //			L = Link
    //	
  	//		Usually used as a very fast index into maps based on 
    //		ibm_diagram graph element types.
  	//
    TID: 'N',
    
    _ports: null,
 
    constructor: function() {
        if (config.useGfxLayout) {
            this.setLayout(new gfxlayout.GridLayout());
        }
    },
    
    //---------- Disposal ----------
    
    _dispose: function() {
        // summary:
        //		Dispose this Node.
        // description:
        //		This function should be called when the node is completely deleted, that is, when it is removed
        //		from its parent graph and it will never be used again.
        
        array.forEach(this.getLinks(), function(link) {
            if (link.getStartNode() == this) 
                link.setStartPort(null);
            if (link.getEndNode() == this) 
                link.setEndPort(null);
        });
    },
    
    // ---------- Ports management: ----------
    
    addPort: function(/*ibm_ilog.diagram.PortBase*/port) {
        // summary:
        //		Adds a port to this node.
        // port: ibm_ilog.diagram.PortBase:
        //		The port to add.
        if (!this._ports) 
            this._ports = [port];
        else 
            this._ports.push(port);
        port._setOwner(this);
    },
    
    removePort: function(/*ibm_ilog.diagram.PortBase*/port) {
        // summary:
        //		Removes a port from this node.
        // port: ibm_ilog.diagram.PortBase:
        //		The port to remove.
        if (this._ports) {
            var index = array.indexOf(this._ports, port);
            if (index >= 0) {
                port._setOwner(null);
                if (this._ports.length == 1) 
                    this._ports = null;
                else 
                    this._ports.splice(index, 1);
            }
        }
    },
    
    getPorts: function() {
        // summary:
        //		Returns the ports of this node.
        // returns:
        //		An array of PortBase objects.
        // description:
        //		Note that this method always returns a newly allocated array.
        var ports = [];
        if (this._ports) {
            for (var i = 0; i < this._ports.length; i++) 
                ports.push(this._ports[i]);
        }
        return ports;
    },
    
    _invalidateLinks: function() {
        // tag: private
        // summary:
        //		Invalidates the shape of all the links connected to this node. 
        // description:
        //		This method is internal and should not be called directly by application code.
        if (this._ports) {
            for (var i = 0; i < this._ports.length; i++) {
                this._ports[i].invalidateLinks();
            }
        }
    },
    
	_setParent: function(parent, matrix)
	{
		GraphElement.prototype._setParent.call(this, parent, matrix);
        if (this._ports) {
            for (var i = 0; i < this._ports.length; i++) {
				var p = this._ports[i];
				if(p._links){
					for(var j = 0; j < p._links.length; j++)
						p._links[j]._forceCheckIntergraphLink();
				}
            }
        }
	},
	
    // ---------- Get connected links: ----------
    
    getLinks: function(starting, ending) {
        // summary: 
        //		Gets the links whose start and/or end nodes are equal to this node.
        // description:
        //		If starting is not false, the method returns all the links whose start nodes are this node.
        //		If ending is not false, the method returns all the links whose end nodes are this node.
        // starting: Boolean:
        //		If this argument is not false (e.g., true or undefined), links whose start nodes are equal to this node are returned.
        // ending: Boolean:
        //		If this argument is not false (e.g., true or undefined), links whose end nodes are equal to this node are returned.
        // returns:
        //		An array of ibm_ilog.diagram.Link objects.
        // example:
        //		node.getLinks()
        //		node.getLinks(true, true)
        //		node.getLinks(true)
        //				 These 3 calls return all the links connected to the node.
        // example:
        //		node.getLinks(true, false)
        //				 This call returns the links starting at the node.
        // example:
        //		node.getLinks(false)
        //		node.getLinks(false, true)
        //				 These 2 calls return the links ending at the node.
        // example:
        //		node.getLinks(false, false) 
        //				This call always returns an empty array.
        
        var result = [];
        if (this._ports !== null && (starting != false || ending != false)) {
            array.forEach(this._ports, function(p) {
                array.forEach(p.getLinks(), function(link) {
                    if ((starting != false && link.getStartPort() === p) ||
                    (ending != false && link.getEndPort() === p)) {
                        if (array.indexOf(result, link) < 0) 
                            result.push(link);
                    }
                }, this);
            }, this);
        }
        return result; // Array
    },
    
    // ---------- Base shape: ----------
    
    getBaseShape: function() {
        // summary:
        //		Gets the base shape of the node.
        // description:
        //		The base shape for various purposes, for example links will typically
        //		be connected to the base shape instead of the overall bounding rectangle of the node.
        //		By default, the base shape is the shape contained in the node template
        //		whose dojoAttachPoint property is set to "baseShape". In the default template,
        //		this is a rounded rectangle. If not baseshape exists in the template, the
        //		Node itself is returned.
        
        return this.baseShape || this;
    },
    
    // ---------- Bounds: ----------
    
    getBounds: function(/*dojox.gfx.Group*/parent) {
        // summary:
        //		Returns the bounds of this node in the coordinate space of the specified parent.
        // parent: dojox.gfx.Group
        //		The parent object that determines the coordinate space
        //		the bounds are relative to. If null or undefined, the bounds of the node
        //		relative to its parent are returned.
        // returns:
        //		A rectangle (i.e. an object with x/y/width/height properties) containing
        //		the bounds of the node in the specified coordinate space.

        var rect = this.getLocalBoundingBox();
        if (rect && parent && parent != this.getParent()) {
            var t = this.getTransformToContainer(parent);
            rect = t.transformRectangle(rect);
        }
        return rect;
    },
    
    setBounds: function(rect, /*dojox.gfx.Group*/ parent) {
        // summary:
        //		Changes the transform of this node so that its bounds will be a given rectangle,
        //		in the coordinate space of the specified parent.
        // rect:
        //		A rectangle (i.e. an object with x/y/width/height properties) containing
        //		the new bounds of the node in the specified coordinate space.
        // parent: dojox.gfx.Group
        //		The parent object that determines the coordinate space
        //		the bounds are relative to. If null or undefined, the bounds of the node
        //		relative to its parent are changed.
        
        if (parent && parent != this.getParent()) {
            var t = this.getTransformToContainer(parent);
            t = t.inverse();
            rect = t.transformRectangle(rect);
        }
        
        if (config.useGfxLayout) {
            // if this Node has a layout, set its clientRectangle
            if (this.getLayout()) {
                this.setExplicitSize(rect);
				this.move(rect.x, rect.y, parent);
            // maybe it contains a panel as only child
            } else if (this.children.length === 1 && this.children[0].children && this.children[0].getLayout()) {
                this.children[0].setExplicitSize(rect);
            // fallback: uses transform
            } else {
                var oldBounds = this.getLocalBoundingBox();
                if (oldBounds === null) {
                    this.applyLeftTransform(matrix.translate(rect.x, rect.y));
                } else if (rect.x != oldBounds.x ||
                rect.y != oldBounds.y ||
                rect.width != oldBounds.width ||
                rect.height != oldBounds.height) {
                    this.applyLeftTransform(matrix.createFromRectangles(oldBounds, rect));
                }
            }
        } else {
                var oldBounds = this.getLocalBoundingBox();
                if (oldBounds === null) {
                    this.applyLeftTransform(matrix.translate(rect.x, rect.y));
                } else if (rect.x != oldBounds.x ||
                           rect.y != oldBounds.y ||
                           rect.width != oldBounds.width ||
                           rect.height != oldBounds.height) {
                    this.applyLeftTransform(matrix.createFromRectangles(oldBounds, rect));
                }
        }
    },
    
    allowsResize: function() {
    	return false;
    },

    minimumSize: Size(10,10),
    
    move: function(/*number*/x, /*number*/ y, /*dojox.gfx.Group*/ parent) {
        // summary:
        //		Moves the node to the specified position.
        // description:
        //		This function changes the node's transform so that the top-left of its bounds
        //		(in the parent coordinate space) will be the specified 'x'and 'y' arguments
        
        
        if (parent && parent != this.getParent()) {
            var t = this.getTransformToContainer(parent);
            t = t.inverse();
            var p = {
                x: x,
                y: y
            };
            p = t.transformPoint(p);
            x = p.x;
            y = p.y;
        }

        var oldBounds = this.getLocalBoundingBox();
        if (oldBounds) {
            if (x != oldBounds.x || y != oldBounds.y) 
                this.applyLeftTransform(matrix.translate(x - oldBounds.x, y - oldBounds.y));
        } else {
            this.applyLeftTransform(matrix.translate(x, y));
        }
    },
    
    onBoundsChanged: function() {
        // summary:
        //		This event is called to signal that the bounds of the node have changed.
    },
    
    _onChanged: function(shape, reason) {
    	// This method is called a lot, keep it short and fast :).
    	
    	// <inlining this call from BoundingBoxFix at diagext.js>
    	// 
    	// this.inherited(arguments);
    	this._bbCacheValid = false;
    	// <end inline>

    	if(!Node._ChangesInvalidateLinksDisabled) {
    		this._invalidateLinks();
    	}
    	this.onBoundsChanged(shape,reason); // bounds probably changed
    },
    
    hitTest: function(p,graph,tolerance){
    	// Summary:
    	//		return if the given point hits the element
    	
    	if(tolerance == null){
    		tolerance = 0;
    	}
    	var bounds = this.getBounds(graph);
    	if(!bounds) {
    		return false;
    	}
    	var bb = g.expandRect(bounds,tolerance);
    	if(g.containsPoint(bb,p)) {
    		var shape = this.getBaseShape();
    		if(shape != this){
    			var referencePoint = g.Point(0,0);
    			var clipConnectionPoint = this._getExternalPoint(bb);
    			// This solution only works with closed shapes
    			var completeResult = {};
    			ClippingUtil.clipToShape(this,graph,shape,bounds,referencePoint, clipConnectionPoint, p,completeResult);
    			// If the point is inside the node, the number of intersection must be even
    			if( (completeResult.numberOfResults%2) == 1){
					return true;
				}else{
					return false;
				}
    		}else{
    			return true;
    		}
    	}
    	return false;
    },
    
    _getExternalPoint: function(bounds){
    	var margin = 30;//this margin is to ensure that the point is outside the node shape (as the bb is not correctly on path shapes, this is big)
    	return g.Point(bounds.x-margin,bounds.y-margin);
    },
    
    __eod: undefined
   
});

// Declare bindable properties
templating.declareBindableProperty(Node, "label", "");
templating.declareBindableProperty(Node, "wrap", true);
templating.declareBindableProperty(Node, "annotation", ""); // used by annotation adorners
templating.declareBindableProperty(Node, "tooltip", ""); // used to generate a tooltip on hover
templating.declareBindableProperty(Node, "backgroundColor", "#ADD7FF");
templating.declareBindableProperty(Node, "selectedBackgroundColor", "#0000FF");
templating.declareBindableProperty(Node, "borderColor", "#808080");
templating.declareBindableProperty(Node, "textColor", "#000000");
templating.declareBindableProperty(Node, "selectedTextColor", "#FFFFFF");
templating.declareBindableProperty(Node, "data", null);
templating.declareBindableProperty(Node, "textDir", "");

// Default node template
Node.defaultTemplate = iid.declareTemplate(templates.defaultNodeTemplate);

Node.nodeType = gfx.Group.nodeType;
Node.defaultShape = {
    type: 'node'
};

return Node;

});
