/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"../main",
"dojo/_base/declare",
"dojox/gfx/utils",
"./TemplatedOverlay"
],
function(
iid,
declare,
gfxu,
TemplatedOverlay
){

/*=====
var TemplatedOverlay = ibm_ilog.diagram.adorners.TemplatedOverlay;
=====*/

var AdornerHandle =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.adorners.AdornerHandle', TemplatedOverlay,{
		
		initialize: function(adorner,template) {
			this._adorner = adorner;
			this._template = template;
			this.applyTemplate(this._template);
		},
		getAdorner: function(){
			return this._adorner;
		},
		getViewport: function() {
			return this._adorner.getViewport();
		},
		
		add: function(toShow){
			// Summary:
			//		if IE browser, restore the saved Styles
			this.inherited(arguments); 
			if (iid.isVml) {
	             this._restoreStyles(toShow);
	         }
		},
		
		remove: function(toHide){
			// Summary:
			//		if IE browser, saves the Styles before removing the elements from its parent
			//		Workaround for IE: removing a shape clears all its styles.
			if (iid.isVml) {
	                this._saveStyles(toHide);
	         }
			 this.inherited(arguments);
		},
		
		_saveStyles: function(group) {
	        // summary:
	        //		Workaround for IE: removing a shape clears all its styles.
	        // tags:
	        //		private
	        gfxu.forEach(group, function(shape) {
	            if (shape.setFill) {
	                shape.oldFill = shape.getFill();
	            }
	            if (shape.setStroke) {
	                shape.oldStroke = shape.getStroke();
	            }
	            if (shape.setFont) {
	                shape.oldFont = shape.getFont();
	            }
	            if (shape.setFont) {
	                shape.oldFont = shape.getFont();
	            }
	            if (shape.setShape) {
	                shape.oldShape = shape.getShape();
	            }
	        }, null);
	    },
	    
	    _restoreStyles: function(group) {
	        // summary:
	        //		Workaround for IE: removing a shape clears all its styles.
	        // tags:
	        //		private
	        gfxu.forEach(group, function(shape) {
	            if (shape.oldFill) {
	                shape.setFill(shape.oldFill);
	            }
	            if (shape.oldStroke) {
	                shape.setStroke(shape.oldStroke);
	            }
	            if (shape.oldFont) {
	                shape.setFont(shape.oldFont);
	            }
	            if (shape.oldShape) {
	                shape.setShape(shape.oldShape);
	            }
	        }, null);
	    }
		
	}));

return AdornerHandle;

});

