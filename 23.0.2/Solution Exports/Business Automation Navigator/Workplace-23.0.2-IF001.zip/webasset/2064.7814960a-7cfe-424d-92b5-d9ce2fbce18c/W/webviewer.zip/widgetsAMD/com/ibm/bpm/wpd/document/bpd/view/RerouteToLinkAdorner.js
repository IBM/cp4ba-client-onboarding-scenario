/**
 * A link adorner that is meant to signify that the link is a "non-taken" fork in a path. Pressing
 * the adorner indicates that the path should be rerouted through the adorned link.
 * 
 */
define([
   "dojo/_base/declare",
   "dojo/_base/lang",
   "dojo/_base/event",
   "dojox/gfx/_base",
   "dijit/Tooltip",
   "dojo/_base/Color",
   "dojox/collections/Dictionary",
   "ibm_ilog/diagram/adorners/Adorner",
   "dojo/i18n!./nls/BPDViewerResources",
   "./CenteredILogLinkAdorner",
   "./TemplatedAdorner",
   "./adornerConstants",
   "./ilogDiagramUtils"
], function(
   declare,
   lang,
   event,
   gfx,
   Tooltip,
   Color,
   Dictionary,
   ILogAdorner,
   nls,
   CenteredILogLinkAdorner,
   TemplatedAdorner,
   adornerConstants,
   ilogDiagramUtils) {
   return declare([
      TemplatedAdorner
   ], {

      HIGHLIGHT_COLOR : [
         222, 232, 238
      ],

      UN_HIGHLIGHT_COLOR : [
         236, 241, 245
      ],

      BUTTON_WIDTH : 25,
      BUTTON_HEIGHT : 25,
      BUTTON_ROUNDING : 6,
      ICON_SIZE : 25,

      ADORNER_CLICKED : "ADORNER_CLICKED",

      ICON_PATHS : {
         basePath : ilogDiagramUtils.toUrl("com.ibm.bpm.wpd/images/") + "Lhotse_setpath.png",
         hoverPath : ilogDiagramUtils.toUrl("com.ibm.bpm.wpd/images/") + "Lhotse_setpath_hover.png"
      },

      linkAdornerRerouteButtonTemplate : {
         dojoAttachPoint : 'linkAdornerButton',
         transform : {
            dx : $bind("{{linkCenteredX}}"),
            dy : $bind("{{linkCenteredY}}")
         },
         children : [
            {
               dojoAttachPoint : 'rerouteBaseRectangle',
               shape : {
                  width : 25,
                  height : 25,
                  r : 6,
                  type : 'rect'
               },
               fill : {
                  r : 236,
                  g : 241,
                  b : 245,
                  a : 0.0
               },
               stroke : {
                  color : [
                     0, 0, 0, 0.50
                  ],
                  width : 0
               }
            }, {
               dojoAttachPoint : 'rerouteIcon',
               shape : {
                  x : 0,
                  y : 0,
                  width : 25,
                  height : 25,
                  src : "",
                  type : 'image'
               }
            }, {
               dojoAttachPoint : 'rerouteEventRectangle',
               shape : {
                  width : 25,
                  height : 25,
                  r : 6,
                  type : 'rect'
               },
               fill : {
                  r : 0,
                  g : 0,
                  b : 0,
                  a : 0.0
               }
            }

         ]
      },

      constructor : function(args) {
         lang.mixin(this, args);
      },

      adorn : function() {
         try {
            // If already adorned, nothing to do.
            if (this.adorned)
               return;
            // If not a link, then don't know what to do.
            if (this.adornerTarget.type != adornerConstants.TYPE_LINK)
               return;
            // Resolve the node.
            var gfxLink = ilogDiagramUtils.getGfxLinkById(this.adornerTarget.ilogDiagram, this.adornerTarget.id);
            if (!gfxLink)
               return;
            // Create and set the halo from the passed in args
            var template = lang.clone(this.linkAdornerRerouteButtonTemplate);
            template.children[1].shape.src = this.ICON_PATHS.basePath;
            var dic = new Dictionary();
            dic.add("RerouteToLinkAdorner", template);
            this.ilogAdorner = this.adornerTarget.ilogDiagram.createAdorner(CenteredILogLinkAdorner, dic, "RerouteToLinkAdorner");
            this.ilogAdorner.centeredElementWidth = this.BUTTON_WIDTH;
            this.ilogAdorner.centeredElementHeight = this.BUTTON_HEIGHT;
            this.unAdornInfo.adorner = this.ilogAdorner;
            this.ilogAdorner.setAdorned(gfxLink);
            this.registerEventListeners();
            this.createTooltip();
            this.inherited(arguments);
         } catch (e) {
            console.error(e);
         }
      },

      registerEventListeners : function() {
         var currEvt = this.ilogAdorner.rerouteEventRectangle.connect("onmouseover", this, function(e) {
            this.setHighlighted();
         });
         this.eventHandles.push(currEvt);
         currEvt = this.ilogAdorner.rerouteEventRectangle.connect("onmouseout", this, function(e) {
            this.setUnhighlighted();
         });
         this.eventHandles.push(currEvt);
         currEvt = this.ilogAdorner.rerouteEventRectangle.connect("onmousedown", this, function(e) {
            event.stop(e);
            this.click();
         });
         this.eventHandles.push(currEvt);
         currEvt = this.ilogAdorner.rerouteEventRectangle.connect("ontouchstart", this, function(e) {
            event.stop(e);
            this.click();
         });
         this.eventHandles.push(currEvt);
      },

      setHighlighted : function() {
         // this.ilogAdorner.rerouteBaseRectangle.setFill(new Color(this.HIGHLIGHT_COLOR));
         var shape = this.ilogAdorner.rerouteIcon.shape;
         shape.src = this.ICON_PATHS.hoverPath;
         this.ilogAdorner.rerouteIcon.setShape(shape);
      },

      setUnhighlighted : function() {
         // this.ilogAdorner.rerouteBaseRectangle.setFill(new Color(this.UN_HIGHLIGHT_COLOR));
         var shape = this.ilogAdorner.rerouteIcon.shape;
         shape.src = this.ICON_PATHS.basePath;
         this.ilogAdorner.rerouteIcon.setShape(shape);
      },

      click : function() {
         this.onEvent(this, this.ADORNER_CLICKED, null);
      },

      createTooltip : function() {
         var node = this.ilogAdorner.rerouteEventRectangle.rawNode;
         node["offsetWidth"] = 0; // Kludge to get FF working (See
         // http://trac.dojotoolkit.org/ticket/16310
         var tt = new Tooltip({
            connectId : [
               node
            ],
            label : nls.CLICK_TO_REROUTE,
            position : [
               "below"
            ],
            showDelay : 900
         });
         this.tooltips.push(tt); // Need this in FF tooltip stays around if the adorner is deleted.
      },

      /**
       * Called as part of adorn and when the viewer is resized.
       * 
       */
      updateLayout : function() {
         try {
            if (!this.ilogAdorner)
               return;
            // Scale what needs to be scaled
            var zoom = this.ilogAdorner.getZoom();
            var width = Math.round(this.BUTTON_WIDTH * zoom);
            var height = Math.round(this.BUTTON_HEIGHT * zoom);
            var rounding = Math.round(this.BUTTON_ROUNDING * zoom);
            var iconSize = Math.round(this.ICON_SIZE * zoom);
            // Now layout the shapes.
            var shape = this.ilogAdorner.rerouteBaseRectangle.shape;
            shape.width = width;
            shape.height = height;
            shape.r = rounding;
            this.ilogAdorner.rerouteBaseRectangle.setShape(shape);
            shape = this.ilogAdorner.rerouteIcon.shape;
            shape.width = iconSize;
            shape.height = iconSize;
            shape.x = (width > iconSize) ? (width - iconSize) / 2 : (iconSize - width) / 2;
            shape.y = (height > iconSize) ? (height - iconSize) / 2 : (iconSize - height) / 2;
            this.ilogAdorner.rerouteIcon.setShape(shape);
            shape = this.ilogAdorner.rerouteEventRectangle.shape;
            shape.width = width;
            shape.height = height;
            shape.r = rounding;
            this.ilogAdorner.rerouteEventRectangle.setShape(shape);
         } catch (e) {
            console.error(e);

         }
      }
   });

});
