/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/event",
"./Interactor"
],
function(
declare,
event,
Interactor
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var FocusInteractor =
declare("ibm_ilog.diagram.interactors.FocusInteractor", [Interactor], {
	//
	//	summary:
	//

	//
	//	_viewport: ibm_ilog.diagram.widget.Viewport
	//		The diagram viewport 
	//
	_viewport: null,

	//
	//	_diagram: ibm_ilog.diagram.widget.Diagram
	//
	_diagram: null,

	//
	//	_diagram: ibm_ilog.diagram.widget.Diagram
	//
	_graph: null,

	initialize: function ( /*ibm_ilog.diagram.widget.Diagram*/ diagram ) {
		this._diagram = diagram;
		this._graph = diagram.getGraph();
		this._viewport = diagram.getViewport();
		this._initialize();
		return this;
	},

	_declareStates: function () {
		this._declareState("idle", ["changeFocus"]);
	},

	getDefaultConnections: function () {
		//
		//	summary:
		//		returns the default event mapping
		//
		return {
			changeFocus: {
				src: this._viewport.getEventSource(),
				srcEvt: "onmousedown",
				connectTo: "_changeFocus",
				gfxConnect: true
			}
		};
	},

	_getGraphElementFromEvent: function (e) {
		// Summary:
		//		return the selection object
		var ge = this._getGraphElementFromEventInRoot(e, this._graph);
		return ge !== this._graph ? ge : null;
	},
	
	_changeFocus: function (e) {

		this._diagram.setFocusedElement(this._getGraphElementFromEvent(e));

		event.stop(e);
	},

	onEnabled: function () {
		this._goStateId("idle");
	},

	onDisabled: function () {
		this._goState(null);
	}
	
});

return FocusInteractor;

});