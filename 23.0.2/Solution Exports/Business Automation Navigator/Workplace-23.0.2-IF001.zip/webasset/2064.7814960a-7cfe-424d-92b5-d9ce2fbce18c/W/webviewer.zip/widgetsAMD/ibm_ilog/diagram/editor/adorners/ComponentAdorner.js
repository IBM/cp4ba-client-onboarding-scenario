/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojox/gfx/matrix",
"../../base",
"../../templating",
"../../adorners/Adorner",
"../../util/GraphUtil",
"../../util/Geometry"
], function(
declare,
m,
iid,
templating,
Adorner,
GraphUtil,
g
){

/*=====
var Adorner = ibm_ilog.diagram.adorners.Adorner;
=====*/

	var Rect = g.Rect;
	
	var __invisibleLocation = g.Rect(iid._invisibleLocation, iid._invisibleLocation, iid._invisibleSize, iid._invisibleSize);

	var ComponentAdorner =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.ComponentAdorner', [Adorner], {

	//	summary:
	//		An adorner for adorning components of Graph elements. 
	//
		
	//
	// _component: dojox.gfx.Shape
	//
	_component: null,
	
	//
	//	_componentBounds: dojox.gfx.Rect
	//
	_componentBounds: null,
	
	
	setComponent: function( /*Shape|string|null*/ component ) {
		//
		// 	summary:
		//		Sets the attachPoint name of visual shape associated with the property. 
		//		If null the whole element shape is asummed.
		//
		if(component && typeof(component) == "string") {
			this._component = this[component];
		} else {
			this._component = component;
		}
	},

	getComponent: function() {
		//
		//	summary:
		//		Returns the attachPoint name of the visual shape associated with the property. 
		//
		return this._component;
	},
	
	_computeElementBoundsChanged: function () {
		//
		//	summary:
		//		Recomputes the geometric values published to the template (adds 
		//		property component bounds to the values already computed in the 
		//		superclass)   
		//
	  var c,bb;
	  // compute component bounds	  
	  if(this._component && this._required() ) {
			c = this._component;
			  
			bb = c.getBoundingBox();
			if(bb) { // gfx does not support this properly, some renderers may fail. Fallback to node BB
				var pm = this._diagram.getGraph()._getRealMatrix().inverse();
				var cm = c.getParent()._getRealMatrix() || m.identity;
				var t = m.multiply(pm,cm);
				this._componentBounds = t.transformRectangle(bb);
		  } else {
		  	this._componentBounds = null;
		  }
	  } else {
	  	this._componentBounds = null;
	  }
	  this.inherited(arguments);
	},
	
	_updateLayout: function() {
		//
		//	summary:
		//		Publish new geometric values (causes template bindings to be applied if changed).
		//
		
		this.startDTLBatch();

		this.inherited(arguments);
		
		// also publish component-related coords (fallback to element coords if not present)
		
		var bb = __invisibleLocation;
		if (this._adorned) {
			bb = this._viewport.contentToClient().transformRectangle(this._componentBounds || this._elementBounds);
		}
		this.setCompWidth(bb.width);
		this.setCompHeight(bb.height);
		this.setCompRight(bb.x + bb.width);
		this.setCompBottom(bb.y + bb.height);
		this.setCompLeft(bb.x);
		this.setCompTop(bb.y);
		this.setCompCenterX(bb.width / 2);
		this.setCompCenterY(bb.height / 2);
		
		this.endDTLBatch();
	}
	
}));

templating.declareBindableProperty(ComponentAdorner, "compLeft", null);
templating.declareBindableProperty(ComponentAdorner, "compTop", null);
templating.declareBindableProperty(ComponentAdorner, "compBottom", null);
templating.declareBindableProperty(ComponentAdorner, "compRight", null);
templating.declareBindableProperty(ComponentAdorner, "compWidth", null);
templating.declareBindableProperty(ComponentAdorner, "compHeight", null);
templating.declareBindableProperty(ComponentAdorner, "compCenterX", null);
templating.declareBindableProperty(ComponentAdorner, "compCenterY", null);

return ComponentAdorner;

});
