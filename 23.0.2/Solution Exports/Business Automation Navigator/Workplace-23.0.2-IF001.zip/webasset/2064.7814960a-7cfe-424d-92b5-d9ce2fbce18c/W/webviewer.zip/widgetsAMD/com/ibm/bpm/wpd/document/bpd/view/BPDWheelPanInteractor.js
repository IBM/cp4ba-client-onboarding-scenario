/**
 * A Wheel Pan (the wheel on a mouse) interactor that limits scrolling
 */
define([
   "dojo/_base/declare", "dojo/_base/lang", "dojo/_base/event", "ibm_ilog/diagram/interactors/WheelPanInteractor"
], function(declare, lang, event, WheelPanInteractor) {

   return declare([
      WheelPanInteractor
   ], {
      _wheelPan : function(e) {
         var isLeftRight = false;
         var isUpDown = false;

         if (!!e && !!e.type && e.type == "DOMMouseScroll") {
             isLeftRight = e.axis == e.HORIZONTAL_AXIS;
             isUpDown = e.axis == e.VERTICAL_AXIS;
         } else if (!!e.wheelDeltaX || !!e.wheelDeltaY) {
             isLeftRight = e.wheelDeltaX != 0;
             isUpDown = e.wheelDeltaY != 0;
         } else {
             // Can not determine direction of mouse wheel scroll, assume it is up/down
             isUpDown = true;
         }

         // This is to prevent the process diagram from scrolling within a large viewport
         var r = this._viewport.getViewRect();
         var cr = this._viewport.getContentRect();
         if ((isUpDown && r.height >= cr.height) ||
             (isLeftRight && r.width >= cr.width)) {
             event.stop(e);
             return;
         }

         var delta = this._incrementFactor / this._viewport.getZoom();
         if (this.eventWheelAmmount(e) > 0)
            delta = -delta;
         r = {
            x : r.x,
            y : r.y,
            width : r.width,
            height : r.height
         };

         if (isUpDown) {
             r.y += delta;
             if (delta < 0) {
                if (r.y < cr.y)
                   r.y = cr.y;
             } else {
                if (r.y + r.height > cr.y + cr.height)
                   r.y = cr.y + cr.height - r.height;
             }
         }
         if (isLeftRight) {
             r.x += delta;
             if (delta < 0) {
                if (r.x < cr.x)
                   r.x = cr.x;
             } else {
                if (r.x + r.width > cr.x + cr.width)
                   r.x = cr.x + cr.width - r.width;
             }
         }

         this._viewport.setViewRect(r, {
            instant : true
         });

         event.stop(e);
      }
   });

});
