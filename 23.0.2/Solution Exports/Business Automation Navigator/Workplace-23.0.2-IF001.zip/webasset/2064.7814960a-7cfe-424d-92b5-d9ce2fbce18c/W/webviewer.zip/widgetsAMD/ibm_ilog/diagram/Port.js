/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["./PortBase", "./BasicPort", "./AutomaticPort"],
function(PortBase, BasicPort, AutomaticPort){
	return {
		PortBase: PortBase,
		BasicPort: BasicPort,
		AutomaticPort: AutomaticPort
	};
});
