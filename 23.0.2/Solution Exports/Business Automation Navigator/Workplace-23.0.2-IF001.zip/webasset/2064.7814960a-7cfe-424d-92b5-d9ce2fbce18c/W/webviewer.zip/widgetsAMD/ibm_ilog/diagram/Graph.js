/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["./base",
"dojo/_base/declare", "dojo/_base/lang", "dojo/_base/array", "dojo/_base/config",
"require",
"dojox/gfx/_base", "dojox/gfx/matrix",
"./Node", "./Link", "./Subgraph",
"./util/ErrorReporter", "./util/Batch", "./graphlayout/LayoutRunner", "./util/Geometry"],
function(iid, declare, lang, array, config, require, gfx, matrix, Node, Link, Subgraph, ErrorReporter, Batch, LayoutRunner, Geometry){

/*=====
var gfx = dojox.gfx;
var LayoutRunner = ibm_ilog.diagram.graphlayout.LayoutRunner;
=====*/

	var Graph = declare("ibm_ilog.diagram.Graph", [gfx.Group, LayoutRunner], {
		// summary:
		//		The Graph object acts as a container for Node and Link objects. 
		
		// Allows to test the class faster that testing declaredClass
		_isIBMDiagramGraph: true,
		
		// diagram widget if this graph is embedded in a Diagram widget
		_diagram: null,
		
		constructor: function(){
			var id = iid._IdGenerator.nextId(this).toString();
			this.getId = function(){
				return id;
			};
		},
		
		createNode: function(/*String || Object*/template, context){
			// summary:
			//		Creates a new node in this Graph.
			// template:
			//		The template of the new node. If not specified, the default node template is used.
			//      If null, then an empty node is created.
			// returns:
			//		The new node.
			
			var node = this._createShape(Node, template, Node.defaultTemplate, context);
			return node;
		},
		
		createLink: function(/*String || Object*/template, context){
			// summary:
			//		Creates a new link in this Graph.
			// description:
			//      The description defined in the template parameter must specify which shape 
			//      in the template defines the link path by means of the dojoAttachPoint attribute set to '_path'.
			//      In addition, the optional start and end arrow shapes can be defined in the template
			//      object and in this case must be declared using the corresponding '_startArrow' and '_endArrow'
			//      dojoAttachPoint's. 
			// template:
			//		The template of the new link. If not specified, the default link template is used.
			// returns:
			//		The new link.
			
			var link = this._createShape(Link, template, Link.defaultTemplate, context);
			return link;
		},
		
		createSubgraph: function(/*String || Object*/template, context){
			// summary:
			//		Creates a new subgraph in this Graph.
			// template:
			//		The template of the new subgraph. If not specified or null, the default subgraph template is used.
			// returns:
			//		The new subgraph.
			
			var subgraph = this._createShape(Subgraph, template, Subgraph.defaultTemplate, context);
			return subgraph;
		},
		
		createSwimLane: function(/*String || Object*/template, context){
			// summary:
			//		Creates a new swim lane in this Graph.
			// template:
			//		The template of the new swim lane. If not specified or null, the default swim lane template is used.
			// returns:
			//		The new swim lane.
			
			var swimlane = this._createShape(ibm_ilog.diagram.SwimLane, template, ibm_ilog.diagram.SwimLane.defaultTemplate, context);
			return swimlane;
		},
		
		_createShape: function(type, template, defaultTemplate, context){
			var shape = this.createObject(type);
			this._applyTemplate(shape, template, defaultTemplate, context);
			return shape;
		},
		
		_applyTemplate: function(shape, template, defaultTemplate, gfxContext){
			if (config.isBidiInDojoDiagrammer) 
				this._propogateTextDir(shape);
			if (template === null) // null-> empty shape 
				return;
			if (!template) { // undefined-> default template fallback
				template = defaultTemplate;
			}
			if (!template) {
				ErrorReporter.error("UnexpectedArgument", this, "createSubgraph", "template", template);
			}
			shape.applyTemplate(template, gfxContext);
			shape._template = template; // [AV] temporary, TBD with Patrick
			return shape;
		},
		
		_propogateTextDir: function(shape){
			if (config.isBidiInDojoDiagrammer) {
				var tDir = this.textDir, gr = this;
				while (!tDir) {
					if (!gr.getParent) 
						break;
					gr = gr.getParent();
					tDir = gr.textDir;
				}
				if (tDir && shape.setTextDir) 
					shape.setTextDir(tDir);
			}
		},
		
		onChanged: function(){
			// summary:
			//		This event is called to signal that the contents of the graph have changed.
		},
		
		_onChanged: function(shape, reason){
			// This method is called a lot, keep it short and fast :).
			
			// <inlining this call from BoundingBoxFix at diagext.js>
			// 
			// this.inherited(arguments);
			
			this._bbCacheValid = false;
			
			// <end inline>
			
			// TODO: aggregate changes
			this.onChanged();
			
			if (this._owningSubgraph) 
				this._owningSubgraph._graphChanged();
			
			// Auto-layout:
			// We do an auto-layout only if a node changes (basically when a node is moved),
			// to avoid infinite loops: node move -> auto-layout -> link change -> _onChanged -> etc
			if (shape._isIBMDiagramNode) 
				this._checkAutoLayout();
		},
		
		clear: function(/*boolean*/dispose){
			// summary: 
			//     removes all shapes from a group/surface
			// dispose: boolean :
			//     Indicates whether the graph contents should be disposed. The default
			//     value is true.
			
			if (typeof(dispose) === 'undefined') 
				dispose = true;
			if (dispose) {
				array.forEach(this.children, function(s){
					if (s.dispose && typeof(s.dispose) == "function") 
						s.dispose();
				}, this);
			}
			this.inherited(arguments);
		},
		
		textDir: "", //text direction property
		setTextDir: function(/*String*/textdir){
			// summary: 
			//      set text direction to graph, propagate a new text direction to children (subgraphs, nodes, links)
			// textdir: String, text direction 
			
			if (config.isBidiInDojoDiagrammer) {
				if (this.textDir == textdir) 
					return;
				this.textDir = textdir;
				array.forEach(this.children, function(n){
					if (n.setTextDir) {
						if (n instanceof Subgraph) 
							n.propagateTextDir(textdir);
						n.setTextDir(textdir);
					}
				});
			}
		},
		
		getTextDir: function(){
			// summary: 
			//      returns text direction of the graph	
			return this.textDir;
		},
		
		//------------------
		// Fit to contents
		//------------------
		
		fitToContents: function(margin, zoomOutOnly){
			// summary:
			//		Changes the transform of this Graph so that the whole graph is visible in its parent surface.
			// margin: number:
			//		A margin (in pixels) to leave around the graph contents.
			// zoomOutOnly: boolean:
			//		If true, the graph will only be zoomed out, that is, if its contents are smaller than the surface,
			//			the graph will only be centered and not zoomed in.
			//		If false, the graph will be zoomed in or out to fit the size of the parent surface.
			if (this._diagram) {
				var graphBounds = this.getBoundingBox();
				var viewBounds = this._diagram.getViewport().getViewRect();
				if (zoomOutOnly) {
					if (!margin) 
						margin = 10;
					if (graphBounds.width + 2 * margin <= viewBounds.width && graphBounds.height + 2 * margin <= viewBounds.height) {
						var r = {};
						r.x = graphBounds.x - (viewBounds.width - graphBounds.width) / 2 + margin;
						r.y = graphBounds.y - (viewBounds.height - graphBounds.height) / 2 + margin;
						r.width = viewBounds.width;
						r.height = viewBounds.height;
						this._diagram.getViewport().setViewRect(r);
						return;
					}
				}
				this._diagram.getViewport().setViewRect(Geometry.expandRect(graphBounds, margin), {
					center: true
				});
			}
			else 
				this.setTransform(this.getFitToContentsTransform(margin, zoomOutOnly));
		},
		
		getFitToContentsTransform: function(margin, zoomOutOnly){
			// summary:
			//		Computes the transform to apply to this Graph so that the whole graph is visible in its parent surface.
			// returns: dojox.gfx.matrix.Matrix2D:
			//		The transform to apply to the graph. If the parent of the graph is not a GFX Surface,
			//		the identity matrix is returned.
			// margin: number:
			//		A margin (in pixels) to leave around the graph contents.
			// zoomOutOnly: boolean:
			//		If true, the graph will only be zoomed out, that is, if its contents are smaller than the surface,
			//			the graph will only be centered and not zoomed in.
			//		If false, the graph will be zoomed in or out to fit the size of the parent surface.
			
			var surface;
			for (surface = this.getParent(); surface != null; surface = surface.getParent ? surface.getParent() : null) {
				if (!surface.getParent) 
					break;
			}
			if (!surface) 
				return matrix.identity;
			
			Batch.endBatch(); // update links
			if (!margin) 
				margin = 10;
			
			var surfaceSize = surface.getDimensions();
			
			var graphBounds = this.getBoundingBox();
			var viewBounds = {
				x: margin,
				y: margin,
				width: surfaceSize.width - 2 * margin,
				height: surfaceSize.height - 2 * margin
			};
			
			var t;
			if (!zoomOutOnly || graphBounds.width > viewBounds.width || graphBounds.height > viewBounds.height) 
				t = matrix.createFromRectangles(graphBounds, viewBounds, true);
			else 
				t = matrix.translate((viewBounds.x + viewBounds.width / 2) - (graphBounds.x + graphBounds.width / 2), (viewBounds.y + viewBounds.height / 2) - (graphBounds.y + graphBounds.height / 2));
			
			return t;
		},
		
		
		//------------------
		// Hit testing API
		//------------------
		
		hitTest: function(p, tolerance){
			// Summary:
			//		find the diagram elements bellow the given point
			//		The resulting array is order by the z-order of the elements
			var elements = [];
			if (tolerance == null) {
				tolerance = 2;
			}
			this._hitTest(this, p, elements, tolerance);
			return elements;
		},
		
		_hitTest: function(graph, p, elements, tolerance){
			for (var i = graph.children.length - 1; i >= 0; i--) {
				// we iterate in reverse order to return the last elements first (z-order)
				var c = graph.children[i];
				if (c.hitTest && typeof(c.hitTest) == "function") {
					if (c.hitTest(p, this.getParent(), tolerance)) {
						if (c._isIBMDiagramSubgraph && !c.isCollapsed()) {
							this._hitTest(c.getGraph(), p, elements, tolerance);
						}
						elements.push(c);
					}
				}
			}
		},
		
		//------------------------------------
		// Shortcuts to enable selection/move
		//------------------------------------
		
		setSelect: function(select, callback){
			// summary:
			//		Enables or disables interactive selection on this Graph.
			// select: Boolean
			//		If true, the user will be able to select nodes by clicking on them.
			//		If false, selection will be disabled.
			// callback: Function
			//		(Optional) A function that will be called when the Select interactor is actually loaded.
			//		If not already loaded, the Select interactor may be loaded asynchronously by the AMD loader
			//		so this callback can be used to be notified when the interactor is loaded.
			//		The callback is called only if the select argument is true.
			
			if (select != this._select) {
				this._select = select;
				if (select) {
					if (!this._selInteractor) {
						require(["./interactors/SelectionInteractor"], lang.hitch(this, function(SelectionInteractor){
							this._selInteractor = new SelectionInteractor().initialize(this);
							this._selInteractor.activate();
							if (callback) 
								callback.call(this);
						}));
					}
					else {
						this._selInteractor.activate();
						if (callback) 
							callback.call(this);
					}
				}
				else {
					if (this._selInteractor) {
						this._selInteractor.deactivate();
					}
				}
			}
			return this;
		},
		
		isSelect: function(){
			// summary:
			//		Returns true if selection is enabled, or false if selection is disabled.
			
			return this._select || false; // Boolean
		},
		
		getSelection: function(){
			// summary:
			//		Returns the selection object, if selection is enabled in the graph (isSelect == true).
			if (this.isSelect() && this._selInteractor) {
				return this._selInteractor.getSelection();
			}
			return null;
		},
		
		setMove: function(move, callback){
			// summary:
			//		Enables or disables interactive move on this Graph.
			// description:
			//		Enables or disables interactive move on this Graph.
			//		Note that enabling move also enables select automatically.
			// move: Boolean
			//		If true, the user will be able to move nodes by dragging them.
			//		If false, move will be disabled.
			// callback: Function
			//		(Optional) A function that will be called when the Move interactor is actually loaded.
			//		If not already loaded, the Move interactor may be loaded asynchronously by the AMD loader
			//		so this callback can be used to be notified when the interactor is loaded.
			//		The callback is called only if the move argument is true.

			if (move != this._move) {
				this._move = move;
				if (move) {
					this.setSelect(true, lang.hitch(this, function(){
						if (!this._moveInteractor) {
							require(["./interactors/MoveInteractor"], lang.hitch(this, function(MoveInteractor){
								this._moveInteractor = new MoveInteractor().initialize(this._selInteractor.getSelection(), this);
								this._moveInteractor.activate();
								if (callback) 
									callback.call(this);
							}));
						}
						else {
							this._moveInteractor.activate();
							if (callback) 
								callback.call(this);
						}
					}));
				}
				else {
					if (this._moveInteractor) {
						this._moveInteractor.deactivate();
					}
				}
			}
			return this;
		},
		
		isMove: function(){
			// summary:
			//		Returns true if move is enabled, or false if move is disabled.
			
			return this._move || false;
		},
		
		//----------------------------------------
		// Shortcuts to get nodes/links/subgraphs
		//----------------------------------------
		
		getNodes: function(){
			// summary:
			//		Returns the nodes (that is, instances of ibm_ilog.diagram.Node) contained in this Graph.
			
			return array.filter(this.children, function(item){
				return item._isIBMDiagramNode;
			}); // Array
		},
		
		getLinks: function(){
			// summary:
			//		Returns the links (that is, instances of ibm_ilog.diagram.Link) contained in this Graph.
			
			return array.filter(this.children, function(item){
				return item._isIBMDiagramLink;
			}); // Array
		},
		
		getSubgraphs: function(){
			// summary:
			//		Returns the subgraphs (that is, instances of ibm_ilog.diagram.Subgraph) contained in this Graph.
			
			return array.filter(this.children, function(item){
				return item._isIBMDiagramSubgraph;
			}); // Array
		},
		
		//--------------
		// Check moves:
		//--------------
		
		onElementMoving: function(element, transform, delta){
			// summary:
			//		Called when an element is about to be moved by an interactor.
			// description:
			//		This event lets a Graph forbid or limit node moves.
			//		The event handler can modify the delta argument:
			//		if delta.x or delta.y are modified, the move is limited to the new delta
			//		(and other objects moved together with the specified element will also be limited accordingly).
			//		The default implementation checks the limits set by setMoveLimits(rect) (null by default -> no limit).
			// element: ibm_ilog.diagram.GraphElement
			//		The element being moved
			// transform: dojox.gfx.matrix.Matrix2D
			//		The original transform of the element.
			// delta: Point
			//		An object with x and y properties specifying the move delta.
			//		This argument can be modified by event handlers to forbid of limit the move.
			
			var limits = this.getMoveLimits();
			if (limits) {
				// delta is in untransformed element coords, so convert the limits accordingly...
				if (transform) 
					limits = transform.inverse().transformRectangle(limits);
				var bb = element.getBoundingBox();
				if (bb.x + delta.x + bb.width > limits.x + limits.width) 
					delta.x = limits.x + limits.width - bb.x - bb.width;
				if (bb.y + delta.y + bb.height > limits.y + limits.height) 
					delta.y = limits.y + limits.height - bb.y - bb.height;
				if (bb.x + delta.x < limits.x) 
					delta.x = limits.x - bb.x;
				if (bb.y + delta.y < limits.y) 
					delta.y = limits.y - bb.y;
			}
		},
		
		_moveLimits: null,
		
		setMoveLimits: function(rect){
			// summary:
			//		Sets the move limits for this Graph.
			// description:
			//		This method lets you limit interactive node moves to a given rectangle in the Graph.
			// rect: Rectangle
			//		A rectangle (x/y/width/height) that specifies the region where nodes
			//		are allowed to be moved. If null, node moves are not limited.
			
			this._moveLimits = rect;
		},
		
		getMoveLimits: function(){
			// summary:
			//		Gets the move limits for this Graph.
			// description:
			//		See setMoveLimits().
			// returns: Rectangle
			//		A rectangle (x/y/width/height) that specifies the region where nodes
			//		are allowed to be moved. If null, node moves are not limited.
			//		The default is null (no limit).
			
			return this._moveLimits;
		},
		
		getOwningSubgraph: function(){
			// summary:
			//		Returns the Subgraph object that is displaying this Graph.
			// description:
			//		Returns the <code>Subgraph</code> object that is displaying this <code>Graph</code>.
			//		If this <code>Graph</code is not contained in a <code>Subgraph</code>,
			//		returns <code>null</code> or <code>undefined</code>.
			// returns:
			//		The Subgraph object that is displaying this Graph.
			return this._owningSubgraph; // ibm_ilog.diagram.Subgraph
		},
		
		//--------------
		// toString()...
		//--------------
		
		toString: function(){
			return "Graph[" + this.children.length + "]" + (this._owningSubgraph ? (" at " + this._owningSubgraph.toString()) : "");
		}
	});
	
	Graph.nodeType = gfx.Group.nodeType;
	Graph.defaultShape = {
		type: 'graph'
	};
	
	// Extend the GFX Surface and Group objects with a createGraph function:
	
	var graphCreator = {
		createGraph: function(){
			var graph = this.createObject(Graph);
			return graph;
		}
	};
	lang.extend(gfx.Surface, graphCreator);
	lang.extend(gfx.Group, graphCreator);
	
	return Graph;
});
