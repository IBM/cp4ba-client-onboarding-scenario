define({      
//begin v1.x content
    errorDialogTitle: "IBM BPM 오류",
    moreDetails: "세부사항...",
    closeMessage: "모든 오류 메시지 닫기",
    contentMessage: "오류가 발생했습니다."
//end v1.x content
});

