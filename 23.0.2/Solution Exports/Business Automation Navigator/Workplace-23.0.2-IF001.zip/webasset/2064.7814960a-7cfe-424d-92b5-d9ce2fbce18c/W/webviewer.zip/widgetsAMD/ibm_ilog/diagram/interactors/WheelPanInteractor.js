/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/event",
"dojox/gfx/matrix",
"dojox/gfx/fx",
"./Interactor",
"../util/Geometry"
],
function(
declare,
lang,
event,
matrix,
gfxfx,
Interactor,
g
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var WheelPanInteractor =
declare("ibm_ilog.diagram.interactors.WheelPanInteractor", [Interactor], {
	//
	//	summary:
	//		A WheelPanInteractor controls the process of panning the viewport by the mouse wheel
	//

	
	//
	//	_viewport: ibm_ilog.diagram.widget.Viewport
	//		The diagram viewport 
	//
	_viewport: null,

	//
	//	_diagram: ibm_ilog.diagram.widget.Diagram
	//		The diagram to pan
	//
	_diagram: null,
	
	//
	//	_incrementFactor: Number
	//		The amount at which pan is moved at each discrete step
	//
	_incrementFactor: 40,
	
	_declareStates: function() {
		this._declareState("idle",["wheelPan"]);
	},
	
	activate: function() {
		this._goStateId("idle");
	},
	
	setIncrementFactor: function( /*Number*/ factor ) {
		//
		//	summary:
		//		Sets the amount at which pan is moved at each discrete operation
		//
		this._incrementFactor = factor;
	},
	
	getIncrementFactor: function() {
		//
		//	summary:
		//		Returns the amount at which pan is moved at each discrete operation
		//
		return this._incrementFactor;
	},
	
    initialize: function( /*ibm_ilog.diagram.widget.Diagram*/ diagram ) {
		//
		//	summary:
		//		Wheel Pan interactor constructor, based on a target Diagram widget.
		//
		this._diagram = diagram;
		this._viewport = diagram.getViewport();
		this._initialize();
		return this;
	},
    
    getDefaultConnections:function(){
		//
		//	summary:
		//		Returns the default event mapping
		//
    	return {
    		wheelPan:{src:this._diagram.domNode,srcEvt:this.eventNameWheel,connectTo:"_wheelPan",filter:this._buildInputFilter({ctrl:false,shift:false})}
    	};
    },
    
    _wheelPan: function( /*Event*/ e ) {
		//
		//	summary:
		//		Handles the wheel mouse event and dispatches the appropriate pan operations
		//
    	
    	var V = this._viewport;
		var delta = this._incrementFactor;
		
		if(this.eventWheelAmmount(e)<0) {
			delta = -delta;
		}

		var viewMovement = g.mulPoint(g.Point(0,delta),-1/V.getZoom()); // scale delta to zoom level to get delta in model coords
		
		V.setViewRect( g.moveRect(V.getViewRect(),viewMovement), {instant:true} );

		if (e.preventDefault) {
			e.preventDefault();
		}
		//	TODO: do we need this?
		e.returnValue = false;

    }
});

return WheelPanInteractor;

});
