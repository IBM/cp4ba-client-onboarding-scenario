define({      
//begin v1.x content
    errorDialogTitle: "IBM BPM hiba",
    moreDetails: "További részletek...",
    closeMessage: "Összes hibaüzenetet bezárása",
    contentMessage: "Hiba történt."
//end v1.x content
});

