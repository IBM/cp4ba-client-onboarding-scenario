/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"dojo/_base/connect",
"dojox/gfx/matrix",
"dojox/collections/Dictionary",
"../util/GraphUtil",
"../util/Geometry",
"./undo/MultipleAction",
"./undo/UndoActionList",
"./DiagramSerializer",
"./EditingUtils"
], function(
declare,
lang,
array,
connect,
m,
Dictionary,
gu,
g,
MultipleAction,
UndoActionList,
DiagramSerializer,
eu
){

var Clipboard =
declare("ibm_ilog.diagram.editor.Clipboard", null , {
	
	_diagram: null,
	_serializer: null, 
	_pasteContainer : null,
	_clipboard: null, 
	_pasteXY: null, 
	_pasteBB: null, 

	_nextPasteLocations: null,
	
	//
	//	_nextPasteLocationDelta: Point
	//		The delta used to compute _nextPasteLocation.
	//
	_nextPasteLocationDelta: g.Point(25,25),

	setNextPasteLocationDelta: function(value) {
		//
		//	summary:
		//		Set the delta used to compute _nextPasteLocation.
		//
		this._nextPasteLocationDelta = value;
	},	
	
	getNextPasteLocationDelta: function(value) {
		//
		//	summary:
		//		Get the delta used to compute _nextPasteLocation.
		//
		return this._nextPasteLocationDelta;
	},

	constructor: function(diagram){
		// summary:
		//		creates a new clipboard instance, initializing a new serializer.
		
		this._nextPasteLocations = new Dictionary();
		
		this._diagram = diagram;
		this._initializeSerializer();
	},
	
	getDiagram: function(){
		// summary:
		//		returns the associated diagram.
		// return: ibm_ilog.diagram.editor.DiagramEditor
		return this._diagram;
	},
	
	_basicCopy: function() {
		// summary:
	    //		This method serializes the selected elements to the clipboard, and save it for further paste.
		var maximals = gu.maximals(this._diagram.getSelection().fastGet().toArray())
		if(!this._isEmpty(maximals)){
			var bb = this._getBoundsOf(maximals);
			var lca = gu.lowestCommonAncestor(maximals);
			
			this._nextPasteLocations.clear();
			
			var bbxy = {x:bb.x,y:bb.y};
			var localxy = lca._getRealMatrix().inverse().transformPoint(bbxy);
			this._nextPasteLocations.add(lca.getId(),localxy);

			this._clipboard = this._serializer.serialize(maximals);
			connect.publish("/ibm_diagram/Clipboard/copied", [maximals]);
			return maximals;
		}
		return null;
	},
	
	copy: function() {
		// summary:
    //		This method serializes the selected elements to the clipboard, and save it for further paste.
		if(this._basicCopy()) {
			var entry = this._nextPasteLocations.getIterator().get();
			entry.value = g.addPoint(entry.value,this._nextPasteLocationDelta);
			
		}		
	},
	
	cut: function(){
		// summary:
	    //		This method serializes the selected elements to the clipboard, and save it for further paste.
		//		Also deletes the selected elements after the copy.
		if(this._basicCopy()) {
			var selected = this._diagram.getSelection().fastGet().toArray();
			var action = eu.deleteGraphElements(this._diagram,selected);
			this._diagram.getUndoManager().addAction(action);
		}
	},
	
	clear: function(){
		// summary:
	  //		This method clears the clipboard and signals the event "/ibm_diagram/Clipboard/cleared".
		//
		this._clipboard = null; 
		connect.publish("/ibm_diagram/Clipboard/cleared",[]);
	},
	
	paste: function(pasteContainer,pasteLocation) {
		//
		//	summary:
	  //		Pastes previously copied content into the diagram.
		//	pasteContainer: ibm_ilog.diagram.Graph
		//		The Graph into which the contents of the clipboard are going to be pasted.
		//
		if(this._clipboard){
			this._pasteContainer = pasteContainer;
			if(!pasteLocation) {
				var storedLoc = this._nextPasteLocations.item(pasteContainer.getId());
				if(storedLoc) {
					pasteLocation = storedLoc;
				} else {
					pasteLocation = storedLoc = {x:0,y:0};
				}
				storedLoc = g.addPoint(storedLoc,this._nextPasteLocationDelta);
				this._nextPasteLocations.add(pasteContainer.getId(),storedLoc);
			}

			this._pasteXY = pasteLocation;
			this._pasteBB = this._calculateBB(this._clipboard); 
			var undoGroup = new MultipleAction(UndoActionList.Paste);
		
			// add a connection to select all deserialized elements.
			var elements = [];
			var connection = connect.connect(this,'onDeserialize',
										  this,function(serialized,newElement){
			                						elements.push(newElement);
												});
		
			this._serializer.deserialize(this._clipboard,{graph:this._pasteContainer,undo:undoGroup});
			this._diagram.getUndoManager().addAction(undoGroup);
		
			//disconnect
			connect.disconnect(connection);
		
			//selects the deserialized top elements
			var maximals = gu.maximals(elements);
			this._diagram.getSelection().add(maximals,true);
			connect.publish("/ibm_diagram/Clipboard/pasted", [maximals]);
			//this._advancePasteLocation();
		}
	},
	
	getSerializer: function(){
		// summary:
		//		returns the pre-configured serializer, ready for the copy-paste action.
		// return: ibm_ilog.diagram.editor.DiagramSerializers
		return this._serializer;
	},
	
	_calculateBB: function(serialized) {
		var bb = null;
		array.forEach(serialized,function(e) {
			if(e.data.uibb) {
				if(bb) {
					bb = g.addRect(bb,e.data.uibb);
				} else {
					bb = e.data.uibb;
				}
			}
		});
		return bb;
	},
	
	_initializeSerializer: function(){
		var t = lang.hitch(this,this._adjustTransform);
		this._serializer = new DiagramSerializer(this._diagram,t,this);
	},
	
	_adjustTransform: function(t,c,s) {
		// if this is toplevel, reassign t offsets such that pasteXY is the new translation
		if(c==this._pasteContainer) {
			if(!s){
				// compute transform for link intermediate points
				return m.multiply(m.translate(g.subPoint(this._pasteXY, this._pasteBB)), t);
			}
			t.dx=0;	t.dy=0;
			var newp = this._pasteXY;
			newp = g.addPoint(g.subPoint(s.uibb,this._pasteBB),newp);
			return m.multiply(m.translate(newp),t);
		} else return t;
	},
	
	_isEmpty:function(array) {
		// summary:
		//		verifies if an array is empty
		for(var i in array) {
			return false; 
		}
		return true; 
	},
	
	onSerialize: function(graphElement,serializedData){
		// summary:
		//		this function is called when a graphElement is serialized in the local Serializer.
		//		The user can connect to this method to customize the serialization.
		// graphElement: ibm_ilog.diagram.GraphElement
		//		the GraphElement to be serialized
		// serializedData: JSObject
		//		the serialized version of the GraphElement
	},
	
	onDeserialize: function(serializedData,newGraphElement,container,undoAction){
		// summary:
		//		this function is called when a graphElement is deserialized in the local Serializer.
		//		The user can connect to this method to customize the deserialization.
		// serializedData: JSObject
		//		the serialized version of the GraphElement
		// newGraphElement: ibm_ilog.diagram.GraphElement
		//		the deserialized GraphElement
		// container: ibm_ilog.diagram.Graph
		//		the container object where the newGraphElement is hold
		// undoAction: ibm_ilog.diagram.editor.undo.UserCustomizedAction
		//		the undo Action to be added to the UndoManager. If the serialized object is a link, 
		//		this Action will be an instance of ibm_ilog.diagram.editor.undo.ConnectAction.
		//		In other case it will be a ibm_ilog.diagram.editor.undo.PasteNodeAction
	},
	
	_getBoundsOf: function (list) {
		//
		//	summary:
		//		return the bounds of a list of elements currently selected
		//	list: Array
		//		The list of graph elements to include
		//	tags:
		//		private
		var bb = null;
		var graph = this._diagram.getGraph();
		for(var i = 0; i<list.length; i++) {
			var b = list[i].getBounds(graph);
			if(!bb) {
				bb = b;
			} else {
				bb = g.addRect(bb,b);
			}
		}
		return bb;
	}
	
});

return Clipboard;

});
