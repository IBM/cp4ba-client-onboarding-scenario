/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare", "dojo/_base/lang", "dojo/_base/array", "dojo/_base/connect",
"dojox/collections/ArrayList",
"./Selectable",
"./util/GraphUtil", "./util/ErrorReporter"],
function(declare, lang, array, connect, ArrayList, Selectable, gu, R){

var Selection = 
declare("ibm_ilog.diagram.Selection", [], {
	
	_diagram: null,
	_selectionStrategy: null,
	_multiSelectionEnabled: null,
	_nodeSelectionEnabled: null,
	_linkSelectionEnabled: null,
	
	constructor: function(diagram,options) {
		// summary:
		//		creates a new instance
		this._multiSelectionEnabled = true;
		this._nodeSelectionEnabled = true;
		this._linkSelectionEnabled = true;
		this._diagram = diagram;	
		options = options || diagram || {selectionMode:Selection.standard};
		this.instantiateSelectionStrategy(diagram,options);
	},
	
	instantiateSelectionStrategy: function(diagram,options){
		var useIndividualConnect = !diagram!=null;
		
		switch( options.selectionMode){
			case Selection.standard:{
				if(diagram && diagram.useDataStore()){
					this._selectionStrategy = new StoreSelectionStrategy(this,useIndividualConnect);
				}else{
					this._selectionStrategy = new GFXSelectionStrategy(this,useIndividualConnect);
				}
				this.setMultiSelectionEnabled(true);
				break;}
			case Selection.gfx_single: {
				this._selectionStrategy = new GFXSelectionStrategy(this,useIndividualConnect);
				this.setMultiSelectionEnabled(false);
				break;}
			case Selection.gfx_multi: {
				this._selectionStrategy = new GFXSelectionStrategy(this,useIndividualConnect);
				this.setMultiSelectionEnabled(true);
				break;}
			case Selection.dataStore_single: {
				this._selectionStrategy = new StoreSelectionStrategy(this,useIndividualConnect);
				this.setMultiSelectionEnabled(false);
				break;}
			case Selection.dataStore_multi: {
				this._selectionStrategy = new StoreSelectionStrategy(this,useIndividualConnect);
				this.setMultiSelectionEnabled(true);
				break;}		
		}
		if(!useIndividualConnect){
			connect.connect(diagram,'beforeGraphElementDispose',this,'onElementDisposed');
		}
		
	},
	add: function(elements,forceClear){
		// summary:
		// 		sets the desired as selected, and add it to the selected list (if not in
		// 		the list yet). Also connect the element to react to the selectableChanged method
		// elements: a single element or an array of elements
		var removed = [];
		if((!this._multiSelectionEnabled && this.get().count>0) || forceClear == true){
			removed = this._clear();
		}
		if(!(elements instanceof Array)){
			elements = [elements];
		}
		var added = [];
		for( itemIndex in elements ){ 
		 		var item = elements[itemIndex];
				var rta = this._selectionStrategy.add(item);
				if(rta){
					added.push(rta);
				}		
		 }
		
		if(added.length>0 || removed.length>0){
			this.onSelectionChanged(added,removed);
			return true;
		}else{
			return false;
		}
	},
	remove: function(elements,isDisposed){
		// summary:
		// 		sets the desired as unselected, and remove it from the selected list (if in
		// 		the list).
		// elements: a single element or an array of elements
		if(!(elements instanceof Array)){
			elements = [elements];
		}
		var removed = [];
		for( itemIndex in elements ){ 
		 		var item = elements[itemIndex];
				var rta = this._selectionStrategy.remove(item,isDisposed);
				if(rta){
					removed.push(item);
				}		
		 }
		
		if(removed.length>0){
			!isDisposed && this.onSelectionChanged([],removed);
			return true;
		}else{
			return false;
		}
	},
	_clear: function(){
		// summary:
		// sets the selection state of all the elements in the selected list as
		// false, and clear the list. Return an array with the removed elements
		var removed = this._selectionStrategy.get().toArray();
		this._selectionStrategy.clear();
		return removed;
	},
	clear: function() {
		// summary:
		// sets the selection state of all the elements in the selected list as
		// false, and clear the list. If any element is removed from the selection, a notification is thrown.
		var removed = this._clear();
		if(removed.length>0){
			this.onSelectionChanged([],removed);
		}
	},
	get: function(){
		// summary:
		// gets the ArrayList of selected elements
		return this._selectionStrategy.get().clone();
	},
	fastGet: function(){
		// summary:
		// gets the ArrayList of selected elements
		return this._selectionStrategy.get();
	},
	onSelectionChanged: function(added,removed){
		
	},
	getMultiSelectionEnabled: function(){
		// summary:
		// gets if multi-Selection is enabled (true by default)
		return this._multiSelectionEnabled;
	},
	setMultiSelectionEnabled: function(enabled){
		// summary:
		// sets if multi-Selection is enabled (true by default)
		this._multiSelectionEnabled = enabled;
	},
	getNodeSelectionEnabled: function(){
		// summary:
		// gets if Node Selection is enabled (true by default)
		// this enablement only affects the accept(graphelement) return value.
		return this._nodeSelectionEnabled;
	},
	setNodeSelectionEnabled: function(enabled){
		// summary:
		// sets if node Selection is enabled (true by default)
		// this enablement only affects the accept(graphelement) return value.
		this._nodeSelectionEnabled = enabled;
	},
	getLinkSelectionEnabled: function(){
		// summary:
		// gets if link Selection is enabled (true by default)
		// this enablement only affects the accept(graphelement) return value.
		return this._linkSelectionEnabled;
	},
	setLinkSelectionEnabled: function(enabled){
		// summary:
		// sets if link Selection is enabled (true by default)
		// this enablement only affects the accept(graphelement) return value.
		this._linkSelectionEnabled = enabled;
	},
	_getDataItem: function(element){
		if(Selectable.Util.isSelectableInstance(element)){
			return this._diagram.getBoundItem(element);
		}else{
			return element;
		}
	},
	_asGraphElement: function(element){
		if(!Selectable.Util.isSelectableInstance(element)){
			return this._diagram.getGraphElementFromDataItem(element);
		}else{
			return element;
		}
	},
	accept: function(element){
		// Summary:
		//		This method return true if the element can be added to the selection 
		//		eg1: an element with no data item cannot be added to a StoreSelectionStrategy
		//		eg: a link is trying to be added to the selection but link selection is disabled
		var ge = this._asGraphElement(element);
		return ((ge._isIBMDiagramNode && this._nodeSelectionEnabled) || (ge._isIBMDiagramLink && this._linkSelectionEnabled)) && this._selectionStrategy.accept(element);
	},
	onElementDisposed: function(graphElement) {
		this.remove(graphElement,true);
	},
	selectAll: function(graph,options) {
		//
		//	summary: 
		//		select all elements in a graph 
		//	graph:
		//		the graph containing all the items to be selected
		//	options:
		//		options.noCheck: if true, skip checking each item is accepted by the receiver
		//
		graph = graph || this._diagram.getGraph();
		
		var selectables = gu.allGraphElements(graph.children).toArray()
	
		if(!options || !options.noCheck) {
			selectables = array.filter(selectables,lang.hitch(this,"accept"));
		}
		this.add(selectables,true);
	},	
	__eod: undefined
});

var AbstractSelectionStrategy =
declare("ibm_ilog.diagram.AbstractSelectionStrategy", [], {
	_selectedHandle: null,
	_selectedElements: null,
	_selection: null,
	_individualConnect: null,
	
	constructor: function(selection,useIndividualConnect) {
		this._selection = selection;
		this._individualConnect = useIndividualConnect;
		this._selectedElements = new ArrayList();
		if(this._individualConnect){
			this._selectedHandle = new ArrayList();
		}
	},
	add: function(element){
	
	},
	remove: function(element,isDisposed){
		
	},
	disposeRemove: function(element){
		
	},
	get: function(){
		return this._selectedElements;
	},
	clear: function(){
		while(this._selectedElements.count>0){
			var element = this._selectedElements.item(this._selectedElements.count-1);
			this.remove(element);
		}
	},
	_addElement: function(element){
		this._selectedElements.add(element);
		var ge = this._selection._asGraphElement(element);
		if (this._individualConnect) {
			this._selectedHandle.add(connect.connect(ge, 'beforeDisposing', this._selection, 'onElementDisposed'));
		}
	},
	_removeElement: function(element){
		// summary:
		//		remove the elements from the list, disconnect it and remove the handle.
			var index =  this._selectedElements.indexOf(element);
			this._selectedElements.removeAt(index);
			if (this._individualConnect) {
				connect.disconnect(this._selectedHandle.item(index));
				this._selectedHandle.removeAt(index);
			}
	}
});

/*=====
var AbstractSelectionStrategy = ibm_ilog.diagram.AbstractSelectionStrategy;
=====*/

var GFXSelectionStrategy =
declare("ibm_ilog.diagram.GFXSelectionStrategy", [AbstractSelectionStrategy], {
	add: function(element){
		var ge = this._selection._asGraphElement(element);
		if(!this._selectedElements.contains(ge)){
			if(ge.setSelected(true)){
				this._addElement(ge);
				return ge;
			}
		}
		return null;
	},
	remove: function(element,isDisposed){
		var ge = this._selection._asGraphElement(element);
		if (this._selectedElements.contains(ge)) {
			if(!isDisposed){
				ge.setSelected(false);
			}
			this._removeElement(element);
			return ge;
		}
		return null;
	},
	accept: function(element){
		// Summary:
		//		This method return true if the element can be added to the selection 
		//		(eg: an element with no data item cannot be added to a StoreSelectionStrategy)
		
		return true;
	}
});

var StoreSelectionStrategy =
declare("ibm_ilog.diagram.StoreSelectionStrategy", [AbstractSelectionStrategy], {
	add: function(element){
		var ge = this._selection._asGraphElement(element);
		var dataItem = this._selection._getDataItem(element);
		if(dataItem == null){
			R.error("NotInDataStore");
		}
		if(!this._selectedElements.contains(dataItem)){
			if(ge == null || ge.setSelected(true)){
				this._addElement(dataItem);
				var dataItem = this._selection._getDataItem(element);
				return dataItem;	
			}
		}
		return null;
	},
	remove: function(element,isDisposed){
		var ge = this._selection._asGraphElement(element);
		var dataItem = this._selection._getDataItem(element);
		if(dataItem == null){
			R.error("NotInDataStore");
		}
		if (this._selectedElements.contains(dataItem)) {
			if (ge != null && !isDisposed) {
				ge.setSelected(false);
			}
			this._removeElement(dataItem);
			return dataItem;
		}
		return null;
	},
	accept: function(element){
		// Summary:
		//		This method return true if the element can be added to the selection 
		//		(eg: an element with no data item cannot be added to a StoreSelectionStrategy)
		
		var dataItem = this._selection._getDataItem(element);
		if(dataItem == null){
			return false;
		}
		return true;
	}
});

Selection.standard = 0;
Selection.dataStore_single = 1;
Selection.dataStore_multi = 2;
Selection.gfx_single = 3;
Selection.gfx_multi = 4;

return Selection;

});
