/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/kernel", "dojox", "dojo/_base/declare", "dojo/_base/lang", "dojox/gfx", "dojox/gfx/matrix", "dojox/gfx/utils", "./MultilineText", "./ErrorReporter"],
function(dojo, dojox, declare, lang, gfx, matrix, gfxu, MultilineText, R){

	/*=====
	ibm_ilog.diagram.util.__PrintUtilArgs = function(){
		//	getTargetSurfaceDiv: Function?
		//		This is used to get the HTML div tag where the target surfaces are going to be drawn
		//	postProcessing: Function?
	 	//		This function is called after every target surface is created, to customize any part necessary
		
		// [av] TODO the following doc style is copied from dojo.xhr but is not currently working.
		getTargetSurfaceDiv = function(row,column) {
			// [Mandatory]
			// row: the row number
			// column: the column number
			// return: the div tag where the surface will be drawn
		},
		postProcessing= function(row,column) {
			// [optional]
			// row: the row number
			// column: the column number
			// surface: the the drawn surface
			// group: the complete gfx.group drawn (typically the complete graph)
		},
	};
=====*/
	
var PrintUtil = declare("ibm_ilog.diagram.util.PrintUtil",null,{
	constructor: function( /*ibm_ilog.diagram.util.__PrintUtilArgs*/ kwArgs ) {
		this._kwArgs = kwArgs;
	},
	printGraph: function(graph,bounding,width,height,pagesWidth,pagesHeight,paperColor){
		// Summary:
		// 		Separates the given graph boundingBox into pagesWidth horizontal surfaces and pagesHeight vertical surfaces.
		//
		// graph:
		// 		the graph to be separated into multiple surfaces
		// bounding:
		// 		[Rect] indicates the area to be show. If missing, the complete graph is shown
		// width:
		// 		the width in pixels of every single surface
		// height:
		// 		the height in pixels of every single surface
		// pagesWidth:
		// 		the amount of horizontal surfaces into be split
		// pagesHeight:
		// 		the amount of vertical surfaces into be split
		// paperColor:
		//		[Color] this paperColor is used to hide not required part of the graph, when the target area has different aspect 
		//		ratio than the source bounding. If missing, white is used as default color.
		
		if (!gfxu.toSvg) {
			R.error("UnsupportedDojoFeature", "1.4.0");
		}
		
		// patch so that gfx (de)serialization does not crash on MultilineText deserialization :
		// The gfx serialize() method does not save the 'shape' property of a Group instance, but
		// will save the others 'default' gfx properties (fill, stroke, font...), so MultilineText instances
		// are serialized as Group instance :
		// { children : [....], transform:..., font: ... }.  (so, no shape:{type:'ml'}).
		// Therefore, when the json is deserialized, a Group instance is created, and setFont() is invoked
		// (which fails because Group.setFont does not exist).
		// Patch (Hack!!!!): we delete the getFont/setFont accessors so that the font is not serialized 
		var getFont = MultilineText.prototype.getFont;
		delete MultilineText.prototype.getFont;
		
		bounding = bounding || graph.getBoundingBox();
		paperColor = paperColor || 'white';
		// Calculate the zoom and necessary to fit and center
		var tMatrix = this._calculateTransformToFit(bounding, width, height, pagesHeight, pagesWidth);
		//Fix to avoid null bounding [defect 725]
		bounding = bounding || {x:0,y:0,width:0,height:0};
		var userFunc = this._kwArgs;
		for (var r = 0; r < pagesHeight; r++) {
			for (var c = 0; c < pagesWidth; c++) {
				var div = userFunc.getTargetSurfaceDiv(r,c);
				
				//Option 1: with this lines the code fails on div.appendChild(tempDiv);
				/*
				var tempDiv = dojo.create("div");
				div.appendChild(tempDiv);
				var surf = dojox.gfx.createSurface(tempDiv,width,height);
				*/
				
				
				//Option 2: This Line fails on vml.js line 1036: r.appendChild(b); (V:GROUP append V:RECT)
				var surf = gfx.createSurface(div,width,height);
				
				//Create temp surface to render object to and render.
				//Option 3: This Line fails on vml.js line 1036: r.appendChild(b); (V:GROUP append V:RECT)
				/*
				var divWindow = this._getWindow(div.ownerDocument);
				this._setDojoScope(divWindow);
				var surf = divWindow[dojox._scopeName].gfx.createSurface(div, width, height);
				*/
				
				surf.whenLoaded(lang.hitch(this, function(){
					var obj = gfxu.serialize(graph);
					var group = surf.createGroup();
					group.applyLeftTransform(tMatrix);
					group.applyLeftTransform(matrix.translate(width * c * -1, height * r * -1));
					gfxu.deserialize(group, obj);
					if(userFunc.postProcessing){
						userFunc.postProcessing(r,c,surf,group);
					}
					this._cropToFit(group,bounding,r,c,pagesHeight,pagesWidth,width,height,tMatrix.xx,paperColor);
				}));
			}
		}
		
		// restore font accessors
		MultilineText.prototype.getFont = getFont;
	},
	/* this code seems unused...
	_getWindow:function(anyDocument){
		var divWindow = anyDocument.defaultView ||  anyDocument.parentWindow;
		return divWindow;
	},
	_setDojoScope: function(window){
		
		window[dojox._scopeName] = this._getWindow(document)[dojox._scopeName];
		window[dojo._scopeName] = this._getWindow(document)[dojo._scopeName];
	},
	*/
	printViewport: function(diagram,width,height,pagesWidth,pagesHeight,paperColor){
		// Summary:
		// 		Separates the given diagram viewport into pagesWidth horizontal surfaces and pagesHeight vertical surfaces.
		// diagram:
		// 		the diagram which viewport will be separated into multiple surfaces
		// width:
		// 		the width in pixels of every single surface
		// height:
		// 		the height in pixels of every single surface
		// pagesWidth:
		// 		the amount of horizontal surfaces into be split
		// pagesHeight:
		// 		the amount of vertical surfaces into be split
		// paperColor:
		//		[Color] this paperColor is used to hide not required part of the graph, when the target area has different aspect 
		//		ratio than the source bounding. If missing, white is used as default color.
		var graph = diagram.getGraph();
		var bounding = diagram.getViewport().getViewRect();
		this.printGraph(graph,bounding,width,height,pagesWidth,pagesHeight,paperColor);
	},
	
	_calculateTransformToFit: function(printBB,dimx, dimy, h, w){
		// Summary:
		// 		Calculates and returns the Transformation necessary to fit the pintBB area in the printable area,
		//		compound by the merge of (dimx * w) X (dimy * h)
		
		//Fix to avoid null transformation [defect 725]
		if(!printBB){
			return matrix.identity;
		}
		
		if (printBB.width && printBB.height) {
			var sz = {
				width: dimx * w,
				height: dimy * h
			};
			var xr = sz.width / printBB.width;
			var yr = sz.height / printBB.height;
			var cent = {
				x: 0,
				y: 0
			};
			
			var zoom;
			if (xr < yr) {
				zoom = xr;
				cent.y = (printBB.width * (sz.height / sz.width) - printBB.height) / 2;
			}
			else {
				zoom = yr;
				cent.x = (printBB.height * (sz.width / sz.height) - printBB.width) / 2;
			}
			
			var zt = matrix.scale(zoom);
			var tt = matrix.translate({
				x: - printBB.x + cent.x,
				y: - printBB.y + cent.y
			});
			
			var t = matrix.multiply(zt, tt);
			
			return t;
		}
	},
	_cropToFit: function(group,bounding,r,c,pagesHeight,pagesWidth,width,height,zoom,paperColor){
		// Summary:
		// 		Creates rectangles over the surrounding surfaces, to limit the printed area to the given bounding 
		//		(hiding the parts that are out of the bounding when the target aspect ratio do not match the original aspect ratio)
		var rectx = Math.max((bounding.width),(width * pagesWidth/zoom));
		var recty = Math.max((bounding.height),(height * pagesHeight/zoom));
		
		if(r==0){
			group.createRect({ x: bounding.x, y: bounding.y-recty, width: rectx, height: recty }).setFill(paperColor);
		}
		if(c==0){
			group.createRect({ x: bounding.x-rectx, y: bounding.y, width: rectx, height: recty }).setFill(paperColor);
		}
		if(r==(pagesHeight-1)){
			group.createRect({ x: bounding.x, y: bounding.y+bounding.height, width: rectx, height: recty }).setFill(paperColor);
		}
		if(c==(pagesWidth-1)){
			group.createRect({ x: bounding.x+bounding.width, y: bounding.y, width: rectx, height: recty }).setFill(paperColor);
		}
	}
});

return PrintUtil;

});