/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["../main", "dojo/_base/lang", "dojo/_base/array", "dojo/_base/sniff", "./BidiEngine"],
function(iid, lang, _array, has, bidiEngine){

	// TODO: Change to this when AMD conversion is complete:
	// var gu = {};
	var gu = lang.getObject("ibm_ilog.diagram.util.BidiUtil", true);
 
    var findDirAndRTLChar = function(text){
    	var len = text.length;
    	var c, ret = {dir: "ltr", findChar: false};
    	var isDirFound = false;
    	for (var i = 0; i<len; i++){
			c = text.charCodeAt(i);
			if((c >= 0x05d0 && c <= 0x065f ||
				c >= 0x066a && c <= 0x06ef ||
				c >= 0x06fa && c <= 0x07ff ||
				c >= 0xfb1d && c <= 0xfdff ||
				c >= 0xfe70 && c <= 0xfefc)){
					ret.findChar = true;
					if (!isDirFound){
						ret.dir = "rtl";
					}
					return ret;
			}
			if((c > 64 && c < 91) || (c > 96 && c < 123)){
				if (!isDirFound){
					ret.dir = "ltr";
					isDirFound = true;
				}
			}	        		
    	}
    	return ret;
    };
    
    var checkSourceDir = function(sh) {            	        	
    	var parent = this.getParent();
    	var text = sh.text;
		if (sh.textDir.toLowerCase() == "auto" && parent &&
		parent._isIBMDiagramMultilineText) {
			var firstChild = parent.children[0];
			if (firstChild !== this) {
				if (firstChild.getShape().__beforeBidi) 
					text = firstChild.getShape().__beforeBidi;
				else 
					if (firstChild.getShape().text) 
						text = firstChild.getShape().text;
			}
		}
    	var d = gu.checkDir(text);
    	return d;
 
	};
	
	var convertText = function(text, targetDir, sourceDir, hasBidiChar) {
	    var LRM = '\u200E', LRE = '\u202A', RLE = '\u202B', PDF = '\u202C';
		var RLM = '\u200f';
			   
	   if (iid.isSvgWeb) {
			if (targetDir == "rtl"){
				text = bidiEngine.bidiTransform(text, "IRNNN", "ILNNN");
			}
		}
		else if(iid.isSilverlight) {
			if (targetDir == "rtl"){
				text = bidiEngine.bidiTransform(text, "IRNNN", "VLYSN");
			}
			else {
                text = bidiEngine.bidiTransform(text, "ILNNN", "VLYSN");				
			}
		}
		else if(iid.isCanvas) {
			if (targetDir == "rtl"){
				text = RLE + text + PDF;
			}
			else {
				text = LRE + text + PDF;
			}
		}
		else if(iid.isVml){ 
            if (targetDir != sourceDir){
				if (targetDir == "rtl") {
					if (!hasBidiChar)
						text = bidiEngine.bidiTransform(text, "IRNNN", "ILNNN");
					else
						text = RLM + text;
				}
				else
					text = LRM + text;
			}
		}
		else if(iid.isSvg){
			if (has("ff")){
				if (targetDir == "rtl"){
					text = bidiEngine.bidiTransform(text, "IRYNN", "VLNNN"); 					
				}
				else {
					text = bidiEngine.bidiTransform(text, "ILYNN", "VLNNN");					
				}							
			}
			else if(has("chrome")){
				text = LRM + (targetDir == "rtl"? RLE : LRE) + text + PDF;
			}
		}	
		return text;
	};
		
	gu.checkDir = function(/*String*/text) {
	//
    //	summary:
    //		Returns "ltr" or "rtl" text direction depending on first strong RTL character in the text
    //	
    
   	    var len = text.length;
	    var c;
	    for(var i = 0;i < len;i++){
		    c = text.charCodeAt(i);
		    if((c >= 0x05d0 && c <= 0x065f ||
			    c >= 0x066a && c <= 0x06ef ||
			    c >= 0x06fa && c <= 0x07ff ||
			    c >= 0xfb1d && c <= 0xfdff ||
			    c >= 0xfe70 && c <= 0xfefc)){
				    return "rtl";
		    }
		    if((c > 64 && c < 91) || (c > 96 && c < 123)){
			    return "ltr";
		    }
	    }
	    return "ltr";   //return here some default for neutrals	
    };
    		
	gu.bidiFormat = function(/*Shape*/sh) { 
	//
    //	summary:
    //		apply BidiFormat on the text of the shape, according to the text direction
    //   sh - Shape
    //	
                       
		if (sh.textDir && sh.text && sh.text.length > 1) {
			var sourceDir = "ltr", targetDir = sh.textDir;
			var sourceText = sh.text, targetText = sh.text;
			var hasBidiChar = false;
			var parent = this.getParent();
			if (parent && parent._isIBMDiagramMultilineText) {
				targetText = parent.getShape().text;
			}
			if (iid.isVml){
				sh.text = sh.text.replace(/[\u200E\u200F]/, "");
			    sourceText = sh.text;
				var obj = findDirAndRTLChar(sourceText); 
				sourceDir = obj.dir;
				hasBidiChar = obj.findChar;
				if (targetDir == "auto"){
					if (sourceText == targetText)
						targetDir = sourceDir;
					else
						targetDir = gu.checkDir(targetText);
				}
			}
			else if(targetDir == "auto")
				targetDir = gu.checkDir(targetText);
				
			if (iid.isSvg && has("safari")){ 
			    if (targetDir == "rtl"){
					var node = this.getNode();
					node.setAttribute("unicode-bidi","embed");
					node.setAttribute("direction", "rtl");
				}
				else if (targetDir == "ltr"){
					var node = this.getNode();
					node.setAttribute("unicode-bidi","embed");
					node.setAttribute("direction", "ltr");
				}
			}
			else
			   sh.text = convertText(sh.text, targetDir, sourceDir, hasBidiChar);		
		}
		return sh;			
	};

    gu.complExp = function(/*Shape*/sh) {
    //
    //	summary:
    //		Returns Shape with text converted according to complex expression type
    //	
    //   sh - Shape
    //
        var ce = sh.ceType; //complex expression type,  email: "<>@.,;" or delim[<separators>]
        var textDir = "ltr", delim = "", textout = "", sourcedir = "";
        
        if (ce.match(/delim\[/) != null)
            delim = ce.substr(6, ce.length-7);
        else if (ce == "email")
            delim = "<>@.,;"
        else
            return sh;
            
  
        if (delim != ""){
            var array = "";
            _array.forEach(sh.text, function(ch, i){
                if (delim.indexOf(ch) > -1) {
                    if (array != ""){
                        if(iid.isVml){
                            if (array.charAt(0) == '\u200E')
	                            sourcedir = "ltr";
                            else
                                sourcedir = gu.checkDir(array);
                        }    
                        textout += convertText(array, textDir, sourcedir);
                    }     
                    textout += ch;
                    if(!iid.isVml && !iid.isSilverlight)
                        textout += '\u200E'; //LRM
                    array = "";
                }else    
                    array += ch;
            }); 
            if (array != ""){
                if(iid.isVml){
                    if (array.charAt(0) == '\u200E')
                        sourcedir = "ltr";
                    else
                        sourcedir = gu.checkDir(array);
                }
                textout += convertText(array, textDir, sourcedir);
            }    
        }  
        sh.text = textout;           
        return sh;
    };

	return gu;

 });
