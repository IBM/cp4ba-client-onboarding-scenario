/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/declare",
"./PortBase",
"./util/ErrorReporter"],
function(declare, PortBase, ErrorReporter){

/*=====
var PortBase = ibm_ilog.diagram.PortBase;
=====*/

var BasicPort = declare("ibm_ilog.diagram.BasicPort", PortBase, {
	// summary:
	//		The BasicPort class represents ports that define fixed connection points
	//		relative to the rectangular bounds of a node.
	//		The 'position' property is an object with 'x' and 'y' properties representing
	//		ratios (between 0 and 1) of the width and height of the node. For example,
	//		the position { x: 0.5, y: 0.5} defines a connection point at the center of a node, and
	//		the position { x: 1, y: 0 } defines a connection point at the top-right of a node.
	//		The 'offset' property (another x/y object, but in pixels this time) can be used
	//		to alter slightly this relative position.
	
	// Allows to test the class faster that testing declaredClass
	_isIBMDiagramBasicPort: true,
	
	_position: null,
	_offset: null,
	_movable: true,
	
    constructor: function() {
		// summary:
		//		Creates a new BasicPort with a default position set to the center of the node.
		// description:
		//		The default position is { x: 0.5, y: 0.5 }, and the default offset is { x: 0, y: 0 }.
		this._position = { x: 0.5, y: 0.5 };
		this._offset = { x: 0, y: 0 };
	},
	
	getPosition: function() {
		// summary:
		//		Gets the position of this port.
		// returns:
		//		An object with 'x' and 'y' properties representing a ratio (between 0 and 1) of the node width/height.
		return this._position;
	},
	
	setPosition: function(position) {
		// summary:
		//		Sets the position of this port.
		// position:
		//		An object with 'x' and 'y' properties representing a ratio (between 0 and 1) of the node width/height.
		
		if(typeof(position) != 'object' || !('x' in position) || !('y' in position))
			ErrorReporter.error("UnexpectedArgument",this, "setPosition", "position", position);
		
		if (position.x != this._position.x ||
		    position.y != this._position.y) {
			this._position.x = position.x;
			this._position.y = position.y;
			this.invalidateLinks();
		}
	},
		
    isMovable: function() {
        // summary:
        //		Gets the movable state of this port.
        // returns:
        //		True if graph layout and user interaction are allowed to change the position 
	    //      of the port.
        //		False if graph layout and user interaction are not allowed to change the 
		//      position of the port.
        
		// AVA: the design of the class hierarchy for Ports is different in  
		// Diagram for Flex in the sense that the base class (PortBase) defines
		// a "move" function (default implementation is empty). Hence, the functions
		// "set/isMovable" plus the marker "supportsMove" are also defined at the
		// base class. This allows the code that uses the port to treat all ports in
		// a generic way, without the need to check the port class.
		// Here, the function which allows to move the port ("setPosition") exists
		// only on BasicPort, not on PortBase. Therefore, we cannot place "set/isMovable"
		// and "supportsMove" at PortBase. Not a big deal, but maybe it would be worth
		// to review the design.
		// With the current design, Diagram.flex' "supportsMove" makes no sense here,
		// therefore I only added "set/isMovable".  
        return this._movable ? true : false;
    },
    
    setMovable: function(m) {
        // summary:
        //		Sets the movable state of this port. The ports are movable by default.
        // m: Boolean:
        //		If 'm' is true, graph layout and user interaction are allowed to change the position 
	    //      of the port.
        //		If 'm' is false, graph layout and user interaction are not allowed to change the 
		//      position of the port.
        
        this._movable = m;
    },
	
	getOffset: function() {
		// summary:
		//		Gets the offset of this port.
		// returns:
		//		An object with 'x' and 'y' properties representing horizontal/vertical offsets in pixels.
		return this._offset;
	},
	
	setOffset: function(offset) {
		// summary:
		//		Sets the offset of this port.
		// offset:
		//		An object with 'x' and 'y' properties representing horizontal/vertical offsets in pixels.
		
		if(typeof(offset) != 'object' || !('x' in offset) || !('y' in offset))
			ErrorReporter.error("UnexpectedArgument",this, "setOffset", "offset", offset);
		
		if (offset.x != this._offset.x ||
		    offset.y != this._offset.y) {
			this._offset.x = offset.x;
			this._offset.y = offset.y;
			this.invalidateLinks();
		}
	},
	
	computeConnectionPoint: function(link, parent, referencePoint, connectionPoint, originPoint, start){
		// summary:
		//		Implements the calculation of the connection and origin points for the BasicPort class.
		// description:
		//		The connection point is computed based on the position and offset properties.
		//		The origin point is always the center of the node.
		
		var bounds = this.getConnectionBounds(parent);
		connectionPoint.x = bounds.x + bounds.width * this._position.x;
		connectionPoint.y = bounds.y + bounds.height * this._position.y;
		originPoint.x = bounds.x + bounds.width/2;
		originPoint.y = bounds.y + bounds.height/2;
		connectionPoint.x += this._offset.x;
		connectionPoint.y += this._offset.y;
		return connectionPoint;
	}
});

return BasicPort;

});

