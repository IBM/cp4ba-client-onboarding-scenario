/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"dojox/gfx/matrix",
"./UserCustomizedAction",
"./UndoActionList",
"../../util/GraphUtil"
], function(
declare,
lang,
array,
m,
UserCustomizedAction,
UndoActionList,
GraphUtil
){
	
/*=====
var UserCustomizedAction = ibm_ilog.diagram.editor.undo.UserCustomizedAction;
=====*/

	var UngroupAction =
	declare("ibm_ilog.diagram.editor.undo.UngroupAction", [UserCustomizedAction], {
		//	
		// summary:
		//		this action undo/redo any Ungroup action.
		//		This action must be modified for the user if any user defined action is done on a Ungroup action.
		//
		
	_elements: null,
	_subgraph: null,
	_subgraphTransform: null,
	_deleteAction: null,
	constructor:function(){
		//	
		// summary:
		//		creates a new instance, setting the corresponding label
		this._label = UndoActionList.Group;
	},
	setElements: function(elements){
		//	
		// summary:
		//		sets the elements list to be group
		this._elements = [];
		array.forEach(elements,function(ge){this._elements.push(ge.getId());},this);
	},
	getElements: function(){
		//	
		// summary:
		//		gets the elements list to be group
		return this._elements;// summary:
		//		creates the group undo action.
		// subgraph: ibm_ilog.diagram.Subgraph
		//		the created subgraph, that groups the elements.
		// elements: array of ibm_ilog.diagram.GraphElement
		//		the elements that have been group.
	},
	setSubgraphId: function(subgraphId){
		//	
		// summary:
		//		sets the subgraph where to group
		this._subgraph = subgraphId;
	},
	getSubgraphId: function(){
		//	
		// summary:
		//		gets the subgraph where to group
		return this._subgraph;
	},
	setSubgraphTransform: function(subgraphT){
		//	
		// summary:
		//		sets the subgraph where to group
		this._subgraphTransform = subgraphT;
	},
	getSubgraphTransform: function(){
		//	
		// summary:
		//		gets the subgraph where to group
		return this._subgraphTransform;
	},
	setDeleteAction: function(deleteAction){
		//	
		// summary:
		//		sets the DeleteAction
		this._deleteAction = deleteAction;
		//this._deleteAction.getUndoManager = lang.hitch(function(){this.getUndoManager},this);
	},
	getDeleteAction: function(){
		//	
		// summary:
		//		gets the DeleteAction
		return this._deleteAction;
	},
	setUndoManager: function(undoManager){
		//
		//	summary:
		//		Sets the undo Manager
		this.inherited(arguments);
		this._deleteAction.setUndoManager(undoManager);
	},
	redoFunction: function(){
		var elements = this._getNewList();
		var D = this.getUndoManager().getDiagram();
		var sg = this.getUndoManager().getRegisteredGraphElement(this._subgraph);
		UngroupAction.EditingUtils.groupReparent(D,elements,sg.getParent(),sg);
		this._deleteAction.redo();
	},
	undoFunction: function(){
		var newElements = this._getNewList();
		var D = this.getUndoManager().getDiagram();
		this._deleteAction.undo();
		var sg = this.getUndoManager().getRegisteredGraphElement(this._subgraph);
		sg.setTransform(m.clone(this._subgraphTransform));
		var lca = GraphUtil.lowestCommonAncestor.apply(this,newElements);
		UngroupAction.EditingUtils.groupReparent(D,newElements,sg,lca);
	},
	_getNewList: function(){
		var newElements = [];
		var elements = this.getElements();
		array.forEach(elements, lang.hitch(this, function(item){
			var newItem = this.getUndoManager().getRegisteredGraphElement(item);
			newElements.push(newItem);
		}));
		return newElements;
	}
	});
	
	return UngroupAction;
	
});
