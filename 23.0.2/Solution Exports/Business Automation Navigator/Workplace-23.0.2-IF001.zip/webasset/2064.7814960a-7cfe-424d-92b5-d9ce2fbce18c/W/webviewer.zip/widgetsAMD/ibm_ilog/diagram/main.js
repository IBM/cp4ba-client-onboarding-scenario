/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/lang", "dojo/has"], function(lang, has) {
	// summary:
	//		This module is the main module of Dojo Diagrammer, used by other modules to get a root object (ibm_ilog.diagram).
	
	// Create or get the root ibm_ilog.diagram object. When AMD migration is complete,
	// this *should* be the only place where we explicitly reference ibm_ilog.diagram
	// (apart from dojo.declare() calls, which also create global variables as a side effect).
	//
	var diagram = lang.getObject("ibm_ilog.diagram", true);
	
	/*=====	
	ibm_ilog.diagram.version = function(){
		// summary:
		//		Version number of Dojo Diagrammer.
		// major: Integer
		//		Major version.
		// minor: Integer
		//		Minor version.
		// fixpack: Integer
		//		Fix Pack version.
		// ifix: Integer
		//		iFix version.
		// flag: String
		//		Descriptor flag.
		this.major = 0;
		this.minor = 0;
		this.fixpack = 0;
		this.ifix = 0;
		this.flag = "";
	}
	=====*/
	diagram.version = {
		major: 1, minor: 1, fixpack: 2, ifix: 0, flag: "",
		toString: function(){
			var v = diagram.version;
			return v.major + "." + v.minor + "." + v.fixpack + "." + v.ifix + v.flag;	// String
		}
	};
	
	return diagram;
	
});
