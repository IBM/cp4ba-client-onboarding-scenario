/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/array",
"dojox/collections/Dictionary",
"dojox/collections/Set",
"dojox/collections/ArrayList",
"./Interactor",
"../util/ErrorReporter"
],
function(
declare,
arr,
Dictionary,
Set,
ArrayList,
Interactor,
R
){

var InteractorManager =
declare("ibm_ilog.diagram.interactors.InteractorManager", [], {
	//
	//	summary:
	//		Organizes interactors by id and is responible for distinguishing 
	//		the currently active interactors.
	//
	
	//
	//	_interactors: 
	//		Registered interactors
	_interactors:null,
	
	//
	//	_stack: 
	//		Holds active interaction (currently only one level is used)
	_stack:null,
	
	//
	//	_base: 
	//		Idle interactors, which are active when _stack is empty
	_base:null,
	
	constructor:function(){
		//
		//	summary:
		//		creates a new instance of InteractorManager
		//
		this._interactors = new Dictionary();
		this._base = this._gatherInteractors([]);
		this._stack = [];
	},
	
	add:function(id,interactor){
		//
		//	summary:
		//		register a new interactor with the given id
		//
		this._interactors.add(id,interactor);
		interactor._manager = this;
	},

	get:function(id){
		//
		//	summary:
		//		Returns the interactor registered with the given id
		//
		var interactor = this._interactors.item(id);
		if(!interactor) {
			R.error("InvalidInteractorId",id);
		}
		return interactor;
	},
	
	top:function(){
		//
		//	summary:
		//		Returns the top level of the stack
		//
		return this._stack[this._stack.length-1];
	},

	activeInteractors:function(){
		//
		//	summary:
		//		Returns a set with the currently active interactors
		//
		return this._stack.length?this.top().interactors:this._base;
	},

	_createStackObject:function(interactors){
		//
		//	summary:
		//		Returns a new stack object (also used as handle for popping)
		//
		return {interactors:interactors, active:true, index:this._stack.length};
	},

	_activate: function() {
		//
		//	summary:
		//		Activate the active set (currently: either _base or _stack[0])
		//
		this.activeInteractors().forEach(function(i){
			i.activate();
		},this);
	},

	_deactivate: function() {
		//
		//	summary:
		//		Deactivate the active set (currently: either _base or _stack[0])
		//
		this.activeInteractors().forEach(function(i){
			i.deactivate();
		},this);
	},
	
	_gatherInteractors: function( /*array*/ maybeNames ) {
		//
		//	summary:
		//		Gather a set of interactor that are listed explicitly of 
		//      by name into a dojox.collections.Set
		//
		var interactors = new ArrayList();
		arr.forEach(maybeNames,function(i){
			if(typeof i=="string") {
				interactors.add(this.get(i));
			} else if (i instanceof Interactor) {
				interactors.add(i);
			} else {
				R.error("UnexpectedArgument");
			}
		},this);
		return interactors;
	},	
	
	switchTo:function(interactor1,interactor2,etc){
		//
		//	summary:
		//		Changes the set of idle interactors that are ready to be used. 
		//		Has immediate effect only when there are no elements in the active _stack.
		//
		var interactors = this._gatherInteractors(arguments); 

		if(!this._stack.length) {
			this._deactivate();
			this._base = interactors;
			this._activate();
		} else {
			this._base = interactors;
		}
	},
	
	push:function(interactor1,interactor2,etc){
		//
		//	summary:
		//		Push a set of interactors into the active stack. (Although currently only 1 is supported)
		//
		if(this._stack.length) {
			R.error("RestrictedToOneInteractor");
		}
		
		var interactors = this._gatherInteractors(arguments);
		var keep = [];
		var old = this.activeInteractors();
		var so = this._createStackObject(interactors);
		this._stack.push(so);
		var n = this.activeInteractors();
		Set.difference(old,n).forEach(function(i){
			i.deactivate();
		});
		
		return this.top(); // this is the handle for deactivation
	},

	pop:function(h){
		//
		//	summary:
		//		Deactivates and eventually pops the interactors previously pushed on the active stack
		//
		if(h.active) {
			h.active = false;
			if(h == this.top()) {
				var old = this.activeInteractors();
				var i = h.index;
				while(i>=0 && !this._stack[i].active) {
					this._stack.pop();
					i--;
				}
				var n = this.activeInteractors();

				Set.difference(n,old).forEach(function(i){
					i.activate();
				});
			}
		}
	},
	
	stackLength: function(){
		return this._stack.length;
	},

	__eod:undefined

});

return InteractorManager;

});