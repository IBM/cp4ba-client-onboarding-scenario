/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/declare", "dojox/gfx/matrix", "./Layout", "../util/Geometry"],
function(declare, matrix, Layout, Geometry){

/*=====
var Layout = ibm_ilog.diagram.gfxlayout.Layout;
=====*/

var CanvasLayout =
declare('ibm_ilog.diagram.gfxlayout.CanvasLayout', Layout, {

	getConfig:function(){
		// summary:
		// Gets the current configuration of this layout instance.
		// returns: Object
		//	An object that represents the layout current configuration.
		return {type:'ibm_ilog.diagram.gfxlayout.CanvasLayout'}; /*Object*/
	},

	computePreferredSize: function(proposedSize) {
		var children = this._container.children, count = children.length, i, bbox, sz;
		for (i = 0; i < count; ++i) {
			var child = children[i];
			sz = child.computePreferredSize({
				width: -1,
				height: -1
			});
			var rect = child.getBoundingBox();
			if (!rect) 
				continue;
			var t = child.getTransform();
			
			if (child.__oldLayoutTransform) {
				t = matrix.multiply(child.__oldLayoutTransform.inverse(), t);
			}
			
			if (t && !t.isIdentity()) 
				rect = t.transformRectangle(rect);
			rect.width = sz.width;
			rect.height = sz.height;
			bbox = bbox ? Geometry.addRect(rect, bbox) : rect;
		}
		return {
			width: bbox ? bbox.width : -1,
			height: bbox ? bbox.height : -1
		};
	},
	
	layoutChildren: function(contBounds) {
		var children = this._container.children, count = children.length, o, i;
		if (count === 0) 
			return;
		for (i = 0; i < count; ++i) {
			var child = children[i];
			// Process only panels (ie a Group with a Layout)
			if (!child.children || !child.getLayout()) 
				continue;
			var sz = child.getPreferredSize();
			child.layout({
				x: 0,
				y: 0,
				width: sz.width,
				height: sz.height
			});
		}
		// translate the graph so that the top-left corner of its content bbox
		// matches the layout origin (contBounds)
		var r = this._container.getBoundingBox();
		if (!r) 
			return;
		var t = this._container.getTransform();
		if (this._oldCanvasTransform) 
			t = matrix.multiply(this._oldCanvasTransform.inverse(), t);
		this._oldCanvasTransform = matrix.translate(contBounds.x - r.x, contBounds.y - r.y);
		t = matrix.multiply(t, this._oldCanvasTransform);
		this._container.setTransform(t);
	}
});

return CanvasLayout;

});
