/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
function _loadDojo(baseUrl, graphlayoutUrl, diagramUrl){
	// summary: Loads a minimal Dojo library in a Web Worker thread (Dojo 1.7+/AMD version).
	
	dojoConfig = {
		baseUrl: baseUrl,
		paths: {
				'ibm_ilog/diagram' : diagramUrl ,
				'ibm_ilog/graphlayout' : graphlayoutUrl
		},
		async: false,				// very important, otherwise layouts cannot be loaded dynamically.
		has: {
			"host-browser": 0,
			"dom": 0,
			"dojo-has-api": 1,
			"dojo-xhr-factory": 0,
			"dojo-inject-api": 1,
			"dojo-timeout-api": 0,
			"dojo-trace-api": 1,
			"dojo-loader-catches": 1,
			"dojo-dom-ready-api": 0,
			"dojo-dom-ready-plugin": 0,
			"dojo-ready-api": 1,
			"dojo-error-api": 1,
			"dojo-publish-privates": 1,
			"dojo-gettext-api": 1,
			"dojo-sniff": 0,
			"dojo-loader": 1,
			"dojo-boot": 1,
			"dojo-test-xd": 0,
			"dojo-test-sniff": 0,
			"graph-layout-without-diagram": 1
		},
		
		loaderPatch: {
			// We must provide a getText function that works in  web worker.
			getText: function(url, async, onLoad){
				var xhr = new XMLHttpRequest();
				xhr.open('GET', url + "", false);
				xhr.send(null);
				if (xhr.status == 200 || !xhr.status) {
					if (onLoad) {
						onLoad(xhr.responseText, async);
					}
				}
				else {
					throw new Error("xhrFailed: " + xhr.status);
				}
				return xhr.responseText;
			}
		}
	};
	
	importScripts(baseUrl + "/dojo.js");
	
	// Define a simplified dojo/_base/connect module: we cannot import
	// the full dojo/_base/connect since it includes DOM code for mouse events etc.
	// Here we have no dom, so we never use 'on': connect always calls aspect.after.
	
	define("dojo/_base/connect",
	["dojo/_base/lang", "dojo/aspect"],
	function(lang, aspect){
	
		var connect = {};
		
		connect.connect = function(obj, event, context, method, dontFix){
			var a = arguments, args = [], i = 0;
			args.push(typeof a[0] == "string" ? null : a[i++], a[i++]);
			var a1 = a[i + 1];
			args.push(typeof a1 == "string" || typeof a1 == "function" ? a[i++] : null, a[i++]);
			for (var l = a.length; i < l; i++) {
				args.push(a[i]);
			}
			return aspect.after(obj || self, event, lang.hitch(context, method), true);
		};
		
		connect.disconnect = function(handle){
			if (handle) {
				handle.remove();
			}
		};
		
		return connect;
	});
}
