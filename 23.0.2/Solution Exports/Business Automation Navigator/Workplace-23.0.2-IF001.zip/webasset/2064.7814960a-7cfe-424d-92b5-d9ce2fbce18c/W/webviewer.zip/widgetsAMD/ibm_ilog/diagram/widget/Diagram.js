/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"../main",
"require",
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"dojo/_base/json",
"dojo/_base/config",
"dojo/_base/connect",
"dojo/dom-geometry",
"dojo/dom-construct",
"dojo/dom-style",
"dijit/_Widget",
"dijit/registry",
"dojox/gfx/matrix",
"dojox/gfx/utils",
"dojox/collections/ArrayList",
"dojox/collections/Dictionary",
"../_base/dojoext",
"./DataConnector",
"./DivViewport",
"../overview/OverviewTopLevelTemplateRenderer",
"../widget/OverviewHudComponent",
"../widget/ZoomHudComponent",
"../interactors/PanInteractor",
"../interactors/ZoomInteractor",
"../interactors/SelectionInteractor",
"../interactors/InteractorManager",
"../data/dtlbinding",
"../util/ErrorReporter",
"../util/DeferredInitialization",
"../util/Geometry",
"../util/GraphUtil",
"../style",
"../Graph",
"../Node",
"../Link",
"../Subgraph",
"../Selection",
"../Selectable",
"dojo/has!config-isBidiInDojoDiagrammer?../util/BidiUtil:",
"dojo/has!config-diagramForMobile?:./_Diagram",
"../data/StoreApi"
], function(
iid,
require,
declare,
lang,
array,
json,
config,
connect,
domgeo,
domctr,
domstyle,
_Widget,
registry,
matrix,
gfxutils,
ArrayList,
Dictionary,
dojoext,
DataConnector,
DivViewport,
OverviewTopLevelTemplateRenderer,
OverviewHudComponent,
ZoomHudComponent,
PanInteractor,
ZoomInteractor,
SelectionInteractor,
InteractorManager,
dtlbinding,
R,
DeferredInitialization,
g,
gu,
_style,
Graph,
Node,
Link,
Subgraph,
Selection,
Selectable,
BidiUtil,
_Diagram,
StoreApi
){

	var Size = g.Size;
	
	var Tooltip;
	
	var _emptyEntityHandler = function(entity, event) {
	};
	
/*=====
var _Widget = dijit._Widget;
var DataConnector = ibm_ilog.diagram.widget.DataConnector;
var DeferredInitialization = ibm_ilog.diagram.util.DeferredInitialization;
=====*/

	var Diagram =
	declare('ibm_ilog.diagram.widget.Diagram', [_Widget, DataConnector, DeferredInitialization], {
		// summary:
		//		The Diagram widget is the main entry point to the Dojo Diagrammer component.
		// description:
		//		The purpose of the Dojo Diagrammer component is to display <em>graphs</em> (or <em>diagrams</em>)
		//		(that is, graphical representations consisting of nodes connected by links)
		//		in a Web browser page. The Dojo Diagrammer component is fully implemented in JavaScript
		//		and is based on the Dojo Toolkit. Dojo Diagrammer uses DojoX GFX to render the diagram.
		//		<p>
		//		The Diagram widget is the Dijit widget that is commonly used as an entry point to Dojo Diagrammer,
		//		and provides the following main features:
		//		<ul>
		//		<li><strong>Data store connection</strong>
		//		The Diagram widget can load a Dojo data store that implements the dojo.data.api.Read interface.
		//		For this, the data store must be set as the 'nodesStore' attribute of the Diagram.
		//		Each item of the data store will typically be displayed as a node in the graph.
		//		The appearance of the nodes is defined by a <em>template</em>, specified using the 'nodeTemplate'
		//		attribute (or the nodeTemplateFunction to define different templates according to each item).
		//		The Diagram widget will also create links to represent the relationships between nodes.
		//		These relationships must be defined by specifying one or several of the following attributes:
		//		childBinding, parentBinding, successorsBinding, predecessorsBinding. For example, if
		//		successorsBinding attribute is set to "nextItems", the value if the "nextItems" property
		//		of the data items is expected to be an array of identifiers that define
		//		the set of items to which the current item should be connected by links.
		//		</li>
		//		<li><strong>Viewport (scrolling and zooming)</strong>
		//		If the diagram is larger than the client area of the Diagram, it can be scrolled using the
		//		scrollbars or using the mouse (the default interaction for panning is Shift-drag).
		//		The diagram can also be zoomed or unzoomed (the default interaction is Control-mouse wheel).
		//		Alternately, all viewport actions can be done by code through the viewport object, accessible by the getViewport()
		//		method.
		//		</li>
		//		<li><strong>Selection</strong>
		//		Nodes and links in the diagram can be selected. The set of selected objects can be accessed and modified
		//		through the selection object accessible by the getSelection() method.
		//		The appearance of selected objects can be customized through their template.
		//		</li>
		//		<li><strong>Event handling</strong>
		//		The Diagram handles mouse and keyboard events through objects called "interactors". Examples of interactors are
		//		the SelectionInteractor, the PanInteractor, the ZoomInteractor, etc. The predefined interactors can be
		//		enabled or disabled using attributes of the Diagram widget: 'select', 'zoom', 'pan', etc.
		//		In addition, the Diagram widget provides events to easily connect to mouse or key events on all the
		//		nodes or links of the diagram: onNodeClick, onNodeMouseDown, onLinkClick, etc.
		//		</li>
		//		<li><strong>Accessibility</strong>
		//		The Diagram widget provides accessibility services: the diagram can be described by a screen reader,
		//		and the user can navigate through the nodes and links using the keyboard.
		//		</li>
		//		<li><strong>Touch-enablement and mobile support</strong>
		//		The Diagram widget reacts to touch events on mobile platforms (or other touch-enabled devices):
		//		single touch-and-scroll pans the diagram, two-fingers pinch zooms the diagram.
		//		Dojo Diagrammer can be used with dojox.mobile.
		//		In addition, to optimize download size, some features are disabled on mobile:
		//		key events, focus adorners, accessibility, etc. You can explicitly disable these features by setting
		//		the 'diagramForMobile' flag to true in djConfig/dojoConfig. If diagramForMobile is not defined,
		//		the Diagram widget tries to auto-detect some well-known mobile user agents. Note that diagramForMobile
		//		is also set to true if the dojox.mobile module is loaded before the Diagram widget is loaded.
		//		You can set diagramForMobile to false explicitly to enable all features even on mobiles.
		//		</li>
		//		</ul>
		//		The Diagram widget uses the following basic graphic objects behind the scene to display the diagram:
		//		<ul>
		//		<li><strong>Graph</strong> (class ibm&#95;ilog.diagram.Graph): A subclass of dojox.gfx.Group that contains nodes and links. </li>
		//		<li><strong>Node</strong> (class ibm&#95;ilog.diagram.Node): Represents a node in a Graph, the contents of a Node are defined by a template. </li>
		//		<li><strong>Link</strong> (class ibm&#95;ilog.diagram.Link): Represents a link between two nodes. </li>
		//		<li><strong>Subgraph</strong> (ibm&#95;ilog.diagram.Subgraph): Represents a Node that contains a nested Graph. </li>
		//		</ul>
		//		It is possible to use the Dojo Diagramer component without using a Diagram widget.
		//		For this, you must create a GFX surface (or use an existing one), and create a Graph in it using surface.createGraph().
		//		You can then create nodes, links and subgraphs using the methods createNode, createLink and createSubgraph of the Graph
		//		object.
		
		_isIBMDiagramDiagram: true,
		
		_graph: null,
		
		_firePropertyChanged: function(pname, oldValue, newValue) {
			if (this.isInitialized()) {
				this.onPropertyChanged(pname, oldValue, newValue);
			}
		},
		
		onPropertyChanged: function(/*String*/name, /*Object*/ oldValue, /*Object*/ newValue) {
			// summary:
			//     An extension point invoked when a property has changed.
			// name: String: the property name.
			// oldValue: Object: the old property value.
			// newValue: Object: the new property value.
		},
		
		// Public properties
		
		// loadOnCreate: Boolean
		//		Indicates whether data are loaded automatically at the end of the widget creation phase (provided all required parameters have been set). 
		//		The default value is true. If set to false,	it requires a explicit call to Diagram.load() to load the data and build the graph.
		loadOnCreate: true,
		
		// nodesStore: dojo.data.api.Read 
		//		A data store that provides data item to be represented as Nodes.
		//		Must implement at least the dojo.data.api.Read and dojo.data.api.Identity interfaces.
		nodesStore: null,
		
		_setNodesStoreAttr: function(value) {
			var old = this._getNodesStore();
			if (old !== value) {
				this.nodesStore = this._setNodesStore(value);
				this._firePropertyChanged('nodesStore', old, value);
			}
			return this;
		},
		
		// An object providing the query criteria for the nodes data store.
		nodesQuery: null, // cast the value as an Object
		
		_setNodesQueryAttr: function(value) {
			// use the DataConnector getter to get the real old value and not the one set in the mixin() step
			var old = this._getNodesQuery(); 
			this.nodesQuery = this._setNodesQuery(value);
			this._firePropertyChanged('nodesQuery', old, value);
			return this;
		},
		
		// nodesQueryOptions: Object
		//                    An object containing additional options for the node query.
		nodesQueryOptions: {}, // cast the value as an Object
		_setNodesQueryOptionsAttr: function(value) {
			// use the DataConnector getter to get the real old value and not the one set in the mixin() step
			var old = this._getNodesQueryOptions();
			this.nodesQueryOptions = this._setNodesQueryOptions(value);
			this._firePropertyChanged('nodesQueryOptions', old, value);
			return this;
		},
		
		_setBindingAttr: function(value, pname) {
			if (value) {
				var func = lang.getObject(value); // global scope
				// We don't want "xBinding" treated as variable name only a Function or a String
				if (typeof(func) == "function") {
					value = func;
				}
			}
		    var uname = (pname.substr(0, 1).toUpperCase()) + pname.substr(1);
			// _s and _g refer to the corresponding functions defined in the DataConnector impl.
			// which all starts like '_setFoo'
			var _s = '_set' + uname;
			var _g = '_get' + uname;
			var old = this[_g]();
			if (old !== value) {
				this[pname] = this[_s](value);
				this._firePropertyChanged(pname, old, value);
			}
			return this;
		},
		
		// childBinding: String
		//     A string that indicates either the data item field name 
		//     defining the "child" relationship or a function name that returns the
		//     origin of a link for the specified data item.
		childBinding: "", // cast the value as a String
		
		_setChildBindingAttr: function(value) {
			// We don't want "xBinding" treated as variable name only a Function or a String
			return this._setBindingAttr(value, 'childBinding');
		},
		
		// parentBinding: String
		//     A string that indicates either the data item field name defining the
		//     "parent" relationship or a function name that returns the destination 
		//     of a link for the specified data item.
		parentBinding: "", // cast the value as a String
		
		_setParentBindingAttr: function(parentBinding) {
			return this._setBindingAttr(parentBinding, 'parentBinding');
		},
		
		// predecessorsBinding: String
		//     A string that indicates either the data item field name 
		//     defining the predecessors or a function name that returns the
		//     origins of a link for the specified data item.
		predecessorsBinding: "", // cast the value as a String
		
		_setPredecessorsBindingAttr: function(predecessorsBinding) {
			return this._setBindingAttr(predecessorsBinding, 'predecessorsBinding');
		},
		
		// successorsBinding: String
		//     A string that indicates either the data item field name defining the
		//     successors or a function name that returns the destination 
		//     of a link for the specified data item.
		successorsBinding: "", // cast the value as a String

		_setSuccessorsBindingAttr: function(successorsBinding) {
			return this._setBindingAttr(successorsBinding, 'successorsBinding');
		},
		
		// xBinding: String
		//     A string that indicates either the data item field name defining the
		//     "x location" associated with a nodesStore data item or a named function that 
		//     returns the "x location" associated with a nodesStore data item.
		xBinding: "", // cast the value as a String
		
		_setXBindingAttr: function(xBinding) {
			return this._setBindingAttr(xBinding, 'xBinding');
		},
		
		// yBinding: String
		//     A string that indicates either the data item field name defining the
		//     "y location" associated with a nodesStore data item or a named function that 
		//     returns the "y location" associated with a nodesStore data item.
		yBinding: "", // cast the value as a String

		_setYBindingAttr: function(yBinding) {
			return this._setBindingAttr(yBinding, 'yBinding');
		},
		
		// nodesGraphBinding: String
		//     A string that indicates either the data item field name defining the
		//     "node graphic data" associated with a nodeStore data item or a named function that 
		//     returns the "node graphic data" associated with a linksStore data item.
		nodesGraphBinding: "", // cast the value as a String

		_setNodesGraphBindingAttr: function(nodesGraphBinding) {
			return this._setBindingAttr(nodesGraphBinding, 'nodesGraphBinding');
		},
		
		// nodesGraphProperties: String
		//           A comma-separated list of properties to save if nodesGraphBinding is specified.
		nodesGraphProperties: "",
		
		_setNodesGraphPropertiesAttr: function(value) {
			var old = this._getNodesGraphProperties();
			if (old !== value) {
				this.nodesGraphProperties = this._setNodesGraphProperties(value);
				this._firePropertyChanged('nodesGraphProperties', old, value);
			}
			return this;
		},
		
		// centerOnLocation: Boolean
		//     If true, the values provided by xBinding/yBinding atributes represent the center of the node.
		//     If false, the values provided by xBinding/yBinding atributes represent the top left-hand corner of the node.
		centerOnLocation: false,
		
		_setCenterOnLocationAttr: function(value) {
			var old = this._getCenterOnLocation();
			if (old !== value) {
				this.centerOnLocation = this._setCenterOnLocation(value);
				this._firePropertyChanged('centerOnLocation', old, value);
			}
			return this;
		},
		
		// linksStore: dojo.data.api.Read
		//             A data store that provides data item to be represented as Links when the
		//             nodes relationship cannot be implicitly deducted from the nodes store data structure.
		//             Must implement at least the dojo.data.api.Read and
		//             dojo.data.api.Identity interfaces.
		linksStore: null,
		
		_setLinksStoreAttr: function(value) {
			var old = this._getLinksStore();
			if (old !== value) {
				this.linksStore = this._setLinksStore(value);
				this._firePropertyChanged('linksStore', old, value);
			}
			return this;
		},
		
		// linksQuery: Object
		//     An object providing the query criteria for the links datas store.		
		linksQuery: null, // cast the value as a String
		
		_setLinksQueryAttr: function(value) {
			var old = this._getLinksQuery();
			this.linksQuery = this._setLinksQuery(value);
			this._firePropertyChanged('linksQuery', old, value);
			return this;
		},
		
		// linksQueryOptions: Object
		//                    An object containing additional options for the links query.
		linksQueryOptions: {}, // cast the value as an Object

		_setLinksQueryOptionsAttr: function(value) {
			var old = this._getLinksQueryOptions();
			this.linksQueryOptions = this._setLinksQueryOptions(value);
			this._firePropertyChanged('linksQueryOptions', old, value);
			return this;
		},
		
		// linksGraphBinding: String
		//     A string that indicates either the data item field name defining the
		//     "link graphic data" associated with a linksStore data item or a named function that 
		//     returns the "link graphic data" associated with a linksStore data item.
		linksGraphBinding: "", // cast the value as a String
		
		_setLinksGraphBindingAttr: function(linksGraphBinding) {
			return this._setBindingAttr(linksGraphBinding, 'linksGraphBinding');
		},
		
		// linksGraphProperties: String
		//     A comma-separated list of properties to save if linksGraphBinding is specified.
		linksGraphProperties: "",
		
		_setLinksGraphPropertiesAttr: function(value) {
			var old = this._getLinksGraphProperties();
			if (old !== value) {
				this.linksGraphProperties = this._setLinksGraphProperties(value);
				this._firePropertyChanged('linksGraphProperties', old, value);
			}
			return this;
		},
		
		// startNodeBinding: String
		//              A string that indicates either the data item field name 
		//              defining the "start" of a link or a function name that returns the
		//              origin of a link for the specified data item.
		startNodeBinding: "start", // cast the value as a String and set the default as field with name of "start"
		
		_setStartNodeBindingAttr: function(startNodeBinding) {
			return this._setBindingAttr(startNodeBinding, 'startNodeBinding');
		},

		// endNodeBinding: String
		//     A string that indicates either the data item field name defining the
		//     "end" of a link or a function name that returns the destination 
		//     of a link for the specified data item.
		endNodeBinding: "end", // cast the value as a String and set the default as field with name of "end"

		_setEndNodeBindingAttr: function(endNodeBinding) {
			return this._setBindingAttr(endNodeBinding, 'endNodeBinding');
		},
		
		// createLinksForHierarchy: Boolean
		//     If true, the hierarchy is rendered using nodes and links.
		//     If false, it is rendered using subgraphs and nodes
		createLinksForHierarchy: true,
		
		_setCreateLinksForHierarchyAttr: function(value) {
			var old = this._getCreateLinksForHierarchy();
			if (old !== value) {
				this.createLinksForHierarchy = this._setCreateLinksForHierarchy(value);
				this._firePropertyChanged('createLinksForHierarchy', old, value);
			}
			return this;
		},
		
		// textDir: String
		//     A string that indicates the text direction of displayed text
		textDir: "",   
		
		_setTextDirAttr: function(value) {
		    if (config.isBidiInDojoDiagrammer) {
		        if (this._graph)
		            this._graph.setTextDir(value);
	  	        if (this._annotations) {
		           array.forEach(this._annotations,function(a) {
				        if (a.setTextDir)
				            a.setTextDir(value);
			            });
    	        }    
		    }
		},		
		
		//////////////////////////////////////////////////////////////////////////////
		//	Viewport Properties
		//

		viewportClass: "DivViewport",
		
		//
		//	viewportAirFactor: [markup] Boolean
		//		The minimum navigable space to the sides of the current content bounds as a percentage
		//		with respect to the current model bounding box.
		viewportAirFactor: 0.0,
		_setViewportAirFactorAttr: function(value) {
			return this._setViewportAttr("AirFactor",value); 
		},
		_getViewportAirFactorAttr: function(){
			return this._getViewportAttr("AirFactor");
		},

		//
		// viewportAnimated: [markup] Boolean
		//		Boolean flag to indicate that viewport movements are animated by default.
		viewportAnimated: false,
		_setViewportAnimatedAttr: function(value) {
			return this._setViewportAttr("Animated",value); 
		},
		_getViewportAnimatedAttr: function(){
			return this._getViewportAttr("Animated");
		},

		//
		// viewportMaxZoom: [markup] Number
		//		Defines how much the view rectangle can zoom in. Unlimited if 0.
		viewportMaxZoom: 0,
		_setViewportMaxZoomAttr: function(value) {
			return this._setViewportAttr("MaxZoom",value); 
		},
		_getViewportMaxZoomAttr: function(){
			return this._getViewportAttr("MaxZoom");
		},

		//
		//	viewportMinZoom: [markup] Number
		//		Defines how much the view rectangle can zoom out. If 0, the limit is based on the contentRectangle.
		//
		viewportMinZoom: 0,
		_setViewportMinZoomAttr: function(value) {
			return this._setViewportAttr("MinZoom",value); 
		},
		_getViewportMinZoomAttr: function(){
			return this._getViewportAttr("MinZoom");
		},

		//
		//	viewportResizeMode: [markup] Number
		//		Resize mode of the vieport. See Viewport.js
		//
		viewportResizeMode: 1,
		_setViewportResizeModeAttr: function(value) {
			return this._setViewportAttr("ResizeMode",value); 
		},
		_getViewportResizeModeAttr: function(){
			return this._getViewportAttr("ResizeMode");
		},

		
		
		// Initialize viewport properties.
		// The method is called during the postCreate stage to apply the markup properties
		// that have been deferred (viewport is not fully initialized when the custom
		// setters are invoked by the dijit attributes engine).
		_initializeViewportProperties: function(){
			if (this.overviewSize != undefined)
				this._setOverviewSizeAttr(this.overviewSize);
			if (this.overviewPan != undefined)
				this._setOverviewPanAttr(this.overviewPan);
			if (this.overviewZoom!= undefined)
				this._setOverviewZoomAttr(this.overviewZoom);
			if (this.showZoomFactor)
				this._setShowZoomFactorAttr(this.showZoomFactor);
			if (this.showZoomFeedback)
				this._setShowZoomFeedbackAttr(this.showZoomFeedback);
			if (this.overview)
				this._setOverviewAttr(this.overview);
			if (!this.hud)
				this._setHudAttr(this.hud);
		},

		
		
		//
		//	overviewSize: Size
		//		The size of the embedded Overview
		//		
		overviewSize: Size(100, 100),
		
		_setOverviewSizeAttr: function(value) {
			if (!this._viewportReady)
				return;
			var old = this._getOverviewSizeAttr();
			this.overviewSize = value;
			if (this._hudOverview) {
				this._hudOverview.setSize(value);
			}
			this._firePropertyChanged('overviewSize', old, value);
			return this;
		},
		
		_getOverviewSizeAttr:function(){
			return this._hudOverview ? this._hudOverview.getSize() : this.overviewSize;
		},
		
		
		//
		//	overviewPan: boolean
		//		Activate or deactivate panning in the hud overview
		//		
		overviewPan: true,
		
		_setOverviewPanAttr: function(value) {
			if (!this._viewportReady)
				return;
			var old = this._getOverviewPanAttr();
			this.overviewPan = value;
			if (this._hudOverview) {
				this._hudOverview.setPan(value);
			}
			this._firePropertyChanged('overviewPan', old, value);
			return this;
		},
		
		_getOverviewPanAttr:function(){
			return this._hudOverview ? this._hudOverview.getPan() : this.overviewPan;
		},

		
		//
		//	overviewZoom: boolean
		//		Activate or deactivate panning in the hud overview
		//		
		overviewZoom: true,
		
		_setOverviewZoomAttr: function(value) {
			if (!this._viewportReady)
				return;
			var old = this._getOverviewZoomAttr();
			this.overviewZoom = value;
			if (this._hudOverview) {
				this._hudOverview.setZoom(value);
			}
			this._firePropertyChanged('overviewZoom', old, value);
			return this;
		},
		
		_getOverviewZoomAttr:function(){
			return this._hudOverview ? this._hudOverview.getZoom() : this.overviewZoom;
		},

		
		//
		//	showZoomFactor: [markup] Boolean
		//		Display the current zoom factor
		//		
		showZoomFactor: false,
		
		_setShowZoomFactorAttr: function(enabled) {
			if (!this._viewportReady)
				return;
			var old = this._getShowZoomFactorAttr();
			if (old !== enabled) {
				this.showZoomFactor = enabled;
				if (!this._hudZoom) {
					this._hudZoom = new ZoomHudComponent(this._viewport);
				}
				this._hudZoom.setEnabled(enabled);
				this._firePropertyChanged('showZoomFactor', old, enabled);
			}
			return this;
		},
		
		_getShowZoomFactorAttr: function() {
			return this._hudZoom ? this._hudZoom.isEnabled() : false;
		},
		
		
		//
		//	showZoomFeedback: [markup] Boolean
		//		Display a visual feedback while zooming with animation 
		//		
		showZoomFeedback: false,
		
		_setShowZoomFeedbackAttr: function(/*Boolean*/enabled) {
			if (!this._viewportReady)
				return;
			var old = this._getShowZoomFeedbackAttr();
			if (old !== enabled) {
				this.showZoomFeedback = enabled;
				this._viewport.setHudZoomFeedbackEnabled(enabled);
				this._firePropertyChanged('showZoomFeedback', old, enabled);
			}
			return this;
		},
		
		_getShowZoomFeedbackAttr: function() {
			return this._viewportReady ? this._viewport.isHudZoomFeedbackEnabled() : false;
		},
		
		
		
		//
		//  overview: [markup] Boolean
		//      Use the embedded overview hud component
		//      
		overview: false,
		
		_setOverviewAttr: function(/*Boolean*/enabled) {
			if (!this._viewportReady)
				return;
			var old = this._getOverviewAttr();
			if (old !== enabled) {
				this.overview = enabled;
				if (!this._hudOverview) {
					var renderer = this.overviewRenderer || new OverviewTopLevelTemplateRenderer();
					this._hudOverview = new OverviewHudComponent(this._viewport, this._graph, renderer, this.overviewSize);
					this._hudOverview.getOverview().setInteractorManager(this._interactors);
					this._hudOverview.setPan(this.overviewPan);
					this._hudOverview.setZoom(this.overviewZoom);
				}
				this._hudOverview.setEnabled(enabled);
				this._firePropertyChanged('overview', old, enabled);
			}
			return this;
		},
		
		_getOverviewAttr: function() {
			return this._hudOverview ? this._hudOverview.isEnabled() : false; 
		},


		
		//
		//  overviewRenderer: ibm_ilog.diagram.overview.OverviewRenderer
		//      Use renderer used in the embedded overview
		//      
		overviewRenderer: false,
		
		_setOverviewRendererAttr: function(/*ibm_ilog.diagram.overview.OverviewRenderer*/renderer) {
			if (!this._viewportReady)
				return;
			var old = this._getOverviewRendererAttr();
			if (old !== renderer) {
				this.overviewRenderer = renderer;
				if (this._hudOverview) {
					this._hudOverview.getOverview().setRenderer(renderer);
				}
				this._firePropertyChanged('overviewRenderer', old, renderer);
			}
			return this;
		},
		
		_getOverviewRendererAttr: function() {
			return this._hudOverview ? this._hudOverview.getOverview().getRenderer() : this.overviewRenderer; 
		},
		
		
		//
		//  hud: [markup] Boolean
		//      Use to disable the entire viewport hud.
		//      
		
		hud: true,
		
		_setHudAttr: function(enabled) {
			if (!this._viewportReady)
				return;
			var old = this._getHudAttr();
			if (old !== enabled) {
				this.hud = enabled;
				this._viewport.setHudEnabled(enabled);
				this._firePropertyChanged('hud', old, enabled);
			}
			return this;
		},
		
		_getHudAttr: function() {
			return this._viewportReady ? this._viewport.isHudEnabled() : true;
		},

		
		
		_setViewportAttr: function(uname, value) {
			if (!this._viewportReady)
				return;
			var old = this['_getViewport'+uname+'Attr']();
			if (old !== value) {
				var pname = 'viewport'+uname;
				this[pname] = value;
				this._viewport['set'+uname](value);
				this._firePropertyChanged(pname, old, value);
			}
			return this;
		},

		_getViewportAttr: function(uname) {
			var pname = 'viewport'+uname;
			if (!this._viewportReady) {
				return this[pname];
			} else {
				return this._viewport['get'+uname]();
			}
		},
		
		//////////////////////////////////////////////////////////////////////////////
		//  Interactor Properties
		//

		//
		//  pan: [markup] boolean
		//      enable or disable panning
		//
		pan: true,
		
		_setPanAttr: function( /*Boolean*/b) {
			if (!this._viewportReady) 
				// at creation time, interactors are initialized in the postCreate stage.
				// Since customSetter are called before postCreate(), skip it in this case.
				return; 
			var old = this._getPanAttr(); // use the getter as the interactor may have been configured directly
			if (old !== b) {
				this.pan = b;
				this._interactors.get('pan').setEnabled(b);
				this._firePropertyChanged('pan', old, b);
			}
			return this;
		},
		
		_getPanAttr: function() {
			return this._viewportReady ? this._interactors.get("pan").getEnabled() : true;
		},

		
		
		//
		//  pan: [markup] boolean
		//      enable or disable panning if clicking on shapes.
		//
		panOnShapes:false,
		
		_setPanOnShapesAttr: function( /*Boolean*/b) {
			if (!this._viewportReady) 
				// at creation time, interactors are initialized in the postCreate stage.
				// Since customSetter are called before postCreate(), skip it in this case.
				return;
			var old = this._getPanOnShapesAttr();
			if (old !== b) {
				this.panOnShapes = b;
				this._interactors.get("pan").setActOnShapes(b);
				this._firePropertyChanged('panOnShapes', old, b);
			}
			return this; 
		},
		
		_getPanOnShapesAttr: function( /*boolean*/b) {
			return this._viewportReady ? this._interactors.get("pan").getActOnShapes(b) : false;
		},
		
		
		
		
		//
		//  zoom: [markup] boolean
		//      enable or disable zooming
		//
		zoom: true,
		
		_setZoomAttr: function( /*Boolean*/b) {
			if (!this._viewportReady) 
				// at creation time, interactors are initialized in the postCreate stage.
				// Since customSetter are called before postCreate(), skip it in this case.
				return; 
			var old = this._getZoomAttr();
			if (old !== b) {
				this.zoom = b;
				this._interactors.get("zoom").setEnabled(b);
				this._firePropertyChanged('zoom', old, b);
			}
			return this;
		},
		
		_getZoomAttr: function() {
			return this._viewportReady ? this._interactors.get("zoom").getEnabled() : true;
		},
		
		
		
		
		//
		//  select: [markup] boolean
		//      enable or disable selecting entities
		//
		select: true,

		_setSelectAttr: function( /*Boolean*/b) {
			if (!this._viewportReady) 
				// at creation time, interactors are initialized in the postCreate stage.
				// Since customSetter are called before postCreate(), skip it in this case.
				return; 
			var old = this._getSelectAttr();
			if (old !== b) {
				this.select = b;
				this._interactors.get("select").setEnabled(b);
				this._firePropertyChanged('select', old, b);
			}
			return this;
		},
		_getSelectAttr: function() {
			return this._viewportReady ? this._interactors.get("select").getEnabled() : true;
		},
		
		
		//
		//  marquee: [markup] boolean
		//      enable or disable marquee selection
		//
		marquee: true,
		
		_setMarqueeAttr: function( /*Boolean*/b) {
			if(!_Diagram) return;
			if (!this._viewportReady) 
				// at creation time, interactors are initialized in the postCreate stage.
				// Since customSetter are called before postCreate(), skip it in this case.
				return; 
			var old = this._getMarqueeAttr();
			if (old !== b) {
				this.marquee = b;
				this._interactors.get("marquee").setEnabled(b);
				this._firePropertyChanged('marquee', old, b);
			}
			return this;
		},
		
		_getMarqueeAttr: function() {
			if(!_Diagram) return false;
			return this._viewportReady ? this._interactors.get("marquee").getEnabled() : true;
		},
		
		
		
		//
		//  wheelPan: [markup] boolean
		//      enable or disable scrolling with the mouse wheel (vertical panning)
		//
		wheelPan: true,
		
		_setWheelPanAttr: function( /*Boolean*/b) {
			if(!_Diagram) return;
			if (!this._viewportReady) 
				// at creation time, interactors are initialized in the postCreate stage.
				// Since customSetter are called before postCreate(), skip it in this case.
				return; 
			var old = this._getWheelPanAttr();
			if (old !== b) {
				this.wheelPan = b;
				this._interactors.get("wheelPan").setEnabled(b);
				this._firePropertyChanged('wheelPan', old, b);
			}
			return this;
		},
		
		_getWheelPanAttr: function() {
			if(!_Diagram) return false;
			return this._viewportReady ? this._interactors.get("wheelPan").getEnabled() : true;
		},
		
		
		
		//
		//	adorners: [markup] boolean
		//		enable or disable adorners focus following mouse pointer
		//
		adorners: true,
		
		_setNodeAdornersFocusAttr: function( /*Boolean*/b) {
			if(!_Diagram) return;
			if (!this._viewportReady) 
				// at creation time, interactors are initialized in the postCreate stage.
				// Since customSetter are called before postCreate(), skip it in this case.
				return; 
			var old = this._getNodeAdornersFocusAttr();
			if (old !== b) {
				this.adorners = b;
				this._interactors.get("adorners").setEnabled(b);
				this._firePropertyChanged('adorners', old, b);
			}
			return this;
		},
		
		_getNodeAdornersFocusAttr: function() {
			if(!_Diagram) return false;
			return this._viewportReady ? this._interactors.get("adorners").getEnabled() : true;
		},
		
		//
		//  moveFunction: Function
		//      This function is an optional callback to configure how the MoveInteractor applies the movement deltas on entities.
		//      function(graphElement,originalTransform,delta) {
		//          //  summary:
		//          //      Concrete the movement to a graph element.
		//          //  graphElement:
		//          //      The graph element to move.
		//          //  originalTransform:
		//          //      The matrix representing the location from which the delta is computed.
		//          //  delta:
		//          //      The ammount to translate the entity from its original location.
		//      },  
		//
		moveFunction: null,
		
		//
		//  isMovableFunction: Function
		//      This function is an optional callback to configure how the MoveInteractor tests movability of elements
		//      function(graphElement) {
		//          //  summary:
		//          //      Return true if the given graph element is allowed to move
		//          //  graphElement:
		//          //      The graph element to test.
		//      }
		//
		isMovableFunction: null,
		
		
		//////////////////////////////////////////////////////////////////////////////
		// Events properties
		
		//
		//  nodeMenu:
		//      An optional dijit.Menu for nodes (property)
		//
		nodeMenu: null,
		
		//
		//  linkMenu:
		//      An optional dijit.Menu for links (property)
		//
		linkMenu: null,
		
		//
		//  subgraphMenu:
		//      An optional dijit.Menu for subgraphs (property)
		//
		subgraphMenu: null,
		
		//
		//  backMenu:
		//      An optional dijit.Menu for the diagram background (property)
		//
		backMenu: null,
		
		//////////////////////////////////////////////////////////////////////////////
		// Styling Properties
		
		// nodeStyle: Object: 
		//     A dictionary of property-value pairs that define global properties to apply on nodes.
		//     Properties must obey the Java get/set naming convention in order to be taken into account (i.e.
		//     for a property 'myProperty', there must be a getMyProperty and a setMyProperty methods defined on
		//     the node).
		nodeStyle: null,
		
		_setNodeStyleAttr: function(value) {
			var old = this._created ? this.nodeStyle : null;
			this.nodeStyle = value;
			this._firePropertyChanged('nodeStyle', old, value);
			return this;
		},
		
		// linkStyle: Object: 
		//     A dictionary of property-value pairs that define global properties to apply on links.
		//     Properties must obey the Java get/set naming convention in order to be taken into account (i.e.
		//     for a property 'myProperty', there must be a getMyProperty and a setMyProperty methods defined on
		//     the node).
		linkStyle: null,
		
		_setLinkStyleAttr: function(value) {
			var old = this._created ? this.linkStyle : null;
			this.linkStyle = value;
			this._firePropertyChanged('linkStyle', old, value);
			return this;
		},
		
		// subgraphStyle: Object: 
		//     A dictionary of property-value pairs that define global properties to apply on subgraphs.
		//     Properties must obey the Java get/set naming convention in order to be taken into account (i.e.
		//     for a property 'myProperty', there must be a getMyProperty and a setMyProperty methods defined on
		//     the node).
		subgraphStyle: null,
		
		_setSubgraphStyleAttr: function(value) {
			var old = this._created ? this.subgraphStyle : null;
			this.subgraphStyle = value;
			this._firePropertyChanged('subgraphStyle', old, value);
			return this;
		},
		
		//////////////////////////////////////////////////////////////////////////////
		// Templating Properties
		
		_setTemplateField: function(field, template) {
			var _field = '_' + field;
			this[_field] = this[field] = template;
			if (template) {
				if (typeof(template) == "string" && template.length > 0) {
					// if no DTL, convert it to plain JS object to prevent useless costly parsing
					if (!template.match(/{{|{%/)) 
						this[_field] = json.fromJson(template);
				}
				if (!(this[_field] instanceof dtlbinding.GfxTemplate)) 
					this[_field] = new dtlbinding.GfxTemplate(this[_field]);
			}
		},
		
		// nodeTemplate: String:
		//    A description object that defines the graphical representation of nodes.
		nodeTemplate: '',
		
		_setNodeTemplateAttr: function(template) {
			var old = this._created ? this.nodeTemplate : '';
			this._setTemplateField('nodeTemplate', template);
			this._firePropertyChanged('nodeTemplate', old, template);
			return this;
		},
		
		// nodeTemplateFunction: Function
		//    an optional function that computes the node template based on the item.
		//    The function receives the following parameters:
		//    item : the data item to create node from
		//    diagram : a reference to this diagram widget.
		nodeTemplateFunction: null,
		
		// createNodeFunction: Function
		//    An optional function that creates the ibm_ilog.diagram.Node instance for a given data
		//    item.
		//    The function receives the following parameters:
		//    item : the data item associated with this node.
		//    templateObj : A template object.
		//    graph : the target graph to create the node from. 
		//    diagram : a reference to this diagram widget.
		createNodeFunction: null,
		
		
		// subgraphTemplate: String:
		//    A description object that defines the graphical representation of subgraphs.
		subgraphTemplate: '',
		
		_setSubgraphTemplateAttr: function(/*String||Object*/template) {
			var old = this._created ? this.subgraphTemplate : '';
			this._setTemplateField('subgraphTemplate', template);
			this._firePropertyChanged('subgraphTemplate', old, template);
			return this;
		},
		
		// subgraphTemplateFunction: Function
		//    an optional function that computes the subgraph template based on the item.
		//    The function receives the following parameters:
		//    item : the data item to create subgraph from.
		//    diagram : a reference to this diagram widget.
		subgraphTemplateFunction: null,
		
		// createSubgraphFunction: Function
		//    An optional function that creates the ibm_ilog.diagram.Subgraph instance for a given data
		//    item.
		//    The function receives the following parameters:
		//    item : associated with this node.
		//    templateObj : the template object.
		//    graph : the target graph to create the subgraph from.
		//    diagram : a reference to this diagram widget.
		createSubgraphFunction: null,
		
		// linkTemplate: String:
		//    A description object that defines the graphical representation of links.
		linkTemplate: '',
		
		_setLinkTemplateAttr: function(/*String||Object*/template) {
			var old = this._created ? this.linkTemplate : '';
			this._setTemplateField('linkTemplate', template);
			this._firePropertyChanged('linkTemplate', old, template);
			return this;
		},
		
		// linkTemplateFunction: Function
		//    an optional function that computes the link template dynamically based on the item.
		//    The function receives the following parameters:
		//    linkItem : the link data item, if any.
		//    startNode: the link start node.
		//    endNode: the link end node.
		//    diagram : a reference to this diagram widget.
		linkTemplateFunction: null,
		
		// createLinkFunction: Function
		//    An optional function that creates the ibm_ilog.diagram.Link instance for a given data
		//    item.  
		//    The function receives the following parameters:
		//    linkItem : the link data item, if any.
		//    startNode: the link start node.
		//    endNode: the link end node.
		//    templateObj : the template object.
		//    graph : the parent graph of the link.
		//    diagram : a reference to this diagram widget.
		createLinkFunction: null,
		
		
		//////////////////////////////////////////////////////////////////////////////
		// Graph GraphLayout Properties
		
		_initializeLayoutProps:function(){
			if (this.nodeLayout)
				this._setNodeLayoutAttr(this.nodeLayout);
			if (this.automaticNodeLayout)
				this._setAutomaticNodeLayoutAttr(this.automaticNodeLayout);
			if (!this.nodeLayoutActive)
				this._setNodeLayoutActiveAttr(this.nodeLayoutActive);
			if (this.linkLayout)
				this._setLinkLayoutAttr(this.linkLayout);
			if (this.automaticLinkLayout)
				this._setAutomaticLinkLayoutAttr(this.automaticLinkLayout);
			if (!this.linkLayoutActive)
				this._setLinkLayoutActiveAttr(this.linkLayoutActive);
		},
		
		// summary: ibm_ilog.graphlayout.GraphLayout :
		//    The graph layout algorithm that will be executed on the nodes of this diagram.
		nodeLayout: null,
		
		_setNodeLayoutAttr: function(/*ibm_ilog.graphlayout.GraphLayout*/layout) {
			if (!this._viewportReady)
				return; 
			var old = this._graph.getNodeLayout();
			if (old !== layout) {
				this.nodeLayout = layout;
				this._graph.setNodeLayout(layout);
				this._firePropertyChanged('nodeLayout', old, layout);
			}
			return this;
		},
		
		_getNodeLayoutAttr: function() {
			return this._viewportReady ? this._graph.getNodeLayout() : null;
		},
		
		//		Determines if the node layout must be executed automatically
		//		whenever the graph changes.
		automaticNodeLayout: false,
		
		_setAutomaticNodeLayoutAttr: function(/*boolean*/automatic) {
			if (!this._viewportReady)
				return; 
			var old = this._graph.isAutomaticNodeLayout();
			if (old !== automatic) {
				this.automaticNodeLayout = automatic;
				this._graph.setAutomaticNodeLayout(automatic);
				this._firePropertyChanged('automaticNodeLayout', old, automatic);
			}
			return this;
		},
		
		_getAutomaticNodeLayoutAttr: function() {
			return this._viewportReady ? this._graph.isAutomaticNodeLayout() : false;
		},
		
		// summary:
		//		Activates or deactivates the graph layout specified by setNodeLayout().
		nodeLayoutActive:true,
		
		_setNodeLayoutActiveAttr: function(/*boolean*/active) {
			if (!this._viewportReady)
				return; 
			var old = this._graph.isNodeLayoutActive();
			if (old !== active){
				this.nodeLayoutActive = active;
				this._graph.setNodeLayoutActive(active);
				this._firePropertyChanged('nodeLayoutActive', old, active);
			}
			return this;
		},
		
		_getNodeLayoutActiveAttr: function() {
			return this._viewportReady ? this._graph.isNodeLayoutActive() : true;
		},
		
		// summary: ibm_ilog.graphlayout.GraphLayout :
		//    The graph layout algorithm that will be executed on the links of this diagram.
		linkLayout: null,
				
		_setLinkLayoutAttr: function(/*ibm_ilog.graphlayout.GraphLayout*/layout) {
			if (!this._viewportReady)
				return; 
			var old = this._graph.getLinkLayout();
			if (old !== layout) {
				this.linkLayout = layout;
				this._graph.setLinkLayout(layout);
				this._firePropertyChanged('linkLayout', old, layout);
			}
			return this;
		},

		_getLinkLayoutAttr: function() {
			return this._viewportReady ? this._graph.getLinkLayout() : null;
		},

		//		Determines if the link layout must be executed automatically
		//		whenever the graph changes.
		automaticLinkLayout: false,
		
		_setAutomaticLinkLayoutAttr: function(/*boolean*/automatic) {
			if (!this._viewportReady)
				return; 
			var old = this._graph.isAutomaticLinkLayout();
			if (old !== automatic) {
				this.automaticLinkLayout = automatic;
				this._graph.setAutomaticLinkLayout(automatic);
				this._firePropertyChanged('automaticLinkLayout', old, automatic);
			}
			return this;
		},
		
		_getAutomaticLinkLayoutAttr: function() {
			return this._viewportReady ? this._graph.isAutomaticLinkLayout() : false;
		},
		
		// summary:
		//		Activates or deactivates the link layout specified by setLinkLayout().
		linkLayoutActive: true,
		
		_setLinkLayoutActiveAttr: function(/*boolean*/active) {
			if (!this._viewportReady)
				return; 
			var old = this._graph.isLinkLayoutActive();
			if (old !== active) {
				this.linkLayoutActive = active;
				this._graph.setLinkLayoutActive(active);
				this._firePropertyChanged('linkLayoutActive', old, active);
			}
			return this;
		},
		
		_getLinkLayoutActiveAttr: function() {
			return this._viewportReady ? this._graph.isLinkLayoutActive() : true;
		},
		
		// END OF PROPERTIES
		// =======================================================================
		
		
		// =======================================================================
		//
		// WIDGET LIFECYCLE:
		//
		//  The following group methods define the process of construction, initialization, deinitialization and 
		//  related. These are mostly hooks into the Dijit framework.
		//
		
		_connections: null,
		_subscriptions: null,
		
		constructor: function() {
			this._connections = [];
			this._subscriptions = [];
		},
		
		postMixInProperties: function() {
			this.inherited(arguments);
			
			this._beginInit();
			
			// Create Viewport, which defines the templateString to use.
			this._createViewport();
			
			// Create Selection object
			this._createSelection();
			
			// register node events
			this._initializeNodeEvents();
			
			// initialize annotations infrastructure
			this._initializeAnnotations();
			
			// initialize adorner infrastructure
			this._initializeAdorners();

			// create interactor manager
			this._interactors = new InteractorManager();

		},
		
		postCreate: function() {
		
			this.inherited(arguments);
			
			this._initializeViewport();

			this.getViewport().whenLoaded(lang.hitch(this, function() {
				if (this["backMenu"]) {
					try {
						var thiz = this;
						this._viewport.getEventSourceBackground().connect("oncontextmenu", function(e) {
							thiz.lastMenuTarget = thiz._graph;
							thiz.lastMenuEvent = e;
						});
						this["backMenu"].bindDomNode(this._viewport.getEventSourceBackground().getEventSource());
					} catch (e) {
						R.warn("EventConnectionFailed", "oncontextmenu");
					}
				}
				
				this._graph = this.getViewport().getContent().createGraph();
				this._graph._diagram = this;
				if (config.isBidiInDojoDiagrammer)
				    this._graph.textDir = this.textDir;							
				
				if (!this.disableGraphWai) {
					this._initializeGraphWai();
				} else {
					this.set('tabIndex','0');
				}
				
				this._connections.push(connect.connect(this._graph, "onLayoutAnimationStart", this, function() {
					this._viewport.setRefreshContentsSuspended(true);
				}));
				
				this._connections.push(connect.connect(this._graph, "onLayoutAnimationEnd", this, function() {
					this._viewport.setRefreshContentsSuspended(false);
				}));
				
				this._viewportReady = true;
				
				// initialize viewport properties
				this._initializeViewportProperties();
				
				// initialize graph graphlayout properties
				this._initializeLayoutProps();
				
				// initialize interactors
				this._initializeInteractors();
				
				// initialize key interactors
				this._initializeKeyInteractors();
				
				this.enterStandardMode();
				
				// If there was a nodeStore defined on the widget then draw     
				if (this.loadOnCreate && this._getNodesStore()) {
					this.load();
				}
				
				this.postPostCreate();
				
				this._endInit();
			}));
		},
		
		postPostCreate: function() {
			//  summary:
			//      Hook executed just after Diagram postCreate. Used by DiagramEditor subclass.
		},
		
		
		onLoaded: function() {
			//  summary:
			//      Invoked when the diagram has loaded the data. 
		},
		
		resize: function(info) {
		  var doResize = true;
			// No size info passed: use the widget's marginBox
			if(!info || !info.w || !info.h || info.w <= 0 || info.h <= 0){ 
			  info = domgeo.getMarginBox(this.domNode);
			  doResize = false;
			}
			
			// We get negative sizes sometimes... (e.g. on Chrome/Canvas)
			if (!info || !info.w || !info.h || info.w <= 0 || info.h <= 0) 				
  	  	return;
	    
			// We get _viewport.getSurface() being null sometimes... (e.g. on IE8)
			if (this._viewport.getSurface()) {
				this._viewport.setSize({
					width: info.w,
					height: info.h
				},doResize);
			}
		},
		
		destroy: function() {
		
			if (this._interactors) {
				this._interactors.switchTo();
			}
			
			array.forEach(this._connections, connect.disconnect, dojo);
			
			array.forEach(this._subscriptions, connect.unsubscribe, dojo);
			
			this._destroyDataConnector();

			if (this._graph) {
				this._graph.clear(true); // true = call dispose() on children
			}
			this._graph = null;
			
			if (this._viewport) {
				this._viewport.destroy();
			}
			
			this.inherited(arguments);
		},
		
		reset: function() {
			// clear the selection
			this.getSelection().clear();
			// reset the dataconnector and the associated graphical shapes created from the stores
			this._reset();
			
			// clear any remaining shapes (those not created from datastores)
			this._graph.clear(/*dispose*/true);
			
			// Defect 1875
			// The layout instances do cleanup work when notified that the content of the
			// graph has changed. Hence, let's notify the layout:
			var nodeLayout = this._graph.getNodeLayout();
			var linkLayout = this._graph.getLinkLayout();
			var graphModelEvent = null;
			if (nodeLayout || linkLayout) {
				// We do not need a dojo.require for GraphLayoutModelEvent, because this is 
				// required by GraphLayout itself. Hence, if a layout instance is already
				// set on the graph, the event class has already been required.
				var GraphLayoutModelEvent = require("ibm_ilog/graphlayout/GraphLayoutModelEvent"); 
				graphModelEvent = new GraphLayoutModelEvent();
				graphModelEvent.setType(GraphLayoutModelEvent.STRUCTURE_CHANGED);
			}
			if (nodeLayout)
				nodeLayout.contentsChanged(graphModelEvent);
		  if (linkLayout)
				linkLayout.contentsChanged(graphModelEvent);
				
			this._viewport.reset();
			this.enterStandardMode();
			
			return this;
		},
		
		
		// =======================================================================
		//
		//	WAI-ARIA / A11Y
		//
		
		// moved to _Diagram.js
		
		disableGraphWai: true,

		// =======================================================================
		//
		//  VIEWPORT:
		//
		//      The viewport is an abstraction used to control the currently visualized area of the model.
		//
		//      see:
		//      widget.Viewport, widget.DivViewport
		//
		//
		
		//
		//  _viewport: ibm_ilog.diagram.widget.Viewport
		//      The viewport
		//
		_viewport: null,
		
		getViewport: function() {
			// summary:
			//     Gets the Viewport instance.
			return this._viewport;
		},
		
		visualizeBounds: function( /*Node|Link|Subgraph*/graphic, /*{expandCurrent:false,airFactor}*/ options) {
			//
			//	summary:
			//		Makes the bounds of a graph object visible, givin it an extra air between the 
			//		area and the borders of the viewport if possible. The view may be zoomed out 
			//		if required, but it is never zoomed in.
			//
			//	graphic:
			//		The object to make visible
			//
			//	options:
			//		Viewport options kwArgs
			//
			var b = graphic.getBounds(this.getGraph());
			if (!b) {
				return;
			}
			this._viewport.visualizeArea(b, options);
		},
		
		centerOnNode: function( /*Node|Link*/nodeOrLink, /*{animate}*/ options) {
			//
			//	summary:
			//		Centers the viewport on an object of the graph. Does not change the zoom level.
			//
			nodeOrLink = this.asGraphElement(nodeOrLink);
			var b = nodeOrLink.getBounds(this.getGraph());
			if (!b) 
				return;
			if (nodeOrLink._isIBMDiagramNode) {
				this._viewport.centerAt(g.getRectCenter(b), options);
			} else {
				if (nodeOrLink._isIBMDiagramLink) {
					//
					//	TODO: temporary, correct this when it's ready
					//
					this._viewport.centerAt(g.getRectCenter(b), options);
				}
			}
			
		},
		
		_createViewport: function() {
			//
			//	Creates the Viewport object
			//
			//	tags:
			//		private
			//
			
			// if an exotic viewport class is specified, we assume it is already loaded so a simple require should get it.
			this._viewport = new (this.viewportClass == "DivViewport" ? DivViewport : require("./"+this.viewportClass))();
			this.templateString = this._viewport.templateString();
			
			
		},
		
		buildRendering: function(){
			// there are no variables in the template so we can cache the DOM tree
			var node = domctr.toDom(this.templateString);
			if(node.nodeType != 1){
				throw new Error("Invalid template: " + this.templateString);
			}
			this.domNode = node;
			var nodes = node.getElementsByTagName("*");
			for (var i = -1; i < nodes.length; i++){
				var n = (i == -1) ? node : nodes[i];
				var attachPoint = n.getAttribute("dojoAttachPoint");
				if (attachPoint == 'canvasNode') {
					domstyle.set(n, "overflow", 'hidden');
				}
				this[attachPoint]= n;
			}
			
			//this.inherited(arguments);
			
			this._fillContent(this.srcNodeRef);
			
		},
		
		_fillContent: function(/*DomNode*/ source){
			// summary:
			//		Relocate source contents to templated container node.
			//		this.containerNode must be able to receive children, or exceptions will be thrown.
			// tags:
			//		protected
			var dest = this.containerNode;
			if(source && dest){
				while(source.hasChildNodes()){
					dest.appendChild(source.firstChild);
				}
			}
		},
		
		
		_initializeViewport: function() {
			//
			//	Creates the Viewport object
			//
			//	tags:
			//		private
			//
			this._viewport.initialize(this);
			
			this._viewport.setAirFactor(this.viewportAirFactor);
			this._viewport.setAnimated(this.viewportAnimated);
			this._viewport.setMaxZoom(this.viewportMaxZoom);
			this._viewport.setMinZoom(this.viewportMinZoom);
			this._viewport.setResizeMode(this.viewportResizeMode);
			
		},
		
		createAdorner: function(clazz, templates, rootId) {
			var a = this._adornerLayer.createObject(clazz);
			a.initialize(this, templates, rootId);
			return a;
		},
		
		destroyAdorner: function(a) {
			a.destroy();
			a.getParent().remove(a);
		},
		
	  fitToContents: function(margin, zoomOutOnly) {
	    this.getGraph().fitToContents(margin, zoomOutOnly);
	  },
	  
		// =======================================================================
		//
		// INTERACTORS:
		//
		//		An interactor is an abstraction of a user interface process. Each interactor controls some kind
		//		process. It is responsible for making it available and has all the UI logic pertinent to it.
		//
		//		The interactors are managed by an InteractionManager, which organizes them by id and is responible
		//		for distinguishing the currently active interactors.
		//
		//		The diagram widget uses interactors to provide the users with ways to interact with the Graph
		//		surface. It uses a PanInteractor to provide the user with a mode in which the surface
		//		can be navigating by grabbing it with the left mouse button and zoomed using the mouse wheel.
		//		It also uses a SelectionInteractor to provide the user the ability of selecting nodes by 
		//		left-clicking them.
		//
		//		see:
		//		event.Interactor, event.PanInteractor, event.SelectionInteractor, event.InteractorManager
		//
		
		//
		//	_interactors: ibm_ilog.diagram.interactors.InteractorManager
		//		The interactor manager
		//
		_interactors: null,
		
		
		_setupInteractors: function(ids) {
			array.forEach(ids, function(i) {
				this._interactors.get(i).setEnabled(this[i]);
			}, this);
		},
		
		_initializeInteractors: function() {
			//
			//	summary:
			//		Initializes the interactors used by the Diagram
			//
			//	tags:
			//		protected
			//
			
			this._interactors.add("pan", new PanInteractor().initialize(this));
			this._interactors.add("select", new SelectionInteractor().initialize(this._graph, this.getSelection(), this._viewport.getBackgroundShape()));
			this._interactors.add("zoom", new ZoomInteractor().initialize(this));
			
			this._setupInteractors(["pan", "select", "zoom"]);
		},
		
		startup: function() {
			this.inherited(arguments);
			
			//	[av] adorner creation fails on certain renderers/browsers if this is done before "startup".
			//this._createAdorners();
			this._viewport.whenLoaded(lang.hitch(this, this._createAdorners));
			
			this._loadAnnotations();
		},
		
		getInteractor: function(id) {
			return this._interactors.get(id);
		},
		
		getInteractorManager: function() {
			return this._interactors;
		},

		enterStandardMode: function() {
			//
			//	summary:
			//		TODO TBD. Probably to be renamed also
			//    	
			this._interactors.switchTo("pan", "select", "zoom");
		},
		
		assignInteractorInputs: function(iid, assignments) {
			this.getInteractor(iid).assignInputs(assignments);
		},
		
		setMarqueeMode: function( /*int*/b) {
			this._interactors.get("marquee").setMode(b);
		},
		
		enableMarqueePartialSelection: function( /*boolean*/b) {
			this._interactors.get("marquee").setPartialSelectionEnabled(b);
		},

		// =======================================================================
		//
		// KEY INTERACTORS:
		//
		
		// moved to _Diagram.js
		
		_initializeKeyInteractors: function() {
		},
		
		// =======================================================================
		//
		//	GRAPH MOUSE EVENTS:
		//
		//		The user can connect to input events related to entities through the events defined in this 
		//		section. These are mapped to the corresponding DOM events when they occur on the corresponding
		//		entity (Node or Link).
		//
		
		onNodeContextMenu: function(n, e) {
			this.lastMenuTarget = n;
			this.lastMenuEvent = e;
		},
		onNodeClick: _emptyEntityHandler,
		onNodeDblClick: _emptyEntityHandler,
		onNodeMouseUp: _emptyEntityHandler,
		onNodeMouseDown: _emptyEntityHandler,
		onNodeMouseMove: _emptyEntityHandler,
		onNodeMouseEnter: _emptyEntityHandler,
		onNodeMouseLeave: _emptyEntityHandler,
		onNodeMouseOver: _emptyEntityHandler,
		onNodeMouseOut: _emptyEntityHandler,
		// Touch events for Node
		onNodeTouchStart: function (ge,event){
			this.onNodeMouseDown(ge,event);
		},
		onNodeTouchEnd: function (ge,event){
			this.onNodeMouseUp(ge,event);
			this.onNodeClick(ge,event);
			if(event.touches.length == 0){
				var delay = new Date().getTime() - this._lastUp;
				if(this._lastUp && (delay < 500)){
					this.onNodeDblClick(ge,event);
					delete this._lastUp;
				}else{
					this._lastUp = new Date().getTime();
				}   
			}			
		},
		onNodeTouchMove: function (ge,event){
			this.onNodeMouseMove(ge,event);
		},
		
		onLinkContextMenu: function(l, e) {
			this.lastMenuTarget = l;
			this.lastMenuEvent = e;
		},
		onLinkClick: _emptyEntityHandler,
		onLinkDblClick: _emptyEntityHandler,
		onLinkMouseUp: _emptyEntityHandler,
		onLinkMouseDown: _emptyEntityHandler,
		onLinkMouseMove: _emptyEntityHandler,
		onLinkMouseEnter: _emptyEntityHandler,
		onLinkMouseLeave: _emptyEntityHandler,
		onLinkMouseOver: _emptyEntityHandler,
		onLinkMouseOut: _emptyEntityHandler,
		
		// Touch events for Link
    onLinkTouchStart: function (ge,event){
      this.onLinkMouseDown(ge,event);
    },
    onLinkTouchEnd: function (ge,event){
        this.onLinkMouseUp(ge,event);
        this.onLinkClick(ge,event);
        if(event.touches.length == 0){
            var delay = new Date().getTime() - this._lastUp;
            if(this._lastUp && (delay < 500)){
                this.onLinkDblClick(ge,event);
                delete this._lastUp;
            }else{
                this._lastUp = new Date().getTime();
            }   
        }           
    },
    onLinkTouchMove: function (ge,event){
        this.onLinkMouseMove(ge,event);
    },
  
		
		onSubgraphContextMenu: function(s, e) {
			this.lastMenuTarget = s;
			this.lastMenuEvent = e;
		},
		onSubgraphClick: _emptyEntityHandler,
		onSubgraphDblClick: _emptyEntityHandler,
		onSubgraphMouseUp: _emptyEntityHandler,
		onSubgraphMouseDown: _emptyEntityHandler,
		onSubgraphMouseMove: _emptyEntityHandler,
		onSubgraphMouseEnter: _emptyEntityHandler,
		onSubgraphMouseLeave: _emptyEntityHandler,
		onSubgraphMouseOver: _emptyEntityHandler,
		onSubgraphMouseOut: _emptyEntityHandler,

    // Touch events for subGraph
    onSubgraphTouchStart: function (ge,event){
      this.onSubgraphMouseDown(ge,event);
    },
    onSubgraphTouchEnd: function (ge,event){
        this.onSubgraphMouseUp(ge,event);
        this.onSubgraphClick(ge,event);
        if(event.touches.length == 0){
            var delay = new Date().getTime() - this._lastUp;
            if(this._lastUp && (delay < 500)){
                this.onSubgraphDblClick(ge,event);
                delete this._lastUp;
            }else{
                this._lastUp = new Date().getTime();
            }   
        }           
    },
    onSubgraphTouchMove: function (ge,event){
        this.onSubgraphMouseMove(ge,event);
    },
  
        
		
		//
		//	lastMenuTarget:
		//		The entity on which the last/current menu was opened.
		//
		lastMenuTarget: null,
		
		//
		//	linkMenu:
		//		An optional dijit.Menu for links (property)
		//
		_initializeNodeEvents: function() {
			//
			// TODO analyze and maybe replace this connection method by
			// the deferred method used in _Widget.
			//
			// May also be replaced by a single connection plus a linear search on the geometry.
			//
			//	tags:
			//		private
			//
			
			var eventNames = ["ContextMenu", "Click", "DblClick", "MouseUp", "MouseDown", "MouseMove", "MouseEnter", "MouseLeave", "MouseOver", "MouseOut"];
			if (iid.mobileEnabled){
				eventNames.push("TouchStart","TouchMove","TouchEnd");
			}
			var lcEventNames = array.map(eventNames, function(e) {
				return e.toLowerCase();
			});
			
			var self = this;
			
			// Connect to node events
			
			array.forEach(["Node", "Link", "Subgraph"], function(get) {
				var lget = get.toLowerCase();
				var evtPrefix = "on" + get;
				var menuName = lget + "Menu";
				this._connections.push(connect.connect(this, "_on" + get + "Created", this, function(ge) {
					for (var i = 0; i < eventNames.length; i++) {
						(function() {
							var eventName = evtPrefix + eventNames[i];
							try {
								ge.connect("on" + lcEventNames[i], self, function(e) {
									return (this[eventName])(ge, e);
								});
							} catch (e) {
								R.warn("EventConnectionFailed", "on" + lcEventNames[i]);
							}
						})();
					}
					if (this[menuName]) {
						try {
							this[menuName].bindDomNode(ge.getEventSource());
						} catch(e){}
					}
				}));
				
			}, this);
			
			this._subscriptions.push(connect.subscribe('/ibm_diagram/GraphElement/beforeDisposing', this, function(graphElement) {
				this.beforeGraphElementDispose(graphElement);
			}));
			
			this._subscriptions.push(connect.subscribe('/ibm_diagram/GraphElement/afterDisposing', this, function(graphElement) {
				this.afterGraphElementDispose(graphElement);
			}));
			
		},
		
		beforeGraphElementDispose: function(graphElement) {
			//
			//	summary:
			//		this method is called before any graph element is disposed
		},
		
		afterGraphElementDispose: function(graphElement) {
			//
			//	summary:
			//		this method is called after any graph element is disposed
		},
		
		// =======================================================================
		//
		//	SELECTION:
		//
		//		The interface to the currently selected nodes/dataitems.
		//
		//		see:
		//		widget.SelectionInteractor, widget.Selection
		//
		//
		
		
		//
		//	_selection: ibm_ilog.diagram.Selection
		//		The selection object
		//
		_selection: null,
		
		getSelection: function() {
			//
			//	summary:
			//		Return the selection object
			//    	
			return this._selection;
		},
		
		// bindable property that defines the selection mode
		// See: ibm_diagram_Selection
		selectionMode: null,
		
		_createSelection: function() {
			//
			//	summary:
			//		Creates the selection object
			//    	
			if (this.selectionMode == null) {
				this.selectionMode = Selection.standard;
			}
			this._selection = new Selection(this);
			
		},
		
		
		// =======================================================================
		//
		//	ADORNERS FOCUS:
		//
		//		The interface to manage focus on an entity for operation
		//
		//		see:
		//		widget.AdornerFocusInteractor
		//
		//

		//
		//  _nodeAdornersFocus: ibm_ilog.diagram.Node|ibm_ilog.diagram.Subgraph
		//      The currently adorner-focused node/subgraph 
		//
		_nodeAdornersFocus: null,

		//
		//	getAssociatedNodeAdornersFunction:
		//		User-customizable function which must return the adorners associated with the adorner focus on the given node.
		//
		getAssociatedNodeAdornersFunction: function(node) {
			return [];
		},
		
		//
		//	getAssociatedLinkAdornersFunction:
		//		User-customizable function which must return the adorners associated with the adorner focus on the given link.
		//
		getAssociatedLinkAdornersFunction: function(link) {
			return [];
		},

		//
		//	getAssociatedSubgraphAdornersFunction:
		//		User-customizable function which must return the adorners associated with the adorner focus on the given subgraph.
		//
		getAssociatedSubgraphAdornersFunction: function(sg) {
			return [];
		},

		getNodeAdornersFocus: function() {
			//
			//	summary:
			//		Returns the current node adorners focus.
			//			
			return this._nodeAdornersFocus;
		},
		
		setNodeAdornersFocus: function(ge) {
			//
			//	summary:
			//		Sets the node adorners focus on a graph element. Used by the adorners focus interactor;
			//			
			var oldValue = this._nodeAdornersFocus;
			this._nodeAdornersFocus = ge;
			if (oldValue != ge) {
				this.onNodeAdornersFocusChanged(oldValue, ge);
			}
			return this;
		},
		
		onNodeAdornersFocusChanged: function(oldValue, newValue) {
			//
			//	summary:
			//		event that occurs when the adorners focus has changed.
			//			
			var adorners = [];
			if(newValue) {
				if(newValue._isIBMDiagramSubgraph) {
					adorners = this.getAssociatedSubgraphAdornersFunction(newValue);
				} else {
					adorners = this.getAssociatedNodeAdornersFunction(newValue);
				}
			}
			array.forEach(this._activeNodeAdorners,function(g){
				g.setAdorned(null);
			},this);
			
			this._activeNodeAdorners = adorners;

			array.forEach(this._activeNodeAdorners,function(g){
				g.setAdorned(newValue);
			},this);
		},

		
		//
		//  _nodeAdornersFocus: ibm_ilog.diagram.Link
		//      The currently adorner-focused link 
		//
		_linkAdornersFocus: null,
		
		getLinkAdornersFocus: function() {
			//
			//	summary:
			//		Returns the current link adorners focus.
			//			
			return this._linkAdornersFocus;
		},
		
		setLinkAdornersFocus: function(ge) {
			//
			//	summary:
			//		Sets the link adorners focus on a graph element. Used by the adorners focus interactor;
			//			
			var oldValue = this._linkAdornersFocus;
			this._linkAdornersFocus = ge;
			if (oldValue != ge) {
				this.onLinkAdornersFocusChanged(oldValue, ge);
			}
			return this;
		},
		onLinkAdornersFocusChanged: function(oldValue, newValue) {
			//
			//	summary:
			//		event that occurs when the link adorners focus has changed.
			//			
			var adorners = []; 
			if(newValue) {
				adorners = this.getAssociatedLinkAdornersFunction(newValue);
			}
			
			array.forEach(this._activeLinkAdorners,function(g){
				g.setAdorned(null);
			},this);
			
			this._activeLinkAdorners = adorners;

			array.forEach(this._activeLinkAdorners,function(g){
				g.setAdorned(newValue);
			},this);
		},

		mustFreeAdornersFocus: function(graphElement, point, margin, outOfBounds) {
			// Summary:
			//		This function is called from the adorners focus interactor to decide whether to free the adorners focus or not.
			
			// This special case is added to be able to modify intermediate point on spline links
			if (outOfBounds && graphElement._isIBMDiagramLink && graphElement.isSelected() && graphElement.getCurveTension() > 0) {
				return false;
			}
			return outOfBounds;
		},
		
		changeAdornersFocus: function(focus, newFocus, possibleCursors, mustchangeAdornersFocus) {
			// Summary:
			//		This function is called from the adorners focus interactor to decide whether to change the adorners focus or not.
			// return: 
			//		the new gfx to apply the cursor, or null if not need to change. 	
			if (mustchangeAdornersFocus) {
				return newFocus;
			} else {
				return null;
			}
		},
		
		// _lowCpuMode: Enables the use of some low cpu consuming functions.
		// Be aware that some of them have less precision than the high cpu consumption.
		_lowCpuMode: false,
		
		isLowCpuMode: function() {
			//	Summary:
			//		return true if the low cpu mode is enabled
			//
			return this._lowCpuMode;
		},
		
		
		enableLowCpuMode: function(enable) {
			//	Summary:
			//		enables or disables the low cpu mode
			//
			this._lowCpuMode = enable;
			this.lowCpuModeChanged();
		},
		
		lowCpuModeChanged: function() {
			//	Summary:
			//		this function is called when the low cpu mode is changed
			//
		},

		// =======================================================================
		//
		//	Adorners
		//

		// moved to _Diagram.js
		
		_initializeAdorners: function() {
		},
		
		_createAdorners: function() {
		},
		
		// =======================================================================
		//
		//	FOCUSED ELEMENT:
		//
		//		The interface to manage focus on an entity for operation and navigation
		//
		//		see:
		//		widget.FocusInteractor
		//
		//

		focus: true,

		//
		//  _focusedElement: /*GraphElement*/
		//      The graph element currently focused
		//
		_focusedElement: null,
		
		_focusedNodeAdorner: null,
		
		_focusedLinkAdorner: null,

		_currentFocusAdorner: null,
		
		getFocusedElement: function() {
			return this._focusedElement;
		},
		
		getFocusAdorner: function(ge) {
			var node = this._focusedNodeAdorner;
			var link = this._focusedLinkAdorner;
			
			return {N:node,S:node,L:link}[ge.TID];
		},
		
		setFocusedElement: function(ge) {
			var oldValue = this._focusedElement;
			this._focusedElement = ge;
			
			var adorner = null;
			if(ge) {
				adorner = this.getFocusAdorner(ge);
			}
			
			if (adorner) {
				adorner.setAdorned(ge);
			}
			if(adorner!=this._currentFocusAdorner && this._currentFocusAdorner) {
				this._currentFocusAdorner.setAdorned(null);
			}
			this._currentFocusAdorner = adorner;
			
			if (oldValue != ge) {
				this.onFocusedElementChanged(oldValue, ge);
			}
			
			// [av] make sure we get focus when user clicks the diagram.
			// the standard capture is hidden because the only element with
			// tabIndex 0 may be hidden under several layers.
			this._htmlRefocus();

			return this;
		},
		
		onFocusedElementChanged: function(oldValue, newValue) {
		},
		
		// =======================================================================
		//
		//	Layout
		//
		
		
		performGraphLayout: function() {
		// summary:
		//		Executes the graph layout and/or the link layout specified by the setNodeLayout()
		//		and setLinkLayout methods.
		// description:
		//		If a non-null graph layout has been specified by calling setNodeLayout(),
		//		and if the graph layout is active (that is, unless setNodeLayoutActive(false) has been called),
		//		then the graph layout algorithm is performed on the contents of this graph.
		//		Then, if a non-null link layout has been specified by calling setLinkLayout(),
		//		and if the link layout is active (that is, unless setLinkLayoutActive(false) has been called),
		//		then the link layout algorithm is performed on the contents of this graph.
			
			this._graph.performGraphLayout();
		},
		
		//
		// Input Events
		//
		
		// =======================================================================
		//
		//	DATA CONNECTION:
		//
		//		The interface to manage attributes related to the node and links data stores
		//
		//		see:
		//		widget.DataConnector
		//
		// =======================================================================
		
		load: function() {
			// summary: 
			//        loads the data stores and creates the diagram.
			
			// Temporary
			this._load();
		},
		
		// =======================================================================
		
		//
		// Templating
		//    
		
		_nodeTemplate: null,
		_subgraphTemplate: null,
		_linkTemplate: null,
		
		createTemplatedShape: function(/*Function*/shapeType, /*String||Object?*/template, /*ibm_ilog.diagram.Graph?*/onGraph, /*Object?*/style, /*dojo.data.api.Read?*/store, /*Object?*/item) {
			// summary:
			// 		Creates an instance of the specified type fully initialized.
			// description:
			//     This method creates an instance of the specified type and populates it with the specified template.
			//     If the template defines bindings to the shape or the data item (if any), bindings are resolved.
			// shapeType: Function
			//		The type of the instance.
			// template: String||Object
			//    a template defining the shape contents. If no template is specified, the default Subgraph template will be used. Optional.
			// onGraph: ibm_ilog.diagram.Graph
			//    the parent graph. Optional.
			// store : dojo.data.api.Read
			//	a data store. Optional.
			// item: dojo.data.api.Item:
			//    a data item associated with this shape. Optional.
			
			onGraph = onGraph || this._graph;
			// Creates the node instance
			var shape = onGraph.createObject(shapeType);
			// Set the data context
			if (store && item) {
				shape.setData(new dtlbinding.DataContext(item, store));
			}
			// apply the style
			if (style) {
				_style.applyTo(style, shape);
			}
			// Apply the template (and resolve bindings, if any)
			onGraph._applyTemplate(shape, template, null, null);
			return shape;
		},
		
		_resolveTemplate: function(func, prop, def) {
			var template = null;
			// is there a function to return a template ?
			if (func) {
				// Should return a String to enable DTL engine. An Object means no binding.
				template = func();
			}
			if (!template) {
				// let's try the property 
				template = prop;
			}
			if (!template) {
				//let's use the default one
				template = def;
			}
			return template;
		},
		
		// a private hook to use for internal notification, as the public onNodeCreated
		// might be changed by the user *after* the widget initialization (in this case,
		// the internal "dojo.connect('onNodeCreated')" would listen the old method.
		_onNodeCreated: function(node, diagram) {
			this.onNodeCreated(node, diagram);
		},
		
		onNodeCreated: function(node, diagram) {
			// summary:
			//    Invoked when the specified node has been created.
			// node: ibm_ilog.diagram.Node: the new node instance.
			// diagram: ibm_ilog.diagram.widget.Diagram: the diagram instance that fired the event.
		},
		
		resolveNodeTemplate: function(/*dojo.data.Item*/item) {
			// summary:
			//    Returns the template to represent the specified node item.
			//    item: dojo.data.Item: the node data item.
			
			var func = this.nodeTemplateFunction ? lang.partial(this.nodeTemplateFunction, item, this) : null;
			return this._resolveTemplate(func, this._nodeTemplate, Node.defaultTemplate);
		},
		
		createNode: function(/*Object or String*/template, /*dojo.data.api.Item*/ item, /*ibm_ilog.diagram.Graph*/ onGraph, /*Function?*/ nodeType) {
			// summary:
			//        Creates a Node that represents the specified data item.
			// template: Object or String 
			//		The template to use for this node. Optional.
			// item: dojo.data.api.Item 
			//		a data item associated with this node. Optional.
			// onGraph: ibm_ilog.diagram.Graph 
			//		The parent graph of the node. If null, the top-level graph is used. Optional.
			// nodeType: Function
			//		The type of the node instance. Optional.
			// returns:
			//        A ibm_ilog.diagram.Node instance.
			
			
			if (!onGraph) {
				onGraph = this._graph;
			}
			
			template = template || this.resolveNodeTemplate(item);
			
			var node = null;
			// let's try a custom node factory
			if (this.createNodeFunction) {
				node = this.createNodeFunction.call(null, item, template, onGraph, this);
				if (node && (!(node._isIBMDiagramNode))) {
					R.error("UnexpectedReturnValueType", this, createNodeFunction, "ibm_diagam.Node", typeof(node));
				}
				
			}
			if (!node) {
				nodeType = nodeType || Node;
				node = this.createTemplatedShape(nodeType, template, onGraph, this.nodeStyle, this.nodesStore, item);
			}
			
			// set Label property
			if (item) {
				
				var text = StoreApi.getLabel(this.nodesStore, item);
				if (text) {
					node.setLabel(text);
				}
				
			}
			
			// TODO: should we pass the store and item ? 
			this._onNodeCreated(node, this);
			
			return node;
		},
		
		// a private hook to use for internal notification, as the public onNodeCreated
		// might be changed by the user *after* the widget initialization (in this case,
		// the internal "dojo.connect('onNodeCreated')" would listen the old method.
		_onSubgraphCreated: function(subgraph, diagram) {
			this.onSubgraphCreated(subgraph, diagram);
		},
		
		onSubgraphCreated: function(/*ibm_ilog.diagram.Subgraph*/subgraph, /*ibm_ilog.diagram.widget.Diagram*/ diagram) {
			// summary:
			//    Invoked when the specified subgraph object has been created and initialized. 
			//    The default implementation does nothing.
			// subgraph: ibm_ilog.diagram.Subgraph: the new subgraph instance.
			// diagram: ibm_ilog.diagram.widget.Diagram: the diagram instance that fired the event.
		},
		
		resolveSubgraphTemplate: function(item) {
			// summary:
			//    Returns the template to represent the specified subgraph item.
			
			var func = this.subgraphTemplateFunction ? lang.partial(this.subgraphTemplateFunction, item, this) : null;
			return this._resolveTemplate(func, this._subgraphTemplate, Subgraph.defaultTemplate);
		},
		
		createSubgraph: function(/*Object or String*/template, /*dojo.data.api.Item*/ item, /*ibm_ilog.diagram.Graph*/ onGraph, /*Function?*/ nodeType) {
			// summary:
			//        Creates a Subgraph that represents the specified data item.
			// template: Object or String The template to use for this subgraph. Optional.
			// item: dojo.data.api.Item a data item associated with this subgraph. Optional.
			// onGraph: ibm_ilog.diagram.Graph The parent graph of the subgraph. If null, the top-level graph is used. Optional.
			// nodeType: Function
			//		The type of the node instance. Optional.
			// returns:
			//        A ibm_ilog.diagram.Subgraph instance.
			
			if (!onGraph) {
				onGraph = this._graph;
			}
			
			template = template || this.resolveSubgraphTemplate(item);
			
			var subgraph = null;
			// let's try a custom subgraph factory
			if (this.createSubgraphFunction) {
				subgraph = this.createSubgraphFunction.call(null, item, template, onGraph, this);
				if (subgraph && (!(subgraph._isIBMDiagramSubgraph))) {
					R.error("UnexpectedReturnValueType", this, createSubgraphFunction, "ibm_diagam.Subgraph", typeof(subgraph));
				}
			}
			if (!subgraph) {
				nodeType = nodeType || Subgraph;
				subgraph = this.createTemplatedShape(nodeType, template, onGraph, this.subgraphStyle, this.nodesStore, item);
			}
			
			// set Label property
			if (item) {
				var text = StoreApi.getLabel(this.nodesStore,item);
				if (text) {
					subgraph.setLabel(text);
				}
			}
			
			
			this._onSubgraphCreated(subgraph, this);
			
			return subgraph;
		},
		
		connectNodes: function(/* ibm_ilog.diagram.Node */start, /* ibm_ilog.diagram.Node */ end, /*String||Object*/ template, /*dojo.data.Item*/ linkItem) {
			// summary:
			//        Connects the specified nodes.
			//        This method creates a ibm_ilog.diagram.Link instance invoking the createLink() method
			//        and connects its extremities to the specified nodes. Optionally, one may specify
			//        the linksStore item associated with this link.
			// start: ibm_ilog.diagram.Node : the link start node.
			// end: ibm_ilog.diagram.Node: the link end node.
			// template: Object or String : the template to use. Optional.
			// linkItem: dojo.data.Item: the data item corresponding to this link, if any. Optional.
			// returns: ibm_ilog.diagram.Link
			
			if (!linkItem) {
				linkItem = null;
			}
			
			var link = this.createLink(start, end, template, linkItem);
			if (!link.getStartPort()) {
				link.setStartNode(start);
			}
			if (!link.getEndPort()) {
				link.setEndNode(end);
			}
			return link;
		},
		
		// a private hook to use for internal notification, as the public onNodeCreated
		// might be changed by the user *after* the widget initialization (in this case,
		// the internal "dojo.connect('onNodeCreated')" would listen the old method.
		_onLinkCreated: function(link, start, end, diagram) {
			this.onLinkCreated(link, start, end, diagram);
		},
		
		onLinkCreated: function(/*ibm_ilog.diagram.Link*/link, /*ibm_ilog.diagram.Node*/ start, /*ibm_ilog.diagram.Node*/ end, /*ibm_ilog.diagram.widget.Diagram*/ diagram) {
			// summary:
			//    Invoked when the specified link has been created.
			// link: ibm_ilog.diagram.Link: the new link instance.
			// start: ibm_ilog.diagram.Node: the link start node, if any.
			// end: ibm_ilog.diagram.Node: the link end node, if any.
			// diagram: ibm_ilog.diagram.widget.Diagram: the diagram instance that fired the event.
		
		},
		
		resolveLinkTemplate: function(/*dojo.data.Item*/linkItem,/*ibm_ilog.diagram.Node*/ start, /*ibm_ilog.diagram.Node*/ end) {
			// summary:
			//    Returns the link template to represent the specified relationship.
			// linkItem: dojo.data.Item: the data item corresponding to this link, if any.
			// start: ibm_ilog.diagram.Node : the link start node.
			// end: ibm_ilog.diagram.Node: the link end node.
			
			var func = this.linkTemplateFunction ? lang.partial(this.linkTemplateFunction, linkItem, start, end, this) : null;
			return this._resolveTemplate(func, this._linkTemplate, Link.defaultTemplate);
		},
		
		createLink: function(/* ibm_ilog.diagram.Node */start, /* ibm_ilog.diagram.Node */ end, /*Object or String*/ template, /*dojo.data.Item*/ linkItem, /*Function?*/ linkType) {
			// summary:
			//        Creates a Link to connect the specified nodes. Optionally, one may specify
			//        the linksStore item associated with this link. 
			// description: This method only creates the Link instance and does not connect the nodes. Caller may invoke
			//        the Diagram.connectNodes() method instead, which invokes this method and perfom the connection.
			// start: ibm_ilog.diagram.Node
			//		the link start node.
			// end: ibm_ilog.diagram.Node
			//		the link end node.
			// template: Object or String
			//		the template to use. Optional.
			// linkItem: dojo.data.Item
			//		the data item corresponding to this link, if any. Optional.
			// nodeType: Function
			//		The type of the node instance. Optional.
			// returns:
			//        a ibm_ilog.diagram.Link instance.
			
			if (!linkItem) {
				linkItem = null;
			}
			
			template = template || this.resolveLinkTemplate(linkItem, start, end);
			
			// let's try a custom factory
			var link = null;
			var graph = gu.lowestCommonAncestor(start, end);
			if (this.createLinkFunction) {
				link = this.createLinkFunction.call(null, linkItem, start, end, template, graph, this);
				if (link && (!(link._isIBMDiagramLink))) {
					R.error("UnexpectedReturnValueType", this, createLinkFunction, "ibm_diagam.Link", typeof(link));
				}
			}
			if (!link) {
				linkType = linkType || Link;
				link = this.createTemplatedShape(linkType, template, graph, this.linkStyle, this.linksStore, linkItem);
			}
			this._onLinkCreated(link, start, end, this);
			return link;
		},
		
		
		//
		// Data Binding
		//
		
		getBoundItem: function(nodeOrLink) {
			// summary: 
			//     Returns the data item, if any, associated with the specified node or link.
			// nodeOrLink: ibm_ilog.diagram.Node || ibm_ilog.diagram.Link || ibm_ilog.diagram.Subgraph: 
			//     the node, link or subgraph instance.
			
			var data = nodeOrLink.getData();
			return data ? data.item : null;
		},
		
		//------------------
		// Image export API
		//------------------
		
		toSvg: function(/*Function*/onComplete, /*Function*/ onError, /*Boolean*/ all){
			// summary:
			//     Export the graph as an SVG string.
			// description:
			//		Export the graph as an SVG string. This features requires Dojo 1.4.x or greater.
			// onComplete: Function
			//		The callback that receives the resulting SVG.
			// onError: Function
			//		The function called when the generation fails.
			// all: Boolean
			//		Indicates whether the whole graph should be visible in the resulting svg. If false, only the visible area is displayed. The default value is false. 
			
			var svg, gr = this._graph;
			var oldhud = this._getHudAttr();
			// hide hud and adorners
			this._setHudAttr(false);
			this.getViewport()._showOverlays(false);
			
			// patch so that gfx (de)serialization does not crash on MultilineText deserialization :
			// The gfx serialize() method does not save the 'shape' property of a Group instance, but
			// will save the others 'default' gfx properties (fill, stroke, font...), so MultilineText instances
			// are serialized as Group instance :
			// { children : [....], transform:..., font: ... }.  (so, no shape:{type:'ml'}).
			// Therefore, when the json is deserialized, a Group instance is created, and setFont() is invoked
			// (which fails because Group.setFont does not exist).
			// Patch (Hack!!!!): we delete the getFont/setFont accessors so that the font is not serialized
			var MultilineText = null;
			if (!iid.isSvg) {
				try {
					MultilineText = require("ibm_ilog/diagram/util/MultilineText");
					var getFont = MultilineText.prototype.getFont;
					delete MultilineText.prototype.getFont;
				} catch (err) {
				}
			}
			svg = gfxutils.toSvg(gu.getSurface(gr));
			svg.addCallbacks(lang.hitch(this, function(result){
				// restore font accessors
				if (!iid.isSvg && MultilineText) {
					MultilineText.prototype.getFont = getFont;
				}
				if (all) {
					var topg = this.getViewport().getEventSource();
					var bbox = gr.getBoundingBox();
					var tlt = this.getViewport()._transformedLayer.getTransform();
					var inv = tlt.inverse();
					var m = matrix.multiply(matrix.translate(-bbox.x, -bbox.y), inv);
					// neutralize the transformedLayer transform
					result = result.replace(/(<g)/, '$1 transform="matrix(' + m.xx + ',' + m.xy + ',' + m.yx + ',' + m.yy + ',' + (m.dx) + ',' + (m.dy) + ')"'); // resize surface to graph content
					// resize viewport size
					var e = /(<svg\b[^>]*)(\bwidth=\s*"\d*\w*")([^>]*)(\bheight=\s*"\d*\w*")([^>]*>)/g;
					var bb = "$1width=\"" + Math.round(bbox.width) + "px\"$3height=\"" + Math.round(bbox.height) + "px\"$5";
					result = result.replace(e, bb);
				}
				// restore state
				this._setHudAttr(oldhud);
				this.getViewport()._showOverlays(true);
				onComplete.call(null, result);
			}), lang.hitch(this, function(result){
				// restore font accessors
				if (!iid.isSvg && MultilineText) {
					MultilineText.prototype.getFont = getFont;
				}
				// restore state
				this._setHudAttr(oldhud);
				this.getViewport()._showOverlays(true);
				if (onError) {
					onError.call(null, result);
				}
			}));
		},
		
		
		//
		// Misc
		//
		
		getParent: function(){
			// summary:
			//		Returns the parent widget of this widget, assuming the parent
			//		specifies isContainer
			var parent = registry.getEnclosingWidget(this.domNode.parentNode);
			return parent && parent.isContainer ? parent : null;
		},
		
		getSurface: function() {
			// summary: 
			//        Returns the dojox.gfx.Surface object displaying the graph.
			// returns:
			//        A dojox.gfx.Surface instance. 
			return this._viewport.getSurface();
		},
		
		getGraph: function() {
			// summary:
			//        Returns the ibm_ilog.diagram.Graph instance that displays the graph.
			// returns:
			//        An ibm_ilog.diagram.Graph instance. 
			return this._graph;
		},
		
		getGraphTransform: function() {
			// summary:
			//        Returns the graph transform.
			// returns:
			//        A dojox.gfx.matrix.Matrix2D instance that represents the current graph transform.
			return this._graph.getTransform() || matrix.identity;
		},
		
		getGraphToDiagramTransform: function() {
			// summary:
			//		Returns the matrix used to transform coordinates of objects contained
			//		in this diagram's graph (returned by <code>getGraph()</code>) to coordinates
			//		relative to this Diagram object.
			// returns:
			//		A dojox.gfx.matrix.Matrix2D instance.
			
			return this._graph._getRealMatrix() || matrix.identity; // dojox.gfx.matrix.Matrix2D
		},
		
		getGraphToClientTransform: function() {
			// summary:
			//		Returns the matrix used to transform coordinates of objects contained
			//		in this diagram's graph (returned by <code>getGraph()</code>) to coordinates
			//		relative to the client browser's page.
			// returns:
			//		A dojox.gfx.matrix.Matrix2D instance.
			
			var t = this.getGraphToDiagramTransform();
			var rect = this.domNode.getBoundingClientRect();
			t = matrix.multiply(matrix.translate(rect.left, rect.top), t);
			return t; // dojox.gfx.matrix.Matrix2D
		},
		
		getNodeRect: function(node, inClient) {
			// summary:
			//		Returns the bounding rectangle of a node of the graph,
			//		in client (i.e., browser page) coordinates, or relative to the Diagram.
			// description:
			//		This method computes the bounding rectangle of a node contained in this Diagram widget.
			//		The returned rectangle is either relative to the whole browser page (if inClient is true or omitted),
			//		or relative to the bounds of the Diagram widget (if inClient is false).
			// node: ibm_ilog.diagram.Node
			//		A Node of the Graph displayed in this Diagram.
			// inClient: Boolean
			//		If true (the default), the returned rectangle is relative to the whole browser page.
			//		If false, the returned rectangle is relative to the bounds of the Diagram widget.
			// returns:
			//		An object with x, y, width and height properties.
			
			var bb = node.getBounds(this._graph);
			var t = (arguments.length == 1 || inClient) ? this.getGraphToClientTransform() : this.getGraphToDiagramTransform();
			bb = t.transformRectangle(bb);
			return bb; // Object
		},
		
		getGraphElementFromDataItem: function(item) {
			// summary:
			//        Gets the GFX object, for the given Data Item.
			var node = this._nodesStore ? this._getNodeFromStoreItem(item) : null;
			return node ? node : (this._linksStore ? this._getLinkFromStoreItem(item) : null);
		},
		
		asGraphElement: function(itemOrGraphElement) {
			// Summary:
			// 		return the gfx that corresponds to the given item, checking if it is not a gfx already
			if (Selectable.Util.isSelectableInstance(itemOrGraphElement)) {
				return itemOrGraphElement;
			} else {
				return this.getGraphElementFromDataItem(itemOrGraphElement);
			}
		},
		
		useDataStore: function() {
			// Summary:
			//		return if the Diagram is using node store.
			return this.nodesStore != null;
		},
		
		// =======================================================================
		//
		//  ANNOTATIONS:
		//
		
		//
		//	annotationsEnabled:
		//		Used to disable annotations.
		//
		annotationsEnabled: true,
		
		//
		//	createAnnotationAdornerFunction:
		//		Allows to specify what adorner to create for annotating the given GraphElement
		//
		createAnnotationAdornerFunction: function(ge, kwArgs) {
			//
			//	ge: the graph element
			//
			var layer = this._annotationLayer;
			
			var AnnotationAdorner = require("../adorners/AnnotationAdorner"); // may throw error if not required explicitly...
			var target = layer.createObject(AnnotationAdorner.AnnotationTargetAdorner); // Attention!! dojo
			target.initialize(this, this._adornerTemplates, "AnnotationTargetAdorner");
			
			var annotation = layer.createObject(AnnotationAdorner);
			annotation.initialize(this, this._adornerTemplates, "AnnotationAdorner");
			
			var link = layer.createObject(Link);
			link.applyTemplate(this._adornerTemplates.item("AnnotationLink"));
			
			link.setShapeType(Link.LinkShapeType.Orthogonal);
			
			var port = require("../Port");
			var s = new port.AutomaticPort();
			var e = new port.AutomaticPort();
			
			s._setOwner(annotation);
			e._setOwner(target);
			
			link.setStartPort(s);
			link.setEndPort(e);
			
			target.setLink(link);
			annotation.setLink(link, target);
			
			return annotation;
		},
		
		//
		//	destroyAnnotationAdornerFunction:
		//		Counterpart to the createAnnotationAdornerFunction, this functions destroyed the previously created annotation.
		//
		destroyAnnotationAdornerFunction: function(annotation) {
			var layer = this._annotationLayer;
			layer.remove(annotation.getLink());
			this.destroyAdorner(annotation.getTarget());
			this.destroyAdorner(annotation);
		},

		//
		//	hasAnnotationFunction:
		//		Allows to specify when the adorner needs an annotation adorner created
		//
		hasAnnotationFunction: function(ge) {
			//
			//	ge: the graph element
			//
			return ge.getAnnotation() != "";
		},
		
		//
		//	loadAnnotationsFunction:
		//		Allows to create the annotations already associated with data already present in the ge.
		//
		loadAnnotationsFunction: function(ge) {
			//
			//	ge: the graph element
			//
		},
		
		_loadAnnotations: function() {
			//
			//	summary:
			//		Allows the user to create annotations based on ge/item data. This 
			//		method is executed after widget initialization is completed. 
			//
			gu.forEach(this._graph, this.loadAnnotationsFunction, this);
		},
		
		_annotations: null,
		
		_initializeAnnotations: function() {
			var v = this.getViewport();
			
			v.whenLoaded(lang.hitch(this, function() {
				this._annotations = new Dictionary();
				this._annotationLayer = v.getOverlayLayer().createGroup();
			}));
		},
		
		getAnnotationList: function(ge) {
			//
			//	returns:
			//		A dojox.collections.ArrayList with the annotations created for the graph element.
			//	note:
			//		Creates an empty list if none is registered yet.
			//
			var id = ge.getId();
			var ans;
			if (this._annotations.contains(id)) {
				ans = this._annotations.item(id);
			} else {
				this._annotations.add(id, ans = (new ArrayList()));
			}
			return ans;
		},
		
		addAnnotation: function(ge, kwArgs) {
			//
			//	ge: ibm_ilog.diagram.GraphElement
			//		The entity being annotated
			//
			if (this.annotationsEnabled) {
				var a = this.createAnnotationAdornerFunction(ge, kwArgs);
				
				var ans = this.getAnnotationList(ge);
				
				ans.add(a);
				
				a.setAdorned(ge);
			}
		},
		
		removeAnnotation: function(annotation) {
			var ans = this.getAnnotationList(annotation.getAdorned());
			ans.remove(annotation);
			this.destroyAnnotationAdornerFunction(annotation);
		},
		
		// =======================================================================
		//
		//  TOOLTIPS:
		//
		
		// On mobile platforms, these functions can be used only if the application
		// explicitly requires dijit.Tooltip. On desktop, dijit.Tooltip is required
		// in _Diagram.js so the application has nothing to do.
		
		//
		//	getTooltipContentFunction:
		//		Callback function used to build the tooltip content associated with 
		//		the given graph element.  
		//
		getTooltipContentFunction: function(ge) {
			return ge.getTooltip ? ge.getTooltip() : "";
		},

		//
		//	getTooltipAroundPlacementFunction:
		//		Callback function used to compute the graph element bounding box used
		//		to compute the tooltip placement.
		//
		getTooltipAroundPlacementFunction: function(ge) {
			var r = dojoext.coords(this.domNode, true), bb;
			bb = this._viewport.contentToClient().transformRectangle(ge.getBounds(this._graph));
			bb = g.moveRect(g.clipRect(g.standarizeRect(this._viewport.getClientSize()),bb),r);
			bb = { x:bb.x, y:bb.y, w:bb.width, h:bb.height }; // rename w/h for Dojo 1.7/2.0
			return bb;
		},

		showTooltip: function(ge, innerHTML, dontHideOnChange) {
			//
			//	summary:
			//		Opens the dijit master tooltip on a graph element.
			//
			//	description:
			//		Opens a tooltip for a graph element. The content is get using the 
			//		getTooltipContentFunction function. Optionally, 
			//		the content can be overriden using the 'innerHTML' argument.
			//
			//	ge: ibm_ilog.diagram.GraphElement
			//		the graph element
			//
			//	innerHTML: String?
			//		optional argument that overrides the content of the tooltip.
			//
			//	dontHideOnChange:  boolean
			//		option to disable auto-hiding of the tooltip then the element reports changes
			//

			if(Tooltip === undefined){
				try {
					Tooltip = require("dijit/Tooltip");
				} catch(err){
					Tooltip = null;
				}
			}
			if(!Tooltip)
				return;
			
			this.hideTooltip();
			
			innerHTML = innerHTML || this.getTooltipContentFunction(ge);
			if (innerHTML.length) {
				if (innerHTML.length) {

					var bb = this.getTooltipAroundPlacementFunction(ge);
					
					//Set text direction in tooltip
					if (config.isBidiInDojoDiagrammer) {  
					    var UCC = "";  
	                    var textdir = this.textDir;
	                    if (textdir == "auto")
	                        textdir = BidiUtil.checkDir(innerHTML);
	                    if (textdir == "rtl")
	                        UCC  = "\u202B"; //RLE
	                    else if (textdir == "ltr")
	                        UCC = "\u202A"; //LRE
	                    Tooltip.show(UCC+innerHTML, bb);      
    				} else	
						Tooltip.show(innerHTML, bb);
						
					this._tooltipHandle = bb;
					this._tooltipTarget = ge;

					if(!dontHideOnChange) {
						this._tooltipHideOnChange = connect.connect(ge,"_onChanged",this,function() {
							this.hideTooltip();
							connect.disconnect(this._tooltipHideOnChange);
						});
					}
				}
			}
		},
		
		hideTooltip: function() {
			//
			//	summary:
			//		Hides the dijit master tooltip, if currently in use by the Diagram.
			//
			
			if(!Tooltip)
				return;
			
			if(this._tooltipHandle) {
				Tooltip.hide(this._tooltipHandle);
				if(this._tooltipHideOnChange) {
					connect.disconnect(this._tooltipHideOnChange);
				}
				this._tooltipHandle = null;
				this._tooltipTarget= null;
			}
		},
		
		//
		//	_tooltipTarget: ibm_ilog.diagram.GraphElement?
		//		The current toolip target.
		//
		_tooltipOwner: null,
		
		//
		//	_tooltipHandle: Object?
		//		The tooltip handle, used for hiding.
		//
		_tooltipHandle: null,
		
		//
		//	_tooltipHideOnChange: Object?
		//		The tooltip hide on change connection handle.
		//
		_tooltipHideOnChange: null
	});
	
	// Add _Diagram features to Diagram if not on mobile.
	if(_Diagram)
		lang.extend(Diagram, _Diagram);
	
	return Diagram;
		
});
