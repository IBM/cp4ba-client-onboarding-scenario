/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare"
], function(
declare
){

var HudComponent =
declare('ibm_ilog.diagram.widget.HudComponent', null, {
	//
	//	summary:
	//		Superclass for Viewport overlaid components.
	//	
	
	//
	//	_layer: dojox.gfx.Group
	//			Viewport layer at which the component is created.
	//
	_layer: null,

	//
	//	_enabled: boolean
	//			True if enabled and visible.
	//
	_enabled: true,

	//
	//	_shape: dojox.gfx.Group
	//			Main shape of the component
	//
	_shape: null,

	constructor: function (viewport) {
		this._enabled = true;
		this._viewport = viewport;
		this._layer = viewport._hudLayer;
		this._shape = this._layer.createGroup();

		viewport.registerHudComponent(this);
	},

	_enable: function () {
		//
		//	summary:
		//			Enables the component and displays it.
		//
		this._enabled = true;
		this._layer.add(this._shape);
	},

	_disable: function () {
		//
		//	summary:
		//			Disables the component and hides it.
		//
		this._layer.remove(this._shape);
		this._enabled = false;
	},

	setEnabled: function ( /*boolean*/ enabled ) {
		//
		//	summary:
		//			Shows or hides the component, disabling possible connections and overhead while hidden.
		//
		if (!this._enabled && enabled) {
			this._enable();
		} else if (this._enabled && !enabled) {
			this._disable();
		}
	},

	isEnabled: function () {
		//
		//	summary:
		//			Returns true of the component is active and visible.
		//
		return this._enabled;
	}

});

return HudComponent;

});
