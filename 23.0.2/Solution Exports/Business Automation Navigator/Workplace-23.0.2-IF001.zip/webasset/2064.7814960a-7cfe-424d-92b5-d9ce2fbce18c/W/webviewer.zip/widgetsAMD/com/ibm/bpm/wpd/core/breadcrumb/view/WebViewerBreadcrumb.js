define(["require",
        "dojo/parser",
        "dojo/_base/config",
        "dojo/_base/connect",
        "dojo/_base/lang",
        "dojo/dom-construct",
        "dijit/_Widget",
        "dijit/_TemplatedMixin",
        "dijit/_WidgetBase",
        "dojo/_base/declare",
		"../../control/commands/OpenDocumentCommand",
        "../../model/providers/ModelTypeProviderRegistry",
        "../../../util/Helper",
        "../../../util/BidiUtils"
		],
function(require,
        parser,
        config,
        connect,
        lang,
        domConstruct,
        _Widget,
        _TemplatedMixin,
        _WidgetBase,
        declare,
        OpenDocumentCommand,
        ModelTypeProviderRegistry,
        Helper,
        BidiUtils) {

/**
 * Breadcrumb for the WebViewer
 */
return declare([ _WidgetBase, _TemplatedMixin], {

	templateString : "<div dojoAttachPoint=\"breadcrumbEntryAttachPoint\"></div>",
	
	_connectionHandles : null,
	_subscriptionHandles : null,
	//view types that this breadcrumb displays
    //typesToDisplay:null,
 
	//For breadcrumb entry, we can choose to use a dojo cleass for breadcrumb entry too if we want
	_divToModel:null,
	_modelToDiv:null,
	_isBidiLang:null,
	
	/**
	 * 
	 * @param params properties
	 * 		className css class name to be used for this breadcrumb
	 */
	constructor : function(params) {
		this._connectionHandles = [];
		this._subscriptionHandles = [];
		this._divToModel = {};
		this._modelToDiv = {};
		var locale = config.locale;
		if (locale === "ar" || locale === "he") {
			this._isBidiLang = true;
		} else {
			this._isBidiLang = false;
		}
		//this.typesToDisplay = params.displayTypes;
	},
	
	postCreate : function() {
		this.domNode.className = this.className;
		this.addListeners();
	},
	
	addListeners : function(){
		this._subscriptionHandles.push(connect.subscribe("com.ibm.bpm.wpd.core.model.shellstate.ShellStateModel" + "::" + "_openViewStateModels", this, this.openVsmChanged));
		this._subscriptionHandles.push(connect.subscribe(
				"com.ibm.bpm.wpd.core.model.shellstate.ShellStateModel" + "::" + "_activeViewStateModel",
				this,
				this.activeVsmChanged));
	},
	
	/**
	 * Receives notifications via dojo publish and subscription
	 * Removes a breadcrumb entry upon view state model change
	 */
	openVsmChanged : function(notification){
		if (notification.changeType == 3){
			//remove the corresponding breadcrumb
			this.removeBreadcrumbEntry(notification.oldValue);
		}
	},
	
	/**
	 * Receives notifications via dojo publish and subscription
	 * Adds a breadcrumb entry upon view state model change
	 */
	activeVsmChanged : function(notification){
		
		if(!!notification.newValue){
			//if(this._isDisplayable(vsm)){
			if (!this.breadCrumbSwap(notification)) {
				this.addBreadcrumbEntry(notification.newValue, lang.hitch(this, this._breadcrumbEntryClicked));
			}
		}
	},
	
	/**
	 * In the case of a comparison the assetListView is removed from the trail and replaced by the comparison
	 * entry
	 */
	breadCrumbSwap: function(notification) {
		
		// check to see if there exists an new on old value
		if (!!notification.newValue && !!notification.oldValue) {
			if (notification.newValue.documentId == "compareListModel") {
				this.removeBreadcrumbEntry(notification.oldValue);
				this.addBreadcrumbEntry(notification.newValue, lang.hitch(this, this._breadcrumbEntryClicked));
				return true;
			}
		}
		
		return false;
	},
	
	/**
	 * Receives notifications via dojo publish and subscription
	 * Adds or removes a breadcrumb entry upon view state model change
	 */
//	modelChanged : function(notification) {
//		
//		if (notification.attributeName == "_openViewStateModels" && notification.changeType == 3){
//			//remove the corresponding breadcrumb
//			this.removeBreadcrumbEntry(notification.oldValue);
//		}
//		
//		else if (notification.attributeName == "_activeViewStateModel"){		
//			if(!!notification.newValue){
//				//if(this._isDisplayable(vsm)){
//					this.addBreadcrumbEntry(notification.newValue, dojo.hitch(this, this._breadcrumbEntryClicked));
//				//}
//			}
//		}
//	},
	
	_isDisplayable: function(vsm){
		//check if the type is in the list of displayble ones
	},
	
	/**
	 * Adds an entry
	 * @param vsm the model associate with the breadcrumb entry to be created
	 * 			properties
	 * 				type: the type of the po
	 * 				name: name to be displayed
	 * 				id : an unique id for this breadcrumb entry, ie, po id
	 * @param onClick handler for the onClick event
	 * @param noSeparator whether the entry start with an separator
	 * @param imagePath   the image file path for the icon to be used. If not provided, the value provided by the 
	 * 					  doc type provider will be used	 * 	
	 * @param keyboardClick handler for the onkeypress event				 
	 */
	addBreadcrumbEntry : function(vsm, onClick, noSeparator, imagePath/*Optional*/, keyboardClick /*Optional*/){

		var noSeparator = true;
		for(var pro in this._modelToDiv){
			noSeparator = false;
		}
		this._addBreadcrumbEntry(this.breadcrumbEntryAttachPoint, vsm, onClick, noSeparator, imagePath, keyboardClick);
	},
	
	_addBreadcrumbEntry:function(parentDiv, viewModel, onClick, noSeparator, imagePath, keyboardClick){
		var sectionDiv;
		//check if an entry for the model exists already
		//This happens when click on an entry for a document which is not the current open one
		if (!!this._modelToDiv[viewModel.id]){
			sectionDiv = !!this._modelToDiv[viewModel.id];
		}
		else{
			var divId = "breadcrumbEntryDiv" + viewModel.id;
			var sectionDiv = domConstruct.create("div", {
				id: divId
			}, parentDiv, this._getAttachPosition());
		
			var type = viewModel.type;
			var id = viewModel.id;
			var name = viewModel.name;
			if (type == "Service") {
				var serviceType = viewModel.getDocumentModel().serviceType;
			}

						
			if(!noSeparator){
				this.attachSeparator(sectionDiv);
			}
			this.attachIcon(sectionDiv, type, imagePath, serviceType);
			this.attachName(sectionDiv, name, onClick, keyboardClick);
	
			this._modelToDiv[id] = sectionDiv;
			this._divToModel[divId] = viewModel;
		}
		this._setStyleForSelectedBreadcrumb(viewModel);
	},

	/*
	* Returns whether to attach a new node last (for LTR)
	* or first (for RTL)
	*/
	_getAttachPosition: function() {
		if (this._isBidiLang) {
			return "first";
		}
		return "last";
	},
	
	
	attachIcon: function(sectionDiv, itemType, imagePath, serviceType) {		
		var src = imagePath;
		if(!imagePath){		
			var docTypeProvider = ModelTypeProviderRegistry.getInstance().getDocTypeProvider(itemType);
			if (itemType == "Service") {
				src = docTypeProvider.getServiceIconPath(16, serviceType);
			} else {
				src = docTypeProvider.getIconPath(16);
			}	
		}

		if(!!src){
			var imageDiv = document.createElement("div");
			sectionDiv.appendChild(imageDiv);
			imageDiv.className = "viewerBreadcrumbEntryItem";
			imageDiv.innerHTML = "<img style='' src='" + require.toUrl("../../../" + src) + "'/>";
		}
	},
	
	attachName: function(sectionDiv,name, onClick, keyboardClick) {
		var displayName = name;
		if (displayName.indexOf("<span ")==-1)
			displayName = Helper.text2htmlText_1(name);
		
		var nameDiv = domConstruct.create("div", {
			style: {
				cursor: "pointer"
			},
			className: "viewerBreadcrumbEntryItem",
			innerHTML: displayName
		}, sectionDiv, this._getAttachPosition());		

		var dir = BidiUtils.getDirValue(name);
		if (dir=="rtl") {
			// consider breadcrumb has ()
			nameDiv.innerHTML = BidiUtils.getRTLTextWithBracket(nameDiv.innerHTML);
			nameDiv.setAttribute("dir","rtl");
		}

		this._connectionHandles.push(connect.connect(nameDiv, "onclick", null, onClick));

		if (keyboardClick){
			nameDiv.setAttribute("tabIndex",0);
			this._connectionHandles.push(connect.connect(nameDiv, "onkeypress", null, keyboardClick));
		}				
	},
	
	attachSeparator: function (sectionDiv) {
		var contents = "     &gt;";
		domConstruct.create("div", {
			innerHTML: contents,
			className: "viewerBreadcrumbEntryItem"
		}, sectionDiv, this._getAttachPosition());
	},
	
	_breadcrumbEntryClicked:function(event){		
		var div = event.currentTarget;
		div = div.parentNode;
		var model = this._divToModel[div.id];		
	
		//dispatch event, the open doc command will find the cached vsm and set it as active and return, 
		//No need to go to the server
		var params = {documentId:model.documentId, keyId: model.keyId};
		(new OpenDocumentCommand(params)).execute();
		
	},
	/**
	 * Remove the breadcrumb entry associated with vsm
	 * @param vsm the model associated with the entry to be removed
	 */
	removeBreadcrumbEntry: function(vsm){
		var div = this._modelToDiv[vsm.id];
		if (!!div) {
			delete this._divToModel[div.id];
		
			div.parentNode.removeChild(div);
		}
		delete this._modelToDiv[vsm.id];
	},
	
	_setStyleForSelectedBreadcrumb:function(cvsm){
		
		//go through all divs, if its model is the same as cvsm, then set as selected
		var div;		
		for (var modelId in this._modelToDiv) {
			div = this._modelToDiv[modelId];
			if((!!div)){
				if(cvsm.id == modelId){				
					div.className = "viewerBreadcrumbEntrySelected";
				}
				else{
					div.className = "viewerBreadcrumbEntry";
				}
			}
		}
	},

	/**
	 * Clean up stored data
	 */
	removeListeners:function(){
	
		for ( var i = 0; i < this._connectionHandles.length; i++) {
			if(!!this._connectionHandles[i]){
				connect.disconnect(this._connectionHandles[i]);
			}
		}

		for ( var i = 0; i < this._subscriptionHandles.length; i++) {
			if(!!this._subscriptionHandles[i]){
				connect.unsubscribe(this._subscriptionHandles[i]);
			}
		}
	},
	
	/**
	 * Destroy the widget
	 */
	destroy : function() {
		this.inherited(arguments);
		this.removeListeners();
		this._divToModel = null;
		this._modelToDiv = null;
		
	}
});

});

/**
 * BreadcrumbEntry
 * Currently there is no benefit from having this class
 */
//dojo.declare("com.ibm.bpm.wpd.core.breadcrumb.view.WebViewerBreadcrumb",[ dijit._Widget, dijit._Templated ], {
//	vsm:null,
//	
//	
//	modelChanged : function(){
//		
//	},
//	
//	entryClicked : function(){
//		
//	}
//	
//});
