define(["dojo/_base/declare"],
function(declare) {

/**
 * This class represents a change made to a model and is used to communicate the change to
 * parties that are listening for model changes
 **/
return declare([], {
	
//	/* The possible values for the change type */
//	SET:String = 1;
//	COLLECTION_ADD:String = 2;
//	COLLECTION_REMOVE:String = 3;
//	COLLECTION_UPDATE:String = 4;
// 	COLLECTION_REMOVE_ALL: String = 5;	
	
	changeType : null,
	parentObject : null,		// type: MObject
	attributeName : null,
	oldValue : null,
	newValue : null,
	affectedListPosition: -1,
	context: null,
	
	constructor : function(changeType, parentObject, attributeName, oldValue, newValue, affectedListPosition, context){
		this.changeType = changeType;
		this.parentObject = parentObject;
		this.attributeName = attributeName;
		this.oldValue = oldValue;
		this.newValue = newValue;
		if (affectedListPosition != null){
			this.affectedListPosition = affectedListPosition;
		}
		this.context = context;
	}
	
});

});