/**
 * @author jdbennet
 */
define(["dojo/_base/declare", "dojo/_base/lang", "com.ibm.bpm.wpd/base/bootstrap"],
function(declare, lang, bootstrap) {

return declare(null, {

DEFAULT_COLOR_DEFAULT: "#edf5ff",
DEFAULT_COLOR_MAGENTA: "#fff0f7",
DEFAULT_COLOR_COOLGRAY: "#dde1e6",
DEFAULT_COLOR_GREEN: "#defbe6",
DEFAULT_COLOR_CYAN: "#e5f6ff",
DEFAULT_COLOR_PURPLE: "#f6f2ff",
DEFAULT_COLOR_TEAL: "#d9fbfb",
DEFAULT_COLOR_YELLOW: "#fcf4d6",

DEFAULT_STROKE_DEFAULT: "#0f62fe",
DEFAULT_STROKE_MAGENTA: "#9f1853",
DEFAULT_STROKE_COOLGRAY: "#697077",
DEFAULT_STROKE_GREEN: "#198038",
DEFAULT_STROKE_CYAN: "#0072c3",
DEFAULT_STROKE_PURPLE: "#8a3ffc",
DEFAULT_STROKE_TEAL: "#007d79",
DEFAULT_STROKE_YELLOW: "#684e00",


complexEventTemplate: {
    layout: {
        type: 'ibm_ilog.diagram.gfxlayout.StackLayout'
    },

    children: [
        {
            dojoAttachPoint: 'counter',
            halign: 'center',
            shape: {
                align: 'middle',
                text: '{{data.counter}}',
                type: 'text',
                width: 80
                },
            fill: {
                r: 0,
                g: 0,
                b: 0,
                a: 1
            },
            font: {
                type: 'font',
                weight: 'normal',
                size: '11.5pt',
                family: 'arial'
            }
        },


    {
      layout: {
        type: 'ibm_ilog.diagram.gfxlayout.GridLayout'
    },
        children: [{
            dojoAttachPoint: 'baseShape',
            valign: 'center',
            halign: 'center',
            shape: {
                width: 24,
                height: 24,
                src: '/BPMN/com/ibm/bpm/wpd/images/BPD/start_event_25x25.png',
                type: 'image'
            }
        }

      ]


    }, {
      dojoAttachPoint: 'textShape',
      shape: {
                align: 'middle',
                text: '{{label|safe}}',
                type: 'mltext',
                width: 90,
                wrap: false
            },
        fill: {
            r: 0,
            g: 0,
            b: 0,
            a: 1
        },
        font: {
            type: 'font',
            weight: 'normal',
            size: '11.5pt',
            family: 'arial'
        }
    }]
},



complexVMLTemplate: {
    layout: {
        type: 'ibm_ilog.diagram.gfxlayout.StackLayout'
    },

    children: [
        {
            halign: 'center',
            shape: {
                align: 'middle',
                text: '{{data.counter}}',
                type: 'text',
                width: 80
                },
            fill: {
                r: 0,
                g: 0,
                b: 0,
                a: 1
            },
            font: {
                type: 'font',
                weight: 'normal',
                size: '11.5pt',
                family: 'arial'
            }
        },


    {
      layout: {
        type: 'ibm_ilog.diagram.gfxlayout.GridLayout'
    },
        children: [{
            dojoAttachPoint: 'baseShape',
            valign: 'center',
            halign: 'center',
            shape: {
                width: 24,
                height: 24,
                src: '/BPMN/com/ibm/bpm/wpd/images/BPD/start_event_25x25.png',
                type: 'image'
            }
        }

      ]


    }, {
            
            valign: 'center',
            halign: 'center',
            shape: {
                width: 72,
                height: 50,
                src: '/BPMN/com/ibm/bpm/wpd/images/BPD/start_event_25x25.png',
                type: 'image'
            }
        }]
},


    linkTemplate: [{
        dojoAttachPoint: '_path',
        shape: {
            type: 'polyline',
            points: [{
                x: 0,
                y: 0
            }, {
                x: 100,
                y: 100
            }]
        },
        stroke: {
            type: 'stroke',
            color: 'gray',
            width: 1
        }
    },

    {
        dojoAttachPoint: '_endArrow',
        shape: {
            type: 'polyline',
            points: [{
                x: -8,
                y: 4
            }, {
                x: 0,
                y: 0
            }, {
                x: -8,
                y: -4
            }, {
                x: -8,
                y: 4
            }]
        },
        fill: 'gray',
        stroke: {
            type: 'stroke',
            color: 'gray',
            width: 1
        }
                 
    }],

    linkDiamondTemplate: [{
        dojoAttachPoint: '_path',
        shape: {
            type: 'polyline',
            points: [{
                x: 0,
                y: 0
            }, {
                x: 100,
                y: 100
            }]
        },
        stroke: {
            type: 'stroke',
            color: 'gray',
            width: 1
        }
    },
    {
        dojoAttachPoint: '_startArrow',
           shape: {
                    path: 'M -12 0 l 7 -4 l 7 4 l -7 4 z',
                    type: 'path'
                 },
            fill: 'white',
            stroke: {
                type: 'stroke',
               color: 'gray',
                width: 1
        }
      },
      

    {
        dojoAttachPoint: '_endArrow',
        shape: {
            type: 'polyline',
            points: [{
                x: -8,
                y: 4
            }, {
                x: 0,
                y: 0
            }, {
                x: -8,
                y: -4
            }, {
                x: -8,
                y: 4
            }]
        },
        fill: 'gray',
        stroke: {
            type: 'stroke',
            color: 'gray',
            width: 1
        }
    }],

    linkConditionTemplate: [{
        dojoAttachPoint: '_path',
        shape: {
            type: 'polyline',
            points: [{
                x: 0,
                y: 0
            }, {
                x: 100,
                y: 100
            }]
        },
        stroke: {
            type: 'stroke',
            color: 'gray',
            width: 1
        }
    },
    {
        dojoAttachPoint: '_startArrow',
           shape: {
                    path: 'M -4 8 L -8 -8',
                    type: 'path'
                 },
            fill: 'gray',
            stroke: {
                type: 'stroke',
                color: 'gray',
                width: 1
        }
      },
      

    {
        dojoAttachPoint: '_endArrow',
        shape: {
            type: 'polyline',
            points: [{
                x: -8,
                y: 4
            }, {
                x: 0,
                y: 0
            }, {
                x: -8,
                y: -4
            }, {
                x: -8,
                y: 4
            }]
        },
        fill: 'gray',
        stroke: {
            type: 'stroke',
            color: 'gray',
            width: 1
        }
    }],

    assignmentEventMarker: {
            valign: 'center',
            halign: 'center',
            margins: [3, 3, 17, 3 ],
            shape: {
                width: 7,
                height: 7,
                src: bootstrap.getEndPointAndContextRootForModule(bootstrap.wpdConstant.BPM_WARNAME_WEBVIEWER) + '/widgets/com/ibm/bpm/wpd/images/BPD/Pre-Post-assignment_marker_7x7.png',
                type: 'image'
            },
            stroke: 'black'
     
        },


 groupTemplate: {
        layout: {
            type: 'ibm_ilog.diagram.gfxlayout.GridLayout'
        },
        children: [{
            dojoAttachPoint: 'baseShape',
            shape: {
                x: 0,
                y: 0,
                width: 95,
                height: 20,
                type: 'rect',
                r: 5
            },
            stroke: {
                color: 'black',
                width: 1,
                style: 'LongDashDot'
            },
            fill: "#F8F3F7"
        }

        
       

        ]
    },

    noteTemplate: {
        layout: {
            type: 'ibm_ilog.diagram.gfxlayout.GridLayout'
        },
        children: [{
            dojoAttachPoint: 'baseShape',
            shape: {
                x: 0,
                y: 0,
                width: 95,
                height: 20,
                type: 'rect'
            },
            fill: "#FFFFCC"
        },

        {
            dojoAttachPoint: 'textShape',
            halign: 'left',
            valign: 'top',
            margins: [10, 5, 0, 0 ],
            shape: {
                x: 15,
                y: 5,
                align: 'start',
                text: '{{label|safe}}',
                width: 80,
                type: 'mltext',
                wrap: false
            },
            
            fill: {
                r: 0,
                g: 0,
                b: 0,
                a: 1
            },
            font: {
                type: 'font',
                weight: 'normal',
                size: '11.5pt',
                family: 'Arial'
            }
        },
        {
            halign: 'left',
            valign: 'center',
            shape: {
                type: 'line',
                x1: 0,
                y1: 0,
                x2: 0,
                y2: 70
            },
            stroke: 'black'
        },
        {
            halign: 'left',
            valign: 'top',
            shape: {
                type: 'line',
                x1: 0,
                y1: 0,
                x2: 18,
                y2: 0
            },
            stroke: 'black'
        },
        {
            halign: 'left',
            valign: 'bottom',
            shape: {
                type: 'line',
                x1: 0,
                y1: 0,
                x2: 18,
                y2: 0
            },
            stroke: 'black'
        }

        ]
    },

    activityTemplate: {
        
        layout: {
            type: 'ibm_ilog.diagram.gfxlayout.StackLayout'
        },
        children: [
            {
                dojoAttachPoint: 'counter',
                shape: {
                        align: 'middle',
                        text: '{{data.counter}}',
                        type: 'text',
                        width: 80
                    },
                    fill: {
                        r: 0,
                        g: 0,
                        b: 0,
                        a: 1
                    },
                    font: {
                        type: 'font',
                        weight: 'normal',
                        size: '11.5pt',
                        family: 'arial'
                    }
            },
            {
                halign: 'center',
                valign: 'center',
                layout: {
                    type: 'ibm_ilog.diagram.gfxlayout.GridLayout'
                },
                children: [{
                    halign: 'center',
                    valign: 'center',
                    dojoAttachPoint: 'baseShape',
                    shape: {
                        width: 95,
                        height: 70,
                        src: './images/bwGateway.png',
                        type: 'image'
                    }
                },
        
                {
                    dojoAttachPoint: 'textShape',
                    halign: 'center',
                    valign: 'center',
                    shape: {
                        align: 'middle',
                        text: '{{label|safe}}',
                        y: 15,
                        x: 15,
                        type: 'mltext',
                        wrap: false,
                        width: 80
                    },
                    fill: {
                        r: 0,
                        g: 0,
                        b: 0,
                        a: 1
                    },
                    font: {
                        type: 'font',
                        weight: 'normal',
                        size: '11.5pt',
                        family: 'arial'
                    }
                }]
            }
        ]
    },

    stepTemplate: {
        layout: {
            type: 'ibm_ilog.diagram.gfxlayout.StackLayout'
        },
        children: [
            {   
                dojoAttachPoint: 'counter',
                halign: 'center',
                layout: {
                    type: 'ibm_ilog.diagram.gfxlayout.StackLayout',
                    horizontal:true,
                    paddingBottom: 5
                },
                children: [
                    {	
                        shape: {
                            text: '{{data.counter}}',
                            type: 'text',
                            width: 80
                        },
                        fill: {
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 1
                        },
                        font: {type: 'font', weight: 'normal', size: '9pt', family: 'IBM Plex Sans'}
                    }
                ]
            },
            {
                halign: 'center',
                valign: 'center',
                layout: {
                    type: 'ibm_ilog.diagram.gfxlayout.GridLayout'
                },
                maximumSize: {width: 95, height: 70},
                children: [
                    {	dojoAttachPoint: 'baseShape',
                        halign: 'center', valign: 'center',		            
                        svgType: 'stepTemplate',
                        shape: {x: 0, y: 0, type: 'rect', width: 95, height: 70, r: 4},
                        fill: {type: "linear", x1: 0, y1: 100, x2: 0, y2: 100,
                            colors: [
                                { offset: 0,   color: "#edf5ff" },
                                { offset: 1,   color: "#edf5ff" }
                            ]
                        },
                        stroke: {type: 'stroke', style: "none", color: "#0f62fe", width: 1},
                        selectedStyle: {
                            stroke: {type: 'stroke', color: '#A6C8FF', width: 1}
                        }
                    },
                    {	dojoAttachPoint: 'higlightShape',
                        halign: 'center', valign: 'center',		            
                        svgType: 'stepTemplate',
                        shape: {x: 0, y: 0, type: 'rect', width: 92, height: 67, r: 4},
                        selectedStyle: {
                            stroke: {type: 'outline', color: '#A6C8FF', width: 2, offset: '4px'}
                    }
                    },
                    {	dojoAttachPoint: 'textShape',
                        halign: 'stretch',
                        valign: 'center',
                        margins: [5, 5, 5, 0],
                        // See extension of the '_createLines' function from iLog's MultilineText.js in BaseDiagram.js. 'isStepText', 'hasStepIcon'
                        // 'topIcon' and 'bottomIcon' are additional parameters passed in the template to control the margins of the text in the
                        // step template. This is to align the text properly after the SVG text lines have been created.
                        // 'firstLineOffset' is used in the extension of the 'wrap' function from iLog's MultilineText.js in BaseDiagram.js.
                        shape: {isStepText: true, hasStepIcon: true, firstLineOffset: 15, topIcon: false, bottomIcon: false, align: 'middle', text: '{{label|safe}}',
x:0, y:0, type: 'mltext', wrap: true, wordWrap: true, width: 85, height: 70, spacing: -0.5},
                        fill: {r: 0, g: 0, b: 0, a: 1},
                        font: {type: 'font', weight: 'normal', size: '9pt', family: 'IBM Plex Sans'},
                        editable: {
                                                            id:'label', editor:'textbox', border:2//, 
                        }
                    },
                    {	dojoAttachPoint: 'stepTypeAdorner',
                        margins: [3, 2, 2, -2], 
                        halign: 'left', valign: 'top',
                        svgType: "stepTypeAdorner",
                        shape: {
                            x: 0, y:0,
                            width: 0,
                            height: 0,
                            type: 'image'
                        }
                    }
                ]
            }
        ]
    },

/**
    Template used to create a decorator for the iBPM work. 
    A picture of a person with a green or red dot in the upper right corner and the name on top.
 **/
 iBPMTemplate: {
        
        layout: {
            type: 'ibm_ilog.diagram.gfxlayout.StackLayout'
        },
        children: [
            {
                shape: {
                        align: 'middle',
                        text: '{{data.label|safe}}',
                        type: 'text',
                        width: 42
                    },
                    fill: {
                        r: 0,
                        g: 0,
                        b: 0,
                        a: 1
                    },
                    font: {
                        type: 'font',
                        weight: 'normal',
                        size: '11.5pt',
                        family: 'arial'
                    }
            },
            {
                halign: 'center',
                layout: {
                    type: 'ibm_ilog.diagram.gfxlayout.GridLayout'
                },
                children: [{
                    dojoAttachPoint: 'baseShape',
                    shape: {
                        width: 42,
                        height: 42,
                        src: './images/bwGateway.png',
                        type: 'image'
                    }
                },
        
                {
                    dojoAttachPoint: 'status',
                    valign: 'top',
                    halign: 'right',
                    margins: [5,5, 5, 5],
                    shape: {
                        type: 'circle',
                        r: 5
                        
                    },
                    stroke: 'black',
                    fill: 'green'
                }]
            }
        ]
    },
 
  borderTemplate:  {
           
            valign: 'center',
            halign: 'right',
            dojoAttachPoint: '_border',
            layout: {
                type: 'ibm_ilog.diagram.gfxlayout.GridLayout'
            },
            children: [{
                shape: {
                   width: 95,
                   height: 70,
                   src: '/BPMN/com/ibm/bpm/wpd/images/BPD/EVSP_-_Default_Outline_95x70.gif',
                   type: 'image'
                },
                stroke: 'black'

            }]
        },




    milestoneTemplate: {
        layout: {
            type: 'ibm_ilog.diagram.gfxlayout.StackLayout'
        },
        children: [{
            layout: {
                type: 'ibm_ilog.diagram.gfxlayout.GridLayout'
            },
            children: [{
                dojoAttachPoint: 'baseShape',
                shape: {
                    x: 0,
                    y: 0,
                    width: 250,
                    height: 25,
                    r: 1,
                    type: 'rect'
                },
                stroke: {
                    type: 'stroke',
                    color: 'black',
                    width: 1
                },
                fill: '#e0e0e0'
            },

            {
                dojoAttachPoint: 'textShape',
                halign: 'center',
                valign: 'center',
                shape: {
                    align: 'middle',
                    text: '{{label|safe}}',
                    y: 10,
                    x: 10,
                    type: 'text',
                    wrap: false,
                    width: 80
                },
                fill: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 1
                },
                font: {
                    type: 'font',
                    weight: 'normal',
                    size: '9pt',
                    family: 'sans-serif'
                }
            }]
        },

        {
            shape: {
                type: 'rect',
                width: 140,
                height: 275
            },
            
            stroke: {
                type: 'stroke',
                color: '#E0E3E7',
                width: 0.5

            },
            border: 1
        }

        ]
    },


    HPoolTemplate: [{
        dojoAttachPoint: '_expandedGroup',
        layout: {
            type: 'ibm_ilog.diagram.gfxlayout.GridLayout',
            cols: [{
                width: -1
            }, {}]
        },
        children: [{
            dojoAttachPoint: '_expandedBaseShape',
            column: 0,
            colspan: 2,
            shape: {
                type: 'rect',
                width: 0,
                height: 0
            },
            fill: '#e0e0e0',
            selectedStyle: {
                fill: '#9dbde4'
            },
            stroke: {
                type: 'stroke',
                color: 'black',
                width: 1
            },
            border: 1
        }, {
            dojoAttachPoint: '_header',
            column: 0,
            margins: [0, 2, 2, 2],
            minimumSize: {
                width: 22,
                height: -1
            },
            layout: {
                type: 'ibm_ilog.diagram.gfxlayout.GridLayout',
                rows: [{
                    height: -1
                }, {}]
            },
            stroke: {
                type: 'stroke',
                color: 'black',
                width: 1
            },
            children: [{
                dojoAttachPoint: '_collapseButton',
                row: 0,
                column: 0,
                halign: 'center',
                valign: 'center',
                layout: {
                    type: 'ibm_ilog.diagram.gfxlayout.GridLayout'
                },
                children: [{
                    shape: {
                        type: 'rect',
                        x: 0,
                        y: 0,
                        width: 12,
                        height: 12
                    }
                }]
            }, {
                row: 1,
                dojoAttachPoint: 'titleShape',
                halign: 'center',
                valign: 'stretch',
                transform: {
                    xx: 0,
                    xy: 1,
                    yx: -1,
                    yy: 0
                },
                shape: {
                    type: 'text',
                    text: '{{label|safe}}',
                    align: 'middle'
                },
                fill: 'black',
                font: {
                    type: 'font',
                    size: '10pt',
                    family: 'sans-serif'
                }
            }]
        }, {
            dojoAttachPoint: '_graphRect',
            column: 1,
            shape: {
                type: 'rect',
                width: 0,
                height: 0
            }
        }, {
            dojoAttachPoint: '_graphBackground',
            column: 1,
            margins: 1,
            shape: {
                type: 'rect',
                width: 0,
                height: 0
            },
            fill: '#f8f8f8'
        }, {
            column: 1,
            row: 0,
            margins: 0,
            halign: 'left',
            valign: 'top',
            children: [{
                shape: {
                    type: 'rect',
                    x: 0,
                    y: 0,
                    width: 0,
                    height: 0
                }
            }, {
                dojoAttachPoint: '_graph',
                shape: {
                    type: 'graph'
                }
            }]
        }]
    }],


   eventTemplate: {
        layout: {
            type: 'ibm_ilog.diagram.gfxlayout.StackLayout'
        },
        children: [{
            dojoAttachPoint: 'baseShape',
            transform: {
                dx: 1,
                dy: 1
            },
            halign: 'center',
            shape: {
                width: 24,
                height: 24,
                src: '/BPMN/com/ibm/bpm/wpd/images/BPD/start_event_25x25.png',
                type: 'image'
            }
        }, {
            dojoAttachPoint: 'textShape',
            shape: {
                align: 'middle',
                text: '{{label|safe}}',
                type: 'mltext',
                width: 90,
                wrap: false
            },
            fill: {
                r: 0,
                g: 0,
                b: 0,
                a: 1
            },
            font: {
                type: 'font',
                weight: 'normal',
                size: '11pt',
                family: 'Arial'
            }
        }]
    },

    // The circular shape used for events -----------------------------------------------------------------------------
    //  - An icon describes the shape.
    //  - A text shape below the shape holds text (e.g. name)
    eventTemplate2: {
        layout: { type: 'ibm_ilog.diagram.gfxlayout.StackLayout' },
        children: [
            {   
                halign: 'right',
                dojoAttachPoint: 'counter',
                layout: {
                    type: 'ibm_ilog.diagram.gfxlayout.StackLayout',
                    horizontal:true,
                    paddingBottom: 5,
                    paddingRight: 10
                },
                children: [
                    {	
                        shape: {
                            text: '{{data.counter}}',
                            type: 'text',
                            width: 80
                        },
                        fill: {
                            r: 0,
                            g: 0,
                            b: 0,
                            a: 1
                        },
                        font: {type: 'font', weight: 'normal', size: '9pt', family: 'IBM Plex Sans'}
                    }
                ]
            },
            {
                svgType: 'eventTemplate',
                layout: { type: 'ibm_ilog.diagram.gfxlayout.GridLayout' },
                children:[
                    
                    {	dojoAttachPoint: 'baseShape',
                        halign: 'center', valign: 'center',	                    
                        svgType: 'eventTemplate',
                        shape: {r: 12, type: 'circle'},
                        fill: {r: 0, g: 0, b: 0, a: 0},
                        selectedStyle: {
                            stroke: {type: 'stroke', color: '#A6C8FF', width: 5} //blue40
                        }
                    },
                    {	dojoAttachPoint: 'icon',
                        transform: {dx:1, dy: 1},
                        halign: 'center',
                        shape: {width: 24, height: 24, type: 'image'}
                    }
                ]
            },
            {	layout: { type: 'ibm_ilog.diagram.gfxlayout.GridLayout' },
                children:[
                    {	dojoAttachPoint: 'textShape',
                        halign: 'center', valign: 'top',
                        shape: {align: 'middle', text: '{{label|safe}}', type: 'mltext', width: 90, height: 70, wrap: true, wordWrap: true},
                        fill: {r: 0, g: 0, b: 0, a: 1},
                        margins: [3, 6, 3, 3],
                        font: {type: 'font', weight: 'normal', size: '9pt', family: 'IBM Plex Sans'},
                        editable: {
                            id:'label', editor:'textbox', border:2//, 
                        }
                    }
                ]
            }
        ]
    },	    

// The diamond shape used for gateways -----------------------------------------------------------------------------
//  - An icon describes the shape.
//  - A text shape below the shape holds text (e.g. name)
gatewayTemplate: {
    layout: { type: 'ibm_ilog.diagram.gfxlayout.StackLayout' },
    children: [{
        svgType: 'gatewayTemplate',
        layout: { type: 'ibm_ilog.diagram.gfxlayout.GridLayout' },
        children:[
            {	dojoAttachPoint: 'baseShape',
                halign: 'center', valign: 'center',	                    
                svgType: 'eventTemplate',
                shape: {width: 32, height: 32, type: 'rect'},
                transform: {xx: 0.5, xy: 0.5, yx: -0.5, yy: 0.5},	// Rotate 45 degrees.
                fill: {r: 0, g: 0, b: 0, a: 0},
                selectedStyle: {
                    stroke: {type: 'stroke', color: '#A6C8FF', width: 7} //blue40
                }
            },
            {	dojoAttachPoint: 'icon',
                transform: {dx: 1, dy: 1},
                halign: 'center',
                shape: {width: 32, height: 32, type: 'image'}
            }
        ]
    },
    {	layout: { type: 'ibm_ilog.diagram.gfxlayout.GridLayout' },
        children:[
                {	dojoAttachPoint: 'textShape',
                    shape: {align: 'middle', text: '{{label|safe}}', type: 'mltext', width: 90, height: 70, wrap: true, wordWrap: true},
                    fill: {r: 0, g: 0, b: 0, a: 1},
                    margins: [3, 6, 3, 3],
                    font: {type: 'font', weight: 'normal', size: '9pt', family: 'IBM Plex Sans'},
                    editable: {
                        id:'label', editor:'textbox', border:2//, 
                    }
                }
            ]
    }
    ]
},


 activityEventTemplate: {

        layout: {
            type: 'ibm_ilog.diagram.gfxlayout.StackLayout'
        },
        children: [
        {
            dojoAttachPoint: 'counter',
            shape: {
                    align: 'middle',
                    text: '{{data.counter}}',
                    type: 'text',
                    width: 80
                },
                fill: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 1
                },
                font: {
                    type: 'font',
                    weight: 'normal',
                    size: '11.5pt',
                    family: 'arial'
                }
        },

        {
            dojoAttachPoint: 'baseShape',
            transform: {
                dx: 1,
                dy: 1
            },
            halign: 'center',
            shape: {
                width: 24,
                height: 24,
                src: '/BPMN/com/ibm/bpm/wpd/images/BPD/start_event_25x25.png',
                type: 'image'
            }
        }]
    },

    activityHalo: {
      
        valign: 'center',
        halign: 'center',
        shape : {
            type: 'rect',
            width: 95,
            height: 70,
            r: 3
        },
        stroke: {
            color: 'yellow',
            width: 6
        }
        
    },

  eventHalo: {
      
        valign: 'center',
        halign: 'center',
        shape : {
            type: 'circle',
            r: 13
        },
        stroke: {
            color: 'yellow',
            width: 6
        }
        
    },


  expandButton:  {
            margins: 8,
            valign: 'bottom',
            halign: 'right',
            dojoAttachPoint: '_expandButton',
            layout: {
                type: 'ibm_ilog.diagram.gfxlayout.GridLayout'
            },
            children: [{
                shape: {
                    width: 7,
                    height: 7,
                    src: '/BPMN/com/ibm/bpm/wpd/images/BPD/sub_bpd_7x7.png',
                    type: 'image'
                },
                stroke: 'black'

            }]
        },


  activityIcon:  {
            margins: [2, 2, 2, 2],
            valign: 'center',
            halign: 'right',
            
            layout: {
                type: 'ibm_ilog.diagram.gfxlayout.GridLayout'
            },
            children: [{
                halign: 'left',
                valign: 'center',

                shape: {
                    width: 12,
                    height: 12,
                    src: '/BPMN/com/ibm/bpm/wpd/images/BPD/start_event_25x25.png',
                    type: 'image'
                },
                stroke: 'black'

            }

            ]
        },

        decoratorIcon:  {
            margins: 4,
            valign: 'center',
            halign: 'right',
            
            layout: {
                type: 'ibm_ilog.diagram.gfxlayout.GridLayout'
            },
            children: [{
                halign: 'left',
                valign: 'center',

                shape: {
                    width: 12,
                    height: 12,
                    src: '/BPMN/com/ibm/bpm/wpd/images/BPD/start_event_25x25.png',
                    type: 'image'
                },
                stroke: 'black'

            },
            {
	    	dojoAttachPoint: 'decoratorCount',
                halign: 'right',
                valign: 'center',
               margins: [20, 0, 0, 0],
                shape: {
                    type: 'text',
                    text: '{{data.decoratorCount}}',
                    align: 'middle'
                },
                fill: 'black',
                font: {
                    type: 'font',
                    size: '9pt',
                    family: 'arial'
                }            
            }

            ]
        },


 swimlaneTemplate : [{
    dojoAttachPoint: '_expandedGroup',
    layout: {
        type: 'ibm_ilog.diagram.gfxlayout.GridLayout',
        cols: [{
            width: -1
        }, {}]
    },
    children: [{
        dojoAttachPoint: '_expandedBaseShape',
        column: 0,
        colspan: 2,
        shape: {
            type: 'rect',
            width: 0,
            height: 0
        },
        fill: '#e0e0e0',
        selectedStyle: {
            fill: '{{selectedHeaderColor}}'
        },
        stroke: '#404040'
    }, {
        dojoAttachPoint: '_header',
        column: 0,
        margins: [0, 2, 2, 2],
        layout: {
            type: 'ibm_ilog.diagram.gfxlayout.GridLayout',
            horizontalFlow: false,
            rows: [{
                height: -1
            }, {}]
        },
        children: [{
            dojoAttachPoint: '_collapseButton',
            halign: 'center',
            valign: 'top',
            layout: {
                type: 'ibm_ilog.diagram.gfxlayout.GridLayout'
            },
            children: [{
                shape: {
                    type: 'rect',
                    x: 0,
                    y: 0,
                    width: 1,
                    height: 1
                },
                fill: '#808080'
            }]
        }, {layout: {type: 'ibm_ilog.diagram.gfxlayout.GridLayout'
            },
            children: [{
                dojoAttachPoint: 'titleShape',
                halign: 'center',
                valign: 'stretch',
                transform: {
                    xx: 0,
                    xy: 1,
                    yx: -1,
                    yy: 0
                },
                shape: {
                    type: 'text',
                    text: '{{label|safe}}',
                    align: 'middle'
                },
                fill: '{{textColor}}',
                font: {
                    type: 'font',
                    size: '10pt',
                    family: 'sans-serif'
                },
                
                selectedStyle: {
                    fill: '{{selectedTextColor}}'
                }
            }]
        }]
    }, {
        dojoAttachPoint: '_graphRect',
        shape: {
            type: 'rect',
            width: 0,
            height: 0
        },
        border: 1,
        stroke: 'black'
    }, {
        dojoAttachPoint: '_graphBackground',
        column: 1,
        margins: 1,
        shape: {
            type: 'rect',
            width: 0,
            height: 0
        },
        fill: '{{graphBackgroundColor}}'
    }, {
        column: 1,
        row: 0,
        margins: 0,
        halign: 'left',
        valign: 'top',
        children: [{
            shape: {
                type: 'rect',
                x: 0,
                y: 0,
                width: 0,
                height: 0
            }
        }, {
            dojoAttachPoint: '_graph',
            shape: {
                type: 'graph'
            }
        }]
    }]
}],


flashSwimlaneTemplate : [{
    dojoAttachPoint: '_expandedGroup',
    layout: {
        type: 'ibm_ilog.diagram.gfxlayout.GridLayout',
        cols: [{
            width: -1
        }, {}]
    },
    children: [{
        dojoAttachPoint: '_expandedBaseShape',
        column: 0,
        colspan: 2,
        shape: {
            type: 'rect',
            width: 0,
            height: 0
        },
        fill: '#e0e0e0',
        selectedStyle: {
            fill: '{{selectedHeaderColor}}'
        },
        stroke: '#404040'
    }, {
        dojoAttachPoint: '_header',
        column: 0,
        margins: [0, 2, 2, 2],
        layout: {
            type: 'ibm_ilog.diagram.gfxlayout.GridLayout',
            horizontalFlow: false,
            rows: [{
                height: -1
            }, {}]
        },
        children: [{
            dojoAttachPoint: '_collapseButton',
            halign: 'center',
            valign: 'top',
            layout: {
                type: 'ibm_ilog.diagram.gfxlayout.GridLayout'
            },
            children: [{
                shape: {
                    type: 'rect',
                    x: 0,
                    y: 0,
                    width: 1,
                    height: 1
                },
                fill: '#808080'
            }]
        }, {layout: {type: 'ibm_ilog.diagram.gfxlayout.GridLayout'
            },
            children: [{
                dojoAttachPoint: 'titleShape',
                halign: 'center',
                valign: 'center',
                margins: [2,2,2,2],
                shape: {
                    
                    width: 25,
                    height: 150,
                    
                    src: bootstrap.getEndPointAndContextRootForModule(bootstrap.wpdConstant.BPM_WARNAME_WEBVIEWER) + '/widgets/com/ibm/bpm/wpd/images/BPD/SLHeader.gif',
                    type: 'image'
                },
                fill: '{{textColor}}',
             
                
                selectedStyle: {
                    fill: '{{selectedTextColor}}'
                }
            }]
        }]
    }, {
        dojoAttachPoint: '_graphRect',
        shape: {
            type: 'rect',
            width: 0,
            height: 0
        }
    }, {
        dojoAttachPoint: '_graphBackground',
        column: 1,
        margins: 1,
        shape: {
            type: 'rect',
            width: 0,
            height: 0
        },
        fill: '{{graphBackgroundColor}}'
    }, {
        column: 1,
        row: 0,
        margins: 0,
        halign: 'left',
        valign: 'top',
        children: [{
            shape: {
                type: 'rect',
                x: 0,
                y: 0,
                width: 0,
                height: 0
            }
        }, {
            dojoAttachPoint: '_graph',
            shape: {
                type: 'graph'
            }
        }]
    }]
}],

// Small 7x7 Icons for pre/post-assignments, conditional markers -------------------------------------------------
smallAdornerIconTemplate:  {
    margins: [3, 3, 3, 3], 
    valign: 'center', halign: 'left',
    layout: { type: 'ibm_ilog.diagram.gfxlayout.GridLayout' },
    children: [{
        halign: 'center', valign: 'center',
        shape: {
            width: 7, height: 7,
            type: 'image'
        },
        stroke: 'black'
    }]
},

// Large 8x11 Icons for pre/post tracking on activities -------------------------------------------------
largeTrackingIconTemplate:  {
    margins: [3, 3, 3, 1], 
    valign: 'center', halign: 'left',
    layout: { type: 'ibm_ilog.diagram.gfxlayout.GridLayout' },
    children: [{
        halign: 'center', valign: 'center',
        shape: {
            width: 6, height: 11,
            type: 'image'
        }
    }]
},   
// Medium 8x12 Icons for pre/post tracking on events and gateway -------------------------------------------------
mediumTrackingIconTemplate:  {
    margins: [3, 3, 3, 3], 
    valign: 'center', halign: 'left',
    layout: { type: 'ibm_ilog.diagram.gfxlayout.GridLayout' },
    children: [{
        halign: 'center', valign: 'center',
        shape: {
            width: 7, height: 12,
            type: 'image'
        }
    }]
}, 

contentAdornerTemplate:  {
    dojoAttachPoint: 'contentAdorner',
    svgType: "contentAdorner",
    margins: [0, 1, 0, 1],
    halign: 'center', valign: 'bottom',
    shape: {width: 12, height: 12, type: 'image'}
},

counterIconTemplate:  {
    shape: {
        width: 20,
        height: 20,
        type: 'image'
    }
},

/**
Return the appropriate node template (GFX diagram) for a step node.
@param iconURL The url for where the images are located
@param stepTypeIcon An optional icon that adorns the step at the top left position.
@param colourName An optional colour name. One of: 'blue', 'gray', 'green', 'orange', 'purple', 'red', 'yellow', 'brightyellow', 'lightyellow'
@param counter An optional boolean whether to have the counter icon and number on top
@param hasPreAssignment An optional boolean indicating that the step has a pre-assignment
@param hasPostAssignment An optional boolean indicating that the step has a post-assignment
@param hasPreTracking An optional boolean indicating that the step has a pre-tracking point
@param hasPostTracking An optional boolean indicating that the step has a post-tracking point
@param isConditional An optional boolean indicating that the step has conditional logic
@param contentIcon An optional icon or array of icons that adorn the step at the bottom center position.
@param border An optional border name. One of: 'solid' or 'dashed'
@param hasPageLoadEvent An optional boolean indicating that the step has a page-load event

**/
getStepTemplate: function(iconURL, stepTypeIcon, colourName, counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking, isConditional, contentIcon, border, loopType) {
    var template = lang.clone (this.stepTemplate);
    
    if (stepTypeIcon) {
        var image = this.templateQuery( template, 'stepTypeAdorner');
        if (image && image.shape) {
            image.shape.src = stepTypeIcon;
            image.shape.width = 16;
            image.shape.height = 16;
        }
    }

    var adornerIcon;
    var textNode;
    var children;

    // According to the BPMN specification, the loop icon should be in the bottom center (same place as the contentIcon).
    // If there is both a loop and a content icon, the content icon should be placed first, and the loop icon second.
    if (loopType && (loopType !== "None")) {
        var adornerImage = null;
        switch (loopType) {
            case "SimpleLoop":
                adornerImage = iconURL + 'loop.svg';
                break;
            case "MultipleLoop":
                adornerImage = iconURL + 'Parallel_MI_marker.svg';
                break;
            case "MultipleLoopSequential":
                adornerImage = iconURL + 'Sequential_MI_marker.svg';
                break;
        }

        if (!contentIcon) {
            contentIcon = adornerImage;
        } else if (Array.isArray (contentIcon)) {
            contentIcon.push (adornerImage);
        } else {
            var newIcons = [adornerImage, contentIcon];		// Looping comes first, then content icon.
            contentIcon = newIcons;
        }
    }

    if (contentIcon) {
        var contentTemplate;
        if (lang.isArray(contentIcon)){
            // arrange multiple content icons in a horizontal stack layout
            contentTemplate = 
            {	
                dojoAttachPoint: 'contentAdorner',
                margins: 0, 
                halign: 'center', valign: 'bottom',
                layout:{
                        type:'ibm_ilog.diagram.gfxlayout.StackLayout',
                        horizontal:true,
                        gap:0,
                        padding:[0,0,0,0]},
                children:[]		          
            };
            
            // for each content icon, create a child template
            for (var i=0; i < contentIcon.length; i++){
                var cTemplate = lang.clone (this.contentAdornerTemplate);
                if (cTemplate && cTemplate.shape) {
                    cTemplate.shape.src = contentIcon[i];
                    contentTemplate.children.push (cTemplate);
                }
            }
        } else {
            // there is only one content icon
            contentTemplate = lang.clone (this.contentAdornerTemplate);
            if (contentTemplate && contentTemplate.shape) {
                contentTemplate.shape.src = contentIcon;	
            }
        }
        
        if (contentTemplate){	
            children = template.children[1].children;
            children.push (contentTemplate);
        }
    }
    
    var baseShape = this.templateQuery (template, 'baseShape');
    var higlightShape = this.templateQuery(template, 'higlightShape');

    if (!colourName || (colourName === "") || colourName == "#A5B7CD"){
        colourName = this.DEFAULT_COLOR_CYAN;
    }
    var color = colourName;
    var strokeColor = this.getStrokeColor(color);
    if (baseShape) {
        if (baseShape.fill && baseShape.fill.colors) {
            baseShape.fill.colors[1].color = color;
            baseShape.stroke.color = strokeColor;
            baseShape.selectedStyle.stroke.color = "#A6C8FF"; //blue 40
            baseShape.selectedStyle.stroke.width = 4;
            higlightShape.selectedStyle.stroke.color = strokeColor;
            higlightShape.selectedStyle.stroke.width = 1;
        }
        var stroke = baseShape.stroke;
        if (stroke && border) {
            stroke.color = strokeColor;
            stroke.width = 2;
            if (border === "dashed") {
                stroke.style = "ShortDot";
            }
        }
    }

    var hasPreOrPostAssignmentAdornerIcon = false;
    if (hasPreAssignment && hasPreAssignment === true) {
        adornerIcon = lang.clone (this.smallAdornerIconTemplate);				
        if (adornerIcon) {
            adornerIcon.valign = "center";
            adornerIcon.halign = "left";
            adornerIcon.children[0].shape.src = iconURL + 'pre-post-assignment_adorner.svg';
            adornerIcon.children[0].shape.width = 10;
            adornerIcon.children[0].shape.height = 10;
            template.children[1].children.push(adornerIcon);
            hasPreOrPostAssignmentAdornerIcon = true;
        }
    }
    if (hasPostAssignment && hasPostAssignment === true) {
        adornerIcon = lang.clone (this.smallAdornerIconTemplate);				
        if (adornerIcon) {
            adornerIcon.valign = "center";
            adornerIcon.halign = "right";
            adornerIcon.children[0].shape.src = iconURL + 'pre-post-assignment_adorner.svg';
            adornerIcon.children[0].shape.width = 10;
            adornerIcon.children[0].shape.height = 10;
            template.children[1].children.push(adornerIcon);
            hasPreOrPostAssignmentAdornerIcon = true;
        }
    }
    if (hasPreOrPostAssignmentAdornerIcon) {
        // Reduce the width of the text shape, to make room for the adorner icons on the left and/or right.
        // But keep the text shape centered, even if there is an adorner icon on only one side.
        textNode = this.templateQuery (template, 'textShape');
        if (textNode && textNode.shape) {
            textNode.shape.width = textNode.shape.width - 2*7;
            textNode.margins[0] = textNode.margins[0] + 7;
            textNode.margins[2] = textNode.margins[2] + 7;
        }
    }

    if (isConditional && isConditional === true) {
        adornerIcon = lang.clone (this.smallAdornerIconTemplate);
        if (adornerIcon) {
            adornerIcon.valign = "top";
            adornerIcon.halign = "center";
            adornerIcon.children[0].shape.src = iconURL + 'conditional_adorner.svg';
            adornerIcon.children[0].shape.width = 10;
            adornerIcon.children[0].shape.height = 10;
            template.children[1].children.push(adornerIcon);
        }
    }			

    var hasTracking = false;
    if (hasPreTracking && hasPreTracking === true){
        hasTracking = true;
        adornerIcon = lang.clone (this.largeTrackingIconTemplate);				
        if (adornerIcon) {
            adornerIcon.valign = "bottom";
            adornerIcon.halign = "left";
            adornerIcon.children[0].shape.src = iconURL + 'tracking_adorner.svg';
            template.children[1].children.push(adornerIcon);
        }			
    }
    
    if (hasPostTracking && hasPostTracking === true){
        hasTracking = true;
        adornerIcon = lang.clone (this.largeTrackingIconTemplate);				
        if (adornerIcon) {
            adornerIcon.margins = [3, 3, 1, 1];
            adornerIcon.valign = "bottom";
            adornerIcon.halign = "right";
            adornerIcon.children[0].shape.src = iconURL + 'tracking_adorner.svg';
            template.children[1].children.push(adornerIcon);
        }			
    }

    // Adjust the height of the text based on various adornments to the step.
    textNode = this.templateQuery (template, 'textShape');
    if (textNode && textNode.shape) {
        var linesOfText = 5;	// Maximum number of text lines is 5. Each lines is 14px tall, so maximum height = 14 * 5 = 70.

        if (isConditional) {
            linesOfText--;		// Remove a row of text.
            textNode.shape.topIcon = true;
        }

        if (contentIcon || hasTracking) {
            linesOfText--;		// Remove a row of text.
            textNode.shape.bottomIcon = true;
        }

        // Update the template.
        textNode.shape.height = linesOfText * 14;
        textNode.shape.hasStepIcon = stepTypeIcon ? true : false;	// Used to truncate first line of text.
    }

    if (counter){
        var counterIcon = lang.clone (this.counterIconTemplate);
        counterIcon.shape.src = iconURL + "token_hollow.png";
        template.children[0].children.unshift(counterIcon);
    }

    return template;
},

getEventSubProcessTemplate: function (iconURL, stepTypeIcon, colourName, counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking, isConditional, contentIcon) {
    var template = this.getSubProcessTemplate (iconURL, stepTypeIcon, colourName, counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking, isConditional, contentIcon, "dashed");
    return template;
},

getSubProcessTemplate: function (iconURL, stepTypeIcon, colourName, counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking, isConditional, contentIcon, border, loopType) {
    var template = this.getStepTemplate (iconURL, stepTypeIcon, colourName, counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking, isConditional, contentIcon, border, loopType);
    return template;
},

/**
Return the appropriate node template (GFX diagram) for an event node.
@param iconURL The url for where the images are located
@param eventTypeIcon An icon that indicates the event type. This icon fills the shape
@param counter An optional boolean whether to have the counter icon and number on top
@param hasPreAssignment An optional boolean indicating that the event has a pre-assignment
@param hasPostAssignment An optional boolean indicating that the event has a post-assignment
@param hasPreTracking An optional boolean indicating that the step has a pre-tracking point
@param hasPostTracking An optional boolean indicating that the step has a post-tracking point
**/
getEventTemplate: function(iconURL, eventTypeIcon, counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking) {
    var template = lang.clone (this.eventTemplate2);
    
    if (eventTypeIcon) {
        var image = this.templateQuery( template, 'icon');
        if (image && image.shape) {
            image.shape.src = eventTypeIcon;
        }
    }

    var adornerIcon;
    // The adornders need to be positioned relative to the center not horizontally aligned to the left, as the left side of
    // the node is the left side of the text box (label) that has a dynamic width based on the text contents.
    // Margins are: left, top, right, and bottom.
    if (hasPreAssignment && hasPreAssignment === true) {
        adornerIcon = lang.clone (this.smallAdornerIconTemplate);				
        if (adornerIcon) {
            adornerIcon.margins = [3, 3, 15, 3];
            adornerIcon.valign = "center";
            adornerIcon.halign = "center";
            adornerIcon.children[0].shape.src = iconURL + 'pre-post-assignment_adorner.svg';
            template.children[0].children.push(adornerIcon);
        }
    }

    if (hasPostAssignment && hasPostAssignment === true) {
        adornerIcon = lang.clone (this.smallAdornerIconTemplate);				
        if (adornerIcon) {
            adornerIcon.margins = [15, 3, 3, 3];
            adornerIcon.valign = "center";
            adornerIcon.halign = "center";
            adornerIcon.children[0].shape.src = iconURL + 'pre-post-assignment_adorner.svg';
            template.children[0].children.push(adornerIcon);
        }
    }
    
    if (hasPreTracking && hasPreTracking === true){
        adornerIcon = lang.clone (this.mediumTrackingIconTemplate);				
        if (adornerIcon) {
            adornerIcon.margins = [0, 3, 28, -5];
            adornerIcon.valign = "bottom";
            adornerIcon.halign = "center";
            adornerIcon.children[0].shape.src = iconURL + 'tracking_adorner.svg';
            template.children[0].children.push(adornerIcon);
        }			
    }
    
    if (hasPostTracking && hasPostTracking === true){
        adornerIcon = lang.clone (this.mediumTrackingIconTemplate);				
        if (adornerIcon) {
            adornerIcon.margins = [32, 3, 0, -5];
            adornerIcon.valign = "bottom";
            adornerIcon.halign = "center";
            adornerIcon.children[0].shape.src = iconURL + 'tracking_adorner.svg';	
            template.children[0].children.push(adornerIcon);
        }			
    }

    if (counter){
        var counterIcon = lang.clone (this.counterIconTemplate);
        counterIcon.shape.src = iconURL + "token_hollow.png";
        template.children[0].children.unshift(counterIcon);
    }
		
    return template;
},

/**
Return the appropriate node template (GFX diagram) for a gateway node.
@param gatewayTypeIcon An icon that indicates the gateway type. This icon fills the shape
@param hasPreAssignment An optional boolean indicating that the gateway has a pre-assignment
@param hasPostAssignment An optional boolean indicating that the gateway has a post-assignment
@param hasPreTracking An optional boolean indicating that the step has a pre-tracking point
@param hasPostTracking An optional boolean indicating that the step has a post-tracking point
**/
getGatewayTemplate: function(iconURL, gatewayTypeIcon, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking) {
    var template = lang.clone (this.gatewayTemplate);
    
    if (gatewayTypeIcon) {
        var image = this.templateQuery( template, 'icon');
        if (image && image.shape) {
            image.shape.src = gatewayTypeIcon;
        }
    }

    var adornerIcon;
    // The adorners need to be positioned relative to the center not horizontally aligned to the left, as the left side of
    // the node is the left side of the text box (label) that has a dynamic width based on the text contents.
    // Margins are: left, top, right, and bottom.
    if (hasPreAssignment && hasPreAssignment === true) {
        adornerIcon = lang.clone (this.smallAdornerIconTemplate);				
        if (adornerIcon) {
            adornerIcon.margins = [0, 3, 22, 3];
            adornerIcon.valign = "center";
            adornerIcon.halign = "center";
            adornerIcon.children[0].shape.src = iconURL + 'pre-post-assignment_adorner.svg';
            template.children[0].children.push(adornerIcon);
        }
    }

    if (hasPostAssignment && hasPostAssignment === true) {
        adornerIcon = lang.clone (this.smallAdornerIconTemplate);				
        if (adornerIcon) {
            adornerIcon.margins = [22, 3, 0, 3];
            adornerIcon.valign = "center";
            adornerIcon.halign = "center";
            adornerIcon.children[0].shape.src = iconURL + 'pre-post-assignment_adorner.svg';
            template.children[0].children.push(adornerIcon);
        }
    }

    if (hasPreTracking && hasPreTracking === true){
        adornerIcon = lang.clone (this.mediumTrackingIconTemplate);				
        if (adornerIcon) {
            adornerIcon.margins = [0, 5, 28, -1];
            adornerIcon.valign = "bottom";
            adornerIcon.halign = "center";
            adornerIcon.children[0].shape.src = iconURL + 'tracking_adorner.svg';
            template.children[0].children.push(adornerIcon);
        }			
    }

    if (hasPostTracking && hasPostTracking === true){
        adornerIcon = lang.clone (this.mediumTrackingIconTemplate);				
        if (adornerIcon) {
            adornerIcon.margins = [32, 5, 0, -1];
            adornerIcon.valign = "bottom";
            adornerIcon.halign = "center";
            adornerIcon.children[0].shape.src = iconURL + 'tracking_adorner.svg';
            template.children[0].children.push(adornerIcon);
        }			
    }				
    
    return template;
},

/**
Walk a given template looking for an object with the appropriate dojoAttachPoint.
Easy way to isolate the view code from changes in the template.
**/
templateQuery: function( template, attachpoint ){
    var i;
    var child;
    var shape;
    if (lang.isArray(template)) {
        for (i = 0; i < template.length; i++) {
            child = template[i];
            shape = this.templateQuery( child, attachpoint);
            if (shape) {
                return shape;
            }
        }     
    } else {
        var name = template.dojoAttachPoint;
        var children = template.children;

        if (name && name == attachpoint) {
            return template;
        } else if (children) {
            for (i = 0; i < children.length; i++) {
                child = children[i];
                shape = this.templateQuery( child, attachpoint);
                if (shape) {
                    return shape;
                }
            }     
        } else {
            return undefined;
        }
    }
},

getStrokeColor: function (colorName) {
    //if color name is undefined
    if (!colorName || (colorName === ""))
        return "#0f62fe";
    //if the input is already a colorHex
    switch (colorName) {
        case "#95D087":
            return "#198038";
        case this.DEFAULT_COLOR_MAGENTA:
            return "#9f1853";
        case this.DEFAULT_COLOR_COOLGRAY:
            return "#AAAAAA";
        case this.DEFAULT_COLOR_GREEN:
            return this.DEFAULT_STROKE_GREEN;
        case this.DEFAULT_COLOR_CYAN:
            return this.DEFAULT_STROKE_CYAN;
        case this.DEFAULT_COLOR_PURPLE:
            return this.DEFAULT_STROKE_PURPLE;
        case this.DEFAULT_COLOR_TEAL:
            return this.DEFAULT_STROKE_TEAL;
        case this.DEFAULT_COLOR_YELLOW:
            return this.DEFAULT_STROKE_YELLOW;
        default:
            return "#000000"; //black is default

    }
}
        
        

});

});
