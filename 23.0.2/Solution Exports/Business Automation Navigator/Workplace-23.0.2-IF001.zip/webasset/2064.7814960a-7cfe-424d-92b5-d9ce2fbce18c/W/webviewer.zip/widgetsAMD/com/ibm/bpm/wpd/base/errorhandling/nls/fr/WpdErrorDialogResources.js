define({      
//begin v1.x content
    errorDialogTitle: "Erreur IBM BPM",
    moreDetails: "Plus de détails...",
    closeMessage: "Fermer tous les messages d'erreur",
    contentMessage: "Une erreur s'est produite."
//end v1.x content
});

