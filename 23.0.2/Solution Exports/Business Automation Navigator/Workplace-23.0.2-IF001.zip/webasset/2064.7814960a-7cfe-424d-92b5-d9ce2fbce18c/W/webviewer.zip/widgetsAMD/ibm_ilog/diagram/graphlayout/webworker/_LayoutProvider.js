/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"require",
"dojo/_base/declare",
"ibm_ilog/graphlayout/ILayoutProvider",
"ibm_ilog/graphlayout/MultipleLayout",
"./_GraphAdapter"
], function(
require,
declare,
ILayoutProvider,
MultipleLayout,
_GraphAdapter
){

var layoutClasses = {
    circular: 		"ibm_ilog.graphlayout.circular.CircularLayout",
    forcedirected: 	"ibm_ilog.graphlayout.forcedirected.ForceDirectedLayout",
    grid: 			"ibm_ilog.graphlayout.grid.GridLayout",
    hierarchical: 	"ibm_ilog.graphlayout.hierarchical.HierarchicalLayout",
    longlink: 		"ibm_ilog.graphlayout.longlink.LongLinkLayout",
    random: 		"ibm_ilog.graphlayout.random.RandomLayout",
    shortlink: 		"ibm_ilog.graphlayout.shortlink.ShortLinkLayout",
    tree: 			"ibm_ilog.graphlayout.tree.TreeLayout"
};

/*=====
var ILayoutProvider = ibm_ilog.graphlayout.ILayoutProvider;
=====*/

var _LayoutProvider =
declare("ibm_ilog.diagram.graphlayout.webworker._LayoutProvider", ILayoutProvider, {
  
  getGraphLayout : function(graphModel)
  {
     var graph = graphModel._graph;
     var nodeLayout = this._getLayout(graph, graph.nodeLayout);
     var linkLayout = this._getLayout(graph, graph.linkLayout);
     var res = null;
     if (nodeLayout == null && linkLayout == null)
       res = null; // This means no layout at all for the current graph model
     else if (nodeLayout == null)
       res = linkLayout;
     else if (linkLayout == null)
       res = nodeLayout;
     else
        res = new MultipleLayout(nodeLayout, linkLayout);
     
     if (res != null && res.getGraphModel() == null) 
       res.attach(new _GraphAdapter(graph));

     this._setObjProperties(graph.nodes, nodeLayout, linkLayout);
     this._setObjProperties(graph.links, nodeLayout, linkLayout);
     
     return res;
  },
  
  _getLayout : function(graph, layoutObj)
  {
    if(!layoutObj)
      return null;
    
    // already created and cached?
    var layout = layoutObj._layout;
    if(layout)
      return layout;
    
    var layoutClass = layoutClasses[layoutObj.algorithm];
	var constr;
	// loader MUST be in symchronous mode!
    require([layoutClass.replace(/\./g, '/')], function(c) { constr = c; });
    layout = new constr();
    
    // store for reuse
    layoutObj._layout = layout;
    
    // set layout properties
    this._setProperties(layout, layoutObj);
    
    // create hierarchical constraints
    if(layoutObj.constraints)
      this._createConstraints(layout, layoutObj.constraints, graph);
    
    return layout;
  },
  
  _setObjProperties : function(a, nodeLayout, linkLayout)
  {
    if(a){
      for(var i = 0; i < a.length; i++){
        var obj = a[i];
        if(nodeLayout && obj.parentNodeLayout)
          this._setProperties(nodeLayout, obj.parentNodeLayout, obj);
        if(linkLayout && obj.parentLinkLayout)
          this._setProperties(linkLayout, obj.parentLinkLayout, obj);
      }
    }
  },
  
  _setProperties: function(layout, props, obj)
  {
    var defltObj = {};
    for(var p in props){
      if(p == "algorithm" || p == "constraints" || p in defltObj)
        continue;
      var setter = "set" + p.charAt(0).toUpperCase() + p.substr(1);
      var f = layout[setter];
      if(typeof(f) == "function"){
        var v = props[p];
        // convert points and rectangles
        if(v instanceof Array){
          if(v.length == 2)
            v = { x:v[0], y:v[1] };
          else if(v.length == 4)
            v = { x:v[0], y:v[1], width:v[2], height:v[3] };
        }
        if(obj)
          f.call(layout, obj, v);
        else
          f.call(layout, v);
      }
    }
  },
  
  _createConstraints: function(layout, constraints, graph)
  {
    // find the id -> node hash, stored in the toplevel graph object
    var idToNode = graph._idToNode;
    while(!idToNode){
      graph = graph._parent;
      idToNode = graph._idToNode;
    }

    var ca = [];

    for(var i = 0; i < constraints.length; i++){
      var obj = constraints[i];
      var c = null;
      var className = "ibm_ilog.graphlayout.hierarchical.Hierarchical" + obj.name;
	  // loader MUST be in symchronous mode!
 	  var constr;
      require([className.replace(/\./g, '/')], function(c) { constr = c; });
      switch(obj.name){
      case "LevelRangeConstraint":
        c = new constr(this._getNodeGroup(obj.nodes, idToNode), obj.minLevel, obj.maxLevel);
        break;
      case "GroupSpreadConstraint":
        c = new constr(this._getNodeGroup(obj.nodes, idToNode), obj.spreadSize);
        break;
      case "RelativeLevelConstraint":
        c = new constr(this._getNodeGroup(obj.lowerNodes, idToNode), this._getNodeGroup(obj.higherNodes, idToNode), obj.priority);
        break;
      case "ExtremityConstraint":
        c = new constr(this._getNode(obj.node, idToNode), obj.side);
        break;
      case "RelativePositionConstraint":
        c = new constr(this._getNodeGroup(obj.lowerNodes, idToNode), this._getNodeGroup(obj.higherNodes, idToNode), obj.priority);
        break;
      case "SameLevelConstraint":
        c = new constr(this._getNode(obj.firstNode, idToNode), this._getNode(obj.secondNode, idToNode));
        break;
      case "SideBySideConstraint":
        c = new constr(this._getNodeGroup(obj.nodes, idToNode), obj.priority);
        break;
      case "SwimLaneConstraint":
        c = new constr(this._getNodeGroup(obj.nodes, idToNode), obj.relativeSize, obj.specPositionIndex, obj.westMinMargin, obj.eastMinMargin);
        break;
      }
      
      if(c)
        ca.push(c);
    }
    
    // constraints are sent in reverse order, so add them in reverse order too.
    for(var i = ca.length - 1; i >= 0; i--)
      layout.addConstraint(ca[i]);
  },
  
  _getNodeGroup: function(nodes, idToNode)
  {
  	var constr;
    require(["ibm_ilog/graphlayout/hierarchical/HierarchicalNodeGroup"], function(c) { constr = c; });
    var group = new constr();
    for(var i = 0; i < nodes.length; i++)
      group.add(idToNode[nodes[i].id]);
    return group;
  },
  
  _getNode: function(obj, idToNode)
  {
    return idToNode[obj.id];
  }
});

return _LayoutProvider;

});

