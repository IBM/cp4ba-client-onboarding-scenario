/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"./UserCustomizedAction",
"./UndoActionList"
], function(
declare,
UserCustomizedAction,
UndoActionList
){

/*=====
var UserCustomizedAction = ibm_ilog.diagram.editor.undo.UserCustomizedAction;
=====*/

	var DropAction = 
	declare("ibm_ilog.diagram.editor.undo.DropAction", [UserCustomizedAction], {
		//	
		// summary:
		//		this action undo/redo any drop action.
		//		This action must be modified for the user if any user defined action is done on a drop action.
		//
		_droppedItem: null,
		_droppedPosition: null,
		_elementsList: null,
		_dropInteractor: null,
		
	constructor:function(){
		//	
		// summary:
		//		creates a new instance, setting the corresponding label
		this._label = UndoActionList.Drop;
	},
	setDroppedItem: function(droppedItem){
		//	
		// summary:
		//		sets the dropped item
		this._droppedItem = droppedItem;
	},
	getDroppedItem: function(){
		//	
		// summary:
		//		gets the dropped item
		return this._droppedItem;
	},
	setDroppedPosition: function(droppedPosition){
		//	
		// summary:
		//		sets the dropped position (graph coordinates)
		this._droppedPosition = droppedPosition;
	},
	getDroppedPosition: function(){
		//	
		// summary:
		//		gets the dropped position (graph coordinates)
		return this._droppedPosition;
	},
	setElementsList: function(elementsList){
		//	
		// summary:
		//		sets the elements list, that contains the graph elements that match to the dropped position
		this._elementsList = elementsList;
	},
	getElementsList: function(){
		//	
		// summary:
		//		gets the elements list, that contains the graph elements that match to the dropped position
		return this._elementsList;
	},
	setDropInteractor: function(dropInteractor){
		//	
		// summary:
		//		sets the drop interactor
		this._dropInteractor = dropInteractor;
	},
	getDropInteractor: function(){
		//	
		// summary:
		//		gets the drop interactor
		return this._dropInteractor;
	},
	redoFunction: function(){
		var newElements = this._getNewList();
		var di = this.getDropInteractor()
		DropAction.EditingUtils.startDropAction(this.getDroppedItem(),this.getDroppedPosition(),di.getDiagram(),newElements,this);
	},
	_getNewList: function(){
		var newElements = [];
		var elements = this.getElementsList();
		dojo.forEach(elements, dojo.hitch(this, function(item){
			var newItem = this.getUndoManager().getRegisteredGraphElement(item);
			newElements.push(newItem);
		}));
		return newElements;
	}
	});
	
	return DropAction;
	
});
