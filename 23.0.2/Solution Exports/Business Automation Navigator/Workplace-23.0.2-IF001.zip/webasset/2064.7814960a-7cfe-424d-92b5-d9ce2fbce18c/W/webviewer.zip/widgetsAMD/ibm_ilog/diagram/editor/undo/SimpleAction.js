/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"./Action"
], function(
declare,
lang,
Action
){
	
/*=====
var Action = ibm_ilog.diagram.editor.undo.Action;
=====*/

	var SimpleAction =
	declare("ibm_ilog.diagram.editor.undo.SimpleAction", [Action], {
		//
		//	summary:
		//		This class is the simple undo action. It is used to undo/redo simple properties that can be 
		//		changed by setting up a property or calling a method with a simple argument.
		//
		_oldValue:null,
		_newValue: null,
		_modifiedElementId: null,
		_methodOrProperty: null,
		_cloneFunction:null,
		
	constructor:function(label){
		//
		//	summary:
		//		creates a new instance, setting up the label
		//
		this._label = label;
		this.initialize(lang.hitch(this,this._undoFunction),lang.hitch(this,this._redoFunction));
	},
	setOldValue: function(oldValue){
		//
		//	summary:
		//		sets the old value
		this._oldValue = oldValue;
	},
	setNewValue: function(newValue){
		//
		//	summary:
		//		sets the new value
		this._newValue = newValue;
	},
	getOldValue: function(){
		//
		//	summary:
		//		gets the old value, cloning the set value if clone function is previously set
		return this._cloneFunction?this._cloneFunction.call(null,this._oldValue):this._oldValue;
	},
	getNewValue: function(){
		//
		//	summary:
		//		gets the new value, cloning the set value if clone function is previously set
		return this._cloneFunction?this._cloneFunction.call(null,this._newValue):this._newValue;
	},
	setModifiedElementId: function(modifiedElementId){
		//
		//	summary:
		//		sets the modified object
		this._modifiedElementId = modifiedElementId;
	},
	getModifiedElementId: function(){
		//
		//	summary:
		//		sets the modified object
		return this._modifiedElementId;
	},
	getModifiedElement: function(){
		//
		//	summary:
		//		gets the modified graph element, looking for its replacements if neccesary
		return this.getUndoManager().getRegisteredGraphElement(this._modifiedElementId);
	},
	setMethodOrProperty: function(methodOrProperty){
		//
		//	summary:
		//		sets the property or method name to be modified
		this._methodOrProperty = methodOrProperty;
	},
	setCloneFunction: function(cloneF){
		//
		//	summary:
		//		sets the clone function in case the value should be clone before the change action
		this._cloneFunction = cloneF;
	},
	_undoFunction: function(){
		this.changeFunction(this.getOldValue());
	},
	_redoFunction: function(){
		this.changeFunction(this.getNewValue());
	},
	changeFunction: function(value){	
		
		var modifiedObject = this.getModifiedElement();
		if( modifiedObject && this._methodOrProperty){
			if(modifiedObject[this._methodOrProperty]){
				if(dojo.isFunction(modifiedObject[this._methodOrProperty])){
					modifiedObject[this._methodOrProperty](value);
				}else{
					modifiedObject[this._methodOrProperty] = value;
				}
			}
		}
	}
	});
	
	return SimpleAction;
	
});
