/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"../../base",
"../../adorners/LinkAdorner",
"../adorners/LinkConnectionHandle"
], function(
declare,
iid,
LinkAdorner,
LinkConnectionHandle
){
    
/*=====
var LinkAdorner = ibm_ilog.diagram.adorners.LinkAdorner;
=====*/

	var LinkConnectionAdorner =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.LinkConnectionAdorner',[LinkAdorner],{

    	initialize: function() {
    		this.inherited(arguments);

    		this._createHandle(LinkConnectionHandle,"start").setup(0);
    		this._createHandle(LinkConnectionHandle,"end").setup(1);

    	},
    	
    	activate: function() {
    		this._activateHandle("start");
    		this._activateHandle("end");
    	},
    	
    	deactivate: function() {
    		this._deactivateHandle("start");
    		this._deactivateHandle("end");
    	}

    }));

	return LinkConnectionAdorner;
	
});
