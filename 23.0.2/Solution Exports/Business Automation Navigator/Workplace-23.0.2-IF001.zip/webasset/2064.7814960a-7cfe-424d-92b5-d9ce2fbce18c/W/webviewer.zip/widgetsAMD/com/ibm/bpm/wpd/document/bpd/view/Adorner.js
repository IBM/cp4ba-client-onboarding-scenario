/**
 * A generalized adorner.  Will typically wrap an ILog Adorner.
 * 
 */
define([
   "dojo/_base/declare", "dojo/_base/lang"
], function(declare, lang) {
   return declare([], {

      // The target to be adorned (type AdornerTarget)
      adornerTarget : null,

      // True if the target is adorned, false otherwise
      adorned : null,
      
      // General structure that can be used by adorners to help
      // in adorning.
      unAdornInfo : null,
      
      // Event handles that are being listened to
      eventHandles : null,
      
      // Tooltip handles
      tooltips : null,

      constructor : function(args) {
         lang.mixin(this, args);
         this.adorned = false;
         this.unAdornInfo = {};
         this.eventHandles = [];
         this.tooltips = [];
      },
      
      adorn: function() {
         this.adorned = true;
      },
      
      unAdorn: function() {
         // Remove all listeners
         for ( var i = 0; i < this.eventHandles.length; i++) {
            this.eventHandles[i].remove();
         }
         // Clear the events array
         this.eventHandles.length = 0;
         // Close all tooltips
         for ( var i = 0; i < this.tooltips.length; i++) {
            this.tooltips[i].close();
         }
         // Clear the tooltips array
         this.tooltips.length = 0;
         // Show unadorned
         this.adorned = false;
      },
      
      destroy: function() {
         if (this.adorned) this.unAdorn();
      },
      
      // To be listened to
      onEvent : function(adorner, eventName, data) {

      }

   });

});