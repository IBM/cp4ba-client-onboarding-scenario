/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/declare", "dojo/_base/lang", "dojo/_base/array", "dojo/_base/fx",
"../Node", "../Link", "../util/Batch"],
function(declare, lang, array, fx, Node, Link, Batch){

var Animation =
declare("ibm_ilog.diagram.graphlayout.Animation", null, {
	// summary:
	//		An internal class that handles graph layout animation.
	// tags:
	//		private
	
	_graph: null,
	_fitTransform: null,
	_nodes: null,
	_links: null,
	
	constructor: function(graph, recursive)
	{
		// tags:
		//		private
		this._graph = graph;
		this._nodes = this._getObjects(true, recursive);
		this._links = this._getObjects(false, recursive);
	},
	
	_getObjects: function(nodes, recursive){
		// summary:
		//		Gets all the nodes or links to animate.
		// tags:
		//		private
		var layout = this._graph._rml;
		if (layout) {
			var model = layout.getGraphModel();
			// Note: we use getAllLinks, which is specific to GrapherAdapter:
			// in the Diagram code we assume the model is always a GrapherAdapter.
			var objs = nodes ? model.getNodes() : model.getAllLinks();
			if(recursive)
				objs = this._concat(objs, this._getSubgraphObjects(model, model, nodes));
			return objs;
		}
		return [];
	},
	
	_getSubgraphObjects: function(root, model, nodes) {
		// summary:
		//		Gets all the nodes or links contained in subgraphs.
		// tags:
		//		private
		var objs = [];
		var subgraphs = model.getSubgraphs();
		for(var i = 0; i < subgraphs.length; i++){
			var submodel = root.getGraphModel(subgraphs[i]);
			objs = this._concat(objs, nodes ? submodel.getNodes() : submodel.getAllLinks());
			objs = this._concat(objs, this._getSubgraphObjects(root, submodel, nodes));
		}
		return objs;
	},
	
	_concat : function(a1, a2){
		if(a2 && a2.length > 0)
			return a1.concat(a2);
		else
			return a1;
	},
	
    beforeLayout: function(){
		// tags:
		//		private
		
		// stop previous animation:
		if (this._graph._glAnimation) {
			this._graph._glAnimation.stop();
			delete this._graph._glAnimation;
		}
		
		// save all node/link geometry:
		array.forEach(this._nodes, function(node){
			var bounds = node.getBounds();
			node._oldPosition = {
				x: bounds.x,
				y: bounds.y
			};
		});
		array.forEach(this._links, function(link){
			link._oldPoints = link.getPoints();
		});
	},
	
    afterLayout: function(){
		// tags:
		//		private
		
		// update links:
		Batch.endBatch();
		
		// get new node/link geometry:
		array.forEach(this._nodes, function(node){
			var bounds = node.getBounds();
			node._newPosition = {
				x: bounds.x,
				y: bounds.y
			};
		});
		array.forEach(this._links, function(link){
			link._newPoints = link.getPoints();
			// animate link points only if nodes have moved.
			link._newShapeType = link.getShapeType();
			link.setShapeType(Link.LinkShapeType.Free);
			if (link._newPoints.length != link._oldPoints.length) {
				// add points to the array that has less points by interpolation
				var more, less;
				if (link._newPoints.length > link._oldPoints.length) {
					more = link._newPoints;
					less = link._oldPoints;
				}
				else {
					more = link._oldPoints;
					less = link._newPoints;
				}
				// avg number of points to add on each segment
				var n = Math.floor((more.length - less.length) / (less.length - 1));
				for (var i = 0; i < less.length - 1; i++) {
					var p1 = less[i];
					var p2 = less[i + 1];
					// last segment: add exactly the number of points needed
					if (i == less.length - 2) 
						n = more.length - less.length;
					for (var j = 1; j <= n; j++) {
						var p = {
							x: p1.x + j * (p2.x - p1.x) / (n + 1),
							y: p1.y + j * (p2.y - p1.y) / (n + 1)
						};
						less.splice(j, 0, p);
					}
					i += n;
				}
			}
			link._newIntermediatePoints = link.getIntermediatePoints();
		});
		var anim = new fx.Animation({
			duration: 1000,
			rate: 20,
			curve: [0, 100],
            beforeBegin: function(){
                // disable _onChanged events during animation
            	// [av] TODO: maybthis flag changes should be moved into a global flag stack
            	Node._ChangesInvalidateLinksDisabled = true;                 
            },
			onAnimate: lang.hitch(this, function(v){
				var completion = v / 100;
				array.forEach(this._nodes, function(node){
					var p1 = node._oldPosition;
					var p2 = node._newPosition;
					node.move(p1.x + completion * (p2.x - p1.x), p1.y + completion * (p2.y - p1.y));
				});
				array.forEach(this._links, function(link){
					var oldp = link._oldPoints;
					var newp = link._newPoints;
					if (oldp && newp && oldp.length == newp.length) {
						var count = oldp.length;
						var ip = [];
						for (var i = 1; i < count - 1; i++) {
							var p1 = oldp[i];
							var p2 = newp[i];
							ip.push({
								x: p1.x + completion * (p2.x - p1.x),
								y: p1.y + completion * (p2.y - p1.y)
							});
						}
						link.setIntermediatePoints(ip);
					}
				});
				
				Batch.endBatch();
				
				if (this._graph.isAutoFitOnLayout() && this._mustSetFitTransform) {
					this._graph.setTransform(this._fitTransform);
					delete this._mustSetFitTransform;
				}
				
				this._graph.onLayoutAnimate(v);
			}),
			onEnd: lang.hitch(this, function(e){
                // re-enable the _onChanged events
            	// [av] TODO: maybe this flag changes should be moved into a global flag stack
                delete Node._ChangesInvalidateLinksDisabled;
				array.forEach(this._nodes, function(node){
					node._oldPosition = undefined;
					node._newPosition = undefined;
				});
				array.forEach(this._links, function(link){
					if (link._newIntermediatePoints) 
						link.setIntermediatePoints(link._newIntermediatePoints);
					if (link._newShapeType) 
						link.setShapeType(link._newShapeType);
					link._newShapeType = undefined;
					link._oldPoints = undefined;
					link._newPoints = undefined;
					link._newIntermediatePoints = undefined;
				});
				this._graph.onLayoutAnimationEnd();
				delete this._graph._glAnimation;
			})
		});
		
		if (this._graph.isAutoFitOnLayout()) {
			this._fitTransform = this._graph.getFitToContentsTransform();
			this._mustSetFitTransform = true;
		}
		
		this._graph.onLayoutAnimationStart();
		this._graph._glAnimation = anim;
		anim.play();
	}
});

return Animation;

});
