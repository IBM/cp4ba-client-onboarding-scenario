/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/lang",
"dojox/collections/Dictionary",
"dijit/form/Textarea",
"../data/dtlbinding"
],
function(lang, Dictionary, Textarea, dtlbinding){

	// TODO: Change to this when AMD conversion is complete:
	// var t = {};
	var t = lang.getObject("ibm_ilog.diagram.templates", true);
	
    t.defaultResizeAdornerTemplate = [{
        dojoAttachPoint: 'adornerRoot',
        transform: {
            dx: $bind("{{elemBaseLeft}}"),
            dy: $bind("{{elemBaseTop}}")
        },
        children: [{
            dojoAttachPoint: 'hndTL',
            transform: {
                dx: -7,
                dy: -7,
                xx: 1,
                yy: 1
            }
        }, {
            dojoAttachPoint: 'hndTR',
            transform: {
                dx: $bind("{{elemBaseWidth}}+7"),
                dy: -7,
                xx: -1,
                yy: 1
            }
        }, {
            dojoAttachPoint: 'hndBL',
            transform: {
                dx: -7,
                dy: $bind("{{elemBaseHeight}}+7"),
                xx: 1,
                yy: -1
            }
        }, {
            dojoAttachPoint: 'hndBR',
            transform: {
                dx: $bind("{{elemBaseWidth}}+7"),
                dy: $bind("{{elemBaseHeight}}+7"),
                xx: -1,
                yy: -1
            }
        }]
    }];

    t.defaultResizeHandleTemplate = [{
        dojoAttachPoint: 'stNormal',
        children: [{
            shape: {
                type: 'rect',
                x: 0,
                y: 0,
                width: 10,
                height: 10
            },
            fill: [0, 0, 0, 0.0001]
        }, {
            shape: {
                type: 'line',
                x1: 0,
                y1: 0,
                x2: 10,
                y2: 0
            },
            stroke: {
                color: [0, 120, 255, 0.5],
                width: 2
            }
        }, {
            shape: {
                type: 'line',
                x1: 0,
                y1: 0,
                x2: 0,
                y2: 10
            },
            stroke: {
                color: [0, 120, 255, 0.5],
                width: 2
            }
        }]
    }, {
        dojoAttachPoint: 'stHighlighted',
        children: [{
            shape: {
                type: 'rect',
                x: 0,
                y: 0,
                width: 10,
                height: 10
            },
            fill: [0, 0, 0, 0.0001]
        }, {
            shape: {
                type: 'line',
                x1: 0,
                y1: 0,
                x2: 10,
                y2: 0
            },
            stroke: {
                color: [0, 120, 255],
                width: 2
            }
        }, {
            shape: {
                type: 'line',
                x1: 0,
                y1: 0,
                x2: 0,
                y2: 10
            },
            stroke: {
                color: [0, 120, 255],
                width: 2
            }
        }]
    }, {
        dojoAttachPoint: 'stActive',
        children: [{
            shape: {
                type: 'line',
                x1: 0,
                y1: 0,
                x2: 10,
                y2: 0
            },
            stroke: {
                color: [255, 0, 120, 0.3],
                width: 2
            }
        }, {
            shape: {
                type: 'line',
                x1: 0,
                y1: 0,
                x2: 0,
                y2: 10
            },
            stroke: {
                color: [255, 0, 120, 0.3],
                width: 2
            }
        }]
    }];
    t.defaultResizeHandleTemplate.noDtl = true;

    t.defaultConnectionAdornerTemplate = [{
        dojoAttachPoint: 'adornerRoot',
        transform: {
            dx: $bind("{{elemBaseLeft}}"),
            dy: $bind("{{elemBaseTop}}")
        },
        children: [{
            dojoAttachPoint: 'hndT',
            transform: {
                dx: $bind("{{elemBaseCenterX}}-10"),
                dy: 5,
                xx: 1,
                yy: -1
            }
        }, {
            dojoAttachPoint: 'hndR',
            transform: {
                dx: $bind("{{elemBaseWidth}}-5"),
                dy: $bind("{{elemBaseCenterY}}+10"),
                xx: 0,
                xy: 1,
                yx: -1,
                yy: 0
            }
        }, {
            dojoAttachPoint: 'hndB',
            transform: {
                dx: $bind("{{elemBaseCenterX}}-10"),
                dy: $bind("{{elemBaseHeight}}-5"),
                xx: 1,
                yy: 1
            }
        }, {
            dojoAttachPoint: 'hndL',
            transform: {
                dx: 5,
                dy: $bind("{{elemBaseCenterY}}-10"),
                xx: 0,
                xy: -1,
                yx: 1,
                yy: 0
            }
        }]
    }];

    t.defaultConnectionHandleTemplate = [{
        dojoAttachPoint: 'stNormal',
        children: [{
            shape: {
                type: 'path',
                path: 'M 1,10 L 19,10 L 10,18 z e'
            },
            fill: [0, 120, 255, 0.5]
        }, {
            shape: {
                type: 'path',
                path: 'M 0,10 L 20,10 L 15,0 L 5,0 z e'
            },
            fill: [255, 255, 255, 0.001]
        }]
    }, {
        dojoAttachPoint: 'stHighlighted',
        children: [{
            shape: {
                type: 'path',
                path: 'M 1,10 L 19,10 L 10,18 z e'
            },
            fill: [0, 120, 255, 1]
        }, {
            shape: {
                type: 'circle',
                cx: 10,
                cy: 10,
                r: 10
            },
            fill: [0, 120, 255, 0.001]
        }, {
            shape: {
                type: 'path',
                path: 'M 0,10 L 20,10 L 15,0 L 5,0 z e'
            },
            fill: [255, 255, 255, 0.001]
        }]
    }, {
        dojoAttachPoint: 'stActive',
        children: [{
            shape: {
                type: 'path',
                path: 'M 1,10 L 19,10 L 10,18 z e'
            },
            fill: [255, 0, 120, 0.3]
        }]
    }];
    t.defaultConnectionHandleTemplate.noDtl = true;
    
    t.defaultConnectionTargetHandleTemplate = [{
        dojoAttachPoint: 'stNormal',
        children: [{
            shape: {
                type: 'path',
                path: 'M 1,10 L 19,10 L 10,18 z e'
            },
            fill: [0, 120, 255, 0.5]
        }, {
            shape: {
                type: 'circle',
                cx: 10,
                cy: 10,
                r: 10
            },
            fill: [255, 255, 255, 0.001]
        }]
    }, {
        dojoAttachPoint: 'stHighlighted',
        children: [{
            shape: {
                type: 'path',
                path: 'M 1,10 L 19,10 L 10,18 z e'
            },
            fill: [255, 0, 120, 0.3]
        }, {
            shape: {
                type: 'circle',
                cx: 10,
                cy: 10,
                r: 10
            },
            fill: [255, 0, 120, 0.001]
        }]
    }, {
        dojoAttachPoint: 'stActive',
        children: [{
            shape: {
                type: 'path',
                path: 'M 1,10 L 19,10 L 10,18 z e'
            },
            fill: [255, 0, 120, 0.3]
        }]
    }];
    t.defaultConnectionTargetHandleTemplate.noDtl = true;

    t.defaultLinkConnectionAdornerTemplate = [{
        dojoAttachPoint: 'adornerRoot',
        children: [{
            dojoAttachPoint: '_path',
            shape: {
                type: 'polyline',
                points: [{
                    x: 0,
                    y: 0
                }, {
                    x: 0,
                    y: 0
                }]
            },
            stroke: {
                width: 6,
                color: [255, 0, 255, 0.15]
            }
        },{
            dojoAttachPoint: 'start',
            transform: {
                dx: $bind("{{linkStartX}}"),
                dy: $bind("{{linkStartY}}")
            }
        }, {
            dojoAttachPoint: 'end',
            transform: {
                dx: $bind("{{linkEndX}}"),
                dy: $bind("{{linkEndY}}")
            }
        }]
    }];

    t.defaultLinkConnectionHandleTemplate = [{
        dojoAttachPoint: 'stNormal',
        children: [{
            shape: {
                type: 'circle',
                cx: 0,
                cy: 0,
                r: 5
            },
            fill: [0, 120, 255, 0.3]
        }]
    }, {
        dojoAttachPoint: 'stHighlighted',
        children: [{
            shape: {
                type: 'circle',
                cx: 0,
                cy: 0,
                r: 5
            },
            fill: [0, 120, 255, 0.7]
        }]
    }, {
        dojoAttachPoint: 'stActive',
        children: [{
            shape: {
                type: 'circle',
                cx: 0,
                cy: 0,
                r: 5
            },
            fill: [255, 0, 255, 0.5]
        }]
    }];
    t.defaultLinkConnectionHandleTemplate.noDtl = true;

    t.defaultTextEditAdornerTemplate = [{
        dojoAttachPoint: 'textbox',
        transform: {
            dx: $bind("{{compLeft}}-2"),
            dy: $bind("{{compTop}}-2")
        },
        height: $bind("{{compHeight}}+4"),
        width: $bind("{{compWidth}}+4"),
        fontPxSize: $bind("{{refFontPxSize}}"),
        fontMinPxSize: 12,
        minWidth: 40,
        shape: {
            type: 'widget',
            dojoType: 'dijit.form.Textarea',
            tabIndex: -1,
            scrollOnFocus: 0,
            role: 'presentation',
            style: 'text-align:center;font-size:10pt;font-family:sans-serif'
        }
    }];

    t.defaultLinkIntermediatePointsAdornerTemplate = [{
        dojoAttachPoint: 'adornerRoot',
        children: [{
            dojoAttachPoint: '_path',
            shape: {
                type: 'polyline',
                points: [{
                    x: 0,
                    y: 0
                }, {
                    x: 0,
                    y: 0
                }]
            },
            stroke: {
                width: 7,
                color: [255, 0, 150, 0.1]
            }
        }, {
            dojoAttachPoint: 'currentPointGroup',
            children: []
        }, {
            dojoAttachPoint: 'addPointGroup',
            children: []
        }]
    }];
    t.defaultLinkIntermediatePointsAdornerTemplate.noDtl = true;
    
    t.defaultLinkIntermediatePointsHandleTemplate = [{
        dojoAttachPoint: 'stNormal',
        transform: {
            dx: $bind("{{intPointPosX}}"),
            dy: $bind("{{intPointPosY}}")
        },
        children: [{
            shape: {
                type: 'path',
                path: 'M -7,0 L 0,-7 L 7,0 L 0,7 z e'
            },
            fill: [0, 120, 255, 0.3]
        }]
    }, {
        dojoAttachPoint: 'stHighlighted',
        transform: {
            dx: $bind("{{intPointPosX}}"),
            dy: $bind("{{intPointPosY}}")
        },
        children: [{
            shape: {
                type: 'path',
                path: 'M -7,0 L 0,-7 L 7,0 L 0,7 z e'
            },
            fill: [0, 120, 255, 0.7]
        }]
    }, {
        dojoAttachPoint: 'stActive',
        transform: {
            dx: $bind("{{intPointPosX}}"),
            dy: $bind("{{intPointPosY}}")
        },
        children: [{
            shape: {
                type: 'path',
                path: 'M -7,0 L 0,-7 L 7,0 L 0,7 z e'
            },
            fill: [255, 0, 255, 0.5]
        }]
    }];
    
     t.defaultLinkIntermediatePointsAddHandleTemplate = [{
        dojoAttachPoint: 'stNormal',
        transform: {
            dx: $bind("{{addPointPosX}}"),
            dy: $bind("{{addPointPosY}}")
        },
        children: [{
       	 	shape: {
        		type: 'circle',
        		cx: 0,
        		cy: 0,
        		r: 6
    		},
            fill: [0, 120, 255, 0.5]
        },{
            shape: {
            type: 'path',
            path: 'M 0,-4 L 0,4 M -4,0 L 4,0 e'
        	},
        	stroke: {
                width: 2,
                color: [255, 255, 255, 1]
            }
        }]
    }, {
        dojoAttachPoint: 'stHighlighted',
        transform: {
            dx: $bind("{{addPointPosX}}"),
            dy: $bind("{{addPointPosY}}")
        },
        children: [{
       	 	shape: {
        		type: 'circle',
        		cx: 0,
        		cy: 0,
        		r: 6
    		},
            fill: [0, 120, 255, 0.9]
        },{
            shape: {
            type: 'path',
            path: 'M 0,-4 L 0,4 M -4,0 L 4,0 e'
        	},
        	stroke: {
                width: 2,
                color: [255, 255, 255, 1]
            }
        }]
    }, {
        dojoAttachPoint: 'stActive',
        transform: {
            dx: $bind("{{addPointPosX}}"),
            dy: $bind("{{addPointPosY}}")
        },
        children: [{
        	 shape: {
            	type: 'circle',
            	cx: 0,
            	cy: 0,
            	r: 6
        	},
            fill: [255, 0, 255, 0.7]
        },{
            shape: {
            type: 'path',
            path: 'M 0,-4 L 0,4 M -4,0 L 4,0 e'
        	},
        	stroke: {
                width: 2,
                color: [255, 255, 255, 1]
            }
        }]
    }];
    
    t.defaultAdornerTemplates = t.defaultAdornerTemplates || new Dictionary();
    
    t.defaultAdornerTemplates.add("TextEditAdorner", t.defaultTextEditAdornerTemplate);
    t.defaultAdornerTemplates.add("ResizeAdorner", t.defaultResizeAdornerTemplate);
    t.defaultAdornerTemplates.add("ResizeHandle", t.defaultResizeHandleTemplate);
    t.defaultAdornerTemplates.add("ConnectionHandle", t.defaultConnectionHandleTemplate);
    t.defaultAdornerTemplates.add("ConnectionAdorner", t.defaultConnectionAdornerTemplate);
    t.defaultAdornerTemplates.add("ConnectionTargetHandle", t.defaultConnectionTargetHandleTemplate);
    t.defaultAdornerTemplates.add("ConnectionTargetAdorner", t.defaultConnectionAdornerTemplate);
    
    t.defaultAdornerTemplates.add("LinkConnectionAdorner", t.defaultLinkConnectionAdornerTemplate);
    t.defaultAdornerTemplates.add("LinkConnectionHandle", t.defaultLinkConnectionHandleTemplate);
    
    t.defaultAdornerTemplates.add("LinkIntermediatePointsHandle", t.defaultLinkIntermediatePointsHandleTemplate);
    t.defaultAdornerTemplates.add("LinkIntermediatePointsAdorner", t.defaultLinkIntermediatePointsAdornerTemplate);
    t.defaultAdornerTemplates.add("LinkIntermediatePointsAddHandle",t.defaultLinkIntermediatePointsAddHandleTemplate);
	
	return t;
});
