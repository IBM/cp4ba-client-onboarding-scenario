/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"../../base",
"../../adorners/HighlightedHandle",
"../interactors/LinkConnectionHandleInteractor"
], function(
declare,
iid,
HighlightedHandle,
LinkConnectionHandleInteractor
){

/*=====
var HighlightedHandle = ibm_ilog.diagram.adorners.HighlightedHandle;
=====*/

	var LinkConnectionHandle =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.LinkConnectionHandle',[HighlightedHandle],{
		
		//
		//	location: handle position
		//
		location: null,
		
		setup: function(location) {
			// Summary:
			//		sets the handle positioning ( 0=start - 1=end )
			this.location = location;
			this.addInteractor(new LinkConnectionHandleInteractor().initialize(this));
			return this;
		},
		
		getLocation:function(){
			return this.location;
		}
	}));

	LinkConnectionHandle.templateId = "LinkConnectionHandle";

	return LinkConnectionHandle;

});

