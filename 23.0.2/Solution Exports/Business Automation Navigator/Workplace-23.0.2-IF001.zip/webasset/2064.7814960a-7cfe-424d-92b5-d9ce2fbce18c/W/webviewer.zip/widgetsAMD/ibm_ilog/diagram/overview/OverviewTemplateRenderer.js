/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"./OverviewRenderer",
"../util/GraphUtil"
],
function(
declare,
lang,
array,
OverviewRenderer,
gu
){

/*=====
var OverviewRenderer = ibm_ilog.diagram.overview.OverviewRenderer;
=====*/

var OverviewTemplateRenderer =
declare('ibm_ilog.diagram.overview.OverviewTemplateRenderer', OverviewRenderer, {

	//
	//	summary:
	//		Uses custom templates to generate the overview image.
	//
	//	description:
	//		Iterates the given graph and reinstantiates the elements in the graph 
	//		with new templates. If no templates are specified, default ones are used.
	//	
	
	//
	//	node:  Function
	//		The node template function for the overview.
	//
	node: function(node){
		return node._template;
	},
	
	//
	//	link:  Function
	//		The link template function for the overview.
	//
	link: function(link){
		return link._template;
	},

	//
	//	subgraph:  Function
	//		The subgraph template function for the overview.
	//
	subgraph: function(subgraph){
		return subgraph._template;
	},

	//
	//	stripTexts: Boolean
	//		Optional removal of the texts from the generated shapes.
	//
	stripTexts: true,
	
	//
	//	stripBitmaps: Boolean
	//		Optional removal of the bitmaps from the generated shapes
	//
	stripBitmaps: true,

	constructor: function( kwArgs ) {
		if(kwArgs) {
			lang.mixin(this,kwArgs);
		}
		
		this._toFunction("node");
		this._toFunction("link");
		this._toFunction("subgraph");

	},
	
	_toFunction: function(name) {
		if(typeof this[name] != "function") {
			var value = this[name];
			this[name] = function(){
				return value;
			};
		}
	},

	_cloneGroup: function(parent,g) {
		var ng = parent.createGroup();
		if(g.getTransform){
			var t = g.getTransform();
			if(t) {
				ng.setTransform(t);
			}
		}
		return ng;
	},

	_stripShapes: function(childrenArray){
		var remove = [];
		array.forEach(childrenArray,function(child){
			if(!child.TID) {
				if (child.shape && ((this.stripTexts && child.shape.type=="text") || (this.stripBitmaps && child.shape.type=="image") )) {
					remove.push(child);
				} else {
					if (child.children) {
						this._stripShapes(child.children);
					}
				}
			}
		},this);
		array.forEach(remove,function(child){
			child.getParent().remove(child);
		},this);
	},

	
	render: function( graph, /*dojox.gfx.Group*/ output ) {
		
		var sub = function(ps,ns,g,b) {
			if(g.isCollapsed()) {
				ns.clear(); // TODO: cut iteration earlier instead of removing result of collapsed subgraphs
			}
			var subrep=ns.createGroup();
			subrep = g.shallowInstantiateAt(subrep,this.subgraph(g));
            g.layoutShape(subrep,true);
			subrep.moveToBack();
      if(this.stripTexts || this.stripBitmaps) {
        this._stripShapes(subrep.children);
    }
//
//	Draft of future version of this method:
//
//			ps.remove(ns);
//			var subrep=this.cloneGroup(ps,g);
//			subrep = g.shallowInstantiateAt(subrep,this.subgraph(g));
//			subrep._graph.add(ns);
//	        g.layoutShape(subrep);
//			subrep._graph.moveToFront();
		};

		var instantiator = function(templateF) {
			return function(ps,g){
				var t = templateF(g);
				var r = g.shallowInstantiateAt(this._cloneGroup(ps,g),t);
	            g.layoutShape(r,true);
	      if(this.stripTexts || this.stripBitmaps) {
	          this._stripShapes(r.children);
	      }
				return r;
			};
		};

		gu.fold(
			graph,
			output, // state
			gu.folders({
				sub:   sub,
				node:  instantiator(this.node),
				link:  instantiator(this.link),
				cBase: null,
				accGroup: this._cloneGroup,
				accGraph: this._cloneGroup,
				accSubgraph: this._cloneGroup
			}),
			this
		);

	}
});

return OverviewTemplateRenderer;

});

