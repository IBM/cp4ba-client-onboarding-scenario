/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/keys",
"./Interactor",
"../util/Geometry"
],
function(
declare,
keys,
Interactor,
g
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var PanKeyInteractor =
declare("ibm_ilog.diagram.interactors.PanKeyInteractor", [Interactor], {
	//summary:
	//		This Interactor manages the ViewPort Pan movement through the keyboard interaction.
	//		This Interactor have 4 connections: panLeft, panRigth, panUp, panDown.
	
	_diagram: null,
	_increment: null,
	
	initialize: function (diagram) {
	// summary:
    //		initialize the new instance.
    // diagram: ibm_ilog.diagram.widget.Diagram
    //		the associated diagram.				
		this._diagram = diagram;
		this.setIncrement(10);
		return this._initialize();
	},
	setIncrement: function(increment){
		// summary: 
		//		sets the pan increment
		// increment: integer
		//		the increment to be set
		this._increment = increment;
	},
	getIncrement: function(){
		// summary: 
		//		gets the pan increment
		return this._increment;
	},
	panUp: function(e){
		// summary:
	    //		This method pans the diagram up
	    // e: Event object
	    //		the event to be treated.
		this._pan({x:0,y:-this._increment});
	},
	panDown: function(e){
		// summary:
	    //		This method pans the diagram down
	    // e: Event object
	    //		the event to be treated.
		this._pan({x:0,y:this._increment});
	},
	panRight: function(e){
		// summary:
	    //		This method pans the diagram right
	    // e: Event object
	    //		the event to be treated.
		this._pan({x:this._increment,y:0});
	},
	panLeft: function(e){
		// summary:
	    //		This method pans the diagram left
	    // e: Event object
	    //		the event to be treated.
		this._pan({x:-this._increment,y:0});
	},
	getKeyInteractorId: function(){
		// summary:
	    //		returns the Interactor Id
		return PanKeyInteractor.KeyInteractorId;
	},
	getDefaultConnections: function () {
		// summary:
		//		returns the default event mapping
		
		return {
			panLeft: {
				hotKey: keys.LEFT_ARROW,	
				connectTo: "panLeft",
				filter: this._buildInputFilter({ctrl:false,shift:true})
			}, panRight: {
				hotKey: keys.RIGHT_ARROW,	
				connectTo: "panRight",
				filter: this._buildInputFilter({ctrl:false,shift:true})
			}, panUp: {
				hotKey: keys.UP_ARROW,	
				connectTo: "panUp",
				filter: this._buildInputFilter({ctrl:false,shift:true})
			}, panDown: {
				hotKey: keys.DOWN_ARROW,	
				connectTo: "panDown",
				filter: this._buildInputFilter({ctrl:false,shift:true})
			}
		};
	},
	_pan: function(delta){
		var v = this._diagram.getViewport();
		var viewMovement = g.mulPoint(delta, -1 / v.getZoom()); // scale delta to zoom level to get delta in model coords
		var firstViewRect = v.getViewRect();
		v.setViewRect(g.moveRect(firstViewRect, viewMovement), {instant:true});
	}
});

PanKeyInteractor.KeyInteractorId = "Pan";

return PanKeyInteractor;

});
