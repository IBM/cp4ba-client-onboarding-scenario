/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/lang", "dojo/json",
"dojo/has!config-diagramForMobile?:dojo/i18n", "dojo/has!config-diagramForMobile?:dojo/string"],
function(lang, json, i18n, string){

	// TODO:
	// For now we must create a global object since there are still references to ibm_ilog.diagram.util.ErrorReporter
	// in the rest of the code, but when AMD migration is finished all global references should be replaced
	// by module references and this will be replaced by a simple object creation:
	// var e = {};
	var e = lang.getObject("ibm_ilog.diagram.util.ErrorReporter", true);

	var B;

	e.getLocalizedString = function(id){
		// summary:
		//		Returns the localized string for the specified identifier.
		// description:
		//		This function normally fetches the specified string (using the dojo.i18n API)
		//		from the package name "ibm_ilog.diagram" and the bundle name "ErrorReporter".
		//		On mobile platforms (that is, if dojo.config.diagramForMobile is true),
		//		dojo.i18n is not used (to reduce the size of downloaded code), so the id is
		//		returned unchanged. To localize messages on mobile, the application should
		//		replace this function (ibm_ilog.diagram.util.ErrorReporter.getLocalizedString)
		//		by a function that requests the localized string from the server.
		if(!i18n)
			return id;
		try { // workaround for i18n bug in dojo 1.7...
			if (!B) 
				B = i18n.getLocalization("ibm_ilog.diagram", "ErrorReporter");
			return B[id];
		} catch(error){
			return id;
		}
	};
	
	e._errors = {};
	
	e.error = function(id) {
		throw this.buildError.apply(this,arguments);
	};

	e.warn = function(id) {
		console.warn(this.buildDescription.apply(this,arguments));
	};

	e.buildError = function(id) {
		var e = new Error(this.buildDescription.apply(this,arguments));
		e._isIBMDiagramError = true;
		var ed = this._errors[id];
		if(ed!==undefined) {
			e.id = ed.id;
			e.errorCode = ed.errorCode; 
		}
		return e;
	};
	
	e.buildDescription = function(id) {
		var err = this._errors[id];
		if(!err) {
			err = this._errors.InvalidErrorId;
		}
		var description = err.descriptor.apply(this,arguments);
		return err.errorCode+ ": " + description + " ("+err.id+")";
	};

	
	e._errorAtObject = function(obj,args) {
		// TODO [AV] obj is ignored for now
		this.error.apply(this,args);
	};
	
	var toKw = function(args,names,start) {
		var kwArgs = {}
		start = start || 0;
		for(var i=0;i<names.length;i++) {
			kwArgs[names[i]] = args[start+i];
		}
		return kwArgs;
	};
	
	var substitute  = function(s, args) {
		if(string)
			return string.substitute(s, args);
		return s;
	};
	
	var buildStandardDescriptor = function(/*Array*/kwArgNames) {
		// 
		//	summary:
		//		Builds a standard error descriptor function.
		//
		//	description:
		//		This function takes names for the positional user arguments 
		//		in the ErrorReporter.error() call so that they can be referenced
		//		from the I18N string templates easier.
		//
		//	kwArgNames: Array
		//		list of the argument names for using them in the call to 
		//		string.substitute
		//
		return function(id) {
			return substitute(e.getLocalizedString(id),toKw(arguments,kwArgNames,1));
		};

	};
	
	e.declareError = function(errorCode,id,descriptor) {
		// 
		//	summary:
		//		Error declaration helper
		//
		//	errorCode: String
		//		The IBM standard error code.
		//
		//	id: String
		//		An alphabetic error name used to reference it from the 
		//		code; making it more readable.
		//
		//	descriptor: String|Array|Function
		//		The error message or message generator.
		//	
		//		It can be three: 
		//		* message itself (Non-I18Nized)
		//		* a function which handles the R.error() arguments directly
		//		* an array naming the arguments of the R.error() call; for 
		//		  which a function is built that calls string.substitute 
		//		  with these names for I18N. (We call this the standard descriptor)  
		//
		var error = {};
		error.errorCode = errorCode;
		error.id = id;
		if(typeof(descriptor) == "function") {
			error.descriptor = descriptor;
		} else if(descriptor instanceof Array) { 
			error.descriptor = buildStandardDescriptor(descriptor);
		} else {
			error.descriptor = function() {
				return ""+descriptor;
			};
		}
		if(this._errors[id]!==undefined) {
			throw new Error(substitute(e.getLocalizedString("ErrorIdAlreadyDeclared"),id));
		}
		this._errors[id] = error;
	};
	
	//
	// ERROR DECLARATIONS
	//	

	var errorTable =
	[

	 
	 	//-------------------------------------------------------
		// ErrorReporter internals
	 	//
		{	name: "Unknown" },
		{ name: "InvalidErrorId", args:["errorId"] },
		{	name: "ErrorIdAlreadyDeclared", args:["errorId"] },

		//-------------------------------------------------------
		// Generic-JavaScript
		//
		{ name: "SubclassResponsibility", args:["methodName"] },
	 	{
		 	name: "NullPointerException",
			descriptor: function(id, objectName, where) {
				return where?
						substitute(e.getLocalizedString("NullPointerException2"),{objectName:objectName,where:where}):
						substitute(e.getLocalizedString("NullPointerException"),{objectName:objectName});
			}
		},
		{
		 	name: "Wrapped",
		 	descriptor: function(id, process, error) {
		 		if(error.message) {
					error = error.message;
				}
				return substitute(e.getLocalizedString(id),{process:process,error:error});
			}
		},
		{
		 	name: "UnexpectedArgument",
		 	descriptor: function(id, sender, functionName, argumentName, actualArgument) {
				// summary:
				// 		Throws an error indicating that an argument is not of the expected type or range. 
				// sender:
				//		The object that raised the error.
				// functionName:
				//		The name of the function in which the error occurred.
				// argumentName:
				//		The name of the argument that received a wrong value.
				// actualArgument:
				//		The argument value that was passed and detected as unexpected.
				return substitute(e.getLocalizedString(id),toKw(arguments,["sender","functionName","argumentName","actualArgument"],1));
			}
		},
		{
		 	name: "InvalidNumberOfArguments",
		 	descriptor: function(id, args) {				
				return substitute(e.getLocalizedString(id),{
					numberOfArgs: args.length,
					options: Array.prototype.slice.call(arguments,4).toString()});
			}
		},
		{
			name:"UnexpectedReturnValueType", args: ["sender", "functionName", "expectedType", "actualType"]
		},
		
		
		// ------------------------------------------------------
		// Dojo-version
		//
		{ name:"UnsupportedDojoFeature", args:["version"] },
		
		
		
		
		//-------------------------------------------------------
		// Generic-Graph/Diagram
		//
		{	name: "GraphElementExpected" },
		
		
		
		
		
		//-------------------------------------------------------
		// DataStore
		//
		{	name: "NotInDataStore" },
		{	name: "CannotUseAStringForAQuery" },
		{	name: "NodesStoreRequired" },
		{	name: "StoresMustSupportIdentity" },
		{	name: "StoresMustSupportRead" },
		{
			name: "UnexpectedErrorOnNodesStoreFetch",
			descriptor: function(id, error){
				if(error.message) {			
					error = error.message;
				}
				return substitute(e.getLocalizedString(id),{errorString:error});
			}
		},
		{
			name: "UnexpectedErrorOnLinksStoreFetch",
			descriptor: function(id, error){
				if(error.message) {			
					error = error.message;
				}
				return substitute(e.getLocalizedString(id),{errorString:error});
			}
		},

		
		
		
		//-------------------------------------------------------
		// Overview
		//
		{	name: "OverviewDiagramMissing", args: ["diagram"] },

		
		
		//-------------------------------------------------------
		// WAI
		//
		{	name: "MissingWaiNode", args: ["element"] },

		
		
		//-------------------------------------------------------
		// ServerSideLayout
		//
		{
			name: "UnsupportedAlgorithm",
			descriptor: function(id,algorithm){
				return substitute(e.getLocalizedString(id),{algorithmClass:algorithm.declaredClass});
			}
		},


		
		//-------------------------------------------------------
		// Interactors
		//
		{	name: "RestrictedToOneInteractor" },
		{
		 	name: "InvalidInteractorId",
			descriptor: function(id, interactorId) {
				return substitute(e.getLocalizedString(id),{interactorId:json.stringify(interactorId)});
			}
		},
		{	name: "InvalidInteractorEvent", args: ["name"] },
		{	name: "InvalidInputFilterSpec", args: ["name"] },



		
		//-------------------------------------------------------
		// UI events/connections
		//
		{	name: "ConnectionStillActive", args: ["id"]	},
		{	name: "EventConnectionFailed", args: ["eventName"] },

		
		
		
		//-------------------------------------------------------
		// Viewport
		//
		{	name: "MaxZoomBelowMin" },
		{	name: "MinZoomAboveMax" },

		
		//-------------------------------------------------------
		// Swim lanes
		//
		{	name: "SwimLanesRequireGfxLayout" },
		

		//-------------------------------------------------------
		// User-defined functions
		//
		{
			name: "DropUserFunctionError",
			descriptor: function(id, error){
				if(error.message) {			
					error = error.message;
				}
				return substitute(e.getLocalizedString(id),{error:error});
			}
		},
		{
			name: "UndoUserActionError",
			descriptor: function(id, action, error){
				if(error.message) {
					error = error.message;
				}
				return substitute(e.getLocalizedString(id),{action:action,error:error});
			}
		},

		
		
		
		//-------------------------------------------------------
		//
		{	name: "LASTERRORCODE" }
	];
	
	//	
	//	Iterate the table and declare the errors.
	//
	
	for( var i = 0; i<errorTable.length; i++ ) {
		var code = "CWZDD"+(2000+i)+"E"; // Should we better put this on the table and take care of possible errors/repetitions/maintainance problems/etc.?
		// AVA: yes, it think it would be better. My experience: I got 
		// CWZDD2016E: A node or link layout algorithm is needed. 
		// Then, to debug, I grepped for "2016" everywhere and found nothing...
		var ed = errorTable[i];
		e.declareError(code,ed.name,ed.descriptor||ed.args||ed.description||[]);
	}
	
	return e;
});
