/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/config",
"dojo/_base/array",
"dojox/gfx",
"dojox/gfx/matrix",
"../util/GraphUtil",
"../util/Serializer",
"../util/ErrorReporter",
"./undo/MultipleAction",
"./undo/ConnectAction",
"./undo/PasteNodeAction"
], function(
declare,
lang,
config,
array,
gfx,
m,
gu,
Serializer,
R,
MultipleAction,
ConnectAction,
PasteNodeAction
){

var mixinAtts = function mixinAtts(target,src,these) {
//	var count = 0;
	for(var i = 0; i < these.length; i++ ) {
		if(src[these[i]] !== undefined) {

// debugging:
//			if(target[these[i]]) {
//				console.log("overriding ",these[i], ",",target[these[i]], ",",src[these[i]]);
//			} else {
//				console.log("adding     ",these[i], ",",target[these[i]], ",",src[these[i]]);
//			}

			target[these[i]] = src[these[i]];
			
//			count ++;
		}
	}
//	return count;
};

var serializeAtt = function serializeAtt(obj,t,name) {
	var v;
	if(obj["get"+name]){
		v = obj["get"+name]();
		if(v){ t[name] = v; }
	}
};

var deserializeAtt = function deserializeAtt(obj,t,name) {
	if(name in t) {
		obj["set"+name](t[name]);
	}
};	

serializeShapeStates = function serializeShapes ( shape ){
	
	var t = {}, v;
	
	if(shape._isIBMDiagramGraph) {
		return; // we skip the Graph object at subgraphs 
	}
	
	if(shape instanceof gfx.Group){
		t.children = array.map(shape.children, serializeShapeStates);
	}

	if(shape.getLayout) {
		v = shape.getLayout();
		if(v) {
			t.layout = v.getConfig();
		}
	}
	
	serializeAtt(shape,t,"ExplicitSize");

	mixinAtts(t,shape,["selectedStyle"]);
	mixinAtts(t,shape,["minimumSize","maximumSize", "valign", "halign", "col", "row","margins"]);

	return t;	// shape
};

function deserializeShapeStates(shape,t) {

	if(shape._isIBMDiagramGraph) {
		return;
	}

	if(shape instanceof gfx.Group){
		
		if(!t.children) {
			//console.log("not an array @ t:",shape,t);
		} else {
			if(shape.children.length != t.children.length) {
				//console.log("not of same length:",shape.children.length,t.children.length);
			} else {
				mixinAtts(shape,t,["selectedStyle"]);
				
				if(t.layout) {
					shape.setLayout(t.layout);
				}

				deserializeAtt(shape,t,"ExplicitSize");
				
				mixinAtts(shape,t,["minimumSize","maximumSize", "valign", "halign", "col", "row","margins"]);
			}
		}
		
		for(var i = 0; i< shape.children.length; i++) {
			deserializeShapeStates(shape.children[i],t.children[i]);
		}
	}
};

var DiagramSerializer =
declare("ibm_ilog.diagram.editor.DiagramSerializer",null,{
	_serializer: null,
	_notifiyingObject: null,
	_diagram: null,
	_transformFunction: null,
	
	constructor: function(diagram,transformFunction,notifiyingObject){
		this._notifiyingObject = notifiyingObject;
		this._diagram = diagram;
		this._transformFunction = transformFunction;
		this._initializeSerializer();
	}, 
	serialize: function(toSerialize){
		return this._serializer.serialize(toSerialize);
	},
	deserialize: function(serialized,container){
		return this._serializer.deserialize(serialized,container);
	},
	_initializeSerializer: function(){
		var thiz = this;
		this._serializer = new Serializer({
			getId: function(ge) {
				return ge.getId();
			},
			serializeNodeData: function(ge){
				var serializedData = {
					id:ge.getId(),
					label:ge.getLabel(),
					transform:m.clone(ge.getTransform()),
					uibb:ge.getBounds(this.getDiagram().getViewport().getSurface()),
					template:ge._template,
					shapesStates:serializeShapeStates(ge)
				};
				this.getNotifiyingObject().onSerialize(ge,serializedData);
				return serializedData;
			},
			deserializeNodeData: function(s,newByOldId,container){
			    var node = this.getDiagram().createNode(s.template,null,container.graph);
			    var t = this.getTransformFunction()(s.transform,container.graph,s);
			    node.setTransform(t);
			    node.setLabel(s.label);

			    deserializeShapeStates(node,s.shapesStates);
			    if (config.useGfxLayout) {
					node.invalidate();
				}
			    
			    var undoAction = this._createNodeUndoAction(s,node.getId(),t,container,false);
			    this.getNotifiyingObject().onDeserialize(s,node,container,undoAction);
			    container.undo.addAction(undoAction);
			    return {created:node};
			},
			serializeSubgraphData: function(ge){
				var serializedData = {
					id:ge.getId(),
					label:ge.getLabel(),
					collapsed:ge.isCollapsed(),
					clss:ge.constructor,
					transform:m.clone(ge.getTransform()),
					uibb:ge.getBounds(this.getDiagram().getViewport().getSurface()),
					template:ge._template,
					collapsedShapeStates:serializeShapeStates(ge._collapsedGroup),
					expandedShapeStates:serializeShapeStates(ge._expandedGroup)
				};
				this.getNotifiyingObject().onSerialize(ge,serializedData);
				return serializedData;
			},
			deserializeSubgraphData: function(s,newByOldId,container){
			    var sg = this.getDiagram().createSubgraph(s.template,null,container.graph,s.clss);
			    var t = this.getTransformFunction()(s.transform,container.graph,s);
			    sg.setLabel(s.label);

			    // TODO this is a hack to prevent current imposibility of creating subgraphs while collapsed
			    // assign position after deserializing
			    setTimeout(function(){
				    if(s.collapsed!=sg.isCollapsed()) {
				    	sg._setCollapsed(s.collapsed,false); // TODO allow animation control publicly at Subgraph
				    }
				    sg.setTransform(t);
			    },1);

			    // TODO hack: hide if we can
			    
			    // TODO fixed by gino commented and added sg.setTransform(t);
			    
			    /*if(!container.graph._owningSubgraph) {
			    	sg.setTransform(m.translate(ibm_ilog.diagram._invisibleLocation,ibm_ilog.diagram._invisibleLocation));
			    } else {
				    sg.setTransform(t);
			    }*/
			    //sg.setTransform(t);

				deserializeShapeStates(sg._collapsedGroup,s.collapsedShapeStates);
				deserializeShapeStates(sg._expandedGroup,s.expandedShapeStates);
				if (config.useGfxLayout) {
					sg.invalidate();
				}
			    var undoGroup = new MultipleAction();
			    var undoAction = this._createNodeUndoAction(s,sg.getId(),t,container,true);
			    this.getNotifiyingObject().onDeserialize(s,sg,container,undoAction);
			    undoGroup.addAction(undoAction);
			    container.undo.addAction(undoGroup);
			    return {created:sg,graph:sg.getGraph(),undo:undoGroup};
			},
			serializeLinkData: function(ge){
				var serializedData = {
					startId:ge.getStartNode().getId(),
					endId:ge.getEndNode().getId(),
					shapeType:ge.getShapeType(),
					transform:m.clone(ge.getTransform()),
					intermediatePoints:ge.getIntermediatePoints()
				};
				this.getNotifiyingObject().onSerialize(ge,serializedData);
				return serializedData;
			},
			deserializeLinkData: function(s,newByOldId,container){
				if(newByOldId.contains(s.startId) && newByOldId.contains(s.endId)) {
					var link = container.graph.createLink();
					var start = newByOldId.item(s.startId).created;
					var end = newByOldId.item(s.endId).created;
					link.setStartNode(start);
					link.setEndNode(end);
					link.setShapeType(s.shapeType);
					var points = lang.clone(s.intermediatePoints);
					if (points) {
					    var t = this.getTransformFunction()(s.transform,container.graph,null);
						for (var i = 0; i < points.length; i++) {
							points[i] = t.transformPoint(points[i]);
						}
					}
					link.setIntermediatePoints(points);
					this.getDiagram()._onLinkCreated(link,start,end,this.getDiagram());
					var undoAction = this._createLinkUndoAction(link,container);
					this.getNotifiyingObject().onDeserialize(s,link,container,undoAction);
					container.undo.addAction(undoAction);
					return {created:link};
				}
			},
			_createNodeUndoAction: function(s,newId,t,container,isSubgraph){
			    var action = new PasteNodeAction();
			    action.elementId = newId;
			    action.parentId = this.getDiagram().getUndoManager().getParentId(container.graph);
			    action.template = s.template;
			    action.transformation = m.clone(t);
			    action.label = s.label;
			    action.isSubgraph = isSubgraph;
			    action.collapsed = s.collapsed;
			    return action;
			},
			_createLinkUndoAction: function(link,container){
				var action = new ConnectAction(this.getDiagram(),link,container.graph);
				return action;
			},
			getDiagram: lang.hitch(thiz,function(){
				return this._diagram;
			}),
			getNotifiyingObject: lang.hitch(thiz,function(){
				if(this._notifiyingObject){
					return this._notifiyingObject;
				}else{
					//Dummy notifyingObject
					return {onSerialize:function(){},onDeserialize:function(){}};
				}
			}),
			getTransformFunction: lang.hitch(thiz,function(){
				
				if(this._transformFunction){
					return this._transformFunction;
				}else{
					return function(t){return t;};
				}
			})
		});
	}
});

return DiagramSerializer;

});
