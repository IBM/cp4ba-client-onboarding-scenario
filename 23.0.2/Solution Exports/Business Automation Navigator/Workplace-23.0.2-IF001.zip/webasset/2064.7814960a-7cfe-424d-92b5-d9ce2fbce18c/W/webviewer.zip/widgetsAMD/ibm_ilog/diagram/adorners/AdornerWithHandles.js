/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"../main",
"dojo/_base/declare",
"dojox/collections/ArrayList",
"./Adorner"
],
function(
iid,
declare,
ArrayList,
Adorner
){

/*=====
var Adorner = ibm_ilog.diagram.adorners.Adorner;
=====*/

var sup = Adorner.prototype;

var a = iid.gfxDeclaration(declare('ibm_ilog.diagram.adorners.AdornerWithHandles', [Adorner], {

	//   
	//	_handles:
	//		The AdornerHandles created for the Adorner
	//
	_handles: null,
	
	initialize: function () {
		
		this._handles = new ArrayList();
		sup.initialize.apply(this,arguments);
	},

	activate: function () {
		//
		// 	summary:
		//		activates all the adorner handles
		//
		this._handles.forEach(function (e) {
			e.activate();
		});
	},

	deactivate: function () {
		//
		// 	summary:
		//		deactivates all the adorner handles
		//
		this._handles.forEach(function (e) {
			e.deactivate();
		});
	},

	_activateHandle: function (attachPointName) {
		if (this[attachPointName] !== undefined) {
			this[attachPointName].activate();
		}
	},

	_deactivateHandle: function (attachPointName) {
		if (this[attachPointName] !== undefined) {
			this[attachPointName].deactivate();
		}
	},

	_createHandle: function (clazz, attachPointName) {
		if (this[attachPointName]) {
			var template = this._templatePool.item(this[attachPointName].template || clazz.templateId);
			var handle = this[attachPointName].createObject(clazz);
			handle.initialize(this, template);
			this[attachPointName] = handle;
			this._handles.add(handle);
			return handle;
		} else {
			return null;
		}
	}
	
}));

return a;

});
