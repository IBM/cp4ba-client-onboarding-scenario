/**
 * An Adorner that places a halo around an activity node. The halo can be a specified color, width
 * and opacity.
 * 
 */
define([
   "dojo/_base/declare",
   "dojo/_base/lang",
   "dojox/gfx/_base",
   "dojox/collections/Dictionary",
   "ibm_ilog/diagram/adorners/Adorner",
   "./ComponentILogAdorner",
   "./TemplatedAdorner",
   "./adornerConstants",
   "./ilogDiagramUtils"
], function(declare, lang, gfx, Dictionary, ILogAdorner, ComponentILogAdorner, TemplatedAdorner, adornerConstants, ilogDiagramUtils) {
   return declare([
      TemplatedAdorner
   ], {

      color : null,
      width : null,
      opacity : null,

      activityHaloAdornerTemplate : [
         {
            dojoAttachPoint : 'baseShape',
            transform : {
               dx : $bind("{{elemBaseLeft}}"),
               dy : $bind("{{elemBaseTop}}")
            },
            children : [
               {
                  dojoAttachPoint : 'halo',
                  shape : {
                     x : 0,
                     y : 0,
                     width : 1,
                     height : 1,
                     r : 3,
                     type : 'rect'
                  },
                  fill : {
                     r : 0,
                     g : 0,
                     b : 0,
                     a : 0
                  },
                  stroke : {
                     color : [
                        255, 255, 0, 0.50
                     ],
                     width : 8
                  }
               }
            ]

         }
      ],

      constructor : function(args) {
         lang.mixin(this, args);
         if (!this.color)
            this.color = "red";

         if (!this.width)
            this.width = 8;

         if (!this.opacity)
            this.opacity = .5;
      },

      adorn : function() {
         try {
            // If already adorned, nothing to do.
            if (this.adorned)
               return;
            // If not a node (not an event or gateway), then don't know what to do.
            if (this.adornerTarget.type != adornerConstants.TYPE_ACTIVITY)
               return;
            // Resolve the node.
            var gfxNode = ilogDiagramUtils.getGfxNodeById(this.adornerTarget.ilogDiagram, this.adornerTarget.id);
            if (!gfxNode)
               return;
            // Create and set the halo from the passed in args
            var template = lang.clone(this.activityHaloAdornerTemplate)[0];
            // Set the invariables of the template
            template.children[0].stroke.color = gfx.normalizeColor(this.color);
            template.children[0].stroke.color.a = this.opacity;
            // Create the ILog adorner and use that
            var dic = new Dictionary();
            dic.add("HaloAdorner", template);
            this.ilogAdorner = this.adornerTarget.ilogDiagram.createAdorner(ComponentILogAdorner, dic, "HaloAdorner");
            this.ilogAdorner.setComponent("halo");
            this.ilogAdorner.setAdorned(gfxNode);
            this.inherited(arguments);
         } catch (e) {
            console.error(e);
         }
      },

      /**
       * Called as part of adorn and when the viewer is resized.
       * 
       */
      updateLayout : function() {
         try {
            if (!this.ilogAdorner)
               return;
            // Scale what needs to be scaled
            var borderWidth = Math.round(this.width * this.ilogAdorner.getZoom());
            var spacing = Math.round(2 * this.ilogAdorner.getZoom());
            // Now layout the shapes.
            var shape = this.ilogAdorner.halo.shape;
            shape.width = this.ilogAdorner.getElemBaseWidth() - spacing + borderWidth;
            shape.height = this.ilogAdorner.getElemBaseHeight() - spacing + borderWidth;
            this.ilogAdorner.halo.setShape(shape);
            var stroke = this.ilogAdorner.halo.strokeStyle;
            stroke.width = borderWidth;
            this.ilogAdorner.halo.setStroke(stroke);
            var transform = this.ilogAdorner.baseShape.getTransform();
            transform.dx = this.ilogAdorner.getElemBaseLeft() - (borderWidth / 2 - 1);
            transform.dy = this.ilogAdorner.getElemBaseTop() - (borderWidth / 2 - 1);
            this.ilogAdorner.baseShape.setTransform(transform);
         } catch (e) {
            console.error(e);

         }
      }

   });

});