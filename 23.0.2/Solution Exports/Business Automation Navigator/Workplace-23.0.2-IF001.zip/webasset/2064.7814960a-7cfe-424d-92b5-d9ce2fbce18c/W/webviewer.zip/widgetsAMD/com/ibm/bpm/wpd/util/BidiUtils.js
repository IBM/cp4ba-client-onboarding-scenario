define(["dojo/_base/kernel",
        "../core/model/shellstate/ShellStateModel",
        "../base/bootstrap"],
function(dojo,
        ShellStateModel,
        bootstrap){

var BidiUtils = {};

/**
 * BidiUtils to include utilities to determine the Base Text Direction and return
 * the corresponding HTML direction setting.
 */

/**
 * Bidi constants
 */
BidiUtils.DEFAULT = 0;
BidiUtils.LTR = 1;
BidiUtils.RTL = 2;
BidiUtils.CONTEXTUAL = 3;

/**
 * Return true if a given ch is a Bidi character
 * @param ch
 * @returns {Boolean}
 */
BidiUtils.isBidiChar = function (ch){
	if (ch >= 0x05d0 && ch <= 0x065f ||
		ch >= 0x066a && ch <= 0x06ef ||
		ch >= 0x06fa && ch <= 0x07ff ||
		ch >= 0xfb1d && ch <= 0xfdff ||
		ch >= 0xfe70 && ch <= 0xfefc)
		return true;
	else
		return false;
};

/**
 * Return true if a given ch is a Latin character
 * @param ch
 * @returns {Boolean}
 */
BidiUtils.isLatinChar = function (ch){
    if((ch > 64 && ch < 91)||(ch > 96 && ch < 123))
        return true;
    else            
    	return false;    
};


/**
 * Check the direction for the given string
 * @param text
 * @return LTR or RTL
 */
BidiUtils.checkContextual = function (text){
	var len = text.length;
	for(var i = 0;i < len;i++)  {
		symbol = text.charCodeAt(i);
		if(this.isBidiChar(symbol))
			return this.RTL;
		else if(this.isLatinChar(symbol))
			return this.LTR;
	}
	return this.LTR;
};


/**
 * Check the direction for the given string
 * @param text
 * @return boolean
// */
//BidiUtils.isContextualRTL = function (text){
//	var contextualValue = this.checkContextual(text);
//	if (RTL==contextualValue)
//		return true;
//	return false;
//};

/**
 * Check if there is any character non-Latin
 * Called externally
 * @param text
 * @return boolean
 */
BidiUtils.hasNonLatinChar = function (text){
	var len = text.length;
	for(var i = 0;i < len;i++)  {
		symbol = text.charCodeAt(i);
		if(symbol!=32 && !this.isLatinChar(symbol)) 
			return true;
	}
	return false;
};


/**
 * Return the bidi direction value (LTR or RTL) based on the text and the preference.
 * @param text
 * @return LTR or RTL
 */
BidiUtils.getDir = function (text){
	// get context from the preference page: DEFAULT, LTR, RTL or CONTEXTUAL
	var btd = "default";

	// Check to see if the global has been created. The global is defined in the bootstrap, but depending on the component that
	// uses the base code the bootstrap might not have been invoked. As well check for localization type. It might be set differently
	// depending on the product using the base.
	if (bootstrap.getBPMGlobals().WPD_ModelTypeProviderRegistry) {
		var dojoGlobal = bootstrap.getBPMGlobals().WPD_ModelTypeProviderRegistry._docTypeProviderMap;
		if (dojoGlobal.ProcessInstanceType && dojoGlobal.ProcessInstanceType.config && dojoGlobal.ProcessInstanceType.config.userBTD) {
			btd = dojoGlobal.ProcessInstanceType.config.userBTD;	
		}
	}
	
	if (!btd) {
		var stateModel = ShellStateModel.getInstance();
		if (stateModel)
			btd = stateModel.getBTDPreference();
	}
	
	// parse the last part only
	if (!btd)
		btd = "default";
	var lastDot = btd.lastIndexOf('.');
	if (lastDot>=0 && lastDot<btd.length-1) {
		btd = btd.substring(lastDot+1);
	}
	if (btd=="default")
		dir = this.DEFAULT;
	else
	if (btd=="ltr")
		dir = this.LTR;
	else
	if (btd=="rtl")
		dir = this.RTL;
	else
	if (btd=="contextual" || btd == "ctx")
		dir = this.CONTEXTUAL;
	else
		dir = this.DEFAULT;
	if (dir==this.DEFAULT || dir==this.LTR)
		return this.LTR;
	else
	if (dir==this.RTL)
		return this.RTL;
	else {
		// assume check context
		return this.checkContextual(text);
	}
};

/**
 * Return the bidi direction string (ltr or rtl) based on the text and the preference.
 * @param text
 * @return "ltr" or "rtl"
 */
BidiUtils.getDirValue = function (text){
	var dir = this.getDir(text);
	if (dir==this.RTL)
		return "rtl";
	else
		return "ltr";
};


/**
 * Return the RTL text with the (), {} and [] in the right direction
 * @param text
 * @return String
 */
BidiUtils.getRTLTextWithBracket = function (text){
    var dummyEle = document.createElement("title");
    var result = "";
	for (var i=0; i<text.length; i++) {
		if (text[i]=='(' || text[i]=='{' || text[i]=='[') {
			result += "&#x202b;";
		}
		else
		if (text[i]==')' || text[i]=='}' || text[i]==']') {
			result += "&#x202c;";
		}
		result += text[i];
	}
	return result;
};

/**
 * Return the Calendar type based on the preference.
 * @return calendarPreference// "gregorian", "islamic", "hebrew"
 */
//BidiUtils.getCalendarType = function (){
//	// get context from the preference page: DEFAULT, LTR, RTL or CONTEXTUAL
//	return com.ibm.bpm.wpd.core.model.shellstate.ShellStateModel.getInstance().getCalendarPreference();
//};

/**
 * Return the calendar date type value based on the calendar preference
 * @return calendar date time value
 */
//BidiUtils.getDateTimeValue = function(value) {
//	var calendarType = this.getCalendarType();
//	var dateFormat;
//	var timeFormat;
//    if (calendarType == "islamic") {
//        dateFormat = "MMMM d, yyyy h:mm:ss a";
//        timeFormat = "h:mm:ss a";
//        var dateHij = dojox.date.islamic.locale.parse(value, {datePattern: dateFormat, selector: "date"});
//        return dojox.date.islamic.locale.parse(dateHij, {datePattern: dateFormat, selector: "date"});
//    } 
//    else if (calendarType == "hebrew") {
//        dateFormat = "dd MMMM yyyy HH:mm:ss";
//        timeFormat = "HH:mm:ss";
//        return dojox.date.hebrew.locale.parse(value, {datePattern: dateFormat, selector: "date"});
//        return dojox.date.hebrew.locale.parse(dateHeb, {datePattern: dateFormat, selector: "date"});
//    }
//    return value;
//};

return BidiUtils;
});