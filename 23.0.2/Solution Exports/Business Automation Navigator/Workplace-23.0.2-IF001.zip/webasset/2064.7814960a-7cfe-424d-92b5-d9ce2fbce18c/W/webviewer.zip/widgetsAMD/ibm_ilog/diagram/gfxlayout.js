/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/has!config-useGfxLayout?./gfxlayout/_base:",
"dojo/has!config-useGfxLayout?./gfxlayout/Layout:",
"dojo/has!config-useGfxLayout?./gfxlayout/Engine:",
"dojo/has!config-useGfxLayout?./gfxlayout/GridLayout:",
"dojo/has!config-useGfxLayout?./gfxlayout/StackLayout:",
"dojo/has!config-useGfxLayout?./gfxlayout/FillLayout:"
],
function(gfxlayout, Layout, Engine, GridLayout, StakcLayout, FillLayout){
	return gfxlayout;
});
