/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"./OverviewInteractor",
"../interactors/DragInteractor",
"../util/Geometry",
"../util/GraphUtil"
],
function(
declare,
OverviewInteractor,
DragInteractor,
g,
gu
){

// Note: OverviewInteractor must be last in the superclass array since it overrides initialize()

/*=====
var DragInteractor = ibm_ilog.diagram.interactors.DragInteractor;
var OverviewInteractor = ibm_ilog.diagram.overview.OverviewInteractor;
=====*/

var OverviewPanInteractor =
declare("ibm_ilog.diagram.overview.OverviewPanInteractor", [DragInteractor, OverviewInteractor], {
	//
	//	summary:
	//		An OverviewPanInteractor pans the viewport when the user drags on 
	//		the overview and centers the viewport on a point when the user clicks at 
	//		that point.	//

	_dragCursor: "move",


	//
	//	_constrain: Boolean
	//		Constrains view rectangle movements to the viewport's content area
	//
	_constrain: true,
	
	setConstrain: function( /*boolean*/ b ) {
		this._constrain = b;
	},
	
	getConstrain: function() {
		return this._constrain;
	},
	
	_initialize: function() {
		this.inherited(arguments);
		this._cursorStyle = gu.getSurface(this._overview._output).rawNode.style;
	},
	
	_declareStates: function () {
		this._declareState("idle", ["fit","start","mouseenter","mouseleave"]);
		this._declareState("active", ["first", "move", "end", "cancelOnDragStart", "cancelOnSelectStart","mouseenter","mouseleave"]);
	},
	
	getDefaultConnections: function() {
		var cs = this.inherited(arguments);
		cs.fit = {
				src: this._getInitialEventSource(),
				srcEvt: "onmousedown",
				connectTo: "_fitContents",
				filter: this._buildInputFilter({shift:true,button:0}),
				gfxConnect:true
			};
		cs.mouseenter = {
				src: this._getInitialEventSource(),
				srcEvt: "onmouseenter",
				connectTo: "_hover",
				gfxConnect:true
			};
		cs.mouseleave = {
				src: this._getInitialEventSource(),
				srcEvt: "onmouseleave",
				connectTo: "_leave",
				gfxConnect:true
			};
		return cs;
	},
	
	_updateCursor: function() {
		if(this._hovered || this._state._id=="active") {
			this._showDragCursor();
		} else {
			this._hideDragCursor();
		}
	},
	
	_hover: function() {
		this._hovered = true;
		this._updateCursor();
	},
	
	_leave: function() {
		this._hovered = false;
		this._updateCursor();
	},

	_getInitialEventSource: function() {
		return this._overview.getEventSource(); 
	},
	
	_fitContents: function(e) {
		this._viewport.setViewRect(this._viewport.getContentRect());
	},

	_dragPreStart: function(e) {
		this._cursorStyle = this._cursorStyle || gu.getSurface(this._overview._output);
		var v = this._viewport;
		this.inherited(arguments);
		this._firstViewRect = v.getViewRect();
	},
    
	_dragMove: function(e) {
    this.inherited(arguments);

		// scale delta to zoom level to get delta in model coords
		var panDelta = g.mulPoint(this._totalDelta,1/this._overview.getZoom());
		
		var newViewRect = this._constrainedViewRect(g.moveRect(this._firstViewRect,panDelta));
		
		this._viewport.setViewRect( newViewRect, {instant:true} );
  },
	
	_dragEnd: function(e) {
		//
		//	summary:
		//		Terminates the current panning process.
		//
		var v = this._viewport;
		var dragged = this.hasDragged; // inherited will clear this;
		this.inherited(arguments); // clears hadDragged
		if(!dragged) {
			
			var newViewRect = this._constrainedViewRect(g.rectCenteredAt(this._viewport.getViewRect(), this.eventViewportLocation(e)));

			this._viewport.setViewRect( newViewRect );
		}
	},

  _constrainedViewRect: function( viewRect ) {
	  if(this._constrain) {
			viewRect = g.constrainRect(viewRect,g.addRect(this._viewport.getContentRect(),this._viewport.getViewRect()));
		}
	  return viewRect;
  }

});

return OverviewPanInteractor;

});
