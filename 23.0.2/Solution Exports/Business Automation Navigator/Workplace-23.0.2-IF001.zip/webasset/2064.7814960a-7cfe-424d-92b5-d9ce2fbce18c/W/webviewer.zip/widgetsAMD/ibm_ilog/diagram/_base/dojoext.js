/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/lang", "dojo/dom", "dojo/_base/html"],
function(lang, dom, html){

	// TODO:
	// For now we must create a global object since there are still references to ibm_ilog.diagram._base.gfxext
	// in the rest of the code, but when AMD migration is finished all global references should be replaced
	// by module references and this will be replaced by a simple object creation:
	// var de = {};
	var de = lang.getObject("ibm_ilog.diagram._base.dojoext", true);
	
	// Dojo patches and cross-version helper functions
	
	// dojo.coords marked with dojo.deprecated in 1.7
	de.coords = function(node, includeScroll){
		var n = dom.byId(node), mb = html.marginBox(n), abs = html.position(n, includeScroll);
		mb.x = abs.x;
		mb.y = abs.y;
		return mb;
	};
	
	return de;
});
