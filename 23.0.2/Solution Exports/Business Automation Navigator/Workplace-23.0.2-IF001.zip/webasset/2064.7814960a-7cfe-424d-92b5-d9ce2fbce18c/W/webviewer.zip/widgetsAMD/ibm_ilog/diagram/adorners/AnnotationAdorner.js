/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"../main",
"dojo/_base/declare",
"dojo/_base/connect",
"dojox/collections/ArrayList",
"dojox/collections/Dictionary",
"../templating",
"./Adorner",
"./MoveAnnotationInteractor"
],
function(
iid,
declare,
connect,
ArrayList,  // not used directly here, but used in Diagram to manage annotations
Dictionary, // not used directly here, but used in Diagram to manage annotations
templating,
Adorner,
MoveAnnotationInteractor
){

/*=====
var Adorner = ibm_ilog.diagram.adorners.Adorner;
=====*/

// Note on Dictionary/ArrayList: we require them here, so that on mobile we just have to tell users
// to require this module to use annotations.

var AnnotationTargetAdorner =
iid.gfxDeclaration(declare('ibm_ilog.diagram.adorners.AnnotationTargetAdorner', [Adorner], {

	_link: null,
	
	setLink: function(link) {
		this._link = link;
	},
	
	_onChange: function() {
		if(this._link) {
			this._link.revalidateLinkShape(); // immediate
			this._link.invalidateLinkShape(); // .. and failproof
		}
	}
}));

var sup = Adorner.prototype;

var a = iid.gfxDeclaration(declare('ibm_ilog.diagram.adorners.AnnotationAdorner', [Adorner], {
	//
	//	summary:
	//		An Adorner which displays node annotations
	//
	
	//
	//	annotationChangedEvent:
	//		The event to watch for associated with the annotation changing its value. 
	//
	annotationChangedEvent: "setAnnotation", 
	
	//
	//	annotationGetter:
	//		The method to invoke in the adorned entity to get the annotation. This is used in 
	//		the default implementation of refreshAnnotation. 
	//
	annotationGetter: "getAnnotation",
	
	
	_moveInteractor: null,
	
	initialize: function() {
		this.inherited(arguments);
		this._moveInteractor = new MoveAnnotationInteractor();
		this._moveInteractor.initialize(this._viewport,this);
		this._moveInteractor.setManager(this._diagram._interactors);
		
	},
	
	_reconnectNotifications: function() {
		//
		//	Add an additional connection to watch for "annotation changed" events.
		//
		Adorner.prototype._reconnectNotifications.apply(this,arguments);
		var e = this._adorned;
		if (e) {
			this.refreshAnnotation();
			this._changeConnections.push(connect.connect(e,this.annotationChangedEvent,this,"refreshAnnotation"));
		}
	},
	
	refreshAnnotation: function(){
		//
		//	summary:
		//		Update receiver with a new annotation
		//	description:
		//		Current implementation relies on the template referencing 
		//		the "annotation" bindable property of the receiver.
		//		Can be overriden by subclasses to produce specific 
		//		ways of	rendering the annotation like word wrap, etc.
		//
		this.setAnnotation(this._adorned[this.annotationGetter]());
	},

	activate: function () {
		this._moveInteractor.activate();
	},

	deactivate: function () {
		this._moveInteractor.deactivate();
	},
	
	_link: null,
	_target: null,

	_updateLayout: function () {
		sup._updateLayout.apply(this,arguments);
	},
	
	setLink: function(link,target) {
		this._target = target;
		this._link = link;
	},
	
	getLink: function() {
		return this._link;
	},
	
	getTarget: function() {
		return this._target;
	},
	
	setAdorned: function(adorned) {
		this.inherited(arguments);
		if(this._target) {
			this._target.setAdorned(adorned);
		}
	},
	
	getBaseShape: function() {
		return this.baseShape;
	},
	
	destroy: function() {
		sup.destroy.apply(this,arguments);
	},
	
	_onChanged: function() {
		if(this._link) {
			this._link.revalidateLinkShape(); // immediate
			this._link.invalidateLinkShape(); // .. and failproof
		}
	}
	
}));

templating.declareBindableProperty(a, "annotation", "");

a.AnnotationTargetAdorner = AnnotationTargetAdorner;

return a;

});
