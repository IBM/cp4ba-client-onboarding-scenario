/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/sniff",
"dojo/keys",
"./Interactor",
"../util/Geometry"
],
function(
declare,
lang,
has,
keys,
Interactor,
Geometry
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var ZoomKeyInteractor =
declare("ibm_ilog.diagram.interactors.ZoomKeyInteractor", [Interactor], {
	//summary:
	//		This Interactor manages the ViewPort Zoom through the keyboard interaction.
	//		This Interactor have 2 connections: zoomIn, zoomOut.
	
	_diagram: null,
	_incrementFactor: null,
	
	initialize: function (diagram) {
	// summary:
    //		initialize the new instance.
    // diagram: ibm_ilog.diagram.widget.Diagram
    //		the associated diagram.				
		this._diagram = diagram;
		this.setIncrementFactor(1.5);
		return this._initialize();
	},
	setIncrementFactor: function(incrementFactor){
		// summary: 
		//		sets the zoom increment factor
		// increment: integer
		//		the increment factor to be set
		this._incrementFactor = incrementFactor;
	},
	getIncrementFactor: function(){
		// summary: 
		//		gets the zoom increment factor
		// return: integer
		return this._incrementFactor;
	},
	zoomOut: function(e){
		// summary:
	    //		This method zooms the diagram out
	    // e: Event object
	    //		the event to be treated.
		this._zoom(1/this._incrementFactor);
	},
	zoomIn: function(e){
		// summary:
	    //		This method zooms the diagram in
	    // e: Event object
	    //		the event to be treated.
		this._zoom(this._incrementFactor);
	},
	zoomReset: function(e){
		// summary:
	    //		This method reset the diagram zoom (set to 1)
	    // e: Event object
	    //		the event to be treated.
		var v = this._diagram.getViewport();
		var zoom = 1/v.getZoom();
		this._zoom(zoom);
	},
	getKeyInteractorId: function(){
		// summary:
	    //		returns the Interactor Id
		return ZoomKeyInteractor.KeyInteractorId;
	},
	getDefaultConnections: function () {
		// summary:
		//		returns the default event mapping
		
		var connections = {
			zoomIn: {
				hotKey: keys.NUMPAD_PLUS,
				connectTo: "zoomIn",
				filter: this._buildInputFilter({ctrl:true,shift:false})
			}, zoomOut: {
				hotKey: keys.NUMPAD_MINUS,
				connectTo: "zoomOut",
				filter: this._buildInputFilter({ctrl:true,shift:false})
			}, zoomReset: {
				hotKey: keys.NUMPAD_0,
				connectTo: "zoomReset",
				filter: this._buildInputFilter({ctrl:true,shift:false})
			}, zoomReset2: {
				hotKey: 48, // The non-numpad 0 key - always different from numpad 0
				connectTo: "zoomReset",
				filter: this._buildInputFilter({ctrl:true,shift:false})
			}
		};
		if(!has("ff")){ // on all browsers except FF, the non-numpad +/- keys have different keycodes
			lang.mixin(connections,	{
			zoomIn2: {
				hotKey: 187,
				connectTo: "zoomIn",
				filter: this._buildInputFilter({ctrl:true,shift:false})
			}, zoomOut2: {
				hotKey: 189,
				connectTo: "zoomOut",
				filter: this._buildInputFilter({ctrl:true,shift:false})
			}
			});
		}
		return connections;
	},
	_zoom: function(zoomFactor){
		var v = this._diagram.getViewport();
		var ge = this._diagram.getFocusedElement();
		 
		if(ge){
			var point = Geometry.getRectCenter(ge.getBounds(this._diagram.getGraph()));
			this._zoomAt(v,point,zoomFactor);
		}else{
			var currentZoom = v.getZoom();
	        var zoom = currentZoom * zoomFactor;
			v.setZoom(zoom, {
				instant: true
			});
		}
		
		
	},
	_zoomAt: function(viewport, /*Point*/ p, /*Number*/z ) {
		//
		//	summary:
		//		Performs a zoom operation maitaining a pivot point p in the same 
    	//		fixed position relative to the viewport.
		//
    	var cp = viewport.pointClientToContent(p); // content p    	
    	viewport.zoomAt(cp,z);
    }
});

ZoomKeyInteractor.KeyInteractorId = "Zoom";

return ZoomKeyInteractor;

});
