/*
dojo.provide("com.ibm.bpm.wpd.core.model.providers.ModelTypeProviderRegistry");

//dojo.require("com.ibm.bpm.wpd.core.model.documenttype.providers.BaseDocTypeProvider");
//dojo.require("com.ibm.bpm.wpd.sample.model.SampleDocTypeProvider");
//dojo.require("com.ibm.bpm.wpd.core.model.documenttype.providers.SampleDiagramDocTypeProvider");
dojo.require("com.ibm.bpm.wpd.document.bpd.model.BPDDocTypeProvider");
dojo.require("com.ibm.bpm.wpd.document.bpd.model.ServiceTypeProvider");
dojo.require("com.ibm.bpm.wpd.document.bo.model.BODocTypeProvider");
dojo.require("com.ibm.bpm.wpd.document.epv.model.EPVDocTypeProvider");
dojo.require("com.ibm.bpm.wpd.assetlistview.model.AssetListModelTypeProvider");
dojo.require("com.ibm.bpm.wpd.document.ParticipantGrp.model.ParticipantGrpDocTypeProvider");
dojo.require("com.ibm.bpm.wpd.document.webservice.model.webserviceDocTypeProvider");
dojo.require("com.ibm.bpm.wpd.document.uca.model.ucaDocTypeProvider");
dojo.require("com.ibm.bpm.wpd.document.ea.model.eaDocTypeProvider");
dojo.require("com.ibm.bpm.wpd.document.tg.model.tgDocTypeProvider");
dojo.require("com.ibm.bpm.wpd.document.timingInt.model.timingIntDocTypeProvider");
dojo.require("com.ibm.bpm.wpd.document.ais.model.aisDocTypeProvider");
dojo.require("com.ibm.bpm.wpd.compare.model.CompareModelTypeProvider");
dojo.require("com.ibm.bpm.wpd.copy.model.CopyModelTypeProvider");
dojo.require("com.ibm.bpm.wpd.document.sla.model.slaDocTypeProvider");


//TODO remove the dojo.require here and do the require upon registration

dojo.declare("com.ibm.bpm.wpd.core.model.providers.ModelTypeProviderRegistry", null, {
*/
define(["dojo/_base/declare",
        "dojo/_base/connect"],
function(declare,
		connect) {

var _ModelTypeProviderRegistry = declare([], {

	_docTypeProviderMap: null,
	
	_bpmGlobals: null,
	
	//_baseDocTypeProvider:null,
	
	constructor : function (bpmGlobals) {
		this._docTypeProviderMap = {};
		
		this._bpmGlobals = bpmGlobals;
		
		//TODO remove the dojo.require here and do the require upon registration
		/* Initialize the registry by looking up the document types
		 *  that are registered via the ExtensionRegistry or register it here programmatically
		 */
/*		
		//var sampleDocTypeProvider = new com.ibm.bpm.wpd.sample.model.SampleDocTypeProvider();
		//this.registerDocTypeProvider(sampleDocTypeProvider);	
		
		//var diagramDocTypeProviRder = new com.ibm.bpm.wpd.core.model.documenttype.providers.SampleDiagramDocTypeProvider();
		//this.registerDocTypeProvider(diagramDocTypeProvider);
		
		//TO Think ? instantiate here, or instantiate when needed
		var bpdDocTypeProvider = new com.ibm.bpm.wpd.document.bpd.model.BPDDocTypeProvider();
		this.registerDocTypeProvider(bpdDocTypeProvider);
		
		//Register the business object doc type provider
		var boDocTypeProvider = new com.ibm.bpm.wpd.document.bo.model.BODocTypeProvider();
		this.registerDocTypeProvider(boDocTypeProvider);

		if (com.ibm.bpm.wpd.core.model.shellstate.ShellStateModel.getInstance().state == com.ibm.bpm.wpd.core.model.shellstate.ShellStateModel.getInstance().STATE_PROCESS_CENTER){
			var assetListModelTypeProvider = new com.ibm.bpm.wpd.assetlistview.model.AssetListModelTypeProvider();
			this.registerDocTypeProvider(assetListModelTypeProvider);
			
			var compareAssetListModelTypeProvider = new com.ibm.bpm.wpd.compare.model.CompareModelTypeProvider();
			this.registerDocTypeProvider(compareAssetListModelTypeProvider);
			
			var copyModelTypeProvider = com.ibm.bpm.wpd.copy.model.CopyModelTypeProvider();
			this.registerDocTypeProvider(copyModelTypeProvider);
		
			//Register the participant group doc type provider
			var participantGrpDocTypeProvider = new com.ibm.bpm.wpd.document.ParticipantGrp.model.ParticipantGrpDocTypeProvider();
			this.registerDocTypeProvider(participantGrpDocTypeProvider);
		
			//Register the webservice doc type provider
			var wsDocTypeProvider = new com.ibm.bpm.wpd.document.webservice.model.webserviceDocTypeProvider();
			this.registerDocTypeProvider(wsDocTypeProvider);
			
			var epvDocTypeProvider = new com.ibm.bpm.wpd.document.epv.model.EPVDocTypeProvider();
			this.registerDocTypeProvider(epvDocTypeProvider);
			
			//Register the external activity doc type provider
			var eaDocTypeProvider = new com.ibm.bpm.wpd.document.ea.model.eaDocTypeProvider();
			this.registerDocTypeProvider(eaDocTypeProvider);
			
			//Register the uca doc type provider
			var ucaDocTypeProvider = new com.ibm.bpm.wpd.document.uca.model.ucaDocTypeProvider();
			this.registerDocTypeProvider(ucaDocTypeProvider);
			
			//Register the tracking group doc type provider
			var tgDocTypeProvider = new com.ibm.bpm.wpd.document.tg.model.tgDocTypeProvider();
			this.registerDocTypeProvider(tgDocTypeProvider);
			
			//Register the tracking group doc type provider
			var serviceProvider = new com.ibm.bpm.wpd.document.bpd.model.ServiceTypeProvider();
			this.registerDocTypeProvider(serviceProvider);
			
			//Register the tracking group doc type provider
			var timingIntDocTypeProvider = new com.ibm.bpm.wpd.document.timingInt.model.timingIntDocTypeProvider();
			this.registerDocTypeProvider(timingIntDocTypeProvider);
			
			//Register the ais doc type provider
			var aisDocTypeProvider = new com.ibm.bpm.wpd.document.ais.model.aisDocTypeProvider();
			this.registerDocTypeProvider(aisDocTypeProvider);
			
			//Register the sla doc type provider
			var slaDocTypeProvider = new com.ibm.bpm.wpd.document.sla.model.slaDocTypeProvider();
			this.registerDocTypeProvider(slaDocTypeProvider);
			
	
		}
*/
	},
		
	getDocumentTypeByPO : function(poId, assetType){
		if(!_bpmGlobals.WPD_useWLEServer){
			return "BPDDocType";
		}
		var index = poId.indexOf(".");
		if (index <= 0){
			throw new Error("Unexpected PO id format");
		}
		var poType = poId.substring(0, index);
		//We may want to store this as a map in DocumentTypeRegistry
		var docType;
		switch(poType){
			case "25":
				docType = "BPDDocType";
				break;
			case "12":
				docType = "BODocType";
				break;				
			case "1":
				if(assetType == "SCA Service"){
					docType = "aisDocType";
				}
				else{
					docType = "Service";
				}
				break;	
			case "24":
				docType = "ParticipantGrpDocType";
				break;					
			case "7":
				docType = "webserviceDocType";
				break;
			case "21":
				docType = "EPVDocType";
				break;
			case "4":
				docType = "ucaDocType";
				break;				
			case "60":
				docType = "eaDocType";
				break;			
			case "14":
				docType = "tgDocType";
				break;	
			case "15":
				docType = "timingIntDocType";
				break;	
			case "47":
				docType = "slaDocType";
				break;	
			default:
				throw new Error("poType is not registered");
		}
		return docType;
	},
	
	getDocTypeProvider: function(documentType){

		var docTypeProvider = this._docTypeProviderMap[documentType];
		if (!docTypeProvider){
			throw new Error("No DocTypeProvider is registered for " + documentType);
			//if(!this._baseDocTypeProvider){
				//this._baseDocTypeProvider = new com.ibm.bpm.wpd.core.model.documenttype.providers.BaseDocTypeProvider();		
			//}
			//docTypeProvider = this._baseDocTypeProvider;
		}
		return docTypeProvider;
		
	},
	
	registerDocTypeProvider : function(docTypeProvider){
		 this._docTypeProviderMap[docTypeProvider.getDocType()] = docTypeProvider;
	}
	
});

	var _instance;
	var _ModelTypeProviderRegistryWrapper = {
		getInstance : function(bpmGlobals) {
			return (_instance = (_instance || new _ModelTypeProviderRegistry(bpmGlobals)));
		},
		deleteInstance : function() {
			return delete _instance;
		}
	};
	
	return _ModelTypeProviderRegistryWrapper;
});

/*
com.ibm.bpm.wpd.core.model.providers.ModelTypeProviderRegistry.getInstance = function() {
	// summary: 
	//	retrieve the singleton DocumentTypeRegistry instance 
	//  It is initialized in bootstrap.js during start up 
    return dojo.global.BPM.WPD_ModelTypeProviderRegistry;
};
*/