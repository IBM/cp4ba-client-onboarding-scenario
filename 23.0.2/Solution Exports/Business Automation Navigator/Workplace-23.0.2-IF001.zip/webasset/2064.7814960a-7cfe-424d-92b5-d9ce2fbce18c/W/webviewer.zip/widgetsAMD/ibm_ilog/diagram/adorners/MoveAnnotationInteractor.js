/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"../main",
"dojo/_base/declare",
"dojox/gfx/matrix",
"../interactors/DragInteractor"
],
function(
iid,
declare,
m,
DragInteractor
){

/*=====
var DragInteractor = ibm_ilog.diagram.interactors.DragInteractor;
=====*/

var MoveAnnotationInteractor =
declare("ibm_ilog.diagram.adorners.MoveAnnotationInteractor", [DragInteractor], {

	initialize: function ( viewport, annotation ) {
		//
		//	summary:
		//		Initializes the interactor to work with the given handle
		//
		this._annotation = annotation;
		this._viewport = viewport;
		this._initialize();
		return this;
	},
	
	_getInitialEventSource: function () {
		return this._annotation;
	},

	_refreshTransform: function () {
		this._transform = this._annotation._adorned._getRealMatrix().inverse();
	},

	activate: function () {
		this.inherited(arguments);
	},

	_dragPreStart: function () {
		this._refreshTransform();
		this._connect("updateTransforms", this._viewport, "onViewRectChanged", this, "_refreshTransform");

		this.inherited(arguments);
	},

	_dragEnd: function () {
		this._disconnect("updateTransforms");
		var dragged = this.hasDragged, action, D;
		this.inherited(arguments);
	},

	_dragMove: function () {
		this.inherited(arguments);
		var t = this._annotation.getTransform();
		t = m.multiply(t,m.translate(this._delta))
		this._annotation.setTransform(t);
	}

});

return MoveAnnotationInteractor;

});
