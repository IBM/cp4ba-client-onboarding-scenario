/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"./main",
"dojo/_base/config", "dojo/_base/array", "dojo/_base/lang", "dojo/_base/declare",
"dojo/_base/sniff", "dojo/_base/connect", "dojo/fx",
"dojox/gfx", "dojox/gfx/fx", "dojox/gfx/utils", "dojox/gfx/matrix",
"./GraphElement", "./Node", "./templating", "./templates/templates",
"./gfxlayout",
"dojo/has!config-useGfxLayout?./gfxlayout/CanvasLayout:",
"./util/Geometry", "./util/ErrorReporter"
],
function(iid,
config, array, lang, declare,
has, connect, fx,
gfx, gfxfx, gfxutils, matrix,
GraphElement, Node, templating, templates,
gfxlayout,
CanvasLayout,
g, ErrorReporter){

/*=====
Node = ibm_ilog.diagram.Node;
=====*/

var Subgraph =
declare("ibm_ilog.diagram.Subgraph", [Node], {
    // summary:
    //		A Subgraph is a Node that contains a nested Graph.
    // description:
    //		Subgraph objects are used to implemented nested graphs, that is, graphs contained in graphs.
    //		A Subgraph can be collapsed (i.e., its nested graph is hidden and replaced by a plain node)
    //		or expanded (i.e., its nested graph is fully displayed).
    
    // Allows to test the class faster that testing declaredClass
    _isIBMDiagramSubgraph: true,

  	//
  	//	TID: String
  	//		Graph element Type ID, used to distinguish basic graph 
    //		element types:
    //	
    //			N = Node
    //			S = Subgraph
    //			L = Link
    //	
  	//		Usually used as a very fast index into maps based on 
    //		ibm_diagram graph element types.
  	//
    TID: 'S',

    // "attach points" (aka template parts),
    // initialized automatically when reading the template.
    _graph: null,
    _collapsedGroup: null,
    _expandedGroup: null,
    _expandButton: null,
    _collapseButton: null,
    
    _collapsed: false,
    
    _fixedPosition: null,
    _animate: true,
    
    allowsResize: function() {
    	return true;
    },
    
    dispose: function(options) {
    	//	summary:
			//		Dispose this GraphElement.
			//	description:
			//		This function should be called when the GraphElement is completely deleted, that is, when it is removed
			//		from its parent graph and it will never be used again.
			//	options:
    	//		options.noRecurse:
			//			Do not recurse children
    	if(!options || !options.noRecurse) {
	    	array.forEach(this._graph.children, function(c){
	    		c.dispose(options);
	    	});
    	}
    	GraphElement.prototype.dispose.apply(this,arguments);
    },

    _subgraphInitialize: function() {
        // summary:
        //		Performs post-creation initializations such as connecting events, etc.
        // tags:
        //		private
        
        this._fixedPosition = {
            x: 0,
            y: 0
        };
        
        this.baseShape = this._expandedBaseShape;
        
        if (this._graph) {
            this._graph._owningSubgraph = this;
            if (config.useGfxLayout)
                this._graph.setLayout(new CanvasLayout());
        }
        this._hide(this._collapsedGroup);
        
		try { // throws errors in Silverlight for example
			if (this._expandedBaseShape) {
				this._expandedBaseShape.connect("ondblclick", this, this._collapseButtonClicked);
				if (iid.mobileEnabled) 
					this._expandedBaseShape.connect("ontouchend", this, this._collapseButtonDoubleTap);
			}
			if (this.titleShape) {
				this.titleShape.connect("ondblclick", this, this._collapseButtonClicked);
				if (iid.mobileEnabled) 
					this.titleShape.connect("ontouchend", this, this._collapseButtonDoubleTap);
			}
			
			if (this._collapsedBaseShape) {
				this._collapsedBaseShape.connect("ondblclick", this, this._expandButtonClicked);
				if (iid.mobileEnabled) 
					this._collapsedBaseShape.connect("ontouchend", this, this._expandButtonDoubleTap);
			}
			if (this.textShape) {
				this.textShape.connect("ondblclick", this, this._expandButtonClicked);
				if (iid.mobileEnabled) 
					this.textShape.connect("ontouchend", this, this._expandButtonDoubleTap);
				
			}
		} catch(err){}
        // setup mouse listeners on expand/collapse buttons:
        if (this._expandButton) {
            this._expandButton.connect("onclick", this, this._expandButtonClicked);
        	if (iid.mobileEnabled) {
				try {
					this._expandButton.connect("ontouchend", this, this._expandButtonTouch);
				} catch (err) {}
			}
        }
        if (this._collapseButton) {
            this._collapseButton.connect("onclick", this, this._collapseButtonClicked);
        	if (iid.mobileEnabled) {
				try {
					this._collapseButton.connect("ontouchend", this, this._collapseButtonTouch);
				} catch(err){}
			}
        }
		
        if (!config.useGfxLayout)
		  this._doLayout();
    },
    
    applyTemplate: function(/*String||Object*/template, /*Object||ibm_ilog.diagram.data.dtlbinding.BoundContext*/context) {
        // summary:
        //     Applies the specified template on this subgraph.
        
        var c = this.inherited(arguments);
        if (c)
            this._subgraphInitialize();
        return c;
    },
    
    getGraph: function() {
        // summary:
        //		Gets the nested graph contained in this Subgraph.
        // returns: ibm_ilog.diagram.Graph
        //		The Graph object contained in this Subgraph.
        return this._graph;
    },
    
    setAnimate: function(/*Boolean*/value){
        // summary:
        //     Sets whether the expand/collapse operation is animated. The default value is true.
        // value: Boolean
    	//		Indicates whether the expand/collapse operation is animated.
        this._animate = value;
        return this;
    },
    
    getAnimate: function() {
        // summary:
        //     Returns whether the expand/collapse operation is animated.
        return this._animate;
    },
    
    isCollapsed: function() {
        // summary:
        //		Gets the collapsed state of this Subgraph.
        // returns: Boolean:
        //		True if the subgraph is collapsed, or false if the subgraph is expanded.
        return this._collapsed;
    },
    setCollapsed: function(/*Boolean*/collapsed, /*Boolean*/animate) {
        // summary:
        //		Collapses or expands this subgraph.
        // collapsed: Boolean:
        //		If true, the subgraph is collapsed, otherwise it is expanded.
        // animate: Boolean
    	//		If specified, indicates whether the expand/collapse operation is animated.
    	//		If this argument is not specified, the <code>getAnimate()</code> flag is used instead.
        
        this._setCollapsed(collapsed, arguments.length == 2 ? animate : this._animate);
        return this;
    },
    _setCollapsed: function(/*Boolean*/v, /*Boolean*/animate) {
        // summary:
        //		Internal method to collapse/expand the subgraph.
        // description:
        //		This method does nothing if v is equal to isCollapsed().
        // v: Boolean:
        //		True to collapse, false to expand.
        // animate: Boolean:
        //		True to animate.
        // tags:
        //		private
        
        if (v != this._collapsed) {

					if(this._animating)
						return;
						
			  if(!this.canCollapse())
				return;
					
		      if (config.useGfxLayout) {
		          this.suspendInvalidate();
		      }
		  
		      this._collapsed = v;
		
		      this.baseShape = v ? this._collapsedBaseShape : this._expandedBaseShape;
		      
		      var toHide, toShow;
		      if (this._collapsed) {
		          toHide = this._expandedGroup;
		          toShow = this._collapsedGroup;
		      } else {
		          toHide = this._collapsedGroup;
		          toShow = this._expandedGroup;
		      }
		      
		      var bbox = toHide.getLocalBoundingBox();
		      
		      this._show(toShow);
		
		      this._realign(toShow, bbox);
			
		      if (animate && !iid.isVml) {
		        var anim = fx.combine([this.__animateShowHide(toShow, true), this.__animateShowHide(toHide, false)]);
		        connect.connect(anim, "onAnimate", this, this._invalidateIntergraphLinks);
						this._animating = true;
		        this.onCollapsedChanged();
		          
		             	connect.connect(anim, "onEnd", this, function(){
							if (config.useGfxLayout) {
								this.resumeInvalidate(true);
								gfxlayout.doPendingValidate(this);
							}
							delete this._animating;
			        this.onCollapsedAnimated();
						});
		                         
		        anim.play();
		      } else {
		        this.onCollapsedChanged();
		        
		        this._hide(toHide);
		        
		        this._invalidateIntergraphLinks();
		
		        if (config.useGfxLayout) {
		            this.resumeInvalidate(true);
					gfxlayout.doPendingValidate(this);
		        }
		        
		      }
		      this._changeSelectionStyle(this.isSelected());
        }
    },
    
	canCollapse: function() {
		// summary:
		//		Indicates if this Subgraph can be collapsed.
		// description:
		//		Indicates if this Subgraph can be collapsed.
		//		This method always returns true for the Subgraph class,
		//		it can be overridden in subclasses that do not support collapsing.
		// returns:
		//		True if this Subgraph can be collapsed, false otherwise.
		
		return true; // Boolean
	},
	
    getFixedPosition: function() {
        // summary:
        //		Gets the fixed position used to realign the subgraph when it is expanded/collapsed.
        // returns:
        //		An object with 'x' and 'y' properties representing a ratio (between 0 and 1) of the subgraph width/height.
        return this._fixedPosition;
    },
    
    setFixedPosition: function(position) {
        // summary:
        //		Sets a fixed position used to realign the subgraph when it is expanded/collapsed.
        // description:
        //		When a subgraph is expanded or collapsed, it is automatically realigned so that its position
        //		in the new state (expanded or collapsed) matches the position in the previous state.
        //		This method specifies how the subgraph will be realigned by defining a fixed position relative
        //		to the subgraph width/height.
        //		For example, setFixedPosition({x:0, y:0}) (the default value)
        //		realigns the subgraph so that its top-left corner stays at the same position,
        //		and setFixedPosition({x:0.5, y:0.5})
        //		realigns the subgraph so that its center stays at the same position.
        // position:
        //		An object with 'x' and 'y' properties representing a ratio (between 0 and 1) of the subgraph width/height.
        
        if (typeof(position) != 'object' || !('x' in position) || !('y' in position)) 
            ErrorReporter.error("UnexpectedArgument", this, "setFixedPosition", "position", position);
        
        this._fixedPosition.x = position.x;
        this._fixedPosition.y = position.y;
        return this;
    },
    
    
    _realign: function(group, bbox) {
        // summary:
        //		Realigns the position of the shown group
        //		based on the bbox of the hidden group
        // tag: private
        
        var bb = group.getLocalBoundingBox();
        if (!bb) return;
        var newx = bbox.x + this._fixedPosition.x * (bbox.width - bb.width);
        var newy = bbox.y + this._fixedPosition.y * (bbox.height - bb.height);
        if (bb.x != newx || bb.y != newy) 
            group.applyLeftTransform(matrix.translate(newx - bb.x, newy - bb.y));
    },
	
    _saveStyles: function(group) {
        // summary:
        //		Workaround for IE: removing a shape clears all its styles.
        // tags:
        //		private
        gfxutils.forEach(group, function(shape) {
            if (shape.setFill) {
                shape.oldFill = shape.getFill();
            }
            if (shape.setStroke) {
                shape.oldStroke = shape.getStroke();
            }
            if (shape.setFont) {
                shape.oldFont = shape.getFont();
            }
            if (shape.setShape) {
                shape.oldShape = shape.getShape();
            }
        }, null);
    },
    
    _restoreStyles: function(group) {
        // summary:
        //		Workaround for IE: removing a shape clears all its styles.
        // tags:
        //		private
        gfxutils.forEach(group, function(shape) {
            try {
                if (config.useGfxLayout)
                    shape.suspendInvalidate();
                
                if (shape.oldFill) {
                    shape.setFill(shape.oldFill);
                }
                if (shape.oldStroke) {
                    shape.setStroke(shape.oldStroke);
                }
                if (shape.oldFont) {
                    shape.setFont(shape.oldFont);
                }
                if (shape.oldShape) {
					if('text' in shape.oldShape) // text may have been edited
						shape.oldShape.text = shape.getShape().text;
                    shape.setShape(shape.oldShape);
                }
            } finally {
                if (config.useGfxLayout) {
                    if (shape.oldShape && 'text' in shape.oldShape) 
                        shape._explicitSize = null;
                    shape.resumeInvalidate(true);
                }
            }
        }, null);
    },
    
    onCollapsedAnimated: function() {
      // summary:
      //		Called when the subgraph is about to be been expanded or collapsed.
    	connect.publish("/ibm_diagram/Subgraph/collapsedAnimated",[this]);
    },

    onCollapsedChanged: function() {
        // summary:
        //		Called when the subgraph has been expanded or collapsed.
    	connect.publish("/ibm_diagram/Subgraph/collapsedChanged",[this]);
    },
    
    __animateShowHide: function(group, show) {
        // summary:
        //		Creates and starts the expand/collapse animations.
        // tags:
        //		private
        var anim;
        var startScale, endScale;
        if (show) {
            startScale = 0.1;
            endScale = 1;
        } else {
            startScale = 1;
            endScale = 0.1;
        }
        var r = group.getLocalBoundingBox();
        var cx = r.x + r.width * this._fixedPosition.x;
        var cy = r.y + r.height * this._fixedPosition.y;
        anim = gfxfx.animateTransform({
            shape: group,
            duration: 500,
            transform: [{
                name: "scaleAt",
                start: [startScale, startScale, cx, cy],
                end: [endScale, endScale, cx, cy]
            }, {
                name: "original"
            }]
        });
        if (!show) {
			group._transformBeforeAnim = group.getTransform();
            connect.connect(anim, "onEnd", this, lang.hitch(this, "__endHide", group));
        }
        return anim;
    },
    
    __endHide: function(group) {
        // summary:
        //		Called at the end of the expand/collapse animation.
        // tags:
        //		private
        group.setTransform(group._transformBeforeAnim);
		delete group._transformBeforeAnim;
        // call _hide() after setTransform (crash under IE)
        this._hide(group);
    },
    
    _hide: function(toHide) {
        if (toHide && toHide.getParent()) {
            if ((has("chrome") && iid.isSvg) || iid.isVml) {
                this._saveStyles(toHide);
            }
            toHide._collapsedParent = toHide.getParent();
            toHide._collapsedParent.remove(toHide);
        }
    },
    
    _show: function(toShow) {
        if (toShow && !toShow.getParent()) {
            toShow._collapsedParent.add(toShow);
            toShow._collapsedParent = undefined;
            if ((has("chrome")  && iid.isSvg) || iid.isVml) {
                this._restoreStyles(toShow);
            }
        }
    },
    
    _expandButtonClicked: function(e) {
        // summary:
        //		Expand button click callback.
        // tags:
        //		private
        this._setCollapsed(false, this._animate);
    },
    _collapseButtonClicked: function(e) {
        // summary:
        //		Collapse button click callback.
        // tags:
        //		private
        this._setCollapsed(true, this._animate);
    },
    
    _expandButtonTouch: function(e) {
        // summary:
        //		Expand button click callback.
        // tags:
        //		private
        this._setCollapsed(false, this._animate);
        if (e.preventDefault)
          e.preventDefault();
        
    },
    _expandButtonDoubleTap: function(e) {
        // summary:
        //		Expand button click callback.
        // tags:
        //		private
        
  		if(event.touches.length == 0){
  			var delay = new Date().getTime() - this._lastUp;
  			if(this._lastUp && (delay < 500)){
  				this._setCollapsed(false, this._animate);
  				delete this._lastUp;
  			}else{
  				this._lastUp = new Date().getTime();
  			}   
  		}			
      if (e.preventDefault)
        e.preventDefault();
        
    },
    _collapseButtonTouch: function(e) {
        // summary:
        //		Collapse button click callback.
        // tags:
        //		private
        this._setCollapsed(true, this._animate);
        if (e.preventDefault)
          e.preventDefault();
    },
    
    _collapseButtonDoubleTap: function(e) {
        // summary:
        //		Collapse button click callback.
        // tags:
        //		private
  		if(event.touches.length == 0){
  			var delay = new Date().getTime() - this._lastUp;
  			if(this._lastUp && (delay < 500)){
  				this._setCollapsed(true, this._animate);
  				delete this._lastUp;
  			}else{
  				this._lastUp = new Date().getTime();
  			}   
  		}			
      if (e.preventDefault)
        e.preventDefault();
        
    },
    
	getCollapsedPort: function(link, port) {
		// summary:
		//		Gets a port to which the specified intergraph link will be connected when this
		//		subgraph is collapsed.
		// link: ibm_ilog.diagram.Link:
		//		The intergraph link connected to a node contained in this subgraph.
		// port: ibm_ilog.diagram.PortBase:
		//		The port to which the intergraph link is normally connected when this subgraph is expanded.
		// description:
		//		When a subgraph is collapsed, intergraph links connected to nodes contained in the subgraph
		//		are automatically reconnected to a port of the collapsed subgraph itself.
		//		This method lets you customize which port will be used for this.
		//		If this method returns null (the default), an AutomaticPort will be used by default.
		
		return null;
	},
	
	propagateTextDir: function(/*String*/textdir) {
        // summary: 
        //      propagate a new text direction to children (nodes, links)
        // textdir: String, text direction 
	 
        if (config.isBidiInDojoDiagrammer) {
	   	    array.forEach(this.getGraph().children, function(n) {
	   	        if (n.setTextDir){
	   	            n.setTextDir(textdir);
	   	            if (n instanceof Subgraph)
	   	                n.propagateTextDir(textdir);
	   	        }    
	   	    });
        }	   	    
	},
	
    // 
    // Internal layout (i.e. layout the parts of the template)
    // 
    
    // TODO: should not be hard-coded...
    _graphPosition: null,
    _headerHeight: 20,
    _margin: 2,
    
    layoutShape: function( /*Object*/target, forceDoLayout){
        var c = target._collapsedGroup, e = target._expandedGroup, s, h;
        if (this._collapsed) {
            s = c;
            h = e;
        } else {
            s = e;
            h = c;
        }
        
        target._graphPosition = {x:0,y:0};
        if (forceDoLayout)
            this._doLayout(target);

        if(this._collapsed) {
            var hbb = h.getLocalBoundingBox();
            this._realign(s, hbb);
        }
        if (h) {
            h.getParent().remove(h);
        }        
    },
    
    applyLayout : function(rect){
        if (config.useGfxLayout) {
            Node.prototype.applyLayout.apply(this, arguments);
            // update the subgraph location depending on the graph content bbox
            // (_noTranslate: flag set in the SwimLane subclass)
            if (this.getLayout() && !this.isCollapsed() && !this._noTranslate && this._graph) {
                var graphBB = this._graph.getBoundingBox();
                if (!graphBB) // empty
                    return;
                var t = this._graph.getShapeToContainerTransform(this) || matrix.identity;
                var subBB = this.getBoundingBox();
                var r = t.transformRectangle(graphBB);
                var r2 = subBB;
                var dx =  graphBB.x - (r.x-r2.x);
                var dy =  graphBB.y - (r.y-r2.y);
                t = this._expandedGroup.getTransform();
                if (this._oldSubgraphTransform)
                    t = matrix.multiply(this._oldSubgraphTransform.inverse(), t);
                this._oldSubgraphTransform = matrix.translate(dx, dy);
                t = matrix.multiply(t, this._oldSubgraphTransform);
                this._settingTransformInApplyLayout = true;
                this._expandedGroup.suspendInvalidate();
				this._expandedGroup.setTransform(t);
                this._expandedGroup.resumeInvalidate();
                delete this._settingTransformInApplyLayout;
            }
            
			// realign collapsed group after layout
			if(this.getLayout() && this.isCollapsed()){
				this._realign(this._collapsedGroup, this._expandedGroup.getLocalBoundingBox());
			}
        }
    },
    
    _doLayout: function( /*Object*/target ) {
        // summary:
        //		Layout the part of the subgraph template according to the new bounds of the graph.
        
        //if (/*config.useGfxLayout*/this.getLayout())
        //    return;
        
        target = target || this;
        
        // get new graph bounds
        var graphBounds = this._graph.getLocalBoundingBox();
        if (!graphBounds) {
            graphBounds = {x:0, y:0, width:80, height:40};
    	} else {
            graphBounds = g.cloneRect(graphBounds);
        }
        if (target._header) {
            if (target._graphPosition) {
                var dx = graphBounds.x - target._graphPosition.x;
                var dy = graphBounds.y - target._graphPosition.y;
                target._header.applyLeftTransform(matrix.translate(dx, dy));
            } else {
            	target._graphPosition = {};
            }
            target._graphPosition.x = graphBounds.x;
            target._graphPosition.y = graphBounds.y;
        }
        
        var gm = this.getGraphMargin();
        graphBounds.x -= gm;
        graphBounds.y -= gm;
        graphBounds.width += 2 * gm;
        graphBounds.height += 2 * gm;
        
		var shape;
		
        // move/resize graph background rect
        if (target._graphBackground) {
            shape = target._graphBackground.getShape();
            shape.x = graphBounds.x;
            shape.y = graphBounds.y;
            shape.width = graphBounds.width;
            shape.height = graphBounds.height;
            target._graphBackground.setShape(shape);
        }
        
        // move/resize overall background rect
        var bg = target._expandedBaseShape || target._background; // try also _background for compatibility...
        if (bg) {
            shape = bg.getShape();
            shape.x = graphBounds.x - this._margin;
            shape.y = graphBounds.y - this._headerHeight;
            shape.width = graphBounds.width + 2 * this._margin;
            shape.height = graphBounds.height + this._headerHeight + this._margin;
            bg.setShape(shape);
        }
    },
    
    _graphChanged: function() {
        if (config.useGfxLayout) {
            if (this.getLayout()) 
                this.invalidate();
            else
                this._doLayout();
        } else {
            this._doLayout();
        }
        
    },
    
	setExplicitSize: function(sz)
	{
		// summary:
		//		Does nothing, Subgraphs cannot have an explicit size, their size is determined by their children.
		
		if(this._isIBMDiagramSwimLane)
			this.inherited(arguments);
	},
	
    // 
    // Intergraph links invalidation:
    // (intergraph links are added to the subgraph's _intergraphLinks array by the Link,
    // when setting the start/end ports).
    // 
    
    _onChanged: function(shape, reason) {
    	// This method is called a lot, keep it short and fast :).

    	//	[av] this.inherited(arguments); replaced by:
		Node.prototype._onChanged.apply(this,arguments);
        
    	if(!Node._ChangesInvalidateLinksDisabled) {
	    	if (shape == this && reason == "setTransform") {
	            this._invalidateIntergraphLinks();
	        }
    	}
    },
    
    _invalidateIntergraphLinks: function() {
        if (this._intergraphLinks) {
            array.forEach(this._intergraphLinks, function(link) {
                link.invalidateLinkShape();
            });
        }
    },
    
    getIntergraphLinks: function(){
    	// summary:
        //		return all the intergraph links
    	// return array of ibm_ilog.diagram.Link
        return this._intergraphLinks || [];
    },
    _findAllStyledElements: function() {
    	// summary:
        //		find all the styled elements, from collapsed and expanded groups
    	// override Selectable method
        if(this._collapsedGroup!=null){
        	this._findStyledChildren(this._collapsedGroup.children);
        }
        if(this._expandedGroup!=null){
        	this._findStyledChildren(this._expandedGroup.children);
        }
    },
    
    _applySelectedStyle: function(shape,selected){
    	// summary:
        //		apply the appropriate style to the shape, verifying if it is visible 
    	//      (some styles cannot be applied if no surface is associated )
    	// override Selectable method
    	if(this._isVisible(shape)){
    		this.inherited(arguments);
    	}
    },
    
    _isVisible: function(shape){
    	// summary:
        //		verify if the shape belongs to the shown group
    	var parent = shape.getParent();
    	while(parent!=null){
    		if(parent==this){
    			return true;
    		}
    		parent = parent.getParent();
    	}
    	return false;
    }
    
});

templating.declareBindableProperty(Subgraph, "headerColor", "#6699FF");
templating.declareBindableProperty(Subgraph, "selectedHeaderColor", "#0000FF");
templating.declareBindableProperty(Subgraph, "graphBackgroundColor", "#f8f8f8");
templating.declareBindableProperty(Subgraph, "graphMargin", 10);
templating.declareBindableProperty(Subgraph, "textDir", "");

// The default template for Subgraphs
Subgraph.defaultTemplate = iid.declareTemplate(templates.defaultSubgraphTemplate);

Subgraph.nodeType = gfx.Group.nodeType;
Subgraph.defaultShape = {
    type: 'subgraph'
};

return Subgraph;

});
