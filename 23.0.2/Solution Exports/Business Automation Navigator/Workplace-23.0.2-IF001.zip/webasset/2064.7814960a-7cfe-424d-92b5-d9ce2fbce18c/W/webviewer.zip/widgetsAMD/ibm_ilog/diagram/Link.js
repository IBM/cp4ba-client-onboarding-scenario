/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["./main",
"dojo/_base/declare", "dojo/_base/lang", "dojo/_base/array", "dojo/_base/json",
"dojox/gfx", "dojox/gfx/matrix",
"./GraphElement", "./Port", "./templating", "./templates/templates",
"./util/Geometry", "./util/Batch", "./util/ErrorReporter"
],
function(iid, declare, lang, array, json, gfx, gfxm, GraphElement, port, templating, templates, Geometry, Batch, ErrorReporter){

var LinkShapeType = {
    Straight: 1,
    Orthogonal: 2,
    OrthogonalEditable: 3,
    Oblique: 4,
    Free: 5
};
iid.LinkShapeType = LinkShapeType;

/*=====
var GraphElement = ibm_ilog.diagram.GraphElement;
=====*/

var Link = 
declare("ibm_ilog.diagram.Link", [GraphElement], {
    // summary:
    //		A Link is a graphic object that connects two Node objects.
    // description:
    //		The link is a templatable object that connects two nodes.
    //		A link is created by calling graph.createLink(template), where 'graph' is an ibm_ilog.diagram.Graph instance,
    //		and 'template' is a GFX definition of the shapes that make up the link.
    //		The template must contain at least a GFX shape that will represent the polyline shape of the link.
    //		This shape must have a "dojoAttachPoint: '_path'" property.
    //		The template can contain one or two shapes representing the start and/or end arrows
    //		of the link, with "dojoAttachPoint: '_startArrow'" and "dojoAttachPoint: '_endArrow'" properties.
	//		The template can also contain decorations, that is, shapes that will placed placed automatically
	//		along the link's path. Decorations are identified by a isDecoration property which must be set to true.
	//		Additional properties can be specified to define how a decoration is placed and aligned on the path.
	//		See the getDecorations() method for more details.
    
	// Allows to test the class faster that testing declaredClass
	_isIBMDiagramLink: true,
	
	//
	//	TID: String
	//		Graph element Type ID, used to distinguish basic graph 
  //		element types:
  //	
  //			N = Node
  //			S = Subgraph
  //			L = Link
  //	
	//		Usually used as a very fast index into maps based on 
  //		ibm_diagram graph element types.
	//
  TID: 'L',
	
    // properties
    _startPort: null,
    _endPort: null,
    _startPoint: {
        x: 0,
        y: 0
    },
    _endPoint: {
        x: 100,
        y: 0
    },
    _intermediatePoints: null,
    _shapeType: LinkShapeType.Free,
    _nodeDistance: 20,
    _hitTolerance: 0,
    
    // template parts
    _path: null,
    _startArrow: null,
    _endArrow: null,
    
    // internal state	
    _pathPoints: null,
    _pathPointsValid: false,
    _selectionPath: null,
	
	_isIntergraphLinkAtStart: false,
	_isIntergraphLinkAtEnd: false,

	_curveTension: 0,
	
    constructor: function() {
        // summary: Constructor.

        this._startPoint = {
            x: 0,
            y: 0
        };
        this._endPoint = {
            x: 100,
            y: 0
        };
    },
    
    //---------- Disposal ----------
    
    _dispose: function() {
        // summary:
        //		Dispose this Link.
        // description:
        //		This function should be called when the link is completely deleted, that is, when it is removed
        //		from its parent graph and it will never be used again.
        
        this.setStartPort(null);
        this.setEndPort(null);
    },
    
    invalidate:function(){},
    applyLayout:function(){},
    
    //---------- Start/end ports ----------
    
    getStartPort: function() {
        // summary:
        //		Gets the start port of the link.
        // returns:
        //		The PortBase object that defines the start point of the link.
        return this._startPort;
    },
    
    setStartPort: function(port) {
        // summary:
        //		Sets the start port of the link.
        // port: ibm_ilog.diagram.PortBase:
        //		The PortBase object that defines the start point of the link.
        if (this._startPort != port) {
            if (this._startPort)
				this._startPort._removeLink(this);
			this._checkIntergraphLink(this._startPort, port, true);
            this._startPort = port;
            if (this._startPort)
				this._startPort._addLink(this);
            this.invalidateLinkShape();
        }
        return this;
    },
    
    getEndPort: function() {
        // summary:
        //		Gets the end port of the link.
        // returns:
        //		The PortBase object that defines the end point of the link.
        return this._endPort;
    },
    
    setEndPort: function(port) {
        // summary:
        //		Sets the end port of the link.
        // port: ibm_ilog.diagram.PortBase:
        //		The PortBase object that defines the end point of the link.
        if (this._endPort != port) {
			if (this._endPort) 
				this._endPort._removeLink(this);
			this._checkIntergraphLink(this._endPort, port, false);
			this._endPort = port;
			if (this._endPort)
				this._endPort._addLink(this);
			this.invalidateLinkShape();
		}
        return this;
    },
	
    _forceCheckIntergraphLink: function(){
		this._isIntergraphLinkAtStart = this._forceCheckIntergraphLink1(this.getStartPort(),this._isIntergraphLinkAtStart);
		this._isIntergraphLinkAtEnd = this._forceCheckIntergraphLink1(this.getEndPort(),this._isIntergraphLinkAtEnd);
    },
    
    _forceCheckIntergraphLink1: function(port,isIntergraphLink){
    	if(port){
    		if(isIntergraphLink){
    			this._checkIntergraphLink1(port, true);
    		}
    		return this._checkIntergraphLink1(port, false);
		}
    	return isIntergraphLink;
    },
    
	_checkIntergraphLink: function(oldPort, newPort, start){
		// check cases when we know this is not necessary:
		if(oldPort && newPort && oldPort._owner == newPort._owner)
			return;
		// remove link from _integraphLinks arrays for old port:
		var isIntergraphLink = start ? this._isIntergraphLinkAtStart : this._isIntergraphLinkAtEnd;
		if (oldPort && isIntergraphLink)
			this._checkIntergraphLink1(oldPort, true);
		// add link from _integraphLinks arrays for new port:
		if (newPort) {
			isIntergraphLink = this._checkIntergraphLink1(newPort, false);
			if(start)
				this._isIntergraphLinkAtStart = isIntergraphLink;
			else
				this._isIntergraphLinkAtEnd = isIntergraphLink;
		}
	},
		
	_checkIntergraphLink1: function(port, cleanup) {

		// Is this an intergraph link?
		// (definition = link parent is an ancestor or port owner parent)
		var node = port.getOwner();
		var linkParent = this.getParent();
		if(node && linkParent){
			var nodeParent = node.getParent();
			if(nodeParent && nodeParent != linkParent){
				for(var p = nodeParent.getParent(); p && p.getParent; p = p.getParent()){
					if(p == linkParent){
						// OK, yes, this is an intergraph link.
						// record the link in the _intergraphLinks arrays of all subgraphs
						// between the node parent and the link parent
						for (var sub = nodeParent.getParent(); sub != linkParent; sub = sub.getParent()) {
							if (sub._isIBMDiagramSubgraph) {
								if (cleanup) {
									if (sub._intergraphLinks) {
										var index = array.indexOf(sub._intergraphLinks, this);
										if (index >= 0) {
											if(sub._intergraphLinks.length == 1)
												sub._intergraphLinks = undefined;
											else
												sub._intergraphLinks.splice(index, 1);
										}
									}
								}
								else {
									if (!sub._intergraphLinks) 
										sub._intergraphLinks = [this];
									else 
										if (array.indexOf(sub._intergraphLinks, this) < 0) 
											sub._intergraphLinks.push(this);
								}
							}
						}
						return true;
					}
				}
			}
		}
		return false;
	},
	
	_setParent: function(parent, matrix)
	{
		GraphElement.prototype._setParent.call(this, parent, matrix);
		this._forceCheckIntergraphLink();
	},
    
    //---------- Start/end nodes ----------
    
    getStartNode: function() {
        // summary:
        //		Gets the start node of the link.
        // returns:
        //		A ibm_ilog.diagram.Node object.
        // description:
        //		If a start port has been specified, this function returns the owner of the start port,
        //		otherwise it returns null.
        
        if (this._startPort) 
            return this._startPort.getOwner();
        else 
            return null;
    },
    
    setStartNode: function(/*ibm_ilog.diagram.Node*/node) {
        // summary:
        //		Sets the start node of the link.
        // node:
        //		A ibm_ilog.diagram.Node object.
        // description:
        //		If a start port has been specified, this function returns the owner of the start port,
        //		otherwise it returns null.
        
        if (node) {
            if (!this._startPort || this._startPort.getOwner() != node) {
                this.setStartPort(this._getOrCreateDefaultPort(node));
            }
        } else {
            this.setStartPort(null);
        }
        return this;
    },
    
    getEndNode: function() {
        // summary:
        //		Gets the end node of the link.
        // returns:
        //		A ibm_ilog.diagram.Node object.
        // description:
        //		If a end port has been specified, this function returns the owner of the end port,
        //		otherwise it returns null.
        
        if (this._endPort) 
            return this._endPort.getOwner();
        else 
            return null;
    },
    
    setEndNode: function(/*ibm_ilog.diagram.Node*/node) {
        // summary:
        //		Sets the end node of the link.
        // node:
        //		A ibm_ilog.diagram.Node object.
        // description:
        //		If a end port has been specified, this function returns the owner of the end port,
        //		otherwise it returns null.
        
        if (node) {
            if (!this._endPort || this._endPort.getOwner() != node) {
                this.setEndPort(this._getOrCreateDefaultPort(node));
            }
        } else {
            this.setEndPort(null);
        }
        return this;
    },
    
    _getOrCreateDefaultPort: function(/*ibm_ilog.diagram.Node*/node) {
        // tag: private
        // summary:
        //		Looks for an existing default port on the specified node
		///		(the default port is identified by the _isDefaultPort flag),
        //		if none exists create and add one.
        // node: ibm_ilog.diagram.Node:
        //		The node in which the default port should be looked up or created.
        
        var port;
        var ports = node.getPorts();
        for (var i = 0; i < ports.length; i++) {
            var port = ports[i];
            if (port._isDefaultPort) {
                return port;
            }
        }
        port = this._createDefaultPort(node);
		port._isDefaultPort = true;
        node.addPort(port);
        return port;
    },
	
	_createDefaultPort: function(/*ibm_ilog.diagram.Node*/node) {
        // tag: private
        // summary:
        //		Called by _getOrCreateDefaultPort to create the default port if none exists.
		//		By default, creates a new AutomaticPort.
        // node: ibm_ilog.diagram.Node:
        //		The node in which the default port should be created.
		return new port.AutomaticPort();
	},
    
    //---------- Start/end points ----------
    
    getFallbackStartPoint: function() {
        // summary:
        //		Gets the start point of the link.
        // returns:
        //		An object with 'x' and 'y' properties.
        // description:
        //		The start point is used only when no start port is specified.
        return this._startPoint;
    },
    
    setFallbackStartPoint: function(point) {
        // summary:
        //		Sets the start point of the link.
        // point:
        //		An object with 'x' and 'y' properties.
        // description:
        //		The start point is used only when no start port is specified.
        
        if (typeof(point) != 'object' || !('x' in point) || !('y' in point)) 
            ErrorReporter.error("UnexpectedArgument", this, "setFallbackStartPoint", "point", point);
        
        if (point.x != this._startPoint.x ||
        point.y != this._startPoint.y) {
            this._startPoint.x = point.x;
            this._startPoint.y = point.y;
            if (!this._startPort) 
                this.invalidateLinkShape();
            
        }
        return this;
    },
    
    getFallbackEndPoint: function() {
        // summary:
        //		Gets the end point of the link.
        // returns:
        //		An object with 'x' and 'y' properties.
        // description:
        //		The end point is used only when no end port is specified.
        return this._endPoint;
    },
    
    setFallbackEndPoint: function(point) {
        // summary:
        //		Sets the end point of the link.
        // point:
        //		An object with 'x' and 'y' properties.
        // description:
        //		The end point is used only when no end port is specified.
        
        if (typeof(point) != 'object' || !('x' in point) || !('y' in point)) 
            ErrorReporter.error("UnexpectedArgument", this, "setFallbackEndPoint", "point", point);
        
        if (point.x != this._endPoint.x ||
        point.y != this._endPoint.y) {
            this._endPoint.x = point.x;
            this._endPoint.y = point.y;
            if (!this._endPort) 
                this.invalidateLinkShape();
        }
        return this;
    },
    
    //---------- Intermediate points ----------
    
    getIntermediatePoints: function() {
        // summary:
        //		Gets the intermediate points of the link.
        // returns:
        //		An array of objects with 'x' and 'y' properties.
        // description:
        //		The intermediate points define the additional points of the link (i.e., the points between the start and end points,
        //		which are always determined by the setStartPort()/setEndPort() or setFallbackStartPoint/setFallbackEndPoint() functions)
        //		when the link shape type is ibm_ilog.diagram.LinkShapeType.Free or ibm_ilog.diagram.LinkShapeType.OrthogonalEditable.
        //		For other shape types, the intermediate points are ignored since the link path is computed automatically.
        
        if (this._intermediatePoints !== null) {
            return lang.clone(this._intermediatePoints);
        } else {
            return [];
        }
    },
    
    setIntermediatePoints: function(points) {
        // summary:
        //		Sets the intermediate points of the link.
        // points:
        //		An array of objects with 'x' and 'y' properties
        //		(can be null to remove all intermediate points).
        // description:
        //		The intermediate points define the additional points of the link (i.e., the points between the start and end points,
        //		which are always determined by the setStartPort()/setEndPort() or setFallbackStartPoint/setFallbackEndPoint() functions)
        //		when the link shape type is ibm_ilog.diagram.LinkShapeType.Free or ibm_ilog.diagram.LinkShapeType.OrthogonalEditable.
        //		For other shape types, the intermediate points are ignored since the link path is computed automatically.
        
        if (points !== null) {
            this._intermediatePoints = lang.clone(points);
        } else {
            this._intermediatePoints = null;
        }
        if (this._shapeType == LinkShapeType.Free ||
        		this._shapeType == LinkShapeType.OrthogonalEditable) 
            this.invalidateLinkShape(); // in the other shapeTypes the interm points are not used
        return this;            
    },
    
    //---------- Shape type ----------
    
    getShapeType: function() {
        // summary:
        //		Gets the shape type of this link.
        // returns:
        //		One of the values defined in the ibm_ilog.diagram.LinkShapeType enumeration.
        // description:
        //		The shape type determines if and how the link automatically computes its shape
        //		based on its start and end port or points, and possibly its intermediate points.
        
        return this._shapeType;
    },
    
    setShapeType: function(/*int*/shapeType) {
        // summary:
        //		Sets the shape type of this link.
        // shapeType: int:
        //		One of the values defined in the ibm_ilog.diagram.LinkShapeType enumeration.
        // description:
        //		The shape type determines if and how the link automatically computes its shape
        //		based on its start and end port or points, and possibly its intermediate points.
        
        if (shapeType != this._shapeType) {
            this._shapeType = shapeType;
            this.invalidateLinkShape();
        }
        return this;
    },
    
    //---------- Node distance ----------
    
    getNodeDistance: function() {
        // summary:
        //		Gets the minimum distance between this link and its start or end nodes when the link is orthogonal.
        // returns:
        //		A distance in pixels.
        // description:
        //		This property is used when the link shape type is Orthogonal, OrthogonalEditable or Oblique,
        //		and determines the minimum distance kept between the link and its start or end nodes.
        //		The default distance is 20.
        
        return this._nodeDistance;
    },
    
    setNodeDistance: function(/*number*/distance) {
        // summary:
        //		Sets the minimum distance between this link and its start or end nodes when the link is orthogonal.
        // distance: number:
        //		A distance in pixels.
        // description:
        //		This property is used when the link shape type is Orthogonal, OrthogonalEditable or Oblique,
        //		and determines the minimum distance kept between the link and its start or end nodes.
        
        if (distance != this._nodeDistance) {
            this._nodeDistance = distance;
            if (this._shapeType == LinkShapeType.Orthogonal ||
            this._shapeType == LinkShapeType.OrthogonalEditable ||
            this._shapeType == LinkShapeType.Oblique) 
                this.invalidateLinkShape();
        }
        return this;
    },
    
    //---------- Curve tension (splines) ----------
	
	setCurveTension: function(/*number*/t) {
		// summary:
		//		Sets the curve tension to draw the link as a spline.
		// t: number:
		//		The curve tension, between 0 and 1.
		// description:
		//		This properties allows to draw curved links. By default, the curve tension is 0, which draws
		//		a plain polyline (not curved). If the curve tension is set to a value greater than 0, the
		//		link is drawn as a smooth spline that goes through the start point, then through the middle
		//		of each link segment (as computed according to the link shape type), and then to the end point.
		//		The curve tension determines the shape of the curve: small values will produce sharper bends,
		//		larger values will produce a smoother curve.
		//		The curve tension must be greater than 0 and less than 1
		//		(0.5 usually provides nicest results).
		//
		//		NOTE: If the _path part of the link template was a GFX Polyline shape, setting the curve tension to
		//			  a value greater than 0 automatically replaces it by a GFX Path shape. 
		
		if(t < 0) t = 0;
		if(t > 1) t = 1;
		if(t != this._curveTension){
			this._curveTension = t;
			// if the path is a polyline, replace it by a GFX Path.
			if (t > 0 && !(this._path instanceof gfx.Path)) {
				var stroke, selectedStyle, parent;
				if (this._path) {
					stroke = this._path.getStroke();
					selectedStyle = this._path.selectedStyle;
					parent = this._path.getParent();
					// Added to solve problem when link is selected
					standardStyle = this._path.standardStyle;
					if(this._styledChildren)
						this._styledChildren.remove(this._path);
					this._path.removeShape();
				}
				this._path = (parent || this).createPath();
				if(stroke)
					this._path.setStroke(stroke);
				if(selectedStyle)
					this._path.selectedStyle = selectedStyle;
				// Added to solve problem when link is selected
				if(standardStyle)
					this._path.standardStyle = standardStyle;
				if(this._styledChildren && this._path.standardStyle)
					this._styledChildren.add(this._path);
			}
			this.invalidateLinkShape();
		}
        return this;
	},
	
	getCurveTension: function() {
		// summary:
		//		Gets the curve tension.
		// returns: number:
		//		The curve tension.
		// description:
		//		See setCurveTension.
		
		return this._curveTension;
	},
    //---------- Path ----------

    layoutShape: function(target) {
    	//
    	//	_DiagramTemplated API:
    	//	
    	//		for externally instantiated templates
    	//
    	this._updatePath(target);
    },
    
    _updatePath: function(target) {
    	
    	var target = target || this;
    
        var points = this.applyPathToArrows(target);
    	this.applyPath(target._path,points,target._curveTension);
		// decorations:
		
		this._placeDecorations(target);
        this._updateSelectionPath(points,target,target._curveTension);
    },
    
    //-------------------------------------------------------	
    applyPathToArrows: function(target){
    	
    	var points = this._pathPoints;
        
        // arrows:
        if (points && points.length >= 2) {
            if ((target._startArrow && target._startArrow.getParent()) ||
            (target._endArrow && target._endArrow.getParent())) {
                points = lang.clone(points); // end points will be modified
            }
            if (target._startArrow && target._startArrow.getParent()) {
            	this._updateArrow(target._startArrow, points[0], points[1],target);
            }
            if (target._endArrow && target._endArrow.getParent()) {
            	this._updateArrow(target._endArrow, points[points.length - 1], points[points.length - 2],target);
            }
        }
        return points;
    },
    
    applyPath: function(path,points,curveTension){
    	
        if (path instanceof gfx.Polyline) {
            path.setShape(points);
			path.bbox = null; // patch for GFX bug...
        } else {
            path.setShape("");
            if (points && points.length > 0) {
                path.moveTo(points[0].x, points[0].y);
				if (curveTension > 0 && points.length > 2) {
					var x = points[0].x;
					var y = points[0].y;
					var t = 1 - curveTension/2;
					for (var i = 0; i < points.length - 2; i++) {
						// first control point:
						var p1 = points[i + 1];
						var x1 = x + (p1.x - x) * t;
						var y1 = y + (p1.y - y) * t;
						// Compute next curve point:
						var p2 = points[i + 2];
						if (i < points.length - 3) {
							x = p1.x + (p2.x - p1.x) / 2;
							y = p1.y + (p2.y - p1.y) / 2;
						}
						else {
							x = p2.x;
							y = p2.y;
						}
						// second control point:
						var x2 = x + (p1.x - x) * t;
						var y2 = y + (p1.y - y) * t;
						path.curveTo(x1, y1, x2, y2, x, y);
					}
				}
				else {
					// polyline:
					for (var i = 1; i < points.length; i++) {
						path.lineTo(points[i].x, points[i].y);
					}
				}
            }
        }
	},
    //---------- Mouse tolerance ----------
    
    _updateSelectionPath: function(points,target,curveTension) {
    	var target = target || this;
        if (target._hitTolerance == 0) {
            if (target._selectionPath != null) {
            	target.remove(target._selectionPath);
            	target._selectionPath = null;
            }
        } else {
            this._updatePathShape(target,curveTension);
            this.applyPath(target._selectionPath,points,curveTension);
        }
    },
    
    _updatePathShape: function(target,curveTension){
		
    	if (target._selectionPath != null) {
        	if( ((curveTension > 0) && !(this._selectionPath instanceof gfx.Path)) || 
        	    ((curveTension == 0) && (this._selectionPath instanceof gfx.Path)) ){
        			target.remove(target._selectionPath);
        			target._selectionPath = null;
        	}
        }
    	if (target._selectionPath == null) {
    		if (curveTension > 0) {
    			target._selectionPath = target.createPath();
    		}else{
    			target._selectionPath = target.createPolyline();
    		}
    		target._selectionPath.setStroke(json.fromJson('{"color": [255,255,255,0.001],"width": " + this._hitTolerance + "}'));
    	}
	},
    
    getHitTolerance: function() {
        // Summary:
        //		gets the mouse tolerance.
        
        return this._hitTolerance;
    },
    
    setHitTolerance: function(tolerance) {
        // Summary: 
        //		sets the mouse tolerance. This value affects all the mouse events and the tolerance to consider it is over a link.
        //		The recomended values goes from 5 to 10 (bigger --> bigger tolerance).
        //		If 0, no tolerance is applied.
        
        this._hitTolerance = tolerance;
        this.invalidateLinkShape();
        return this;
    },
    
    //---------- Arrows ----------
    
    isStartArrowVisible: function() {
        // summary:
        //		Gets the visibility of the start arrow.
        // returns:
        //		True if the start arrow is defined in the link template and visible.
        //		False if the start arrow is either not defined in the link template or invisible.
        
        return (this._startArrow && this._startArrow.getParent()) ? true : false;
    },
    
    setStartArrowVisible: function(v) {
        // summary:
        //		Makes the start arrow visible or invisible.
        // v: Boolean:
        //		If no start arrow is defined in the link template
        //		(that is, if the template contains no shape with "dojoAttachPoint: '_startArrow'"),
        //		this method does nothing.
        //		Otherwise, if 'v' is true, the start arrow is shown (i.e., added to the link),
        //		and if 'v' is false, the start arrow is hidden (i.e. removed from the link).
        
        if (this._startArrow) {
            if (v) {
                if (!this._startArrow.getParent()) {
                    this.add(this._startArrow);
		            this.invalidateLinkShape();
                }
            } else {
                if (this._startArrow.getParent()) {
                    this.remove(this._startArrow);
		            this.invalidateLinkShape();
                }
            }
        }
        return this;
    },
    
    isEndArrowVisible: function() {
        // summary:
        //		Gets the visibility of the end arrow.
        // returns:
        //		True if the end arrow is defined in the link template and visible.
        //		False if the end arrow is either not defined in the link template or invisible.
        return (this._endArrow && this._endArrow.getParent()) ? true : false;
    },
    
    setEndArrowVisible: function(v) {
        // summary:
        //		Makes the end arrow visible or invisible.
        // v: Boolean:
        //		If no end arrow is defined in the link template
        //		(that is, if the template contains no shape with "dojoAttachPoint: '_endArrow'"),
        //		this method does nothing.
        //		Otherwise, if 'v' is true, the end arrow is shown (i.e., added to the link),
        //		and if 'v' is false, the end arrow is hidden (i.e. removed from the link).
        
        if (this._endArrow) {
            if (v) {
                if (!this._endArrow.getParent()) {
                    this.add(this._endArrow);
		            this.invalidateLinkShape();
                }
            } else {
                if (this._endArrow.getParent()) {
                    this.remove(this._endArrow);
		            this.invalidateLinkShape();
                }
            }
        }
        return this;
    },
    
    
    _updateArrow: function(arrow, endPoint, nextPoint,target) {
    	var target = target || this;
        // tag: private
        var _m = gfxm;
        var dx = nextPoint.x - endPoint.x;
        var dy = nextPoint.y - endPoint.y;
		// hack for VML: because of roundings in transforms,
		// almost vertical/horizontal segments cause exceptions...
		if(dx > -0.01 && dx < 0.01) dx = 0;
		if(dy > -0.01 && dy < 0.01) dy = 0;
        var a = Math.atan2(-dy, -dx);
        var transforms = [_m.translate(endPoint.x, endPoint.y), _m.rotate(a)];
        var stroke = target._path.getStroke();
        if (stroke && stroke.width > 2) {
            transforms.push(_m.scale(1 + (stroke.width - 2) / 4)); // nicer than linear scaling...
        }
		arrow.setTransform(transforms);
		
        // shorten the segment so that the polyline's end does not show at the tip of the arrow
        var l = Math.sqrt(dx * dx + dy * dy);
        if (l > 0) {
            stroke = target._path.getStroke();
            var w = stroke ? stroke.width : 2;
            var r = w / l;
            endPoint.x += r * dx;
            endPoint.y += r * dy;
        }
    },
    
    //---------- Points computation ----------
    
    getPoints: function() {
        // summary:
        //		Gets the actual points of the link.
        // description:
        //		This function calls validateLinkShape() and returns the points that have been computed.
        
        this.validateLinkShape();
        return lang.clone(this._pathPoints);
    },
    
    invalidateLinkShape: function() {
        // summary:
        //		Invalidates the shape of this link.
        // description:
        //		This function ensures that the shape of the link will be recomputed before the next redisplay of the link.
        //		This function is called automatically when the start or end port change, or their owner nodes change,
        //		or when a property of the link that determines the shape (such as the intermediate points) is changed.
        //		In most cases you do not need to call this function explicitly.
        
        this._pathPointsValid = false;
        Batch.add(this); // arrange so that _endBatch() is called soon
    },
    
    _endBatch: function() {
        // summary:
        //		This method will be called when invalidateLinkShape() has been called, and calls validateLinkShape().
        // tags:
        //		private
        
        this.validateLinkShape();
    },
    
    validateLinkShape: function() {
        // summary:
        //		Recomputes the shape of this link.
        // description:
        //		This function is called automatically when invalidateLinkShape() has been called, and before the
        //		link is redisplayed. 
        //		In most cases you do not need to call this function explicitly.
        
        if (!this._pathPointsValid) {
            this._computeLinkPoints();
            this._updatePath();
            this._pathPointsValid = true;
        }
    },
    
    revalidateLinkShape: function() {
        // summary:
        //		Recomputes the shape of this link.
        
    	this._pathPointsValid = false;
    	this.validateLinkShape();
    },

    _getParent: function() {
        // tag: private
        var p = this.getParent();
        if (p && !p.getParent) {
            p = null;
        }
        return p;
    },
    
    _computeLinkPoints: function() {
        // tag: private
        var _m = gfxm;
        var startPoint = this.getFallbackStartPoint();
        var endPoint = this.getFallbackEndPoint();
        var startOrigin = startPoint;
        var endOrigin = endPoint;
        var cp, op, p, result;
        
        var parent = this._getParent();
        
        if (parent !== null) {
			
			var startPort = this._isIntergraphLinkAtStart ? this._getVisiblePort(this._startPort) : this._startPort;
			var endPort = this._isIntergraphLinkAtEnd ? this._getVisiblePort(this._endPort) : this._endPort;
			
            var t = _m.invert(this.getTransform());
            
            if (startPort !== null &&
            startPort.getOwner() !== null) {
                p = {
                    x: 0,
                    y: 0
                };
                
                if (startPort.needsReferencePoint()) {
                    p = this._getReferencePoint(false, startPort, endPort);
                    if (endPort === null) {
                        p = _m.multiplyPoint(this.getTransform(), p);
                    }
                }
                cp = {};
                op = {};
                result = startPort.getConnectionPoint(this, parent, p, cp, op, true);
                startPoint = _m.multiplyPoint(t, cp);
                startOrigin = _m.multiplyPoint(t, op);
            }
            
            if (endPort !== null &&
            endPort.getOwner() !== null) {
                p = {
                    x: 0,
                    y: 0
                };
                
                if (endPort.needsReferencePoint()) {
                    p = this._getReferencePoint(true, startPort, endPort);
                    if (startPort === null) {
                        p = _m.multiplyPoint(this.getTransform(), p);
                    }
                }
                cp = {};
                op = {};
                result = endPort.getConnectionPoint(this, parent, p, cp, op, false);
                endPoint = _m.multiplyPoint(t, cp);
                endOrigin = _m.multiplyPoint(t, op);
            }
        }
        
        this._setLinkPoints(startPoint, startOrigin, endPoint, endOrigin, startPort, endPort);
    },
	
	_getVisiblePort: function(port) {
		if(!port)
			return null;
		var owner = port.getOwner();
		if(!owner)
			return null;
		var topMostCollapsedNode = null;
		var linkParent = this.getParent();
		for(var p = owner.getParent(); p && p.getParent && p != linkParent; p = p._collapsedParent || p.getParent()){
			if(p._collapsedParent){
				for (var pp = p._collapsedParent; pp && pp.getParent; pp = pp.getParent()) {
					if (pp._isIBMDiagramSubgraph) {
						topMostCollapsedNode = pp;
						break;
					}
				}
			}
		}
		if (topMostCollapsedNode) {
			var collapsedPort = topMostCollapsedNode.getCollapsedPort(this, port);
			if(collapsedPort){
				if(!collapsedPort.getOwner())
					topMostCollapsedNode.addPort(collapsedPort);
				return collapsedPort;
			} 
			return this._getOrCreateDefaultPort(topMostCollapsedNode);
		}
		return port;
	},
	
    _getReferencePoint: function(start, startPort, endPort) {
        // tag: private
        var _m = gfxm;
        var points = this._intermediatePoints;
        if ((this._shapeType === LinkShapeType.Free ||
        this._shapeType === LinkShapeType.OrthogonalEditable) &&
        points !== null &&
        points.length > 0) {
            var p = start ? points[points.length - 1] : points[0];
			var t = this.getTransform();
			if(t)
            	return _m.multiplyPoint(t, p);
			else
				return p;
        } else {
            var port = start ? startPort : endPort;
            if (port !== null && port.getOwner() !== null && !port.needsReferencePoint()) {
                cp = {};
                op = {};
                return port.getConnectionPoint(this, this.getParent(), null, cp, op, start);
            } else {
                var obj = start ? (startPort !== null ? startPort.getOwner() : null) : (endPort !== null ? endPort.getOwner() : null);
                if (obj !== null && obj.getParent() !== null) {
                    // Note by E.T
                    // testing obj.Parent != null is not enough because
                    // link from or to still may be not in same hierarchy
                    // but it fixes some basic cases.
                    var relBounds;
                    try {
                        relBounds = obj.getBounds(this.getParent());
                    } catch (Exception) {
                        // port owner not in same hierarchy.(for example not added yet)
						relBounds = null;
                    }
					if (relBounds != null) {
						return {
							x: relBounds.x + relBounds.width / 2,
							y: relBounds.y + relBounds.height / 2
						};
					} else {
						if (start) {
							return this.getFallbackStartPoint();
						}
						else {
							return this.getFallbackEndPoint();
						}
					}
                    
                } else {
                    if (start) {
                        return this.getFallbackStartPoint();
                    } else {
                        return this.getFallbackEndPoint();
                    }
                }
            }
        }
    },
    
    _setLinkPoints: function(startPoint, startOrigin, endPoint, endOrigin, startPort, endPort) {
        // tag: private
        
        var i;
        
        this._pathPoints = null;
        
        if (Math.abs(startPoint.x - endPoint.x) <= _constants._epsilon) {
            endPoint.x = startPoint.x;
        }
        if (Math.abs(startPoint.y - endPoint.y) <= _constants._epsilon) {
            endPoint.y = startPoint.y;
        }
        var points = [];
        switch (this._shapeType) {
            case LinkShapeType.Free:
                points.push(startPoint);
                if (this._intermediatePoints !== null) {
                    points.push.apply(points, this._intermediatePoints);
                }
                points.push(endPoint);
                break;
            case LinkShapeType.Straight:
                points.push(startPoint, endPoint);
                break;
            case LinkShapeType.Orthogonal:
            case LinkShapeType.OrthogonalEditable:
            case LinkShapeType.Oblique:
                // TODO (what?)
                
                var startDirection = !this._samePoint(startPoint, startOrigin) ? this._getDirection(startOrigin, startPoint) : this._getDirection(startPoint, endPoint);
                var endDirection = !this._samePoint(endPoint, endOrigin) ? this._getDirection(endOrigin, endPoint) : this._getDirection(endPoint, startPoint);
                
                points.push(startPoint);
                
                var startBounds, endBounds;
                var parent = this._getParent();
                if (parent !== null) {
                    if (startPort !== null) {
                        startBounds = startPort.getConnectionBounds(parent);
                    /*
                     } else if (this.getStart() !== null) {
                     startBounds = this.getStart().getBounds(parent);
                     */
                    } else {
                        startBounds = {
                            x: startPoint.x,
                            y: startPoint.y,
                            width: 0,
                            height: 0
                        };
                    }
                    if (endPort !== null) {
                        endBounds = endPort.getConnectionBounds(parent);
                    /*
                     } else if (this.getEnd() !== null) {
                     endBounds = this.getEnd().getBounds(parent);
                     */
                    } else {
                        endBounds = {
                            x: endPoint.x,
                            y: endPoint.y,
                            width: 0,
                            height: 0
                        };
                    }
                } else {
                    startBounds = {
                        x: startPoint.x,
                        y: startPoint.y,
                        width: 0,
                        height: 0
                    };
                    endBounds = {
                        x: endPoint.x,
                        y: endPoint.y,
                        width: 0,
                        height: 0
                    };
                }
                
                if (this._shapeType === LinkShapeType.OrthogonalEditable &&
                this._intermediatePoints !== null &&
                this._intermediatePoints.length > 0) {
                    var keepExisting = true;
                    
                    // Check that the existing segments are orthogonal.
                    //
                    if (keepExisting) {
                        for (i = 0; i < this._intermediatePoints.length - 1; i++) {
                            if (this._intermediatePoints[i].x != this._intermediatePoints[i + 1].x &&
                            this._intermediatePoints[i].y != this._intermediatePoints[i + 1].y) {
                                keepExisting = false;
                                break;
                            }
                        }
                    }
                    
                    if (keepExisting) {
                        // Keep the existing points,
                        // and just adjust the first/last segments.
                        //
                        points.push.apply(points, this._intermediatePoints);
                        //                        for each(var p in this._intermediatePoints) {
                        //							points.push(p);
                        //						}
                        //
                        points.push(endPoint);
                        
                        // adjust start:
                        //
                        this._adjustEndPoint(points, 0, 1);
                        
                        // adjust end:
                        //
                        this._adjustEndPoint(points, points.length - 1, -1);
                    } else {
                        this._computeOrthogonal(startPoint, startDirection, startBounds, endPoint, endDirection, endBounds, points);
                        points.push(endPoint);
                    }
                } else {
                    this._computeOrthogonal(startPoint, startDirection, startBounds, endPoint, endDirection, endBounds, points);
                    points.push(endPoint);
                }
                
                if (this._shapeType === LinkShapeType.Oblique) {
                
                    for (i = 0; i < points.length - 3; i++) {
                        var p1 = points[i];
                        var p2 = points[i + 1];
                        var p3 = points[i + 2];
                        var p4 = points[i + 3];
                        if (p1.x === p2.x && p3.x === p4.x) {
                            var dx = Math.abs(p3.x - p1.x) / 2;
                            var dy1 = p2.y - p1.y;
                            var dy2 = p4.y - p3.y;
                            if (((dy1 > 0 && dy2 > 0) || (dy1 < 0 && dy2 < 0)) &&
                            Math.abs(dy1) >= dx &&
                            Math.abs(dy2) >= dx) {
                                if (dy1 > 0) {
                                    points[i + 1] = {
                                        x: p2.x,
                                        y: p2.y - dx
                                    };
                                    points[i + 2] = {
                                        x: p3.x,
                                        y: p3.y + dx
                                    };
                                } else {
                                    points[i + 1] = {
                                        x: p2.x,
                                        y: p2.y + dx
                                    };
                                    points[i + 2] = {
                                        x: p3.x,
                                        y: p3.y - dx
                                    };
                                }
                            }
                        } else if (p1.y === p2.y && p3.y === p4.y) {
                            var dy = Math.abs(p3.y - p1.y) / 2;
                            var dx1 = p2.x - p1.x;
                            var dx2 = p4.x - p3.x;
                            if (((dx1 > 0 && dx2 > 0) || (dx1 < 0 && dx2 < 0)) &&
                            Math.abs(dx1) >= dy &&
                            Math.abs(dx2) >= dy) {
                                if (dx1 > 0) {
                                    points[i + 1] = {
                                        x: p2.x - dy,
                                        y: p2.y
                                    };
                                    points[i + 2] = {
                                        x: p3.x + dy,
                                        y: p3.y
                                    };
                                } else {
                                    points[i + 1] = {
                                        x: p2.x + dy,
                                        y: p2.y
                                    };
                                    points[i + 2] = {
                                        x: p3.x - dy,
                                        y: p3.y
                                    };
                                }
                            }
                        }
                    }
                    
                }
                
                break;
            default:
                break;
        }
        
        this._pathPoints = points;
    },
    
    _samePoint: function(p1, p2) {
        return (Math.abs(p1.x - p2.x) <= _constants._epsilon) &&
        (Math.abs(p1.y - p2.y) <= _constants._epsilon);
    },
    
    _getDirection: function(originPoint, connectionPoint) {
        // tag: private
        var dx = connectionPoint.x - originPoint.x;
        var dy = connectionPoint.y - originPoint.y;
        if (Math.abs(dx) >= Math.abs(dy)) {
            // Horizontal:
            if (dx > 0) {
                return _constants._right;
            } else {
                return _constants._left;
            }
        } else {
            // Vertical:
            if (dy > 0) {
                return _constants._bottom;
            } else {
                return _constants._top;
            }
        }
    },
    
    _adjustEndPoint: function(points, i, d) {
        // tag: private
        
        var p0 = points[i]; // The start or end point.
        var p1 = points[i + d]; // The point just next to the start/end point.
        // Do we need to adjust? Only if the first/last segment is not orthogonal.
        if (Math.abs(p0.x - p1.x) > _constants._epsilon && Math.abs(p0.y - p1.y) > _constants._epsilon) {
            // We must guess if the first/last segment must be horizontal or vertical.
            // For this, we cannot just look at the first segment, because the
            // first/last point may have been already modified by the interactor.
            // So, we look at the next segment, and we say that the first/last
            // segment must be orthogonal to it.
            //
            var p2 = points[i + d + d]; // The second point of the next segment.
            var nextSegmentIsHorizontal;
            var dx = Math.abs(p1.x - p2.x);
            var dy = Math.abs(p1.y - p2.y);
            if (dx < _constants._epsilon && dx < _constants._epsilon && points.length > 3) {
                // The next segment is null: this can happen if points
                // get aligned during interaction. In that case, we look at
                // the segment after the next segment.
                p1 = p2;
                p2 = points[i + d + d + d];
                dx = Math.abs(p1.x - p2.x);
                dy = Math.abs(p1.y - p2.y);
                nextSegmentIsHorizontal = dx < dy;
            } else {
                nextSegmentIsHorizontal = dx > dy;
            }
            
            if (nextSegmentIsHorizontal) {
                points[i + d] = {
                    x: p0.x,
                    y: p1.y
                };
            } else {
                points[i + d] = {
                    x: p1.x,
                    y: p0.y
                };
            }
        }
    },
    
    _rotatePosition: function(position, count) {
        // tag: private
        return (position + count) % 4;
    },
    
    _rotatePoint: function(p, count) {
        // tag: private
        var tmp;
        switch (count) {
            case 1:
                tmp = p.x;
                p.x = -p.y;
                p.y = tmp;
                break;
            case 2:
                p.x = -p.x;
                p.y = -p.y;
                break;
            case 3:
                tmp = p.x;
                p.x = p.y;
                p.y = -tmp;
                break;
        }
        return p;
    },
    _rotateRect: function(r, count) {
        // tag: private
        var tmp;
        switch (count) {
            case 1:
                tmp = r.x;
                r.x = -r.y - r.height;
                r.y = tmp;
                tmp = r.width;
                r.width = r.height;
                r.height = tmp;
                break;
            case 2:
                r.x = -r.x - r.width;
                r.y = -r.y - r.height;
                break;
            case 3:
                tmp = r.x;
                r.x = r.y;
                r.y = -tmp - r.width;
                tmp = r.width;
                r.width = r.height;
                r.height = tmp;
                break;
        }
        return r;
    },
    
    _computeOrthogonal: function(startPoint, startDirection, startBounds, endPoint, endDirection, endBounds, points) {
        // tag: private
        
        // First, rotate everything so that the start point points to the top.
        //
        var rotateCount = 0;
        switch (startDirection) {
            case _constants._top:
                break;
            case _constants._bottom:
                rotateCount = 2;
                break;
            case _constants._left:
                rotateCount = 1;
                break;
            case _constants._right:
                rotateCount = 3;
                break;
        }
        
        startPoint = this._rotatePoint(lang.clone(startPoint), rotateCount);
        startDirection = this._rotatePosition(startDirection, rotateCount);
        startBounds = this._rotateRect(lang.clone(startBounds), rotateCount);
        endPoint = this._rotatePoint(lang.clone(endPoint), rotateCount);
        endDirection = this._rotatePosition(endDirection, rotateCount);
        endBounds = this._rotateRect(lang.clone(endBounds), rotateCount);
        
        // OK, now we start to enumerate all directions for the end point.
        //
        var x, y;
        switch (endDirection) {
            case _constants._top:
                if (endBounds.y + endBounds.height < startBounds.y) {
                    if ((endBounds.x > startPoint.x) || (endBounds.x + endBounds.width < startPoint.x)) {
                        //     ___          ___
                        //    |   |        |   |
                        //    |   E   or   E   |
                        //    |                |
                        //    S                S
                        
                        y = Math.min(startBounds.y, endBounds.y) - this._nodeDistance;
                        points.push({
                            x: startPoint.x,
                            y: y
                        });
                        points.push({
                            x: endPoint.x,
                            y: y
                        });
                    } else {
                        //     ___          ___
                        //    |   |        |   |
                        //    |   E   or   E   |
                        //    |__            __|
                        //       |          |
                        //       S          S
                        
                        y = (startPoint.y + endBounds.y + endBounds.height) / 2;
                        points.push({
                            x: startPoint.x,
                            y: y
                        });
                        if (endPoint.x > startPoint.x) {
                            x = endBounds.x - this._nodeDistance;
                        } else {
                            x = endBounds.x + endBounds.width + this._nodeDistance;
                        }
                        points.push({
                            x: x,
                            y: y
                        });
                        y = endBounds.y - this._nodeDistance;
                        points.push({
                            x: x,
                            y: y
                        });
                        points.push({
                            x: endPoint.x,
                            y: y
                        });
                    }
                } else if (endBounds.y > startBounds.y + startBounds.height) {
                    if ((endPoint.x > startBounds.x + startBounds.width) || (endPoint.x < startBounds.x)) {
                        //     ___          ___
                        //    |   |        |   |
                        //    S   |   or   |   S
                        //        E        E
                        
                        y = Math.min(startBounds.y, endBounds.y) - this._nodeDistance;
                        points.push({
                            x: startPoint.x,
                            y: y
                        });
                        points.push({
                            x: endPoint.x,
                            y: y
                        });
                    } else {
                        //     __          __
                        //    |  |        |  |
                        //    S  |   or   |  S
                        //      _|        |_
                        //     |            |
                        //     E            E
                        
                        y = startBounds.y - this._nodeDistance;
                        points.push({
                            x: startPoint.x,
                            y: y
                        });
                        if (endPoint.x < startPoint.x) {
                            x = startBounds.x - this._nodeDistance;
                        } else {
                            x = startBounds.x + startBounds.width + this._nodeDistance;
                        }
                        points.push({
                            x: x,
                            y: y
                        });
                        y = (endPoint.y + startBounds.y + startBounds.height) / 2;
                        points.push({
                            x: x,
                            y: y
                        });
                        points.push({
                            x: endPoint.x,
                            y: y
                        });
                    }
                } else {
                    //     _          _
                    //    | |        | |
                    //    S E   or   E S
                    
                    y = Math.min(startBounds.y, endBounds.y) - this._nodeDistance;
                    points.push({
                        x: startPoint.x,
                        y: y
                    });
                    points.push({
                        x: endPoint.x,
                        y: y
                    });
                }
                break;
            case _constants._bottom:
                if (endPoint.y < startPoint.y) {
                    if (endPoint.x !== startPoint.x) // straight link!...
                    {
                        //           E        E
                        //     ______|   or   |______
                        //    |                      |
                        //    S                      S
                        
                        y = (startPoint.y + endPoint.y) / 2;
                        points.push({
                            x: startPoint.x,
                            y: y
                        });
                        points.push({
                            x: endPoint.x,
                            y: y
                        });
                    }
                } else if ((endBounds.x > startBounds.x + startBounds.width) ||
                (endBounds.x + endBounds.width < startBounds.x)) {
                    //     ____                    ____
                    //    |    |    E   or   E    |    |
                    //    S    |____|        |____|    S
                    
                    y = startBounds.y - this._nodeDistance;
                    points.push({
                        x: startPoint.x,
                        y: y
                    });
                    if (endBounds.x > startBounds.x + startBounds.width) {
                        x = (endBounds.x + startBounds.x + startBounds.width) / 2;
                    } else {
                        x = (endBounds.x + endBounds.width + startBounds.x) / 2;
                    }
                    points.push({
                        x: x,
                        y: y
                    });
                    y = endBounds.y + endBounds.height + this._nodeDistance;
                    points.push({
                        x: x,
                        y: y
                    });
                    points.push({
                        x: endPoint.x,
                        y: y
                    });
                } else {
                    //     ______          ______
                    //    |      |        |      |
                    //    S      |   or   |      S
                    //        E  |        |  E
                    //        |__|        |__|
                    
                    y = Math.min(startBounds.y, endBounds.y) - this._nodeDistance;
                    points.push({
                        x: startPoint.x,
                        y: y
                    });
                    if (endPoint.x > startPoint.x) {
                        x = Math.max(startBounds.x + startBounds.width, endBounds.x + endBounds.width) + this._nodeDistance;
                    } else {
                        x = Math.min(startBounds.x, endBounds.x) - this._nodeDistance;
                    }
                    points.push({
                        x: x,
                        y: y
                    });
                    y = endBounds.y + endBounds.height + this._nodeDistance;
                    points.push({
                        x: x,
                        y: y
                    });
                    points.push({
                        x: endPoint.x,
                        y: y
                    });
                }
                break;
            case _constants._left:
                if (endBounds.x < startPoint.x) {
                    if (endBounds.y + endBounds.height < startPoint.y) {
                        //    _E
                        //   |___
                        //       |
                        //       S
                        
                        y = (startPoint.y + endBounds.y + endBounds.height) / 2;
                        points.push({
                            x: startPoint.x,
                            y: y
                        });
                        x = endBounds.x - this._nodeDistance;
                        points.push({
                            x: x,
                            y: y
                        });
                        points.push({
                            x: x,
                            y: endPoint.y
                        });
                    } else {
                        //     _____
                        //    |     |
                        //    |_E   |
                        //          S
                        
                        y = Math.min(endBounds.y, startBounds.y) - this._nodeDistance;
                        points.push({
                            x: startPoint.x,
                            y: y
                        });
                        x = Math.min(endBounds.x, startBounds.x) - this._nodeDistance;
                        points.push({
                            x: x,
                            y: y
                        });
                        points.push({
                            x: x,
                            y: endPoint.y
                        });
                    }
                } else if (endPoint.y < startBounds.y) {
                    //     ____E
                    //    |
                    //    |
                    //    S
                    
                    points.push({
                        x: startPoint.x,
                        y: endPoint.y
                    });
                } else if (endBounds.x > startBounds.x + startBounds.width) {
                    //     ____
                    //    |    |
                    //    S    |___E
                    
                    y = startBounds.y - this._nodeDistance;
                    points.push({
                        x: startPoint.x,
                        y: y
                    });
                    x = (startBounds.x + startBounds.width + endBounds.x) / 2;
                    points.push({
                        x: x,
                        y: y
                    });
                    points.push({
                        x: x,
                        y: endPoint.y
                    });
                } else {
                    //     ___
                    //    |   |
                    //    |   S
                    //    |__E
                    
                    y = Math.min(endBounds.y, startBounds.y) - this._nodeDistance;
                    points.push({
                        x: startPoint.x,
                        y: y
                    });
                    x = Math.min(endBounds.x, startBounds.x) - this._nodeDistance;
                    points.push({
                        x: x,
                        y: y
                    });
                    points.push({
                        x: x,
                        y: endPoint.y
                    });
                }
                break;
            case _constants._right:
                if (endBounds.x + endBounds.width > startPoint.x) {
                    if (endBounds.y + endBounds.height < startPoint.y) {
                        //      E_
                        //     ___|
                        //    |
                        //    S
                        
                        y = (startPoint.y + endBounds.y + endBounds.height) / 2;
                        points.push({
                            x: startPoint.x,
                            y: y
                        });
                        x = endBounds.x + endBounds.width + this._nodeDistance;
                        points.push({
                            x: x,
                            y: y
                        });
                        points.push({
                            x: x,
                            y: endPoint.y
                        });
                    } else {
                        //     _____
                        //    |     |
                        //    |   E_|
                        //    S
                        
                        y = Math.min(endBounds.y, startBounds.y) - this._nodeDistance;
                        points.push({
                            x: startPoint.x,
                            y: y
                        });
                        x = Math.max(endBounds.x + endBounds.width, startBounds.x + startBounds.width) + this._nodeDistance;
                        points.push({
                            x: x,
                            y: y
                        });
                        points.push({
                            x: x,
                            y: endPoint.y
                        });
                    }
                } else if (endPoint.y < startBounds.y) {
                    //    E____
                    //         |
                    //         |
                    //         S
                    
                    points.push({
                        x: startPoint.x,
                        y: endPoint.y
                    });
                } else if (endBounds.x + endBounds.width < startBounds.x) {
                    //          ____
                    //         |    |
                    //    E____|    S
                    
                    y = startBounds.y - this._nodeDistance;
                    points.push({
                        x: startPoint.x,
                        y: y
                    });
                    x = (startBounds.x + endBounds.x + endBounds.width) / 2;
                    points.push({
                        x: x,
                        y: y
                    });
                    points.push({
                        x: x,
                        y: endPoint.y
                    });
                } else {
                    //     ___
                    //    |   |
                    //    S   |
                    //     E__|
                    
                    y = Math.min(endBounds.y, startBounds.y) - this._nodeDistance;
                    points.push({
                        x: startPoint.x,
                        y: y
                    });
                    x = Math.max(endBounds.x + endBounds.width, startBounds.x + startBounds.width) + this._nodeDistance;
                    points.push({
                        x: x,
                        y: y
                    });
                    points.push({
                        x: x,
                        y: endPoint.y
                    });
                }
                break;
        }
        
        // Rotate the computed points back to the original orientation.
        //
        if (rotateCount !== 0) {
            rotateCount = 4 - rotateCount;
            for (var i = 1; i < points.length; i++) {
                var p = points[i];
                p = this._rotatePoint(p, rotateCount);
                points[i] = p;
            }
        }
    },
    _changeSelectionStyle: function(selected) {
        this.inherited(arguments);
        this.invalidateLinkShape();
    },
	
	// Link decorations:
	
	getDecorations: function() {
		// summary:
		//		Gets an array containing the decorations of the link.
		// returns: Array:
		//		An array of GFX shapes.
		// description:
		//		The link can contain shapes called "decorations". Decorations are automatically
		//		placed along the link path. To be considered as a decoration, a child shape
		//		must have the "isDecoration" set to true. The decoration can have the following properties
		//		that define their placement on the link:
		//		- position: A number that defines the position of the decoration along the link. The meaning
		//				of the position depends on the positionType property.
		//				The default position is 0.5, and 
		//				The default positionType is ibm_ilog.diagram.LinkDecorationPositionType.Relative,
		//				so by default a decoration is placed at the middle of the link.
		//		- positionType: Defines the way the position is interpreted. Possible values are:
		//			ibm_ilog.diagram.LinkDecorationPositionType.Relative:
		//				The position property is a ratio between 0 and 1 that defines a relative position on the
		//				link (0 = start of the link, 1 = of the link, 0.5 = middle of the link, etc).
		//			ibm_ilog.diagram.LinkDecorationPositionType.AnsoluteFromStart:
		//				The position is a fixed length that defines an offset from the start of the link
		//				(going forward from the start to the end of the link).
		//			ibm_ilog.diagram.LinkDecorationPositionType.AnsoluteFromMiddle:
		//				The position is a fixed length that defines an offset from the middle of the link
		//				(going forward from the start to the end of the link).
		//			ibm_ilog.diagram.LinkDecorationPositionType.AnsoluteFromEnd:
		//				The position is a fixed length that defines an offset from the end of the link
		//				(going backward from the end to the start of the link).
		//				The default positionType is ibm_ilog.diagram.LinkDecorationPositionType.Relative,
		//				and the default position is 0.5,
		//				so by default a decoration is placed at the middle of the link.
		//		- orthogonalAlignment: Defines the alignment of the decoration orthogonally to the link path.
		//				Possible values are:
		//			ibm_ilog.diagram.LinkDecorationOrthogonalAlignment.Left:
		//				The decoration is placed on the "left" of the link, looking towards the end of the link
		//				(for example, if the link is horizontal and pointing to the right, the decoration will be
		//				above the link). The spacing between the decoration and the link is defined by the
		//				distance property.
		//			ibm_ilog.diagram.LinkDecorationOrthogonalAlignment.Center:
		//				The decoration is centered on the link.
		//			ibm_ilog.diagram.LinkDecorationOrthogonalAlignment.Start:
		//				The decoration is placed on the "right" of the link, looking towards the end of the link
		//				(for example, if the link is horizontal and pointing to the right, the decoration will be
		//				below the link). The spacing between the decoration and the link is defined by the
		//				distance property.
		//				The default orthogonalAlignment is ibm_ilog.diagram.LinkDecorationOrthogonalAlignment.Center.
		//		- parallelAlignment: Defines the alignment of the decoration along the link.
		//				Possible values are:
		//			ibm_ilog.diagram.LinkDecorationParallelAlignment.Start:
		//				The side of the decoration that is closest to the start of the link is aligned
		//				on the point defined by the position and positionType.
		//			ibm_ilog.diagram.LinkDecorationParallelAlignment.Middle:
		//				The middle of the decoration is aligned
		//				on the point defined by the position and positionType.
		//			ibm_ilog.diagram.LinkDecorationParallelAlignment.Start:
		//				The side of the decoration that is closest to the end of the link is aligned
		//				on the point defined by the position and positionType.
		//				The default parallelAlignment is ibm_ilog.diagram.LinkDecorationParellelAlignment.Middle.
		//		- distance: Defines the distance between the decoration and the link when
		//				orthogonalAlignment is ibm_ilog.diagram.LinkDecorationOrthogonalAlignment.Left
		//				or ibm_ilog.diagram.LinkDecorationOrthogonalAlignment.Right.
		//				The default distance is 0.
		//		- autoRotate: If autoRotate is true, the decoration is rotated according to the orientation
		//				of the link segment that contains the decoration position.
		//				By default, autoRotate is false.

		var decorations = [];
		
		var children = this.children;
		var childrenCount = children.length;
		
		for (var childIndex = 0; childIndex < childrenCount; childIndex++) {
			var item = children[childIndex];
			if (item.isDecoration) {
				decorations.push(item);
			}
		}
		
		return decorations;
	},
	
	_placeDecorations: function(target){
		// summary:
		//		Moves (and possibly rotates) a decoration along the link's path.
		// tags:
		//		private
		
		target = target || this;
		
		var points = null;
		var totalLength = 0;
		
		var children = target.children;
		var childrenCount = children.length;
		
		for (var childIndex = 0; childIndex < childrenCount; childIndex++) {
			var item = children[childIndex];
			if (item.isDecoration) {
				
				if (!points) {
					points = target._pathPoints;
					// compute total length of link
					for (var i = 0; i < points.length - 1; i++) 
						totalLength += Geometry.getDistance(points[i], points[i + 1]);
				}
				
				// get placement parameters and set default values
				
				var position = (item.position !== undefined) ? item.position : 0.5;
				var positionType = item.positionType || iid.LinkDecorationPositionType.Relative;
				var positionLength = 0;
				var autoRotate = item.autoRotate;
				var distance = item.distance || 0;
				var orthogonalAlignment = item.orthogonalAlignment || iid.LinkDecorationOrthogonalAlignment.Center;
				var parallelAlignment = item.parallelAlignment || iid.LinkDecorationParallelAlignment.Middle;
				
				switch (positionType) {
					case iid.LinkDecorationPositionType.Relative:
						positionLength = totalLength * position;
						break;
					case iid.LinkDecorationPositionType.AbsoluteFromStart:
						positionLength = position;
						break;
					case iid.LinkDecorationPositionType.AbsoluteFromMiddle:
						positionLength = totalLength / 2 + position;
						break;
					case iid.LinkDecorationPositionType.AbsoluteFromEnd:
						positionLength = totalLength - position;
						break;
				}
				
				var currentLength = 0;
				var i;
				for (i = 0; i < points.length - 1; i++) {
					currentLength += Geometry.getDistance(points[i], points[i + 1]);
					if (positionLength < currentLength) 
						break;
				}
				if (i == points.length - 1) 
					i--;
				
				var d = Geometry.getDistance(points[i], points[i + 1]);
				
				var p;
				var dx, dy;
				
				if (d == 0) {
					p = {
						x: points[i].x,
						y: points[i].y
					};
					dx = 0;
					dy = 0;
				}
				else {
					var e = currentLength - positionLength;
					dx = points[i + 1].x - points[i].x;
					dy = points[i + 1].y - points[i].y;
					p = {
						x: points[i + 1].x - (dx * e) / d,
						y: points[i + 1].y - (dy * e) / d
					};
				}
				
				// Compute final position based on alignments and distance:
				//
				
				item.setTransform(null);
				
				var bounds = item.getBoundingBox() || {height: 0, width: 0, x:0, y:0};
				
				var rotationTransform = null;
				
				if (dy == 0 && !autoRotate) {
					// Horizontal segment:
					//
					var dir = dx >= 0 ? 1 : -1;
					switch (orthogonalAlignment) {
						case iid.LinkDecorationOrthogonalAlignment.Center:
							break;
						case iid.LinkDecorationOrthogonalAlignment.Left:
							p.y -= dir * (distance + bounds.height / 2);
							break;
						case iid.LinkDecorationOrthogonalAlignment.Right:
							p.y += dir * (distance + bounds.height / 2);
							break;
					}
					switch (parallelAlignment) {
						case iid.LinkDecorationParallelAlignment.Middle:
							break;
						case iid.LinkDecorationParallelAlignment.Start:
							p.x += dir * (bounds.width / 2);
							break;
						case iid.LinkDecorationParallelAlignment.End:
							p.x -= dir * (bounds.width / 2);
							break;
					}
				}
				else 
					if (dx == 0 && !autoRotate) {
						// Vertical segment:
						//
						dir = dy >= 0 ? 1 : -1;
						switch (orthogonalAlignment) {
							case iid.LinkDecorationOrthogonalAlignment.Center:
								break;
							case iid.LinkDecorationOrthogonalAlignment.Left:
								p.x += dir * (distance + bounds.width / 2);
								break;
							case iid.LinkDecorationOrthogonalAlignment.Right:
								p.x -= dir * (distance + bounds.width / 2);
								break;
						}
						switch (parallelAlignment) {
							case iid.LinkDecorationParallelAlignment.Middle:
								break;
							case iid.LinkDecorationParallelAlignment.Start:
								p.y += dir * (bounds.height / 2);
								break;
							case iid.LinkDecorationParallelAlignment.End:
								p.y -= dir * (bounds.height / 2);
								break;
						}
					}
					else {
						// Oblique segment, or AutoRotate == true
						//
						
						var angle = Math.atan2(dy, dx);
						var t = gfxm.rotateAt(-angle, p);
						var pbounds;
						if (autoRotate) 
							pbounds = lang.clone(bounds);
						else 
							pbounds = t.transformRectangle(bounds);
						
						
						switch (orthogonalAlignment) {
							case iid.LinkDecorationOrthogonalAlignment.Center:
								break;
							case iid.LinkDecorationOrthogonalAlignment.Left:
								p.y -= distance + pbounds.height / 2;
								break;
							case iid.LinkDecorationOrthogonalAlignment.Right:
								p.y += distance + pbounds.height / 2;
								break;
						}
						switch (parallelAlignment) {
							case iid.LinkDecorationParallelAlignment.Middle:
								break;
							case iid.LinkDecorationParallelAlignment.Start:
								p.x += pbounds.width / 2;
								break;
							case iid.LinkDecorationParallelAlignment.End:
								p.x -= pbounds.width / 2;
								break;
						}
						
						t = t.inverse();
						p = t.transformPoint(p);
						
						if (autoRotate) {
							var pi = Math.PI;
							if (angle > pi / 2 || angle < -pi / 2) {
								if (angle < 0) 
									angle += pi;
								else 
									angle -= pi;
								t = gfxm.rotateAt(angle, {
									x: t.dx,
									y: t.dy
								});
							}
							item.setTransform(t);
							bounds = t.transformRectangle(bounds);
						}
					}
				
				// OK, move the decoration now, 'p' contains the location of the center of the decoration.
				
				dx = p.x - (bounds.x + bounds.width / 2)
				dy = p.y - (bounds.y + bounds.height / 2);
				
				if (dx != 0 || dy != 0) 
					item.applyLeftTransform(gfxm.translate(dx, dy));
			}
		}
	},
	
// ---------- Bounds: ----------
    
    _onChanged: function(shape, reason) {
    	this._bbCacheValid = false;
    	if(this._explicitSize)
    		this._explicitSize = null;
	},
	
	_computePreferredSize: function(proposedSize){
		this._noOnChanged = true;
		this.validateLinkShape();
		delete this._noOnChanged;
    	this._bbCacheValid = false;
    	if(this._explicitSize)
    		this._explicitSize = null;
		return GraphElement.prototype._computePreferredSize.call(this, proposedSize);
	},
	
    getBounds: function(/*dojox.gfx.Group*/parent) {
        // summary:
        //		Returns the bounds of this node in the coordinate space of the specified parent.
        // parent: dojox.gfx.Group
        //		The parent object that determines the coordinate space
        //		the bounds are relative to. If null or undefined, the bounds of the node
        //		relative to its parent are returned.
        // returns:
        //		A rectangle (i.e. an object with x/y/width/height properties) containing
        //		the bounds of the node in the specified coordinate space.
        
        var rect = this.getLocalBoundingBox();
        if (rect && parent && parent != this.getParent()) {
            var t = this.getTransformToContainer(parent);
            rect = t.transformRectangle(rect);
        }
        return rect;
    },
    
    hitTest: function(p,graph,tolerance){
    	// Summary:
    	//		return if the given point hits the element
    	var g = Geometry;
    	
    	if(tolerance == null){
    		tolerance = this._hitTolerance;
    	}
    	
    	var bb = this.getBounds(graph);
    	if(!bb) {
    		return false;
    	}
    	bb = g.expandRect(bb,tolerance);
    	if(g.containsPoint(bb,p)) {
    		var path = this._path;
    		if (path instanceof gfx.Polyline) {
    			var t = this.getShapeToContainerTransform(graph).inverse();
    			p = t.transformPoint(p);
    			if(this._getPathDistance(path,p)<tolerance){
    				return true;
    			}
    		}else{
    			// TODO if the link is not a polyline, use just the bounding box
    			return true;
    		}
    	}
    	return false;
    },
    
    _getPathDistance: function(path,p){
    	// Summary:
    	//		calculates the distance from the polyline to the given point
    	//
    	var g = Geometry;
    	var points = path.getShape().points;
    	var distance = Number.MAX_VALUE;
    	for(var i=1;i<points.length;i++){
    		var a = points[i-1];
    		var b = points[i];
    		var d = g.getPointToSegmentDistance(a,b,p);
    		distance = Math.min(distance,d);
    	}
    	return distance;
    }
});

var LinkDecorationPositionType = {
	Relative: 1,
	AbsoluteFromStart: 2,
	AbsoluteFromMiddle: 3,
	AbsoluteFromEnd: 4
};
iid.LinkDecorationPositionType = LinkDecorationPositionType;

var LinkDecorationParallelAlignment = {
	Start: 1,
	Middle: 2,
	End: 3
};
iid.LinkDecorationParallelAlignment = LinkDecorationParallelAlignment;

var LinkDecorationOrthogonalAlignment = {
	Left: 1,
	Center: 2,
	Right: 3
};
iid.LinkDecorationOrthogonalAlignment = LinkDecorationOrthogonalAlignment;

var _constants = {
    _top: 0,
    _right: 1,
    _bottom: 2,
    _left: 3,
    
    _epsilon: 0.001
};

Link.nodeType = gfx.Group.nodeType;
Link.defaultShape = {
    type: 'link'
};

// Declare bindable properties
templating.declareBindableProperty(Link, "strokeColor", "#000000");
templating.declareBindableProperty(Link, "strokeWidth", 2);
templating.declareBindableProperty(Link, "selectedStrokeColor", "#0000FF");
templating.declareBindableProperty(Link, "selectedStrokeWidth", 3);
templating.declareBindableProperty(Link, "data", null);
templating.declareBindableProperty(Link, "textDir", ""); 

Link.defaultTemplate = iid.declareTemplate(templates.defaultLinkTemplate);

Link.LinkShapeType = LinkShapeType; // for easier access from module value

return Link;

});
