/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"./OverviewInteractor"
],
function(
declare,
OverviewInteractor
){

/*=====
var OverviewInteractor = ibm_ilog.diagram.overview.OverviewInteractor;
=====*/

var OverviewZoomInteractor =
declare("ibm_ilog.diagram.overview.OverviewZoomInteractor", [OverviewInteractor], {
	//
	//	summary:
	//		A ZoomInteractor controls the process of viewport panning and zooming
	//
	//	_incrementFactor: Number
	//		The factor at which the zoom is incremented at each discrete step
	//
	_incrementFactor: 1.5,



	setIncrementFactor: function ( /*Number*/ factor) {
		//
		//	summary:
		//		Sets the increment factor for zooming discrete operations
		//
		this._incrementFactor = factor;
	},

	getIncrementFactor: function () {
		//
		//	summary:
		//		Returns the increment factor for zooming discrete operations
		//
		return this._incrementFactor;
	},

	_declareStates: function () {
		this._declareState("idle", ["wheelZoom"]);
	},

	getDefaultConnections: function () {
		//
		//	summary:
		//		Returns the default event mapping
		//
		return {
			wheelZoom: {
				src: this._overview.getEventSource(),
				srcEvt: this.eventNameWheel,
				connectTo: "_wheelZoom",
				filter: this._noneFilter,
				gfxConnect: true
			}
		};
	},

	_wheelZoom: function ( /*Event*/ e) {
		//
		//	summary:
		//		Handles the wheel mouse event and dispatchs the appropriate zooming operations
		//
		var v = this._incrementFactor;

		if (this.eventWheelAmmount(e) < 0) {
			v = 1 / v;
		}

		this._viewport.setZoom(this._viewport.getZoom() * v);

		if (e.preventDefault) {
			e.preventDefault();
		}

		//	TODO: do we need this?
		e.returnValue = false;
	}

});

return OverviewZoomInteractor;

});
