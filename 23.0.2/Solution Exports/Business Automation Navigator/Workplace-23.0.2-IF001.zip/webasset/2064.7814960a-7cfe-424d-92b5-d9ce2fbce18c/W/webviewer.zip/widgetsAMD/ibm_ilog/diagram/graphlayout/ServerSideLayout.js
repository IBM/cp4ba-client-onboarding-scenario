/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
	"dojo/_base/declare",
	"dojo/_base/config",
	"dojo/_base/lang",
	"dojo/_base/json",
	"dojo/_base/array",
	"dojo/_base/window",
	"dojo/_base/Deferred",
	"dojo/_base/xhr",
	"require",
	"dojox/lang/functional/array",
	"dojox/gfx",
	"dojox/collections/Dictionary",
	"ibm_ilog/graphlayout/IIterator",
	"ibm_ilog/graphlayout/internalutil/GraphModelUtil",
	"./GraphAdapter",
	"../util/GraphUtil",
	"../util/ErrorReporter",
	"../util/Geometry",
	"../util/Batch",
	"../gfxlayout/Engine",
	"dojo/has!graph-layout-without-diagram?:ibm_ilog/diagram/graphlayout/_base"
	],
	function(
		declare,
		config,
		lang,
		json,
		array,
		win,
		Deferred,
		xhr,
		require,
		df,
		gfx,
		Dictionary,
		IIterator,
		GraphModelUtil,
		GraphAdapter,
		gu,
		R,
		g,
		Batch,
		gfxlayout
	) {

// AVA: TODO OPTIMIZEME "ip"
    
    var isServerSideExtended = function(instance) {
        return instance.__serverSideEnabled__ === true;
    };
    
	var _requireCache = {};
	var _require = function(name) {
		// summary: Cache-enhanced version of require() used to dynamically load classes.
		var c = _requireCache[name];
		if(c === undefined){
			try {
				c = require(name);
			} catch(err){
				c = null;
			}
			_requireCache[name] = c;
		}
		return c;
	};
	
    var commonLayoutExtension = {
        __serverSideEnabled__: true,
        
        getServerLayoutGlobalParameters: function() {
            return {};
        },
        
        getLayoutGlobalDescriptor: function() {
            var descriptor = {
                algorithm: this.id
            };
            var globalParameters = this.getServerLayoutGlobalParameters();
            if (globalParameters !== null) {
                lang.mixin(descriptor, globalParameters);
            }
            return json.toJson(descriptor);
        },
        
        getLayoutNodeDescriptor: function(node) {
            var nodeParameters = this.getServerLayoutNodeParameters(node);
            if (nodeParameters === null) {
                return null;
            }
            var descriptor = {};
            lang.mixin(descriptor, nodeParameters);
            return json.toJson(descriptor);
        },
        
        getLayoutLinkDescriptor: function(link) {
            var linkParameters = this.getServerLayoutLinkParameters(link);
            if (linkParameters === null) {
                return null;
            }
            var descriptor = {};
            lang.mixin(descriptor, linkParameters);
            return json.toJson(descriptor);
        },
        
        _capitalize: function(w) {
            return w.substring(0, 1).toUpperCase() + w.substring(1);
        },
        
        _isRectType: function(value, defaultValue) {
            return (value !== null && value !== undefined && value.width !== undefined) ||
            (defaultValue !== null && defaultValue !== undefined && defaultValue.width !== undefined);
        },
        
        _isPointType: function(value, defaultValue) {
            // Must be called only for parameters that have been tested already against _isRectType.
            return (value !== null && value !== undefined && value.x !== undefined) ||
            (defaultValue !== null && defaultValue !== undefined && defaultValue.x !== undefined);
        },
        
        _forceSavingParameter: function(paramName, layoutName) {
            // A few global parameters have different default values in JViews than in Dojo.
            // This must be always be put in json.
            // The default value comes from J2JS metadata embedded in the java
            // layouts, for instance:
            // @j2js jsinspectable (name="linkClipping",defaultValue="false")
            // The alternate solution for handling the cases of different defaults would be
            // that the metadata declares the default for the JViews layouts, not for the
            // dojo ones. But doing so would introduce a mess in the metadata and would 
            // make it harder to be reused for other purposes, such as providing a customization
            // GUI for the Dojo layouts.
            return ("forcedirected" == layoutName &&
            		(paramName == "respectNodeSizes" ||
            		 paramName == "maxRepeatForConvergence" ||
            		 paramName == "layoutMode")) ||
            	  ("circular" == layoutName &&
             		 paramName == "clusteringMode") ||
            	  ("hierarchical" == layoutName &&
             		 paramName == "recursiveLayoutMode") ||
								// This param holds for several algos (BasicLinkStyleLayout and its
								// subclasses ForceDirected, Circular and Random). No real need to
								// check the layoutname. 
								(paramName == "connectLinksToNodeCenters");
        },
        
        _isDefaultValue: function(value, defaultValue, isRectParam, isPointParam) {
            if (value === null || value === undefined) {
                // if both null or undefined, then the param has the default value
                return defaultValue === null || defaultValue === undefined;
            } else if (defaultValue === null || defaultValue === undefined) {
                return value === null || value === undefined;
            } else {
            	// okay, both value and defaultValue are not null and are not undefined
               	if (isRectParam) {
                	return value.x == defaultValue.x && value.y == defaultValue.y &&
                     	value.width == defaultValue.width &&
                        value.height == defaultValue.height;
                } else if (isPointParam) {
                    return value.x == defaultValue.x && value.y == defaultValue.y;
                } else {
                 	// okay, it is a parameter of type int/float/long/double/boolean
                    return value == defaultValue;
                }
      	    }
        },
        
        _addServerParam: function(params, name, defaultValue, layoutName, getterArg) {
            // getterArg : the argument to be passed to the getter of the layout
            // parameter. This argument must be passed for local (per-node/link)
            // layout parameters (the node/link itself). For global parameters
            // it is not passed.
            // layoutName : the identifier of the layout algorithm. 
            //
            // Returns true if the parameter has been added, false otherwise.
            
						var isCircularClusterIds = "circular" == layoutName && "clusterIds" == name;
						
						var getterPrefix;
						var value = null;
						if (!isCircularClusterIds) {
							getterPrefix = (typeof(defaultValue) == "boolean") ? "is" : "get";
							value = this[getterPrefix + this._capitalize(name)](getterArg);
						} else {
							// Do not use CircularLayout.getClusterIds() because this triggers the 
							// clusterization which would fail with the reduced layout code for SSL.
							// Note that we are only interested in the specified clusters, not in
							// those computed by the automatic clustering.
							value = this._getClusterIds(this);
						}
			
            var isRectParam = this._isRectType(value, defaultValue);
            var isPointParam = isRectParam ? false : this._isPointType(value, defaultValue);
            
            if (this._forceSavingParameter(name, layoutName) ||
            		!this._isDefaultValue(value, defaultValue, isRectParam, isPointParam)) {
                var isHierarchicalConstraints = false; // case of HierarchicalLayout's constraints.
                var isCircularClusterIds = false; // case of CircularLayout's cluster ids.
                
                if (value !== null) {
                    if (isRectParam) {
                        value = [value.x, value.y, value.width, value.height];
                    } else if (isPointParam) {
                        value = [value.x, value.y];
                    } else if ("hierarchical" == layoutName) {
											if ("constraints" == name &&
					  							value instanceof IIterator) {
					  						this._addServerHierarchicalConstraintsParam(params, value);
					  						isHierarchicalConstraints = true;
					  					} else if ("recursiveLayoutMode" == name && 
																 value && // shortcut
											           this.getGraphModel().getSubgraphsCount() == 0) {
												// The client-side Dojo HierarchicalLayout automatically disables
												// recursive mode for flat graphs. We must configure the server-side
												// layout consistently. 
												// Also, the recursive mode of HierarchicalLayout does not support swimlanes
												// (documented limitation in Dojo and JViews). Thanks to the internal
												// flattening of the graph model in presence of swimlanes, the graph model
												// is flat for nested graphs containing swimlanes, and this is how the
												// client-side Dojo HierarchicalLayout deactivates the recursive mode for
												// swimlanes. By counting here the subgraphs we ensure the same holds for
												// server-side layout.
												value = false;
											}
                    } else if ("circular" == layoutName && "clusterIds" == name) {
                        this._addServerCircularClusterIdsParam(params, value);
                        isCircularClusterIds = true;
                    }
                } // else keep the value at null
                
                if (!(isHierarchicalConstraints || isCircularClusterIds)) {
                    params[name] = value;
                } // else constraints and cluster ids are handled differently
                
                return true;
            }
            return false;
        },
        
				// =====================================================================
				// Hierarchical layout
				
        _addServerHierarchicalConstraintsParam: function(params, value) {
            // value : the value of hierarchicalLayout.getConstraints() parameter. 
            if (!value) {
                return false;
            }
            var e = value;
            var constraint;
            var allConstraintsValue = [];
            var constraintValue;
            
						// Analysis of the dojo.require situation:
						// This method is only called if the user has configured an instance of
						// of HierarchicalLayout on the client graph. Hence, the class HierarchicalLayout
						// is already loaded. Which implies that ibm_ilog.graphlayout.hierarchical is already 
						// loaded. Hence no need for a dojo.require for it.
						// Also, a client-side constraint can be of a certain type only if an instance of
						// this constraint type has been specified by the user. Hence, again, we do not
						// need a dojo.require for the constraint class. We only need to check 
						// that the constraint class is not undefined before using instanceof.
			
			// AMD conversion note: the explanations above still apply, we call require() to check whether
			// each class is already loaded or not.
			
			var HierarchicalLevelRangeConstraint = _require("ibm_ilog/graphlayout/hierarchical/HierarchicalLevelRangeConstraint");
			var HierarchicalGroupSpreadConstraint = _require("ibm_ilog/graphlayout/hierarchical/HierarchicalGroupSpreadConstraint");
			var HierarchicalRelativeLevelConstraint = _require("ibm_ilog/graphlayout/hierarchical/HierarchicalRelativeLevelConstraint");
			var HierarchicalExtremityConstraint = _require("ibm_ilog/graphlayout/hierarchical/HierarchicalExtremityConstraint");
			var HierarchicalRelativePositionConstraint = _require("ibm_ilog/graphlayout/hierarchical/HierarchicalRelativePositionConstraint");
			var HierarchicalSameLevelConstraint = _require("ibm_ilog/graphlayout/hierarchical/HierarchicalSameLevelConstraint");
			var HierarchicalSideBySideConstraint = _require("ibm_ilog/graphlayout/hierarchical/HierarchicalSideBySideConstraint");
			var HierarchicalSwimLaneConstraint = _require("ibm_ilog/graphlayout/hierarchical/HierarchicalSwimLaneConstraint");
			
            while (e.hasNext()) {
                constraint = e.next();
                constraintValue = null;
                if (HierarchicalLevelRangeConstraint &&
				    				constraint instanceof HierarchicalLevelRangeConstraint) {
                    var nodesValue1 = this._getConstraintNodes(constraint.getSubject());
                    constraintValue = {
                        name: "LevelRangeConstraint",
                        minLevel: constraint.getMinLevel(),
                        maxLevel: constraint.getMaxLevel(),
                        nodes: nodesValue1
                    };
                } else if (HierarchicalGroupSpreadConstraint &&
						   							constraint instanceof HierarchicalGroupSpreadConstraint) {
                	var nodesValue2 = this._getConstraintNodes(constraint.getGroup());
                    constraintValue = {
                    	name: "GroupSpreadConstraint",
                        spreadSize: constraint.getSpreadSize(),
                        nodes: nodesValue2
                    };
               	} else if (HierarchicalRelativeLevelConstraint &&
				         						constraint instanceof HierarchicalRelativeLevelConstraint) {
                 	var lowerNodesValue1 = this._getConstraintNodes(constraint.getLowerSubject());
                    var higherNodesValue1 = this._getConstraintNodes(constraint.getHigherSubject());
                    	constraintValue = {
                        name: "RelativeLevelConstraint",
                        lowerNodes: lowerNodesValue1,
                        higherNodes: higherNodesValue1
                    };
                } else if (HierarchicalExtremityConstraint &&
				 		   							constraint instanceof HierarchicalExtremityConstraint) {
                    var nodeValue = this._getConstraintNodes(constraint.getNode());
                    constraintValue = {
                    	name: "ExtremityConstraint",
                        side: constraint.getSide(),
                        node: nodeValue
                    };
                } else if (HierarchicalRelativePositionConstraint &&
						   							constraint instanceof HierarchicalRelativePositionConstraint) {
                    var lowerNodesValue2 = this._getConstraintNodes(constraint.getLowerSubject());
                    var higherNodesValue2 = this._getConstraintNodes(constraint.getHigherSubject());
                    constraintValue = {
                    	name: "RelativePositionConstraint",
                        lowerNodes: lowerNodesValue2,
                        higherNodes: higherNodesValue2
                    };
				} else if (HierarchicalSameLevelConstraint &&
						   constraint instanceof HierarchicalSameLevelConstraint) {
					var firstNodeValue = this._getConstraintNodes(constraint.getFirstNode());
					var secondNodeValue = this._getConstraintNodes(constraint.getSecondNode());
					constraintValue = {
						name: "SameLevelConstraint",
						firstNode: firstNodeValue,
						secondNode: secondNodeValue
					};
				} else if (HierarchicalSideBySideConstraint &&
						   constraint instanceof HierarchicalSideBySideConstraint) {
					var nodesValue3 = this._getConstraintNodes(constraint.getGroup());
					constraintValue = {
						name: "SideBySideConstraint",
						nodes: nodesValue3
					};
				} else if (HierarchicalSwimLaneConstraint &&
						   constraint instanceof HierarchicalSwimLaneConstraint) {
					var nodesValue4 = this._getConstraintNodes(constraint.getGroup());
					constraintValue = {
						name: "SwimLaneConstraint",
						relativeSize: constraint.getRelativeSize(),
						specPositionIndex: constraint.getSpecPositionIndex(),
						eastMinMargin: constraint.getEastMinMargin(),
						westMinMargin: constraint.getWestMinMargin(),
						nodes: nodesValue4
					};
				} 
           if (constraintValue !== null) {
					// Properties that exist on all constraints:
					constraintValue.priority = constraint.getPriority();
					
					// Add it
                    allConstraintsValue.push(constraintValue);
                }
            }
            
            var atLeastOneConstraint = allConstraintsValue.length > 0;
            if (atLeastOneConstraint) {
                params.constraints = allConstraintsValue;
            }
            
            return atLeastOneConstraint;
        },
        
        _getConstraintNodes: function(constraintSubject) {
            // constraintSubject: a node or a HierarchicalNodeGroup
            // Returns an array of objects representing the nodes that are subject
            // to a hierarchical constraint.
            if (constraintSubject === null) {
                return null; // empty constraint
            }
            if (constraintSubject._isIBMDiagramNode) {
                return [{id: constraintSubject.getId()}];
            } // else it is a HierachicalNodeGroup
            var nodesValue = [];
            var elements = constraintSubject.elements();
            var node;
            while (elements.hasNext()) {
                node = elements.next();
                nodesValue.push({
                    id: node.getId()
                });
            }
            return nodesValue;
        },
				
				// ==================================================================================
				// Circular layout
				
				_getClusterIds: function(circularLayout) {
				   	var nodes = circularLayout.getGraphModel().getNodes();
						var n = nodes.length;
						var nodeClusterIds;
						var clusterIds = null; 
						var node;
						var clusterId;
						var ClusterIdCollection = _require("ibm_ilog/graphlayout/circular/clayout/ClusterIdCollection");
        		for (var i = 0; i < n; i++) {
							node = nodes[i];
							nodeClusterIds = circularLayout.getNodeClusterIds(node);
							var nClusterIds = nodeClusterIds != null ? nodeClusterIds.length : 0;
							for (var j = 0; j < nClusterIds; j++) {
			  					clusterId = clusterIds[j];
								if (clusterIds == null)
									clusterIds = new ClusterIdCollection(clusterId);
								else
								  clusterIds.add(clusterId);
			  			}								
						}
						return clusterIds != null ? clusterIds.getClusterIds() : [];
				},
        
        _addServerCircularClusterIdsParam: function(params, value) {
            // value : the value of circularLayout.getClusterIds() parameter. 
            if (!value) {
                return false;
            }
            var clusterId;
            var allClusterIdsValue = [];
            var clusterIdValue;
            var clusterIndex = 0;
            
						// Analysis of the dojo.require situation:
						// This method is only called if the user has configured an instance of
						// of CircularLayout on the client graph. Hence, the class CircularLayout
						// is already loaded. Which implies that ibm_ilog.graphlayout.circular is already 
						// loaded. Hence no need for a dojo.require for it.
						// Also, a client-side cluster identifier can be of a certain type only if an 
						// instance of it has been specified by the user. Hence, again, we do not
						// need a dojo.require for the cluster identifier class. We only need to check 
						// that the cluster identifier class is not undefined before using instanceof.
			
			// AMD conversion node: we now call require("classname") to test if the class is loaded.
			
			var CircularClusterName = _require("ibm_ilog/graphlayout/circular/CircularClusterName");
			var CircularClusterNumber = _require("ibm_ilog/graphlayout/circular/CircularClusterNumber");
			
            for (var i = 0; i < value.length; i++) {
                clusterId = value[i];
                clusterIdValue = null;
                var nodesDescription = [];
                var isClusterName = false;
                var isClusterNumber = false;
                if (CircularClusterName && 
										clusterId instanceof CircularClusterName) {
                    isClusterName = true;
                } else if (CircularClusterNumber &&
						   							clusterId instanceof CircularClusterNumber) {
									isClusterNumber = true;
                }
                if (isClusterName || isClusterNumber) {
                    var nodesValue = this.getClusterNodes(i);
                    for (var j = 0; j < nodesValue.length; j++) {
                        var node = nodesValue[j];
                        var index = this.getIndex(node, clusterId);
                        var isStarCenter = this.isStarCenter(node);
                        var obj = {
                            id: node.getId()
                        };
                        if (index >= 0) {
                            obj.index = index;
                        }
                        if (isStarCenter) {
                            obj.starCenter = true;
                        }
                        nodesDescription.push(obj);
                    }
                    clusterIdValue = {};
                    if (isClusterName) {
                        clusterIdValue.name = clusterId.getName();
                    } else {
                        clusterIdValue.number = clusterId.getNumber();
                    }
                    clusterIdValue.nodes = nodesDescription;
                }
                if (clusterIdValue.nodes) {
                    allClusterIdsValue.push(clusterIdValue);
                }
            }
            
            var atLeastOneClusterId = allClusterIdsValue.length > 0;
            if (atLeastOneClusterId) {
                params.clusterIds = allClusterIdsValue;
            }
            
            return atLeastOneClusterId;
        },
        
        _addServerGlobalParam: function(params, name, defaultValue, layoutName) {
            // Returns true if the parameter has been added, false otherwise.
            return this._addServerParam(params, name, defaultValue, layoutName);
        },
        
        _addServerNodeOrLinkParam: function(nodeOrLink, params, name, defaultValue, layoutName) {
            // Returns true if the parameter has been added, false otherwise.
            return this._addServerParam(params, name, defaultValue, layoutName, nodeOrLink);
        },
        
        _getServerGlobalParameters: function(globalProperties, layoutName) {
            var params = {};
            if (globalProperties) {
                var n = globalProperties.length;
                var param;
                for (var i = 0; i < n; i++) {
                    param = globalProperties[i];
                    this._addServerGlobalParam(params, param.name, param.defaultValue, layoutName);
                }
            }
            return params;
        },
        
        _getServerNodeOrLinkParameters: function(nodeOrLink, nodeOrLinkProperties, layoutName) {
            if (nodeOrLinkProperties) {
                var n = nodeOrLinkProperties.length;
                if (n === 0) {
                    return null;
                }
                var params = {};
                var param;
                // For local (per-node/link) parameters, we skip completely the dump to
                // json of these parameters if there is none with non-default value.
                // (For global parameters it goes differently, because we anyway need to
                // store the type of the algo.) 
                var atLeastOne = false;
                for (var i = 0; i < n; i++) {
                    param = nodeOrLinkProperties[i];
                    if (this._addServerNodeOrLinkParam(nodeOrLink, params, param.name, param.defaultValue, layoutName)) {
                        atLeastOne = true;
                    }
                }
                return atLeastOne ? params : null;
            } else {
                return null;
            }
        },
        
        _getServerLayoutGlobalParametersImpl: function(globalProperties, layoutName) {
            if (globalProperties === null) {
                return null;
            }
            return this._getServerGlobalParameters(globalProperties, layoutName);
        },
        
        _getServerLayoutNodeOrLinkParametersImpl: function(nodeOrLink, nodeOrLinkProperties, layoutName) {
            if (nodeOrLinkProperties === null || nodeOrLinkProperties.length === 0) {
                return null;
            }
            return this._getServerNodeOrLinkParameters(nodeOrLink, nodeOrLinkProperties, layoutName);
        }
    };
    
	var markServerSideExtended = function(instance) {
        lang.extend(instance.constructor, commonLayoutExtension);
    };
	
    var extendLayout = function(layout) {
        if (layout && !isServerSideExtended(layout)) {
            markServerSideExtended(layout);
			/*
            if (layoutExtensions[layout.declaredClass] === undefined) {
                R.error("UnsupportedAlgorithm", layout);
            } else {
                dojo.extend(layout.constructor, layoutExtensions[layout.declaredClass]);
            }
            */
			var layoutClass = layout.constructor;
			var id = layout.declaredClass.split('.')[2];
			lang.extend(layoutClass, {
				id: id,
				
				getServerLayoutGlobalParameters: function(){
					var globalProperties = layoutClass._getGlobalProperties();
					return this._getServerLayoutGlobalParametersImpl(globalProperties, id);
				},
				
				getServerLayoutNodeParameters: function(node){
					var nodeProperties = layoutClass._getNodeProperties();
					return this._getServerLayoutNodeOrLinkParametersImpl(node, nodeProperties, id);
				},
				
				getServerLayoutLinkParameters: function(link){
					var linkProperties = layoutClass._getLinkProperties();
					return this._getServerLayoutNodeOrLinkParametersImpl(link, linkProperties, id);
				}
			});
        }
    };
    
	// [Eric] moved here from GraphUtil.js, to avoid a dependency from GraphUtil to graphlayout.
	var foldGraphModel = function (e,ps,folders,scope,stopRecursionAtCollapsedSub) {
		//
		//	summary:
		//		Graph model data structure fold function. --Functional Programming--
		//
		//	description:
		//		Recurses a graph layout model offering callbacks to the user at each structural joint. In addition
		//		to the standard folder functions for each kind of entity, this function supports
		//		a state that is built forward on composite nodes [ for processing root-to-leaf instead
		//		of only folding leaf-to-root ].
		//      Also, it allows optionally to stop the recursion at the level of collapsed subgraphs,
		//      which are treated as a node.
		//
		//	types:
		//		G == Graph layout model (subclass of ibm_ilog.graphlayout.AbstractGraphLayoutModel)
		//		FG == folded graph layout model
		//		FC == folded child collection
		//		ST == forward-built state
		//
		//	e:  /*G*/
		//		The graph layout model (subclass of ibm_ilog.graphlayout.AbstractGraphLayoutModel) to recurse
		//
		//	ps: /*ST*/
		//		the initial parent state
		//
		//	folders: {
		//
		//		graph: function( ST, ST, G, FG ){ return FG; },
		//			Fold a graph layout model (ibm_ilog.graphlayout.AbstractGraphLayoutModel)
		//
		//		group: function( ST, ST, G, FG ){ return FG; },
		//			Fold a Group
		//
		//		sub:   function( ST, ST, G, FG ){ return FG; },
		//			Fold a Subgraph (receives folded inner Graph)
		//
		//		node:  function( ST, G ){ return FG; },
		//			Fold a Node
		//
		//		link:  function( ST, G ){ return FG; },
		//			Fold a Group node
		//
		//		other: function( ST, G ){ return FG; },
		//			Fold an unknown node (eventual gfx.Rects, etc.)
		//
		//		child: function( ST, FC, FG ){ return FC; },
		//			Fold a folded AbstractGraphLayoutModel FG into a folded child-collection FC, returning the new collection
		//
		//		cBase: FC
		//			The initially empty folded child collection (constant)
		//
		//		accSubgraph: function( ST, G ){ return ST; }
		//			The forward-state accumulator, builds a new ST given a newly encountered G
		//
		//		accGraph: function( ST, G ){ return ST; }
		//			The forward-state accumulator, builds a new ST given a newly encountered G
		//
		//		accGroup: function( ST, G ){ return ST; }
		//			The forward-state accumulator, builds a new ST given a newly encountered G
		//
		//	}
		//
		//  stopRecursionAtCollapsedSub: 
		//      If true, the recursion stops at the level of collapsed subgraphs, which are
		//      treated as a node. 
		//
		scope = scope || win.global;
	
		var foldChildren = function(c,ns,stopRecursionAtCollapsedSub) {
			return df.foldl(c,
				function(z,j){
					return folders.child.call(scope,ns,z,foldGraphModel(j,ns,folders,scope,stopRecursionAtCollapsedSub));
				},folders.cBase);
		};
	
		if(e._isIBMDiagramSubgraph) { 
	   		if (stopRecursionAtCollapsedSub && e.isCollapsed()) {
	     		return folders.node.call(scope,ps,e);
	   		} else {
				var ns = folders.accSubgraph.call(scope,ps,e); 
				return folders.sub.call(scope,ps,ns,e,foldGraphModel(new GraphAdapter(e.getGraph()),ns,folders,scope,stopRecursionAtCollapsedSub));	   	
			} 
		}
		else if(e._isIBMDiagramNode)     { return folders.node.call(scope,ps,e); }
		else if(e._isIBMDiagramLink)     { return folders.link.call(scope,ps,e); }
		else if(e._isIBMDiagramGraph)    { var ns = folders.accGraph.call(scope,ps,e); 
	                                             return folders.graph.call(scope,ps,ns,e,foldChildren(e.children,ns,stopRecursionAtCollapsedSub)); }
    	else if(e instanceof GraphAdapter)    { var ns = folders.accGraph.call(scope,ps,e); 
	                                             return folders.graph.call(scope,ps,ns,e,foldChildren(e.getNodesAndAllLinks(),ns,stopRecursionAtCollapsedSub)); }												 
		else if(e instanceof gfx.Group)            { var ns = folders.accGroup.call(scope,ps,e); 
	                                             return folders.group.call(scope,ps,ns,e,foldChildren(e.children,ns,stopRecursionAtCollapsedSub)); }
		else { return folders.other.call(scope,ps,e); }
	};

    var _AsynchronousLayout =
	declare('ibm_ilog.diagram.graphlayout._AsynchronousLayout', null, {
        //
        //	summary:
        //		This class executes a layout algorithm asynchronously, and is the base class for the
        //		ServerSideLayout and WebWorkerLayout classes.
        //		
        //		An _AsynchronousLayout object is constructed with a Graph object.
        //		To execute a layout, the user must select the algorithm with the standard 
        //		client-side GraphLayout API:
        //
        //		graph.setNodeLayout(x);
        //		graph.setLinkLayout(y);
        //	
        //		After this, the _AsynchronousLayout object can be used to execute these 
        //		algorithms on the server or in a web worker by calling:
        //
        //		asynchronousLayout.layout();
        //
        //		This will obtain the currently configured layouts on the graph object,
        //		including optional settings for laying out internal subgraphs, gather
        //		their configured parameters and requesting the equivalent layout on the
        //		server or in the web worker.
        //
        //		Each time a layout is requested, the graph and the layout settings are
        //		serialized into a JSON object sent in the request.
        //
        //		The layout() method returns a dojo.Deferred which is signaled after the
        //		execution is complete.
        
        _localParametersEnabled: true,
        
        _running: false,
        
        _debugPrefix: "_AsynchronousLayout: ",
        
        constructor: function( /*Graph*/graph) {
            //
            //	summary: Creates and configures an AsynchronousLayout object.
            //	
            //  graph: Graph
            //		The graph to be laid out.
            //
            this._graph = graph;
            this._graphModel = new GraphAdapter(graph);
        },
        
        setLocalParametersEnabled: function(enabled) {
            //	summary:
            //		Sets whether the local (per node and per link) layout parameters 
            //		are sent to the server-side layout service or to the web worker.
            //	enable: Boolean
            //		'true' to enable the local parameters or 'false' to disable it.
            this._localParametersEnabled = enabled === true ? true : false;
        },
        
        isLocalParametersEnabled: function() {
            //	summary:
            //		Returns 'true' if the local (per node and per link) layout parameters are enabled.
            //	returns:
            //		'true' if the local (per node and per link) layout parameters are enabled. 
            return this._localParametersEnabled; // Boolean
        },
        
        _serializeMatrix: function(matrix) {
            //
            //	summary: Serializes a dojox.gfx.matrix in the JSON format needed for the protocol.
            //	
            return '[' +
            			matrix.xx + ',' + matrix.xy + ',' +
            			matrix.yx + ',' + matrix.yy + ',' +
            			matrix.dx + ',' + matrix.dy + 
					']';
        },
        
        _serializeBounds: function(rect) {
            //
            //	summary: Serializes a rectangle in the JSON format needed for the protocol.
            //	
            return rect === null ? 'null' : '[' +
            	rect.x + ',' + rect.y + ',' +
            	rect.width + ',' + rect.height +
				']';
        },
        
        _serializePoint: function(point) {
            //
            //	summary: Serializes a point in the JSON format needed for the protocol.
            //	
            return point === null ? 'null' : '[' +
            		point.x + ',' + point.y + ']';
        },
        
        _serializePoints: function(points) {
            //
            //	summary: Serializes a list of points in the JSON format needed for the protocol.
            //	
            var result = '[';
            var n = points.length;
            for (var i = 0; i < n; i++) {
                result += (i ? ',' : '') + this._serializePoint(points[i]);
            }
            return result + ']';
        },
        
        _serializeNode: function(node) {
            //
            //	summary: Serializes a node in the JSON format needed for the protocol.
            //	
            return '{' +
				'"id":"' + node.getId() + '",' +
            	'"b":' + this._serializeBounds(node.getBounds()) +
            	this._serializeLayoutNodeOrLinkParameters(node, false) +
            	'}';
        },
        
        _serializeLink: function(link) {
            //
            //	summary: Serializes a link in the JSON format needed for the protocol.
            //	
            var points = link.getPoints();
            var to = points.pop();
            var from = points.shift();
            
            var pinnedAtStartNode = this._graphModel.hasPinnedConnectionPoint(link, true);
            var pinnedAtEndNode = this._graphModel.hasPinnedConnectionPoint(link, false);
            
            return '{' +
            	'"id":"' + link.getId() + '",' +
            	'"f":"' + this._graphModel.getFrom(link).getId() + '",' +
            	'"t":"' + this._graphModel.getTo(link).getId() + '",' +
            	'"fp":' + this._serializePoint(from) + ',' +
            	'"tp":' + this._serializePoint(to) + ',' +
            	'"ip":' + this._serializePoints(points) + "," +
            	'"w":' + link.getStrokeWidth() + 
				(pinnedAtStartNode ? ("," + '"sp":true') : "") +
            	(pinnedAtEndNode ? ("," + '"ep":true') : "") +
            	this._serializeLayoutNodeOrLinkParameters(link, true) +
            	'}';
        },
        
        _serializeModel: function(graph) {
            //
            //	summary: Serializes the Graph in the JSON format needed for the protocol.		
            //
            
            var acc = function(s, ge) {
                return {
                    links: [],
                    nodes: []
                }; // new s for folding children
            };
            
            var accGroup = function(s, ge) {
                return s;
            };
            
            var fsub = function(s, ns, sg, fc) {
                var sgg = sg.getGraph();
                // The local bounds of the graph inside the subgraph
                var b = this._serializeBounds(sg.getBounds());
                
                // The local bounds of the graph inside the subgraph
                var sggBB = sgg.getLocalBoundingBox();
                
                var transformToParent = null;
				 
                // The bounds of the graph inside the subgraph
                // (to allow the server-side to determine the subgraph margins) 
                var sgt = sg.getTransform();
                if (sgt) {
                    sggBB = sgt.transformRectangle(sggBB);
										transformToParent = this._serializeMatrix(sgt);
                }
                
                var gb = this._serializeBounds(sggBB);
                              
                var serializedSub = '{' +
                	'"id":"' + sg.getId() + '",' +
                	this._serializeLayoutGlobalParameters(sgg) +
                	'"b":' + b + ',' + '"gb":' + gb + ',' +
										(transformToParent ? 
                	  ('"m":' + transformToParent + ',') : '') +
                	'"nodes":[' + fc.nodes.join(',') + '],' +
                	'"links":[' + fc.links.join(',') + ']' +
                	this._serializeLayoutNodeOrLinkParameters(sg, false) +
                	'}';
                s.nodes.push(serializedSub);
            };
            
            var fgraph = function(s, ns, ge, fc) {
                return ns;
            };
            
            var flink = function(s, ge) {
            	if (ge.getStartNode() !== null && ge.getEndNode() !== null) {
								s.links.push(this._serializeLink(ge)); // put in s
							}
              // else it is a pending link which must be filtered out
              // from the graph sent to the server-side layout
            };
            
            var fnode = function(s, ge) {
                s.nodes.push(this._serializeNode(ge)); // put in s
            };
            
            var ignore = function() {
            };
            
            var pass = function(s, ns, ge, fg) {
                return fg;
            };
            
            var sg = foldGraphModel(this._graphModel, null, gu.folders({
                graph: fgraph,
                sub: fsub,
                node: fnode,
                link: flink,
                accGraph: acc,
                accSubgraph: acc,
                accGroup: accGroup
            }), this, true /*stopRecursionAtCollapsedSubgraph*/);
            
            return '{' +
            this._serializeLayoutGlobalParameters(graph) +
            	'"nodes":[' + sg.nodes.join(',') + '],' +
            	'"links":[' + sg.links.join(',') + ']' +
            	'}';
        },
        
        _serializeLayoutGlobalParameters: function(graph) {
            var nodeLayout = graph._getActualNodeLayout();
            var linkLayout = graph._getActualLinkLayout();
            
            extendLayout(nodeLayout);
            extendLayout(linkLayout);
            return (nodeLayout ? ('"nodeLayout":' + 
										nodeLayout.getLayoutGlobalDescriptor() + ',') : "") +
            	(linkLayout ? ('"linkLayout":' + 
								linkLayout.getLayoutGlobalDescriptor() + ',') : "");
        },
        
        _serializeLayoutNodeOrLinkParameters: function(nodeOrLink, isLink) {
            if (!this.isLocalParametersEnabled()) {
                return '';
            }
            var graph = nodeOrLink.getParent();
            var nodeLayout = graph._getActualNodeLayout();
            var linkLayout = graph._getActualLinkLayout();
            var nodeLayoutNodeOrLinkDescriptor = null;
            var linkLayoutNodeOrLinkDescriptor = null;
            if (nodeLayout) {
                extendLayout(nodeLayout);
                nodeLayoutNodeOrLinkDescriptor = isLink ? 
					nodeLayout.getLayoutLinkDescriptor(nodeOrLink) : 
					nodeLayout.getLayoutNodeDescriptor(nodeOrLink);
            }
            if (linkLayout) {
                extendLayout(linkLayout);
                linkLayoutNodeOrLinkDescriptor = isLink ? 
					linkLayout.getLayoutLinkDescriptor(nodeOrLink) : 
					linkLayout.getLayoutNodeDescriptor(nodeOrLink);
            }
            return (nodeLayoutNodeOrLinkDescriptor !== null ? 
					(',"parentNodeLayout":' + nodeLayoutNodeOrLinkDescriptor) : "") +
            	(linkLayoutNodeOrLinkDescriptor !== null ? 
					(',"parentLinkLayout":' + linkLayoutNodeOrLinkDescriptor) : "");
        },
        
        layout: function() {
            //        	
            //	summary:
            //		Requests the layout and applies the results.
            //	returns:
            //		a dojo.Deferred to signal when the process finishes.
            //
            
            var graph = this._graphModel.getGraph();
            
			// Analysis of dojo.require situation:
			// We only need to execute SwimLane._beforeLayout in case:
			// 1) A instance of HierarchicalLayout is installed by the user on the graph, and
			// 2) An instance of SwimLane is used as subgraph.
			// Hence, if these 2 classes are undefined, we can safely skip it.
			// No dojo.require needed.
						
			// AMD conversion node: we now call require("classname") to test if the class is loaded.
			
			var HierarchicalLayout = _require("ibm_ilog/graphlayout/hierarchical/HierarchicalLayout");
			var HierarchicalNodeGroup = _require("ibm_ilog/graphlayout/hierarchical/HierarchicalNodeGroup");
			var HierarchicalSwimLaneConstraint = _require("ibm_ilog/graphlayout/hierarchical/HierarchicalSwimLaneConstraint");
			var Direction = _require("ibm_ilog/graphlayout/Direction");
			var SwimLane = _require("../SwimLane");
			if (HierarchicalLayout && HierarchicalNodeGroup && SwimLane &&
				graph._nodeLayout && graph._nodeLayout instanceof HierarchicalLayout) {
				if (config.useGfxLayout) {
					gfxlayout.Engine.layout();
				}
				this._swimLanes = SwimLane._beforeLayout(graph, graph._nodeLayout, Direction, HierarchicalNodeGroup, HierarchicalSwimLaneConstraint);
			}
            
            var data = this._serializeModel(graph);
            
            this._preLayoutDeferred = new Deferred();
            this._layoutDeferred = new Deferred();
            
            this._running = true;
            this._start(data);
            
            // console.log(this._debugPrefix + "Sent");
			
            this._preLayout();
            
            return this._layoutDeferred; // dojo.Deferred
        },
        
        _preLayout: function() {
            //
            //	summary: Begins preparation for receiving the layout results in parallel
            //	         with the request sent to the server or the web worker.
            //	
            this._nodeIndex = new Dictionary();
            this._linkIndex = new Dictionary();
            
            foldGraphModel(this._graphModel, null, gu.folders({
                node: function(s, n) {
                    this._nodeIndex.add(n.getId(), n);
                },
                sub: function(s, ns, n, fc) {
                    this._nodeIndex.add(n.getId(), n);
                },
                link: function(s, l) {
                    this._linkIndex.add(l.getId(), l);
                }
            }), this);
            
            this._preLayoutDeferred.callback();
        },
        
        _layoutGraph: function(laidOutGraph) {
        
		    /*
            var logTr = function(ge) {
                var tr = ge.getTransform();
                console.log("\"", ge.toString(), tr ? ("\" (" + tr.dx + "," + tr.dy + ")") : 
							"", ge._isIBMDiagramSubgraph ? g.printRect(ge.getGraph().getBoundingBox()) : "");
            };
            */
			
            //
            //	summary: Applies the layout result.
            //	
            var gm = null, ls = this._linkIndex, ns = this._nodeIndex;
            var graph;
            
            if (laidOutGraph.id) {
                graph = ns.item(laidOutGraph.id).getGraph();
            } else {
                graph = this._graph;
            }
            
            var adapter = new GraphAdapter(graph);
            
            var getRect = function(field) {
                return field ? {
                    x: field[0],
                    y: field[1],
                    width: field[2],
                    height: field[3]
                } : null;
            };
			
            var maybeRect = function(field) {
                return field ? getRect(field) : null;
            };
            
            if (laidOutGraph.swimLaneCalcBBoxes) {
                // HierarchicalLayout.getConstraints returns the constraints in their
                // *reversed* insertion order. Thanks to that, we can rely on the fact that the 
                // calculated bboxes of swimlane constraints stored by the server-side
                // layout in JSON are ordered similarly to the client-side constraints. 
                var constraints = graph.getNodeLayout().getConstraints();
                array.forEach(laidOutGraph.swimLaneCalcBBoxes, function(calcBBox) {
                    var constraint = null;
					var HierarchicalSwimLaneConstraint = _require("ibm_ilog/graphlayout/hierarchical/HierarchicalSwimLaneConstraint");
                    while (constraints.hasNext() &&
                    	   (constraint === null ||
						    // No dojo.require needed. If the class is undefined, the constraint can't be
						    // of this type. 
                    		!(HierarchicalSwimLaneConstraint &&
							  constraint instanceof HierarchicalSwimLaneConstraint))) {
                        // skip any constraint which is not a swimlane constraint
                        constraint = constraints.next();
                    }
                    if (constraint !== null) { // we found a swimlane constraint
                        var bbox = maybeRect(calcBBox);
                        constraint.setCalcBoundingBox(bbox);
                    }
                }, this);
            }
            
            array.forEach(laidOutGraph.nodes, function(laidOutNode) {
                var n = ns.item(laidOutNode.id);
                if (n) {
                    if (laidOutNode.nodes) {
                        // FIRST: lay out subgraph contents first to get final content bounds
                        this._layoutGraph(laidOutNode);
                        
                        // ALSO: we need to update internal links to have correct bounds:
                        Batch.endBatch();
                    }
                    adapter.moveNode(n, laidOutNode.b[0], laidOutNode.b[1]);

                    // logTr(n);
                }
            }, this);
            
            var getPoint = function(field) {
                return field ? {
                    x: field[0],
                    y: field[1]
                } : null;
            };
			
            var maybePoint = function(field) {
                return field ? getPoint(field) : null;
            };
            
            array.forEach(laidOutGraph.links, function(laidOutLink) {
                var l = ls.item(laidOutLink.id);
                
                var fp = maybePoint(laidOutLink.fp);
                var tp = maybePoint(laidOutLink.tp);
                var ip = df.map(laidOutLink.ip || [], getPoint);
                
				// Analysis of dojo.require situation:
				// ibm_ilog.graphlayout.ReshapeLinkStyle and ibm_ilog.graphlayout.ReshapeLinkMode are
				// both defined in AbstractGraphLayoutModel, which is the parent class of 
				// GraphAdapter. We have already a dojo.require for GraphAdapter. Hence, 
				// no need of dojo.require for ibm_ilog.graphlayout.ReshapeLinkStyle and 
				// ibm_ilog.graphlayout.ReshapeLinkMode.
                adapter.reshapeLink(l, GraphModelUtil.ReshapeLinkStyle.POLYLINE, 
									fp, GraphModelUtil.ReshapeLinkMode.MOVE_AND_CLIP, ip, 0, ip.length, 
									tp, GraphModelUtil.ReshapeLinkMode.MOVE_AND_CLIP);
            }, this);
        },
        
        _onComplete: function(data) {
            //
            //	summary: The server or the web worker has returned the results of the layout. 
            //           The receiver is about to apply the results to the Graph object.
            //           When ready, the deferred object returned by layout() is signaled.
            //	
            
            // console.log(this._debugPrefix + "Response received, applying...");
            // console.dir(this._laidout);
            
            this._layoutGraph(this._laidout);
            
            if (this._swimLanes) {
                Batch.endBatch();
                var graph = this._graphModel.getGraph();
				var SwimLane = _require("../SwimLane");
                SwimLane._afterLayout(graph, graph._nodeLayout, this._swimLanes);
                this._swimLanes = null; // cleanup for gc
            }
            
            this._running = false;
            this._layoutDeferred.callback();
            
            // console.log(this._debugPrefix + "Response applied.");
        },
        
        _onError: function(error) {
            //
            //	summary: A error occurred while trying to execute the layout algorithm. 
            //	
            
            // console.log(this._debugPrefix + "Error. ", error.responseText);
            
            this._running = false;
            this._layoutDeferred.errback(error);
        },
        
        stop: function() {
            // summary:
            //		Stops the execution of the layout.
            // description:
            //		If a graph layout is currently running,	calling this method will stop 
			// 		the graph layout execution.
            //		No result is applied and the graph stays unchanged.
            
            if (this._running) {
                this._stop();
                this._running = false;
            }
        },
        
        isRunning: function() {
            // summary:
            //		Returns true if the layout is currently running.
            return this._running;
        },
        
        _start: function(data) {
            // summary:
            //		Starts the asynchronous layout. This method must be redefined in subclasses.
        },
        
        _stop: function() {
            // summary:
            //		Stops the current layout. This method must be redefined in subclasses.
        }
    });
    
/*=====
var _AsynchronousLayout = ibm_ilog.diagram.graphlayout._AsynchronousLayout;
=====*/

	var ServerSideLayout =
    declare('ibm_ilog.diagram.graphlayout.ServerSideLayout', _AsynchronousLayout, {
        //
        //	summary:
        //		This class executes a layout algorithm on a server. 
        //		
        //		A ServerSideLayout object is constructed with the Graph object and the
        //		URL where the layout service is located.
        //		To execute a layout, the user must select the algorithm with the standard 
        //		client-side GraphLayout API:
        //
        //		graph.setNodeLayout(x);
        //		graph.setLinkLayout(y);
        //	
        //		After this, the ServerSideLayout object can be used to execute these 
        //		algorithms on the server by calling:
        //
        //		serverSideLayout.layout();
        //
        //		This will obtain the currently configured layouts on the graph object,
        //		including optional settings for laying out internal subgraphs, gather
        //		their configured parameters and requesting the equivalent layout on the
        //		server.
        //
        //		Each time a layout is requested, the graph and the layout settings are
        //		serialized into a JSON object sent in the request.
        //
        //		The layout() method returns a dojo.Deferred which is signaled after the
        //		execution is complete.
        
        //	_url: string
        //		The URL where the layout service is located
        _url: "/dojo-diagrammer-server/graphlayout",
        
        _timeout: undefined,
        
        _debugPrefix: "ServerSideLayout: ",
        
        constructor: function(/*Graph*/graph, /*string*/url) {
            //
            //	summary: Creates and configures a ServerSideLayout object.
            //	
            //  graph: Graph
            //		The graph to be laid out.
            //	url: String
            //		The URL where the server is located.
            //
            this._url = url || this._url;
        },
        
        setUrl: function(url) {
            //	summary:
            //		Set the location of the layout service at the server.
            //  url: String
            //		The URL of the layout service at the server.
            //   
            this._url = url;
        },
        
        getUrl: function() {
            //	summary:
            //		Returns the location of the layout service at the server.
            //  returns:
            //		The location of the layout service at the server.
            return this._url; // String
        },
        
        setTimeout: function(msTimeout) {
            //	summary:
            //		Sets the timeout for the request sent to the server. The unit is milliseconds.
            //  msTimeout: int
            //		The timeout (in milliseconds) for the request sent to the server.
            this._timeout = msTimeout;
        },
        
        getTimeout: function() {
            //	summary:
            //		Returns the current timeout for the request sent to the server.
            //  returns:
            //		The timeout (in milliseconds) for the request sent to the server.
            return this._timeout; // int
        },
        
        _start: function(data) {
            var layoutModelKW = {
            
                url: this._url,
                
                postData: data,
                
                headers: lang.mixin({
                    "Content-Type": "application/json"
                }, {}),
                
                load: lang.hitch(this, function(response, ioArgs) {
                    this._laidout = json.fromJson(response);
                    this._preLayoutDeferred.addCallback(lang.hitch(this, "_onComplete"));
                }),
                
                error: lang.hitch(this, function(data, ioArgs) {
                    if (data.dojoType != 'cancel') { 
                        this._onError(data);
					}
                })
            };
            
            if (this._timeout !== undefined) {
                layoutModelKW.timeout = this._timeout;
            }
            
            // console.log(this._debugPrefix + "Sending xhrPost");
            // console.dir(json.fromJson(data));
			
            this._postDeferred = xhr.post(layoutModelKW);
        },
        
        _stop: function() {
            if (this._postDeferred && this._postDeferred.cancel) { 
                this._postDeferred.cancel();
			}
        }
    });
   
   ServerSideLayout._AsynchronousLayout = _AsynchronousLayout;
   
   return ServerSideLayout;
});
