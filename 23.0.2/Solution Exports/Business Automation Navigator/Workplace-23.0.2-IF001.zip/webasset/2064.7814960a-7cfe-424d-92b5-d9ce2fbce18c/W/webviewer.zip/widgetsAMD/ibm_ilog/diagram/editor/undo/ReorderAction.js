/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"./Action",
"./UndoActionList"
], function(
declare,
lang,
array,
Action,
UndoActionList
){

/*=====
var Action = ibm_ilog.diagram.editor.undo.Action;
=====*/

	var ReorderAction =
	declare("ibm_ilog.diagram.editor.undo.ReorderAction", [Action], {
		//
		//	summary:
		//		this action undo / redo a reordering action.
		_newElementList: null,
		_oldElementList: null,
	
	constructor:function(){
		//	
		// summary:
		//		creates a new instance, setting the corresponding label
		this._label = UndoActionList.Reorder;
		this.initialize(lang.hitch(this,this._undoFunction),lang.hitch(this,this._redoFunction));
	},
	setNewElementList: function(elementList){
		//	
		// summary:
		//		sets the new element list
		this._newElementList = [];
		array.forEach(elementList,function(ge){this._newElementList.push(ge.getId());},this);
	},
	setOldElementList: function(elementList){
		//	
		// summary:
		//		sets the old element list
		this._oldElementList = [];
		array.forEach(elementList,function(ge){this._oldElementList.push(ge.getId());},this);
	},
	_undoFunction: function(){
		var elements = this._getList(this._oldElementList);
		ReorderAction.EditingUtils.setChildrenOrder(elements);
	},
	_redoFunction: function(){
		var elements = this._getList(this._newElementList);
		ReorderAction.EditingUtils.setChildrenOrder(elements);
	},
	_getList: function(elements){
		var newElements = [];
		array.forEach(elements, lang.hitch(this, function(item){
			var newItem = this.getUndoManager().getRegisteredGraphElement(item);
			newElements.push(newItem);
		}));
		return newElements;
	}
	});
	
	return ReorderAction;
	
});
