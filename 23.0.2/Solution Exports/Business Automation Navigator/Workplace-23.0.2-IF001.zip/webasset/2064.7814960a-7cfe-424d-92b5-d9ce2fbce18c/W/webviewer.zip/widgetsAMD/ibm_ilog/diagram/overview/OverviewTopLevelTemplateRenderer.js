/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"dojo/_base/config",
"dojox/gfx/matrix",
"../templates/templates",
"./OverviewRenderer",
"../util/GraphUtil"
],
function(
declare,
lang,
array,
config,
m,
templates,
OverviewRenderer,
gu
){

/*=====
var OverviewRenderer = ibm_ilog.diagram.overview.OverviewRenderer;
=====*/

var OverviewTopLevelTemplateRenderer =
declare('ibm_ilog.diagram.overview.OverviewTopLevelTemplateRenderer', OverviewRenderer, {

	//
	//	summary:
	//		Uses custom templates to generate the overview image.
	//
	//	description:
	//		Iterates the given graph and reinstantiates the elements in the graph 
	//		with new templates. If no templates are specified, default ones are used.
	//	
	
	//
	//	node:  Function
	//		The node template function for the overview.
	//
	node: templates.defaultOverviewNodeTemplate,
	
	//
	//	link:  Function
	//		The link template function for the overview.
	//
	link: templates.defaultOverviewLinkTemplate,

	//
	//	expandedSubgraph:  Function
	//		The expanded subgraph template function for the overview.
	//
	expandedSubgraph: templates.defaultOverviewExpandedSubgraphTemplate,

	//
	//	collapsedSubgraph:  Function
	//		The collapsed subgraph template function for the overview.
	//
	collapsedSubgraph: templates.defaultOverviewCollapsedSubgraphTemplate,

	//
	//	stripTexts: Boolean
	//		Optional removal of the texts from the generated shapes.
	//
	stripTexts: true,

	constructor: function( kwArgs ) {
		if(kwArgs) {
			lang.mixin(this,kwArgs);
		}
		
		this._toFunction("node");
		this._toFunction("link");
		this._toFunction("expandedSubgraph");
		this._toFunction("collapsedSubgraph");

	},
	
	_toFunction: function(name) {
		if(typeof this[name] != "function") {
			var value = this[name];
			this[name] = function(){
				return value;
			};
		}
	},

	templateFor: function(ge) {
		return gu.dispatchClass(ge,arguments,this,{
			N:this.node,
			S:function(ge) {
				return ge.isCollapsed()?this.collapsedSubgraph():this.expandedSubgraph();
			},
      L:this.link
		});
	},
	
	renderGraphElement: function(ge) {
		
		var template = this.templateFor(ge);

		var ng = this._output.createGroup();
		
		if(ge.getTransform){
			var t = ge.getTransform();
			if(t) {
				ng.setTransform(t);
			}
		}

		var r = ge.shallowInstantiateAt(ng,template);
		
		if(!ge._isIBMDiagramLink){
			var oldBB = r.getLocalBoundingBox();
			var newBB = ge.getLocalBoundingBox();
		
			if(config.useGfxLayout) {
				r.layout(newBB);
			} else {
				r.applyLeftTransform( m.createFromRectangles( oldBB, newBB ));
			}
		} else {
    	ge.layoutShape(r);
		}
	},

	render: function( graph, /*dojox.gfx.Group*/ output ) {
		
		graph = graph || this.graph;
		
		this._output = output;
		
		array.forEach(graph.children,this.renderGraphElement,this);

	}
});

return OverviewTopLevelTemplateRenderer;

});
