/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"../main",
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"dojo/_base/sniff",
"dojo/_base/connect",
"dojo/dom-construct",
"dojo/dom-attr",
"dojo/dom-geometry",
"dijit/_Widget",
"dijit/registry",
"dojox/gfx",
"./Overview",
"./OverviewRenderer",
"./OverviewPanInteractor",
"./OverviewZoomInteractor",
"./OverviewTemplateRenderer",
"../interactors/InteractorManager",
"../util/DeferredInitialization",
"../util/ErrorReporter",
"../util/Geometry"
],
function(
iid,
declare,
lang,
array,
has,
connect,
domConstruct,
domAttr,
domGeometry,
_Widget,
registry,
gfx,
Overview,
OverviewRenderer,
OverviewPanInteractor,
OverviewZoomInteractor,
OverviewTemplateRenderer,
InteractorManager,
DeferredInitialization,
R,
g
){

var Size = g.Size;

/*=====
var DeferredInitialization = ibm_ilog.diagram.util.DeferredInitialization;
=====*/

var OverviewWidget =
declare('ibm_ilog.diagram.overview.OverviewWidget', [_Widget, DeferredInitialization],
{

	// summary:
	//		A widget that shows the overview of a Diagram.
	//
	// markup example:
	// |	<div dojoType="ibm_ilog.diagram.widget.Diagram" jsId="myDiagram"></div>
	// |	<div dojoType="ibm_ilog.diagram.overview.OverviewWidget" diagram="myDiagram"></div>
	//
	// markup example (custom renderer):
	//
	// |	<div dojoType="ibm_ilog.diagram.widget.Diagram" jsId="myDiagram"></div>
	// |	<div dojoType="ibm_ilog.diagram.overview.OverviewTemplateRenderer" graph="myDiagram.getGraph()" node="myNodeTemplate" jsId="renderer"></div>
	// |	<div dojoType="ibm_ilog.diagram.overview.OverviewWidget" diagram="myDiagram" renderer="renderer"></div>
	//
	
	//
	//	diagram: ibm_ilog.diagram.widget.Diagram
	//
	diagram: null,

	//
	//	renderer: ibm_ilog.diagram.overview.OverviewRenderer
	//		The renderer used for generating the overview image.
	//
	renderer: null,

	//
	//	viewRectFill: String|Object
	//		The fill of the rectangle used to represent the view rectangle
	//
	viewRectFill: null,
	
	//
	//	viewRectStroke: String|Object
	//		The stroke of the rectangle used to represent the view rectangle
	//
	viewRectStroke: null,

	//	
	//	_diagram: [private] ibm_ilog.diagram.widget.Diagram
	//		The diagram Widget
	//
	_diagram: null,
	
	//
	//	_overview: [private] ibm_ilog.diagram.overview.Overview
	//		The overview displayed in the widget surface
	//
	_overview: null,
	
  //
	//	_overviewGroup: [private] dojox.gfx.Group
	//		The group where the overview is placed in the surface
	//
	_overviewGroup: null,

	//
	//	_surface: dojox.gfx.Surface
	//		The surface
	//
	_surface: null,
	
    // ========================================================================================================
    //
    // WIDGET LIFECYCLE:
    //
    //	The following group methods define the process of construction, initialization, deinitialization and 
    //	related. These are mostly hooks into the Dijit framework.
    //

	templateString:  "<div dojoAttachPoint='canvasNode' style='overflow:hidden'></div>",

	buildRendering: function(){
		// there are no variables in the template so we can cache the DOM tree
		var node = domConstruct.toDom(this.templateString);
		if (node.nodeType != 1) {
			throw new Error("Invalid template: " + this.templateString);
		}
		this.domNode = node;
		var nodes = node.getElementsByTagName("*");
		for (var i = -1; i < nodes.length; i++) {
			var n = (i == -1) ? node : nodes[i];
			var attachPoint = n.getAttribute("dojoAttachPoint");
			this[attachPoint] = n;
		}
		
		//this.inherited(arguments);
		
		this._fillContent(this.srcNodeRef);
		
	},
	
	_fillContent: function(/*DomNode*/ source){
		// summary:
		//	Relocate source contents to templated container node.
		//	this.containerNode must be able to receive children, or exceptions will be thrown.
		// tags:
		//	protected
		var dest = this.containerNode;
		if (source && dest) {
			while (source.hasChildNodes()) {
				dest.appendChild(source.firstChild);
			}
		}
	},
	
	postMixInProperties: function() {
	
		this._beginInit();

    	this.inherited(arguments);

    	if(this.diagram._isIBMDiagramDiagram) {
    		this._diagram = this.diagram;
		} else if( (typeof (this.diagram)) == "string") {
			this._diagram = registry.byId(this.diagram);
		} else if(this.diagram instanceof HTMLElement) {
	    	this._diagram = registry.byNode(this.diagram);
		} else {
			R.error("OverviewDiagramMissing",this.diagram);
		}
    	
	},
	
	postCreate: function() {
	
		this.inherited(arguments);

    // compute initial size
    var csz = this._computeSize();
	
    if(!has("ie")) {
			this._surface = gfx.createSurface(this.canvasNode,csz.width+"px",csz.height+"px");
		} else {
			this._surface = gfx.createSurface(this.canvasNode,csz.width,csz.height);
		}        

		this._surface.whenLoaded(this,function(){

    	// create a group for hosting the overview
      this._overviewGroup = this._surface.createGroup();
		        
			this._diagram.whenLoaded(lang.hitch(this,function(){

			    // create a defaut renderer if the user has not defined one
	        this.renderer = this.renderer || new OverviewTemplateRenderer();
		        
			    // create an overview for our viewport with the just constructed arguments
	        this._overview = new Overview(this._diagram.getViewport(),this._diagram.getGraph(),this.renderer,this._overviewGroup,csz);
	    	
	        this._overview.setInteractorManager(this.diagram.getInteractorManager());
	        
	        if(this.viewRectStroke) {
	        	this._overview.setViewRectStroke(this.viewRectStroke);
	        }
	        
	        if(this.viewRectFill) {
	        	this._overview.setViewRectFill(this.viewRectFill);
	        }
	        
			    // create an interactor manager for the overview interactors
		    	this._interactors = new InteractorManager();
		    	
			    // create the pan interactor (which handles pan and cenderAt)
		    	this._interactors.add("pan",new OverviewPanInteractor().initialize(this._diagram.getViewport(),this._overview,this._surface));
	
		    	// create the zoom interactor
		    	this._interactors.add("zoom",new OverviewZoomInteractor().initialize(this._diagram.getViewport(),this._overview,this._surface));
	
		    	this._setupInteractors(["pan","zoom"]);
		    	
		    	// start the interactors
		    	this._interactors.switchTo("pan","zoom");
				
			    if (has("ie") > 7 && iid.isVml){
					// fix overview interaction issue in ie8 (ie8 document mode)
					var panInter = this._interactors.get("pan"),
						zoomInter = this._interactors.get("zoom");
					this._ie8Handler = [
						connect.connect(this._overview, "__ieBeforeEvtSrcChange", this, function(){
							array.forEach([panInter,zoomInter],function(inter){
								if (inter._state)
									inter._state.leave();
							});
						}),
						connect.connect(this._overview, "__ieAfterEvtSrcChange", this, function(){
							array.forEach([panInter,zoomInter],function(inter){
								if (inter._state)
									inter._state.enter();
							});
						}) 
					];
				}

		    	this._endInit();
	
		    }));
	    });
	},
	
	//
	//  pan: [markup] boolean
	//      enable or disable panning
	//
	pan: true,
	
	_setPanAttr: function( /*Boolean*/b ) {
		if (!this._viewportReady) 
			// at creation time, interactors are initialized in the postCreate stage.
			// Since customSetter are called before postCreate(), skip it in this case.
			return; 
		var old = this._getPanAttr(); // use the getter as the interactor may have been configured directly
		if (old !== b) {
			this.pan = b;
			this._interactors.get('pan').setEnabled(b);
			this._firePropertyChanged('pan', old, b);
		}
		return this;
	},
	
	_getPanAttr: function() {
		return this._viewportReady ? this._interactors.get("pan").getEnabled() : true;
	},
	
	//
	//  constrainPan: [markup] boolean
	//		Constrains view rectangle movements to the overview area
	//
	constrainPan: true,
	
	_setConstrainPanAttr: function( /*Boolean*/b ) {
		if (!this._viewportReady) 
			// at creation time, interactors are initialized in the postCreate stage.
			// Since customSetter are called before postCreate(), skip it in this case.
			return; 
		var old = this._getPanAttr(); // use the getter as the interactor may have been configured directly
		if (old !== b) {
			this.constrainPan = b;
			this._interactors.get('pan').setConstrain(b);
			this._firePropertyChanged('constrainPan', old, b);
		}
		return this;
	},
	
	_getConstrainPanAttr: function() {
		return this._viewportReady ? this._interactors.get("pan").getConstrain() : true;
	},

	
	//
	//  zoom: [markup] boolean
	//      enable or disable zooming
	//
	zoom: true,
	
	_setZoomAttr: function( /*Boolean*/b ) {
		if (!this._viewportReady) 
			// at creation time, interactors are initialized in the postCreate stage.
			// Since customSetter are called before postCreate(), skip it in this case.
			return; 
		var old = this._getZoomAttr();
		if (old !== b) {
			this.zoom = b;
			this._interactors.get("zoom").setEnabled(b);
			this._firePropertyChanged('zoom', old, b);
		}
		return this;
	},
	
	_getZoomAttr: function() {
		return this._viewportReady ? this._interactors.get("zoom").getEnabled() : true;
	},
	
	_setupInteractors: function(ids) {
		array.forEach(ids, function(i) {
			this._interactors.get(i).setEnabled(this[i]);
		}, this);
		
		this._interactors.get("pan").setConstrain(this.constrainPan);
		
	},

	destroy: function() {

		this._interactors.switchTo();
		this._interactors = null;

		this._overview = null;

		this._surface.remove(this._overviewGroup);
		this._overviewGroup = null;

		this._surface.destroy();
		this._surface = null;
		
		if (this._ie8Handler){
			array.forEach(this._ie8Handler, function(l){
				connect.disconnect(l);
			});
		}
        
        this.inherited(arguments);

	},

	resize: function( /*{w:h:}*/ sz ) {
		//
		//	summary:
		//		resize accordingly when our container specifies so
		//
		this.whenLoaded(lang.hitch(this,function(){
			var style = {width:sz.w+"px",height:sz.h+"px"};
			domAttr.set(this.domNode,{"style":style});
			if(!has("ie")) {
				this._surface.setDimensions(style.width,style.height);
			} else {
				this._surface.setDimensions(sz.w,sz.h);
			}
			this._overview.setSize({width:sz.w,height:sz.h});
		}));
	},
	
    // ========================================================================================================

	_computeSize: function() {
		//
		//	summary:
		//		decide what size to use for initializing the overview
		//
		var b = domGeometry.getContentBox(this.domNode);
		var c = this.getParent()?domGeometry.getContentBox(this.getParent().containerNode):{};
		return Size(b.w || c.w || b.h || 256, b.h || c.h || b.w || 256);
	},
	
	getParent: function(){
		// summary:
		//		Returns the parent widget of this widget, assuming the parent
		//		specifies isContainer
		var parent = registry.getEnclosingWidget(this.domNode.parentNode);
		return parent && parent.isContainer ? parent : null;
	},
	
	getDiagram: function() {
		return this._diagram;
	},
	
	setDiagram: function(diagram) {
		if(this._diagram!=diagram) {
			this._diagram = diagram;
			var o = this._overview;
			if(o){
				var enabled = o.isEnabled(); 
				o.setEnabled(false);
				o.setContent(diagram.getGraph());
				o.setViewport(diagram.getViewport());
				o.setEnabled(enabled);
				o.generateContent();
			}
		}
	},

	getOverview: function() {
		return this._overview;
	},	

	getRenderer: function() {
		return this.renderer;
	},
	
	setRenderer: function(r) {
		this._overview.setRenderer(r);
		this._overview.generateContent();
	}
});	

return OverviewWidget;

});
