/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"require",
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/connect",
"dojo/dom-style",
"dojox/gfx"
], function(
require,
declare,
lang,
connect,
style,
gfx
){

/*=====
var gfx = dojox.gfx;
=====*/

var GfxWidget =
declare('ibm_ilog.diagram.gfxwidget.GfxWidget', [gfx.Rect], {
	// summary:
	//		A custom GFX shape that allows to put a Dijit widget in a Dojo Diagrammer node or link.
	// description:
	//		The <code>GfxWidget</code> class is a custom GFX shape that is intended to be used in
	//		Dojo Diagrammer node and link templates to integrate Dijit widgets in nodes or links.
	//		The widget type can be specified either by specifying the <code>dojoType</code> property
	//		of the shape, or by passing a function as the <code>createWidget</code> property of the shape.
	//		<p>
	//		Note that this special shape has a number of limitations:
	//		<ul>
	//		<li>The widget does not zoom when the graph is zoomed (only its position will be updated).</li>
	//		<li>The stacking order of widgets may be inconsistent with the order of their parent group shapes.</li>
	//		<li>If the shape is used outside of a Diagram widget, the HTML element that contains the surface
	//		must have its <code>position</code> style set to <code>absolute</code>.</li>
	//		</ul>
	//		</p>
	//	example:
	//		See the widgets/widgets.html sample for examples.
	
	_widget:null,
	
	constructor: function(){
		// summary:
		//		Creates an empty GfxWidget instance.
		// description:
		//		You must call <code>setShape</code> to specify the widget class and attributes.
		
		this.shape = lang.clone(GfxWidget.defaultWidget);
		this.bbox = null;
	},
	
	setShape: function(shape){
		// summary:
		//		Sets the attributes of the GfxWidget shape.
		// description:
		//		The <code>shape</code> parameter is an object with the following properties:
		//		<table style="border-collapse:collapse;" border="1">
		//			<tr>
		//				<th><b>Property</b></th>	<th><b>Description</b></th>
		//			</tr>
		//			<tr>
		//				<td>type</td>				<td>must be <code>'widget'</code></td>
		//			</tr>
		//			<tr>
		//				<td>dojoType</td>			<td>The type of the widget, for example <code>'dijit.form.Button'</code>. If <code>createWidget</code> is specified, dojoType is ignored.</td>
		//			</tr>
		//			<tr>
		//				<td>createWidget</td>		<td>A function that is called to create the widget. The function will be called with the <code>GfxWidget</code> instance as argument.</td>
		//			</tr>
		//			<tr>
		//				<td>x,y</td>				<td>The position of the widget.</td>
		//			</tr>
		//			<tr>
		//				<td>width,height</td>		<td>The size of the shape. If no size is specified, the size of the widget is used.</td>
		//			</tr>
		//			<tr>
		//				<td><em>widget attribute</em></td>		<td>Any other property is passed to the widget using an <code>attr()</code> call. For example, <code>label: 'Click Here'</code> to set the label of a <code>Button</code>.</td>
		//			</tr>
		//		</table>
		// shape: Object
		//		A hash that contains the properties of the widget.
		
		shape = lang.mixin(lang.clone(GfxWidget.defaultWidget), shape);
		
		if (shape) {
			if (!this._widget) {
				var w = null;
				
				if (typeof(shape.createWidget) == 'function') {
					w = shape.createWidget.call(null, this);
					this._setupWidget(w);
				} else if (shape.dojoType) {
					require([shape.dojoType.replace(/\./g, "/")], lang.hitch(this, function(c){ // may be asynchronous
						w = new c(shape);
						this._setupWidget(w);
						this._setWidgetAttrs(shape)
					}));
					this.shape = shape;
					this.bbox = null;
					return this;
				}
			}
			
			this._setWidgetAttrs(shape)
		}
		
		this.shape = shape;
		this.bbox = null;
		
		return this;
	},
	
	_setupWidget: function(w) {
		if (w) {
			this._widget = w;
			w._gfxShape = this;
			w.startup();
			var n = w.domNode;
			n.style.position = "absolute";
		}
	},

	_setWidgetAttrs: function(shape){
		if (this._widget) {
			for (var p in shape) {
				if (!(p in GfxWidget.defaultWidget)) {
					this._widget.set(p, shape[p]);
				}
			}
		}
	},
	
	prepare: function(container) {
		//this._container = container;
		//this._container.appendChild(this._widget.domNode);
	},
	
	_setParent: function(parent){
		var ret = this.inherited(arguments);
		
		for (var p = this.getParent(); p != null; p = p.getParent ? p.getParent() : null) {
			if(p instanceof gfx.Surface){
				p._parent.appendChild(this._widget.domNode);
				break;
			} else {
				connect.connect(p, "setTransform", this, this._updateWidgetPosition);
				if(p._isIBMDiagramLink)
					connect.connect(p, "validateLinkShape", this, this._updateWidgetPosition);
			}
		}
		
		this._updateWidgetPosition();
		
		return ret;
	},


	_minHeight: 0,
	
	_minWidth: 0,

	_minFontPxSize: 0,

	setWidth: function(w) {
		if(this._minWidth && w<this._minWidth) {
			w = this._minWidth;
		}
		style.set(this._widget.domNode,"width",w+"px");		
	},

	setHeight: function(h) {
		if(this._minHeight && h<this._minHeight) {
			h = this._minHeight;
		}
		style.set(this._widget.domNode,"minHeight",h+"px"); // hack for textarea
		style.set(this._widget.domNode,"height",h+"px");
	},

	setMinWidth: function(w) {
		this._minWidth = w;
		if(w && this.getWidth()<w) {
			this.setWidth(w);
		}
	},

	setMinHeight: function(h) {
		this._minHeight = h;
		if(h && this.getHeight()<h) {
			this.setHeight(h);
		}
	},

	getMinWidth: function() {
		return this._minWidth || 0;
	},

	getMinHeight: function() {
		return this._minHeight || 0;
	},
	
	setFontPxSize: function(sz) {
		if(this._minFontPxSize && sz<this._minFontPxSize) {
			sz = this._minFontPxSize;
		}
		style.set(this._widget.domNode,"fontSize",sz+"px");
	},
	
	setFontMinPxSize: function(sz) {
		this._minFontPxSize = sz;
		if(sz && this.getFontPxSize()<sz) {
			this.setFontPxSize(sz);
		}
	},


	getFontMinPxSize: function() {
		return this._minFontPxSize || 0;
	},

	getWidth: function() {
		return gfx.normalizedLength(style.get(this._widget.domNode,"width"));
	},

	getHeight: function() {
		return gfx.normalizedLength(style.get(this._widget.domNode,"height"));
	},

	getFontPxSize: function() {
		return gfx.pt2px(parseFloat(style.get(this._widget.domNode,"font-size")));
	},	

	setTransform: function(t){
		// summary:
		//		Overridden from the base GFX shape class.
		// tags:
		//		private
		
		this.inherited(arguments);
		this._updateWidgetPosition();
		return this;
	},
	
	getBoundingBox: function(){
		// summary:
		//		Overridden from the base GFX shape class.
		// tags:
		//		private
		
		if (!this.bbox) {
			if (this.shape.width && this.shape.height) {
				this.bbox = {
					x: this.shape.x,
					y: this.shape.y,
					width: this.shape.width,
					height: this.shape.height
				};
			}
			else {
				var rect = this._widget.domNode.getBoundingClientRect();
				this.bbox = {
					x: this.shape.x,
					y: this.shape.y,
					width: rect.right - rect.left,
					height: rect.bottom - rect.top
				};
			}
		}
		return this.bbox;
	},
	
	_updateWidgetPosition: function(){
		var box = this.getBoundingBox();
		var t = this._getRealMatrix();
		if(t)
			box = t.transformRectangle(box);
		this._widget.domNode.style.left = box.x + "px";
		this._widget.domNode.style.top = box.y + "px";
	}
});

GfxWidget._nextId = 1;
GfxWidget.defaultWidget = { type:'widget', x:0, y:0, width:0, height:0, r:0, dojoType:'', createWidget:'' };
GfxWidget.nodeType = gfx.Rect.nodeType;

GfxWidget.byWidget = function(widget){
	// summary:
	//		Returns the GfxWidget instance that created the specified widget.
	
	return widget._gfxShape || null;
};

//
// Extends createShape to support our own shape types
//

function extendCreateShape(shapeType) {
    var method = "createShape";
    var old = shapeType.prototype[method];
    shapeType.prototype[method] = function() {
        var ret = old.apply(this, arguments);
        if (!ret) {
            var sh = arguments[0];
            switch (sh.type) {
                case 'widget':
                    ret = this.createObject(GfxWidget, sh);
                    break;
            }
        }
        return ret;
    };
}
extendCreateShape(gfx.Surface);
extendCreateShape(gfx.Group);

return GfxWidget;

});
