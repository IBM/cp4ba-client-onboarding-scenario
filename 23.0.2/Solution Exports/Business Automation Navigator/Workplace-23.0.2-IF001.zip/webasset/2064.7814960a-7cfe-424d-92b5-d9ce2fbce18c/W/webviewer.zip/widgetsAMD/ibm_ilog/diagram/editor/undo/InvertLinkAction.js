/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"./Action",
"./UndoActionList"
], function(
declare,
lang,
Action,
UndoActionList
){
/*=====
var Action = ibm_ilog.diagram.editor.undo.Action;
=====*/

	var InvertLinkAction =
	declare("ibm_ilog.diagram.editor.undo.InvertLinkAction", [Action], {
		//
		//	summary:
		//		this action undo / redo a reparenting action.
		_modifiedElementId: null,
	
	constructor:function(){
		//	
		// summary:
		//		creates a new instance, setting the corresponding label
		this._label = UndoActionList.InvertLink;
		this.initialize(lang.hitch(this,this._changeFunction),lang.hitch(this,this._changeFunction));
	},
	setModifiedElementId: function(modifiedElementId){
		//	
		// summary:
		//		sets the modified element Id
		this._modifiedElementId= modifiedElementId;
	},
	_changeFunction: function(){
		var modifiedElement = this.getUndoManager().getRegisteredGraphElement(this._modifiedElementId);
		InvertLinkAction.EditingUtils.invertLink(modifiedElement);
	}
	});
	
	return InvertLinkAction;
	
});
