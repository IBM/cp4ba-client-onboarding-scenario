/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"../../Link",
"../../interactors/Interactor",
"../undo/ConnectAction",
"../undo/MultipleAction",
"../undo/UndoActionList",
"../EditingUtils"
], function(
declare,
Link,
Interactor,
ConnectAction,
MultipleAction,
UndoActionList,
EditingUtils
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var ConnectionKeyInteractor =
declare("ConnectionKeyInteractor", [Interactor], {
	//summary:
	//		This interactor connects two or more Nodes through the keyboard interaction.
	//		This interactor has 1 connection: connect.
	
	_diagram: null,
	_linkShapeType: null,
	initialize: function (diagram) {
	// summary:
    //		initialize the new instance.
    // diagram: ibm_ilog.diagram.widget.Diagram
    //		the associated diagram.		
		this._diagram = diagram;
		return this._initialize();
		var linkStyle = this._viewport.getDiagram().linkStyle;
		this._linkShapeType = linkStyle?linkStyle.shapeType:Link.LinkShapeType.Straight;
	},
	setLinkShapeType: function(linkShapeType){
		// Summary:
		//		sets the link shape type
		this._linkShapeType = linkShapeType;
	},
	getKeyInteractorId: function(){
		// summary:
	    //		returns the Interactor Id
		return ConnectionKeyInteractor.KeyInteractorId;
	},
	getDefaultConnections: function () {
		// summary:
		//		returns the default event mapping
		
		return {
			connect: {
			hotKey: 74,/* j key */	
			connectTo: "connect",
			filter: this._buildInputFilter({ctrl:true,shift:false})
			}
		};
	},
	connect: function(e){
		// Summary:
		//		connects all the selected nodes in the order that they are selected.
		//		If there is a link in the selection or there is just one element selected, this function does nothing.
		var sel = this._diagram.getSelection().get();
		var linkSelection = false;
		var nodeSelection = false;
		var D = this._diagram;
		sel.forEach(function(elem){
			elem = D.asGraphElement(elem);
			if(elem._isIBMDiagramLink){
				linkSelection = true;
			}else{
				nodeSelection = true;
			}
		});
		if(linkSelection && nodeSelection){
			return false;
		}else{
			if(linkSelection){
				return this.invertLinks(sel);
			}else{if(nodeSelection){
				return this.connectNodes(sel);
			}}
		}
	},
	
	invertLinks: function(sel){
		if(sel.count < 1){
			return false;
		}
		var mAction = new MultipleAction(UndoActionList.InvertLink);
		for(var index = 0;index <sel.count;index++){
			var link = sel.item(index);
			var a = EditingUtils.invertLink(link);
			mAction.addAction(a);
		}
		var um = this._diagram.getUndoManager();
		um.addAction(mAction);
		
		return true;
	},
	connectNodes: function(sel){
		if(sel.count < 2){
			return false;
		}
		var mAction = new MultipleAction(UndoActionList.Connect);
		var links = [];
		var added = 0;
		for(var index = 1;index <sel.count;index++){
			var a = this._doConnect(sel.item(index-1),sel.item(index),links);
			if(a){
				mAction.addAction(a);
				added++;
			}
		}
		if(added>0){
			var um = this._diagram.getUndoManager();
			um.addAction(mAction);
			this._diagram.getSelection().add(links,true);
		}
		
		return true;
	},
	_doConnect: function(start,end,links) {
		//	summary:
		//			
		if(this._diagram.allowCreateLink(start,end)){
			var link = this._diagram.connectNodes(start,end);
			links.push(link);
			var parent = link.getParent();
			var undoAction = this._createConnectUndoAction(this._diagram,link,parent);
			this._diagram.onLinkUpdated(this._diagram,link,true,undoAction);
			return undoAction;
		}else{
			//TODO add onMessage call
			return null;
		}
	},
	_createConnectUndoAction: function(diagram,link,parent){
		var action = new ConnectAction(diagram,link,parent);
		return action;
	}
});

ConnectionKeyInteractor.KeyInteractorId = "Connect";

return ConnectionKeyInteractor;

});
