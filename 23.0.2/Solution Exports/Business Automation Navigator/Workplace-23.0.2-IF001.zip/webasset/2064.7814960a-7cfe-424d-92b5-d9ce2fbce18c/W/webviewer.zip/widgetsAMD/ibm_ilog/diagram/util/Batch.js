/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/lang"], function(lang){

	// Automatic batch mechanism to group possibly costly changes in Diagram objects.
	
	// TODO: Change to this when AMD conversion is complete:
	// var batch = {};
	var batch = lang.getObject("ibm_ilog.diagram.util.Batch", true);
	
	// the current batch
	var _batch = [];
	
	// the timer that will call endBatch
	var _timer = null;
	
	batch.add = function(obj){
		// summary:
		//		Adds the specified object to the current batch.
		// obj:
		//		The object to add to the current batch.
		// description:
		//		This method checks whether the specified object is already contained in the current
		//		batch, and if not adds it. When the first object is added, a timer is started so as
		//		to have the endBatch() function called automatically as soon as the current event loop
		//		is finished.
		//		This method is fast and can be called many times on an object without performance issues.
		
		if (!obj._inBatch) {
			_batch.push(obj);
			obj._inBatch = true;
			if (!_timer) {
				_timer = setTimeout(batch.endBatch, 0);
			}
		}
	};
	
	batch.endBatch = function(){
		// summary:
		//		Calls the _endBatch() method of all objects in the current batch.
		// description:
		//		This function is normally called automatically by the batch timer.
		//		You can call it explicitly if you want to refresh all the objects immediately.
		//		It is also possible to have endBatch() called when a specified method of a specified
		//		class is called, using endBatchOn(type, method).
		
		try {
			// Objects may be batched while we are here, so we save the current batch list
			// in a local variable and allocate a new "public" batch list immediately.
			// We loop until the new batch list is empty.
			// TODO: test for infinite loops?
			var batch = _batch;
			_batch = [];
			while (batch.length > 0) {
				for (var i = 0; i < batch.length; i++) {
					var obj = batch[i];
					if (obj._inBatch) {
						try {
							obj._endBatch();
						}
						finally {
							obj._inBatch = false;
						}
					}
				}
				batch = _batch;
				_batch = [];
			}
		}
		finally {
			_timer = null;
		}
	};
	
	batch.endBatchOn = function(type, method){
		// summary:
		//		Ensures that endBatch() is called when the specified method
		//		of the specified class is called.
		// description:
		//		You can call endBatchOn(type, method) to make sure all objects are refreshed immediately
		//		when the specified method is called.
		
		var old = type.prototype[method];
		type.prototype[method] = function(){
			var ret = old.apply(this, arguments);
			batch.endBatch();
			return ret;
		}
	};
	
	return batch;
});
