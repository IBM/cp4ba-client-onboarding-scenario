/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/lang", "dojo/aspect", "dojo/_base/array", "dojo/_base/Deferred"], 
function(lang, aspect, array, Deferred){
	var storeApi = {};
	
	// TODO: Change to this when AMD conversion is complete:
	var iidd = lang.getObject("ibm_ilog.diagram.data", true);
	iidd.StoreApi = storeApi;
	
	var eventMapApi1 = {
		// StoreApi events | dojo.data.api events
		'onNew': 'onNew',
		'onRemove': 'onDelete',
		'onUpdate': 'onSet',
		'onSave': 'save',
		'onRevert': 'revert'
	}
	var DojoData = {
		bridge: function(store){
		},
		// this = the store
		getValue: function(item, prop, defaultValue){
			return this.getValue(item, prop);
		},
		getValues: function(item, prop){
			return this.getValues(item, prop);
		},
		setValue: function(item, prop, value){
			this.setValue(item, prop, value);
		},
		getFeatures: function(){
			var f = this.getFeatures();
			return {
				canRead: f["dojo.data.api.Read"],
				identity: f["dojo.data.api.Identity"],
				canWrite: f["dojo.data.api.Write"],
				canNotify: f["dojo.data.api.Notification"]
			}
		},
		isItem: function(item){
			return this.isItem(item);
		},
		fetchItemByIdentity: function(args){
			return this.fetchItemByIdentity(args);
		},
		getLabelAttributes: function(item){
			return this.getLabelAttributes(item);
		},
		getLabel: function(item){
			return this.getLabel(item);
		},
		isItemLoaded: function(item){
			return this.isItemLoaded(item);
		},
		fetch: function(args){
			return this.fetch(args);
		},
		loadItem: function(args){
			return this.loadItem(args);
		},
		listen: function(args){
			var h = [];
			for (var p in args) {
				if (p !== 'scope' && args.hasOwnProperty(p)) {
					h.push(aspect.after(this, eventMapApi1[p], lang.hitch(args.scope, args[p]), true));
				}
			}
			return {
				remove: function(){
					removeListenHandlers(h);
				}
			};
		}
	};
	
	var DojoStore = {
		bridge: function(store){
			store.__iid_dataAPIObservers = {};
		},
		// this = the store
		getValue: function(item, prop, defaultValue){
			return prop in item ? item[prop] : defaultValue;
		},
		getValues: function(item, prop){
			var val = item[prop];
			return val instanceof Array ? val : val === undefined ? [] : [val];
		},
		setValue: function(item, prop, value){
			item[prop] = value;
		},
		getFeatures: function(){
			return {
				canRead: !!this.get,
				identity: true,
				canWrite: !!this.put,
				canNotify: !!this.notify
			};
		},
		isItem: function(item){
			return item && !(item instanceof Array || typeof item == 'array') && !(item instanceof Date);
		},
		fetchItemByIdentity: function(args){
			var item;
			Deferred.when(this.get(args.identity), function(result){
				item = result;
				if (args.onItem) 
					args.onItem.call(args.scope, result);
			}, function(error){
				if (args.onError) 
					args.onError.call(args.scope, error);
			});
			return item;
		},
		getLabelAttributes: function(item){
			return [this.labelProperty];
		},
		getLabel: function(item){
			return this.labelProperty ? item[this.labelProperty] : undefined;
		},
		isItemLoaded: function(item){
			return true; // ?
		},
		fetch: function(args){
			args = lang.delegate(args, args && args.queryOptions);
			var self = this;
			var scope = args.scope || self;
			var query = args.query;
			var results = this.query(query, args);
			Deferred.when(results.total, function(totalCount){
				Deferred.when(results, function(results){
					if (typeof results.observe === 'function') {
						results.observe(lang.hitch(self, observableListener), true);
					}
					if (args.onComplete) {
						args.onComplete.call(scope, results, args);
					}
					return results;
				}, errorHandler);
			});
			function errorHandler(error){
				if (args.onError) {
					args.onError.call(scope, error, args);
				}
			}
		},
		loadItem: function(args){
			// TODO: how to know it has been loaded ?...
			var item = args.item;
			if (item && args.onItem) {
				args.onItem.call(args.scope, args.item);
			}
			return item;
		},
		listen: function(args){
			if (typeof this.notify !== 'function') 
				return;
			var h = [], f;
			for (var p in args) {
				if (p !== 'scope' && args.hasOwnProperty(p)) {
					if (!this.__iid_dataAPIObservers[p]) 
						this.__iid_dataAPIObservers[p] = [];
					pushHandler(this.__iid_dataAPIObservers[p], args[p], args.scope, h);
				}
			}
			return {
				remove: function(){
					removeListenHandlers(h);
				}
			}
		}
	};
	
	var removeListenHandlers = function(h){
		array.forEach(h, function(i){
			i.remove();
		});
	};
	
	var pushHandler = function(dest, f, scope, h){
		(function(){
			f = lang.hitch(scope, f);
			dest.push(f);
			h.push({
				remove: function(){
					arrayRemove(dest, array.indexOf(dest, f));
				}
			});
		})();
	};
	
	var arrayRemove = function(array, from, to){
		var rest = array.slice((to || from) + 1 || array.length);
		array.length = from < 0 ? array.length + from : from;
		return array.push.apply(array, rest);
	};
	
	var observableListener = function(object, removedFrom, insertedInto){
		if (removedFrom == -1 && this.__iid_dataAPIObservers.onNew && this.__iid_dataAPIObservers.onNew.length > 0) {
			array.forEach(this.__iid_dataAPIObservers.onNew, function(l){
				l(object);
			});
		} else if (insertedInto == -1 && this.__iid_dataAPIObservers.onRemove && this.__iid_dataAPIObservers.onRemove.length > 0) {
			array.forEach(this.__iid_dataAPIObservers.onRemove, function(l){
				l(object);
			});
		} else if (insertedInto !== -1 && removedFrom !== -1 && this.__iid_dataAPIObservers.onUpdate && this.__iid_dataAPIObservers.onUpdate.length > 0) {
			array.forEach(this.__iid_dataAPIObservers.onUpdate, function(l){
				l(object);
			});
		}
		
	};
	
	
	lang.mixin(storeApi, {
		bridge: function(store){
			store._iid_dataAPI = typeof store.get === 'function' ? DojoStore : DojoData;
			store._iid_dataAPI.bridge(store);
		},
		dispose: function(store){
			store._iid_dataAPI = null;
			delete store._iid_dataAPI;
		},
		fromDojoStore: function(store){
			return typeof store.get === 'function';
		},
		fromDojoData: function(store){
			return typeof store.getFeatures === 'function';
		},
		getValue: function(store, item, p){
			return store._iid_dataAPI.getValue.call(store, item, p);
		},
		getValues: function(store, item, p){
			return store._iid_dataAPI.getValues.call(store, item, p);
		},
		setValue: function(store, item, p, value){
			store._iid_dataAPI.setValue.call(store, item, p, value);
		},
		getIdentity: function(store, item){
			return store.getIdentity(item);
		},
		getFeatures: function(store){
			return store._iid_dataAPI.getFeatures.call(store);
		},
		isItem: function(store, item){
			return store._iid_dataAPI.isItem.call(store, item);
		},
		fetchItemByIdentity: function(store, args){
			return store._iid_dataAPI.fetchItemByIdentity.call(store, args);
		},
		getLabelAttributes: function(store, item){
			return store._iid_dataAPI.getLabelAttributes.call(store, item);
		},
		getLabel: function(store, item){
			return store._iid_dataAPI.getLabel.call(store, item);
		},
		isItemLoaded: function(store, item){
			return store._iid_dataAPI.isItemLoaded.call(store, item);
		},
		fetch: function(store, args){
			return store._iid_dataAPI.fetch.call(store, args);
		},
		loadItem: function(store, args){
			return store._iid_dataAPI.loadItem.call(store, args);
		},
		listen: function(store, args){
			return store._iid_dataAPI.listen.call(store, args);
		}
		
	});
	return storeApi;
});
