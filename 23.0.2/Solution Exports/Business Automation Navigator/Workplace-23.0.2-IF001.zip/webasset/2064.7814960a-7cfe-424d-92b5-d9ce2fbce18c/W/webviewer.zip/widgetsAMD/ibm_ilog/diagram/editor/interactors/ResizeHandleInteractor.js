/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"../../interactors/DragInteractor"
], function(
declare,
DragInteractor
){

/*=====
var DragInteractor = ibm_ilog.diagram.interactors.DragInteractor;
=====*/

var ResizeHandleInteractor =
declare("ibm_ilog.diagram.editor.interactors.ResizeHandleInteractor", [DragInteractor], {
	//
	//	summary:
	//		Handles the interaction of a resize handle while resizing the related adorned.
	//	
	
	//
	//	_handle: /*ibm_ilog.diagram.editor.adorners.ResizeHandle*/
	//		The ResizeHandle associated with the interactor.
	//
	_handle: null,

	initialize: function ( /* ibm_ilog.diagram.editor.adorners.ResizeHandle */ handle ) {
		//
		//	summary:
		//		Initializes the interactor to work with the given handle
		//
		this._handle = handle;
		this._viewport = handle.getViewport();
		this._initialize();
		return this;
	},

	_getInitialEventSource: function () {
		return this._handle;
	},

	_refreshTransform: function () {
		var a = this._handle._adorner;
		if(a._adorned) {
			this._transform = a._adorned.getTransformToContainer(a._viewport.getSurface()).inverse();
		}
	},

	activate: function () {
		this.inherited(arguments);
	},

	_dragPreStart: function () {
		this._refreshTransform();
		this._connect("updateTransforms", this._handle._adorner._viewport, "onViewRectChanged", this, "_refreshTransform");
		this._handle.interactionBegun(this);
		this.inherited(arguments);
	},

	_dragEnd: function () {
		this._disconnect("updateTransforms");
		var dragged = this.hasDragged, action, D;
		this.inherited(arguments);
		this._handle.interactionEnded(this);
		if(dragged){
			action = this._handle.createUndoAction();
			D = this._viewport.getDiagram();
			D.getUndoManager().addAction(action);
		}
	},

	_dragMove: function () {
		this.inherited(arguments);
		this._handle.resize(this._totalDelta);
	}

});

return ResizeHandleInteractor;

});
