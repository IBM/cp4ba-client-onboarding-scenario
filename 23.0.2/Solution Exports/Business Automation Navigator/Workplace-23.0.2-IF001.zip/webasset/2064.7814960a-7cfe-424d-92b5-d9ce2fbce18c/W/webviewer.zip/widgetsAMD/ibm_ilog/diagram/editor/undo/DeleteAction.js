/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"dojo/_base/config",
"./Action",
"./UndoActionList",
"./MultipleAction",
"./ConnectAction",
"../DiagramSerializer",
"../../gfxlayout"
], function(
declare,
lang,
array,
config,
Action,
UndoActionList,
MultipleAction,
ConnectAction,
DiagramSerializer,
gfxlayout
){

/*=====
var Action = ibm_ilog.diagram.editor.undo.Action;
=====*/

var DeleteAction =
declare("ibm_ilog.diagram.editor.undo.DeleteAction", [Action], {
	_serialized: null,
	_deletedNodes: null,
	_diagram: null,
	_deletedLinksAction: null,
	
	constructor:function(diagram){
		this.setLabel(UndoActionList.Delete);
		this._diagram = diagram;
		this._deletedLinksAction = new MultipleAction(UndoActionList.Delete);
		this.initialize(lang.hitch(this,this._undoFunction),lang.hitch(this,this._redoFunction));
	},
	setDeleted: function(targetSet){
		this._deletedNodes = {};
		var ts = [];
		for(var index in targetSet){
			var ge = targetSet[index];
			var parent = ge.getParent();
			if(ge._isIBMDiagramNode){
				this._deletedNodes[ge.getId()] = this._diagram.getUndoManager().getParentId(parent);
				ts.push(ge);
			}else{
				this._deletedLinksAction.addAction(new DeleteLinkAction(this._diagram,ge,parent));
			}
		}
		this._serialized = this._diagram._getRemoveSerializer().serialize(ts);
		this._deletedLinksAction.setUndoManager(this._diagram.getUndoManager());
	},
	_undoFunction: function(){
		var undoGroup = new MultipleAction("Dummy");
		array.forEach(this._serialized,function(item){
			var parent =  this.getUndoManager().getRegisteredParent(this._deletedNodes[item.id]); 
			var d = this._diagram._getRemoveSerializer().deserialize([item],{graph:parent,undo:undoGroup});
			// layout undo'ed elements immediately... (fixes wrong subgraph bounds after undo delete node)
			if(config.useGfxLayout){
				array.forEach(d, function(e){
					var c = e.created;
					if(c && c._isIBMDiagramGraphElement && c.getLayout && c.getLayout())
						gfxlayout.Engine._layout(c);
				});
			}
		},this);
		this._deletedLinksAction.undo();
	},
	_redoFunction: function(){
		this._deletedLinksAction.redo();
		for(var elementId in this._deletedNodes){
			var ge = this.getUndoManager().getRegisteredGraphElement(elementId);
			ge.getParent().remove(ge);
			ge.dispose();
		}
	},
	_initializeSerializer: function(){
		this._serializer = new DiagramSerializer(this._diagram,null,this);
	},
	onSerialize: function(graphElement,serializedData){
		
	},
	onDeserialize: function(serializedData,newGraphElement,container,undoAction){
		var um = this._diagram.getUndoManager();
		um.registerGraphElementReplacement(serializedData.id,newGraphElement.getId());
	}
});

/*=====
var ConnectAction = ibm_ilog.diagram.editor.undo.ConnectAction;
=====*/

var DeleteLinkAction =
declare("ibm_ilog.diagram.editor.undo.DeleteLinkAction", [ConnectAction], {
	undoFunction: function(){
		ConnectAction.prototype.redoFunction.apply(this, arguments);
	},
	redoFunction: function(){
		ConnectAction.prototype.undoFunction.apply(this, arguments);
	}
});

return DeleteAction;

});
