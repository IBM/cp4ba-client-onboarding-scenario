/**
 * Class used to manage computing paths through a diagram. A BasePath can be set and then possible
 * forks computed from that path. Also alternate paths can be computed when taking specified forks.
 */
define([
   "dojo/_base/declare", "dojo/_base/lang", "dojo/aspect", "./adornerConstants", "./ilogDiagramUtils", "./PathElement"
], function(declare, lang, aspect, adornerConstants, ilogDiagramUtils, PathElement) {
   return declare("com.ibm.bpm.wpd.document.bpd.view.PathExplorer", [], {

      diagram : null,
      pathElements : null,
      baseRawPath : null,
      linksById : null,
      nodesById : null,
      nodeIdsByType : null,
      outgoingLinksByNodeId : null,
      supportForkingOutOfActivity : null,

      START_NODES : "start",
      END_NODES : "end",
      NON_EVENT_NODES : "non-event",

      constructor : function(ilogDiagram) {
         this.supportForkingOutOfActivity = false; // Runtime does not support 
         this.diagram = ilogDiagram;
         this.linksById = {};
         this.nodesById = {};
         this.nodeIdsByType = {};
         this.outgoingLinksByNodeId = {};
         this.init();
      },

      // Set up tables to more easily compute paths
      init : function() {
         this.initNodes();
         this.initLinks();
      },

      initLinks : function() {
         var links = ilogDiagramUtils.getAllLinks(this.diagram);
         for ( var i = 0; i < links.length; i++) {
            this.linksById[links[i].id[0]] = links[i];
            if (links[i].start[0]) {
               if (typeof this.outgoingLinksByNodeId[links[i].start[0]] === "undefined") {
                  this.outgoingLinksByNodeId[links[i].start[0]] = [];
               }
               this.outgoingLinksByNodeId[links[i].start[0]].push(links[i].id[0]);
            }
         }
      },

      initNodes : function() {
         var nodes = ilogDiagramUtils.getNodes(this.diagram, lang.hitch(this, function(item) {
            // return adornerConstants.isNodeType(item.type[0]);
            return true;
         }));
         for ( var i = 0; i < nodes.length; i++) {
            var node = nodes[i];
            this.nodesById[node.id[0]] = node;
            var type = this.NON_EVENT_NODES;
            if (adornerConstants.isStartType(node.type[0])) {
               type = this.START_NODES;
            } else if (adornerConstants.isEndType(node.type[0])) {
               type = this.END_NODES;
            }
            if (typeof this.nodeIdsByType[type] === "undefined") {
               this.nodeIdsByType[type] = [];
            }
            this.nodeIdsByType[type].push(node.id[0]);
         }
      },

      /**
       * Set the base path that will be used for computations.
       */
      setBasePath : function(pathElements) {
         this.pathElements = pathElements;
      },

      /**
       * Get the base path that will be used for computations.
       */
      getBasePath : function() {
         return this.pathElements;
      },

      /**
       * Dump the base path to the console.
       */
      dumpBasePath : function() {
         if (!this.pathElements || this.pathElements.length == 0) {
            console.log("<No elements>");
            return;
         }
         var pathElement = null;
         for ( var i = 0; i < this.pathElements.length; i++) {
            pathElement = this.pathElements[i];
            console.debug("(" + i + ") " + pathElement.type + " Name:" + this.getNameForDebug(pathElement));
            console.debug("   id:" + pathElement.id);
         }
      },

      getNameForDebug : function(pathElement) {
         if (!pathElement)
            return "<null>";
         if (this.isLink(pathElement.id)) {
            var link = this.linksById[pathElement.id];
            return "[" + this.getNodeNameForDebug(link.start[0]) + "]-->[" + this.getNodeNameForDebug(link.end[0]) + "]";
         } else {
            return "[" + this.getNodeNameForDebug(pathElement.id) + "]";
         }
      },

      getNodeNameForDebug : function(id) {
         if (!id)
            return "<null>";
         var node = this.nodesById[id];
         if (!node)
            return "<undefined>";
         if (!node.label || !node.label[0]) 
            return "<unnamed>";
         return node.label[0].replace("\n", " ");
      },

      /**
       * Dump the nodes and links for the diagram
       */
      dumpNodesAndLinks : function() {
         console.debug("PathExplorer: Nodes:");
         for ( var id in this.nodesById) {  
            var node = this.nodesById[id];
            console.debug("(" + id + ") " + node.type[0] + " Name:" + this.getNodeNameForDebug(id));
         }
         console.debug("PathExplorer: Links");
         for ( var id in this.linksById) {
            var link = this.linksById[id];
            console.debug("(" + id + ") " + "[" + this.getNodeNameForDebug(link.start[0]) + "]-->[" + this.getNodeNameForDebug(link.end[0]) + "]");
         }
      },

      /**
       * Compute the forks that exist along the base path. If includeAlternateStartingPoints ===
       * true then include alternate start nodes otherwise don't. You can specify the nodes that
       * should not be included in the calculation and the whether to include alternate starting
       * points
       */
      computeAlternateForks : function(nodeExclusionList, includeAlternateStartingPoints) {
         if (!this.pathElements)
            return null;
         // Follow the path, where a node has more than one outgoing link,
         // follow the link not chosen to ensure that it is not a loop, and
         // then return it if it is not
         var alternateForks = [];
         var currLinks = null;
         var newPath = null;
         var currPathElement = null;
         var currentPath = [];
         var exclusionList = null;
         if (nodeExclusionList) {
            exclusionList = this.asPath(nodeExclusionList);
         }

         // If we also include alternate starting points, then figure those out.
         if (includeAlternateStartingPoints) {
            var alternates = this.computeAlternateStartingPoints(nodeExclusionList);
            if (alternates) {
               alternateForks = alternates;
            }
         }
         // Now go down the current path, looking for and accumulating forks.
         for ( var i = 0; i < this.pathElements.length; i++) {
            if (this.pathElements[i].type != adornerConstants.TYPE_LINK && !adornerConstants.isEndType(this.pathElements[i].type)) {
               // Only fork if the element is forkable - some elements with multiple links going out 
               // out of them are not forkable such as a split gateway
               if (this.isForkable(this.pathElements[i].id)) {
                  currLinks = this.outgoingLinksByNodeId[this.pathElements[i].id];
                  if (currLinks && currLinks.length > 1) {
                     // Loop through the not chosen links
                     for ( var j = 0; j < currLinks.length; j++) {
                        // Can only choose a new link
                        if (currLinks[j] != this.pathElements[i + 1].id) {
                           // If the new link leads to a valid path, the add it to our result set
                           if (this.isValidPathTakingFork(currentPath, currLinks[j], exclusionList)) {
                              currPathElement = new PathElement({
                                 id : currLinks[j],
                                 ilogDiagram : this.diagram,
                                 type : adornerConstants.TYPE_LINK
                              });
                              alternateForks.push(currPathElement);
                           }
                        }
                     }
                  }
               }
            }
            currentPath.push(this.pathElements[i].id);
         }
         return alternateForks;
      },
      
      /**
       * Return true if a node and the node can be forked.
       */
      isForkable: function(id) {
         if (!id) return false;
         var node = this.nodesById[id];
         if (!node) return false;
         // We do not support forking on split gateways
         if (node.type[0] === adornerConstants.TYPE_GATEWAY_AND) return false;
         // If we do not support forking on activities...
         if (!this.supportForkingOutOfActivity && node.type[0] === adornerConstants.TYPE_ACTIVITY) return false;
         return true;
      },

      /**
       * Compute alternate starting links (connected to start nodes).
       */
      computeAlternateStartingPoints : function(nodeExclusionList) {
         if (!this.pathElements || this.pathElements.length === 0)
            return null;
         if (nodeExclusionList) {
            exclusionList = this.asPath(nodeExclusionList);
         }
         var startNodes = this.getStartNodeIds();
         if (!startNodes || startNodes.length <= 1)
            return null;
         var alternateNodes = [];
         var currPathElement = null;
         for ( var i = 0; i < startNodes.length; i++) {
            if (startNodes[i] != this.pathElements[0].id) {
               var outgoingLink = this.outgoingLinksByNodeId[startNodes[i]];
               if (outgoingLink) {
                  if (this.isValidPathTakingFork([
                     startNodes[i]
                  ], outgoingLink, exclusionList)) {
                     currPathElement = new PathElement({
                        id : outgoingLink,
                        ilogDiagram : this.diagram,
                        type : adornerConstants.TYPE_LINK
                     });
                     alternateNodes.push(currPathElement);
                  }

               }
            }
         }
         return alternateNodes;
      },

      /**
       * Compute a new path taking the specified fork in the base path. If joinBackToPathIfPossible
       * === true then the new path will try and stray minimally from the current base path.
       */
      computeNewPathTakingFork : function(linkPathElement, joinBackToPathIfPossible, nodeExclusionList) {
         if (!this.pathElements)
            return null;
         if (!linkPathElement)
            return null;
         var currentPath = [];
         var newPath = null;
         var pathElements = this.pathElements;
         var exclusionList = null;
         if (nodeExclusionList) {
            exclusionList = this.asPath(nodeExclusionList);
         }
         // If the path link is connected to a start link, then simply return a new path
         // starting from the connected start node.
         if (this.isLinkConnectedToStart(linkPathElement.id)) {
            var startNode = this.nodesById[this.linksById[linkPathElement.id].start[0]];
            if (startNode) {
               newPath = this.computeAPathStartingAtNode(currentPath, startNode.id[0], exclusionList);
               return this.asPathElements(newPath);
            }
         }
         // Loop through the base path to find the divergent link and then compute the new path from
         // there.
         for ( var i = 0; i < pathElements.length; i++) {
            if (pathElements[i].type != adornerConstants.TYPE_LINK && !adornerConstants.isEndType(pathElements[i].type)) {
               currLinks = this.outgoingLinksByNodeId[pathElements[i].id];
               if (currLinks && currLinks.length > 1) {
                  // Find the new link
                  for ( var j = 0; j < currLinks.length; j++) {
                     // Found the link?
                     if (currLinks[j] === linkPathElement.id) {
                        currentPath.push(pathElements[i].id);
                        // If we want to join back up with the base
                        // path then compute that (need to go through all paths though so will be a
                        // lot
                        // slower).
                        if (joinBackToPathIfPossible) {
                           // Compute all paths and then pick the best one.
                           var paths = this.computeAllPathsStartingAtLink([
                              currentPath
                           ], currLinks[j], exclusionList);
                           if (!paths)
                              return null;
                           // We score each path, the highest one wins.
                           var highestScoredPath = null;
                           var highestScore = -1;
                           var path = this.asPath(this.pathElements);
                           for ( var k = 0; k < paths.length; k++) {
                              var score = this.computePathScore(path, paths[k]);
                              if (score > highestScore) {
                                 highestScore = score;
                                 highestScoredPath = paths[k];
                              }
                           }
                           return this.asPathElements(highestScoredPath);

                        } else {
                           // Just find a path, any will do
                           newPath = this.computeAPathStartingAtLink(currentPath, currLinks[j], exclusionList);
                           return this.asPathElements(newPath);

                        }
                     }
                  }
               }
            }
            currentPath.push(this.pathElements[i].id);
         }
         return this.asPathElements(currentPath);
      },

      isLinkConnectedToStart : function(linkId) {
         if (!linkId)
            return false;
         var link = this.linksById[linkId];
         if (!link)
            return false;
         var node = this.nodesById[link.start[0]];
         if (!node)
            return false;
         return this.isNodeIdStart(node.id[0]);
      },

      isLink : function(id) {
         if (!id)
            return false;
         return typeof this.linksById[id] != "undefined";

      },

      /**
       * Used for testing. Simply finds a path in the diagram. From a start to an end node.
       */
      computeAPath : function() {
         var startId = this.getStartNodeId();
         if (!startId)
            return null;
         var path = this.computeAPathStartingAtNode([], startId);
         return this.asPathElements(path);
      },

      isValidPathTakingFork : function(currPath, fork, nodeExclusionList) {
         var newPath = this.computeAPathStartingAtLink(currPath, fork, nodeExclusionList);
         return (newPath && newPath.length > 0);
      },

      getStartNodeId : function() {
         var ids = this.nodeIdsByType[this.START_NODES];
         if (!ids || ids.length === 0)
            return null;
         return ids[0];
      },

      getStartNodeIds : function() {
         return this.nodeIdsByType[this.START_NODES];
      },

      getNodeById : function(id) {
         if (!id)
            return null;
         return this.nodesById[id];
      },

      getLinkById : function(id) {
         if (!id)
            return null;
         return this.linksById[id];
      },

      getOutgoingLinks : function(nodeId) {
         if (!nodeId)
            return null;
         return this.outgoingLinksByNodeId[nodeId];
      },

      isNodeIdEnd : function(nodeId) {
         if (!nodeId)
            return false;
         return this.nodeIdsByType[this.END_NODES].indexOf(nodeId) >= 0;
      },

      isNodeIdStart : function(nodeId) {
         if (!nodeId)
            return false;
         return this.nodeIdsByType[this.START_NODES].indexOf(nodeId) >= 0;
      },

      computeAllPathsStartingAtNode : function(currentPaths, nodeId, nodeExclusionList) {
         if (!nodeId || !currentPaths)
            return null;
         var updatedPaths = [];
         // If the node is an end, then we're done, the path is current path and the
         // end node.
         if (this.isNodeIdEnd(nodeId)) {
            for ( var i = 0; i < currentPaths.length; i++) {
               updatedPaths.push(currentPaths[i].concat([
                  nodeId
               ]));
            }
            return updatedPaths;
         }
         // If the current path already contains the nodeId then there is a loop
         // which is currently not allowed, so remove the path
         for ( var i = 0; i < currentPaths.length; i++) {
            if (currentPaths[i].indexOf(nodeId) === -1 && (!nodeExclusionList || nodeExclusionList.indexOf(nodeId) === -1))
               updatedPaths.push(currentPaths[i]);
         }
         // If there ar eno more paths then we are done.
         if (updatedPaths.length === 0)
            return null;
         // If there are any outgoing links then follow them
         var outgoingLinks = this.getOutgoingLinks(nodeId);
         if (!outgoingLinks || outgoingLinks.length === 0)
            return null;
         // Add the nodeID to the updated paths
         for ( var i = 0; i < updatedPaths.length; i++) {
            updatedPaths[i].push(nodeId);
         }
         var computedPaths = [];
         // Follow the links
         for ( var i = 0; i < outgoingLinks.length; i++) {
            // If at least one path is found going down the link, then add the paths to our
            // accumulated paths.
            var newPaths = this.computeAllPathsStartingAtLink(updatedPaths, outgoingLinks[i], nodeExclusionList);
            if (newPaths && newPaths.length > 0) {
               computedPaths = computedPaths.concat(newPaths);
            }
         }
         if (!computedPaths || computedPaths.length === 0)
            return null;
         return computedPaths;
      },

      computeAPathStartingAtNode : function(currentPath, nodeId, nodeExclusionList) {
         if (!currentPath || !nodeId)
            return null;
         // If the node is an end, then we're done, the path is current path and the
         // end node.
         if (this.isNodeIdEnd(nodeId))
            return currentPath.concat([
               nodeId
            ]);
         // If the current path already contains the nodeId then there is a loop
         // which is currently not allowed, so return a null.
         if (currentPath.indexOf(nodeId) != -1 || (nodeExclusionList && nodeExclusionList.indexOf(nodeId) != -1))
            return null;
         // If there are any outgoing links then follow them
         var outgoingLinks = this.getOutgoingLinks(nodeId);
         if (!outgoingLinks || outgoingLinks.length === 0)
            return;
         var newPath = null;
         for ( var i = 0; i < outgoingLinks.length; i++) {
            // If a path is returned going down the link then we've found a path,
            // so return it.
            newPath = this.computeAPathStartingAtLink(currentPath.concat([
               nodeId
            ]), outgoingLinks[i], nodeExclusionList);
            if (newPath)
               return newPath;
         }
         return null;
      },

      computeAllPathsStartingAtLink : function(currentPaths, linkId, nodeExclusionList) {
         if (!linkId)
            return null;
         // Find the link and get its end point
         var link = this.getLinkById(linkId);
         if (!link)
            return null;
         var nodeId = link.end[0];
         if (!nodeId)
            return null;
         var updatedPaths = [];
         // Compute paths starting from the end node.
         for ( var i = 0; i < currentPaths.length; i++) {
            updatedPaths.push(currentPaths[i].concat(linkId));
         }
         return this.computeAllPathsStartingAtNode(updatedPaths, nodeId, nodeExclusionList);
      },

      computeAPathStartingAtLink : function(currentPath, linkId, nodeExclusionList) {
         if (!linkId)
            return null;
         // Find the link and get its end point
         var link = this.getLinkById(linkId);
         if (!link)
            return null;
         var nodeId = link.end[0];
         if (!nodeId)
            return null;
         return this.computeAPathStartingAtNode(currentPath.concat([
            linkId
         ]), nodeId, nodeExclusionList);
      },

      computePathScore : function(basePath, computedPath) {
         if (!basePath || !computedPath)
            return 0;
         var foundDiff = false;
         var score = 0;
         for ( var i = 0; i < computedPath.length; i++) {
            // Find the first different node
            if (!foundDiff) {
               if (basePath.indexOf(computedPath[i]) === -1) {
                  foundDiff = true;
               }
               // Now keep score, the more matches the higher the score and
               // the closer the matches to the divergent point, the higher the score
            } else {
               var idx = basePath.indexOf(computedPath[i]);
               if (idx >= 0) {
                  score = score + basePath.length - idx;
               }
            }
         }
         return score;
      },

      asPathFromOnlyNodes : function(nodes) {
         if (!nodes)
            return null;
         var newPath = [];
         var relevantNodes = [];
         var link = null;
         for (var i = 0; i < nodes.length; i++) {
            var node = this.nodesById[nodes[i]];
            if (node) {
               relevantNodes.push(nodes[i]);
            }
         }
         nodes = relevantNodes;
         for ( var i = 0; i < nodes.length; i++) {
            var node = this.nodesById[nodes[i]];
            newPath.push(nodes[i]);
            if (i < nodes.length - 1) {
               // Find the link between this node and the next node
               var links = this.outgoingLinksByNodeId[node.id[0]];
               if (!links) {
                  continue;
               }
               for ( var j = 0; j < links.length; j++) {
                  link = this.linksById[links[j]];
                  if (link.end[0] === nodes[i + 1]) {
                     newPath.push(links[j]);
                     break;
                  }
               }
            }
         }
         return newPath;
      },

      asPathFromOnlyLinks : function(links) {
         if (!links)
            return null;
         var newPath = [];
         var nodeIds = [];
         var link = null;
         for ( var i = 0; i < links.length; i++) {
            var link = this.linksById[links[i]];
            if (!link) {
               // Ignore links not in the diagram
               // console.debug("Could not find link in diagram! id=" + links[i]);
               continue;
            }
            var start = link.start[0];
            var end = link.end[0];
            if (start && nodeIds.indexOf(start) === -1) {
               newPath.push(start);
               nodeIds.push(start);
            }
            newPath.push(links[i]);
            if (end && nodeIds.indexOf(end) === -1) {
               newPath.push(end);
               nodeIds.push(end);
            }
         }
         return newPath;
      },

      asLinkOnlyPath : function(path) {
         if (!path)
            path = this.asPath();
         var newPath = [];
         var link = null;
         for ( var i = 0; i < path.length; i++) {
            link = this.getLinkById(path[i]);
            if (link) {
               newPath.push(path[i]);
            }
         }
         return newPath;
      },

      asNodeOnlyPath : function(path) {
         if (!path)
            path = this.asPath();
         var newPath = [];
         var node = null;
         for ( var i = 0; i < path.length; i++) {
            node = this.getNodeById(path[i]);
            if (node) {
               newPath.push(path[i]);
            }
         }
         return newPath;
      },

      asPathElements : function(path) {
         if (!path)
            path = this.asPath();
         var pathElements = [];
         var pathElement = null;
         var element = null;
         for ( var i = 0; i < path.length; i++) {
            element = this.getNodeById(path[i]);
            if (element) {
               pathElement = new PathElement({
                  id : element.id[0],
                  ilogDiagram : this.diagram,
                  type : element.type[0]
               });
               pathElements.push(pathElement);
            } else {
               element = this.getLinkById(path[i]);
               if (element) {
                  pathElement = new PathElement({
                     id : element.id[0],
                     ilogDiagram : this.diagram,
                     type : adornerConstants.TYPE_LINK
                  });
                  pathElements.push(pathElement);
               }
            }
         }
         return pathElements;

      },

      asPath : function(pathElements) {
         if (!pathElements)
            pathElements = this.getBasePath();
         var ids = [];
         for ( var i = 0; i < pathElements.length; i++) {
            ids.push(pathElements[i].id);
         }
         return ids;
      }

   });

});