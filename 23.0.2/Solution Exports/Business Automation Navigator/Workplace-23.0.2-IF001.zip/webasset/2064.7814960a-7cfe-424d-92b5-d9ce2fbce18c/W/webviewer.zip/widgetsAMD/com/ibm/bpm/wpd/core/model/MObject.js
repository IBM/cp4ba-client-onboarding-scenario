define(["dojo/_base/declare",
        "dojo/_base/connect",
        "../control/notification/Notification"],
function(declare,
		connect,
		Notification) {

return declare([], {

	id: null,
	
	constructor : function(id){
		if (!id){
			this.id =  Math.random().toString();
		} else {
			this.id = id;
		}
	},
	
	getAttribute: function(attributeName) {
		return this[attributeName];
	},

	setAttribute: function(attributeName, newValue, ctx){
		//(changeType, parentObject, attributeName, oldValue, newValue, affectedListPosition, context){
		var n = new Notification(1, this, attributeName, this[attributeName], newValue);
		n.context = ctx;
		this[attributeName] = newValue;
		
		/* Now dispatch the corresponding notification to any topic-based listeners */
		connect.publish(this.declaredClass + "::" + n.attributeName, [n]);
		
		//The following 2 kinds of notification are not needed for now
		/* Publish an object-instance-based notification */
		//dojo.publish(this.id, [n]);
			
		/* Publish an object-instance-attribute based notification */
		//dojo.publish(this.id + "::" + n.attributeName, [n]);
		
		

	}
});

});