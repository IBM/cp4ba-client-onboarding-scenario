/* Contains the functions for initialization and clean up for the BPM Web Viewer*/
define([
        "dojo/has",
        "dojo/_base/sniff",
        "../core/control/WpdRestHandler",
        "../core/model/shellstate/ShellStateModel",
        "../core/model/providers/ModelTypeProviderRegistry"
], function(has,
        sniff,
        WpdRestHandler,
		ShellStateModel,
		ModelTypeProviderRegistry) {

	var _bootstrap_global_BPM = {};

	var _bootstrap = {
		wpdConstant : {
			BPM_WARNAME_BPMREST : "rest",
			BPM_WARNAME_PROCESSPORTALSUPPORT : "processPortalSupport",
			BPM_WARNAME_WEBVIEWER :  "webViewer"
		},
		getBPMGlobals : function() {
			return _bootstrap_global_BPM;
		},

		getEndPointAndContextRootForModule : function(webApp){
			return dojoConfig.App._bpmContextRootMap[webApp];
		},
		
//function to initialize the global variables for Web viewer
initializeWebViewer : function(state, providers){

	_bootstrap_global_BPM.WPD_RestHandler 			= WpdRestHandler.getInstance(null, this.getEndPointAndContextRootForModule(this.wpdConstant.BPM_WARNAME_BPMREST));
	
	_bootstrap_global_BPM.WPD_ShellStateModel 		= ShellStateModel.getInstance(state);
	//dojo.global.BPM.WPD_NotificationManager		= new com.ibm.bpm.wpd.core.control.notification.NotificationManager();

	_bootstrap_global_BPM.WPD_ModelTypeProviderRegistry 	= ModelTypeProviderRegistry.getInstance(_bootstrap_global_BPM);
	
	_bootstrap_global_BPM.WPD_useWLEServer = true;
	
	if (!!providers){
		
		//Register additional docTypeProvider
		for (var i = 0; i < providers.length; i++ ){
			_bootstrap_global_BPM.WPD_ModelTypeProviderRegistry.registerDocTypeProvider(providers[i]);
		}
	}
},

launchHighlight : function(params){
		var url = this.getEndPointAndContextRootForModule(this.wpdConstant.BPM_WARNAME_WEBVIEWER) + "/jsp/visualization/visualization.jsp?newWindow=true";
		url = url + "&documentId=" + params.documentId;
		url = url + "&documentName=" + params.documentName;
		url = url + "&assetType=" + params.assetType;
		url = url + "&branchId=" + params.branchId;
		url = url + "&snapshotId=" + params.snapshotId;
		
		//var windowParams = "location=1,width=850,height=650,top=50,left=50,scrollbars=yes,status=no,resizable=yes,toolbar=no,location=no";
		var windowParams = "location=1,width=850,height=650,top=50,left=50";
		var WindowObject = window.open(url, "Visualization", windowParams);
		WindowObject.focus();
},

//function to clear all the global variables for the Web viewer
cleanUpWebViewerGlobal : function(){

	if(_bootstrap_global_BPM.WPD_ShellStateModel){
		_bootstrap_global_BPM.WPD_RestHandler 			=  null;
		delete _bootstrap_global_BPM.WPD_RestHandler;
	
		//dojo.global.BPM.WPD_DocumentTypeRegistry 	=  null;
		//delete dojo.global.BPM.WPD_DocumentTypeRegistry;
	
		_bootstrap_global_BPM.WPD_ShellStateModel 		=  null;
		delete _bootstrap_global_BPM.WPD_ShellStateModel;
	
		//dojo.global.BPM.WPD_NotificationManager		=  null;
		//delete dojo.global.BPM.WPD_NotificationManager;
	
		_bootstrap_global_BPM.WPD_ModelTypeProviderRegistry 	=  null;
		delete _bootstrap_global_BPM.WPD_ModelTypeProviderRegistry;
	}
	
},

/**
 * Initializes global variables, loads style sheets and creates the component to be used
 *@param componentClassName The class name of the component to be created. It can be the following 3 classes
 *		com.ibm.bpm.wpd.base.DocumentationViewer It displays the breadcrumb, document detains view and the action panel
 *		com.ibm.bpm.wpd.core.view.BreadcrumbView It displays the breadcrumb and  document details view. NO action panel
 *      com.ibm.bpm.wpd.core.view.ViewManager It displays document details view. No breadcrumb
 *@param project Information properties
 *		projectName
 *		projectId
 *		snapshotName or branchName
 *		snapshotId or branchId
 *@param style
 *@param parentDiv
 *@param state in which the component is used. 
 *		processCenter
 *		Portal
 *		Inspector
 *@param providers List of additional BaseDocTypeProvider
 *@param breadcrumbDiv Not decided yet whether we would create breadcrumb this way
 *@param btdPreference
 *			
 */
createWebViewerComponent : function(compClass/*componentClassName*/, project, style, parentDiv, state, providers, breadcrumbDiv, btdPreference){
	
	//initialize global variables
	this.initializeWebViewer(state, providers);
	ShellStateModel.getInstance().setProjectInfor(project);
	ShellStateModel.getInstance().setBTDPreference(btdPreference);
	
	//load css file
//	this.loadStyleSheet("/portal/js/dojo/1.6.1/dijit/themes/tundra/tundra_optimized.css", "tundraCSS");
//	this.loadStyleSheet("/portal/js/dojo/1.6.1/dojox/layout/resources/ExpandoPane.css", "expandoCSS");

//	this.loadStyleSheet("/teamworks/script/coachNG/dojo/1.7.3_src/dijit/themes/tundra/tundra.css", "tundraCSS");
// This is loaded by the Coach framework, if consumers do not already load this then they should.
//	this.loadStyleSheet("/teamworks/script/coachNG/dojo/1.7.3_debug/dijit/themes/claro/claro.css", "claroCSS");
// This is currently NOT used as we are only consumig the BPDViewer and NOT the BPMNViewer
//	this.loadStyleSheet("/teamworks/script/coachNG/dojo/1.7.3_debug/dojox/layout/resources/ExpandoPane.css", "expandoCSS");
	this.loadStyleSheet(this.getEndPointAndContextRootForModule(this.wpdConstant.BPM_WARNAME_WEBVIEWER) + "/widgetsAMD/themes/webviewer.css", "webviewerCSS");
	this.loadStyleSheet(this.getEndPointAndContextRootForModule(this.wpdConstant.BPM_WARNAME_WEBVIEWER) + "/widgetsAMD/com/ibm/bpm/wpd/css/breadcrumb.css", "breadcrumbCSS");
	
	//instantiate the component
//	dojo["require"](componentClassName);
//	var compClass = dojo.getObject(componentClassName);
	var viewer = new compClass({style: style},parentDiv);
	
	//TODO: we may need to do sth about the breadcrumb	
	
	//sample for how to open a po/document, remove the comment for this line(openDocEvent.dispatch();)in your code
	//dojo.require("com.ibm.bpm.wpd.core.control.events.OpenDocumentEvent");
	//var openDocClass = dojo.getObject("com.ibm.bpm.wpd.core.control.events.OpenDocumentEvent");
	//var params = {};
	//params.documentId = "25.c904b3b1-afc1-4698-bf5a-a20892c20275";
	//params.documentName = "name"; 
	//var openDocEvent = new openDocClass(params);
	//openDocEvent.dispatch(); //un comment this in your code
	return viewer;
},

loadStyleSheet : function(url, cssID) {
	// summary: 
	//	Loads a stylesheet if not already loaded
	// 
	// description:
	//  This function loads the style sheet if not already loaded.
	//  If no url is specified, the style sheet for the Business Space
	//  common look and feel is used.
	//

	var loaded = false;
	
//		// create a link element to fully resolve the url
//		var link = document.createElement('link');
//		link.rel = 'stylesheet';
//		link.href = url;
//		link.type = 'text/css';
//		link.media = 'screen';
//		link.charset = 'utf-8';var loaded = false;
//		url = link.href;
//		loaded = com.ibm.bspace.common.util.ui.Helper.isStyleSheetLoaded(url);
//		//console.debug('Helper.loadStyleSheet: stylesheet '+url+' loaded='+loaded);
	
	if(document.getElementById(cssID)) {
		loaded = true;
	}
	
	if (!loaded) {

		if (has("ie"))
		{
			// IE has a limit of 31 style sheets at the document
			// level and also allows a style sheet to import up
			// to 31 additional style sheets.  IE only allows a
			// depth of 3 for the import tree.
			//
			// This logic will first check if we have a created a
			// dynamic style object, and if not then it creates the
			// object and adds it to the head element.  This style
			// object will be used to import all of the style sheets
			// that are loaded by this function.
			//
			// If there is room to add an import to our dynamic
			// style object, the style sheet is imported there.
			// If there is not room, each of the child objects is
			// checked and the style sheet is imported by the first
			// child that has room.  If no child stylesheets have
			// room, then the first grandchild style sheet that has
			// room is used for the import.
			//
			// These allows up to 29791 style sheets to be loaded
			// on IE.
			
			var s = document.createElement('style');
			s.id = cssID;
			document.getElementsByTagName('head')[0].appendChild(s);

			var sheet = null;
			for (var i=0; !sheet && (i<document.styleSheets.length); i++)
			{
				if (document.styleSheets[i].id == cssID)
				{
					sheet = document.styleSheets[i];
				}
			}
			if (sheet)
			{
				// check if room at depth of 1
				if (sheet.imports.length < 31)
				{
					sheet.addImport(url);
					loaded = true;
				}
				// check if room at depth of 2 (if not loaded yet)
				for (var j=0; !loaded && (j<sheet.imports.length); j++)
				{
					var child = sheet.imports[j];
					if (child.imports.length < 31)
					{
						child.addImport(url);
						loaded = true;
					}
				}
				// check if room at depth of 3 (if not loaded yet)
				for (var j=0; !loaded && (j<sheet.imports.length); j++)
				{
					var child = sheet.imports[j];
					for (var k=0; !loaded && (k<child.imports.length); k++)
					{
						var grandchild = child.imports[k];
						if (grandchild.imports.length < 31)
						{
							grandchild.addImport(url);
							loaded = true;
						}
					}
				}
			}
		} else {
			var link = document.createElement('link');
			link.rel = 'stylesheet';
			link.href = url;
			link.type = 'text/css';
			link.media = 'screen';
			link.charset = 'utf-8';
			link.id = cssID;
			document.getElementsByTagName('head')[0].appendChild(link);
			loaded = true;
		}
	}
	return loaded;
}

// end of _bootstrap
}

	return _bootstrap;
});
