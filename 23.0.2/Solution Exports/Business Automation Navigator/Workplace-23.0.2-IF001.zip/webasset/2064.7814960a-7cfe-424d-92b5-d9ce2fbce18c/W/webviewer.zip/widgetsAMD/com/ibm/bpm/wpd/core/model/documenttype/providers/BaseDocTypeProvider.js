define(["dojo/_base/declare",
		"../../../model/viewstate/ViewStateModel",
		"../../../view/BaseViewer"],
function(declare,
		ViewStateModel,
		BaseViewer) {

return declare([], {

	docType:null,
	//editorClass:null,
	
	contructor : function () {
		this._initialize();
	},
	
	/**
	 * Return the document type
	 * Subclass must override this function
	 */
	getDocType: function(){
		return "commonModelDocType";
	},
	
	_initialize : function (){
		
	},
	
	/**
	 * Creates a ViewStateModel for document of this type
	 * @param data
	 * @returns {com.ibm.bpm.wpd.core.model.viewstate.ViewStateModel}
	 */
	createViewStateModel : function (data){
		
		var esm = new ViewStateModel();
		this.setViewStateModel(esm);
		return esm;
	},

	setViewStateModel : function (model){
		this.viewStateModel = model;
	},
	
	/**
	 * Whether reuse existing viewer or instantiate a new viewer when open document of the same type
	 * @returns
	 */
	reuseViewer : function(){
		return true;
	},
	
	/**
	 * Create a viewer for document of this type
	 * Subclass must override this function
	 */
	createViewer : function(model, parent){
		return new BaseViewer({viewStateModel:model}, parent);
	},
	
	
	/**
	 * Return the url to retrieve the details data for the document
	 * Subclass must override this function
	 * @param docId The document/po id
	 */
	getPORestPath: function(docId){
		//var url = "/v1/visual/processModel/" + docId + "?";
		//return url;
		throw new Error("Please implement function:getPORestPath in your docTypeProvider");
	},
	
	getRequestParams:function(properties){
		
		var params = {};
		params.action = "get";
		
		var docId = properties.documentId;		
		var branchId = properties.branchId;
		var snapshotId = properties.snapshotId;
		if (!properties.branchId && !properties.snapshotId){
			throw new Error("Neither branchId nor snapshot is provided");
		}		
		
		params.url = this.getPORestPath(docId);
		
		if (!!snapshotId){
			params.url = params.url + "snapshotId=" + snapshotId;
		}
		else{
			params.url = params.url + "branchId=" + branchId;
		}
		
		return params;
	},
	/**
	 * Return the file path to the icon used by this viewer
	 * Subclass must override this function
	 * @param size is the icon size
	 */
	getIconPath : function(size){
		throw new Error("Please implement function:getIconPath in your docTypeProvider");
	},
	
	/**
	 * Clean up work
	 */
	cleanup: function(){
		
	}
	
});

});
