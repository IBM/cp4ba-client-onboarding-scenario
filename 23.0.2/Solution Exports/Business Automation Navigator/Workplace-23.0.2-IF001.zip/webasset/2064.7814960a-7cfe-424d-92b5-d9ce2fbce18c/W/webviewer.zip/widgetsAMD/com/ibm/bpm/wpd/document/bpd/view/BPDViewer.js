define(["require",
        "dojo/parser",
        "dijit/_Widget",
        "dijit/_TemplatedMixin",
        "dijit/_WidgetsInTemplateMixin",
        "dijit/_WidgetBase",
        "dojo/_base/declare",
        "dojo/_base/kernel",
        "dojox/dtl/tag/logic",
        "dojo/data/ItemFileWriteStore",
        "dijit/layout/ContentPane",
        "dijit/Menu",
        "dijit/MenuItem",
        "dijit/form/HorizontalSlider",
        "dijit/form/Button",
        "dijit/_base/wai",
        "dojox/collections/Dictionary",
        "dojox/gfx/utils",
        "dijit/Dialog",
        "dojo/has",
        "dojo/_base/sniff",
        "dojo/_base/connect",
        "dojo/_base/array",
        "dojo/_base/lang",
        "dojo/query",
        "dojo/_base/json",
        "dojo/_base/xhr",
        "dojo/keys",
        "dojo/_base/Color",
        "dojo/dom",
        "dojo/dom-style",
		"dojo/i18n!./nls/BPDViewerResources",
        // Diagram requires
        "ibm_ilog/diagram/widget/Diagram",
        "ibm_ilog/diagram/SwimLane",
        "ibm_ilog/diagram/util/PrintUtil",
        "ibm_ilog/diagram/util/Batch",
        "ibm_ilog/diagram/Node",
        "ibm_ilog/diagram/main",
        "../../../core/control/commands/OpenDocumentCommand",
        "../../../core/model/shellstate/ShellStateModel",
        "../../../util/BidiUtils",
        "./BPDWheelPanInteractor",
        "./Templates",
		"./Tooltip",
        "dojo/text!./templates/BPDViewer.html"],
function(require,
        parser,
        _Widget,
        _TemplatedMixin,
        _WidgetsInTemplateMixin,
        _WidgetBase,
        declare,
        kernel,
        logic,
        ItemFileWriteStore,
        ContentPane,
        Menu,
        MenuItem,
        HorizontalSlider,
        Button,
        wai,
        Dictionary,
        gfxUtils,
        Dialog,
        has,
        sniff,
        connect,
        array,
        lang,
        query,
        json,
        xhr,
        keys,
        Color,
        dom,
        domStyle,
		nls,
        // Diagram requires
        Diagram,
        SwimLane,
        PrintUtil,
        Batch,
        Node,
        ibm_diagram_base,
        OpenDocumentCommand,
        ShellStateModel,
        BidiUtils,
        BPDWheelPanInteractor,
        Templates,
		Tooltip,
        template) {


/**
 *  Process Documentation widget for the BPD editor.
 */
return declare([ _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {
	
	// Path to the template
	templateString : template,
	
	widgetsInTemplate : true,
	
	// Seem to need this when adding to diagram after it's been zoomed;
	zoomLevel: 1,
	
//	breadcrumb : null,
//	pane: null,
	
	//Access to the print button (TODO: Remove later...)
//	printBtn: null,

	//ILog Diagrammer object
//	diagram: null,

	//Context (Right-click) menu for nodes. Pass in a dijit.Menu item to add a new option to the diagram.
	nodeMenu: null,

	//Hide the properties pane and the controls area if the widget is being used outside of the Process Documentation widget.
	viewerOnly: false,

	//Development flag. Used to force a load of data from the local file system without trying to talk to TeamWorks
	debug: false,

	//Allow diagram editing. Mostly for demonstration purposes.
	enableEditing: false,

	//Location of icons on the server. 
	iconURL: null,

	//Pre-defined templates
	templates: null,

	//Location of REST data interface
	restURL: "HRSample4.json",
	
	//Diagram object
	ilogDiagram: null,

	//Keep track of when we're using silverlight. It requires .png icons
//	iconSuffix: '.gif',

//	onDiagramLoad : undefined,

//	serverSideTextRendering: false,

//	serverSideImageRendering: (has("ie") < 10 || navigator.userAgent.toLowerCase().indexOf('ipad') >= 0),

	//Data being rendered
	data: null,	
	//map contains eventKey and list of handlers, currently it takes one handler function
	//we may change to take an array of handlers if needed
	//events: onNodeContextMenu, onNodeMouseEnter, onNodeMouseLeave, onNodeClick
	config: null,     
	_connectionHandles : null,

	DEFAULT_COLOR_DEFAULT: "#edf5ff",
	DEFAULT_COLOR_MAGENTA: "#fff0f7",
	DEFAULT_COLOR_COOLGRAY: "#dde1e6",
	DEFAULT_COLOR_GREEN: "#defbe6",
	DEFAULT_COLOR_CYAN: "#e5f6ff",
	DEFAULT_COLOR_PURPLE: "#f6f2ff",
	DEFAULT_COLOR_TEAL: "#d9fbfb",
	DEFAULT_COLOR_YELLOW: "#fcf4d6",

	DEFAULT_STROKE_DEFAULT: "#0f62fe",
	DEFAULT_STROKE_MAGENTA: "#9f1853",
	DEFAULT_STROKE_COOLGRAY: "#697077",
	DEFAULT_STROKE_GREEN: "#198038",
	DEFAULT_STROKE_CYAN: "#0072c3",
	DEFAULT_STROKE_PURPLE: "#8a3ffc",
	DEFAULT_STROKE_TEAL: "#007d79",
	DEFAULT_STROKE_YELLOW: "#684e00",
	
	/**
	 *  Constructor. Called after the widget is instantiated, but before any child dijits are displayed.
	 *	Use this code to mix in the template files for later use.
	 */
	constructor : function() {

		
		this._connectionHandles = [];
		//Load the template files.
		var templates = this.templates = new Templates();
		this.tooltip = new Tooltip();

		//Template graphics may have different server URLs depending on how the widget is packaged. 
		//Fix this here.
        this.iconURL = require.toUrl("com.ibm.bpm.wpd/images/BPD/");
        // remove build id when Dojo cacheBust is used
        if (window.dojoConfig && window.dojoConfig.cacheBust) {
	        if (this.iconURL.indexOf('?'+window.dojoConfig.cacheBust) > 0) {
				this.iconURL = this.iconURL.replace('?'+window.dojoConfig.cacheBust,'');
			}
		}

		//Check for older versions of IE. The templates need to be modified so we're doing server side rendering of their images.
//		var isLegacyBrowser = (has("ie") <= 8);

		//Older versions of IE may require special handling when we're rendering. 
		//Make a note of what we're targeting
//		var iid = ibm_ilog.diagram;
//		if ( iid.isSvgWeb )
//			this.renderingEngine = 'svgWeb';
//		else if ( iid.isVml )
//			this.renderingEngine = 'VML';
//		else if ( iid.isSilverlight )
//			this.renderingEngine = 'Silverlight';
//		//Note: Once we move to Dojo 1.7 we should look into supporting canvas as well.
//		else 
			this.renderingEngine = 'svg';

		//svgWeb (Flash) requires that the fonts be made bigger. Undo that for other browsers.
//		if ( !iid.isSvgWeb ){
			templates.activityTemplate.children[0].font.size='9pt';
			templates.activityTemplate.children[1].children[1].font.size = '9pt';
			templates.noteTemplate.children[1].font.size = '9pt';
			templates.complexEventTemplate.children[2].font.size = '9pt';
			templates.complexEventTemplate.children[0].font.size = '9pt';
//		}	

//		if ( iid.isSilverlight ){
//			this.iconSuffix = '.png';
//		}
//
//		if ( iid.isVml ){
//			templates.noteTemplate.children[1].shape.x = 0;
//			templates.noteTemplate.children[1].shape.y = 10;
//			templates.activityTemplate.children[1].children[1].shape.x = 40;
//
//		}

		//Disable touch support when using Flash. We don't support Flash on tablets.
//		if ( iid.isSvgWeb ){
//			ibm_ilog.diagram.mobileEnabled = false;
//		}
		
	},
	
	startup: function(){
	    console.log("*********** in BPDViewer::startup ***********");
		this.inherited(arguments);
		//TODO: Does it make sense for Victor's code to call onShow here?
	
	},
	
	/**
	 * Function called after the pane has been rendered. Dynamically create the view area, but not the vierwport.
	 */
	postCreate : function() {
		
		this.displayAll();
		this.inherited(arguments);
		this.applyZOrderRulesToGraph (this.ilogDiagrammer);

	},
	
	
	onShow: function(){
        try{  
            connect.publish("com.ibm.bpm.wpd.document.bpd.view.BPDViewer::onShow", this);
        } catch (e) {
            console.debug(e);
        }
	},


	/**
	 Adapter function to ensure that BPMNView and BPDViewer share the same set of interfaces
	 **/
	displayAll: function(){
		this.getData();
		
//		if ( this.serverSideImageRendering ){
//			this.displayImage();
//			this.connectImageZoomControl();
//			this.connectPrintButton();
//		}
//		
//		else
			this.displayEditor();
	},







	/*
		svgWeb (Using the Flash Player as an SVG rendering engine) has issues when destroyRecursive() is used to 
		dispose of the current stack container. Destroying the flash (ILog) diagrammer first ensures proper disposal 
		all connection handlers.
	 */
//	destroyFlashPlayer: function() {
//
//		//Flash player disabled for the moment. Just return;
//		return;
//
//
//		//Sanity check. Don't bother with this code if we're not running svgWeb
//		if ( ! has("ie")  ||  !this.renderingEngine == 'svgWeb')
//			return;	
//
//		//Remove all connect.connect() event handlers
//		try{
//			this._disconnectEventHandlers();
//		}catch( err ){
//			console.debug( "Error disconnecting event handlers: " + err.message );
//		}
//
//		//Remove the diagrammer
//		this.ilogDiagrammer.destroy();
//
//	},

	/**
	 Load the data, either from the enclosing framework or from the server.
	 **/
	getData: function(){
		//JSON data from the server
		var processData;


		if ( this.debug && this.restURL ){
			//Get all the dat from the server (Direct file read in this case).
			processData = this.getProcessVisualData();
		}else {
			//Get the server side data
			processData = this.viewStateModel.getDocumentModel();
		}

		//Save  pointer to the data for later use
		//this.data = processData;
		this.data = lang.clone( processData );
	},
	
	/**
	 * Display the editor contents
	 * Note: The viewport requires a parent widget with non-zero width and height when it's instantiated. 
	 		 Wait until the widget has been dynamically added to the parent ContentPane and brought to the front before
	 		 instantiating this code.
	 */
	displayEditor : function() {
		

		var processData = this.data;


		var dictionary = this.dictionary =  new Dictionary();

			//Load text positions for VML and Flash on IE 6 - 8
//			if ( processData.textPositions ){
//
//				var co_ords = processData.textPositions;
//				for ( var i = 0 ; i < co_ords.length; i++ ){
//					var item = co_ords[i];
//					for(var propertyName in item) {
//						var value = item[propertyName];
//
//						//Add the entry to the dictionary if it's not already there.
//						//If it's there, then we've got duplicate, possibly conflicting info. Toss the bad entry.
//						if ( dictionary.contains(propertyName) ){
//							dictionary.remove( propertyName );
//							
//						}
//						else{
//							
//							dictionary.add( propertyName, value );
//						}
//					}
//				}
//			}

//		if ( this.renderingEngine == 'VML' && this.serverSideTextRendering )
//			this.tweakXandYAttributes_SVG_VML( processData.items, dictionary );
//		else if ( this.renderingEngine == 'svg' || this.renderingEngine == 'Silverlight' || this.renderingEngine == 'VML'  )
			this.tweakXandYAttributes_SVG( processData.items, dictionary );
//		else if ( this.renderingEngine == 'svgWeb' )
//			this.tweakXandYAttributes_svgWeb( processData.items, dictionary );
//
//		 if ( this.renderingEngine == 'svgWeb' || this.renderingEngine == 'VML' && this.serverSideTextRendering == false ){
//		 	dojox.gfx.Text.textDictionary = dictionary;
//		 }



		//Pre-processing. Add 'highlight links' when critical path data exists
		this.genCriticalPathLinks( processData.links );

		//Seperate out the node data
		var nodesJSON = new Object();
			nodesJSON.label = 'label';
			nodesJSON.identifier = 'id';
			nodesJSON.items = processData.items;
		
		
		//And the links
		var linksJSON = new Object(); 
			linksJSON.items = processData.links;
			linksJSON.identifier = 'id';
			
		
		var linkStore = new ItemFileWriteStore({
			data: linksJSON
		});
			

		//Load it into memory.
		var store = new ItemFileWriteStore({
					data: nodesJSON
		});

		
		//Only display the overview for chrome and FF. Too slow for legacy IE.
		//
		// take out the pan/scan box
//		var overviewEnabled = !dojo.isIE;    
		var overviewEnabled = false;

		
         //Instantiate the viewer.
    	var params = this._getEditorParams(store, linkStore, overviewEnabled);
	
//    	//Turn off link rendering until it's ready.
//    	if ( !linkStore  ){
//    		delete params.linkLayoutActive;
//    		delete params.linksStore;
//    		delete params.linksQuery;
//    		delete params.linksGraphProperties;
//    		delete params.linksGraphBinding;
//    		delete params.startNodeBinding;
//    		delete params.endNodeBinding;
//    	}
    	
    	
//       if ( this.ilogDiagrammer ){
//
//			var diagram = this.ilogDiagrammer;
//
//			diagram.set("nodesStore", store);
//			diagram.set("linksStore", linkStore);
//			
//			diagram.load();       		
       	
//       }else{	

	       /*var bpmnEditor =*/ this.ilogDiagrammer = this.createILogWidget( params );

	       if (this.hideSideContainer || this.config.hideSideContainer) {
	           this.zoomSliderContainer.style.display = "none";
	       } else {
    	       if ( this.zoomSlider ){
    	           this.connectZoomControl();
    	       }
    
    	       if ( this.printButton ){
    	           this.connectPrintButton();
    	       }
	       }

	       
	       //Force svgWeb to repaint the screen every time the window is resized.
	       //This eliminates a class of bugs where resize changes the client area, but doesn't
	       //seem to cause the diagram to repaint properly.
//			connect.connect(window,"resize",function(n){
//		
//	  			window.setTimeout(function() {
//	  				if ( ibm_ilog.diagram.isSvgWeb ){
//		            		svgweb._onWindowResize();
//		            	}
//	                },1);
//			});
			

       
//   		}
 	  
		this._connectEventHandlers();

	},
	
	  /**
	  * Applies z-order rules to the diagram. The ordering (from bottom to top) is:
      * swimlanes
      * milestones
      * notes
      * groups
      * non-note nodes
      * boundary events
      * links
      * @param ilogDiagrammer: required - The iLog diagram.
      */
     applyZOrderRulesToGraph: function (ilogDiagrammer) {
          console.log("BPDViewer applyZOrderRulesToGraph begin");
          var partitionedElements = this.partitionGraphElements (ilogDiagrammer);

          // Get all the swimlanes and push them to the front
          var swimlanes = partitionedElements.swimlanes;
          for (var i = 0; i < swimlanes.length; i ++) {
              swimlanes[i].moveToFront();
          }
          // Get all the milestones and push them to the front
          var milestones = partitionedElements.milestones;
          for (var i = 0; i < milestones.length; i ++) {
              milestones[i].moveToFront();
          }

          // Get all notes and push them to the front
          var notes = partitionedElements.notes;              
          for (var i = 0; i < notes.length; i ++) {
              notes[i].moveToFront();
          }
          // Get all groups and push them to the front
          var groups = partitionedElements.groups;
          for (var i = 0; i < groups.length; i ++) {
              groups[i].moveToFront();
          }
          // Get non-note nodes and push them to the front
          var nodes = partitionedElements.nodes;
          for (var i = 0; i < nodes.length; i ++) {
              nodes[i].moveToFront();
          }
          // Get boundary events and push them to the front
          var boundaryEvents = partitionedElements.boundaryEvents;
          for (var i = 0; i < boundaryEvents.length; i ++) {
              boundaryEvents[i].moveToFront();
          }
          // Get all links and push them to the front
          var links = partitionedElements.links;
          for (var i = 0; i < links.length; i ++) {
              links[i].moveToFront();
          }
          console.log("BPDViewer applyZOrderRulesToGraph end");
     },

     /**
      * Partitions the node and link store into z-order categories. Returns a structure as follows:
      * elems.swimlanes = [];
      * elems.milestones = [];
      * elems.notes = [];
      * elems.groups = [];
      * elems.nodes = [];
      * elems.boundaryEvents = [];
      * elems.links = [];
      * Each element in the array is the corresponding gfx object to the item from the store.
      * @param ilogDiagrammer: required - The iLog diagram.
      */
     partitionGraphElements: function (ilogDiagrammer) {
          var elems = {};
          elems.swimlanes = [];
          elems.milestones = [];
          elems.notes = [];
          elems.groups = [];
          elems.nodes = [];
          elems.boundaryEvents = [];
          elems.links = [];

          ilogDiagrammer.nodesStore.fetch ({
              query: {},
              onItem: lang.hitch (this, function (item, request) {
                  var type = item.type[0];
                  var gfxNode = ilogDiagrammer.asGraphElement (item);
                  if (gfxNode) {
                      switch (type) {
                        case 'swimlane':
                            elems.swimlanes.push (gfxNode);
                            break;
                        case 'milestone':
                            elems.milestones.push (gfxNode);
                            break;
                        case 'note':
                            elems.notes.push (gfxNode);
                            break;
                        case 'group':
                            elems.groups.push (gfxNode);
                            break;
                        default:
                            if (type.indexOf("Boundary") !== -1) {
                                elems.boundaryEvents.push (gfxNode);
                            } else {
                                elems.nodes.push (gfxNode);
                            }
                            break;
                      }
                  }
              })
          });

          ilogDiagrammer.linksStore.fetch ({
              query: {},
              onItem: lang.hitch (this, function (item, request) {
                  var gfxNode = ilogDiagrammer.asGraphElement (item);
                  if (gfxNode) {
                      elems.links.push (gfxNode);
                  }
              })
          });

          return (elems);
      },


	/**
	 * Provide the params when creating the widget. This allows for subclasses to customize the parameters without having to rewrite the
	 * displayEditor function.
	 * @param store
	 * @param linkStore
	 * @param overviewEnabled
	 * @returns {___anonymous11047_12514}
	 */
	_getEditorParams: function(store, linkStore, overviewEnabled) {
		var params =
		{
            nodesStore: store,
            nodesQuery:{id:'*'},
            nodesQueryOptions: {
                deep: true
            },
			childBinding: "children",
			successorsBinding: "successors",
			xBinding: "x",
			yBinding: "y",
			createLinksForHierarchy: false,
			createSubgraphFunction: lang.hitch( this, 'createSwimLane' ),
			createNodeFunction: lang.hitch( this, 'createNode' ),
			
			linkLayoutActive: false,
			linksStore:linkStore,
			linksQuery:{id:'*'},
            linksGraphBinding: "gfx",
            linksGraphProperties: "intermediatePoints",
            startNodeBinding: "start",
            endNodeBinding: "end",
            selectionMode: ibm_diagram_base.Selection.gfx_multi,
  			nodeMenu: null,
				
			linkStyle: {shapeType: ibm_diagram_base.LinkShapeType.OrthogonalEditable, strokeWidth:1, strokeColor: 'gray' },
			onLinkCreated: lang.hitch( this, 'onLinkCreated' ),
			onNodeCreated: lang.hitch( this, 'onNodeCreated' ),
			
			linkTemplateFunction: lang.hitch( this, "getLinkTemplate" ),
			
			nodeTemplateFunction: lang.hitch( this, 'getNodeTemplate' ),
			onLoaded: function() { 
				Batch.endBatch();
				try{  
//					connect.publish("com.ibm.bpm.wpd.document.bpd.view.BPDViewer::loaded", this);
				} catch (e) {
				    console.debug(e);
				}
			},
			overview : overviewEnabled,
			move: false
		};
		
		return params;
	},

	/**
	 * Set the viewStateModel for this viewer
	 * @param viewStateModel
	 */
	setViewStateModel : function(viewStateModel) {
		this.viewStateModel = viewStateModel;
		if (!!this.viewStateModel && !!this.viewStateModel.zoomLevel) {
		    this.zoomLevel = this.viewStateModel.zoomLevel;
		}
	},

	reset: function(){
		var diagram = this.ilogDiagrammer;
		diagram.reset();
	},

	_connectEventHandlers: function(){

		if(!!this.config)	{

			if (!!this.config["onMouseMove"]){
				this._connectionHandles.push(connect.connect(this.ilogDiagrammer, "onMouseMove", null, this.config["onMouseMove"]));  
			}

			if (!!this.config["onNodeContextMenu"]){
				this._connectionHandles.push(connect.connect(this.ilogDiagrammer, "onNodeContextMenu", null, this.config["onNodeContextMenu"]));  
			}
	 	   
			if (!!this.config["onNodeMouseLeave"]){
				this._connectionHandles.push(connect.connect(this.ilogDiagrammer, "onNodeMouseLeave", null, this.config["onNodeMouseLeave"]));  
			}
		 
			if (!!this.config["onNodeMouseEnter"]){
				this._connectionHandles.push(connect.connect(this.ilogDiagrammer, "onNodeMouseEnter", null, this.config["onNodeMouseEnter"]));  
			}
		 
			if (!!this.config["onNodeClick"]){
				this._connectionHandles.push(connect.connect(this.ilogDiagrammer, "onNodeClick", null, this.config["onNodeClick"]));  
			}
			
		}
		
		// Remove when scrolling is fixed by iLog
		if (has("chrome")) {
			this._connectionHandles.push(connect.connect(this.ilogDiagrammer.getViewport(), "onViewRectChanged", this, "scrollbarFix"));
		}
	},

	/**
	 Remove all registered event handlers.
	 **/
	_disconnectEventHandlers: function(){
		
		for ( var i = 0; i < this._connectionHandles.length; i++) {
			if(!!this._connectionHandles[i]){
				connect.disconnect(this._connectionHandles[i]);
			}
		}

		this._connectionHandles = [];

	},
	
	destroy: function(){

		//No tear down necessary for IE. We're using images. 
		//Standard JavaScript collection will fix them.
//		if (! this.serverSideImageRendering  ){
		
			try{
				this._disconnectEventHandlers();
			}catch( err ){}
	
			if( this.ilogDiagrammer )
				this.ilogDiagrammer.destroy();

//		}
		
		this.inherited(arguments);
	
	},

	/**
	 Hook up print functionality
	 **/
	 connectPrintButton: function(){
		 
		 //debugger;
		 //if ( dojo.isIE ){
			 var handle = connect.connect( this.printButton, 'onClick', function() { window.print(); } );
		 // }else{
			//  this.printButton.diagram = this.ilogDiagrammer;
			// var handle = connect.connect( this.printButton, 'onClick', lang.hitch( this, 'actionPrint'));
		 // }
		 
	 },

	 /**
	 	Hook up the zoom control when there's an image used to display the process data.
	  **/
//	 connectImageZoomControl: function(){
//	 
//	 	   this.zoomSlider.viewer =  this;
// 	   	   var handle = connect.connect( this.zoomSlider, "onChange", function(evt){
//			
//			//Find the image
//			var editor = this.viewer.editorPane;
//			var image = query( 'img', editor )[0];
//
//			//Work out the scaling factor. Zooming goes in a straight line from 25% to 100%
//
//		   	//Figure out what the zoom level is for 'shrink to fit'
//		   	if ( this.viewer.editorContainer ) {
//		   		var scalingFactor = Math.min( 
//		   				(this.viewer.editorContainer.h - 20) / this.viewer.data.height, 
//		   				(this.viewer.editorContainer.w - 20) / this.viewer.data.width,
//		   				this.viewer.data.height / (this.viewer.editorContainer.h - 20), 
//		   				this.viewer.data.width / (this.viewer.editorContainer.w - 20));
// 	   	   } 
//		   	else {
//		   		var scalingFactor = Math.min( 
//		   				(this.viewer.bpmnInspector.offsetHeight - 20) / this.viewer.data.height, 
//		   				(this.viewer.bpmnInspector.offsetWidth - 20) / this.viewer.data.width ,
//		   				this.viewer.data.height / (this.viewer.bpmnInspector.offsetHeight - 20), 
//		   				this.viewer.data.width / (this.viewer.bpmnInspector.offsetWidth - 20) );
//		   	}
//		   		
//		   	var scaling =  ((1-scalingFactor)/9) * evt + (1-10*scalingFactor)/(-9);
//
//			//var scaling = .075 * evt + .25;
//				
//			//Original width 
//			var h = image.offsetHeight;
//			var w = image.offsetWidth;
//
//			//Translate that into pixels
//			var width = Math.round( this.viewer.data.width * scaling ) + "px";
//			var height = Math.round( this.viewer.data.height * scaling ) + "px";
//
//			image.style.height  = height;
//			image.style.width = 'auto';			//There seems to be a bug with image width from the server. Let the browser do the math.
//
//			var events=['start', 'adhocStartEvent', 'timerStartEventInterrupting', 'timerStartEventNonInterrupting', 'msgStartEventNonInterrupting', 'errorStartEvent', 'intermediateEvent', 'intermedCatchMsgEventNonBoundary', 'intermediateMessage', 'intermedCatchMsgEventNonBoundary', 'intermedCatchTrackingEventNonBoundary' , 'intermediateThrowMsgEvent', 'stop', 'end', 'endException', 'errorEndEvent', 'timer' , 'intermedCatchTimerEventNonBoundary' ,  'terminate', 'messageEndEvent', 'gateway', 'gatewayEvent' , 'gatewayAnd' ,  'gatewayOr'];
//
//			//Speculative... 
//			var divs = query( 'div', editor );
//			for ( var i = 0; i < divs.length; i++ ){
//			
//				var div = divs[i];
//				var id = div.getAttribute( 'name');
//
//				var item = this.viewer.IDtoItemMap.item( id );
//
//				var location = this.viewer.getActivityLocation( id );
//				console.debug( "Node: " + item.label + " is at: " + location.x + "/" + location.y );
//				
//				if ( array.indexOf(events, item.type) ==  -1  ){
//					//Handle activities
//					div.style.top = Math.round( location.y * scaling ) + "px";
//					div.style.left = Math.round( location.x * scaling ) + "px";
//					div.style.width = Math.round( 95 * scaling ) + "px";
//					div.style.height = Math.round( 70 * scaling ) + "px";
//				}else{
//					//Handle gateways and events
//					div.style.top = Math.round( location.y * scaling ) + "px";
//					div.style.left = Math.round( ( location.x + 15 ) * scaling ) + "px";
//					div.style.width = Math.round( 32 * scaling ) + "px";
//					div.style.height = Math.round( 32 * scaling ) + "px";
//				}
//			}
// 	   	   		
// 	   	   });
//
//	 },
	 
	 
	 zoomTriggered: function() {
		 //To be subclassed. Do nothing here, probably will remove after I1
	 },
	 

	//Hook up the zoom control so it can resize the editor
	 connectZoomControl: function(){
//		 this.zoomSlider.diagram =  this.ilogDiagrammer;
//		 var viewer = this;
		 var handle = connect.connect( this.zoomSlider, "onChange", this, this.setZoom);

		 this._connectionHandles.push( handle );
	 },

    /**
     * Set the zoom level to display the diagram at.
     * @param: zoomLevel - a value between 1-10.
     */
	 setZoom: function(zoomLevel) {

         //Find the active diagram
         var diagram = this.ilogDiagrammer;

         //The slider should allow the user to toggle between 100% zoom and 'shrink to fit'
         var graph = diagram.getGraph();
         var box = graph.getBoundingBox();

         var vSize = diagram.getViewport().getClientSize();

         //Figure out what the zoom level is for 'shrink to fit' 
         var scalingFactor = Math.min( 
                 vSize.height / box.height, 
                 vSize.width / box.width, 
                 box.height / vSize.height, 
                 box.width / vSize.width );

         //For now, assume that the horizontal slider goes from 1 to 10
         //Do some math to ensure that maps to the correct zoom range
         var zoomFactor =  ((1-scalingFactor)/9) * zoomLevel + (1-10*scalingFactor)/(-9);

         console.debug( "Zoom to: " + zoomFactor );
         
         this.zoomLevel = zoomFactor;

         var V = diagram.getViewport();
         var currentZoom = V.getZoom();
         console.debug( "Current Zoom is: " + currentZoom );

         V.setAnimated(true);

         diagram.set('overviewSize', {
             width: 120,
             height: 70
         });
         V.setHudEnabled(true);

         V.setZoom(zoomFactor, {});
         this.zoomTriggered();

     },

	

	/**
		The server assumes that items are places with the x & y co-ordinates representing the upper left location of the base shape.
		ILog uses the entire graph, which for events can shrink or expand as text is added to the node.
		Walk the list of items tweaking the x & y co-ordinates to accomodate this.
	 **/ 
	tweakXandYAttributes_SVG: function( items, dictionary ){

		for ( var i = 0; i < items.length; i++ ){
			var item = items[i];

			var type = item.type;
			var label = item.label;
			//debugger;

			//Co-ordinate transformation is only necessary for events. Ignore everything else
			if (  item.type == 'note' || item.type == 'milestone'  || item.type == 'group'){
				continue;
			}
			else if ( item.type == 'swimlane'){
				this.dictionary.remove( label );
			
			}
						
			else if (item.category == 'BoundaryIntermediateEvent' ){
				if ( item.counter )
					item.y = item.y -15;

				delete item.label;
			}
			else if ( item.type == 'activity' ){
				//Move the node up to compensate for the text being added to the top of the node
				if ( item.counter && this.renderingEngine == 'Silverlight'){
					item.y = item.y - 21;
				}
				else if ( item.counter && this.renderingEngine == 'VML' )
					item.y = item.y - 10;
				else if ( item.counter ){
					item.y = item.y - 17.3;
				}
				
			}
			else if ( type == 'gateway' || type == 'gatewayOr' || type == 'gatewayAnd'  || type == 'gatewayEvent'){
				if(this.data.modelType != "bpmn") {
					item.x = item.x+13;
				}
				item.y = item.y;
			}
			else{
				var x = item.x;
				var y = item.y;
				
				//console.warn("item.label(1): ",item.label);
				
				var labels = lang.isArray(item.label) ? item.label : item.label.split( "\n");

				//Add offset for counter labels
				if ( item.counter ){
					item.y = item.y -15;
				}

				//Assume each line of text is fifteen pixels tall and adjust the y value
				var yDelta = 15 * (labels.length  / 2);
				//item.y = item.y - yDelta;
				//item.y = item.y +3;

				var node_width = 24;

				//Assume each node is 24 pixels wide and check for labels that are larger than that.
				for ( var i2 = 0; i2 < labels.length; i2++ ){
					var text = labels[i2];
					var bounds = dictionary.item( text );

					//Sanity check...
					if ( !bounds )
						continue;

					node_width = Math.max( bounds.width, node_width );
				}

				var xDelta = (node_width - 24 ) / 2;
				if(this.data.modelType != "bpmn") {
					item.x = item.x - xDelta +22;
				}

				//console.debug( "Setting " + item.label + ", of type " + item.type + ", to be (" + item.x + "/" + item.y +") with deltas of (" + xDelta + "/" + yDelta +")" );
				//debugger;
			}

		}
				
	},


	/**
		Same logic as the SVG transform code but take into condsideration the new graphic labels.
	 **/ 
//	tweakXandYAttributes_SVG_VML: function( items, dictionary ){
//
//		for ( var i = 0; i < items.length; i++ ){
//			var item = items[i];
//
//			var type = item.type;
//			var label = item.label;
//
//			//Co-ordinate transformation is only necessary for events. Ignore everything else
//			if (  item.type == 'note' || item.type == 'milestone'  || item.type == 'group'){
//				continue;
//			}
//			else if ( item.type == 'swimlane'){
//				this.dictionary.remove( label );
//			
//			}
//			else if (item.category == 'BoundaryIntermediateEvent' ){
//				if ( item.counter )
//					item.y = item.y -15;
//
//				delete item.label;
//			}
//			else if ( item.type == 'activity' ){
//				//Move the node up to compensate for the text being added to the top of the node
//				 if ( item.counter )
//					item.y = item.y - 10;
//							
//			}
//			else if ( type == 'gateway' || type == 'gatewayOr' || type == 'gatewayAnd'  || type == 'gatewayEvent'){
//				item.x = item.x+3;
//			//	item.y = item.y;
//			}
//			else{
//				// var x = item.x;
//				// var y = item.y;
//				// var labels = item.label.split( "\n");
//
//				// //Add offset for counter labels
//				// if ( item.counter ){
//				// 	item.y = item.y -15;
//				// }
//
//				
//
//				// //Assume each line of text is fifteen pixels tall and adjust the y value
//				// var yDelta = 15 * (labels.length  / 2);
//				// //item.y = item.y - yDelta;
//				// //item.y = item.y +3;
//
//				// var node_width = 24;
//
//				// //Assume each node is 24 pixels wide and check for labels that are larger than that.
//				// for ( var i2 = 0; i2 < labels.length; i2++ ){
//				// 	var text = labels[i2];
//				// 	var bounds = dictionary.item( text );
//
//				// 	//Sanity check...
//				// 	if ( !bounds )
//				// 		continue;
//
//				// 	node_width = Math.max( bounds.width, node_width );
//				// }
//
//				// var xDelta = (node_width - 24 ) / 2;
//				// item.x = item.x - xDelta +22;
//
//				// //console.debug( "Setting " + item.label + ", of type " + item.type + ", to be (" + item.x + "/" + item.y +") with deltas of (" + xDelta + "/" + yDelta +")" );
//				// //debugger;
//			}
//
//		}
//				
//	},

	/**
		The server assumes that items are places with the x & y co-ordinates representing the upper left location of the base shape.
		ILog uses the entire graph, which for events can shrink or expand as text is added to the node.
		Walk the list of items tweaking the x & y co-ordinates to accomodate this.
	 **/ 
//	tweakXandYAttributes_svgWeb: function( items, dictionary ){
//		
//		for ( var iCtr = 0; iCtr < items.length; iCtr++ ){
//
//			var item = items[iCtr];
//
//			var type = item.type;
//			//Gateway icons never seem to be in the right place. Tweak the placement for better graph layout.
//
//	
//			if ( item.type == 'note' || item.type == 'milestone' || item.type == 'swimlane' || item.type == 'group' ){
//				//Do nothing...
//			}else if (  item.category == 'BoundaryIntermediateEvent' ){
//				if ( item.counter ){
//					item.y = item.y -15;
//					item.x = item.x -20;
//				}
//
//				delete item.label;
//			}
//			
//			else if ( item.type == 'activity' ){
//				if ( item.counter )
//					item.y = item.y - 15;
//			}
//			else if ( type == 'gateway' || type == 'gatewayOr' || type == 'gatewayAnd' || type == 'gatewayEvent'){
//				item.x = item.x + 5;
//				//item.y = item.y +4;
//			}else{
//				//Event icons. 
//				if ( item.counter )
//					item.y = item.y - 16;
//			}
//						
//
//			if ( !item.label )
//				continue;
//			
//			var labels = item.label.split( "\n");
//			
//			
//			for ( var i = 0 ; i < labels.length; i++ ){
//
//				var text = labels[i];
//
//
//				if ( !text || text.length == 0 )
//					continue;
//
//				var bounds = dictionary.item( text );
//
//				if ( !bounds )
//					continue;
//
//				if ( item.type == 'activity' ){
//
//
//					bounds.x = -19;
//					bounds.y = -2 + (i * 15.33);
//
//					bounds.width = 68;
//					bounds.height = 15.33;
//				}
//				else if ( item.type == 'note' ){
//
//					bounds.x = 20;
//					bounds.y = -3 + ( i * 15.33);
//					bounds.width = 68;
//					bounds.height = 15.3;
//					console.debug( "Setting note text: '" + text + "' to be: " + json.toJson( bounds) );
//				}
//				else if ( item.type == 'milestone' || item.type == 'swimlane' || item.category ==  'BoundaryIntermediateEvent' ){
//					//No processing needed. (TODO: double check that for milestones)
//					continue;
//				}
//				else{
//					//Events..
//					bounds.x = -34;
//					bounds.y = -13 + ( i* 15.3 );
//					bounds.width = 68;
//					bounds.height = 15.3;
//				}
//
//				dictionary.add( text, bounds );
//			}
//			
//		}
//				
//	},

	/**
	 Critical path links are supposed to be rendered as a blue link with a blue 'halo' behind them. 
	 There's no easy way to do this on ILog, go find the affected links and generate a second link for the halo
	 effect.
	 **/
	genCriticalPathLinks: function( links ){

		var updates = [];
		
		if ( !links || links.length == 0 )
			return;

		for ( var i = 0; i < links.length; i++ ){
			var link = links[i];
			
			if ( link.inCriticalPath ){
				var hLink = lang.clone( link );
				hLink.highlight = true;
				hLink.id = link.id + "_highlight";
				delete hLink.inCriticalPath;
				updates.push( hLink );
			}

		}


		for ( i = 0; i < updates.length; i++ ){
			links.splice( 0, 0, updates[i] );
		}

	},


	/**
	 Instantiate the ILog widget to displayt the graph contents
	 **/
	createILogWidget: function(params){
		
		var widget = this.ilogDiagrammer = new Diagram( params, this.editorPane );	
        widget.startup();
        widget.domNode.style.height = "100%";
        widget.resize();
        widget.getInteractor("wheelPan").setEnabled(false);
        widget.getInteractorManager().add("wheelPan", new BPDWheelPanInteractor().initialize(widget));
        widget.getInteractor("wheelPan").activate();
		
		//Event hook. Allow external callers to register a callback that will be invoked
		//Once the diagram is fully loaded into memory.
		//Note: This routine works well with svgWeb, but doesn't usually fire with svg.
		//		Modern browsers are simply to fast. Rendering completes before this line is 
		//		executed.
//        connect.connect( widget, "onLoaded", lang.hitch( this, function(){
//			
//			if ( this.onDiagramLoad )
//				this.onDiagramLoad(this.viewStateModel.type);
//
//
//			if ( this.mainBC )
//				this.mainBC.resize();
//
//			/*
//			if ( ibm_ilog.diagram.isSvgWeb ){
//
//				window.setTimeout(function() {
//	  			   		svgweb._onWindowResize();
//		         },1);
//			
//			}
//			*/
//		}));

		//Force a resize event once the window has finished rendering. Required to get scrollbars to show up properly.
//		window.setTimeout( lang.hitch( this, function(){
//			this.ilogDiagrammer.resize();
//		}), 1);
		
		//this.a11y();
		return widget;
	},

    a11y: function() {//Accessibility - Fix RPT violation
        if (this.zoomSliderContainer && this.zoomSliderContainer.firstChild && this.zoomSliderContainer.firstChild.nextSibling) {
            if (this.zoomSliderContainer.firstChild.nextSibling.nodeName.toUpperCase() == 'TABLE') {
                wai.setWaiRole(this.zoomSliderContainer.firstChild.nextSibling,"presentation");
            }
        }
        query(".dijitSlider").forEach(function(node, index, arr){
              if (node.nodeName && node.nodeName.toUpperCase() === 'TABLE') {
                  wai.setWaiRole(node,"presentation");
              }
          });
    },

	/**
	 * Debug: Load the input data from a file on the server.
	 */
	getProcessVisualData: function(){
		
		var nodes;

		var url = "HRSample2.json";
		if ( this.restURL )
			url = this.restURL;

		
		var xhrArgs = {
                url: url,
                handleAs: "json",
                headers: {"Accept": "application/json" },
                sync: true,
                load: function(data) {
                	
                	if ( data.data )
                		nodes = data.data;
                	else
                		nodes = data;
                
                },
                error: function(error) {
                    alert( error );
                }
            }

            //Call the asynchronous xhrGet
            var deferred = xhr.get(xhrArgs);
            return nodes;
		
		
	},
	
	
	
	/**
	 Code to create a swim lane.
	 @param: item - Dojo data item with key / value pairs describing the location and size of the lane.
	 @param: template - Location of code to use when generating the shape of the swim lane.
	 @param: graph: Drawing surface.
	 @param: diagram - DiagramEditor object
	 **/
	 createSwimLane: function(item, template, graph, diagram) {

		var t = this.templates.HPoolTemplate;

		//Set swimlane background color to white by default
		var colorCode = "#F8F8F8";

		//Override the default, if necessary
		if ( item.color ){
			var colorCode = this.getHTMLColorCode( item );
			t[0].children[3].fill = colorCode;
		}

		t[0].children[3].fill = colorCode;

		var swimlane = diagram.createTemplatedShape(SwimLane, t, graph, {
			vertical: false,
			rightToLeft: false
		}, diagram.nodesStore, item);
		

		var width = item.width[0];
		var height = item.height[0];
		swimlane.setExplicitSize({
			width: width,
			height: height
		});
		
		/*
		var x = diagram.nodesStore.getValue(item, "x");
		var y = diagram.nodesStore.getValue(item, "y");
		swimlane.move(x, y);
		*/

		//We've changed the width of the swimlane, preserve that in the model for future reference
		diagram.nodesStore.setValue( item, 'width', width );

		//Back pointer to the containing diagram for future work
		swimlane.diagram = diagram;

		return swimlane;
	},

	/**
	 *  Translate an item's WLE color code into HTML
	 */
	getHTMLColorCode: function( item ){
			var code = '#f8f8f8';		//default white

			var color = item.color[0].toLowerCase();

	   		if ( color == 'green')
	   			code = '#ccffcc';
	   		else if ( color == 'blue')
	   			code = '#ccffff';
	   		else if ( color == 'purple' )
	   			code = '#ffccff';
	   		else if  ( color == 'red' )
	   			code = '#f7dbdb';
	   		else if ( color == 'orange' )
	   			code = '#ffead3';
	   		else if ( color == 'yellow' )
	   			code = '#fffdd3';
	   		else if ( color == 'gray' )
	   			code = '#c4c7b9';
	   		else if ( color == 'default' && item.isSystem && item.isSystem[0] )
	   			code = "#F6F6F6";
	   		else if (color != null)
				code = color || '#f8f8f8';
			
	   		return code;
	},
	
	
	 /**
	  * Call back function invoked when a new node is created to return the correct templated shape.
	  * 
	  * @param item
	  * @param template
	  * @param graph
	  * @param diagram
	  * @returns The correct templated shape.
	  */
	createNode: function(item, template, graph, diagram){
		
		var shape;

			//Special handling for empty swim lanes. 
			//ILog assumes they're nodes. We need to specify otherwise.
			if ( item.type[0] == 'swimlane' ){
				shape = this.createSwimLane(item, template, graph, diagram);
			}
			else{
				shape =  diagram.createTemplatedShape(Node, template, graph, diagram.nodeStyle, diagram.nodesStore, item);
			}

			return shape;
	},


	/**
	 * Function callback for when a node is created.
	 * Perform processing that requires the node exist, but not necessarily be visible just yet.
	 * @param node
	 */
	 onNodeCreated: function( node ){

	 	var item = node._data.item;
	 	
	 	//Node id
		var id = item.id[0];

		//Add event handler for drill down
	 	try{

	 		//If there's extra 'config' handlers then we're iBPM or Process Portal. Only drill down for Event Subprocess or Linked Sub-Process nodes
			var implType = item.bpmn2TaskType ? item.bpmn2TaskType[0] : "n/a";
			var isPortalNode  = (( implType == 'Event_SubProcess' || implType == 'CalledProcess' ||  implType == 'SubProcess'  ) && this.config && item.poId );
			var isViewerNode = ( item.poId && !this.config );

			// Temporary logic, to disable drill-down into a coach flow
			var isCoachFlow = false;
			if (item.poType && item.poType[0]==='Service' && item.serviceType && item.serviceType[0]==='Coach Flow') {
				isCoachFlow = true;
			}
			
			var label = item.label[0];
			
			if(has("ie") && this.config && this.config["onNodeContextMenu"]){
				/*
				 * IE9 does not handle events as expected in normal SVG viewing.  We need
				 * to hook into these event handlers to pass up the correct Node information
				 * to display the correct context-menu.  Left-click events bubble up fine, however
				 * by default, right-click events still show the page level browser-provided context menu.
				 * In Particpants (a process diagram consumer), we look for this window variable, and if set,
				 * use it's values to simulate the expected right-click event supported in other browsers.
				 */
				
				this._connectionHandles.push( node.connect("onmouseover", this, function(){
					//console.warn("setting window.currentDiagrammerNode");
		 			window.currentDiagrammerNode = node;
				}));
		 		
		 		this._connectionHandles.push( node.connect("onmouseout", this, function(){
		 			//console.warn("clearing window.currentDiagrammerNode");
	 				window.currentDiagrammerNode = null;
		 		}));
			}
			if ( node.subProcessIcon && item.label[0].lastIndexOf("EXECUTING")<0 && implType == 'CalledProcess'){
				this._connectionHandles.push( node.subProcessIcon.connect("onmouseover", this, "showCalledProcessTooltip"));
				this._connectionHandles.push( node.subProcessIcon.connect("onmouseout", this, "hideTooltip"));
			}
			if ( node.subProcessIcon && item.label[0].lastIndexOf("EXECUTING")<0 && implType == 'SubProcess'){
				this._connectionHandles.push( node.subProcessIcon.connect("onmouseover", this, "showSubProcessTooltip"));
				this._connectionHandles.push( node.subProcessIcon.connect("onmouseout", this, "hideTooltip"));
			}
			if ( node.iconPrecondition){
				this._connectionHandles.push( node.iconPrecondition.connect("onmouseover", this, "showPreconditionTooltip"));
				this._connectionHandles.push( node.iconPrecondition.connect("onmouseout", this, "hideTooltip"));
			}
			if ( node.iconManual){
				this._connectionHandles.push( node.iconManual.connect("onmouseover", this, "showManualTooltip"));
				this._connectionHandles.push( node.iconManual.connect("onmouseout", this, "hideTooltip"));
			}
			if ( node.iconRepeating){
				this._connectionHandles.push( node.iconRepeating.connect("onmouseover", this, "showRepeatableTooltip"));
				this._connectionHandles.push( node.iconRepeating.connect("onmouseout", this, "hideTooltip"));
			}			
			
		 	if ( isViewerNode || isPortalNode ){

		 		if (!isCoachFlow) {		// Temporary check, to disable drill-down into a coach flow. To be re-enabled at a future time.
			 		this._connectionHandles.push( node.connect("onclick", node, this.drillDown) );

			 		var viewer = this;
			 		// Add a keyboard event to listen for the enter key to allow drill down. I'm guessing this could be doen with
			 		// an interactor, I'm just not sure hot to use them. As well I'd like to trigger the even for the node only (no global)
			 		// but that doesn't appear to be working
			 		this._connectionHandles.push(connect.connect("onkeypress", node, function(e){
			 			if (e.type == "keypress") {
			 				var keyPressedValue = e.which ? e.which : e.keyCode;
			 				if (keyPressedValue != keys.ENTER) {
			 	 				return;
			 	 			}
			 				var tData = this.viewer.ilogDiagrammer.getFocusedElement()._data;
			 				if (tData.item.id[0] != this._data.item.id[0])
			 					return;
			 			}
			 			viewer._data = this._data;
			 			viewer.drillDown(e);
			 		}) );
			 		
			 		this._connectionHandles.push( node.connect("onkeyup", node, this.drillDown) );
			 		this._connectionHandles.push( node.connect("onkeydown", node, this.drillDown) );

			 		//if (  this.renderingEngine  != 'svgWeb'){
				 		
				 		this._connectionHandles.push( node.connect("onmouseover", this, function(){
				 			document.body.style.cursor = 'pointer';
				 		}));
				 		
				 		this._connectionHandles.push( node.connect("onmouseout", this, function(){
				 			document.body.style.cursor = 'default';
				 		}));

			 		//}		 			
		 		}

		 	}else if ( this.config && item.counter ){
		 		//Active node for Process Portal. Update the cursor to make it clear
					this._connectionHandles.push( node.connect("onmouseover", this, function(){
			 			document.body.style.cursor = 'pointer';
			 		}));
			 		
			 		this._connectionHandles.push( node.connect("onmouseout", this, function(){
			 			document.body.style.cursor = 'default';
			 			
			 		}));		 		
		 	}
/*
		 	var dir =  BidiUtils.getDirValue(label);
			if (dir=="rtl") {
				this.modifyTextDir(node);
			}
*/
		}catch( err ){
			console.debug( "Exception (" + err.message + ") connecting to node ("  + node._label + ") for drill down.");
		}
		
		/**
		 Silverlight doesn't offer a context menu hook for the diagram, but it does have one for individual node GEs. 
		 Register that here for active nodes, when necessary. 
		 **/
		if ( this.config && this.config["onNodeContextMenu"] && item.counter && this.renderingEngine == 'Silverlight'){
			console.debug( "Connecting RC handler to node: " + item.label[0] );
			node.connect(  "MouseRightButtonDown", node, this.config["onNodeContextMenu"] );
		}

		//Event group images are always at the back. Make sure this happens.
		var type = item.type[0];
		if ( type == 'group'){
			node.moveToBack();
		}
		
		//If this is an active task, then save a flag for further reference.
		if ( this.data.activeTasks && this.data.activeTasks[id] ){
			node.isActive = true;
		}

		//Save a backpointer to the BPDViewer code so event handlers can get access to the diagram and/or data
		node.viewer = this;

	},
	
	/**
	 * Modify the text direction given a node.
	 * @param node
	 */
	modifyTextDir: function(node) {
		if (node.textShape) {
			if (node.textShape.children) {
				for (var i=0; i<node.textShape.children.length; i++) {
					if (node.textShape.children[i].rawNode) {
						if ("text"==node.textShape.children[i].rawNode.tagName) {
							// find the text node
							var textNode = node.textShape.children[i].rawNode;
							if (has("ie")) {
								textNode.setAttribute("dir", "rtl");
							}
							else
								textNode.setAttribute("direction", "rtl");
						}
					}
				}
			}
		}
	},

	/**
	  iBPM support.
	  Add a status icon to the upper right of an existing icon.
	  @param: id - id of node to decorate
	  @param: online - boolean value representing if the user is online or not
	  @param: name - User name to add to the top of the decoration
	 **/
	decorate: function( id ){
		
		
		var diagram = this.ilogDiagrammer;
		var graph = diagram.getGraph();

		//Get the data item
		var item = this.getNode( id );



		//And the graph item
		var node = diagram.getGraphElementFromDataItem(item);

		//Where's the original node?
		var x = item.x[0];
		var y = item.y[0];

	
		//All nodes that we care about have a parent.
		var sw = node.getParent()._owningSubgraph;
		var swData = sw.getData().item;
		
		//var sg = node.getParent().getOwningSubgraph();
		

		var newItemCounter = 1;

		var template = this.templates.iBPMTemplate;
		template.children[1].children[0].shape.src = this.iconURL + "collaborate_blog.gif";

		//Create the new node (this will cause createNode to fire as well.)
	    var newItem = diagram.nodesStore.newItem({
	        id: "Item " + newItemCounter++,
	        label: "Jon Bennett",
	        x: x + 70,
	        y: y -30,
	        type: 'iBPM'
	    },{
	        parent: swData,
	        attribute: "children"
	    });
				


	},


	/**
		getNode
		Return a node that correponds to a given id value
	 **/
	 getNode: function( id ){
	 	
	 	//Get the iLog diagram widget
  		var diagram = this.ilogDiagrammer;

  		//All nodes in the diagram
  		var nodes = diagram.nodesStore;


	  	//Query the store for a given link
	  	var node;
	  	nodes.fetchItemByIdentity({
	  		identity: id,
	  		onItem : function( item, request) {
	  			node = item;
	  		}
	  	})

	  	return node;

	 },


	/**
	Implement drill down logic.
	params:  e 		- mouse event object
			 this 	- GE node object
	 **/
	drillDown: function(e) {

		var openDocCommand= new OpenDocumentCommand();

		//User clicked on a node. Pull information from the diagram.
		if ( this._data )		
			var data = this._data.item;
		else{
			//Each transparent <div> keeps its originating item in the name field
			var id = e.target.getAttribute( 'name' );
			var data = this.IDtoItemMap.item( id );
		}
		
		var params = {};
	
		if ( data.poId )
	    	params.documentId = lang.isArray(data.poId) ? data.poId[0] : data.poId;
	
	    if ( data.snapshotId )
	    	params.snapshotId = lang.isArray(data.snapshotId) ? data.snapshotId[0] : data.snapshotId;
	    
	    if ( data.branchId )
	    	params.branchId = lang.isArray(data.branchId) ? data.branchId[0] : data.branchId;

	    if ( data.poType && data.poType == 'Service' ){
	    	params.assetType  = data.serviceType;
	    }
	    
	    if(ShellStateModel.getInstance().state == ShellStateModel.getInstance().STATE_PORTAL){
	    	params.type = "ProcessInstanceType";
	    	if (data.bpmn2TaskType) {
	    		var bpmnTaskType = lang.isArray(data.bpmn2TaskType) ? data.bpmn2TaskType[0] : data.bpmn2TaskType;
	    		if (bpmnTaskType == 'SubProcess' || bpmnTaskType == 'Event_SubProcess' || bpmnTaskType == 'CalledProcess') {
		    		params.subProcParentId = lang.isArray(data.id) ? data.id[0] : data.id;
		    	}
	    	}
	    }
	    params.documentName = lang.isArray(data.label) ? data.label[0] : data.label;
	    params.zoomLevel = this.viewer.zoomLevel;
	    openDocCommand.params = params;
	    openDocCommand.execute();
		
		
	},
	
	/**
		Define the appearance of different types of links.
	 **/
	getLinkTemplate: function( item, store, diagram ){
		
		var template;

		
		if ( item.needDefaultMarker && item.needDiamondMarker[0] == true )
			template = this.templates.linkDiamondTemplate;
		else if ( item.needDefaultMarker && item.needDefaultMarker[0] == true )
			template =  this.templates.linkConditionTemplate;
		else
			template = this.templates.linkTemplate;

		/**
			 Process Portal support. 
			 If this link is designated as 'critical path'
			 then we need to visually change the line's appearance.
		 **/
		if ( item.inCriticalPath && item.inCriticalPath[0] == true ){
			template = lang.clone( template );
			template[0].stroke.color = '#000081';
			
			template[1].stroke.color = "#000081";
			template[1].fill = "#000081";
			if ( template.length == 3 ){
				template[2].stroke = "#000081";
			}
		}else if ( item.highlight ){
			template = lang.clone( template );
			template[0].stroke.color = '#EBF3FD';
			template[0].stroke.width = 6;
			template.splice( 1, 2 );
		}


		return template;
	},
	
	/**
		This the heart of the viewer code. 
		It will inspect an items' type information and generate 
		Return the appropriate node template (GFX diagram) for a given type of node.
	 **/
  getNodeTemplate: function(item, store, diagram) {
 	var type = item.type[0]; 

 	var label = item.label ? item.label[0] : 'n/a';
 	 	
 	var id = item.id ? item.id[0] : 'n/a';

	var bpmnType = item.bpmn2TaskType ? item.bpmn2TaskType[0] : "n/a";

	var counter = item.counter ? item.counter[0] : undefined;

 	var eventTemplate = this.templates.complexEventTemplate;

	 var hasPreAssignment = (item.preAssignment && item.preAssignment[0] === true) || (item.preAssignmentScript && item.preAssignmentScript.length>0 && item.preAssignmentScript[0] != "");
	 var hasPostAssignment = (item.postAssignment && item.postAssignment[0] === true) || (item.postAssignmentScript && item.postAssignmentScript.length>0 && item.postAssignmentScript[0] != "");

	 // pretracking and posttracking point
	 var hasPreTracking = item.preTracking && item.preTracking[0] === true;
	 var hasPostTracking = item.postTracking && item.postTracking[0] === true;

	var baseShape;
	var color;
	var conditional;
	var loopType;
	var stepTypeIcon;
	var templateParms;
 

 	/**
 		VML has astonishingly slow text rendering. 
 		Make sure we don't actually display text labels underneath the nodes. 
 		Use server side generated images for text instead. 
 	 **/
// 	if (this.renderingEngine == 'VML' && this.serverSideTextRendering == true){
// 		eventTemplate = lang.clone( this.templates.complexVMLTemplate );
//
// 		//Magic URL to specify where the label text has been generated. 
// 		var poVersionId = this.data.poVersionId;
// 		var flowObjId = item.id[0];
//		var url = "/rest/bpm/wle/v1/diagramImage?poVersionId=" + poVersionId + "&flowObjId=" +  flowObjId;
//
// 		var lblImage = eventTemplate.children[2].shape;
// 		lblImage.src = url;
// 		
// 	}else{
		eventTemplate = lang.clone( this.templates.complexEventTemplate ); 		
// 	}
 
 	var eventBaseShape = eventTemplate.children[1].children[0];
 
 	
 	/*******************************************************************************
 	 							Events
 	********************************************************************************/

 		/********************* Start Events *********************/

 	if ( type == 'start' ){
 		//Blue circle
		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "start_event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);

 	}
 	else if ( type == 'adhocStartEvent'){
 		//Blue circle with white flag in middle
		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "Ad_Hoc_Start_Event_24x24.png", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}
 	else if ( type == 'startMessage'  || type == 'msgStartEventInterrupting' )
 	{
 		//Blue circle with white envelope in middle
		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "Message_Start_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}
 	else if ( type == 'contentMessage'  || type == 'contentStartEventInterrupting' )
 	{
 		//Blue circle with white envelope in middle
		var template =  eventTemplate;
		template = this.templates.getEventTemplate (this.iconURL, this.iconURL + "Content_Start_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
	
 	}
 	else if ( type == 'contentMessage'  || type == 'documentStartEventInterrupting' )
 	{
		var template =  eventTemplate;
		template = this.templates.getEventTemplate (this.iconURL, this.iconURL + "Document_Start_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);

 	}
 	else if ( type == 'timerStartEventInterrupting'){
 		//Blue circle with clock  in middle
		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "Timer_Start_Event_24x24.png", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}
 	else if ( type == 'timerStartEventNonInterrupting' ){
 		//Blue circle with dotted border clock  in middle
		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "NI_Timer_Start_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}
 	else if ( type == 'msgStartEventNonInterrupting' ){
 		//Blue circle with dotted border clock  in middle
		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "NI_Message_Start_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}
 	else if ( type == 'contentStartEventNonInterrupting' ){
 		//Blue circle with dotted border clock  in middle
		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "NI_Content_Start_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}
 	else if ( type == 'documentStartEventNonInterrupting' ){
 		//Blue circle with dotted border clock  in middle
		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "NI_Document_Start_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}
 	else if ( type == 'scaMessageStartEventInterrupting' ){
		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "SCAMessage_Start_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}
 	else if ( type == 'scaMessageStartEventNonInterrupting' ){
		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "NI_SCAMessage_Start_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}
 	else if ( type == 'errorStartEvent'){
		//Blue circle with dotted border clock  in middle
		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "Error_Start_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}


 	/********************* Intermediate Events *********************/
 	// (All Intemediate Events have a blue circle and a double border)

 	 else if ( type == 'intermediateEvent'  || type == 'intermedCatchMsgEventNonBoundary'){
 	 	//Blue circle with double (white) border and envelope
		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "Receive_Message_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);

 	}

 	else if ( type == 'intermediateMessage' || type == 'intermedCatchMsgEventNonBoundary' )
 	{
 		//White envelope in middle
		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "Receive_Message_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}
 	
 	else if ( type == 'intermediateContent' || type == 'intermedCatchContentEventNonBoundary' )
 	{
 		//White envelope in middle
		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "Content_Intermediate_Event_Catching_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}

 	else if ( type == 'intermedCatchTrackingEventNonBoundary' ){
 		//Black flag in middle
		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "Tracking_Intermediate_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}

 	else if ( type == 'intermediateThrowMsgEvent'){
 		//Black envelope in middle
		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "Send_Message_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}

 	//TODO: IS this still in the model?
 	else if ( type == 'intermediateException'  || type == 'intermedCatchMsgEventNonBoundary'){
		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "error_boundary_event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}
 	else if ( type == 'intermedCatchScaMsgEventNonBoundary'){
		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "Receive_SCAMessage_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}


	/********************* End Events *********************/
 	// (All End Events have a blue circle and a thick black border)

 	else if ( type == 'stop'|| type == 'end' )
 	{
 		//Blue circle with black border
		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "end_event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}
 	else if ( type == 'endException' || type == 'errorEndEvent' ){
 		//Black lightning bolt
		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "error_end_event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}
 	else if ( type == 'timer' || type == 'intermedCatchTimerEventNonBoundary' ){
 		//Deprecated?
		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "Timer_Intermediate_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}
 	else if ( type == 'terminate' ){
 		//Black circle in middle
		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "Terminate_End_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}
 	else if ( type == 'messageEndEvent' ){
 		//Thick black border and black envelope in middle
		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "Message_End_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}

	/*******************************************************************************
 	 							iBPM
 	********************************************************************************/

 	else if ( type == 'iBPM' ){
		var template = this.templates.iBPMTemplate;
		template.children[1].children[0].shape.src = this.iconURL + "collaborate_blog.gif";
		return template;

 	}

	/*******************************************************************************
 	 							Gateways
 	********************************************************************************/
 	/*
	else if ( (type == 'gateway' || type == 'gatewayEvent' || type == 'gatewayAnd' || type == 'gatewayOr'  ) && this.renderingEngine == 'VML'){


		console.debug( "VML image for Gateway: " + item.label[0] );
		
		//Special handling for Gateway Events with VML. Text labels (underneath the diamond image) are rendered as 
		//images on the server.		
		var template =  lang.clone( this.templates.complexVMLTemplate );

 		if ( type == 'gateway' )
			template.children[1].children[0].shape.src = this.iconURL + "Exclusive_Gateway_32x32.png"; 		
		else if ( type == 'gatewayEvent')
			template.children[1].children[0].shape.src = this.iconURL + "Event_Gateway_32x32.png";	
		else if ( type == 'gatewayAnd')
			template.children[1].children[0].shape.src = this.iconURL + "Parallel_Gateway_32x32.png";
		else if ( type == 'gatewayOr' )
			template.children[1].children[0].shape.src = this.iconURL + "Inclusive_Gateway_32x32.png";

		template.children[1].children[0].shape.width = 32;
 		template.children[1].children[0].shape.height = 32;

 		//specify the gateway label using an image from the server
		var poVersionId = this.data.poVersionId;
 		var flowObjId = item.id[0];
		var url = "/rest/bpm/wle/v1/diagramImage?poVersionId=" + poVersionId + "&flowObjId=" +  flowObjId;

 		var lblImage = template.children[2].shape;
 		lblImage.src = url;

 	}
 	*/
 	else if ( type == 'gateway' )
 	{
 		//Exclusive gateway - Blue diamond
 		var template =  eventTemplate;
		template = this.templates.getGatewayTemplate(this.iconURL, this.iconURL + "exclusive_gateway_32x32.svg", hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}
 	else if ( type == 'gatewayEvent' ){
 		//Blue diamond with circle and pentagon
 		var template =  eventTemplate;
		template = this.templates.getGatewayTemplate(this.iconURL, this.iconURL + "Event_Gateway_32x32.svg", hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}
 	 else if ( type == 'gatewayAnd' ){
 	 	//Parallel gateway - diamond with cross in middle
		var template =  eventTemplate;
		template = this.templates.getGatewayTemplate(this.iconURL, this.iconURL + "parallel_gateway_32x32.svg", hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}
 	else if ( type == 'gatewayOr')
 	{
 		//Blue diamond with circle in middle
 		var template =  eventTemplate;
		template = this.templates.getGatewayTemplate(this.iconURL, this.iconURL + "inclusive_gateway_32x32.svg", hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}
 	else if ( type == 'group' ){
 		var response = lang.clone( this.templates.groupTemplate );
		response.children[0].shape.width = item.width[0];
		response.children[0].shape.height = item.height[0];;
		return response;
 	}


	/*******************************************************************************
 	 							Attached Events
 	********************************************************************************/
 	else if ( type == 'intermedCatchErrorEventBoundary' ){
  		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "error_boundary_event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
 	}
 	else if ( type == 'intermedCatchMsgEventBoundaryInterrupting' ){
 		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "Receive_Message_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
  	}
  	else if ( type == 'intermedCatchMsgEventBoundaryNonInterrupting' ){
  		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "NI_Receive_Message_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
  	}
 	else if ( type == 'intermedCatchScaMsgEventBoundaryInterrupting' ){
 		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "Receive_SCAMessage_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
  	}
  	else if ( type == 'intermedCatchScaMsgEventBoundaryNonInterrupting' ){
  		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "NI_Receive_SCAMessage_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
  	}
  	else if ( type == 'intermedCatchContentEventBoundaryInterrupting' ){
 		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "Content_Intermediate_Event_Catching_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
  	}
  	else if ( type == 'intermedCatchContentEventBoundaryNonInterrupting' ){
  		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "NI_Content_Intermediate_Event_Catching_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
  	}
  	else if ( type == 'intermedCatchTimerEventBoundaryInterrupting' ){
  		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "Timer_Intermediate_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
  	}
  	//TODO: This icons should have a dotted edge too.
  	else if ( type == 'intermedCatchTimerEventBoundaryNonInterrupting' ){
  		var template =  eventTemplate;
		template = this.templates.getEventTemplate(this.iconURL, this.iconURL + "NI_Timer_Intermediate_Event_24x24.svg", counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking);
  	}

 	/*******************************************************************************
 	 							Milestone
 	********************************************************************************/

 	else if ( type == 'milestone' ){
 		
 		//Dynamically, set the milestone width.
 		var width = item.width[0];
 		var height = item.height[0];
 		var template = this.templates.milestoneTemplate;
 		//Set the width of the text box on top of the swimlane
 		template.children[0].children[0].shape.width = width;

 		//make sure the text has as much room as possible to prevent wrapping
 		template.children[0].children[1].shape.width = width;

 

 		//Set the width and height of the rectangle underneath the text box. 
 		//Subtract 25 (height of the text box) to get the height correct.
 		
 		template.children[1].shape.width = width;
 		template.children[1].shape.height = height;	

	}

 	/*******************************************************************************
 	 							Note
 	********************************************************************************/

	else if ( type == 'note'){
			var response = lang.clone( this.templates.noteTemplate );

			var height = item.height[0];
			
			//Set the width and height of the yellow background box
			response.children[0].shape.width = item.width[0]+6;
			response.children[0].shape.height = height;

			//Set the width of the text field (Probably shouldn't be necesary.)
			response.children[1].shape.width = item.width[0];

			//For performance reasons, we're using images to 
//			if ( this.renderingEngine == 'VML' && this.serverSideTextRendering ){
//			
//				var poVersionId = this.data.poVersionId;
//		 		var flowObjId = item.id[0];
//				var url = "/rest/bpm/wle/v1/diagramImage?poVersionId=" + poVersionId + "&flowObjId=" +  flowObjId;
//
//
//				var image = {
//					halign: 'center',
//					valign: 'center',
//					shape: {
//						width: item.width[0],
//						height: item.height[0],
//						src: url,
//						type: 'image'
//					}
//				};
//
//				response.children.splice( 1, 1, image );
//			
//		}

		
			//Set length of black border on left side of node
			response.children[2].shape.y2 = height;

			return response;	

 	}
	/*******************************************************************************
 	 							Activity (Deprecated edit support)
 	********************************************************************************/


 	else if ( type == 'activity' && this.enableEditing ){
 		
 		var response = this.templates.vectorActivityTemplate;

 		response.children[0].fill.colors[0].color = "#EAF3FF";
		response.children[0].fill.colors[1].color = "#75AFFF";

 		try{
 			var icon = item.colorIcon[0];
 			if ( icon.indexOf('purple') != -1 )
 			{
 				response.children[0].fill.colors[0].color = "#FCEAFB";
				response.children[0].fill.colors[1].color = "#CFA4CD";
 			}
 			else if (  icon.indexOf('yellow') != -1  ){
				response.children[0].fill.colors[0].color = "#FFFEE4";
				response.children[0].fill.colors[1].color = "#FEEF77";

 			}
 			else if (  icon.indexOf('orange') != -1  ){
				response.children[0].fill.colors[0].color = "#FFF7E5";
				response.children[0].fill.colors[1].color = "#FFC876";

 			}
 

 		}catch( err ){
 			console.debug( err );
 		}
 		return response;

 	} 

	/*******************************************************************************
 	 							Activity 
 	********************************************************************************/

 	else if ( type == 'activity' ){
		var decoratorIcon = undefined;
		if (item.decorator){
			decoratorIcon = item.decorator[0];
		}
		if ( bpmnType === "task"){
			template = this.templates.getStepTemplate(this.iconURL, item.decorator ? decoratorIcon : undefined, undefined , counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking, this._getConditionalValue(item));
		} else if ( bpmnType == "ScriptTask") {
				//template = this.templates.getStepTemplate(this.iconURL + "Script_Task_Marker_16x16.png"+"?"+config.cacheBust, undefined, hasPreAssignment, hasPostAssignment, isConditional);
			color = this._getColor(item);
			template = this.templates.getStepTemplate(this.iconURL, item.decorator ? decoratorIcon : this.iconURL + "Script_Task_Marker_16x16.svg", color, counter , hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking, this._getConditionalValue(item), undefined, undefined, this._getLoopType(item));
		} else if (bpmnType == "CalledProcess" || bpmnType == "UserTask" || bpmnType == "InlineUserTask" || bpmnType == "RobotTask") {
					stepTypeIcon = item.decorator ? decoratorIcon : this.getCalledElementIcon(item);
					templateParms = this._getAdHocConfiguration(item);
					loopType = this._getLoopType(item);
					conditional = templateParms.isConditional;
					if(!conditional){
						conditional = this._getConditionalValue(item);
					}
					color = this._getColor(item);
					template = this.templates.getStepTemplate(this.iconURL, stepTypeIcon, color, counter , hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking,
							conditional, templateParms.contentIcons,
							templateParms.isOptional ? "dashed" : ((templateParms.isCalledProcess) ? "solid" : undefined), loopType);
		} else if (bpmnType == 'ServiceTask') {
			stepTypeIcon = item.decorator ? decoratorIcon : this.getServiceTaskIcon(item);
			templateParms = this._getAdHocConfiguration(item);
			loopType = this._getLoopType(item);
			conditional = templateParms.isConditional;
			if(!conditional){
				conditional = this._getConditionalValue(item);
			}
			color = this._getColor(item);
			template = this.templates.getStepTemplate(this.iconURL, stepTypeIcon, color, counter , hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking,
					conditional, templateParms.contentIcons,
					templateParms.isOptional ? "dashed" : ((templateParms.isCalledProcess) ? "solid" : undefined), loopType);
		} else if (bpmnType === "com.ibm.bpmsdk.model.bpmn20.ibmwleext.TContentTask") {
			stepTypeIcon = item.decorator ? decoratorIcon : this.iconURL + "Content_Task_Marker_16x16.svg";
			templateParms = this._getAdHocConfiguration(item);
			loopType = this._getLoopType(item);
			conditional = templateParms.isConditional;
			if(!conditional){
				conditional = this._getConditionalValue(item);
			}
			color = this._getColor(item);
			template = this.templates.getStepTemplate(this.iconURL, stepTypeIcon, color, counter , hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking,
					conditional, templateParms.contentIcons,
					templateParms.isOptional ? "dashed" : ((templateParms.isCalledProcess) ? "solid" : undefined), loopType);
		} else if (bpmnType=== "SubProcess") {
			templateParms = this._getAdHocConfiguration(item);
			color = this._getColor(item);
			loopType = this._getLoopType(item);
			conditional = templateParms.isConditional;
			if(!conditional){
				conditional = this._getConditionalValue(item);
			}
			template = this.templates.getSubProcessTemplate (this.iconURL, undefined, color, counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking, conditional, templateParms.contentIcons, templateParms.isOptional ? "dashed" : undefined, loopType);
		} else if (bpmnType == 'Event_SubProcess') {
			var iconLocation = this.getStepTypeIconForEVSP (item);
			color = this._getColor (item);
			template = this.templates.getEventSubProcessTemplate (this.iconURL, iconLocation, color, counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking, false, this.iconURL + "sub_flow.svg");
		} else if (bpmnType == "RuleTask" || bpmnType == "DecisionTask") {
			color = this._getColor (item);
			template = this.templates.getStepTemplate(this.iconURL, item.decorator ? decoratorIcon : this.iconURL + "Decision_Task_Marker_16x16.svg", color, counter , hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking, this._getConditionalValue(item));
		} else if ( bpmnType == "com.ibm.bpmsdk.model.bpmn20.ibmext.TModifyTask") {
			color = this._getColor(item);
			template = this.templates.getStepTemplate(this.iconURL, item.decorator ? decoratorIcon : this.iconURL + "modify_task_32x32.png", color, counter , hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking, this._getConditionalValue(item), undefined, undefined, this._getLoopType(item));
		}else{
		color = this._getColor(item);
		template = this.templates.getStepTemplate(this.iconURL, item.decorator ? decoratorIcon : undefined, color , counter, hasPreAssignment, hasPostAssignment, hasPreTracking, hasPostTracking, this._getConditionalValue(item));
		}

		
		var isActive = item.counter ? item.counter[0] : undefined;
		
		//If this is an active node then highlight it.
		if(isActive){
			var halo = this.templates.activityHalo;
			halo.shape.width = 100;
			halo.shape.height = 75;
			baseShape = template.children[1].children;
			halo.stroke.color = "#f19027";
			halo.stroke.width = 8;
 			baseShape.splice( 0, 0, halo );
		}

 		return template;
 		
 	}

 	//Add pre & post assignment markers to gateways and events
 	if ( item.type != 'activity' ){

 		var postAssignment = item.postAssignment && item.postAssignment[0] == true;
 		var preAssignment = item.preAssignment && item.preAssignment[0] == true;

 		if ( preAssignment || postAssignment ){
 			template = lang.clone( template );

  		
	 		if ( preAssignment ){
				var marker = lang.clone( this.templates.assignmentEventMarker );
				marker.shape.src =  this.iconURL + 'Pre-Post-assignment_marker_7x7.png';
 	 			marker.margins = [3, 3, 17, 3 ];
	 			template.children[1].children.push( marker );
	 		}
	 			
	 		if( postAssignment ){
				var marker = lang.clone( this.templates.assignmentEventMarker );
	 			marker.shape.src =  this.iconURL + 'Pre-Post-assignment_marker_7x7.png';
 				marker.margins = [17, 3, 3, 3 ];
	 			template.children[1].children.push( marker );
	 		}
 	
 		}
 	}

 	//Highlight events with counters on top of them. (Portal requirement)
	var isActive = item.counter ? item.counter[0] : undefined;
	var itemCategory = item.category ? item.category[0] : undefined;
	
	if ( item.type != 'activity' && isActive ){
		
		template = lang.clone( template);
		var base = template.children[1].children;
		
		var halo = this.templates.eventHalo;
		halo.stroke.color = "#f19027";
		halo.stroke.width = 6;
		base.splice( 0, 0, halo );

	}


 	return template;
 
  },

  _getAdHocConfiguration : function (item){
    	
	// simplified set of relevant adhoc properties for UI refresh
	var adhocProperties = {};
	
	// optional or required adhoc activity
	adhocProperties.isOptional = item.activityOptionType ? item.activityOptionType[0] == "OPTIONAL": false;
	
	// repeatable
	adhocProperties.isRepeatable = item.isRepeatable ? item.isRepeatable[0] === true : false;
	
	// manual or automatic
	adhocProperties.isManual = item.activityExecutionType ?  item.activityExecutionType[0] == "MANUAL" : false;
				
	// pre-conditions
	adhocProperties.isConditional = !!item.conditionTriggerType && 
										!!item.conditionTriggerType[0] && 
										item.conditionTriggerType[0] !== "NO_PRECONDITION" && 
										item.conditionTriggerType[0] !== "NO_PRECONDITIONS";
	// icons		
	var contentIcons = [];
	if (adhocProperties.isRepeatable) {
		contentIcons.push(this.iconURL + "Repeating_marker.svg");
	}

	if (adhocProperties.isManual) {
		contentIcons.push(this.iconURL + "Manual_marker.svg");
	}
	
	// subprocess
	adhocProperties.isSubProcess = item.bpmn2TaskType ? (item.bpmn2TaskType[0] === 'SubProcess') : false;
	// linked process
	adhocProperties.isCalledProcess = item.bpmn2TaskType ? (item.bpmn2TaskType[0] === 'CalledProcess') : (adhocProperties.isSubProcess ? false : true);
	if (adhocProperties.isCalledProcess || adhocProperties.isSubProcess) {
		contentIcons.push(this.iconURL + "sub_flow.svg");
	}
			
	adhocProperties.contentIcons = undefined;
	if (contentIcons.length == 1){
		adhocProperties.contentIcons = contentIcons[0];
	} else if (contentIcons.length > 1){
		adhocProperties.contentIcons = contentIcons;
	}			
	return adhocProperties;
},
_getColor: function(item){
	return item.colorIcon ? item.colorIcon[0] : "#e5f6ff";
},

getCalledElementIcon: function(item){
	var type = item.bpmn2TaskType ? item.bpmn2TaskType[0] : "n/a";
	if (type === "UserTask"){
		return this.iconURL + "User_Task_Marker_16x16.svg";
	} else if (type == 'InlineUserTask') {
		return this.isMergeInlineUserTaskWithUserTask()? this.iconURL + "User_Task_Marker_16x16.svg" : this.iconURL + "Inline_User_Task_Marker_16x16.svg";
	} else if (type == 'RobotTask') {
		return this.iconURL + "Inline_Robot_Task_Marker_16x16.svg";
	} else if (type == 'ServiceTask') {
		return this.iconURL + "Service_Task_Marker_16x16.svg";
	} else if (type == 'RuleTask') {
		return this.iconURL + "Decision_Task_Marker_16x16.svg";
	}

	// not set
	return undefined;
},

_getConditionalValue : function (item){
	var conditional = false;
	if ( item.conditional && item.conditional[0] == true){
		conditional = true;
	}
	return conditional;
},

_getLoopType : function(item){
	var loopType = "None";
	if ( item.loopType ){
		var loop = item.loopType[0];
		var MIOrdering = item.MIOrdering ? item.MIOrdering[0] : 'parallel';

		if ( loop == 'MultiInstanceLoop' && MIOrdering == 'sequential' ){
			loopType = "MultipleLoopSequential";
		}
		else if ( loop == 'MultiInstanceLoop' ){
			loopType = "MultipleLoop";
		}
		else if ( loop == 'simpleLoop' ){
			loopType = "MultipleLoopSequential";
		}
	}
	return loopType;
},

isMergeInlineUserTaskWithUserTask: function() {
	if(!dojoConfig.App._bpmIsSaaSAWS) return false;
	return true;
},

getServiceTaskIcon: function(item){
	var type = item.bpmn2TaskType ? item.bpmn2TaskType[0] : "n/a";
	if (type === "UserTask") {
		return this.iconURL + "User_Task_Marker_16x16.svg";
	} else if (type == 'InlineUserTask') {
		return CapabilityUtils.isMergeInlineUserTaskWithUserTask()? this.iconURL + "User_Task_Marker_16x16.svg" : this.iconURL + "Inline_User_Task_Marker_16x16.svg";
	} else if (type == 'RobotTask') {
		return this.iconUrl + "Inline_Robot_Task_Marker_16x16.svg";
	}
	return this.iconURL + "Service_Task_Marker_16x16.svg";
},

getStepTypeIconForEVSP: function (item) {
	var iconLocation =  this.iconURL + "Error_Start_Event_16x16.svg";
	var eventSubProcType = item.eventSubProcType ? item.eventSubProcType[0] : "n/a";
	var interrupting = item.interrupting ? item.interrupting[0] : false;

	//Error marker, lightning bolt with thin border
	if (eventSubProcType == 'error' || eventSubProcType == 'n/a'){
		iconLocation = this.iconURL + "Error_Start_Event_16x16.svg";
	}
	//Interrupting timer, clock with thin border
   else if ( eventSubProcType == 'timer' && interrupting ){
		iconLocation =  this.iconURL + "Timer_Start_Event_24x24.png";
	}
	//Non-interrupting time, clock with dotted border
   else if ( eventSubProcType == 'timer' && !interrupting ){
		iconLocation =  this.iconURL + "NI_Timer_Start_Event_24x24.png";
	}
	//Interrupting message, envelope with thin border
   else if ( eventSubProcType == 'message' && interrupting ){
		iconLocation =  this.iconURL + "Message_Start_Event_16x16.png";
	}
   //non-interrupting message, envelope with dotted border
   else if ( eventSubProcType == 'message' && !interrupting ){
		iconLocation =  this.iconURL + "NI_Receive_Message_Event_16x16.png";
	}
	//Interrupting content, folder with thin border
   else if ( eventSubProcType == 'content' && interrupting ){
		iconLocation =  this.iconURL + "Content_Start_Event_16x16.png";
	}
   //non-interrupting content, folder with dotted border
   else if ( eventSubProcType == 'content' && !interrupting ){
		iconLocation =  this.iconURL + "Content_Start_Event_-_NI_16x16.png";
	}

	return iconLocation;		//+"?"+config.cacheBust;
},

  showCalledProcessTooltip: function(e){		
	this.tooltip.show(e, nls.LINKEDPROCESS_ICON_HOVER);		
  },
  
  showSubProcessTooltip: function(e){		
	this.tooltip.show(e, nls.SUBPROCESS_ICON_HOVER);		
  },
	
  showPreconditionTooltip: function(e){		
	this.tooltip.show(e, nls.PRECONDITION_HOVER);		
  },
	
  showManualTooltip: function(e){		
	this.tooltip.show(e, nls.MANUAL_HOVER);		
  },
	
  showRepeatableTooltip: function(e){		
	this.tooltip.show(e, nls.REPEATABLE_HOVER);		
  },
	
  hideTooltip: function(e){
        this.tooltip.hide();
  },  
  
  drillableType: function(implType) {
	  return( implType == 'SubProcess' || implType == 'Event_SubProcess' || implType == 'CalledProcess');
  },

  /**
	 * The viewer become invisible
	 */
	onHide: function(){
		//this.breadcrumb.onHide();
	},

 
 	/**
 		Call back function. Invoked when a new link is created to allow us to style the links appearance.
 	**/
	onLinkCreated: function(link, start, end, diagram){
		
		if ( ! link._data ){
			//User creted link
			return;
		}

		var hexColor = new Color("#000081");

		var startPort = this.getPort( link._data.item.startPosition[0] );
		start.addPort( startPort );

		var endPort = this.getPort( link._data.item.endPosition[0] );
    	end.addPort( endPort );

		link.setStartPort( startPort );
		link.setEndPort( endPort );

		var position = link._data.item.linkLabelPosition ? link._data.item.linkLabelPosition[0]: 0.5;
	
		this.addDecoration(link, "Middle Center", 
				position,
				ibm_diagram_base.LinkDecorationPositionType.Relative,
				ibm_diagram_base.LinkDecorationOrthogonalAlignment.Center,
				ibm_diagram_base.LinkDecorationParallelAlignment.Middle);
				

		/*		
		var startBounds = start.getBounds( link.getParent() );
		console.debug( "Start node is: " + dojo.toJson( startBounds ) );
		
		var endBounds = end.getBounds( link.getParent() );
		console.debug( "End node is: " + dojo.toJson( endBounds ) );
		*/
	
	},


	/**
		Code to add a decoration (text label) to the middle of a given link.
		See the link decorations sample for more details.
	 **/
	addDecoration : function(link, text, position, type, orthogonal, parallel) {
			

			try{
				var showName = link._data.item.showName[0];

				if ( showName == false )
					return;

				
				text = link._data.item.name[0];

			}catch(err){
				return;
			}

			this.addTextDecoration( link, text, position, type, orthogonal, parallel );
			
		},

	/**
		Code to add a decoration (text label) to the middle of a given link.
		See the link decorations sample for more details.
	 **/
	addTextDecoration : function(link, text, position, type, orthogonal, parallel) {
		var deco = link.createGroup();
		deco.isDecoration = true;

		var bg = deco.createRect({width: 50, height: 16 });
		bg.setFill('#F8F8F8');

		var label = deco.createText({text: text, y:12, align: 'middle'});
		label.setFill('black');
		label.setFont({family:'sans-serif', size:10});

		var textWidth = this._getLinkLabelWidth(text, "sans-serif", 10);
		bg.setShape({width: textWidth+6});
		label.setShape({x:textWidth/2+3});

		deco.positionType = type;
		deco.position = 0.5;
		deco.orthogonalAlignment = orthogonal;
		deco.parallelAlignment = parallel;
		
		
		deco.distance = 10;
	},

	_getLinkLabelWidth: function(text, fontFamily, fontSize){
		var w = 0;
		if(text.length > 0) {
			var testDiv = document.createElement("div"); 
			testDiv.style.visibility="hidden";
			testDiv.style.position="absolute";
			testDiv.style.left="-4000px";
			testDiv.style.top="-4000px";
			testDiv.style.fontFamily=fontFamily;
			testDiv.style.fontSize=fontSize+"px";
			var testText = document.createTextNode(text); 
			testDiv.appendChild(testText);

			document.body.appendChild(testDiv); 
			w = testDiv.clientWidth ;
			document.body.removeChild(testDiv);
			
			if(w === 0) {
				w = text.length * 6;
			}
		}
		return w;
	}, 

	/**
	 * Generate a port (link connection point) for a specific location on a node.
	 **/
	getPort: function( location ){
		 
		 var position;
		 var port;

		 if ( location == "topLeft" )
		 	position = {x: 0.25, y: 0.0 };
		 else if ( location == "topCenter")
		 	position = {x: 0.5, y: 0.0 };
		 else if ( location == "topRight")
		 	position = {x: .75, y: 0.0 };
		 else if ( location == "leftTop")
		 	position = {x: 0.0, y: 0.25 };
		 else if ( location == "leftCenter")
		 	position = {x: 0.0, y: 0.5 };
		 else if ( location == "leftBottom")
		 	position = {x: 0.0, y: 0.75 };
		 else if ( location == "bottomLeft")
		 	position = {x: 0.25, y: 1.0 };
		 else if ( location == "bottomCenter")
		 	position = {x: 0.5, y: 1.0 };
		 else if ( location == "bottomRight") 
		 	position = {x: .75, y: 1.0 };
		 else if ( location == "rightTop")
		 	position = {x: 1.0, y: 0.25 };
		 else if ( location == "rightCenter")
		 	position = {x: 1.0, y: 0.5 };
		 else if ( location == "rightBottom")
		 	position = {x: 1.0, y: 0.75 };
		 
		 if ( position ){
		 	port = new ibm_diagram_base.BasicPort();
		 	port.setPosition( position );
		 }
		 else{
		 	port = new ibm_diagram_base.AutomaticPort();
		 }

		 return port;

	},

	actionPrint: function () {
		//debugger;

		var printPageNumber = 0;
		var vSize = this.ilogDiagrammer.getViewport().getClientSize();

		var dimy = 600;
		var dimx = 800;

		if ( vSize.height > vSize.width ){
			dimy = 800;
			dimx = 600;
		}


		//console.log(args);
		var h = 1;
		var w = 1;

		//var printAirContent = args.air[0]?args.air[0]=="on":false;
		//    var other = window.open("","wildebeast","width=300,height=300,scrollbars=1,resizable=1")
		var printPages = [];
		var printDivNames = [];
		
		if(has("ie")){
			//Workaround to show the print preview in individual containers but in the same document 
			for (var p = 1, r = 0; r < h; r++) {
				printPages.push([]);
				printDivNames.push([]);
				for (var c = 0; c < w; c++, p++) {
					printPageNumber++;
					var html = "";
					var title = "Print preview: " + this.data.name;
					var printDlg = new Dialog({
				        
						title: title
					});
					var auxClass = "";
					html += "<div id=\"div_" + printPageNumber + "\"></div>";
					printPages[r].push(document);
					printDivNames[r].push(printPageNumber);
					printDlg.attr("content", html);
					printDlg.show();
				}
			}

		}else{
		   	var r = 0;
		   	var c = 1;
		   	var p = 1;
		  //for (var p = 1, r = 0; r < h; r++) {
			printPages.push([]);
			printDivNames.push([]);
			for (var c = 0; c < w; c++, p++) {
				printPageNumber++;
				var other = window.open("", "printPage_"+ p);
				st = "h2.breakhere { page-break-before: always; }";
				var html = "<html><head><style type=\"text/css\">" + st + "</style></head><body>";
				var auxClass = "";
				html += "<h3>" + this.data.name + "</h3>";
				html += "<div id=\"div_" + printPageNumber + "\"></div>";
				auxClass = ' class="breakhere"';
				html += "</body></html>";
				other.document.open();
				other.document.write(html);
				other.document.close();
				printPages[r].push(other);
				printDivNames[r].push(printPageNumber);
			}
		  //}
		}
		
	
		var D = this.ilogDiagrammer;
		var	myPrintUtil = new PrintUtil({
				pagesToPrint : printPages,
				divNames: printDivNames,
				getTargetSurfaceDiv: function(r,c) {
					var doc = this.pagesToPrint[r][c].document;	
					return dom.byId("div_"+this.divNames[r][c],doc);
				},
				postProcessing: function(r,c,surf,group){
				    domStyle.set(surf.rawNode, "backgroundColor", '#888888');
				}
			});

		
			myPrintUtil.printGraph(D.getGraph(),null,dimx,dimy,w,h,'#888888');
		
	
},

	/**
		IE Performance issue have caused performance problems. 
		Detect when we're looking at a legacy browser and pop up an image with several <div> overlays instead.
	 **/
//	displayImage: function(){
//		
//
//		//Find the main editor pane
//		var editor = this.editorPane;
//
//		//Generate a REST call to pull the image back from the server
////		var ssm = com.ibm.bpm.wpd.core.model.shellstate.ShellStateModel.getInstance();
////		var activeModel = ssm.getActiveViewStateModel();
//
//
//		var url;
//
////		var keyId = activeModel.keyId;
//		var keyId = this.viewStateModel.keyId;
//
//
//		if ( this instanceof com.ibm.bpm.wpd.document.bpd.view.BPMNViewer ){
//
//			if ( this instanceof com.ibm.bpm.wpd.document.bpd.view.ServiceViewer )
//				url = "/WebViewer/image/v1/serviceModel/" + this.data.poId;
//			else
//				url = "/WebViewer/image/v1/processModel/" + this.data.poId;
//
//			if (keyId.indexOf("2063.") >= 0) {
//				url += "?branchId=" + keyId;
//			} else {
//				url += "?snapshotId=" + keyId;
//			}
//		} else if ( this instanceof com.ibm.bpm.wpd.document.bpd.view.BPDViewer  && this.viewStateModel.subProcParentId ){
//			//Sample URL
//
//			//If we're in a sub process then Alice's framework will pass in the ID of the calling process. 
//			var parentId = this.viewStateModel.subProcParentId ;
//
//			//Base URL for Process Instance graphics
//			var instanceIds =  this.config.instanceIds;
//			url = "/portal/diagramImage/v1/processModel/instances?instanceIds=[" + instanceIds.toString() + "]";
//
//			//and the snapshot id
//			if (keyId.indexOf("2063.") >= 0) {
//				url += "&branchId=" + keyId;
//			} else {
//				url += "&snapshotId=" + keyId;
//			}
//
//			//Need to know the parent
//			url += "&parentId=" + parentId;  
//
//			var bpdId = this.viewStateModel.documentId;
//			url += "&bpdId=" + bpdId;
//			
//			if (this.config.criticalPathFlowIds.length==0) {
//				url += "&hasCriticalPath=no";
//			}			
//
//		}
//		else if ( this instanceof com.ibm.bpm.wpd.document.bpd.view.BPDViewer ){
//
//			var instanceIds =  this.config.instanceIds;			
//			url = "/portal/diagramImage/v1/processModel/instances?instanceIds=[" + instanceIds.toString() + "]";
//			if (this.config.criticalPathFlowIds.length==0) {
//				url += "&hasCriticalPath=no";
//			}
//		
//		}
//
//		if (!!com.ibm.bpm.wpd.core.model.shellstate.ShellStateModel.getInstance().remoteId) {
//			url = com.ibm.bpm.wpd.core.control.WpdRestHandler.getInstance().calculateRemoteRequestURL(url);
//		}
//		//Add an image underneath it.
//		var img  = document.createElement( 'img' );
//		img.setAttribute( 'src', url  );
//		img.style.zIndex = 99;
//		editor.appendChild( img );
//
//		//Explicitly set the image height and width
//		img.style.width = this.data.width ;
//		img.style.height = this.data.height ;
//
//		//Build a one-time lookup table of actitities to swimlanes
//		var swimlaneMap = this.IDtoSwimlaneMap = this.getSwimlaneMap(this.data.items);
//		var idMap = this.IDtoItemMap = this.getActivityIDMap(this.data.items);		
//
//		//Add event handlers to each of the nodes
//		for ( var i = 0; i < this.data.items.length; i++ ){
//			var item = this.data.items[i];
//			this.imgAddEventHandlers( item, swimlaneMap.item( item.id ) );
//		}
//
//	},



	/**
	 Generate a map of activity id - parent swimlane.
	 **/
//	getSwimlaneMap: function (items){
//
//		var dictionary =  new Dictionary();
//
//		var swimlanes = this.getAllSwimlanes(items);
//		
//
//		for ( var i = 0; i < swimlanes.length; i++ ){
//			var swimlane = swimlanes[i];
//			var children = swimlane.children;
//			for ( var a = 0; a < children.length; a++ ){
//				var child = children[a];
//				var reference = child["_reference"];
//				dictionary.add( reference, swimlane );
//			}
//		}
//
//		return dictionary;
//
//	},

	/**
		Generate a map of activity id - item defintions 
	 **/
//	 getActivityIDMap: function( items ){
//	 	
//		var dictionary =  new Dictionary();
//
//		for ( var i = 0; i < items.length; i++ ){
//			var item = items[i];
//			dictionary.add( item.id, item );
//		}
//
//		return dictionary;
//	 },

	/**
	 Returns a list of all swimlanes on the diagram
	 **/
//	getAllSwimlanes: function( items ){
//	
//		var swimlanes = [];
//		
//		for ( var i = 0; i < this.data.items.length; i++ ){
//				var item = this.data.items[i];
//				if  ( item.type == 'swimlane' )
//					swimlanes.push( item );
//		}
//
//		return swimlanes;
//	},

	/**
		Connect up an event handler for the given node, iff it's necessary.
	 **/
//	imgAddEventHandlers: function( item, parent ){
//
//	 var tasks = [ 'Coach','Script', 'Scriptlet', 'ILOGDecision',  'TaskAction', 'SubProcess', 'Step', 'PostponeAction', 'TaskSender', 'InvokeUca', 'WSConnector', 'JavaConnector', 'SCAConnector', 'ILOGConnector', 'activity' ];
//	 var events=['start', 'adhocStartEvent', 'timerStartEventInterrupting', 'timerStartEventNonInterrupting', 'msgStartEventNonInterrupting', 'errorStartEvent', 'intermediateEvent', 'intermedCatchMsgEventNonBoundary', 'intermediateMessage', 'intermedCatchMsgEventNonBoundary', 'intermedCatchTrackingEventNonBoundary' , 'intermediateThrowMsgEvent', 'stop', 'end', 'endException', 'errorEndEvent', 'timer' , 'intermedCatchTimerEventNonBoundary' ,  'terminate', 'messageEndEvent', 'gateway', 'gatewayEvent' , 'gatewayAnd' ,  'gatewayOr'];
//
//		//Sanity check, do we want to connect to this?
//		if (  array.indexOf(tasks, item.type) ==  -1 &&  array.indexOf(events, item.type) ==  -1 ){
//			return;
//		}
//		
//		//Find the location of the item	
//		var location = this.getActivityLocation( item.id );
//		//Hack, event location data from the server is incorrect
//		if (  array.indexOf( events, item.type) != -1 )
//			location.x = location.x + 15;
//
//		//Create the new div
//		var main = this.editorPane;
//			
//		var div = document.createElement( 'div' );
//		div.style.borderWidth = "2px";
//		div.style.borderStyle = "solid";
//		div.style.borderColor = 'black';
//		
//		div.style.position = "absolute";
//		div.style.top = location.y + "px";
//		div.style.left = location.x + "px";
//		if ( has("ie") )
//			div.style.backgroundColor = 'red';
//		div.style.filter = "alpha(opacity=0)";
//
//		if ( array.indexOf( tasks, item.type) != -1 ){		
//			div.style.width = "90px";
//			div.style.height = "70px";
//		}else if (  array.indexOf( events, item.type) != -1 ){
//			div.style.width = "32px";
//			div.style.height = "32px";
//		}
//		
//   		div.style.opacity = "0.0"; 
//
//		div.setAttribute('name', item.id );
//	
//		div.style.zIndex = 90;
//			
//		main.appendChild( div );
//
//		//TODO If item is a user-based activity, create a placeholder for the user avatar
////		if(item.type=="activity" && item.bpmn2TaskType=="UserTask" && this.serverSideImageRendering && typeof(window.SocialPortalUserAvatars)!="undefined"){
////			this.imgAddAvatarHandlers(item, div);
////		}
//		
//		//Classify nodes. Differentiate between interesting ones for Viewer and Portal
//		var implType = item.bpmn2TaskType;
//		var isPortalNode  = (( implType == 'Event_SubProcess' || implType == 'CalledProcess' || implType == 'SubProcess'  ) && this.config && item.poId );
//		var isViewerNode = ( item.poId && !this.config );
//		var isPortal = this.config ? true : false;		//Are we running in process portal?
//
//		var label = item.label;
//
//		//if( ( isPortal && (isPortalNode || item.counter ) ) || ( !isPortal && isViewerNode )){
//		if(isViewerNode){
//			
//			//Connect the event handlers for drill down
//		    connect.connect( div, "onmouseenter", function(){
//				document.body.style.cursor = 'pointer';
//			});
//			
//
//		    connect.connect( div, "onmouseout", function(){
//				document.body.style.cursor = 'default';
//			});
//
//		}
//
//		//Event trigger for the Coach diagram in the service viewer
//		if ( item.type == 'Coach' ){
//		
//		    connect.connect( div, "onclick", this, function(evt, tgt){
//
//				this.displayCoach(evt);
//			});
//		//Event trigger for drill down in Process viewer		
//		}else if ( ( isPortal && isPortalNode ) || ( !isPortal && isViewerNode )) {
//		    connect.connect( div, "onclick", this, function(evt, tgt){
//				this.drillDown(evt);
//			});
//		}
//
//		/**************************************************************************
//			Process Portal Events
//		 **************************************************************************/
//		//Click on a node.  Previous function limited to clicking on an active node.
//		//if ( isPortal && this.config["onNodeClick"] /*&& item.counter*/ ){  //7.5 functionality
//		if ( isPortal && this.config["onNodeClick"] ){ //8.0 functionality
//		    connect.connect( div, "onclick", this, this.config["onNodeClick"] );
//			div.setAttribute("counter", "true");
//		}
//		
//		//Context menus
//		if ( isPortal && this.config['onNodeContextMenu']){
//		    connect.connect( div, "oncontextmenu", this, this.config["onNodeContextMenu"] );
//		} 
//
//		if ( isPortal && this.config['onMouseMove']){
//		    connect.connect( div, "onmouseout", this, this.config["onMouseMove"] );
//		} 
//		
//		if(this.config && this.config["onNodeContextMenu"]){
//		    connect.connect(div, "onmouseover", this, function(){
//				//console.warn("setting window.currentDiagrammerNode");
//	 			window.currentDiagrammerNode = item;
//			});
//	 		
//		    connect.connect(div, "onmouseout", this, function(){
//	 			//console.warn("clearing window.currentDiagrammerNode");
// 				window.currentDiagrammerNode = null;
//	 		});
//		}
//
//
//	},

	/**
	Connect up an event handler for the given node's associated owner's avatar, iff it's necessary (only applies to acitivities).
	 **/
//	imgAddAvatarHandlers: function(item, parent){
//			//console.log("**** imgAddAvatarHandlers::item.type:", item.type);
//			//console.log("**** imgAddAvatarHandlers::item.id:", item.id);
//			
//			//Find the location of the item	
//			var location = this.getActivityLocation( item.id );
//
//			//Create the new div
//			//var main = this.editorPane;
//				
//			var img = document.createElement( 'img' );
//			img.style.borderWidth = "0px";
//			img.style.borderStyle = "solid";
//			
//			img.style.position = "absolute";
//			img.style.top = (location.y+4) + "px";
//			img.style.left = (location.x+2) + "px";
//
//			img.style.width = "16px";
//			img.style.height = "16px";
//			
//			img.style.backgroundColor = 'transparent';
//
//			img.setAttribute('name', item.id );
//		
//			img.style.zIndex = 95;
//			
//			img.src = dojo.moduleUrl("dojo", "resources/blank.gif");
//			for(var x = 0; x < window.SocialPortalUserAvatars.length; x++){
//				if(window.SocialPortalUserAvatars[x].activityId==item.id){
//					img.src = window.SocialPortalUserAvatars[x].imagePath;
//					break;
//				}
//			}
//			
//			img.setAttribute('width', 16);
//			img.setAttribute('height', 16);
//
//			parent.parentNode.appendChild( img );
//			
//			//Connect the event handlers for hover
//			connect.connect( img, "onmouseenter", function(){
//				document.body.style.cursor = 'pointer';
//			});
//				
//			connect.connect( img, "onmouseout", function(){
//				document.body.style.cursor = 'default';
//			});
//
//			img.setAttribute("clickTargetImage", "true");
//			
//			//Click on an avatar
//			if ( this.config["onNodeClick"] ){
//				if(item.counter){
//					img.setAttribute("counter", "true");
//				}
//				connect.connect( img, "onclick", this, this.config["onNodeClick"] );
//			}
//			
//			//Context menus
//			if ( this.config['onNodeContextMenu'] ){ // && isPortal
//			    connect.connect( img, "oncontextmenu", this, this.config["onNodeContextMenu"] );
//			} 
//			/*
//			if ( isPortal && this.config['onMouseMove']){
//				connect.connect( div, "onmouseout", this, this.config["onMouseMove"] );
//			} 
//			*/
//		
//	},

	/**
 	Calculate the x & y co-ordinates for a given activity.
 	PreCondition: The map of activity id / swimlanes has 
 				  already been generated.
	 **/
//	getActivityLocation: function(id){
//		
//		var swimlaneMap = this.IDtoSwimlaneMap;
//		var IDtoActivityMap = this.IDtoItemMap;
//
//		var item = IDtoActivityMap.item( id );
//
//		var parent = swimlaneMap.item( item.id );
//
//		var x = item.x;
//		var y = item.y;
//
//		//BPD Nodes will have a parent swimlane, Service viewer ones will not.
//		if ( parent ){
//			 x = item.x + parent.x + 25;	//Account for the swimlane header width
//			 y = item.y + parent.y 
//		}
//
//		var location = { x: x, y: y };
//
//		return location;
//
//			
//	},

	/**
		Implement zoom functionality for  an image
	 **/
//	zoomImage: function(evt){
//
//	
//
//	},

/**
	 Generate an aria label for a node. Node labels are used for the default WAI support in ILog,
	 but we want to add adorner information.
	**/
	setNodeWAILabel: function( ge ){
		var aria = ge.toString();

		if ( ge.getLabel ){
			aria = ge.getLabel();
		}

		if ( ge.counter && ge.counter.getShape().text.length > 0 ){
			aria += ", instances: " + ge.counter.getShape().text;
		}

		if ( ge.decoratorCount && ge.decoratorCount.getShape().text.length > 0 ){
			aria += ", Loop activity number: " + ge.decoratorCount.getShape().text;
		}

		return aria;

	},

	/**
	 Generate an ARIA label for a link with a label (stored as a 'name' attribute. )
	 Default to ge.toString() if the link is not present.
	 **/
	setLinkWAILabel: function( ge ){
		try{
			var name = ge._data.item.name[0];
			if ( name && name.length > 0 )
				return name;
			else
				return ge.toString();
		}catch( err ){
			return ge.toString();
		}
	},
	
	/**
	 * Used to fix a vertical scrollbar issue in Chrome. The canvas node is too large and overlays the scrollbars preventing us from using the
	 * vertical scrollbars. Create this little workaround until iLog can address in a future release
	 */
	scrollbarFix: function(){
		if (this.ilogDiagrammer.getViewport()._vScrollbarVisible)
			this.ilogDiagrammer.canvasNode.style.right= this.ilogDiagrammer.getViewport().getScrollbarWidth() + "px";
		else
			this.ilogDiagrammer.canvasNode.style.right= "0px";
		}
	
});

});
