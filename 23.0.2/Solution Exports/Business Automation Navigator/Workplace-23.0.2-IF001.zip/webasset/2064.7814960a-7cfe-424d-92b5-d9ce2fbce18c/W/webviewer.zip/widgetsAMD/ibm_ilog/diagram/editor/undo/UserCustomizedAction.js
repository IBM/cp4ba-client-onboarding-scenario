/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"./Action",
"../../util/ErrorReporter"
], function(
declare,
lang,
Action,
R
){
	
/*=====
var Action = ibm_ilog.diagram.editor.undo.Action;
=====*/

	var UserCustomizedAction =
	declare("ibm_ilog.diagram.editor.undo.UserCustomizedAction", [Action], {
		//	
		// summary:
		//		this action is a simple action, that also called a userCustomized function on undo/redo.
		//		The functions onUndo and onRedo must be overwritten by subclasses
		//
		_redoUserFunction: null,
		_undoUserFunction: null,
		
	constructor:function(){
		//	
		// summary:
		//		creates a new instance, setting the corresponding label
		this.initialize(lang.hitch(this,this._undoFunction),lang.hitch(this,this._redoFunction));
	},
	setUndoUserFunction: function(undoUserFunction){
		//	
		// summary:
		//		sets the undoUser function. The set function is called when undo function. The undoUserFunction must be set every time the user adds custom code on drop action.
		this._undoUserFunction = undoUserFunction;
	},
	getUndoUserFunction: function(){
		//	
		// summary:
		//		gets the undoUser function. This function is called when undo function.
		return this._undoUserFunction;
	},
	setRedoUserFunction: function(redoUserFunction){
		//	
		// summary:
		//		sets the undoUser function. The set function is called after the standard undo function is done.
		this._redoUserFunction = redoUserFunction;
	},
	getRedoUserFunction: function(){
		//	
		// summary:
		//		gets the redoUser function.
		return this._redoUserFunction;
	},
	_undoFunction: function(){
		this.undoFunction();
		if(this._undoUserFunction){
			try{
				this._undoUserFunction();
			 }catch(e){
	            	R.error("UndoUserActionError",this.getLabel(),e);
	         }
		}
	},
	_redoFunction: function(){
		this.redoFunction();
		if(this._redoUserFunction){
			try{
				this._redoUserFunction();
			}catch(e){
				R.error("UndoUserActionError",this.getLabel(),e);
			}
		}
	},
	undoFunction: function(){
		//	
		// summary:
		//		this function must be overwritten by subclasses, and is called on undo
	},
	redoFunction: function(){
		//	
		// summary:
		//		this function must be overwritten by subclasses, and is called on redo
	}
	});
	
	return UserCustomizedAction;
	
});
