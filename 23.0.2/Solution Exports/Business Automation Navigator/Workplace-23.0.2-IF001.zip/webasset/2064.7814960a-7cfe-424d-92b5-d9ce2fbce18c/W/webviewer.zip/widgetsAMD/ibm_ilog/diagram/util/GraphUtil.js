/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/lang", "dojo/_base/array", "dojo/_base/window", "dojox/gfx", "dojox/gfx/matrix", "dojox/lang/functional/lambda", "dojox/lang/functional/fold",
"dojox/collections/Set", "dojox/collections/ArrayList",
"./ErrorReporter", "./Geometry"],
function(lang, array, window, gfx, matrix, df, fold, dxcs, ArrayList, R, g){

	var foldl = df.foldl;
	
	// TODO: Change to this when AMD conversion is complete:
	// var gu = {};
	var gu = lang.getObject("ibm_ilog.diagram.util.GraphUtil", true);

gu.allGraphElements = function collectChildren(roots,result) {
	if(!result) {
		result = new ArrayList();
	}
	array.forEach(roots, function(e){
		if(e._isIBMDiagramGraphElement && !result.contains(e)) {
			result.add(e);
			var g;
			if(e._isIBMDiagramSubgraph && (g=e.getGraph().children)) {
				gu.allGraphElements(g,result);
			}
		}
	});
	return result;
};

gu.maximals = function maximals(gs) {
	//
	//	summary:
	//		Returns only the maximal containers for an array of graph elements
	//	s: Array
	//		the array of graph elements
	//

	var r = [];
	var subgraphs = [];

	array.forEach(gs,function(e){
		if(e._isIBMDiagramSubgraph) {
			subgraphs.push(e);
		}
	});
	
	array.forEach(gs,function(e){
		var keep = true;
		
		for( var i=0; keep && i < subgraphs.length; ++i ) {
			var s = subgraphs[i];
			if(s!=e && gu.isContainedBy(e,s)) {
				keep = false;
			}
		}
		if(keep) {
			r.push(e);
		}
		
	},this);
	
	return r;
};

gu.getOwningSubgraph = function getOwningSubgraph(ge) {
	for (var p = gu.safeGetParent(ge); p !== null && p.declaredClass != 'dojox.gfx.Surface'; p = gu.safeGetParent(p)) {
		if (p._isIBMDiagramSubgraph) {
			return p;
		}
	}
	return null;
};

gu.isStableVisible = function(ge){
	//
	//	returns:
	//		true of the graph element is visible in the surface
	//
  for (var p = ge.getParent();p && p.getParent; p=p.getParent()){
  	if(p._isIBMDiagramSubgraph && p._animating) {
  		return false;
  	}
  }
  return p !== null;
};

var _pairLowestCommonAncestor = function _pairLowestCommonAncestor(ga, gb) {
	var gaa;
	if(ga==gb) {
		return ga;
	}
	if (gu.isContainedBy(gb, ga)) {
		return ga;
	}
	if (gu.isContainedBy(ga, gb)) {
		return gb;
	}
	if(gaa = gu.getOwningSubgraph(ga)) {
		return _pairLowestCommonAncestor(gu.safeGetParent(gaa),gb);
	} else {
		return ga;
	}
};

gu.lowestCommonAncestor = function lowestCommonAncestor() {
	var elements = arguments;
	if(arguments[0] instanceof Array) {
		elements = arguments[0];
	}
	var a = elements[0].getParent();
	for(var i=1;i<elements.length;i++) {
		a = _pairLowestCommonAncestor(a,gu.safeGetParent(elements[i]));
	}
	return a;
};

gu.applyStyle = function(shape,style) {
	if(style.fill) {
		shape.setFill(style.fill);
	}
	if(style.stroke) {
		shape.setStroke(style.stroke);
	}
	if(style.font) {
		shape.setStroke(style.font);
	}
	if(style.selectedStyle) {
		shape.selectedStyle = style.selectedStyle;
	}
	if(style.shape) {
		shape.setShape(style.shape);
	}
	if(style.editable && style.editable.style) {
		shape.editable = shape.editable || {};
		shape.editable.style = style.editable.style;
	}
};

gu.getSurface= function(ge) {
	while(ge && ge.getParent) {
		ge = ge.getParent();
	};
	return ge;
};

gu.forEach = function(ge,f,scope) {
	//
	// Simple forEach style iteration through Graph entities
	//	
	scope = scope || window.global;
	if(ge) {
		var isSurface = ge instanceof gfx.Surface;
		var isSubgraph = ge._isIBMDiagramSubgraph;
		var isNode = ge._isIBMDiagramNode;
		var isLink = ge._isIBMDiagramLink;
		var isGroup = ge instanceof gfx.Group;
		
		if( isSurface || isLink || isNode || isSubgraph ) {
			f.call(scope,ge);
		}
		
		var subs = {};
		
		if( isSubgraph ) {
			subs = ge.getGraph().children;
		} else if( isGroup || isSurface ) {
			subs = ge.children;
		}

		array.forEach(subs,function(ge){
			gu.forEach(ge,f,scope);
		});
	}
};

gu.isContainedBy = function(element,container) {
	while(element){
		if(element==container) {
			return true;
		}
		element = gu.safeGetParent(element);
	}
	return false;
};

gu.safeGetParent = function(ge){
	if(ge.getParent && ge.getParent()){
		return ge.getParent();
	}else{
		if(ge._collapsedParent) {
			return ge._collapsedParent;
		}
	}
	return null;
};

gu.doAncestors = function(shape,cb,scope) {
	scope=scope||window.global;
	for(; shape && gu.safeGetParent(shape); shape = gu.safeGetParent(shape)){
		cb.call(scope,gu.safeGetParent(shape));
	}
};

gu.folders = function(kwArgs) {
	var ignore = function(){};
	return lang.mixin({
		graph: ignore,
		group: ignore,
		sub:   ignore,
		node:  ignore,
		link:  ignore,
		other: ignore,
		child: ignore,
		cBase: null,
		accGraph: ignore,
		accSubgraph: ignore,
		accGroup: ignore		
	},
		kwArgs
	);
};

gu.fold = function fold(e,ps,folders,scope,stopRecursionAtCollapsedSub) {
	//
	//	summary:
	//		Graph data structure fold function. --Functional Programming--
	//
	//	description:
	//		Recurses a Graphic offering callbacks to the user at each structural joint. In addition
	//		to the standard folder functions for each kind of entity, this function supports
	//		a state that is built forward on composite nodes [ for processing root-to-leaf instead
	//		of only folding leaf-to-root ].
	//      Also, it allows optionally to stop the recursion at the level of collapsed subgraphs,
	//      which are treated as a node.
	//
	//	types:
	//		G == Graphic
	//		FG == folded graphic
	//		FC == folded child collection
	//		ST == forward-built state
	//
	//	e:  /*G*/
	//		The Graphic to recurse
	//
	//	ps: /*ST*/
	//		the initial parent state
	//
	//	folders: {
	//
	//		graph: function( ST, ST, G, FG ){ return FG; },
	//			Fold a Graph
	//
	//		group: function( ST, ST, G, FG ){ return FG; },
	//			Fold a Group
	//
	//		sub:   function( ST, ST, G, FG ){ return FG; },
	//			Fold a Subgraph (receives folded inner Graph)
	//
	//		node:  function( ST, G ){ return FG; },
	//			Fold a Node
	//
	//		link:  function( ST, G ){ return FG; },
	//			Fold a Group node
	//
	//		other: function( ST, G ){ return FG; },
	//			Fold an unknown node (eventual gfx.Rects, etc.)
	//
	//		child: function( ST, FC, FG ){ return FC; },
	//			Fold a folded Graphic FG into a folded child-collection FC, returning the new collection
	//
	//		cBase: FC
	//			The initially empty folded child collection (constant)
	//
	//		accSubgraph: function( ST, G ){ return ST; }
	//			The forward-state accumulator, builds a new ST given a newly encountered G
	//
	//		accGraph: function( ST, G ){ return ST; }
	//			The forward-state accumulator, builds a new ST given a newly encountered G
	//
	//		accGroup: function( ST, G ){ return ST; }
	//			The forward-state accumulator, builds a new ST given a newly encountered G
	//
	//	}
	//
	//  stopRecursionAtCollapsedSub: 
	//      If true, the recursion stops at the level of collapsed subgraphs, which are
	//      treated as a node. 
	//
	//	NOTE: unstable API
	//
	scope = scope || window.global;
	
	var foldChildren = function(c,ns,stopRecursionAtCollapsedSub) {
			return foldl(c,
				function(z,j){
					return folders.child.call(scope,ns,z,gu.fold(j,ns,folders,scope,stopRecursionAtCollapsedSub));
				},folders.cBase);
	};
	
	if(e._isIBMDiagramSubgraph) { 
	   if (stopRecursionAtCollapsedSub && e.isCollapsed()) {
	     return folders.node.call(scope,ps,e);
	   } else {
	   	 var ns = folders.accSubgraph.call(scope,ps,e); 
	     return folders.sub.call(scope,ps,ns,e,gu.fold(e.getGraph(),ns,folders,scope,stopRecursionAtCollapsedSub));	   	
	   } 
	}
	else if(e._isIBMDiagramNode)     { return folders.node.call(scope,ps,e); }
	else if(e._isIBMDiagramLink)     { return folders.link.call(scope,ps,e); }
	else if(e._isIBMDiagramGraph)    { var ns = folders.accGraph.call(scope,ps,e); 
	                                             return folders.graph.call(scope,ps,ns,e,foldChildren(e.children,ns,stopRecursionAtCollapsedSub)); }
	else if(e instanceof gfx.Group)            { var ns = folders.accGroup.call(scope,ps,e); 
	                                             return folders.group.call(scope,ps,ns,e,foldChildren(e.children,ns,stopRecursionAtCollapsedSub)); }
	else { return folders.other.call(scope,ps,e); }
};

///////////////////////////////////////////////////////////////////////////////
//
// 	fold example 1: logXml(graph)
//

gu.logXml = function(g) {
	
	var acc = function(indent,e) {
		console.log(indent+"<"+e.declaredClass.slice(12)+" id="+(e.getId?e.getId():"?")+">");
		return indent+" ";
	};
	
	var fold = function(parIndent,selfIndent,g) {
		console.log(parIndent+"</"+g.declaredClass.slice(12)+">");
	};
	
	var leaf = function(parIndent,e) {
		console.log(parIndent+"<"+e.declaredClass.slice(12)+" id="+(e.getId?e.getId():"?")+"/>");
	};
	
	var ignore = function(){};

	gu.fold(
		g,
		"", // accumulated forward-state is the indentation string
		{
			graph: fold,
			group: fold,
			sub:   fold,
			node:  leaf,
			link:  leaf,
			other: ignore,
			child: ignore,
			cBase: null,
			accGraph: acc,
			accGroup: acc,
			accSubgraph: acc
		},
		this
	);
};

///////////////////////////////////////////////////////////////////////////////
//
// 	fold example 2: countNodes(graph)
//

gu.countNodes = function(g) {
	
	var add = function(st,siblingSum,childSum) {
		return siblingSum+childSum;
	};
	
	var one = function(){ return 1; };

	var zero = function(){ return 0; };

	var pass = function(ps,ns,g,fc){ return fc; };

	var nothing = function(){};

	return gu.fold(
		g,
		undefined, // forward state not used
		{
			graph: pass,
			group: pass,
			sub:   pass,
			node:  one,
			link:  zero,
			other: zero,
			child: add,
			cBase: 0,
			accGraph: nothing,
			accGroup: nothing,
			accSubgraph: nothing
		},
		this
	);
};


gu.dispatchClass = function(ge,args,context,handlers) {
	return handlers[ge.TID].apply(context,args);
};

gu._howGotHere = function(shape) {
	//
	//	summary:
	//		Debugging helper. Dumps the offsets contributed by 
	//		each transformation in the ancestors of a shape.
	//
	var r, t;
	var print = g.printPoint;
	
	while(shape) {
		r = shape._getRealMatrix();
		
		if(t = shape.getTransform && shape.getTransform()) {
			var p = {x:t.dx / t.xx, y:t.dy/t.yy};
			var d = null; 
			
			var p1 = gu.safeGetParent(shape);
			p1 = p1 && p1._getRealMatrix && p1._getRealMatrix();
			p1 = p1 || matrix.identity;
			p1 = p1 && p1.transformPoint({x:0,y:0});
			
			var p2 = r.transformPoint({x:0,y:0});
			
			console.log( p1?print({x:p2.x-p1.x,y:p2.y-p1.y}):"(-,-)", print(p));
		} else {
			console.log( "--" );
		}
		
		shape = gu.safeGetParent(shape);
	}
};

return gu;

});
