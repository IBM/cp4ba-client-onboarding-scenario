/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"../main",
"dojo/_base/declare",
"./Interactor",
"../Selection"
],
function(
iid,
declare,
Interactor,
Selection
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var SelectionInteractor =
declare("ibm_ilog.diagram.interactors.SelectionInteractor", [Interactor], {
	//summary:
	//		This function provides the functionality to manage selection events on links and nodes.
	//the selection object
	_selection: null,

	//the event generation root
	_root: null,

	initialize: function (root, selection, background) {
		// summary:
		//		creates a new instance, sets the graph element from where to connect and set the default event mapping
		if (selection == null) {
			this._selection = new Selection();
		} else {
			this._selection = selection;
		}
		this._root = root;
		this._background = background;
		this._initialize();
		if(background) {
			this._states.item("idle").addConnection("clear");
		}
		return this;
	},

	_declareStates: function () {
		var idleStates = ["select", "toggle","add"];
		if (iid.mobileEnabled)
			idleStates.push("touchSelect");
		this._declareState("idle", idleStates);
		this._declareState("active", ["move", "end"]);
		this._declareState("activeTouch", ["touchEnd"]);
	},

	getDefaultConnections: function () {
		// summary:
		//		returns the default event mapping
		
		return {
			select: {
				src: this._root,
				srcEvt: "onmousedown",
				connectTo: "_selectPress",
				filter: this._buildInputFilter({ctrl:false}),
				gfxConnect:true
			}, clear: {
				src: this._background,
				srcEvt: "onmousedown",
				connectTo: "_backgroundPress",
				filter: this._buildInputFilter({ctrl:false}),
				gfxConnect:true
			}, toggle: {
				src: this._root,
				srcEvt: "onmousedown",
				connectTo: "_selectionTogglePress",
				filter: this._buildInputFilter({ctrl:true,button:0}),
				gfxConnect:true
			}, add: {
				src: this._root,
				srcEvt: "onmousedown",
				connectTo: "_selectionAddPress",
				filter: this._buildInputFilter({ctrl:true,button:1}), // right button does not toggle out a selected entity
				gfxConnect:true
			}, move: {
				src: document,
				srcEvt: "onmousemove",
				connectTo: "_mouseMoved"
			}, end: {
				src: document,
				srcEvt: "onmouseup",
				connectTo: "_selectRelease"
			}, touchSelect: {
				src: this._root,
				srcEvt: "touchstart",
				connectTo: "_touchSelectPress",
				gfxConnect:true
			}, touchEnd: {
				src: document,
				srcEvt: "touchend",
				connectTo: "_touchSelectRelease"
			}
		};
	},
	
	_getGraphElementFromEvent: function (e) {
		// Summary:
		//		return the selection object
		var ge = this._getGraphElementFromEventInRoot(e, this._root);
		return ge !== this._root ? ge : null;
	},
	
	getSelection: function () {
		// Summary:
		//		return the selection object
		return this._selection;
	},

	//
	//	_focusedEntity: dojox.gfx.shape
	//		The entity focused during a selection operation (null if none)
	//
	_focusedEntity: null,


	_selectPress: function (event) {
		// summary:
		//		clear the selection and select the given element.
		// not multiselect
		this._focusedEntity = this._getGraphElementFromEvent(event);
		if (this._focusedEntity !== null && !this._focusedEntity.isSelected() && this._focusedEntity.isSelectable()  && this._selection.accept(this._focusedEntity)) {
			this._selection.add(this._focusedEntity,true);
		} else {
			this._goStateId("active");
		}
	},

	_touchSelectPress: function (event) {
		//console.log('touchSelectPress');
		event.preventDefault();
		if (event.touches.length > 1)
			return false;
		//event.target = event.touches[0].target;
		// summary:
		//		clear the selection and select the given element.
		// not multiselect
		this._focusedEntity = this._getGraphElementFromEvent(event);
		if (this._focusedEntity !== null && !this._focusedEntity.isSelected() && this._focusedEntity.isSelectable()  && this._selection.accept(this._focusedEntity)) {
			this._selection.add(this._focusedEntity,true);
		} else {
			this._goStateId("activeTouch");
		}
	},

	_mouseMoved: function (e) {
		this._goStateId("idle");
	},

	_selectRelease: function (event) {
		this._goState(null);

		if (!this._focusedEntity) {
			this._selection.clear();
		} else {
			if(this._focusedEntity.isSelectable() && this._selection.accept(this._focusedEntity)){
				this._selection.add(this._focusedEntity,true);
			}
		}
		this._focusedEntity = null;
		this._goStateId("idle");
	},

	_touchSelectRelease: function (event) {
		if (event.touches.length > 0){
			return false;
		}
		this._goState(null);

		if (!this._focusedEntity) {
			this._selection.clear();
		} else {
			if(this._focusedEntity.isSelectable() && this._selection.accept(this._focusedEntity)){
				this._selection.add(this._focusedEntity,true);
			}
		}
		this._focusedEntity = null;
		this._goStateId("idle");
	},

	_selectionTogglePress: function (event,noRemove) {
		// summary:
		//		adds the given element to the selection (if not selected) or remove it from the selection (if selected)
		// multiselect
		this._focusedEntity = this._getGraphElementFromEvent(event);
		if (this._focusedEntity != null) {
			if (!this._focusedEntity.isSelected() && this._focusedEntity.isSelectable() && this._selection.accept(this._focusedEntity)) {
				this._selection.add(this._focusedEntity);
			} else {
				if(!noRemove) {
					this._selection.remove(this._focusedEntity);
				}
			}
		}
	},
	_selectionAddPress: function (event) {
		this._selectionTogglePress(event,true);
	},
	
	_backgroundPress: function(event) {
		this._focusedEntity = null;
		this._goStateId("active"); // will clear if released, cancelled if moved
	}

});

return SelectionInteractor;

});
