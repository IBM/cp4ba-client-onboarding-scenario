/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/declare", "dojo/_base/array", "dojox/collections/_base"],
function(declare, array, collections){

var LimitedStack = declare("ibm_ilog.diagram.util.LimitedStack", [], {
	//
	// Summary:
	//		this class is similar to dojox.collections.Stack, but a maximun size can be set.
	//		When the maxium size is reached, the oldest elements are discarded.
	
		_stack: null,
		_maxSize: null,
		count: null,
		constructor: function(arr,maximumSize){
			this._stack= [];
			this.setMaxSize(maximumSize);
			if(arr){
				this._stack=this._stack.concat(arr);
			}
			this.count=this._stack.length;
		},
		clear: function(){
			//	summary
			//	Clear the internal array and reset the count
			this._stack=[];
			this.count=this._stack.length;
		},
		clone: function(){
			//	summary
			//	Create and return a clone of this Stack
			return new LimitedStack(this._stack);
		},
		contains: function(/* object */o){
			//	summary
			//	check to see if the stack contains object o
			for (var i=0; i<this._stack.length; i++){
				if (this._stack[i] == o){
					return true;	//	bool
				}
			}
			return false;	//	bool
		},
		copyTo: function(/* array */ arr, /* int */ i){
			//	summary
			//	copy the stack into array arr at index i
			arr.splice(i,0,this._stack);
		},
		forEach: function(/* function */ fn, /* object? */ scope){
			//	summary
			//	functional iterator, following the mozilla spec.
			array.forEach(this._stack, fn, scope);
		},
		getIterator: function(){
			//	summary
			//	get an iterator for this collection
			return new collections.Iterator(this._stack);	//	dojox.collections.Iterator
		},
		peek: function(){
			//	summary
			//	Return the next item without altering the stack itself.
			return this._stack[(this._stack.length-1)];	//	object
		},
		pop: function(){
			//	summary
			//	pop and return the next item on the stack
			var r=this._stack.pop();
			this.count=this._stack.length;
			return r;	//	object
		},
		push: function(/* object */ o){
			//	summary
			//	Push object o onto the stack
			//  If the maximum size is reached, the first object is removed (the older object)
			this.count=this._stack.push(o);
			if(this._maxSize && this.count>this._maxSize){
				this._stack.shift();
				this.count--;
			}
		},
		toArray: function(){
			//	summary
			//	create and return an array based on the internal collection
			return [].concat(this._stack);	//	array
		},
		setMaxSize: function(maxSize){
			// summary:
			//		sets maximum size of the stack. If null or 0, no maximum size is set and behaves as a traditional stack.
			this._maxSize = maxSize==0?null:maxSize;
			if(this._maxSize){
				while(this.count>this._maxSize){
					this._stack.shift();
					this.count--;
				}
			}
		},
		getMaxSize: function(){
			// summary:
			//		gets maximum size of the stack.
			return this._maxSize;
		}
});

return LimitedStack;

});