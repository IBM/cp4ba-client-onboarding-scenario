define(["require",
        "dojo/parser",
        "dojo/_base/connect",
        "dijit/_Widget",
        "dijit/_TemplatedMixin",
        "dijit/_WidgetsInTemplateMixin",
        "dijit/_WidgetBase",
        "dijit/Dialog",
        "dojo/_base/declare",
        "dijit/registry",
        "dojo/text!./templates/WpdErrorDialog.html",
        "dojo/i18n!./nls/WpdErrorDialogResources"],
function(require,
        parser,
        connect,
        _Widget,
        _TemplatedMixin,
        _WidgetsInTemplateMixin,
        _WidgetBase,
        Dialog,
        declare,
        registry,
        template,
        nlMessages) {

var _WpdErrorDialog = declare([ _WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin], {

	// Path to the template
	templateString : template,
	
	widgetsInTemplate: true, 
	error : null, 
	_dialogMessages : null,
   	/**
   	 * @param 
   	 */
	constructor : function(){
		this._dialogMessages = nlMessages;
	},
	
	show: function(error) {
		//TODO 2: make the style better: sort of working, except it is not draggable
		//either leave with it. Or remove the wle header, use dojo.dialog header and make radius work
		
		this.error = error;
		this.dialogWindow.containerNode.className="";
		//this.dialogWindow.baseClass = "compareDialog";
		this.dialogWindow.baseClass = "";
		//this.dialogWindow.titleBar.className = "compareDialogTitleBar";
		this.dialogWindow.titleBar.style.visibility = "hidden";
		this.dialogWindow.show();
	},
	
	/*
	 * When user click the More details twister
	 */
	showErrorDetails : function(){
		//TODO3
		//1. for the javascript error, need to format them better. the server side one is fine
		//2. Why the message dose not show up?
//		debugger;
		if (this.errorDetails.style.display == "none"){
			this.errorDetails.style.display = "block";	
			this.errorDetails.innerHTML = this.error;
		}
		else{
			this.errorDetails.style.display = "none";	
			this.errorDetails.innerHTML = "";
		}
	},
	
	close: function() {
		this.dialogWindow.hide();
	}

});

return {
	showError : function(message){
		//find or create	
		var dialog = registry.byId("wpdErrorDialog");
		if(!dialog){
			dialog = new _WpdErrorDialog();
		}
		dialog.show(message);
	}
}

});
