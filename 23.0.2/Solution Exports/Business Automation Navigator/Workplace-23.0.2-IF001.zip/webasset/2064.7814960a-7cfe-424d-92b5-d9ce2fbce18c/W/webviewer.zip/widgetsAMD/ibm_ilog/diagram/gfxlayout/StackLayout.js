/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/lang", "dojo/_base/declare", "./Layout"],
function(lang, declare, Layout){

/*=====
var Layout = ibm_ilog.diagram.gfxlayout.Layout;
=====*/

var StackLayout =
declare('ibm_ilog.diagram.gfxlayout.StackLayout', Layout, {
    // summary:
    //      A layout class that arranges children of a container as a horizontal or vertical stack.
    // description:
    //      The StackLayout class arranges children of a container as a horizontal or vertical stack
    //      depending on the value of its horizontal property. By default, a StackLayout has a vertical flow.
    //      An horizontal stack layout align its children vertically in the computed layout slot according to
    //      their 'valign' (one of the 'top', 'center', 'bottom' and 'stretch' values) and their 'margins' properties.
    //      Respectively, a vertical stack layout align its children horizontally in the computed layout slot according to
    //      their 'halign' (one of the 'left', 'center', 'right' and 'stretch' values) and their 'margins' properties.
    //      The StackLayout class defines the paddingLeft, paddingRight, paddingTop and paddingBottom properties
    //      to specify the internal margins of the panel from which the children are positioned. A convenient global padding
    //      property is also defined to set the same padding in all directions.
    //      Space between children can be adjusted using the gap property.
    
    // orientation
    horizontal: false,
    // padding
    padding: 0,
    paddingLeft: 0,
    paddingRight: 0,
    paddingTop: 0,
    paddingBottom: 0,
    // margin between items
    gap: 0,
    
    constructor: function(args) {
        if (args && 'padding' in args) {
            // you cannot set both padding and paddingXXX at the same time.
            this._setPadding(args.padding, false);
        }
    },
	
	getConfig: function() {
		// summary:
		// 		Gets the current configuration of this layout instance.
		// Description:
		//		This method returns a descriptor of this layout current configuration
		//		as well as the type information so that it can be passed to the Group.setLayout() method
		//		(for example to make a copy the layout of a Group). 
		// returns: Object
		//	An object that represents the layout current configuration.
		var arg = {};
		arg.type = 'ibm_ilog.diagram.gfxlayout.StackLayout';
		if (this.padding) 
			arg.padding = this.padding;
		else {
			arg.paddingLeft = this.paddingLeft;
			arg.paddingRight = this.paddingRight;
			arg.paddingTop = this.paddingTop;
			arg.paddingBottom = this.paddingBottom;
		}
		arg.gap = this.gap;
		arg.horizontal = this.horizontal;
		return arg; /*Object*/
	},
    
    setGap: function(/*Integer*/value) {
        // summary:
        //     Sets the items gap.
        //  value: Integer: the gap between each items. 
        if (value !== this.gap) {
            var old = this.gap;
            this.gap = value;
            this.onLayoutPropertyChanged('gap', old, value);
        }
    },
    
    setHorizontal: function(/*Boolean*/value) {
        // summary:
        //     Sets the stack orientation.
        // value: Boolean: true for an horizontal layout, false otherwise.
        
        if (this.horizontal !== value) {
            var old = this.horizontal;
            this.horizontal = value;
            this.onLayoutPropertyChanged('horizontal', old, value);
        }
    },
    
    setPadding: function(value) {
        // summary:
        //     Sets the padding of this layout.
        // description:
        //     This property is used to set the internal margins of this layout.
        //     The value can either be a 4-elements array whose items match
        //     respectively the left, top, right and bottom paddings ; or one integer
        //     that is applied to all paddings.
        this._setPadding(value, true);
    },
    _setPadding: function(value, notify) {
        if (value instanceof Array) {
            var l = value.length, oldL = this.paddingLeft, oldR = this.paddingRight, oldT = this.paddingTop, oldB = this.paddingBottom;
            if (l > 0) 
                this.paddingLeft = value[0];
            if (l > 1) 
                this.paddingTop = value[1];
            if (l > 2) 
                this.paddingRight = value[2];
            if (l > 3) 
                this.paddingBottom = value[3];
            if (notify &&
            (this.paddlingLeft !== oldL ||
            this.paddingTop !== oldT ||
            this.paddingBottom !== oldB ||
            this.paddingRight !== oldR)) {
            
                this.onLayoutPropertyChanged();
            }
        } else {
            var old = this.padding;
            this.padding = this.paddingLeft = this.paddingRight = this.paddingBottom = this.paddingTop = value;
            if (notify && (value !== old)) {
                this.onLayoutPropertyChanged();
            }
        }
    },
    
    adjustBBox: function(/*dojox.gfx.Rectangle*/bbox) {
        // summary:
        //     Returns the container bbox adjusted according to the constraints of this layout.
        // bbox: Rectangle: the bounding box of the associated container.
        
        bbox.x -= this.paddingLeft;
        bbox.y -= this.paddingTop;
        bbox.width += this.paddingLeft + this.paddingRight;
        bbox.height += this.paddingTop + this.paddingBottom;
        return bbox;
    },
    
    computePreferredSize: function(/*Size*/proposedSize) {
        // summary:
        //     Computes the preferred size of the associated container according to the layout strategy.
        
        var csz = {}, children = this._container.children, count = children.length, maxW = 0, maxH = 0, i, bounds = [];
        
        for (i = 0; i < count; ++i) {
            var s = children[i];
            var sb = s.computePreferredSize(proposedSize);            
			if (s.margins) {
                sb.width = this._inflateH(sb.width, s.margins);
                sb.height = this._inflateV(sb.height, s.margins);
            }
            if (!s.hfiller && sb.width > maxW) 
                maxW = sb.width;
            if (!s.vfiller && sb.height > maxH) 
                maxH = sb.height;
            bounds.push(lang.clone(sb));
        }
        
        if (proposedSize.width !== -1 && proposedSize.height !== -1) {
            return proposedSize;
        }
        if (proposedSize.height !== -1) 
            maxH = proposedSize.height;
        if (proposedSize.width !== -1) 
            maxW = proposedSize.width;
        var lastCoord = 0;
        if (this.horizontal) {
            for (i = 0; i < count; ++i) {
                if (children[i].hfiller)
					continue;
                var sb = bounds[i];
				lastCoord += sb.width;
                if (i < count - 1) 
                    lastCoord += this.gap;
            }
            csz.width = lastCoord;
            csz.height = maxH;
        } else {
            for (i = 0; i < count; ++i) {
                if (children[i].vfiller)
					continue;
                var sb = bounds[i];
                lastCoord += sb.height;
                if (i < count - 1) 
                    lastCoord += this.gap;
            }
            csz.height = lastCoord;
            csz.width = maxW;
        }
        csz.width += this.paddingLeft + this.paddingRight;
        csz.height += this.paddingTop + this.paddingBottom;
        return csz;
    },
    
    layoutChildren: function(/*Size*/contBounds) {
        // summary:
        //     Lays out the children of the associated container.
        
        var children = this._container.children, count = children.length, i;
        contBounds = lang.clone(contBounds);
        
        contBounds.width = Math.max(0, contBounds.width - this.paddingLeft - this.paddingRight);
        contBounds.height = Math.max(0, contBounds.height - this.paddingTop - this.paddingBottom);
        var lastCoord;
        if (this.horizontal) {
            lastCoord = /*contBounds.x +*/ this.paddingLeft;
            for (i = 0; i < count; ++i) {
                var s = children[i];
                var sb = s.getPreferredSize();
                var slot = {};
                slot.x = lastCoord;
                slot.y = /*contBounds.y + */ this.paddingTop;
                slot.height = contBounds.height;
				slot.width = sb.width;
                if (s.margins) 
                    slot.width = this._inflateH(slot.width, s.margins);
                // the elements in the stack must be clipped 
				if (slot.width + lastCoord > contBounds.width)
					slot.width = contBounds.width - lastCoord;
                this.placeChildInSlot(s, slot, false, true);
                lastCoord += slot.width;
                if (i < count - 1) 
                    lastCoord += this.gap;
            }
        } else {
            lastCoord = /*contBounds.y +*/ this.paddingTop;
            for (i = 0; i < count; ++i) {
                var s = children[i];
                var sb = s.getPreferredSize();
                var slot = {};
                slot.x = /*contBounds.x +*/ this.paddingLeft;
                slot.y = lastCoord;
                slot.width = contBounds.width;
                slot.height = sb.height;
                if (s.margins) 
                    slot.height = this._inflateV(slot.height, s.margins);
                // the elements in the stack must be clipped 
				if (slot.height + lastCoord > contBounds.height)
					slot.height = contBounds.height - lastCoord;
                this.placeChildInSlot(s, slot, true, false);
                lastCoord += slot.height;
                if (i < count - 1) 
                    lastCoord += this.gap;
            }
        }
    }
});

return StackLayout;

});
