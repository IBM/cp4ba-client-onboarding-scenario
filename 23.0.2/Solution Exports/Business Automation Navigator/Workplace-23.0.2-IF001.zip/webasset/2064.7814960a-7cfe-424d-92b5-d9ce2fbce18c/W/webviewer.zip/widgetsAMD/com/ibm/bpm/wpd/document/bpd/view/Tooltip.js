/*
Licensed Materials - Property of IBM

(C) Copyright IBM Corporation 2014. All Rights Reserved.
US Government Users Restricted Rights- Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
@author raviray
*/
        
define([
   "dojo/_base/declare", "dojo/_base/lang", "dojo/aspect", "dijit/Tooltip"
], function(declare, lang, aspect, Tooltip) {
   return declare([], {

	aroundNode: null,
	showDelay: 400,
	
	constructor: function()
	{
		// this is invisible node, it is used only as place holder
		this.aroundNode = dojo.create("div", {
			id: 'portalTooltipContainer',
			style: { position: "absolute" } }, dojo.body());
	},
	
    show: function(evt, msg)
    {
    	var x = evt.clientX;
    	var y = evt.clientY;
    	var rtl = false;
    	y +=15;
    	
    	if(biDirection)
    	{
    		rtl = true;
    	}
		dojo.style(this.aroundNode,{
		    	left:x+"px",
		    	top:y+"px"
		});
		
		if(!this._showTimer){
			this._showTimer = this.defer(function(){ 
				dijit.showTooltip(msg, this.aroundNode, ["below"], rtl); }, 
				this.showDelay);
		}
    },
    
    hide: function()
    {
    	if(this._showTimer){
			this._showTimer.remove();
			delete this._showTimer;
		}
    	dijit.hideTooltip(this.aroundNode);
    },
    
	defer: function(fcn, delay)
	{
		var timer = setTimeout(dojo.hitch(this, 
						function(){ 
							timer = null;
							dojo.hitch(this, fcn)();
						}),
						delay || 0
					);
					
		return {
			remove:	function(){
				if(timer){
					clearTimeout(timer);
					timer = null;
				}
				return null;
			}
		};
	}

   });

});
