define({      
//begin v1.x content
    errorDialogTitle: "IBM BPM-feil",
    moreDetails: "Flere detaljer...",
    closeMessage: "Lukk alle feilmeldinger",
    contentMessage: "Det oppstod en feil."
//end v1.x content
});

