/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"../main",
"dojo/_base/declare",
"dojox/gfx",
"../templating"
],
function(
iid,
declare,
gfx,
templating
){

/*=====
var templating = ibm_ilog.diagram.templating;
=====*/

var TemplatedOverlay =
    declare('ibm_ilog.diagram.adorners.TemplatedOverlay',[gfx.Group, templating._DiagramTemplated],{
    	
    	constructor: function() {
	        var id = iid._IdGenerator.nextId(this).toString();
	        this.getId = function() {
	            return id;
	        }
    	}

    });
    
return TemplatedOverlay;
	
});
