/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojox/gfx/matrix",
"../../interactors/DragInteractor",
"../../util/Geometry"
], function(
declare,
m,
DragInteractor,
g
){

/*=====
var DragInteractor = ibm_ilog.diagram.interactors.DragInteractor;
=====*/

var RotateHandleInteractor =
declare("ibm_ilog.diagram.editor.interactors.RotateHandleInteractor", [DragInteractor], {
	//
	//	summary:
	//		This is a sample interactor. It allows to rotate the entities much like 
	//		the resize adorner resizes them. It works if connected to the ResizeHandles like the
	//		ResizeHandleInteractor is connected.
	//	

	//	
	//	_handle: /*ibm_ilog.diagram.editor.adorners.ResizeHandle*/
	//	
	_handle: null,

	initialize: function ( /* ibm_ilog.diagram.editor.adorners.ResizeHandle */ handle) {
		this._handle = handle;
		this._viewport = handle.getViewport();
		this._initialize();
		return this;
	},

	_getInitialEventSource: function () {
		return this._handle;
	},

	activate: function () {
		var a = this._handle._adorner;
		if(a._adorned) {
			this._transform = a._adorned.getTransformToContainer(a._viewport.getSurface()).inverse();
		}
		this.inherited(arguments);
	},

	getDefaultConnections: function () {
		var map = this.inherited(arguments);
		map.start = {
			src: this._getInitialEventSource(),
			srcEvt: "onmousedown",
			connectTo: "_dragPreStart",
			filter: this._buildInputFilter({shift:true,button:0}),
			gfxConnect:true
		};
		return map;
	},

	_getPivot: function (ge) {
		return g.getRectCenter(ge.getBounds());
	},

	_getAngle: function (pivot, p) {
		return Math.atan2(p.x - pivot.x, p.y - pivot.y);
	},

	_dragMove: function () {
		this.inherited(arguments);

		var ge = this._handle._adorner._adorned;
		var p = this._getPivot(ge);
		var a2 = this._getAngle(this._current, p);
		var a1 = this._getAngle(this._last, p);
		ge.applyLeftTransform(m.rotateAt(a1 - a2, p));
	}

});

return RotateHandleInteractor;

});
