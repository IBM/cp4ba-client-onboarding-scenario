/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"./Action",
"./UndoActionList"
], function(
declare,
lang,
Action,
UndoActionList
){

/*=====
var Action = ibm_ilog.diagram.editor.undo.Action;
=====*/

	var ReparentingAction =
	declare("ibm_ilog.diagram.editor.undo.ReparentingAction", [Action], {
		//
		//	summary:
		//		this action undo / redo a reparenting action.
		_newParentId: null,
		_oldParentId: null,
		_modifiedElementId: null,
	
	constructor:function(){
		//	
		// summary:
		//		creates a new instance, setting the corresponding label
		this._label = UndoActionList.ReParent;
		this.initialize(lang.hitch(this,this._undoFunction),lang.hitch(this,this._redoFunction));
	},
	setNewParentId: function(newParentId){
		//	
		// summary:
		//		sets the new parent Id
		this._newParentId = newParentId;
	},
	setOldParentId: function(oldParentId){
		//	
		// summary:
		//		sets the old parent Id
		this._oldParentId= oldParentId;
	},
	setModifiedElementId: function(modifiedElementId){
		//	
		// summary:
		//		sets the modified element Id
		this._modifiedElementId= modifiedElementId;
	},
	_undoFunction: function(){
		var modifiedElement = this.getUndoManager().getRegisteredGraphElement(this._modifiedElementId);
		var oldParent = this.getUndoManager().getRegisteredParent(this._oldParentId);
		oldParent.add(modifiedElement);
	},
	_redoFunction: function(){
		var modifiedElement = this.getUndoManager().getRegisteredGraphElement(this._modifiedElementId);
		var newParent = this.getUndoManager().getRegisteredParent(this._newParentId);
		newParent.add(modifiedElement);
	}
	});
	
	return ReparentingAction;
	
});
