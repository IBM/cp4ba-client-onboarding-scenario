define(["dojo/_base/declare"],

function(declare) {
return declare(null, {
	
	params : null,

	additonalParams: null, 

	constructor : function (parameters, additonalParams) {
		this.params = parameters;
		this.additonalParams = additonalParams;
	},
	
	/**
	 * Execute the command
	 */
	execute : function(){
		
	}

});

});
