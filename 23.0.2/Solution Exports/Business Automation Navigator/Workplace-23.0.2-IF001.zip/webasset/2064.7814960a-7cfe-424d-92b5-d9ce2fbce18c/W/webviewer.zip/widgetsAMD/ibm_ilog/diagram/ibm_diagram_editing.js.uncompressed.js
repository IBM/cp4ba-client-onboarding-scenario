/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */

//>>built
require({cache:{
'ibm_ilog/diagram/editor/undo/PasteNodeAction':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/undo/PasteNodeAction", [
"dojo/_base/declare",
"dojo/_base/lang",
"./UserCustomizedAction",
"./UndoActionList"
], function(
declare,
lang,
UserCustomizedAction,
UndoActionList
){
	
/*=====
var UserCustomizedAction = ibm_ilog.diagram.editor.undo.UserCustomizedAction;
=====*/

var PasteNodeAction =
declare("ibm_ilog.diagram.editor.undo.PasteNodeAction", [UserCustomizedAction], {
	elementId: null,
	parentId: null,
	template: null,
	transformation: null,
	label: null,
	isSubgraph: null,
	collapsed:false,
	constructor:function(){
		this.setLabel(UndoActionList.Paste);
		this.initialize(lang.hitch(this,this._undoFunction),lang.hitch(this,this._redoFunction));
	},
	_undoFunction: function(){
		var ge = this.getUndoManager().getRegisteredGraphElement(this.elementId);
		ge.getParent().remove(ge);
		ge.dispose();
	},
	_redoFunction: function(){
		var container = this.getUndoManager().getRegisteredParent(this.parentId);
		var ge;
		if(this.isSubgraph){
			ge = this.getUndoManager().getDiagram().createSubgraph(this.template,null,container);
		    ge.setCollapsed(this.collapsed);
		}else{
			ge = this.getUndoManager().getDiagram().createNode(this.template,null,container);
		}
	    ge.setTransform(this.transformation);
	    ge.setLabel(this.label);
	    this.getUndoManager().registerGraphElementReplacement(this.elementId,ge.getId());
	}
});

return PasteNodeAction;

});

},
'ibm_ilog/diagram/editor/undo/UserCustomizedAction':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/undo/UserCustomizedAction", [
"dojo/_base/declare",
"dojo/_base/lang",
"./Action",
"../../util/ErrorReporter"
], function(
declare,
lang,
Action,
R
){
	
/*=====
var Action = ibm_ilog.diagram.editor.undo.Action;
=====*/

	var UserCustomizedAction =
	declare("ibm_ilog.diagram.editor.undo.UserCustomizedAction", [Action], {
		//	
		// summary:
		//		this action is a simple action, that also called a userCustomized function on undo/redo.
		//		The functions onUndo and onRedo must be overwritten by subclasses
		//
		_redoUserFunction: null,
		_undoUserFunction: null,
		
	constructor:function(){
		//	
		// summary:
		//		creates a new instance, setting the corresponding label
		this.initialize(lang.hitch(this,this._undoFunction),lang.hitch(this,this._redoFunction));
	},
	setUndoUserFunction: function(undoUserFunction){
		//	
		// summary:
		//		sets the undoUser function. The set function is called when undo function. The undoUserFunction must be set every time the user adds custom code on drop action.
		this._undoUserFunction = undoUserFunction;
	},
	getUndoUserFunction: function(){
		//	
		// summary:
		//		gets the undoUser function. This function is called when undo function.
		return this._undoUserFunction;
	},
	setRedoUserFunction: function(redoUserFunction){
		//	
		// summary:
		//		sets the undoUser function. The set function is called after the standard undo function is done.
		this._redoUserFunction = redoUserFunction;
	},
	getRedoUserFunction: function(){
		//	
		// summary:
		//		gets the redoUser function.
		return this._redoUserFunction;
	},
	_undoFunction: function(){
		this.undoFunction();
		if(this._undoUserFunction){
			try{
				this._undoUserFunction();
			 }catch(e){
	            	R.error("UndoUserActionError",this.getLabel(),e);
	         }
		}
	},
	_redoFunction: function(){
		this.redoFunction();
		if(this._redoUserFunction){
			try{
				this._redoUserFunction();
			}catch(e){
				R.error("UndoUserActionError",this.getLabel(),e);
			}
		}
	},
	undoFunction: function(){
		//	
		// summary:
		//		this function must be overwritten by subclasses, and is called on undo
	},
	redoFunction: function(){
		//	
		// summary:
		//		this function must be overwritten by subclasses, and is called on redo
	}
	});
	
	return UserCustomizedAction;
	
});

},
'ibm_ilog/diagram/editor/DiagramEditor':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/DiagramEditor", [
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"dojo/_base/config",
"dojo/_base/connect",
"dojo/_base/sniff",
"dojox/gfx",
"dojox/collections/Dictionary",
"../base",
"../widget/Diagram",
"../util/HandleSet",
"../Selectable",
"./interactors/DropInteractor",
"./adorners/ResizeAdorner",
"./adorners/ConnectionAdorner",
"./adorners/LinkConnectionAdorner",
"./adorners/LinkIntermediatePointsAdorner",
"./adorners/TextEditAdorner",
"./interactors/ResizeKeyInteractor",
"./interactors/DeleteKeyInteractor",
"./interactors/ConnectionKeyInteractor",
"./interactors/ClipboardKeyInteractor",
"./interactors/UndoManagerKeyInteractor",
"./interactors/InlineEditorKeyInteractor",
"../interactors/SwitchModeInteractor",
"../templates/editor_templates",
"./undo/UndoManager",
"./Clipboard",
"./DiagramSerializer",
"./EditingUtils",
"../util/ErrorReporter",
"../util/Geometry",
"../util/GraphUtil"
], function(
declare,
lang,
array,
config,
connect,
has,
gfx,
Dictionary,
iid,
Diagram,
HandleSet,
Selectable,
DropInteractor,
ResizeAdorner,
ConnectionAdorner,
LinkConnectionAdorner,
LinkIntermediatePointsAdorner,
TextEditAdorner,
ResizeKeyInteractor,
DeleteKeyInteractor,
ConnectionKeyInteractor,
ClipboardKeyInteractor,
UndoManagerKeyInteractor,
InlineEditorKeyInteractor,
SwitchModeInteractor,
editor_templates,
UndoManager,
Clipboard,
DiagramSerializer,
EditingUtils,
R,
g,
gu
)
{

/*=====
var Diagram = ibm_ilog.diagram.widget.Diagram;
=====*/

	var DiagramEditor =
	declare("ibm_ilog.diagram.editor.DiagramEditor", [Diagram], {
		//
		//	summary:
		//		This is an extension of the Diagram Dijit that provides editing capabilities.
		//
		//	description:
		//		In addition to the services from Diagram, this widget includes the following services:
		//
		//		- Can be a drag and drop target (look at samples/dnd/dnd.html)
		//		- Node/Subgraph resizing through adorners
		//		- Link creation and editing through adorners
		//
		_isIBMDiagramEditor: true,
		
		dropable: null,
		
		//
		//	allowFreeLinks: [markup] boolean
		//		this value determine if the interactors can create free links
		//		
		allowFreeLinks: null,
		
		//
		//	onDropFunction: [markup] function
		//		This function is called on diagram drop action
		//		format: DropFunction(droppedItem,point,Diagram,overElements,undoAction)
		//		
		onDropFunction: null,
		
		//
		//	onDropTemplateFunction: [markup] Boolean
		//		this function is called to determine the template on drop action
		// 		format: DropTemplateFunction(droppedItem,dataItem,diagram)
		//		
		onDropTemplateFunction: null,
		
		//
		//	allowCreateLinkFunction: [markup] function
		//		This function is called to know if it is allowed to create a new link between two nodes
		//		return true by default.
		//		format: allowCreateLinkFunction(DiagramEditor, startNode, endNode)
		//		
		allowCreateLinkFunction: null,
		
		//
		//	allowCreateNodeFunction: [markup] Boolean
		//		This function is called to know if it is allowed to create a new node
		//		return true by default.
		//		format: allowCreateNodeFunction(DiagramEditor, parentNode, childNode)
		allowCreateNodeFunction: null,
		
		
		//
		//  move: [markup] boolean
		//      enable or disable moving entities (true by default at DiagramEditor)
		//
		move: true,
		
		//	summary:
		//		Used to disable the initialization of inline-editable fields in the templates, lowering graphic overhead.
		//
		disableInlineEditors: false,
		
		// undoManager: this variables contains the UndoManager instance
		_undoManager: null,
		
		_adornersInitialized: false,
		_resizeAdorner: null,
		_connectionAdorner: null,
		_linkConnectionAdorner: null,
		_linkIntermediatePointsAdorner: null,
		
		enableDropable: function(enabled){
			if (this.dropable == null) {
				this.dropable = new DropInteractor(this, this.onDropFunction, this.onDropTemplateFunction);
			}
			if (enabled) {
				this.dropable.activate();
			} else {
				this.dropable.deactivate();
			}
		},
		
		postMixInProperties: function(){
			this.inherited(arguments);
			this._inlineEditors = new Dictionary();
		},
		
		postPostCreate: function(){
			connect.connect(this, "onNodeCreated", this, "_editorNodeCreated");
			connect.connect(this, "onLinkCreated", this, "_editorLinkCreated");
			connect.connect(this, "onSubgraphCreated", this, "_editorSubgraphCreated");
		},
		
		reset: function(){
			this.inherited(arguments);
			this._undoManager.reset();
			this._clipboard.clear();
		},
		
		// ========================================================================================================
		//
		//	INTERACTORS:
		//
		
		getAssociatedLinkAdornersFunction: function(ge){
			if (this._adornersInitialized) {
				return [this._linkConnectionAdorner, this._linkIntermediatePointsAdorner];
			} else {
				return [];
			}
		},
		
		getAssociatedNodeAdornersFunction: function(ge){
			if (this._adornersInitialized) {
				return [this._resizeAdorner, this._connectionAdorner];
			} else {
				return [];
			}
		},
		
		getAssociatedSubgraphAdornersFunction: function(){
			if (this._adornersInitialized) {
				if (config.useGfxLayout) {
					return [this._connectionAdorner];
				} else {
					return [this._resizeAdorner, this._connectionAdorner];
				}
			} else {
				return [];
			}
		},
		
		_initializeInteractors: function(){
			//
			//	summary:
			//		Initializes the interactors used by the Diagram
			//
			this._initializeUndoManager();
			
			this._initializeClipboard();
			
			this.inherited(arguments);
			
			this.enableDropable(true);
			
		},
		
		_initializeKeyInteractors: function(){
			//
			//	tags:
			//		private
			//
			this.inherited(arguments);
			
			this._keyInteractors.add(ResizeKeyInteractor.KeyInteractorId, new ResizeKeyInteractor().initialize(this));
			
			this._keyInteractors.add(DeleteKeyInteractor.KeyInteractorId, new DeleteKeyInteractor().initialize(this));
			
			this._keyInteractors.add(ConnectionKeyInteractor.KeyInteractorId, new ConnectionKeyInteractor().initialize(this));
			
			this._keyInteractors.add(ClipboardKeyInteractor.KeyInteractorId, new ClipboardKeyInteractor().initialize(this));
			
			this._keyInteractors.add(UndoManagerKeyInteractor.KeyInteractorId, new UndoManagerKeyInteractor().initialize(this));
			
			this._keyInteractors.add(InlineEditorKeyInteractor.KeyInteractorId, new InlineEditorKeyInteractor().initialize(this));
			
			var edition = this._keyInteractors.get(SwitchModeInteractor.KeyInteractorId);
			edition.addEditionInteractorId(ResizeKeyInteractor.KeyInteractorId);
			edition.enterNavigation();
			
		},
		
		_initializeUndoManager: function(){
			this._undoManager = new UndoManager(this);
		},
		
		registerInlineEditor: function(id, editor){
			//
			//	summary:
			//		Registers a new inline editor with a certain id.
			//	id: string
			//		The associated id for referencing the editor from editable attachpoints at graph element templates.
			//	editor: ibm_ilog.diagram.editor.adorners.TextEditAdorner
			//		The adorner used as editor.
			this._inlineEditors.add(id, editor);
		},
		
		_createAdorners: function(){
			this.inherited(arguments);
			this._resizeAdorner = this.createAdorner(ResizeAdorner, this._adornerTemplates, "ResizeAdorner");
			this._connectionAdorner = this.createAdorner(ConnectionAdorner, this._adornerTemplates, "ConnectionAdorner");
			this._linkIntermediatePointsAdorner = this.createAdorner(LinkIntermediatePointsAdorner, this._adornerTemplates, "LinkIntermediatePointsAdorner");
			this._linkConnectionAdorner = this.createAdorner(LinkConnectionAdorner, this._adornerTemplates, "LinkConnectionAdorner");
			this.registerInlineEditor("textbox", this.createAdorner(TextEditAdorner, this._adornerTemplates, "TextEditAdorner"));
			this.getInlineEditorId("textbox").textbox.prepare(this.canvasNode);
			this._adornersInitialized = true;
		},
		
		enterStandardMode: function(){
			//
			//	summary:
			//		TODO TBD. Probably to be renamed also
			//    	
			this._interactors.switchTo("move", "select", "pan", "zoom", "focus", "adorners", "marquee", "wheelPan");
			
		},
		resolveNodeTemplate: function(item){
			// summary:
			//    Returns the template to represent the specified node item.
			//    item: dojo.data.Item: the node data item.
			var dropTemplate = (this.dropable && this.dropable.isDropAction()) ? this.dropable.resolveNodeTemplate(item) : null;
			return dropTemplate != null ? dropTemplate : this.inherited(arguments);
			
		},
		setAcceptedDropTypes: function(types){
			// summary:
			//    Sets the accepted types to be dropped.
			if (this.dropable != null) {
				this.dropable.setAcceptedTypes(types);
				this.enableDropable(false);
				this.enableDropable(true);
			}
		},
		
		getDropInteractor: function(){
			// summary:
			//    return the drop interactor
			return this.dropable;
		},
		
		onLinkUpdated: function(diagram, link, isNew, undoAction){
			// sumamry:
			//		The user must connect to this function to create the link in the linkstore or customize the created link.
			// diagram: ibm_ilog.diagram.editor.DiagramEditor
			//		this is the DiagramEditor instance.
			// link: ibm_ilog.diagram.Link
			//		the updated link.
			// isNew: boolean
			//		identify if the link is recently created (true) or just modified (false).
			// undoAction: ibm_ilog.diagram.editor.undo.Action
			//		the Action that take place in this edition
		},
		
		allowCreateLink: function(startNode, endNode){
			// summary:
			//		evaluates if the link between two nodes can be created, based on the allowCreateLinkFunction
			// startNode: ibm_ilog.diagram.Node
			//		the possible link start node
			// enNode: ibm_ilog.diagram.Node
			//		the possible link end node
			return this.allowCreateLinkFunction ? this.allowCreateLinkFunction.call(null, this, startNode, endNode) : true;
		},
		
		allowCreateNode: function(parent, child){
			// summary:
			//		evaluates if the nodes can be created, based on the allowCreateLinkFunction
			// parent: ibm_ilog.diagram.Node
			//		the possible parent of the node
			// child: ibm_ilog.diagram.Node
			//		the created node
			return this.allowCreateNodeFunction ? this.allowCreateNodeFunction.call(null, this, parent, child) : true;
		},
		
		getUndoManager: function(){
			// summary:
			//		return the private instance of ibm_ilog.diagram.editor.undo.UndoManager
			return this._undoManager;
		},
		
		getAllowFreeLinks: function(){
			// summary:
			//		This method is deprecated from 1.1. Use dojo.get('allowFreeLinks') instead.
			//		true, if the diagram allow free links (links with no end or start node)
			return this.allowFreeLinks ? this.allowFreeLinks : false;
		},
		
		setAllowFreeLinks: function(allowFreeLinks){
			// summary:
			//		This method is deprecated from 1.1. Use dojo.set('allowFreeLinks', value) instead.
			//		Sets if the diagram allow free links (links with no end or start node)
			// allowFreeLinks: boolean
			// 		true, if the diagram allow free links (links with no end or start node)
			this.allowFreeLinks = allowFreeLinks;
		},
		
		
		// ========================================================================================================
		//
		//	INLINE EDITORS:
		//
		
		//
		//	defaultEditableRegionStyle:
		//		The style to be used for the editable region
		//
		defaultEditableRegionStyle: {
			fill: [0, 0, 0, 0.001],
			selectedStyle: {
				stroke: {
					style: 'ShortDot',
					color: 'black'
				}
			}
		},
		
		_isAttachPointEditable: function(a){
			//	summary:
			//		returns true if an attachPoint has a valid editable region information 
			//	a: the component
			return (a.shape.type == "text" || a.shape.type == "mltext") && a.editable && a.editable.editor && this._inlineEditors.contains(a.editable.editor) && (a.editable.id || (a.editable.getter && a.editable.setter));
		},
		
		_getEditableRegionBoundingBox: function(a){
			//	summary:
			//		returns the bounding box of the editable component
			//	a: the component that was declared editable
			var empty = g.EmptyRect, bb = a.getBoundingBox(), ed = a.editable;
			if (ed.baseRegion) {
				if (!bb) {
					bb = ed.baseRegion;
				} else {
					bb = g.addRect(bb, ed.baseRegion);
				}
			}
			if (ed.minRegionSize) {
				if (!bb) {
					bb = g.standarizeRect(ed.minRegionSize);
				} else {
					var w = ed.minRegionSize.width;
					var h = ed.minRegionSize.height;
					if (w) {
						bb = g.rectCenteredOverride(bb, {
							width: Math.max(w, bb.width)
						});
					}
					if (h) {
						bb = g.rectCenteredOverride(bb, {
							height: Math.max(h, bb.height)
						});
					}
				}
			}
			if (!bb) 
				bb = empty;
			var tr = a.getTransform();
			if (tr) {
				bb = tr.transformRectangle(bb);
			}
			if (ed.border && bb) {
				bb = g.expandRect(bb, ed.border);
			}
			return bb || empty;
		},
		
		_onEditableTextChanged: function(a, ge, er){
			//	summary:
			//		updates the editable region shape when its bounds have changed
			//	a: the component that was declared editable
			//	ge: the graph element
			//	er: the editable region shape
			
			if (has("ie") > 7 && iid.isVml && er.__ie8Handler !== undefined) {
				// dispose the handler set to solve ie8/vml setShape issue (see _createEditableRegionShape)
				er.disconnect(er.__ie8Handler);
			}
			er.setShape(this._getEditableRegionBoundingBox(a));
			if(er.computePreferredSize) er.computePreferredSize({width:-1, height:-1});
		},
		
		_createEditableRegionShape: function(a, ge){
			//	summary:
			//		created the editable region shape associated with an editable component
			//	a: the component that was declared editable
			//	ge: the graph element
			var editable = a.editable;
			var bb = this._getEditableRegionBoundingBox(a);
			var editableBaseShape = a.parent.createRect(bb);
			
			var style = lang.clone(this.defaultEditableRegionStyle || {});
			lang.mixin(style, editable.regionStyle);
			
			gu.applyStyle(editableBaseShape, style);
			
			if (editable.layoutProperties) 
				lang.mixin(editableBaseShape, editable.layoutProperties);
			
			if (gfx.renderer == "silverlight") {
				editableBaseShape.connect("onclick", this, function(){
					this._openInlineEditor(ge, a, editableBaseShape);
				});
			} else {
				editableBaseShape.connect("ondblclick", this, function(){
					this._openInlineEditor(ge, a, editableBaseShape);
				});
				// The edit shape can easily hide the expand button, so listen to clicks on the edit shape
				// and forward them to the button if necessary.
				if(ge._isIBMDiagramSubgraph){
					editableBaseShape.connect("onclick", this, function(e){
						var p = this.getViewport().eventContentLocation(e);
						if(ge.isCollapsed()){
							var b = ge._expandButton;
							if(b){
								var bb = b.getBoundingBox();
								if(bb){
									bb = b.getShapeToContainerTransform(this.getGraph()).transformRectangle(bb);
									if(g.containsPoint(bb, p)){
										ge._expandButtonClicked(e);
									}
								}
							}
						}
					});
				}
			}
			
			if (has("ie") > 7 && iid.isVml){
				connect.connect(editableBaseShape, 'setShape', this, function(){
					// in IE8/VML Rect.setShape creates a new rawNode. need to update the connections
					editableBaseShape.__ie8Handler = editableBaseShape.connect("ondblclick", this, function(){
						this._openInlineEditor(ge, a, editableBaseShape);
					});
				});
			}

			
			return editableBaseShape;
		},
		
		getInlineEditorId: function(id){
			//	summary:
			//		returns the inline editor registered with the given id
			return this._inlineEditors.item(id);
		},
		
		_openInlineEditor: function(ge, a, editableBaseShape){
			//	summary:
			//		opens an inline editor on the component a of graph element ge
			//	ge: the graph element
			//	a: the editable attachpoint
			//	editableBaseShape: the editable region shape
			this.visualizeBounds(ge, {
				expandCurrent: true
			});
			
			var e = this.getInlineEditorId(a.editable.editor), set, get;
			
			if (a.editable.id) {
				var uname = (a.editable.id.substr(0, 1).toUpperCase()) + a.editable.id.substr(1);
				get = "get" + uname;
				set = "set" + uname;
			} else {
				get = a.getter;
				set = a.setter;
			}
			if (a.editable.options) {
				e.setOptions(a.editable.options);
			}
			e.setAccessors(function(adorned){
				return adorned[get]();
			}, function(adorned, value){
				adorned[set](value);
			});
			
			e.setComponentAttachPoint(a);
			e.setComponent(editableBaseShape);
			e.setAdorned(ge);
		},
		
		initializeEditables: function(ge){
			//	summary:
			//		scan the attachpoints of graph element ge in search for editable 
			//		fields initialize the corresponding infrastructure to allow editing.  
			//	ge: the graph element
			if (!this.disableInlineEditors) {
				var maybeEditables = ge._attachPoints;
				array.forEach(ge._attachPoints, function(id){
					var a = ge[id];
					if (this._isAttachPointEditable(a)) {
						try {
							var editableBaseShape = this._createEditableRegionShape(a, ge);
							var textChanged = function(){
								this._onEditableTextChanged(a, ge, editableBaseShape);
							};
							
							// TODO need a.onChange here
							ge.addConnection(connect.connect(a, "setShape", this, textChanged));
							ge.addConnection(connect.connect(a, "setFont", this, textChanged));
							if (a.applyLayout) 
								ge.addConnection(connect.connect(a, "applyLayout", this, textChanged));
							if (ge._isIBMDiagramSubgraph) {
								ge.addConnection(connect.connect(ge, "onCollapsedChanged", this, textChanged));
							}
							ge.__editables = (ge.__editables || []);
							ge.__editables.push({
								ge: ge,
								attach: a,
								base: editableBaseShape
							});
						} catch (e) {
							R.warn("Wrapped", "DiagramEditor.js # initializeEditables", e);
						}
					}
				}, this);
			}
		},
		
		getEditables: function(ge){
			//
			//	summary:
			//		Return the editable attachpoints of a graph element
			//	ge:
			//		ibm_diargram.GraphElement
			//	returns:
			//		The set of the editable attachpoint belonging to a graph element.
			//
			return ge.__editables;
		},
		
		openEditableInlineEditor: function(editable){
			//
			//	summary:
			//		Open the inline editor associated with a graph element editable attachpoint.
			//	editable: {ge:,attach:,base:}
			//		The editable attachpoint belonging to a graph element.
			//
			this._openInlineEditor(editable.ge, editable.attach, editable.base);
		},
		
		_editorNodeCreated: function(node, diagram){
			this.initializeEditables(node);
		},
		
		_editorSubgraphCreated: function(subgraph, diagram){
			this.initializeEditables(subgraph);
		},
		
		_editorLinkCreated: function(link, diagram){
			this.initializeEditables(link);
		},
		
		// ========================================================================================================
		//
		//	CLIPBOARD:
		//
		_clipboard: null,
		
		_initializeClipboard: function(){
			this._clipboard = new Clipboard(this);
		},
		getClipboard: function(){
			// summary:
			//		return the private instance of ibm_ilog.diagram.editor.Clipboard
			return this._clipboard;
		},
		
		// =========================================================================================================
		//
		//	RemoveSerializer:
		// 
		
		_removeSerializer: null,
		
		_getRemoveSerializer: function(){
			var thiz = this;
			if (!this._removeSerializer) {
				var notificationObject = {
					diagram: thiz,
					onSerialize: function(graphElement, serializedData){
					},
					onDeserialize: function(serializedData, newGraphElement, container, undoAction){
						var um = this.diagram.getUndoManager();
						um.registerGraphElementReplacement(serializedData.id, newGraphElement.getId());
					}
				};
				this._removeSerializer = new DiagramSerializer(this, null, notificationObject);
			}
			return this._removeSerializer;
		},
		
		// doDeleteFunction: Function
		// An optional function that handles delete operation and returns a corresponding Action
		// to be added to the undo manager (see ibm_ilog.diagram.editor.undo.Action). If no function
		// is specified, the default behavior is to remove and dispose the graphical shapes from the diagram
		// without any datastore-related considerations.
		// The function receives the following parameters:
		//		diagram: ibm_ilog.diagram.widget.Diagram. The diagram containing the elements to remove.
		//		elements: ibm_ilog.diagram.GraphElement. The graphical elements to delete.
		// The function must returns a ibm_ilog.diagram.editor.undo.Action instance that matches the function implementation (aka:
		// capable of undoing the deletion).
		doDeleteFunction : null,
		
		deleteGraphElements: function(/*ibm_ilog.diagram.GraphElement[]*/elements){
			// summary:
			//		Deletes the selected elements and all the connected links. 
			// description:
			//		This method should be invoked to delete the specified elements from the diagram and handles the 
			//		interface with the undo manager. The way the delete operation
			//		itself is performed may be customized by setting the doDeleteFunction property to a custom implementation. The
			//		default implementation removes and disposes the graphical shapes from the diagram without any datastore-related
			//		considerations. If you need to change this behavior, set this property so that it gets invoked instead of the default implementation.
			// elements: ibm_ilog.diagram.GraphElement[]
			// 		The elements to delete.
			// returns:
			//		true if the deletion could be performed, false otherwise.
		
			if (elements) {
				var action = EditingUtils.deleteGraphElements(this, elements, this.doDeleteFunction);
				var um = this.getUndoManager();
				um.addAction(action);
				return true; // Boolean
			}
			return false; // Boolean
		},
		
		// marks the end of definition to make life easier with trailing '},'...
		__eod: null
	});
	
	return DiagramEditor;
	
});


},
'ibm_ilog/diagram/editor/interactors/DeleteKeyInteractor':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/interactors/DeleteKeyInteractor", [
"dojo/_base/declare",
"dojo/keys",
"../../interactors/Interactor"
], function(
declare,
keys,
Interactor
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var DeleteKeyInteractor =
declare("ibm_ilog.diagram.editor.interactors.DeleteKeyInteractor", [Interactor], {
	//summary:
	//		This interactor manages the graphElements deletion through the keyboard interaction.
	//		This interactor has 2 connections: deleteDelete, deleteBackSpace. Both connections call the "doDelete" method.
	_diagram: null,
	_serializer: null,
	initialize: function (diagram) {
		// summary:
		//		initialize the new instance.
		// diagram: ibm_ilog.diagram.editor.DiagramEditor
		//		the associated diagram editor.		
		this._diagram = diagram;
		return this._initialize();
	},
	getKeyInteractorId: function(){
		// summary:
	    //		returns the Interactor Id
		return DeleteKeyInteractor.KeyInteractorId;
	},
	getDefaultConnections: function () {
		// summary:
		//		returns the default event mapping
		
		return {
			deleteDelete: {
				hotKey: keys.DELETE,	
				connectTo: "doDelete"
			}, 
			deleteBackSpace: {
				hotKey: keys.BACKSPACE,
				connectTo: "doDelete"
			}
		};
	},
	
	doDelete: function(){
		// summary:
		//		Deletes the selected elements and all the connected links. If none selected,
		//		removes the focused element and all connected links.
		var targetSet = this._buildTargetSet();
		return targetSet ? this._diagram.deleteGraphElements(targetSet) : false;
	},
	
	_buildTargetSet: function(){
		//
		//	summary:
		//		Builds the set of entities that are going to be affected by the delete action.
		//
		//	description:
		//		gets the selected object and iterate over them to add all the children and 
		//		connected nodes to to deletion target set.
		//		If no element is selected, the target set is created based on the focused object.
		var selection = this._diagram.getSelection();
		var s = selection.fastGet().toArray();
		var targetSet = null;
		
		if(s.length == 0){
			var c = this._diagram.getFocusedElement();
			if(c){
				targetSet = [c];
			}else{
				return null;
			}
		}else{
			targetSet = s;
		}
		return targetSet;
	}
});

DeleteKeyInteractor.KeyInteractorId = "Delete";

return DeleteKeyInteractor;

});

},
'ibm_ilog/diagram/editor/adorners/ConnectionHandle':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/adorners/ConnectionHandle", [
"dojo/_base/declare",
"../../base",
"../../adorners/HighlightedHandle",
"../interactors/ConnectionHandleInteractor"
], function(
declare,
iid,
HighlightedHandle,
ConnectionHandleInteractor
){

/*=====
var HighlightedHandle = ibm_ilog.diagram.adorners.HighlightedHandle;
=====*/

	var ConnectionHandle =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.ConnectionHandle',[HighlightedHandle],{
		
		//
		//	_location: Point
		//
		location: null,
		
		setup: function(location) {
			this.location = location;
			this.addInteractor(new ConnectionHandleInteractor().initialize(this));
			return this;
		},
		
		getPortPosition:function(){
			return this.location;
		}
	}));
	
	ConnectionHandle.templateId = "ConnectionHandle";

	return ConnectionHandle;
	
});

},
'ibm_ilog/diagram/editor/undo/ReparentingAction':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/undo/ReparentingAction", [
"dojo/_base/declare",
"dojo/_base/lang",
"./Action",
"./UndoActionList"
], function(
declare,
lang,
Action,
UndoActionList
){

/*=====
var Action = ibm_ilog.diagram.editor.undo.Action;
=====*/

	var ReparentingAction =
	declare("ibm_ilog.diagram.editor.undo.ReparentingAction", [Action], {
		//
		//	summary:
		//		this action undo / redo a reparenting action.
		_newParentId: null,
		_oldParentId: null,
		_modifiedElementId: null,
	
	constructor:function(){
		//	
		// summary:
		//		creates a new instance, setting the corresponding label
		this._label = UndoActionList.ReParent;
		this.initialize(lang.hitch(this,this._undoFunction),lang.hitch(this,this._redoFunction));
	},
	setNewParentId: function(newParentId){
		//	
		// summary:
		//		sets the new parent Id
		this._newParentId = newParentId;
	},
	setOldParentId: function(oldParentId){
		//	
		// summary:
		//		sets the old parent Id
		this._oldParentId= oldParentId;
	},
	setModifiedElementId: function(modifiedElementId){
		//	
		// summary:
		//		sets the modified element Id
		this._modifiedElementId= modifiedElementId;
	},
	_undoFunction: function(){
		var modifiedElement = this.getUndoManager().getRegisteredGraphElement(this._modifiedElementId);
		var oldParent = this.getUndoManager().getRegisteredParent(this._oldParentId);
		oldParent.add(modifiedElement);
	},
	_redoFunction: function(){
		var modifiedElement = this.getUndoManager().getRegisteredGraphElement(this._modifiedElementId);
		var newParent = this.getUndoManager().getRegisteredParent(this._newParentId);
		newParent.add(modifiedElement);
	}
	});
	
	return ReparentingAction;
	
});

},
'dojox/dtl':function(){
define("dojox/dtl", ["./dtl/_base"], function(dxdtl){
	return dxdtl;
});
},
'ibm_ilog/diagram/editor/interactors/LinkConnectionHandleInteractor':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/interactors/LinkConnectionHandleInteractor", [
"../../main",
"dojo/_base/declare",
"dojox/gfx",
"dojo/_base/lang",
"../../interactors/DragInteractor",
"../interactors/ConnectionTargetInteractor",
"../undo/ReConnectAction",
"../undo/ReparentingAction",
"../undo/MultipleAction",
"../undo/UndoActionList",
"../../Port",
"../../util/GraphUtil"
], function(
iid,
declare,
gfx,
lang,
DragInteractor,
ConnectionTargetInteractor,
ReConnectAction,
ReparentingAction,
MultipleAction,
UndoActionList,
Port,
gu
){

/*=====
var DragInteractor = ibm_ilog.diagram.interactors.DragInteractor;
=====*/

var LinkConnectionHandleInteractor =
declare("ibm_ilog.diagram.editor.interactors.LinkConnectionHandleInteractor", [DragInteractor], {

	//	_handle: /*ibm_ilog.diagram.editor.ConnectionHandle*/
	_handle:null,
	_automaticPortType: false,
	_target: null,
	_targetPosition: null,
	_targetInteractor: null,
	_allowFreeLinks: false,
	_link: null,
	_savedConnection: null,
	_oldLinkParent: null,
	
	initialize: function( /* ibm_ilog.diagram.editor.ConnectionHandle */ connectionHandle ) {
		this._handle = connectionHandle;
		this._viewport = connectionHandle.getViewport();
		this._targetInteractor = new ConnectionTargetInteractor().initialize(this._handle._adorner._viewport._diagram,this);
		this._initialize();
		return this;
	},
	
	setTarget: function(target){
		// Summary:
		// 		sets the target to be binded with the link 
		this._target = target;
	},
	
	setPortPosition: function(position){
		// Summary:
		//		sets the port position where to bind the link
		this._targetPosition = position;
	},
	_getInitialEventSource: function() {
		return this._handle;
	},

    _dragPreStart: function() {
		this._allowFreeLinks = this._viewport.getDiagram().getAllowFreeLinks();
		this._handle.interactionBegun(this);
		this.inherited(arguments);
	},
	
	_dragMove: function(e) {
    	
		this.inherited(arguments);
		
    	var A = this._handle._adorner;
    	var V = A._viewport;
    	var portPosition = this._handle.getLocation();

		if( this._link == null ){
			this._link = A._adorned;
			this._link._no_reconnect_on_add = true; // to avoid an infinite event look
			this._targetPosition = null;
			var fixedNode,isStart;
			
			var port,point;
			if(portPosition == 0){
				port= this._link.getStartPort();
				point= this._link.getFallbackStartPoint();
				this._link.setStartPort(null);
				fixedNode = this._link.getEndNode();
				isStart = false;
			}else{
				port= this._link.getEndPort();
				point= this._link.getFallbackEndPoint();
				this._link.setEndPort(null);
				fixedNode = this._link.getStartNode();
				isStart = true;
			}
			
			//Save unused port data
			if(port){
				this._savedConnection = {
					auto: !port._isIBMDiagramBasicPort,
					position: port._isIBMDiagramBasicPort?port.getPosition():null,
					node: port.getOwner()	
				};
			}else{
				this._savedConnection = {
						point: lang.clone(point)
				};
			}
			
			//remove unused Port
			if(port && port._isIBMDiagramBasicPort){
				port.getOwner().removePort(port);
			}
			
			//Set the top level parent
			this._oldLinkParent = this._link.getParent();
			V.getDiagram().getGraph().add(this._link);
			this._targetInteractor.setUp(fixedNode,isStart,this._allowFreeLinks);
			this._targetInteractor.activate();
		}
		
		var point = V.eventContentLocation(e);
		var t = this._link.getShapeToContainerTransform(V._diagram.getGraph().getParent()).inverse();
		point = t.transformPoint(point);
		
		if(portPosition == 0){
			point = this._displacePoint(point,this._link,true);
			this._link.setFallbackStartPoint(point);
		}else{
			point = this._displacePoint(point,this._link,false);
			this._link.setFallbackEndPoint(point);
		}
		
		this._link.validateLinkShape();
	},

	_dragEnd: function(e) {
		this.inherited(arguments);
		var A = this._handle._adorner;
		var V = A._viewport;
		var D = A._diagram;
		var portPosition = this._handle.getLocation();
		if( this._link != null ){
			if(this._target){
				var connection = {auto:this._automaticPortType,
								  position: this._targetPosition,
								  node: this._target};
				
				this._applyConnection(this._link,portPosition,connection,this._createPort);
				
				//reparent the link, with the lower common parent
				var start = this._link.getStartPort().getOwner();
				var end = this._link.getEndPort().getOwner();
				if(D.allowCreateLink(start,end)){
					var cParent = gu.lowestCommonAncestor(start,end);
					if(cParent!=this._oldLinkParent){
						if(iid.isVml){
							// workaround for VML remove/add bug, occurs here since fixVmlAdd flag was added
							var oldParent = this._oldLinkParent;
							if(oldParent) { oldParent.remove(this._link); }
							cParent.rawNode.appendChild(this._link.rawNode);
							gfx.shape.Container.add.call(cParent, this._link);
							gfx.utils.forEach(this._link, function(s){
								if(s.setFill) s.setFill(s.getFill());
								if(s.setStroke) s.setStroke(s.getStroke());
							});
						} else {
							cParent.add(this._link);
						}
					}
					var action = this._createUndoReConnectionAction(D,this._link,cParent,this._oldLinkParent,portPosition,this._savedConnection,connection);
					D.onLinkUpdated(D,this._link,false,action);
					if(D._isIBMDiagramEditor){
						D.getUndoManager().addAction(this._createUndoAction(D,this._link,cParent,this._oldLinkParent,action));
					}
				}else{
					this._applyConnection(this._link,portPosition,this._savedConnection,this._createPort);
					//TODO add onMessage call
				}
			}else{
				if(!this._allowFreeLinks){
					this._applyConnection(this._link,portPosition,this._savedConnection,this._createPort);
					//TODO add onMessage call
				}else{
					var action = this._createUndoReConnectionAction(D,this._link,this._link.getParent(),this._oldLinkParent,portPosition,this._savedConnection,connection);
					D.onLinkUpdated(D,this._link,false,action);
					if(D._isIBMDiagramEditor){
						var connection = {point:lang.clone(portPosition==0?this._link.getFallbackStartPoint():this._link.getFallbackEndPoint())};
						D.getUndoManager().addAction(this._createUndoReConnectionAction(D,this._link,this._link.getParent(),this._oldLinkParent,action));
					}
				}
			}
			
			this._savedPort = null;
			delete this._link._no_reconnect_on_add;
			this._link =null;
			this._targetInteractor.deactivate();
		}
		this._handle.interactionEnded(this);
	},
	
	_displacePoint: function(point,link,isStart){
		// Added to fix requirement 642
		var p;
		if(!isStart){
			p = link._pathPoints[link._pathPoints.length-1];
		}else{
			p = link._pathPoints[0];
		}
		var dx = (point.x-p.x)<0?5:-5;
		var dy = (point.y-p.y)<0?5:-5;
		return {x: point.x+dx, y: point.y+dy};
	},
	
	_applyConnection: function(link,portPosition,connection,portFunction){
		var port;
		if(connection.node){
			port = portFunction.call(this,connection.auto,connection.position);
			connection.node.addPort(port);
		}
		if(portPosition == 0){
			if(port){
				link.setStartPort(port);
			}else{
				link.setFallbackStartPoint(lang.clone(connection.point));
			}
		}else{
			if(port){
				link.setEndPort(port);
			}else{
				link.setFallbackEndPoint(lang.clone(connection.point));
			}
		}
	},
	
	_createPort: function(automaticPortType,position){
		var port;
		if(automaticPortType || !position){
			port = new Port.AutomaticPort();
		}else{
			port = new Port.BasicPort();
			port.setPosition(position);
		}
		return port;
	},
	_createUndoReConnectionAction: function(diagram,link,newParent,oldParent,position,savedConnection,newConnection){
		var action = new ReConnectAction(diagram,link,position,savedConnection,newConnection,this._createPort,this._applyConnection);
		return action;
	},
	_createUndoAction: function(diagram,link,newParent,oldParent,action){
		
		if(oldParent!=newParent){
			var reParentAction = new ReparentingAction();
			reParentAction.setOldParentId(diagram.getUndoManager().getParentId(oldParent));
			reParentAction.setNewParentId(diagram.getUndoManager().getParentId(newParent));
			reParentAction.setModifiedElementId(link.getId());
			var mAction = new MultipleAction(UndoActionList.ReConnect);
			mAction.addAction(action);
			mAction.addAction(reParentAction);
			return mAction;
		}else{
			return action;
		}
	}
});

return LinkConnectionHandleInteractor;

});

},
'ibm_ilog/diagram/editor/undo/Action':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/undo/Action", [
"dojo/_base/declare"
], function(
declare
){
	
	var Action =
	declare("ibm_ilog.diagram.editor.undo.Action", [], {
		//
		//	summary:
		//		this is the base Undo action. This contains the base components to apply all undo/redo actions on the UndoManager.
		//		Any Undo Action should inherit from this class
		_undoFunction:null,
		_redoFunction: null,
		_label: null,
		_undoManager: null,
		_isRedoing: null,
		_isUndoing: null,
		
	constructor:function(label){
		//
		//	summary:
		//		creates a new instance, setting up the label	
		//
		this._label = label;
		this._isRedoing = false;
		this._isUndoing = false;
	},
		
	initialize: function(undoFunction,redoFunction){
		//
		//	summary:
		//		initialize the action, by setting the undo and redo functions
		this._undoFunction = undoFunction;
		this._redoFunction = redoFunction;
	},
	
	undo: function(){
		//
		//	summary:
		//		call the undo function
		this._isUndoing = true;
		if(this._undoFunction){
			this._undoFunction();
		}
		this._isUndoing = false;
	},
	
	redo: function(){
		//
		//	summary:
		//		call the redo function
		this._isRedoing = true;
		if(this._redoFunction){
			this._redoFunction();
		}
		this._isRedoing = false;
	},
	
	getLabel: function(){
		//
		//	summary:
		//		return the label. This should be used to be shown in the UI
		return this._label;
	},
	setLabel: function(label){
		//
		//	summary:
		//		sets the label that should be used to be shown in the UI
		this._label = label;
	},
	setUndoManager: function(undoManager){
		//
		//	summary:
		//		Sets the undo Manager
		this._undoManager = undoManager;
	},
	
	getUndoManager: function(){
		//
		//	summary:
		//		Gets the undo Manager. The UndoManager is set in the Action automatically when it is added to the undo stack
		return this._undoManager;
	},
	
	isUndoing: function(){
		//
		//	summary:
		//		return true if the action is executing an undo action
		return this._isUndoing;
	},
	
	isRedoing: function(){
		//
		//	summary:
		//		return true if the action is executing a redo action
		return this._isRedoing;
	}
	});
	
	return Action;
	
});

},
'ibm_ilog/diagram/editor/interactors/AddIntermediatePointInteractor':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/interactors/AddIntermediatePointInteractor", [
"dojo/_base/declare",
"dojo/_base/event",
"../../interactors/Interactor",
"../EditingUtils",
"../../util/Geometry"
], function(
declare,
event,
Interactor,
EditingUtils,
g
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var AddIntermediatePointInteractor =
declare("ibm_ilog.diagram.editor.interactors.AddIntermediatePointInteractor", [Interactor], {
	// summary:
	//		this interactor is created in the LinkIntermediatePointAdorner and have the functionality 
	//		to add intermediate points to the adorned link
	
	
	//	_handle: /*LinkIntermediatePointsHandle*/
	_adorner: null,
	_viewport: null,
	
	_declareStates: function () {
		this._declareState("idle", ["add"]);
		//this._declareState("active", ["end"]);
	},

	getDefaultConnections: function () {
		// summary:
		//		returns the default event mapping
		
		return {
			add: {
				src: this._getInitialEventSource(),
				srcEvt: "onmousedown",
				connectTo: "_addIntermediatePoint",
				filter: this._buildInputFilter({shift:true,button:0}),
				gfxConnect:true
			}
		};
	},
	
	initialize: function( /* LinkIntermediatePointsAdorner */ adorner ) {
		// summary:
		//		sets the LinkIntermediatePointsAdorner and initialize its superclass
		this._adorner = adorner;
		this._viewport = adorner.getViewport();
		this._initialize();
		return this;
	},
	
	_getInitialEventSource: function() {
		return this._adorner._path;
	},
	
	_addIntermediatePoint: function(e) {
		// summary:
		//		Add the intermediate point to the adorned link
		var link = this._adorner.getAdorned();
		var V = this._adorner.getViewport();
		var D = V.getDiagram();
		if(link){
			var intermediatePoints = link.getIntermediatePoints();
			var point = V.eventContentLocation(e);
			var t = link.getShapeToContainerTransform(D.getGraph().getParent()).inverse();
			var pointT = t.transformPoint(point);
			var index = this._getCloserSegmentIndex(link,intermediatePoints,pointT);
			EditingUtils.addItermediatePoint(D,link,pointT,index);
			this._adorner.rebindAdorned();
		}
		event.stop(e);
	},
	_getCloserSegmentIndex: function(link,intermediatePoints,point){
		// summary:
		//		return the index of the closer link segment to the point
    	var distance = Number.MAX_VALUE;
    	var index = -1;
    	var startPoint = link._pathPoints[0];
    	var endPoint = link._pathPoints[link._pathPoints.length - 1];
    	intermediatePoints = [startPoint].concat(intermediatePoints).concat([endPoint]);
    	for(var i=1;i<intermediatePoints.length;i++){
    		var a = intermediatePoints[i-1];
    		var b = intermediatePoints[i];
    		var d = g.getPointToSegmentDistance(a,b,point);
    		if(distance>d){
    			distance = d;
    			index = i-1;
    		}
    	}
    	return index;
    }
});

return AddIntermediatePointInteractor;

});

},
'ibm_ilog/diagram/editor/Clipboard':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/Clipboard", [
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"dojo/_base/connect",
"dojox/gfx/matrix",
"dojox/collections/Dictionary",
"../util/GraphUtil",
"../util/Geometry",
"./undo/MultipleAction",
"./undo/UndoActionList",
"./DiagramSerializer",
"./EditingUtils"
], function(
declare,
lang,
array,
connect,
m,
Dictionary,
gu,
g,
MultipleAction,
UndoActionList,
DiagramSerializer,
eu
){

var Clipboard =
declare("ibm_ilog.diagram.editor.Clipboard", null , {
	
	_diagram: null,
	_serializer: null, 
	_pasteContainer : null,
	_clipboard: null, 
	_pasteXY: null, 
	_pasteBB: null, 

	_nextPasteLocations: null,
	
	//
	//	_nextPasteLocationDelta: Point
	//		The delta used to compute _nextPasteLocation.
	//
	_nextPasteLocationDelta: g.Point(25,25),

	setNextPasteLocationDelta: function(value) {
		//
		//	summary:
		//		Set the delta used to compute _nextPasteLocation.
		//
		this._nextPasteLocationDelta = value;
	},	
	
	getNextPasteLocationDelta: function(value) {
		//
		//	summary:
		//		Get the delta used to compute _nextPasteLocation.
		//
		return this._nextPasteLocationDelta;
	},

	constructor: function(diagram){
		// summary:
		//		creates a new clipboard instance, initializing a new serializer.
		
		this._nextPasteLocations = new Dictionary();
		
		this._diagram = diagram;
		this._initializeSerializer();
	},
	
	getDiagram: function(){
		// summary:
		//		returns the associated diagram.
		// return: ibm_ilog.diagram.editor.DiagramEditor
		return this._diagram;
	},
	
	_basicCopy: function() {
		// summary:
	    //		This method serializes the selected elements to the clipboard, and save it for further paste.
		var maximals = gu.maximals(this._diagram.getSelection().fastGet().toArray())
		if(!this._isEmpty(maximals)){
			var bb = this._getBoundsOf(maximals);
			var lca = gu.lowestCommonAncestor(maximals);
			
			this._nextPasteLocations.clear();
			
			var bbxy = {x:bb.x,y:bb.y};
			var localxy = lca._getRealMatrix().inverse().transformPoint(bbxy);
			this._nextPasteLocations.add(lca.getId(),localxy);

			this._clipboard = this._serializer.serialize(maximals);
			connect.publish("/ibm_diagram/Clipboard/copied", [maximals]);
			return maximals;
		}
		return null;
	},
	
	copy: function() {
		// summary:
    //		This method serializes the selected elements to the clipboard, and save it for further paste.
		if(this._basicCopy()) {
			var entry = this._nextPasteLocations.getIterator().get();
			entry.value = g.addPoint(entry.value,this._nextPasteLocationDelta);
			
		}		
	},
	
	cut: function(){
		// summary:
	    //		This method serializes the selected elements to the clipboard, and save it for further paste.
		//		Also deletes the selected elements after the copy.
		if(this._basicCopy()) {
			var selected = this._diagram.getSelection().fastGet().toArray();
			var action = eu.deleteGraphElements(this._diagram,selected);
			this._diagram.getUndoManager().addAction(action);
		}
	},
	
	clear: function(){
		// summary:
	  //		This method clears the clipboard and signals the event "/ibm_diagram/Clipboard/cleared".
		//
		this._clipboard = null; 
		connect.publish("/ibm_diagram/Clipboard/cleared",[]);
	},
	
	paste: function(pasteContainer,pasteLocation) {
		//
		//	summary:
	  //		Pastes previously copied content into the diagram.
		//	pasteContainer: ibm_ilog.diagram.Graph
		//		The Graph into which the contents of the clipboard are going to be pasted.
		//
		if(this._clipboard){
			this._pasteContainer = pasteContainer;
			if(!pasteLocation) {
				var storedLoc = this._nextPasteLocations.item(pasteContainer.getId());
				if(storedLoc) {
					pasteLocation = storedLoc;
				} else {
					pasteLocation = storedLoc = {x:0,y:0};
				}
				storedLoc = g.addPoint(storedLoc,this._nextPasteLocationDelta);
				this._nextPasteLocations.add(pasteContainer.getId(),storedLoc);
			}

			this._pasteXY = pasteLocation;
			this._pasteBB = this._calculateBB(this._clipboard); 
			var undoGroup = new MultipleAction(UndoActionList.Paste);
		
			// add a connection to select all deserialized elements.
			var elements = [];
			var connection = connect.connect(this,'onDeserialize',
										  this,function(serialized,newElement){
			                						elements.push(newElement);
												});
		
			this._serializer.deserialize(this._clipboard,{graph:this._pasteContainer,undo:undoGroup});
			this._diagram.getUndoManager().addAction(undoGroup);
		
			//disconnect
			connect.disconnect(connection);
		
			//selects the deserialized top elements
			var maximals = gu.maximals(elements);
			this._diagram.getSelection().add(maximals,true);
			connect.publish("/ibm_diagram/Clipboard/pasted", [maximals]);
			//this._advancePasteLocation();
		}
	},
	
	getSerializer: function(){
		// summary:
		//		returns the pre-configured serializer, ready for the copy-paste action.
		// return: ibm_ilog.diagram.editor.DiagramSerializers
		return this._serializer;
	},
	
	_calculateBB: function(serialized) {
		var bb = null;
		array.forEach(serialized,function(e) {
			if(e.data.uibb) {
				if(bb) {
					bb = g.addRect(bb,e.data.uibb);
				} else {
					bb = e.data.uibb;
				}
			}
		});
		return bb;
	},
	
	_initializeSerializer: function(){
		var t = lang.hitch(this,this._adjustTransform);
		this._serializer = new DiagramSerializer(this._diagram,t,this);
	},
	
	_adjustTransform: function(t,c,s) {
		// if this is toplevel, reassign t offsets such that pasteXY is the new translation
		if(c==this._pasteContainer) {
			if(!s){
				// compute transform for link intermediate points
				return m.multiply(m.translate(g.subPoint(this._pasteXY, this._pasteBB)), t);
			}
			t.dx=0;	t.dy=0;
			var newp = this._pasteXY;
			newp = g.addPoint(g.subPoint(s.uibb,this._pasteBB),newp);
			return m.multiply(m.translate(newp),t);
		} else return t;
	},
	
	_isEmpty:function(array) {
		// summary:
		//		verifies if an array is empty
		for(var i in array) {
			return false; 
		}
		return true; 
	},
	
	onSerialize: function(graphElement,serializedData){
		// summary:
		//		this function is called when a graphElement is serialized in the local Serializer.
		//		The user can connect to this method to customize the serialization.
		// graphElement: ibm_ilog.diagram.GraphElement
		//		the GraphElement to be serialized
		// serializedData: JSObject
		//		the serialized version of the GraphElement
	},
	
	onDeserialize: function(serializedData,newGraphElement,container,undoAction){
		// summary:
		//		this function is called when a graphElement is deserialized in the local Serializer.
		//		The user can connect to this method to customize the deserialization.
		// serializedData: JSObject
		//		the serialized version of the GraphElement
		// newGraphElement: ibm_ilog.diagram.GraphElement
		//		the deserialized GraphElement
		// container: ibm_ilog.diagram.Graph
		//		the container object where the newGraphElement is hold
		// undoAction: ibm_ilog.diagram.editor.undo.UserCustomizedAction
		//		the undo Action to be added to the UndoManager. If the serialized object is a link, 
		//		this Action will be an instance of ibm_ilog.diagram.editor.undo.ConnectAction.
		//		In other case it will be a ibm_ilog.diagram.editor.undo.PasteNodeAction
	},
	
	_getBoundsOf: function (list) {
		//
		//	summary:
		//		return the bounds of a list of elements currently selected
		//	list: Array
		//		The list of graph elements to include
		//	tags:
		//		private
		var bb = null;
		var graph = this._diagram.getGraph();
		for(var i = 0; i<list.length; i++) {
			var b = list[i].getBounds(graph);
			if(!bb) {
				bb = b;
			} else {
				bb = g.addRect(bb,b);
			}
		}
		return bb;
	}
	
});

return Clipboard;

});

},
'ibm_ilog/diagram/editor/interactors/AddIntermediatePointHandlerInteractor':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/interactors/AddIntermediatePointHandlerInteractor", [
"dojo/_base/declare",
"dojo/_base/event",
"../../interactors/Interactor",
"../EditingUtils"
], function(
declare,
event,
Interactor,
EditingUtils
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var AddIntermediatePointHandlerInteractor =
declare("ibm_ilog.diagram.editor.interactors.AddIntermediatePointHandlerInteractor", [Interactor], {
	// summary:
	//		this interactor is created in the LinkIntermediatePointAdorner and have the functionality 
	//		to add intermediate points to the adorned link
	
	
	//	_handle: /*LinkIntermediatePointsHandle*/
	_handle: null,
	_viewport: null,
	
	_declareStates: function () {
		this._declareState("idle", ["add"]);
		//this._declareState("active", ["end"]);
	},

	getDefaultConnections: function () {
		// summary:
		//		returns the default event mapping
		
		return {
			add: {
				src: this._getInitialEventSource(),
				srcEvt: "onmousedown",
				connectTo: "_addIntermediatePoint",
				filter: this._buildInputFilter({shift:false,button:0}),
				gfxConnect:true
			}
		};
	},
	
	initialize: function( /* LinkIntermediatePointsHandle */ handle ) {
    	// Summary:
		//		sets the LinkIntermediatePointsHandle
    	this._handle = handle;
		this._viewport = handle.getViewport();
		this._initialize();
		return this;
	},
	
	_getInitialEventSource: function() {
		return this._handle;
	},
	
	_addIntermediatePoint: function(e) {
		// summary:
		//		Add the intermediate point to the adorned link
		var A = this._handle.getAdorner();
		var D = A.getDiagram();
		var link = A.getAdorned();
		var index = this._handle.getIndex();
		var point = this._getPoint(link,index);
		EditingUtils.addItermediatePoint(D,link,point,index);
		A.rebindAdorned();
		event.stop(e);
	},
	
	_getPoint: function(link,index){
		var iPoints = link._pathPoints;
		var p1 = iPoints[index];
		var p2 = iPoints[index+1];
		var point = {x:((p2.x-p1.x)/2+p1.x), y:((p2.y-p1.y)/2+p1.y)};
		return point;
	}
});

return AddIntermediatePointHandlerInteractor;

});

},
'ibm_ilog/diagram/editor/interactors/ResizeHandleInteractor':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/interactors/ResizeHandleInteractor", [
"dojo/_base/declare",
"../../interactors/DragInteractor"
], function(
declare,
DragInteractor
){

/*=====
var DragInteractor = ibm_ilog.diagram.interactors.DragInteractor;
=====*/

var ResizeHandleInteractor =
declare("ibm_ilog.diagram.editor.interactors.ResizeHandleInteractor", [DragInteractor], {
	//
	//	summary:
	//		Handles the interaction of a resize handle while resizing the related adorned.
	//	
	
	//
	//	_handle: /*ibm_ilog.diagram.editor.adorners.ResizeHandle*/
	//		The ResizeHandle associated with the interactor.
	//
	_handle: null,

	initialize: function ( /* ibm_ilog.diagram.editor.adorners.ResizeHandle */ handle ) {
		//
		//	summary:
		//		Initializes the interactor to work with the given handle
		//
		this._handle = handle;
		this._viewport = handle.getViewport();
		this._initialize();
		return this;
	},

	_getInitialEventSource: function () {
		return this._handle;
	},

	_refreshTransform: function () {
		var a = this._handle._adorner;
		if(a._adorned) {
			this._transform = a._adorned.getTransformToContainer(a._viewport.getSurface()).inverse();
		}
	},

	activate: function () {
		this.inherited(arguments);
	},

	_dragPreStart: function () {
		this._refreshTransform();
		this._connect("updateTransforms", this._handle._adorner._viewport, "onViewRectChanged", this, "_refreshTransform");
		this._handle.interactionBegun(this);
		this.inherited(arguments);
	},

	_dragEnd: function () {
		this._disconnect("updateTransforms");
		var dragged = this.hasDragged, action, D;
		this.inherited(arguments);
		this._handle.interactionEnded(this);
		if(dragged){
			action = this._handle.createUndoAction();
			D = this._viewport.getDiagram();
			D.getUndoManager().addAction(action);
		}
	},

	_dragMove: function () {
		this.inherited(arguments);
		this._handle.resize(this._totalDelta);
	}

});

return ResizeHandleInteractor;

});

},
'ibm_ilog/diagram/editor/undo/MultipleAction':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/undo/MultipleAction", [
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"./Action",
"./UndoActionList"
], function(
declare,
lang,
array,
Action,
UndoActionList
){
	
/*=====
var Action = ibm_ilog.diagram.editor.undo.Action;
=====*/

	var MultipleAction =
	declare("ibm_ilog.diagram.editor.undo.MultipleAction", [Action], {
		//
		//	summary:
		//		this action groups a list of actions. It simple groups a set of actions in a single complex action.
		//
		_actionList:null,
		_reverseUndo: null,
		_reverseRedo: null,
	constructor:function(label){
		//
		//	summary:
		//		creates a  new instance, setting up the label
		//
		this._label = label;
		this.initialize(lang.hitch(this,this._undoFunction),lang.hitch(this,this._redoFunction));
		this._actionList = [];
		this._reverseUndo = true;
		this._reverseRedo = false;
	},
	addAction: function(action){
		//
		//	summary:
		//		adds an action to the list
		this._actionList.push(action);
	},
	_undoFunction: function(){
		var size = this._actionList.length;
		for(var index = 0;index<size;index++){
			var action = this._reverseUndo?this._actionList[size-index-1]:this._actionList[index];
			action.undo();
		}
	},
	_redoFunction: function(){
		var size = this._actionList.length;
		for(var index = 0;index<size;index++){
			var action = this._reverseRedo?this._actionList[size-index-1]:this._actionList[index];
			action.redo();
		}
	},
	setUndoManager: function(undoManager){
		//
		//	summary:
		//		sets the undo Manager to each individual action added to the list
		this._undoManager = undoManager;
		array.forEach(
				this._actionList,
			    function(item){
			        item.setUndoManager(undoManager);
			    }
			);
	},
	setReverseUndo:function(reverse){
		// summary:
		//		sets to apply the undo actions in reverse order
			this._reverseUndo = reverse;
	},
	getReverseUndo: function(){
		// summary:
		//		gets to apply the undo actions in reverse order
		return this._reverseUndo;
	},
	setReverseRedo:function(reverse){
		// summary:
		//		sets to apply the redo actions in reverse order
		this._reverseRedo = reverse;
	},
	getReverseRedo: function(){
		// summary:
		//		gets to apply the redo actions in reverse order
		return this._reverseRedo;
	}
	});
	
	return MultipleAction;
	
});

},
'ibm_ilog/diagram/editor/undo/ReConnectAction':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/undo/ReConnectAction", [
"dojo/_base/declare",
"dojo/_base/lang",
"./UserCustomizedAction",
"./UndoActionList"
], function(
declare,
lang,
UserCustomizedAction,
UndoActionList
){
	
/*=====
var UserCustomizedAction = ibm_ilog.diagram.editor.undo.UserCustomizedAction;
=====*/

	var ReConnectAction =
	declare("ibm_ilog.diagram.editor.undo.ReConnectAction", [UserCustomizedAction], {
		//	
		// summary:
		//		this action undo/redo any ReConnect action.
		//		This action must be modified for the user if any user defined action is done on a ReConnect action.
		//
		_linkId: null,
		_applyConnectionFunction: null,
		_createPortFunction: null,
		_oldConnection: null,
		_newConnection: null,
		_portPosition: null,
	
	constructor:function(diagram,link,position,savedConnection,newConnection,createPort,applyConnection){
		
		this._label = UndoActionList.ReConnect;
		this._linkId = link.getId();
		this._portPosition = position;
		this._createPortFunction = lang.hitch(this,createPort);
		this._applyConnectionFunction = lang.hitch(this,applyConnection);
		
		savedConnection.nodeId = savedConnection.node?savedConnection.node.getId():null;
		savedConnection.node = null;
		this._oldConnection = savedConnection;
		
		newConnection.nodeId = newConnection.node?newConnection.node.getId():null;
		newConnection.node = null;
		this._newConnection = newConnection;
	},
	_clearPort: function(){
		var port;
		var link = this.getUndoManager().getRegisteredGraphElement(this._linkId);
		if(this._portPosition == 0){
			port = link.getStartPort();
			link.setStartPort(null);
		}else{
			port = link.getEndPort();
			link.setEndPort(null);
		}
		//remove Port
		if(port && port._isIBMDiagramBasicPort){
			port.getOwner().removePort(port);
		}
	},
	getLink: function(){
		// Summary:
		//		return the link modified (verifying replaces)
		return this.getUndoManager().getRegisteredGraphElement(this._linkId);
	},
	isStartModified: function(){
		// Summary:
		//		return true if the start of the link is the modified component.
		return this._portPosition == 0;
	},
	undoFunction: function(){
		var link = this.getLink();
		var node = this.getUndoManager().getRegisteredGraphElement(this._oldConnection.nodeId);
		this._oldConnection.nodeId = node.getId();
		this._clearPort.call(this);
		this._oldConnection.node = node;
		this._applyConnectionFunction.call(null,link,this._portPosition,this._oldConnection,this._createPortFunction);
		this._oldConnection.node = null;
		var D = this.getUndoManager().getDiagram();
		D.onLinkUpdated(D,link,false,this);
	},
	
	redoFunction: function(){
		var link = this.getLink();
		var node = this.getUndoManager().getRegisteredGraphElement(this._newConnection.nodeId);
		this._newConnection.nodeId = node?node.getId():null;
		this._clearPort.call(this);
		this._newConnection.node = node;
		this._applyConnectionFunction.call(null,link,this._portPosition,this._newConnection,this._createPortFunction);
		this._newConnection.node = null;
		var D = this.getUndoManager().getDiagram();
		D.onLinkUpdated(D,link,false,this);
	}
	});
	
	return ReConnectAction;
	
});

},
'ibm_ilog/diagram/editor/undo/DeleteAction':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/undo/DeleteAction", [
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"dojo/_base/config",
"./Action",
"./UndoActionList",
"./MultipleAction",
"./ConnectAction",
"../DiagramSerializer",
"../../gfxlayout"
], function(
declare,
lang,
array,
config,
Action,
UndoActionList,
MultipleAction,
ConnectAction,
DiagramSerializer,
gfxlayout
){

/*=====
var Action = ibm_ilog.diagram.editor.undo.Action;
=====*/

var DeleteAction =
declare("ibm_ilog.diagram.editor.undo.DeleteAction", [Action], {
	_serialized: null,
	_deletedNodes: null,
	_diagram: null,
	_deletedLinksAction: null,
	
	constructor:function(diagram){
		this.setLabel(UndoActionList.Delete);
		this._diagram = diagram;
		this._deletedLinksAction = new MultipleAction(UndoActionList.Delete);
		this.initialize(lang.hitch(this,this._undoFunction),lang.hitch(this,this._redoFunction));
	},
	setDeleted: function(targetSet){
		this._deletedNodes = {};
		var ts = [];
		for(var index in targetSet){
			var ge = targetSet[index];
			var parent = ge.getParent();
			if(ge._isIBMDiagramNode){
				this._deletedNodes[ge.getId()] = this._diagram.getUndoManager().getParentId(parent);
				ts.push(ge);
			}else{
				this._deletedLinksAction.addAction(new DeleteLinkAction(this._diagram,ge,parent));
			}
		}
		this._serialized = this._diagram._getRemoveSerializer().serialize(ts);
		this._deletedLinksAction.setUndoManager(this._diagram.getUndoManager());
	},
	_undoFunction: function(){
		var undoGroup = new MultipleAction("Dummy");
		array.forEach(this._serialized,function(item){
			var parent =  this.getUndoManager().getRegisteredParent(this._deletedNodes[item.id]); 
			var d = this._diagram._getRemoveSerializer().deserialize([item],{graph:parent,undo:undoGroup});
			// layout undo'ed elements immediately... (fixes wrong subgraph bounds after undo delete node)
			if(config.useGfxLayout){
				array.forEach(d, function(e){
					var c = e.created;
					if(c && c._isIBMDiagramGraphElement && c.getLayout && c.getLayout())
						gfxlayout.Engine._layout(c);
				});
			}
		},this);
		this._deletedLinksAction.undo();
	},
	_redoFunction: function(){
		this._deletedLinksAction.redo();
		for(var elementId in this._deletedNodes){
			var ge = this.getUndoManager().getRegisteredGraphElement(elementId);
			ge.getParent().remove(ge);
			ge.dispose();
		}
	},
	_initializeSerializer: function(){
		this._serializer = new DiagramSerializer(this._diagram,null,this);
	},
	onSerialize: function(graphElement,serializedData){
		
	},
	onDeserialize: function(serializedData,newGraphElement,container,undoAction){
		var um = this._diagram.getUndoManager();
		um.registerGraphElementReplacement(serializedData.id,newGraphElement.getId());
	}
});

/*=====
var ConnectAction = ibm_ilog.diagram.editor.undo.ConnectAction;
=====*/

var DeleteLinkAction =
declare("ibm_ilog.diagram.editor.undo.DeleteLinkAction", [ConnectAction], {
	undoFunction: function(){
		ConnectAction.prototype.redoFunction.apply(this, arguments);
	},
	redoFunction: function(){
		ConnectAction.prototype.undoFunction.apply(this, arguments);
	}
});

return DeleteAction;

});

},
'ibm_ilog/diagram/editor/adorners/LinkIntermediatePointsAdorner':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/adorners/LinkIntermediatePointsAdorner", [
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"../../base",
"../../Link",
"../../adorners/LinkAdorner",
"../adorners/LinkIntermediatePointsHandle",
"../adorners/LinkIntermediatePointsAddHandle",
"../interactors/AddIntermediatePointInteractor",
"../../util/Geometry"
], function(
declare,
lang,
array,
iid,
Link,
LinkAdorner,
LinkIntermediatePointsHandle,
LinkIntermediatePointsAddHandle,
AddIntermediatePointInteractor,
g
){

/*=====
var LinkAdorner = ibm_ilog.diagram.adorners.LinkAdorner;
=====*/

	var LinkIntermediatePointsAdorner =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.LinkIntermediatePointsAdorner',[LinkAdorner],{
		// Summary:
		//		this class is the adorner that contains the LinkIntermediatePointsHandler. 
		//		These handles enables the user to delete and edit link intermediate points.
		//		Also, it creates an instance of the AddIntermediatePointInteractor that enables 
		//		to create new intermediate point at the adorned link
		_intermediatePoints: null,
		_addPointInteractor: null,
		_useHandleInteractorToAdd: null,
		initialize: function(){
		// Summary:
		//		initialize the Adorner and create the instance of the AddIntermediatePointInteractor.
			this.inherited(arguments);
			this.enableHandleInteractorToAdd(true);
			this._addPointInteractor = new AddIntermediatePointInteractor();
		},
		enableHandleInteractorToAdd: function(enabled){
			// Summary:
			//		This method set the use of individual Interactors to add intermediate points (click over handles), or use the general Interactor (Shift+click over link).
			this._useHandleInteractorToAdd = enabled;
		},
		setAdorned: function (element) {
			//	summary:
			//		apply the adorner to the given element. This method creates all the necessary LinkIntermediatePointsHandler and deletes any previously created instances.
			//
			
			if(element){
				var shapeType = element.getShapeType();
				if (shapeType != Link.LinkShapeType.Free &&
				        this._shapeType != Link.LinkShapeType.OrthogonalEditable){
					return; // do not set the adorner
				}
				
				this._intermediatePoints = [];
				this.createAllHandles(element);
				if(!this._useHandleInteractorToAdd){
					this._addPointInteractor.initialize(this);
					this._addPointInteractor.reactivate();
				}
			}else{
				this._clearHandles();
				if(!this._useHandleInteractorToAdd){
					this._addPointInteractor.deactivate();
				}
			}
			this.inherited(arguments);
			this._path.moveToBack();
			this.moveToFront();
		},
		rebindAdorned: function(){
			//	summary: 
			//		rebind the adornet to the same adorned link.
			//		This method should be called when the number of intermediate links varies.

			var link = this.getAdorned();
			this.setAdorned(null);
			this.setAdorned(link);
		},
    	createAllHandles: function(element){
			//	summary: 
			//		This method creates all the necessary LinkIntermediatePointsHandler
			var size = element.getIntermediatePoints().length;
			if(this._useHandleInteractorToAdd){
				this._createDynamicHandle(LinkIntermediatePointsAddHandle,"addPointGroup").setUp(0);
			}
			for(var index = 0;index<size;index++){
    			this._createDynamicHandle(LinkIntermediatePointsHandle,"currentPointGroup").setUp(index);
    			if(this._useHandleInteractorToAdd){
    				this._createDynamicHandle(LinkIntermediatePointsAddHandle,"addPointGroup").setUp(index+1);
    			}
    		}
    	},
    	_createDynamicHandle: function (clazz,attachPointName) {
			if (this[attachPointName]) {
				var template = this._templatePool.item(this[attachPointName].template || clazz.templateId);
				var handle = this[attachPointName].createObject(clazz);
				handle.initialize(this, template);
				this._handles.add(handle);
				return handle;
			} else {
				return null;
			}
		},
		_clearHandles: function(){
			//	summary: 
			//		This method deletes any previously created LinkIntermediatePointsHandler instances.
			this._handles.forEach(function(handle){
				handle.getParent().remove(handle);
			});
			this._handles.clear();
		},
    	_updateLayout: function () {

    		// [AV] updates from "updateShapeBoundProperty" dont work with composite properties
    		// e.g. bounds.width   
    		//      bounds.height
    		//
    		// Correcting this may also be faster, only one rebinding process is needed
    		
    		this.inherited(arguments);
    		if (this.getAdorned()) {
        		var transformationFunction = lang.hitch(this, function (point, list) {
					var v = this._viewport,
						z = v.getZoom(),
						vr = v.getViewRect();
					var t = this._adorned.getShapeToContainerTransform(v._diagram.getGraph().getParent());
					point = t.transformPoint(point);
					point = g.moveRect(point, g.negPoint(vr));
					point.x = point.x * z;
					point.y = point.y * z;
					return point;
				});
				var points = array.map(this.getAdorned().getIntermediatePoints(),transformationFunction);
				this._intermediatePoints = points;
				this._notifyHandles();
    		}
    	},
    	_notifyHandles: function(){
    		// summary:
    		//		notify all the handles of the point modification
    		this._handles.forEach(function(handle){
    			if(handle._isAddHandle){
    				handle.changeBindings([{x:this.getLinkStartX(),y:this.getLinkStartY()}].concat(this._intermediatePoints).concat({x:this.getLinkEndX(),y:this.getLinkEndY()}));
    			}else{
    				handle.changeBindings(this._intermediatePoints);
    			}
    		},this);
    	}

    }));

	return LinkIntermediatePointsAdorner;
	
});

},
'ibm_ilog/diagram/editor/adorners/ConnectionAdorner':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/adorners/ConnectionAdorner", [
"dojo/_base/declare",
"../../base",
"./ConnectionHandle",
"../../adorners/AdornerWithHandles",
"../../util/Geometry"
], function(
declare,
iid,
ConnectionHandle,
AdornerWithHandles,
g
){
    
/*=====
var AdornerWithHandles = ibm_ilog.diagram.adorners.AdornerWithHandles;
=====*/

	var Point = g.Point;
	
	var ConnectionAdorner =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.ConnectionAdorner',[AdornerWithHandles],{

    	initialize: function() {
    		this.inherited(arguments);

    		this._createConnectionHandle("hndT",Point(0.5,0));
    		this._createConnectionHandle("hndR",Point(1,0.5));
    		this._createConnectionHandle("hndB",Point(0.5,1));
    		this._createConnectionHandle("hndL",Point(0,0.5));
    	},
        
    	_createConnectionHandle: function(attachPoint,p) {
    		var h = this._createHandle(ConnectionHandle,attachPoint);
    		if(h) {
    			h.setup(p);
    		}
    	}

    }));

	return ConnectionAdorner;

});


},
'ibm_ilog/diagram/editor/adorners/ResizeHandle':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/adorners/ResizeHandle", [
"dojo/_base/declare",
"../../base",
"../../adorners/HighlightedHandle",
"../interactors/ResizeHandleInteractor",
"../undo/UndoManager",
"../undo/SimpleAction",
"../undo/UndoActionList",
"../../util/Geometry"
], function(
declare,
iid,
HighlightedHandle,
ResizeHandleInteractor,
UndoManager,
SimpleAction,
UndoActionList,
g
){

/*=====
var HighlightedHandle = ibm_ilog.diagram.adorners.HighlightedHandle;
=====*/

	var ResizeHandle =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.ResizeHandle',[HighlightedHandle],{
	//
	//	summary:
	//		A handle that is associated with a corner of the adorner 
	//		bouding box and allows to resize the adorned by grabbing that 
	//		corner.
	//
	
	//
	//	_location: Point
	//		The corner of the adorned BB associated with the handle. Each 
	//		coord may have a value of 0 or 1 indicating the left or right 
	//		and top or down respectively. 
	//
	location: null,

	//
	//	_startBB:
	//		The original BB of the adorned
	//
	_startBB: null,
	_endBB: null,
	
	setup: function(location) {
		this.location = location;
		this.addInteractor(new ResizeHandleInteractor().initialize(this));
		return this;
	},

	interactionBegun: function() {
		this.inherited(arguments);
		this._startBB = this._adorner._adorned.getBounds();
		this._endBB = this._startBB;
	},

	resize: function(delta) {

		var ge = this._adorner._adorned;
		var bb = g.cloneRect(this._startBB);
		var min = ge.minimumSize;
		
		switch(this.location.x) {
		case 0:
			delta.x = bb.width-Math.max(bb.width-delta.x,min.width);
			bb.x = bb.x + delta.x;
			bb.width = bb.width - delta.x;
			break;
		case 1:
			bb.width = Math.max(min.width,bb.width + delta.x);
			break;
		}			
		
		switch(this.location.y) {
		case 0:
			delta.y = bb.height-Math.max(bb.height-delta.y,min.height);
			bb.y = bb.y + delta.y;
			bb.height = bb.height - delta.y;
			break;
		case 1:
			bb.height = Math.max(min.height,bb.height + delta.y);
			break;
		}			
		
		ge.setBounds(bb);
		this._endBB = bb;
	},
	
	createUndoAction: function(){
		
		var action = new SimpleAction(UndoActionList.Resize);
		
		action.setOldValue(this._startBB);
		action.setNewValue(this._endBB);
		action.setMethodOrProperty('setBounds');
		action.setModifiedElementId(this._adorner._adorned.getId());
		return action;
	}

}));

ResizeHandle.templateId = "ResizeHandle";

return ResizeHandle;

});

},
'ibm_ilog/diagram/editor/undo/ConnectAction':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/undo/ConnectAction", [
"dojo/_base/declare",
"dojo/_base/lang",
"./UserCustomizedAction",
"./UndoActionList",
"../../Port"
], function(
declare,
lang,
UserCustomizedAction,
UndoActionList,
Port
){
	
/*=====
var UserCustomizedAction = ibm_ilog.diagram.editor.undo.UserCustomizedAction;
=====*/

	var ConnectAction =
	declare("ibm_ilog.diagram.editor.undo.ConnectAction", [UserCustomizedAction], {
		//	
		// summary:
		//		this action undo/redo any Connect action.
		//		This action must be modified for the user if any user defined action is done on a connect action.
		//
		_linkId: null,
		_parentId: null,
		_createPointFunction: null,
		_linkShapeType: null,
	constructor:function(diagram,link,parent){
		//	
		// summary:
		//		creates a new instance, setting the corresponding label
		this._label = UndoActionList.Connect;
		this._linkId = link.getId();
		this._parentId = diagram.getUndoManager().getParentId(parent);
		this._linkShapeType = link.getShapeType();
		var start = link.getStartPort();
		this._start = {
			auto: !start._isIBMDiagramBasicPort,
			position: start._isIBMDiagramBasicPort?start.getPosition():null,
			nodeId: start.getOwner().getId()	
		};
		
		var end = link.getEndPort();
		if(end){
			this._end = {
				auto: !end._isIBMDiagramBasicPort,
				position: end._isIBMDiagramBasicPort?end.getPosition():null,
				nodeId: end.getOwner().getId()	
			};
		}else{
			this._end = {
					point: lang.clone(link.getFallbackEndPoint())
				};
		}
	},
	_clearPorts: function(){
		var port;
		var link = this.getUndoManager().getRegisteredGraphElement(this._linkId);
		port = link.getStartPort();
		link.setStartPort(null);
		//remove Port
		if(port && port._isIBMDiagramBasicPort){
			port.getOwner().removePort(port);
		}
		port = link.getEndPort();
		link.setEndPort(null);
		//remove Port
		if(port && port._isIBMDiagramBasicPort){
			port.getOwner().removePort(port);
		}
	},
	_createPort: function(automaticPortType,position){
		var port;
		if(automaticPortType || !position){
			port = new Port.AutomaticPort();
		}else{
			port = new Port.BasicPort();
			port.setPosition(position);
		}
		return port;
	},
	getLink: function(){
		//	
		// summary:
		//		returns the link, looking for replaces if necessary
		return this.getUndoManager().getRegisteredGraphElement(this._linkId);
	},
	undoFunction: function(){
		var parent = this.getUndoManager().getRegisteredParent(this._parentId);
		var link = this.getLink();
		parent.remove(link);
		this._clearPorts();
		link.dispose();
	},
	redoFunction: function(){
		var parent = this.getUndoManager().getRegisteredParent(this._parentId);
		var link = parent.createLink();
		this.getUndoManager().registerGraphElementReplacement(this._linkId,link.getId());
		link.setShapeType(this._linkShapeType);
		
		var startNode = this.getUndoManager().getRegisteredGraphElement(this._start.nodeId);
		var endNode = this.getUndoManager().getRegisteredGraphElement(this._end.nodeId);
		
		var startP = this._createPort(this._start.auto,this._start.position);
		startNode.addPort(startP);
		link.setStartPort(startP);
		
		if(endNode){
			var endP = this._createPort(this._end.auto,this._end.position);
			endNode.addPort(endP);
			link.setEndPort(endP);
		}else{
			link.setFallbackEndPoint(lang.clone(this._end.point));
		}
		var D = this.getUndoManager().getDiagram();
		D._onLinkCreated(link,startNode,endNode,D);
		D.onLinkUpdated(D,link,true,this);
		this._linkId = link.getId();
	}
	});
	
	return ConnectAction;
	
});

},
'ibm_ilog/diagram/editor/interactors/InlineEditorKeyInteractor':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/interactors/InlineEditorKeyInteractor", [
"dojo/_base/declare",
"dojo/_base/array",
"dojo/_base/lang",
"dojo/keys",
"../../interactors/Interactor",
"../../util/GraphUtil"
], function(
declare,
array,
lang,
keys,
Interactor,
gu
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var InlineEditorKeyInteractor =
declare("ibm_ilog.diagram.editor.interactors.InlineEditorKeyInteractor", [Interactor], {
	//summary:
	//		This interactor edit the first editable label through the keyboard interaction.
	//		This interactor has 1 connection: editInlineText.
	
	_diagram: null,
	initialize: function (diagram) {
	// summary:
    //		initialize the new instance.
    // diagram: ibm_ilog.diagram.widget.Diagram
    //		the associated diagram.			
		this._diagram = diagram;
		return this._initialize();
	},
	editInlineText: function(e){
		// summary:
		//		opens the inline editor of the first editable label of the focused graph element
		var ge = this._diagram.getFocusedElement();
		if(ge && !ge._isIBMDiagramLink){	
			var es = this._diagram.getEditables(ge);
			if(es && es.length) {
				// open the first visible editable
				array.some(es, lang.hitch(this, function(ed){
					if (gu.getSurface(ed.base)) {
						this._diagram.openEditableInlineEditor(ed);
						return true;
					}
				}));
			}
		}
	},
	getKeyInteractorId: function(){
		// summary:
	    //		returns the Interactor Id
		
		return InlineEditorKeyInteractor.KeyInteractorId;
	},
	getDefaultConnections: function () {
		// summary:
		//		returns the default event mapping
		
		return {
			editInlineText: {
				hotKey: keys.F2,
				connectTo: "editInlineText"
			}
		};
	},
	
	__eod: undefined
});

InlineEditorKeyInteractor.KeyInteractorId = "InlineEditor";

return InlineEditorKeyInteractor;

});

},
'ibm_ilog/diagram/editor/interactors/DropInteractor':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/interactors/DropInteractor", [
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/connect",
"dojo/dnd/Target",
"dojo/dnd/Manager",
"../EditingUtils"
], function(
declare,
lang,
connect,
Target,
Manager,
eu
){

var DropInteractor =
declare("ibm_ilog.diagram.editor.interactors.DropInteractor",[], {
	//
	//	summary:
	//		this interactor manage the drop actions on the DiagramEditor. For Simplicity,
	//		this interactor relies on dojo.dnd.manager() to manage all this behavior with a
	//		standard dojo method.
	//
	_diagram: null,
	_droppedItem: null,
	_connectorHandle: null,
	_dropable: null,
	_acceptedTypes:{},
	_onDropFunction: null,
	_onDropTemplateFunction: null,
	
	constructor: function(diagram,onDropFunction,onDropTemplateFunction){
		// Summary:
		//		Creates a new instance of dojo.dnd.Target associated to the diagram DOM node.
		//		Also sets the diagram, the onDropFunction and the onDropTemplateFunction
		this._diagram = diagram;
		this._dropable = new Target(this._diagram.domNode, {accept: []});
		this._dropable.onDrop = lang.hitch(this,this._onDropNode);
		this.setOnDropFunction(onDropFunction);
		this.setOnDropTemplateFunction(onDropTemplateFunction);
	},
	activate: function(){
		// Summary:
		//		connects this class to the dojo.dnd.manager() onMouseUp function, to catch the event point.
		//		Sets the accepted types
		this._connectorHandle = connect.connect( Manager.manager(),"onMouseUp",this,"_onMouseUpManager");
		this._dropable.accept = this._acceptedTypes;
		
	},
	deactivate: function(){
		// Summary:
		//		disconnects this class to the dojo.dnd.manager() onMouseUp function.
		//		Sets the accepted types to empty, to avoid any drop action
		connect.disconnect(this._connectorHandle);
		this._dropable.accept = {};
	},
	isDropAction: function(){
		// Summary:
		//		return if a drop action is taking place
		return this._droppedItem != null;
	},
	setAcceptedTypes: function(types /*array*/){
		// Summary:
		//		sets the accepted types to be used in the Target element.
		//		The change take place when reactivating this class
		this._acceptedTypes = {};
			for(var i = 0; i < types.length; ++i){
				this._acceptedTypes[types[i]] = 1;
			}
	},
	setOnDropFunction: function(onDropFunction){
		// Summary:
		//		sets the onDropFunction. This function is called when a drop action occurs.
		this._onDropFunction = onDropFunction;
	},
	setOnDropTemplateFunction: function(onDropTemplateFunction){
		// Summary:
		//		sets the onDropTemplateFunction. This function is called to resolve the template when a drop action is taking place.
		this._onDropTemplateFunction = onDropTemplateFunction;
	},
	resolveNodeTemplate: function(dataItem){
		// Summary:
		//		called the onDropTemplateFunction with the given item, and the dropped item
		return this._onDropTemplateFunction?this._onDropTemplateFunction.call(null,this._droppedItem,dataItem,this._diagram):null;
	},
	setDroppedItem: function(droppedItem){
		this._droppedItem = droppedItem;
	},
	_onDropNode: function(source, nodes, copy){
		// Summary:
		//		function called when Target.onDrop is called
		//		Override that method
		this._droppedItem = source.getItem(nodes[0].id);
	},
	_onMouseUpManager: function(e){
		// Summary:
		//		function called when dojo.dnd.manager() "onMouseUp" is called
		//		In this method, the onDropFunction is called
		if(this.isDropAction()){
			var D = this._diagram;
			var V = D.getViewport();
			var GR = D.getGraph();
			var p = V.eventContentLocation(e);
			var elements = D.getGraph().hitTest(p);
			eu.startDropAction(this._droppedItem,p,D,elements,eu.createOnDropAction(D,this._droppedItem,p,elements));
			this._droppedItem = null;
		}
	},
	
	getDiagram: function(){
		return this._diagram;
	}
});

return DropInteractor;

});

},
'ibm_ilog/diagram/editor/interactors/ConnectionTargetInteractor':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/interactors/ConnectionTargetInteractor", [
"dojo/_base/declare",
"../../interactors/Interactor",
"../adorners/ConnectionTargetAdorner",
"../../util/Geometry",
"../../util/GraphUtil"
], function(
declare,
Interactor,
ConnectionTargetAdorner,
g,
gu
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var ConnectionTargetInteractor =
declare("ibm_ilog.diagram.editor.interactors.ConnectionTargetInteractor", [Interactor], {
	//
	//	summary:
	//		A ConnectionTargetInteractor controls the process of selecting the target Connection point
	//		This feature has a low cpu usage alternative. (set in the diagram)
	//
	//
	//	_viewport: ibm_ilog.diagram.widget.Viewport
	//		The diagram viewport 
	//
	_viewport: null,

	//
	//	_diagram: ibm_ilog.diagram.widget.Diagram
	//		The diagram to pan
	//
	_diagram: null,

	_targetIsFree: true,

	_target: null,

	_targetAdorner: null,

	_margin: 12,

	_fixedNode: null,
	_isStart: true,
	_standardCursor: null,
	_forbiddenCursor: "not-allowed",
	_allowedCursor: "crosshair",
	_connectionInteractor: null,
	_lowCpuMode: null,
	_lastPosition: null,

	initialize: function ( /*ibm_ilog.diagram.widget.Diagram*/ diagram, connectionInteractor) {
		this._diagram = diagram;
		this._viewport = diagram.getViewport();
		this._targetIsFree = true;
		this._target = null;
		this._connectionInteractor = connectionInteractor;
		this._targetAdorner = diagram.createAdorner(ConnectionTargetAdorner, this._diagram._adornerTemplates, "ConnectionAdorner");
		this._targetAdorner.setConnectionInteractor(connectionInteractor);
		this._initialize();
		return this;
	},

	setUp: function (node, isStart, allowFreeLinks) {
		this._fixedNode = node;
		this._isStart = isStart;
		this._allowFreeLinks = allowFreeLinks;
		if(this._lowCpuMode != this._diagram.isLowCpuMode()){
			this._lowCpuMode = this._diagram.isLowCpuMode();
			this.deactivate();
			this._initialize();
		}
		this._lastPosition = {x:0, y:0};
	},

	_declareStates: function () {
		if(this._lowCpuMode == true){
			this._declareState("idle", ["nodeover", "subgraphover", "testfreetarget"]);
		}else{
			this._declareState("idle", ["detectOnOver"]);
		}
	},

	getDefaultConnections: function () {
		//
		//	summary:
		//		returns the default event mapping
		//
		if(this._lowCpuMode == true){
			return {
				nodeover: {
					src: this._diagram,
					srcEvt: "onNodeMouseOver",
					connectTo: "_setTarget"
				}, subgraphover: {
					src: this._diagram,
					srcEvt: "onSubgraphMouseOver",
					connectTo: "_setTarget"
				}, testfreetarget: {
					src: this._viewport.getEventSource(),
					srcEvt: "onmousemove",
					connectTo: "_testFreeTarget",
					gfxConnect: true
				}
				};
				
		}else{
						return {
				detectOnOver: {
					src: this._viewport.getEventSource(),
					srcEvt: "onmousemove",
					connectTo: "_detectOnOver",
					gfxConnect: true
				}
				};
		}
	},

	_setTarget: function (ge, e) {
		if (this._targetIsFree || gu.isContainedBy(ge, this._target)) {
			var start, end;
			if (this._isStart) {
				start = this._fixedNode;
				end = ge;
			} else {
				end = this._fixedNode;
				start = ge;
			}
			var D = this._diagram;
			if (!D.allowCreateLink(start, end)) {
				D.domNode.style.cursor = this._forbiddenCursor;
			} else {
				D.domNode.style.cursor = this._allowedCursor;
			}
			this._setTargetAdorner(ge);
			this._targetIsFree = false;
			//dojo.stopEvent(e);
		}
	},

	_setTargetAdorner: function (ge) {
		this._target = ge;
		this._targetAdorner.setAdorned(ge);
		this._connectionInteractor.setTarget(ge);
	},

	activate: function () {
		this.inherited(arguments);
		this._standardCursor = dojo.isIE ? "default" : this._diagram.domNode.style.cursor;
		this._setFreeCursor();
	},

	deactivate: function () {
		this.inherited(arguments);
		this._freeTarget();
		this._diagram.domNode.style.cursor = this._standardCursor;
	},

	_freeTarget: function (e) {
		if (!this._targetIsFree) {
			this._targetAdorner.setAdorned(null);
			this._connectionInteractor.setTarget(null);
		}
		this._targetIsFree = true;
		this._target = null;
		this._setFreeCursor();
	},

	_testFreeTarget: function (e) {
		if (!this._targetIsFree) {
			var c = this._target;
			if (c) {
				var bb = g.expandRect(c.getBounds(this._viewport.getSurface()), this._margin);
				var l = this._viewport.eventClientLocation(e);
				if (!g.containsPoint(bb, l)) {
					this._freeTarget();
				}
			}
		}
	},
	_setFreeCursor: function () {
		if (this._allowFreeLinks) {
			this._diagram.domNode.style.cursor = this._allowedCursor;
		} else {
			this._diagram.domNode.style.cursor = this._forbiddenCursor;
		}
	},
	_detectOnOver: function (e) {
		//added to increase performance
		var current = {x:e.pageX, y:e.pageY};
		var delta = {
				x: Math.abs(current.x - this._lastPosition.x),
				y: Math.abs(current.y - this._lastPosition.y)
			};
		var minDelta = 2;
		if(delta.x<minDelta && delta.y<minDelta){
			return;
		}
		
		this._testFreeTarget(e);	
		var p = this._viewport.eventContentLocation(e);
		var ges = this._diagram.getGraph().hitTest(p,0);
		for (var index in ges){
			var ge = ges[index];
			if(ge._isIBMDiagramNode || ge._isIBMDiagramSubgraph){
				this._setTarget(ge,e);
				break;
			}
		}
		
		this._lastPosition = {x:current.x, y:current.y};
		
	}

});

return ConnectionTargetInteractor;

});

},
'ibm_ilog/diagram/editor/interactors/UndoManagerKeyInteractor':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/interactors/UndoManagerKeyInteractor", [
"dojo/_base/declare",
"../../interactors/Interactor"
], function(
declare,
Interactor
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var UndoManagerKeyInteractor =
declare("ibm_ilog.diagram.editor.interactors.UndoManagerKeyInteractor", [Interactor], {
	//summary:
	//		This interactor manages the UndoManager through the keyboard interaction.
	//		This interactor has 2 connections: undo, redo.
	
	_diagram: null,
	initialize: function (diagram) {
	// summary:
    //		initialize the new instance.
    // diagram: ibm_ilog.diagram.widget.Diagram
    //		the associated diagram.		
		this._diagram = diagram;
		return this._initialize();
	},
	undo: function(e){
		// summary:
	    //		this methods calls the UndoManager undoAction function.
		this._diagram.getUndoManager().undoAction();
	},
	redo: function(e){
		// summary:
	    //		this methods calls the UndoManager redoAction function.
		this._diagram.getUndoManager().redoAction();
	},
	getKeyInteractorId: function(){
		// summary:
	    //		returns the Interactor Id
		return UndoManagerKeyInteractor.KeyInteractorId;
	},
	getDefaultConnections: function () {
		// summary:
		//		returns the default event mapping
		
		return {
			redo: {
				hotKey: 89,//  letter Y
				connectTo: "redo",
				filter: this._buildInputFilter({ctrl:true,shift:false,alt:false})
			}, undo: {
				hotKey: 90,//  letter Z
				connectTo: "undo",
				filter: this._buildInputFilter({ctrl:true,shift:false,alt:false})
			}
		};
	}
});

UndoManagerKeyInteractor.KeyInteractorId = "UndoManager";

return UndoManagerKeyInteractor;

});

},
'ibm_ilog/diagram/editor/undo/InvertLinkAction':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/undo/InvertLinkAction", [
"dojo/_base/declare",
"dojo/_base/lang",
"./Action",
"./UndoActionList"
], function(
declare,
lang,
Action,
UndoActionList
){
/*=====
var Action = ibm_ilog.diagram.editor.undo.Action;
=====*/

	var InvertLinkAction =
	declare("ibm_ilog.diagram.editor.undo.InvertLinkAction", [Action], {
		//
		//	summary:
		//		this action undo / redo a reparenting action.
		_modifiedElementId: null,
	
	constructor:function(){
		//	
		// summary:
		//		creates a new instance, setting the corresponding label
		this._label = UndoActionList.InvertLink;
		this.initialize(lang.hitch(this,this._changeFunction),lang.hitch(this,this._changeFunction));
	},
	setModifiedElementId: function(modifiedElementId){
		//	
		// summary:
		//		sets the modified element Id
		this._modifiedElementId= modifiedElementId;
	},
	_changeFunction: function(){
		var modifiedElement = this.getUndoManager().getRegisteredGraphElement(this._modifiedElementId);
		InvertLinkAction.EditingUtils.invertLink(modifiedElement);
	}
	});
	
	return InvertLinkAction;
	
});

},
'ibm_ilog/diagram/layer_editing':function(){
// wrapped by build app
define(["dijit","dojo","dojox","dojo/require!ibm_ilog/diagram/layer_editing_dojo_requires,ibm_ilog/diagram/editor/adorners/ComponentAdorner,ibm_ilog/diagram/editor/adorners/ConnectionAdorner,ibm_ilog/diagram/editor/adorners/ConnectionHandle,ibm_ilog/diagram/editor/adorners/ConnectionTargetAdorner,ibm_ilog/diagram/editor/adorners/ConnectionTargetHandle,ibm_ilog/diagram/editor/adorners/LinkConnectionAdorner,ibm_ilog/diagram/editor/adorners/LinkConnectionHandle,ibm_ilog/diagram/editor/adorners/LinkIntermediatePointsAddHandle,ibm_ilog/diagram/editor/adorners/LinkIntermediatePointsAdorner,ibm_ilog/diagram/editor/adorners/LinkIntermediatePointsHandle,ibm_ilog/diagram/editor/adorners/ResizeAdorner,ibm_ilog/diagram/editor/adorners/ResizeHandle,ibm_ilog/diagram/editor/adorners/TextEditAdorner,ibm_ilog/diagram/editor/Clipboard,ibm_ilog/diagram/editor/DiagramEditor,ibm_ilog/diagram/editor/DiagramSerializer,ibm_ilog/diagram/editor/EditingUtils,ibm_ilog/diagram/editor/interactors/AddIntermediatePointHandlerInteractor,ibm_ilog/diagram/editor/interactors/AddIntermediatePointInteractor,ibm_ilog/diagram/editor/interactors/ClipboardKeyInteractor,ibm_ilog/diagram/editor/interactors/ConnectionHandleInteractor,ibm_ilog/diagram/editor/interactors/ConnectionKeyInteractor,ibm_ilog/diagram/editor/interactors/ConnectionTargetHandleInteractor,ibm_ilog/diagram/editor/interactors/ConnectionTargetInteractor,ibm_ilog/diagram/editor/interactors/DeleteKeyInteractor,ibm_ilog/diagram/editor/interactors/DropInteractor,ibm_ilog/diagram/editor/interactors/InlineEditorKeyInteractor,ibm_ilog/diagram/editor/interactors/LinkConnectionHandleInteractor,ibm_ilog/diagram/editor/interactors/LinkIntermediatePointsHandleInteractor,ibm_ilog/diagram/editor/interactors/ResizeHandleInteractor,ibm_ilog/diagram/editor/interactors/ResizeKeyInteractor,ibm_ilog/diagram/editor/interactors/RotateHandleInteractor,ibm_ilog/diagram/editor/interactors/UndoManagerKeyInteractor,ibm_ilog/diagram/editor/undo/Action,ibm_ilog/diagram/editor/undo/ChangeLinkIntermediatePointsAction,ibm_ilog/diagram/editor/undo/ConnectAction,ibm_ilog/diagram/editor/undo/DeleteAction,ibm_ilog/diagram/editor/undo/DropAction,ibm_ilog/diagram/editor/undo/GroupAction,ibm_ilog/diagram/editor/undo/InvertLinkAction,ibm_ilog/diagram/editor/undo/MultipleAction,ibm_ilog/diagram/editor/undo/PasteNodeAction,ibm_ilog/diagram/editor/undo/ReConnectAction,ibm_ilog/diagram/editor/undo/ReorderAction,ibm_ilog/diagram/editor/undo/ReparentingAction,ibm_ilog/diagram/editor/undo/SimpleAction,ibm_ilog/diagram/editor/undo/UndoActionList,ibm_ilog/diagram/editor/undo/UndoManager,ibm_ilog/diagram/editor/undo/UngroupAction,ibm_ilog/diagram/editor/undo/UserCustomizedAction"], function(dijit,dojo,dojox){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
dojo.provide('ibm_ilog.diagram.layer_editing');

dojo.require('ibm_ilog.diagram.layer_editing_dojo_requires');

dojo.require('ibm_ilog.diagram.editor.adorners.ComponentAdorner');
dojo.require('ibm_ilog.diagram.editor.adorners.ConnectionAdorner');
dojo.require('ibm_ilog.diagram.editor.adorners.ConnectionHandle');
dojo.require('ibm_ilog.diagram.editor.adorners.ConnectionTargetAdorner');
dojo.require('ibm_ilog.diagram.editor.adorners.ConnectionTargetHandle');
dojo.require('ibm_ilog.diagram.editor.adorners.LinkConnectionAdorner');
dojo.require('ibm_ilog.diagram.editor.adorners.LinkConnectionHandle');
dojo.require('ibm_ilog.diagram.editor.adorners.LinkIntermediatePointsAddHandle');
dojo.require('ibm_ilog.diagram.editor.adorners.LinkIntermediatePointsAdorner');
dojo.require('ibm_ilog.diagram.editor.adorners.LinkIntermediatePointsHandle');
dojo.require('ibm_ilog.diagram.editor.adorners.ResizeAdorner');
dojo.require('ibm_ilog.diagram.editor.adorners.ResizeHandle');
dojo.require('ibm_ilog.diagram.editor.adorners.TextEditAdorner');
dojo.require('ibm_ilog.diagram.editor.Clipboard');
dojo.require('ibm_ilog.diagram.editor.DiagramEditor');
dojo.require('ibm_ilog.diagram.editor.DiagramSerializer');
dojo.require('ibm_ilog.diagram.editor.EditingUtils');
dojo.require('ibm_ilog.diagram.editor.interactors.AddIntermediatePointHandlerInteractor');
dojo.require('ibm_ilog.diagram.editor.interactors.AddIntermediatePointInteractor');
dojo.require('ibm_ilog.diagram.editor.interactors.ClipboardKeyInteractor');
dojo.require('ibm_ilog.diagram.editor.interactors.ConnectionHandleInteractor');
dojo.require('ibm_ilog.diagram.editor.interactors.ConnectionKeyInteractor');
dojo.require('ibm_ilog.diagram.editor.interactors.ConnectionTargetHandleInteractor');
dojo.require('ibm_ilog.diagram.editor.interactors.ConnectionTargetInteractor');
dojo.require('ibm_ilog.diagram.editor.interactors.DeleteKeyInteractor');
dojo.require('ibm_ilog.diagram.editor.interactors.DropInteractor');
dojo.require('ibm_ilog.diagram.editor.interactors.InlineEditorKeyInteractor');
dojo.require('ibm_ilog.diagram.editor.interactors.LinkConnectionHandleInteractor');
dojo.require('ibm_ilog.diagram.editor.interactors.LinkIntermediatePointsHandleInteractor');
dojo.require('ibm_ilog.diagram.editor.interactors.ResizeHandleInteractor');
dojo.require('ibm_ilog.diagram.editor.interactors.ResizeKeyInteractor');
dojo.require('ibm_ilog.diagram.editor.interactors.RotateHandleInteractor');
dojo.require('ibm_ilog.diagram.editor.interactors.UndoManagerKeyInteractor');
dojo.require('ibm_ilog.diagram.editor.undo.Action');
dojo.require('ibm_ilog.diagram.editor.undo.ChangeLinkIntermediatePointsAction');
dojo.require('ibm_ilog.diagram.editor.undo.ConnectAction');
dojo.require('ibm_ilog.diagram.editor.undo.DeleteAction');
dojo.require('ibm_ilog.diagram.editor.undo.DropAction');
dojo.require('ibm_ilog.diagram.editor.undo.GroupAction');
dojo.require('ibm_ilog.diagram.editor.undo.InvertLinkAction');
dojo.require('ibm_ilog.diagram.editor.undo.MultipleAction');
dojo.require('ibm_ilog.diagram.editor.undo.PasteNodeAction');
dojo.require('ibm_ilog.diagram.editor.undo.ReConnectAction');
dojo.require('ibm_ilog.diagram.editor.undo.ReorderAction');
dojo.require('ibm_ilog.diagram.editor.undo.ReparentingAction');
dojo.require('ibm_ilog.diagram.editor.undo.SimpleAction');
dojo.require('ibm_ilog.diagram.editor.undo.UndoActionList');
dojo.require('ibm_ilog.diagram.editor.undo.UndoManager');
dojo.require('ibm_ilog.diagram.editor.undo.UngroupAction');
dojo.require('ibm_ilog.diagram.editor.undo.UserCustomizedAction');

});

},
'ibm_ilog/diagram/editor/undo/ChangeLinkIntermediatePointsAction':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/undo/ChangeLinkIntermediatePointsAction", [
"dojo/_base/declare",
"dojo/_base/lang",
"./Action",
"./UndoActionList"
], function(
declare,
lang,
Action,
UndoActionList
){

/*=====
var Action = ibm_ilog.diagram.editor.undo.Action;
=====*/

	var ChangeLinkIntermediatePointsAction =
	declare("ibm_ilog.diagram.editor.undo.ChangeLinkIntermediatePointsAction", [Action], {
		//	
		// summary:
		//		this action undo/redo any Connect action.
		//		This action must be modified for the user if any user defined action is done on a connect action.
		//
		_linkId: null,
		_newPoint: null,
		_oldPoint:null,
		_index:null,
		_operation: null,
	constructor:function(diagram,link){
		//	
		// summary:
		//		creates a new instance, setting the corresponding label
		this._linkId = link.getId();
		this.initialize(lang.hitch(this,this._undoFunction),lang.hitch(this,this._redoFunction));
	},
	setRemovePointOperation: function(index,oldPoint){
		this._operation = 0;
		this._label = UndoActionList.RemoveIntermediatePoint;
		this._index = index;
		this._oldPoint = lang.clone(oldPoint);
	},
	setAddPointOperation: function(index,point){
		this._operation = 1;
		this._label = UndoActionList.AddIntermediatePoint;
		this._index = index;
		this._newPoint = lang.clone(point);
	},
	setModifyPointOperation: function(index,newPoint,oldPoint){
		this._operation = 2;
		this._label = UndoActionList.ModifyIntermediatePoint;
		this._index = index;
		this._oldPoint = lang.clone(oldPoint);
		this._newPoint = lang.clone(newPoint);
	},
	getLink: function(){
		//	
		// summary:
		//		returns the link, looking for replaces if necessary
		return this.getUndoManager().getRegisteredGraphElement(this._linkId);
	},
	_undoFunction: function(){
		var link = this.getLink();
		switch(this._operation){
			case 0: // Remove
				this._addPoint(link,this._index,this._oldPoint);
				break;
			case 1: // Add
				this._removePoint(link,this._index);
				break;
			case 2: // Modify
				this._modifyPoint(link,this._index,this._oldPoint);
				break;
			}
	},
	_redoFunction: function(){
		var link = this.getLink();
		switch(this._operation){
			case 0: // Remove
				this._removePoint(link,this._index);
				break;
			case 1: // Add
				this._addPoint(link,this._index,this._newPoint);
				break;
			case 2: // Modify
				this._modifyPoint(link,this._index,this._newPoint);
				break;
			}
	},
	_removePoint: function(link,index){
		var intermediatePoints = link.getIntermediatePoints();
		intermediatePoints = intermediatePoints.slice(0,index).concat(intermediatePoints.slice(index+1))
		link.setIntermediatePoints(intermediatePoints);
	},
	_addPoint: function(link,index,point){
		var intermediatePoints = link.getIntermediatePoints();
		intermediatePoints = intermediatePoints.slice(0,index).concat([point]).concat(intermediatePoints.slice(index));
		link.setIntermediatePoints(intermediatePoints);
	},
	_modifyPoint: function(link,index,point){
		var intermediatePoints = link.getIntermediatePoints();
		intermediatePoints[index].x = point.x;
		intermediatePoints[index].y = point.y;
		link.setIntermediatePoints(intermediatePoints);
	}
	});
	
	return ChangeLinkIntermediatePointsAction;
	
});

},
'ibm_ilog/diagram/editor/interactors/ClipboardKeyInteractor':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/interactors/ClipboardKeyInteractor", [
"dojo/_base/declare",
"../../interactors/Interactor"
], function(
declare,
Interactor
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var ClipboardKeyInteractor =
declare("ibm_ilog.diagram.editor.interactors.ClipboardKeyInteractor", [Interactor], {
	//summary:
	//		This interactor manages the Clipboard through the keyboard interaction.
	//		This interactor has 3 connections: cut, copy, paste.
	
	_diagram: null,
	initialize: function (diagram) {
	// summary:
    //		initialize the new instance.
    // diagram: ibm_ilog.diagram.widget.Diagram
    //		the associated diagram.		
		this._diagram = diagram;
		return this._initialize();
	},
	copy: function(e){
		// summary:
	    //		This method calls the Clipboard Copy function.
		this._diagram.getClipboard().copy();
	},
	paste: function(e){
		// summary:
	    //		This method calls the Clipboard Paste function. The pasteObject is the focused element if it is a subgraph, or its parent if other.
		//		If there is no focused element, the paste action is done in the top level graph. The paste position is set to {x:0,y:0} but the pasted 
		//		elements remains selected to easily move them.
		
		var clipboard = this._diagram.getClipboard();
		var container = this._diagram.getFocusedElement();
		if(container){
			if(container._isIBMDiagramSubgraph){
				container = container.getGraph();
			}else{
				container = container.getParent();
			}
		}else{
			container = this._diagram.getGraph();
		}
		
		clipboard.paste(container);
	},
	cut: function(e){
		// summary:
	    //		This method calls the Clipboard Cut function.
		this._diagram.getClipboard().cut();
	},
	getKeyInteractorId: function(){
		// summary:
	    //		returns the Interactor Id
		return ClipboardKeyInteractor.KeyInteractorId;
	},
	getDefaultConnections: function () {
		// summary:
		//		returns the default event mapping
		
		return {
			copy: {
				hotKey: 67,//  letter C	
				connectTo: "copy",
				filter: this._buildInputFilter({ctrl:true,shift:false,alt:false})
			}, paste: {
				hotKey: 86,//  letter V
				connectTo: "paste",
				filter: this._buildInputFilter({ctrl:true,shift:false,alt:false})
			}, cut: {
				hotKey: 88,//  letter X
				connectTo: "cut",
				filter: this._buildInputFilter({ctrl:true,shift:false,alt:false})
			}
		};
	}
});

ClipboardKeyInteractor.KeyInteractorId = "Clipboard";

return ClipboardKeyInteractor;

});

},
'ibm_ilog/diagram/editor/interactors/ConnectionHandleInteractor':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/interactors/ConnectionHandleInteractor", [
"../../main",
"dojo/_base/declare",
"dojox/gfx",
"../../interactors/DragInteractor",
"../interactors/ConnectionTargetInteractor",
"../undo/ConnectAction",
"../../Port",
"../../Link",
"../../util/GraphUtil"
], function(
iid,
declare,
gfx,
DragInteractor,
ConnectionTargetInteractor,
ConnectAction,
Port,
Link,
gu
){

/*=====
var DragInteractor = ibm_ilog.diagram.interactors.DragInteractor;
=====*/

var ConnectionHandleInteractor =
declare("ibm_ilog.diagram.editor.interactors.ConnectionHandleInteractor", [DragInteractor], {

	//	_handle: /*ibm_ilog.diagram.editor.adorners.ConnectionHandle*/
	_handle:null,
	_link:null,
	_linkShapeType: Link.LinkShapeType.Straight,
	_automaticPortType: false,
	_allowFreeLinks: false,
	_target: null,
	_targetPosition: null,
	
	_targetInteractor: null,
	
	_declareStates: function() {
	// Summary:
	//		Add the crtl start to the original states
		this.inherited(arguments);	
		this._declareState("idle",["start","startCtrl"]);
	},
	
	getDefaultConnections:function(){
		//
		//	summary:
		//		returns the default event mapping
		//
    		var map = this.inherited(arguments);
    		map.startCtrl = {src:this._getInitialEventSource(),srcEvt:"onmousedown",connectTo:"_dragCrtlPreStart",filter:this._buildInputFilter({ctrl:true,button:0}), gfxConnect:true};
    		return map;
    },
	
	initialize: function( /* ibm_ilog.diagram.editor.ConnectionHandle */ connectionHandle ) {
		this._handle = connectionHandle;
		this._viewport = connectionHandle.getViewport();
		var linkStyle = this._viewport.getDiagram().linkStyle;
		this._linkShapeType = linkStyle?linkStyle.shapeType:Link.LinkShapeType.Straight;
		this._targetInteractor = new ConnectionTargetInteractor().initialize(this._handle._adorner._viewport._diagram,this);
		this._initialize();
		return this;
	},
	
	setTarget: function(target){
		// Summary:
		//		sets the target node that will be the end node of the new link.
		//		this function is called by the ConnectionTargetInteractor
		this._target = target;
	},
	
	setPortPosition: function(position){
		// Summary:
		//		sets the target port position that will be the end port position of the new link.
		//		this function is called by the ConnectionTargetHandleInteractor
		this._targetPosition = position;
	},
	
	setAllowFreeLinks: function(allowFreeLinks){
		// Summary:
		//		controls if the free links (links with no final nodes) are allowed
		this._allowFreeLinks = allowFreeLinks;
	},
	
	setLinkShapeType: function(linkShapeType){
		// Summary:
		//		sets the link shape type
		this._linkShapeType = linkShapeType;
	},
	
	_getInitialEventSource: function() {
		return this._handle;
	},
	
	_dragCrtlPreStart: function(e) {
		this._dragPreStart(e);
		this._automaticPortType = true;
	},
	
    _dragPreStart: function(e) {
		this._allowFreeLinks = this._viewport.getDiagram().getAllowFreeLinks();
		this._handle.interactionBegun(this);
		this._automaticPortType = false;
		this.inherited(arguments);
	},
	
	_dragMove: function(e) {
    	this.inherited(arguments);
		
    	var A = this._handle._adorner;
    	var V = A._viewport;
    	var D = V.getDiagram();
		if( this._link == null ){
			this._targetPosition = null;
			this._link = D.createTemplatedShape(Link, Link.defaultTemplate, D.getGraph());
			//this._link = D.createLinkShape(D.getGraph());
			var startPort = this._createPort(this._automaticPortType,this._handle.getPortPosition());
			var start = A._adorned;
			start.addPort(startPort);
			this._link.setStartPort(startPort);
			this._link.setShapeType(this._linkShapeType);
			this._targetInteractor.setUp(start,true,this._allowFreeLinks);
			this._targetInteractor.activate();
		}
		
		var point = V.eventContentLocation(e);
		var t = D.getGraph().getShapeToContainerTransform(D.getGraph().getParent()).inverse();
		point = t.transformPoint(point);
		this._link.setFallbackEndPoint(point);
		
		this._link.validateLinkShape();
	},

	_dragEnd: function(e) {
		this.inherited(arguments);
		var A = this._handle._adorner;
		var V = A._viewport;
		var D = V._diagram;
		
		if( this._link != null ){
			if(this._target){
				var endPort = this._createPort(false,this._targetPosition);
				var start = this._link.getStartNode();
				var end = this._target;
				if(D.allowCreateLink(start,end)){
					end.addPort(endPort);
					this._link.setEndPort(endPort);
					//reparent the link, with the lower common parent
					var cParent = gu.lowestCommonAncestor(start,end);
					if(cParent != this._link.getParent()){
						if(iid.isVml){
							// workaround for VML remove/add bug, occurs here since fixVmlAdd flag was added
							var oldParent = this._link.getParent();
							if(oldParent) { oldParent.remove(this._link); }
							cParent.rawNode.appendChild(this._link.rawNode);
							gfx.shape.Container.add.call(cParent, this._link);
							gfx.utils.forEach(this._link, function(s){
								if(s.setFill) s.setFill(s.getFill());
								if(s.setStroke) s.setStroke(s.getStroke());
							});
						} else {
							cParent.add(this._link);
						}
					}
					var undoAction = this._createUndoAction(D,this._link,cParent);
					D._onLinkCreated(this._link,start,end,D);
					D.onLinkUpdated(D,this._link,true,undoAction);
					if(D._isIBMDiagramEditor){
						D.getUndoManager().addAction(undoAction);
					}
					this._link.validateLinkShape();
				}else{
					D.getGraph().remove(this._link);
					this._link.dispose();
					//TODO add onMessage call
				}
			}else{
				if(!this._allowFreeLinks){
					D.getGraph().remove(this._link);
					this._link.dispose();
					//TODO add onMessage call
				}else{
					var undoAction = null;
					if(D._isIBMDiagramEditor){
						undoAction = this._createUndoAction(D,this._link,D.getGraph());
						D.getUndoManager().addAction(undoAction);
					}
					D.onLinkCreated(this._link,this._link.getStartNode(),null,D);
					D.onLinkUpdated(D,this._link,true,undoAction);
				}
			}
			
			this._link =null;
			this._targetInteractor.deactivate();
		}
		this._handle.interactionEnded(this);
	},
	
	_createPort: function(automaticPortType,position){
		var port;
		if(automaticPortType || !position){
			port = new Port.AutomaticPort();
		}else{
			port = new Port.BasicPort();
			port.setPosition(position);
		}
		return port;
	},
	_createUndoAction: function(diagram,link,parent){
		var action = new ConnectAction(diagram,link,parent);
		return action;
	}
});

return ConnectionHandleInteractor;

});
},
'ibm_ilog/diagram/editor/interactors/ResizeKeyInteractor':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/interactors/ResizeKeyInteractor", [
"dojo/_base/declare",
"dojo/keys",
"../../interactors/Interactor",
"../undo/SimpleAction",
"../undo/UndoActionList",
"../../util/Geometry"
], function(
declare,
keys,
Interactor,
SimpleAction,
UndoActionList,
Geometry
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var ResizeKeyInteractor =
declare("ibm_ilog.diagram.editor.interactors.ResizeKeyInteractor", [Interactor], {
	//summary:
	//		This interactor manages the graphElements resizing through the keyboard interaction.
	//		This interactor has 8 connections: reduceWidth, fineReduceWidth, increaseWidth, fineIncreaseWidth, 
	//		reduceHeight, fineReduceHeight, increaseHeight, fineIncreaseHeight.
	
	_diagram: null,
	_increment: null,
	_fineIncrement: null,
	initialize: function (diagram) {
	// summary:
    //		initialize the new instance.
    // diagram: ibm_ilog.diagram.widget.Diagram
    //		the associated diagram.		
		this._diagram = diagram;
		this.setIncrement(10);
		this.setFineIncrement(1);
		return this._initialize();
	},
	setIncrement: function(increment){
		// summary: 
		//		sets the resize increment
		// increment: integer
		//		the increment to be set
		this._increment = increment;
	},
	getIncrement: function(){
		// summary: 
		//		gets the resize increment
		return this._increment;
	},
	setFineIncrement: function(increment){
		// summary: 
		//		sets the resize fine increment
		// increment: integer
		//		the fine increment to be set
		this._fineIncrement = increment;
	},
	getFineIncrement: function(){
		// summary: 
		//		gets the resize fine increment
		return this._fineIncrement;
	},
	reduceHeight: function(e){
		// summary: 
		//		Reduces the focused element height from the right bottom corner
		this._resize({x:0,y:-this._increment});
	},
	increaseHeight: function(e){
		// summary: 
		//		Increases the focused element height from the right bottom corner
		this._resize({x:0,y:this._increment});
	},
	increaseWidth: function(e){
		// summary: 
		//		Increases the focused element width from the right bottom corner
		this._resize({x:this._increment,y:0});
	},
	reduceWidth: function(e){
		// summary: 
		//		Reduces the focused element width from the right bottom corner
		this._resize({x:-this._increment,y:0});
	},
	fineReduceHeight: function(e){
		// summary: 
		//		Finely reduces the focused element height from the right bottom corner
		this._resize({x:0,y:-this._fineIncrement});
	},
	fineIncreaseHeight: function(e){
		// summary: 
		//		Finely increases the focused element height from the right bottom corner
		this._resize({x:0,y:this._fineIncrement});
	},
	fineIncreaseWidth: function(e){
		// summary: 
		//		Finely increases the focused element width from the right bottom corner
		this._resize({x:this._fineIncrement,y:0});
	},
	fineReduceWidth: function(e){
		// summary: 
		//		Finely reduces the focused element width from the right bottom corner
		this._resize({x:-this._fineIncrement,y:0});
	},
	getKeyInteractorId: function(){
		// summary:
	    //		returns the Interactor Id
		return ResizeKeyInteractor.KeyInteractorId;
	},
	getDefaultConnections: function () {
		// summary:
		//		returns the default event mapping
		
		return {
			reduceWidth: {
				hotKey: keys.LEFT_ARROW,
				connectTo: "reduceWidth",
				filter: this._buildInputFilter({ctrl:true,shift:false})
			}, fineReduceWidth: {
				hotKey: keys.LEFT_ARROW,
				connectTo: "fineReduceWidth",
				filter: this._buildInputFilter({ctrl:true,shift:true})
			}, increaseWidth: {
				hotKey: keys.RIGHT_ARROW,
				connectTo: "increaseWidth",
				filter: this._buildInputFilter({ctrl:true,shift:false})
			}, fineIncreaseWidth: {
				hotKey: keys.RIGHT_ARROW,
				connectTo: "fineIncreaseWidth",
				filter: this._buildInputFilter({ctrl:true,shift:true})
			}, reduceHeight: {
				hotKey: keys.UP_ARROW,
				connectTo: "reduceHeight",
				filter: this._buildInputFilter({ctrl:true,shift:false})
			}, fineReduceHeight: {
				hotKey: keys.UP_ARROW,
				connectTo: "fineReduceHeight",
				filter: this._buildInputFilter({ctrl:true,shift:true})
			}, increaseHeight: {
				hotKey: keys.DOWN_ARROW,
				connectTo: "increaseHeight",
				filter: this._buildInputFilter({ctrl:true,shift:false})
			}, fineIncreaseHeight: {
				hotKey: keys.DOWN_ARROW,
				connectTo: "fineIncreaseHeight",
				filter: this._buildInputFilter({ctrl:true,shift:true})
			}
		};
	},
	_resize: function(delta){
		var ge = this._diagram.getFocusedElement();
		if(ge && !ge._IBMDiagramLink){
			var startBB = ge.getBounds();
			var endBB = Geometry.cloneRect(startBB);
			var min = ge.minimumSize;
		
			endBB.width = Math.max(min.width,startBB.width + delta.x);
			endBB.height = Math.max(min.height,startBB.height + delta.y);
		
			ge.setBounds(endBB);
			this._diagram.getUndoManager().addAction(this._createUndoAction(ge, startBB, endBB));
		}
	},
	_createUndoAction: function(ge, startBB, endBB){
		var action = new SimpleAction(UndoActionList.Resize);
		action.setOldValue(startBB);
		action.setNewValue(endBB);
		action.setMethodOrProperty('setBounds');
		action.setModifiedElementId(ge.getId());
		return action;
	}
});

ResizeKeyInteractor.KeyInteractorId = "Resize";

return ResizeKeyInteractor;

});

},
'ibm_ilog/diagram/editor/undo/DropAction':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/undo/DropAction", [
"dojo/_base/declare",
"./UserCustomizedAction",
"./UndoActionList"
], function(
declare,
UserCustomizedAction,
UndoActionList
){

/*=====
var UserCustomizedAction = ibm_ilog.diagram.editor.undo.UserCustomizedAction;
=====*/

	var DropAction = 
	declare("ibm_ilog.diagram.editor.undo.DropAction", [UserCustomizedAction], {
		//	
		// summary:
		//		this action undo/redo any drop action.
		//		This action must be modified for the user if any user defined action is done on a drop action.
		//
		_droppedItem: null,
		_droppedPosition: null,
		_elementsList: null,
		_dropInteractor: null,
		
	constructor:function(){
		//	
		// summary:
		//		creates a new instance, setting the corresponding label
		this._label = UndoActionList.Drop;
	},
	setDroppedItem: function(droppedItem){
		//	
		// summary:
		//		sets the dropped item
		this._droppedItem = droppedItem;
	},
	getDroppedItem: function(){
		//	
		// summary:
		//		gets the dropped item
		return this._droppedItem;
	},
	setDroppedPosition: function(droppedPosition){
		//	
		// summary:
		//		sets the dropped position (graph coordinates)
		this._droppedPosition = droppedPosition;
	},
	getDroppedPosition: function(){
		//	
		// summary:
		//		gets the dropped position (graph coordinates)
		return this._droppedPosition;
	},
	setElementsList: function(elementsList){
		//	
		// summary:
		//		sets the elements list, that contains the graph elements that match to the dropped position
		this._elementsList = elementsList;
	},
	getElementsList: function(){
		//	
		// summary:
		//		gets the elements list, that contains the graph elements that match to the dropped position
		return this._elementsList;
	},
	setDropInteractor: function(dropInteractor){
		//	
		// summary:
		//		sets the drop interactor
		this._dropInteractor = dropInteractor;
	},
	getDropInteractor: function(){
		//	
		// summary:
		//		gets the drop interactor
		return this._dropInteractor;
	},
	redoFunction: function(){
		var newElements = this._getNewList();
		var di = this.getDropInteractor()
		DropAction.EditingUtils.startDropAction(this.getDroppedItem(),this.getDroppedPosition(),di.getDiagram(),newElements,this);
	},
	_getNewList: function(){
		var newElements = [];
		var elements = this.getElementsList();
		dojo.forEach(elements, dojo.hitch(this, function(item){
			var newItem = this.getUndoManager().getRegisteredGraphElement(item);
			newElements.push(newItem);
		}));
		return newElements;
	}
	});
	
	return DropAction;
	
});

},
'ibm_ilog/diagram/editor/adorners/LinkConnectionAdorner':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/adorners/LinkConnectionAdorner", [
"dojo/_base/declare",
"../../base",
"../../adorners/LinkAdorner",
"../adorners/LinkConnectionHandle"
], function(
declare,
iid,
LinkAdorner,
LinkConnectionHandle
){
    
/*=====
var LinkAdorner = ibm_ilog.diagram.adorners.LinkAdorner;
=====*/

	var LinkConnectionAdorner =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.LinkConnectionAdorner',[LinkAdorner],{

    	initialize: function() {
    		this.inherited(arguments);

    		this._createHandle(LinkConnectionHandle,"start").setup(0);
    		this._createHandle(LinkConnectionHandle,"end").setup(1);

    	},
    	
    	activate: function() {
    		this._activateHandle("start");
    		this._activateHandle("end");
    	},
    	
    	deactivate: function() {
    		this._deactivateHandle("start");
    		this._deactivateHandle("end");
    	}

    }));

	return LinkConnectionAdorner;
	
});

},
'ibm_ilog/diagram/editor/adorners/LinkConnectionHandle':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/adorners/LinkConnectionHandle", [
"dojo/_base/declare",
"../../base",
"../../adorners/HighlightedHandle",
"../interactors/LinkConnectionHandleInteractor"
], function(
declare,
iid,
HighlightedHandle,
LinkConnectionHandleInteractor
){

/*=====
var HighlightedHandle = ibm_ilog.diagram.adorners.HighlightedHandle;
=====*/

	var LinkConnectionHandle =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.LinkConnectionHandle',[HighlightedHandle],{
		
		//
		//	location: handle position
		//
		location: null,
		
		setup: function(location) {
			// Summary:
			//		sets the handle positioning ( 0=start - 1=end )
			this.location = location;
			this.addInteractor(new LinkConnectionHandleInteractor().initialize(this));
			return this;
		},
		
		getLocation:function(){
			return this.location;
		}
	}));

	LinkConnectionHandle.templateId = "LinkConnectionHandle";

	return LinkConnectionHandle;

});


},
'ibm_ilog/diagram/editor/undo/UndoActionList':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/undo/UndoActionList", ["dojo/_base/lang"], function(lang) {

	// TODO: Change to this when AMD conversion is complete:
	// var UndoActionList = {};
	var UndoActionList = lang.getObject("ibm_ilog.diagram.editor.undo.UndoActionList", true);

	UndoActionList.Drop = "Drop";
	UndoActionList.RemoveIntermediatePoint = "RemoveIntermediatePoint";
	UndoActionList.AddIntermediatePoint = "AddIntermediatePoint";
	UndoActionList.ModifyIntermediatePoint = "ModifyIntermediatePoint";
	UndoActionList.Connect = "Connect";
	UndoActionList.ReConnect = "ReConnect";
	UndoActionList.ReParent = "ReParent";
	UndoActionList.Resize = "Resize";
	UndoActionList.Move = "Move";
	UndoActionList.Delete = "Delete";
	UndoActionList.Paste = "Paste";
	UndoActionList.Align = "Align";
	UndoActionList.Group = "Group";
	UndoActionList.Ungroup = "Ungroup";
	UndoActionList.Reorder = "Reorder";
	UndoActionList.InvertLink = "InvertLink";
	
	return UndoActionList;
	
});

},
'ibm_ilog/diagram/editor/undo/UngroupAction':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/undo/UngroupAction", [
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"dojox/gfx/matrix",
"./UserCustomizedAction",
"./UndoActionList",
"../../util/GraphUtil"
], function(
declare,
lang,
array,
m,
UserCustomizedAction,
UndoActionList,
GraphUtil
){
	
/*=====
var UserCustomizedAction = ibm_ilog.diagram.editor.undo.UserCustomizedAction;
=====*/

	var UngroupAction =
	declare("ibm_ilog.diagram.editor.undo.UngroupAction", [UserCustomizedAction], {
		//	
		// summary:
		//		this action undo/redo any Ungroup action.
		//		This action must be modified for the user if any user defined action is done on a Ungroup action.
		//
		
	_elements: null,
	_subgraph: null,
	_subgraphTransform: null,
	_deleteAction: null,
	constructor:function(){
		//	
		// summary:
		//		creates a new instance, setting the corresponding label
		this._label = UndoActionList.Group;
	},
	setElements: function(elements){
		//	
		// summary:
		//		sets the elements list to be group
		this._elements = [];
		array.forEach(elements,function(ge){this._elements.push(ge.getId());},this);
	},
	getElements: function(){
		//	
		// summary:
		//		gets the elements list to be group
		return this._elements;// summary:
		//		creates the group undo action.
		// subgraph: ibm_ilog.diagram.Subgraph
		//		the created subgraph, that groups the elements.
		// elements: array of ibm_ilog.diagram.GraphElement
		//		the elements that have been group.
	},
	setSubgraphId: function(subgraphId){
		//	
		// summary:
		//		sets the subgraph where to group
		this._subgraph = subgraphId;
	},
	getSubgraphId: function(){
		//	
		// summary:
		//		gets the subgraph where to group
		return this._subgraph;
	},
	setSubgraphTransform: function(subgraphT){
		//	
		// summary:
		//		sets the subgraph where to group
		this._subgraphTransform = subgraphT;
	},
	getSubgraphTransform: function(){
		//	
		// summary:
		//		gets the subgraph where to group
		return this._subgraphTransform;
	},
	setDeleteAction: function(deleteAction){
		//	
		// summary:
		//		sets the DeleteAction
		this._deleteAction = deleteAction;
		//this._deleteAction.getUndoManager = lang.hitch(function(){this.getUndoManager},this);
	},
	getDeleteAction: function(){
		//	
		// summary:
		//		gets the DeleteAction
		return this._deleteAction;
	},
	setUndoManager: function(undoManager){
		//
		//	summary:
		//		Sets the undo Manager
		this.inherited(arguments);
		this._deleteAction.setUndoManager(undoManager);
	},
	redoFunction: function(){
		var elements = this._getNewList();
		var D = this.getUndoManager().getDiagram();
		var sg = this.getUndoManager().getRegisteredGraphElement(this._subgraph);
		UngroupAction.EditingUtils.groupReparent(D,elements,sg.getParent(),sg);
		this._deleteAction.redo();
	},
	undoFunction: function(){
		var newElements = this._getNewList();
		var D = this.getUndoManager().getDiagram();
		this._deleteAction.undo();
		var sg = this.getUndoManager().getRegisteredGraphElement(this._subgraph);
		sg.setTransform(m.clone(this._subgraphTransform));
		var lca = GraphUtil.lowestCommonAncestor.apply(this,newElements);
		UngroupAction.EditingUtils.groupReparent(D,newElements,sg,lca);
	},
	_getNewList: function(){
		var newElements = [];
		var elements = this.getElements();
		array.forEach(elements, lang.hitch(this, function(item){
			var newItem = this.getUndoManager().getRegisteredGraphElement(item);
			newElements.push(newItem);
		}));
		return newElements;
	}
	});
	
	return UngroupAction;
	
});

},
'ibm_ilog/diagram/editor/interactors/ConnectionTargetHandleInteractor':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/interactors/ConnectionTargetHandleInteractor", [
"dojo/_base/declare",
"../../interactors/Interactor"
], function(
declare,
Interactor
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var ConnectionTargetHandleInteractor =
declare("ibm_ilog.diagram.editor.interactors.ConnectionTargetHandleInteractor", [Interactor], {

	_handle: null,
	_viewport: null,

	initialize: function ( /* ibm_ilog.diagram.editor.ConnectionHandle */ connectionHandle) {
		this._handle = connectionHandle;
		this._viewport = connectionHandle.getViewport();
		this._initialize();
		return this;
	},

	_declareStates: function () {
		this._declareState("idle", ["onMouseRealease"]);
	},

	getDefaultConnections: function () {
		//
		//	summary:
		//		returns the default event mapping
		//
		return {
			onMouseRealease: {
				src: this._getInitialEventSource(),
				srcEvt: "onmouseup",
				connectTo: "_setTarget",
				gfxConnect: true
			}
		};
	},
	
	_getInitialEventSource: function () {
		return this._handle;
	},

	_setTarget: function (ge, e) {
		this._handle.getConnectionInteractor().setPortPosition(this._handle.getPortPosition());
	}
});

return ConnectionTargetHandleInteractor;

});

},
'ibm_ilog/diagram/editor/undo/SimpleAction':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/undo/SimpleAction", [
"dojo/_base/declare",
"dojo/_base/lang",
"./Action"
], function(
declare,
lang,
Action
){
	
/*=====
var Action = ibm_ilog.diagram.editor.undo.Action;
=====*/

	var SimpleAction =
	declare("ibm_ilog.diagram.editor.undo.SimpleAction", [Action], {
		//
		//	summary:
		//		This class is the simple undo action. It is used to undo/redo simple properties that can be 
		//		changed by setting up a property or calling a method with a simple argument.
		//
		_oldValue:null,
		_newValue: null,
		_modifiedElementId: null,
		_methodOrProperty: null,
		_cloneFunction:null,
		
	constructor:function(label){
		//
		//	summary:
		//		creates a new instance, setting up the label
		//
		this._label = label;
		this.initialize(lang.hitch(this,this._undoFunction),lang.hitch(this,this._redoFunction));
	},
	setOldValue: function(oldValue){
		//
		//	summary:
		//		sets the old value
		this._oldValue = oldValue;
	},
	setNewValue: function(newValue){
		//
		//	summary:
		//		sets the new value
		this._newValue = newValue;
	},
	getOldValue: function(){
		//
		//	summary:
		//		gets the old value, cloning the set value if clone function is previously set
		return this._cloneFunction?this._cloneFunction.call(null,this._oldValue):this._oldValue;
	},
	getNewValue: function(){
		//
		//	summary:
		//		gets the new value, cloning the set value if clone function is previously set
		return this._cloneFunction?this._cloneFunction.call(null,this._newValue):this._newValue;
	},
	setModifiedElementId: function(modifiedElementId){
		//
		//	summary:
		//		sets the modified object
		this._modifiedElementId = modifiedElementId;
	},
	getModifiedElementId: function(){
		//
		//	summary:
		//		sets the modified object
		return this._modifiedElementId;
	},
	getModifiedElement: function(){
		//
		//	summary:
		//		gets the modified graph element, looking for its replacements if neccesary
		return this.getUndoManager().getRegisteredGraphElement(this._modifiedElementId);
	},
	setMethodOrProperty: function(methodOrProperty){
		//
		//	summary:
		//		sets the property or method name to be modified
		this._methodOrProperty = methodOrProperty;
	},
	setCloneFunction: function(cloneF){
		//
		//	summary:
		//		sets the clone function in case the value should be clone before the change action
		this._cloneFunction = cloneF;
	},
	_undoFunction: function(){
		this.changeFunction(this.getOldValue());
	},
	_redoFunction: function(){
		this.changeFunction(this.getNewValue());
	},
	changeFunction: function(value){	
		
		var modifiedObject = this.getModifiedElement();
		if( modifiedObject && this._methodOrProperty){
			if(modifiedObject[this._methodOrProperty]){
				if(dojo.isFunction(modifiedObject[this._methodOrProperty])){
					modifiedObject[this._methodOrProperty](value);
				}else{
					modifiedObject[this._methodOrProperty] = value;
				}
			}
		}
	}
	});
	
	return SimpleAction;
	
});

},
'ibm_ilog/diagram/editor/interactors/LinkIntermediatePointsHandleInteractor':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/interactors/LinkIntermediatePointsHandleInteractor", [
"dojo/_base/declare",
"dojo/_base/lang",
"../../interactors/DragInteractor",
"../undo/ChangeLinkIntermediatePointsAction",
"../../util/ClippingUtil",
"../../util/Geometry"
], function(
declare,
lang,
DragInteractor,
ChangeLinkIntermediatePointsAction,
ClippingUtil,
g
){

/*=====
var DragInteractor = ibm_ilog.diagram.interactors.DragInteractor;
=====*/

var LinkIntermediatePointsHandleInteractor =
declare("ibm_ilog.diagram.editor.interactors.LinkIntermediatePointsHandleInteractor", [DragInteractor], {
	// Summary:
	//		this class is the interactor associated to the LinkIntermediatePointHandle. 
	// 		It manages the functionality to edit the position of its point, and to delete it.

	//	_handle: /*LinkIntermediatePointsHandle*/
	_handle:null,
	_link:null,
	_targetPosition: null,
	_newPoint: null,
	_oldPoint: null,
	_minimumAngle: null,
	
	_declareStates: function() {
	// Summary:
	//		Add the deleteIntermediatePoint to the original states
		this.inherited(arguments);	
		this._declareState("idle",["start","deleteIntermediatePoint"]);
	},
	
	getDefaultConnections:function(){
		//
		//	summary:
		//		returns the default event mapping
		//
    		var map = this.inherited(arguments);
    		map.deleteIntermediatePoint = {src:this._getInitialEventSource(),srcEvt:"onmousedown",connectTo:"_deleteIntermediatePoint",filter:this._buildInputFilter({shift:true,button:0}), gfxConnect:true};
    		return map;
    },
	
	initialize: function( /* LinkIntermediatePointsHandle */ handle ) {
    	// Summary:
		//		sets the LinkIntermediatePointsHandle
    	this._handle = handle;
		this._viewport = handle.getViewport();
		this._initialize();
		this._minimumAngle = 7;
		return this;
	},
	
	_getInitialEventSource: function() {
		return this._handle;
	},
	
	_deleteIntermediatePoint: function(e) {
		// Summary:
		//		deletes the clicked intermediate point
		var A = this._handle.getAdorner();
		var D = A.getDiagram();
		var link = A.getAdorned();
		var intermediatePoints = link.getIntermediatePoints();
		var n = this._handle.getIndex();
		var point = intermediatePoints[n];
		link.setIntermediatePoints(intermediatePoints.slice(0,n).concat(intermediatePoints.slice(n+1)));
		if(link.getParent() && link.getParent().invalidate) link.getParent().invalidate();
		A.rebindAdorned();
		D.getUndoManager().addAction(this._createRemoveUndoAction(D,link,point,n));
	},
	
    _dragPreStart: function(e) {
		this._handle.interactionBegun(this);
		this._newPoint = null;
		this._newPoint = null;
		this.inherited(arguments);
	},
	
	_dragMove: function(e) {
    	this.inherited(arguments);
		
    	var A = this._handle.getAdorner();
		var V = A.getViewport();
		var D = V.getDiagram();
		var link = A.getAdorned();
		if(link){
			var point = V.eventContentLocation(e);
			var t = link.getShapeToContainerTransform(V._diagram.getGraph().getParent()).inverse();
			var pointT = t.transformPoint(point);
			var intermediatePoints = link.getIntermediatePoints();
			var oldPoint = intermediatePoints[this._handle.getIndex()];
			if(!this._oldPoint){
				this._oldPoint = lang.clone(oldPoint);
			}
			oldPoint.x = pointT.x;
			oldPoint.y = pointT.y;
			this._newPoint = lang.clone(pointT);
			link.setIntermediatePoints(intermediatePoints);
			if(link.getParent() && link.getParent().invalidate) link.getParent().invalidate();
		}
	},

	_dragEnd: function(e) {
		
		this.inherited(arguments);
		if(this._newPoint){
			var A = this._handle.getAdorner();
			var D = A.getDiagram();
			var link = A.getAdorned();
			var index = this._handle.getIndex();
			if(this._reachMinimunAngle(link,index)){
				D.getUndoManager().addAction(this._createModifyUndoAction(D,link,this._oldPoint,this._newPoint,index));
			}else{
				this._restoreOldPoint(link,index);
				this._deleteIntermediatePoint(e);
			}
		}
		this._handle.interactionEnded(this);

	},
	_reachMinimunAngle: function(link,index){
		var p1 = link._pathPoints[index];
		var p = link._pathPoints[index+1];
		var p2 = link._pathPoints[index+2];
		var v1 = g.subPoint(p1,p);
		var v2 = g.subPoint(p,p2);
		var angle = ClippingUtil.vectorsAngle(v1,v2);
		angle = angle*360/(Math.PI*2);
		return angle>this._minimumAngle;
	},
	_restoreOldPoint: function(link,index){
		var intermediatePoints = link.getIntermediatePoints();
		var point = intermediatePoints[index];
		point.x = this._oldPoint.x;
		point.y = this._oldPoint.y;
	},
	_createRemoveUndoAction: function(diagram,link,point,index){
		var action = new ChangeLinkIntermediatePointsAction(diagram, link);
		action.setRemovePointOperation(index,point);
		return action;
	},
	_createModifyUndoAction: function(diagram,link,oldPoint,newPoint,index){
		var action = new ChangeLinkIntermediatePointsAction(diagram, link);
		action.setModifyPointOperation(index,newPoint,oldPoint);
		return action;
	}
});

return LinkIntermediatePointsHandleInteractor;

});

},
'ibm_ilog/diagram/editor/adorners/LinkIntermediatePointsAddHandle':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/adorners/LinkIntermediatePointsAddHandle", [
"dojo/_base/declare",
"../../base",
"../../templating",
"../../adorners/HighlightedHandle",
"../interactors/AddIntermediatePointHandlerInteractor"
], function(
declare,
iid,
templating,
HighlightedHandle,
AddIntermediatePointHandlerInteractor
){

/*=====
var HighlightedHandle = ibm_ilog.diagram.adorners.HighlightedHandle;
=====*/

	var LinkIntermediatePointsAddHandle =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.LinkIntermediatePointsAddHandle',[HighlightedHandle],{
		// Summary:
		//		this class is the handle that manage the link intermediate points. 
		//		Contains the instance of LinkIntermediatePointsHandleInteractor that enables to remove and edit these points.
		
		//
		//	_location: handle position
		//
		_isAddHandle : true,
		_index: null,
		setUp: function(index) {
		// Summary:
		//		sets the handle Intermediate point index
			
			this._index = index;
			this.addInteractor(new AddIntermediatePointHandlerInteractor().initialize(this));
			return this;
		},
		getIndex: function(){
			// Summary:
			//		returns the index of the adorned link intermediate point
			return this._index;
		},
		changeBindings:function(intermediatePoints){
			// Summary:
			//		modify the handle internal bindings
			var p1 = intermediatePoints[this._index];
			var p2 = intermediatePoints[this._index+1];
			var point = {x: ((p2.x-p1.x)/2+p1.x), y:((p2.y-p1.y)/2+p1.y)};
			this.startDTLBatch();
			this.setAddPointPosX(point.x);
			this.setAddPointPosY(point.y);
			this.endDTLBatch();
		}
	}));

	LinkIntermediatePointsAddHandle.templateId = "LinkIntermediatePointsAddHandle";
	templating.declareBindableProperty(LinkIntermediatePointsAddHandle, "addPointPosX", -99999);
	templating.declareBindableProperty(LinkIntermediatePointsAddHandle, "addPointPosY", -99999);

	return LinkIntermediatePointsAddHandle;
	
});

},
'ibm_ilog/diagram/editor/EditingUtils':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/EditingUtils", [
"dojo/_base/lang",
"dojo/_base/array",
"dojox/gfx",
"dojox/gfx/utils",
"dojox/gfx/matrix",
"dojox/collections/ArrayList",
"dojox/collections/Set",
"../base",
"./undo/GroupAction",
"./undo/UngroupAction",
"./undo/SimpleAction",
"./undo/MultipleAction",
"./undo/DeleteAction",
"./undo/ReorderAction",
"./undo/UndoActionList",
"./undo/ChangeLinkIntermediatePointsAction",
"./undo/InvertLinkAction",
"./undo/DropAction",
"../util/ErrorReporter",
"../util/GraphUtil",
"../util/Geometry",
"../util/Batch"
], function(
lang,
array,
gfx,
gfxu,
m,
ArrayList,
Set,
iid,
GroupAction,
UngroupAction,
SimpleAction,
MultipleAction,
DeleteAction,
ReorderAction,
UndoActionList,
ChangeLinkIntermediatePointsAction,
InvertLinkAction,
DropAction,
R,
gu,
g,
Batch
){

	// TODO: Change to this when AMD conversion is complete:
	// var eu = {};
	var eu = lang.getObject("ibm_ilog.diagram.editor.EditingUtils", true);


	// Some actions need EditingUtils, but they cannot add it in their dependencies since EditingUtils depends on them.
	// To fix this, we store a refence to EditingUtils in these actions here, and the actions will use EditingUtils like this:
	//	XxxAction.EditingUtils.blaBla()
	
	DropAction.EditingUtils = eu;
	GroupAction.EditingUtils = eu;
	UngroupAction.EditingUtils = eu;
	ReorderAction.EditingUtils = eu;
	InvertLinkAction.EditingUtils = eu;

//////////////////////////////////////////////////////////////////////////////
//		Deletion utilities
eu.deleteGraphElements = function deleteGraphElements(/*ibm_ilog.diagram.widget.Diagram*/diagram,/*ibm_ilog.diagram.GraphElement[]*/elements, /*Function?*/doDeleteFunction) {
	// summary:
	//		deletes the elements from the diagram
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram from where to delete
	// elements: ibm_ilog.diagram.GraphElement[]
	//		the elements set to be deleted
	// doDeleteFunction: Function
	//		an optional Function to perform the deletion.
	// returns:
	//		The Action corresponding to the delete operation.
	
	doDeleteFunction = typeof(doDeleteFunction) == "function" ? doDeleteFunction : eu.doDeleteAction;
	var targetSet = eu.prepareDeletedSet(diagram, elements);
	return doDeleteFunction(diagram, targetSet); // ibm_ilog.diagram.editor.undo.Action
};

eu.prepareDeletedSet = function(/*ibm_ilog.diagram.widget.Diagram*/diagram, /*ibm_ilog.diagram.GraphElement[]*/elements){
	// summary:
	//		Computes the set of GraphElement to delete based on the specified elements list.
	// description:
	//		This method processes the specified elements array to ensures children (if any) and connected links are deleted too.  
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		The diagram instance to remove the shapes from.
	// elements: ibm_ilog.diagram.GraphElement[]
	//		the elements set to be deleted
	// returns:
	//		the list of GraphElement to delete.
	
	var allElements = {};
	eu.findElementsToDelete(diagram,elements,allElements);
	
	var list = [];
	
	for(var ids in allElements){
		list.push(allElements[ids]);
	}
	eu._changeFocused(diagram,allElements);

	var targetSet = gu.maximals(list);
	return targetSet; // ibm_ilog.diagram.GraphElement[]
};

eu.doDeleteAction = function(/*ibm_ilog.diagram.widget.Diagram*/diagram, /*ibm_ilog.diagram.GraphElement[]*/shapes){
	// summary:
	//		Deletes the specified shapes from the given diagram and returns a corresponding undo Action.
	// description:
	//		This implementation removes the specified shapes from the diagram graph and dispose them.
	//		Note that it does not handle any data store-related tasks.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		The diagram instance to remove the shapes from.
	// shapes: ibm_ilog.diagram.GraphElement[]
	//		An array of ibm_ilog.diagram.GraphElement to remove.
	// returns:
	//		The action to undo the delete operation.
	
	var action = eu.createDeleteUndoAction(diagram,shapes);
	
	array.forEach(shapes,function(graphElement){
		graphElement.getParent().remove(graphElement);
		graphElement.dispose();
	});
	
	return action; // ibm_ilog.diagram.editor.undo.DeleteAction
};

eu._changeFocused = function _changeFocused(diagram,allElements){
	// summary:
	//		Change the focused element to the first available top parent available (if the focused element is been removed).
	var current = diagram.getFocusedElement();
	if(current && (current.getId() in allElements)){
		var children = diagram.getGraph().children;
		for(var i = 0 ; i<children.length ; i++){
			var child = children[i];
			if(child._isIBMDiagramNode && !(child.getId() in allElements)){
				diagram.setFocusedElement(child);
				return;
			}
		}
	}
};

eu.findElementsToDelete = function findElementsToDelete(diagram,elements,result){
	// summary:
	//		iterate over the elements and add to the result all the children and the connected links.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram from where to delete
	// elements: array of ibm_ilog.diagram.GraphElement
	//		the elements set to be deleted
	// result: array of ibm_ilog.diagram.GraphElement
	//		the resulting array.
	for(key in elements){
		var e = elements[key];
		var ge = diagram.asGraphElement(e);
		if(ge) {
			result[ge.getId()] = ge;
			if(ge._isIBMDiagramNode){
				array.forEach(ge.getLinks(),function(link){
					result[link.getId()] = link;
				});
				if(ge._isIBMDiagramSubgraph){
					eu.findElementsToDelete(diagram,ge.getGraph().children,result);
				}
			}
		}
	}
};

//////////////////////////////////////////////////////////////////////////////
// Group/Ungroup utilities

eu.groupElements = function groupElements(diagram,elements,subgraphName) {
	// summary:
	//		Creates a new subgraph, and moves all the elements inside it. 
	//		This method return a JSObject with the created subgraph and the Undo Action: { subgraph:sg , action:action }
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram from where to group
	// elements: array of ibm_ilog.diagram.GraphElement
	//		the elements set to be group
	// subgraphName: String
	//		the new subgraph label
	// return: { subgraph: ibm_ilog.diagram.Subgraph , action: ibm_ilog.diagram.editor.undo.GroupAction }
	var lca = gu.lowestCommonAncestor.apply(this,elements);
	
	var sg = diagram.createSubgraph(null,null,lca);
	
	sg.setLabel(subgraphName);
	
	eu.groupReparent(diagram,elements,sg,lca);

	var action = eu.createGroupUndoAction(sg,elements);
	
	return { subgraph:sg, action:action };
};

eu.ungroupElements = function ungroupElements(diagram,subgraph) {
	// summary:
	//		Deletes the subgraph and moves all its children to its parent.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram from where to ungroup
	// subgraph: ibm_ilog.diagram.Subgraph
	//		the subgraph to be ungrouped
	
	var elements = [].concat(subgraph.getGraph().children);
	
	var sgTransform = m.clone(subgraph.getTransform());
	
	eu.groupReparent(diagram,elements,subgraph.getParent(),subgraph);
	
	var subgraphId = subgraph.getId();
	
	var deleteAction = eu.deleteGraphElements(diagram,[subgraph]);
	
	var action = eu.createUngroupUndoAction(diagram,subgraphId,elements,deleteAction,sgTransform);
	
	return { elements:elements, action:action };
};

eu.groupReparent = function groupReparent(diagram,elements,newParent,oldParent) {
	// summary:
	//		Change the parent of all the elements given by parameter.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram from where to reparent
	// elements: array of ibm_ilog.diagram.GraphElement
	//		the elements to be reparented.
	// newParent: ibm_ilog.diagram.Subgraph or ibm_ilog.diagram.Graph
	//		the new parent
	// oldParent: ibm_ilog.diagram.Subgraph or ibm_ilog.diagram.Graph
	//		the old parent
	var graph = newParent._isIBMDiagramSubgraph?newParent.getGraph():newParent;
	Batch.endBatch(); // make sure everything is up to date...
	if (iid.isVml) {
		// VML: try to find a way to avoid wrong layouts and IE crashes...
		// Defect #3988 (wrong layout) + also seems to fix #3392 partially (crashes less frequently)
		array.forEach(elements, function(ge){
			if(ge._isIBMDiagramLink) return; // links are reparented separately
			if (ge.suspendInvalidate) 
				ge.suspendInvalidate();
			
			var oldInAdd = iid._inContainerAdd;
			iid._inContainerAdd = true;
			
			var oldParent = ge.getParent();
			if (oldParent) {
				oldParent.remove(ge);
			}
			graph.rawNode.appendChild(ge.rawNode);
			gfx.shape.Container.add.call(graph, ge);
			
			gfxu.forEach(ge, function(s){
				if (s.suspendInvalidate) 
					s.suspendInvalidate();
				if (typeof(s.getFont) == 'function') { // text shapes need to be completely refreshed
					s.setShape(s.getShape());
					s.setFont(s.getFont());
				}
				if (typeof(s.setFill) == 'function') { // if setFill is available a setStroke should be safe to assume also
					s.setFill(s.getFill());
					s.setStroke(s.getStroke());
				}
				if (s.resumeInvalidate) 
					s.resumeInvalidate();
			});
			
			iid._inContainerAdd = oldInAdd;
			
			if (ge.resumeInvalidate) 
				ge.resumeInvalidate();
		});
	} else // normal case (not VML):
	array.forEach(elements, function(ge){
		if(ge._isIBMDiagramLink) return; // links are reparented separately
		graph.add(ge);
	});
	array.forEach(elements,function(ge) {
		if(ge._isIBMDiagramLink) return; // links are reparented separately
		var op = oldParent;
		if(!oldParent){
			op = ge.getParent();
			if(op && op.getParent()){
				op = op.getParent();
			}
		}
		eu.reparentTransform(diagram,ge,newParent,op);
	});
	
	_reparentLinks(elements);
};

var _reparentLinks = function(elements){
	// now reparent all links
	array.forEach(elements,function(ge) {
		if(ge._isIBMDiagramLink){
			_reparentLink(ge);
		} else if(ge._isIBMDiagramNode){
			array.forEach(ge.getLinks(), function(l){
				_reparentLink(l);
			});
			if (ge._isIBMDiagramSubgraph) {
				_reparentLinks(ge.getGraph().children);
			}
		}
	});
};

var _reparentLink = function(l){
	var start = l.getStartNode();
	var end = l.getEndNode();
	if (start && end) {
		var a = gu.lowestCommonAncestor(start, end);
		l.removeShape(); // always remove and add the link to pop it to the front
		a.add(l);
	}
};

eu.reparentTransform = function reparentTransform(diagram,element,newParent,oldParent) {
	// summary:
	//		Apply the transformation to reparent an element without noticeable transformation change.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram from where to reparent
	// element: ibm_ilog.diagram.GraphElement
	//		the element to be reparented.
	// newParent: ibm_ilog.diagram.Subgraph or ibm_ilog.diagram.Graph
	//		the new parent
	// oldParent: ibm_ilog.diagram.Subgraph or ibm_ilog.diagram.Graph
	//		the old parent (can be null)
	if(oldParent){
		var oldT = oldParent.getShapeToContainerTransform(diagram.getGraph().getParent());
		element.applyLeftTransform(oldT);
	}
	newParent = newParent || diagram.getGraph();
	var newT = newParent.getShapeToContainerTransform(diagram.getGraph().getParent()).inverse();
	element.applyLeftTransform(newT);

};

//////////////////////////////////////////////////////////////////////////////
// Alignment functions

eu.alignLeft = function alignLeft(diagram,elements,pivotElement) {
	// summary:
	//		Align the elements based on the pivotElement left side.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram where the elements are aligned.
	// elements: array of ibm_ilog.diagram.Node
	//		the target set to be aligned.
	// pivotElement: ibm_ilog.diagram.Node
	//		the element taken as pivot for alignment.
	return eu.alignWithPivot(diagram,elements,pivotElement,function(b){ return {x:b.x,y:0}; }); 
};
eu.alignRight = function alignRight(diagram,elements,pivotElement) {
	// summary:
	//		Align the elements based on the pivotElement right side.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram where the elements are aligned.
	// elements: array of ibm_ilog.diagram.Node
	//		the target set to be aligned.
	// pivotElement: ibm_ilog.diagram.Node
	//		the element taken as pivot for alignment.
	return eu.alignWithPivot(diagram,elements,pivotElement,function(b){ return {x:b.x+b.width,y:0}; }); 
};
eu.alignHCenter = function alignHCenter(diagram,elements,pivotElement) {
	// summary:
	//		Align the elements based on the pivotElement horizontal center.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram where the elements are aligned.
	// elements: array of ibm_ilog.diagram.Node
	//		the target set to be aligned.
	// pivotElement: ibm_ilog.diagram.Node
	//		the element taken as pivot for alignment.
	return eu.alignWithPivot(diagram,elements,pivotElement,function(b){ return {x:b.x+b.width/2,y:0}; }); 
};
eu.alignTop = function alignTop(diagram,elements,pivotElement) {
	// summary:
	//		Align the elements based on the pivotElement top side.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram where the elements are aligned.
	// elements: array of ibm_ilog.diagram.Node
	//		the target set to be aligned.
	// pivotElement: ibm_ilog.diagram.Node
	//		the element taken as pivot for alignment.
	return eu.alignWithPivot(diagram,elements,pivotElement,function(b){ return {x:0,y:b.y}; }); 
};
eu.alignBottom = function alignBottom(diagram,elements,pivotElement) {
	// summary:
	//		Align the elements based on the pivotElement bottom side.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram where the elements are aligned.
	// elements: array of ibm_ilog.diagram.Node
	//		the target set to be aligned.
	// pivotElement: ibm_ilog.diagram.Node
	//		the element taken as pivot for alignment.
	return eu.alignWithPivot(diagram,elements,pivotElement,function(b){ return {x:0,y:b.y+b.height}; }); 
};
eu.alignVCenter = function alignVCenter(diagram,elements,pivotElement) {
	// summary:
	//		Align the elements based on the pivotElement vertical center.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//	the diagram where the elements are aligned.
	// elements: array of ibm_ilog.diagram.Node
	//	the target set to be aligned.
	// pivotElement: ibm_ilog.diagram.Node
	//	the element taken as pivot for alignment.
	return eu.alignWithPivot(diagram,elements,pivotElement,function(b){ return {x:0,y:b.y+b.height/2}; }); 
};

eu.alignWithPivot = function alignWithPivot(diagram,elements,pivotElement,getBBPivot) {
	// summary:
	//		Align the elements based on the pivotElement and the getBBPivot function.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram where the elements are aligned.
	// elements: array of ibm_ilog.diagram.Node
	//		the target set to be aligned.
	// pivotElement: ibm_ilog.diagram.Node
	//		the element taken as pivot for alignment.
	// getBBPivot: Function
	//		this function determines the alignment position.	
	
	var V = diagram.getViewport();
	var graph = diagram.getGraph();
	var refbb = pivotElement.getBounds(graph);
	var refPivot = getBBPivot(refbb);
	
	var mAction = new MultipleAction(UndoActionList.Align);
	
	for(var i = 1; i<elements.length; i++) {
		var ge = elements[i];
		var oldTransform = m.clone(ge.getTransform());
		var gebb = ge.getBounds(graph);
		var delta = g.subPoint(refPivot,getBBPivot(gebb));
		ge.setTransform(m.multiply(ge.getTransform(),m.translate(delta)));
		mAction.addAction(eu.createMoveUndoAction(ge,oldTransform,ge.getTransform()));
	}
	return mAction;
};

//////////////////////////////////////////////////////////////////////////////
// Reorder z-order functions

eu.reorderedParents = function reorderedParents(graphElements) {
	// summary:
	//		given a list of GraphElements, return and array list with the parents of the elements, 
	//		and a dictionary of the elements, with the Id as keys.
	// graphElements: array of ibm_ilog.diagram.GraphElement
	//		the elements to be processed.
	// return: {parents:dojox.collections.ArrayList,ids:{}}
	var ids = {}; 
	var parents = new ArrayList();
	var union = Set.union;
	
	array.forEach(graphElements,function(e){
		ids[e.getId()]=e;
		parents = union(parents,[e.getParent()]);
	});
	
	return {parents:parents,ids:ids};
};

eu.reorderSelection = function reorderSelection(selectedElements,childrenReorderer) {
	// summary:
	//		get the selection, and iterates over the selection parents,
	//		calling the childrenReorderer function passed as parameter, 
	//		with each parent element and the list of selected elements ids.
	// selectedElements: array of ibm_ilog.diagram.GraphElement
	//		the elements to be arranged.
	// childrenReorderer: Function
	//		the function to be called with each selection parent.
	var o = eu.reorderedParents(selectedElements);
	var actions = []; 
	for(var i = 0; i<o.parents.count ; i++){
		var parent = o.parents.item(i);
		var action = new ReorderAction();
		action.setOldElementList(parent.children);
		childrenReorderer(parent,o.ids);
		action.setNewElementList(parent.children);
		actions.push(action);
	}
	if(actions.length==1){
		return actions[0];
	}else{
		var action = new MultipleAction(UndoActionList.Reorder);
		array.forEach(actions,function(a){action.addAction(a);});
		return action;
	}
};

eu.setChildrenOrder = function setChildrenOrder(order) {
	// summary:
	//		order the elements in the order parameter, as they are passed.
	//		This cause a reverse z-order (the last element is the Front one, and the other way about).
	// order: array of ibm_ilog.diagram.GraphElement
	//		the elements to be order
	array.forEach(order,function(e){
		e.moveToFront();
	});
};

eu.classifyList = function classifyList(childList,in_b,scope) {
	// summary:
	//		evaluates each element in the with the in_b function, 
	//		and add it to the a list if true, and to the b one if false.
	// childList: array of ibm_ilog.diagram.GraphElement
	//		the elements to be order
	// in_b: Function
	//		the function to evaluate.
	// scope: Scope
	//		the scope where to evaluate the in_b function.
	var a = [], b = [];
	array.forEach(childList,function(e){
		if(in_b(e)) {
			b.push(e);
		} else {
			a.push(e);
		}
	},scope);
	return {a:a,b:b};
};

eu.sendToBack = function sendToBack(selectedElements) {
	// summary:
	//		Send the selected elements to back .
	// selectedElements: array of ibm_ilog.diagram.GraphElement
	//		the elements to be arranged
	return eu.reorderSelection(selectedElements,function(parent,ids){
		var p = eu.classifyList(parent.children,function(e) {
			return e.getId() in ids;
		});
		eu.setChildrenOrder(p.b.concat(p.a));
	});
};

eu.bringToFront = function bringToFront(selectedElements) {
	// summary:
	//		Send the selected elements to the front.
	// selectedElements: array of ibm_ilog.diagram.GraphElement
	//		the elements to be arranged
	return eu.reorderSelection(selectedElements,function(parent,ids){
		var p = eu.classifyList(parent.children,function(e) {
			return e.getId() in ids;
		});
		eu.setChildrenOrder(p.a.concat(p.b));
	});
};

eu.sendBackward = function sendBackward(selectedElements) {
	// summary:
	//		Send the selected elements one position back.
	// selectedElements: array of ibm_ilog.diagram.GraphElement
	//		the elements to be arranged.
	return  eu.reorderSelection(selectedElements,function(parent,ids){
		var cs = parent.children;
		var yielded = null;
		var newOrder = [];
		var restore = function() {
			if(yielded) {
				newOrder.push(yielded);
				yielded = null;
			}
		};
		for( var i = 0; i< cs.length; i++) {
			var e = cs[i];
			if(!(e.getId() in ids)) {
				restore();
				yielded = e;
			} else {
				newOrder.push(e);
				restore();
			}
		};
		restore();
		eu.setChildrenOrder(newOrder);
	});
};

eu.bringForward =  function bringForward(selectedElements) {
	// summary:
	//		Send the selected elements one position front.
	// selectedElements: array of ibm_ilog.diagram.GraphElement
	//		the elements to be arranged.
	return eu.reorderSelection(selectedElements,function(parent,ids){
		var cs = parent.children;
		var pushed = [];
		var newOrder = [];
		for( var i = 0; i< cs.length; i++) {
			var e = cs[i];
			if(e.getId() in ids) {
				pushed.push(e);
			} else {
				newOrder.push(e);
				newOrder = newOrder.concat(pushed);
				pushed = [];
			}
		};
		newOrder = newOrder.concat(pushed);
		eu.setChildrenOrder(newOrder);
	});
};

//////////////////////////////////////////////////////////////////////////////
//   DROP FUNCTIONS

eu.startDropAction = function startDropAction(droppedItem,p,D,elements,dropAction){
	// summary:
	//		starts a drop action. 
	//		This method cam be called externally, from the DropInteractor or from an DropAction (redo).
	// droppedItem: ibm_ilog.diagram.GraphElement
	//		the item that has been dropped.
	// p: Point
	//		the dropping point.
	// elements: array of ibm_ilog.diagram.GraphElement
	//		the elements that have been detected behind the point
	// dropAction: ibm_ilog.diagram.editor.undo.UngroupAction
	//		the droped action involved in the operation
	var di = D.getDropInteractor();
	di.setDroppedItem(droppedItem);
	if (di._onDropFunction) {
        try{
        	di._onDropFunction.call(null,droppedItem,p,D,elements,dropAction);
        }catch(e){
        	R.error("DropUserFunctionError",e);
        }
	}
	if(!dropAction.isRedoing()){
		D.getUndoManager().addAction(dropAction);
	}
};

//////////////////////////////////////////////////////////////////////////////
//		Intermediate point operations

eu.addItermediatePoint = function AddItermediatePoint(D,link,point,index){
	// summary:
	//		adds a intermediate point to the given link, in the specified index.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram where the elements are deleted.
	// link: ibm_ilog.diagram.Link
	//		the link to be modified
	// point: point
	//		the point to be added
	// index: integer
	//		the position where to be added (between the intermediate points).
	
	var intermediatePoints = link.getIntermediatePoints();
	intermediatePoints = intermediatePoints.slice(0,index).concat([point]).concat(intermediatePoints.slice(index));
	link.setIntermediatePoints(intermediatePoints);
	D.getUndoManager().addAction(eu.createAddItermediatePointUndoAction(D,link,point,index)); 
};
////////////////////////////////////////////////////////////////////////////////
// INVERT LINKS

eu.invertLink = function invertLink(link){
	var startPort = link.getStartPort();
	var endPort = link.getEndPort();
	link.setStartPort(endPort);
	link.setEndPort(startPort);
	return this.createInvertLinkUndoAction(link);
};


//////////////////////////////////////////////////////////////////////////////
//		CREATION OF UNDO ACTIONS

eu.createInvertLinkUndoAction = function createInvertLinkUndoAction(link){
	var action = new InvertLinkAction();
	action.setModifiedElementId(link.getId());
	return action;
};

eu.createDeleteUndoAction = function createDeleteUndoAction(diagram,targetSet){
	// summary:
	//		creates the move undo action, based on the target.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram where the elements are deleted.
	// targetSet: array of ibm_ilog.diagram.GraphElement
	//		the target set to be deleted
	var action = new DeleteAction(diagram);
	action.setDeleted(targetSet);
	return action;
};

eu.createGroupUndoAction = function createGroupUndoAction(subgraph,elements){
	// summary:
	//		creates the group undo action.
	// subgraph: ibm_ilog.diagram.Subgraph
	//		the created subgraph, that groups the elements.
	// elements: array of ibm_ilog.diagram.GraphElement
	//		the elements that have been group.
	var action = new GroupAction();
	action.setElements(elements);
	action.setSubgraph(subgraph);
	return action;
};

eu.createUngroupUndoAction = function createUngroupUndoAction(diagram,subgraphId,elements,deleteAction,sgTransform){
	// summary: ibm_ilog.diagram.editor.undo.UngroupAction
	//		creates the ungroup undo action.
	// diagram: ibm_ilog.diagram.widget.Diagram
	//		the diagram where the elements are ungroup.
	// subgraph: String
	//		the deleted subgraph Id.
	// elements: array of ibm_ilog.diagram.GraphElement
	//		the elements that have been ungroup.
	// deleteAction: ibm_ilog.diagram.editor.undo.DeleteAction
	//		the created deleteAction, obtained when deleting the subgraph.
	var action = new UngroupAction();
	action.setElements(elements);
	action.setSubgraphId(subgraphId);
	action.setSubgraphTransform(sgTransform);
	action.setDeleteAction(deleteAction);
	return action;
};

eu.createMoveUndoAction = function createMoveUndoAction(target,oldTransformation, newTransformation){
	// summary:ibm_ilog.diagram.editor.undo.UngroupAction
	//		creates the move undo action, based on the target.
	// target: ibm_ilog.diagram.GraphElement
	//		the element that has been moved.
	// oldTransformation: dojox.gfx.matrix
	//		the old transformation matrix.
	// newTransformation: dojox.gfx.matrix
	//		the new transformation matrix.
	var cloneF = function(object){return m.clone(object);};
	
	var action = new SimpleAction(UndoActionList.Move);
	action.setOldValue(m.clone(oldTransformation));
	action.setNewValue(m.clone(newTransformation));
	action.setMethodOrProperty('setTransform');
	action.setModifiedElementId(target.getId());
	action.setCloneFunction(cloneF);
	return action;
};

eu.createOnDropAction = function createOnDropAction(D,droppedItem,p,elements){
	// summary:ibm_ilog.diagram.editor.undo.DropAction
	//		creates the drop undo action.
	// droppedItem: ibm_ilog.diagram.GraphElement
	//		the item that has been dropped.
	// p: Point
	//		the dropping point.
	// elements: array of ibm_ilog.diagram.GraphElement
	//		the elements that have been detected behind the point
	var newElements = [];
	array.forEach(elements, function(item){
		newElements.push(item.getId());
	});
	var action = new DropAction();
	action.setDroppedItem(droppedItem);
	action.setDroppedPosition(p);
	action.setElementsList(newElements);
	action.setDropInteractor(D.getDropInteractor());
	return action;
};

eu.createAddItermediatePointUndoAction = function createAddItermediatePointUndoAction(diagram,link,point,index){
	// summary:
	//		creates the undo action
	var action = new ChangeLinkIntermediatePointsAction(diagram, link);
	action.setAddPointOperation(index,point);
	return action;
};

return eu;

});

},
'dojo/dnd/Target':function(){
define("dojo/dnd/Target", [ "./Source" ], function(Source){
	/*===== Source = dojo.dnd.Source =====*/
	return dojo.declare("dojo.dnd.Target", Source, {
		// summary: a Target object, which can be used as a DnD target

		constructor: function(node, params){
			// summary:
			//		a constructor of the Target --- see the `dojo.dnd.Source.constructor` for details
			this.isSource = false;
			dojo.removeClass(this.node, "dojoDndSource");
		}
	});
});

},
'ibm_ilog/diagram/editor/adorners/ConnectionTargetHandle':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/adorners/ConnectionTargetHandle", [
"dojo/_base/declare",
"../../base",
"../../adorners/HighlightedHandle",
"../interactors/ConnectionTargetHandleInteractor"
], function(
declare,
iid,
HighlightedHandle,
ConnectionTargetHandleInteractor
){

/*=====
var HighlightedHandle = ibm_ilog.diagram.adorners.HighlightedHandle;
=====*/

	var ConnectionTargetHandle =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.ConnectionTargetHandle',[HighlightedHandle],{
		
		//
		//	_location: Point
		//
		location: null,
		connectionInteractor: null,
		setup: function(location) {
			this.location = location;
			this.addInteractor(new ConnectionTargetHandleInteractor().initialize(this));
			return this;
		},
		setConnectionInteractor: function(connectionInteractor){
			this.connectionInteractor = connectionInteractor;
		},	
		getConnectionInteractor:function(){
			return this.connectionInteractor;
		},
		getPortPosition:function(){
			return this.location;
		}
	}));
	
	ConnectionTargetHandle.templateId = "ConnectionTargetHandle";

	return ConnectionTargetHandle;
	
});

},
'ibm_ilog/diagram/editor/interactors/RotateHandleInteractor':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/interactors/RotateHandleInteractor", [
"dojo/_base/declare",
"dojox/gfx/matrix",
"../../interactors/DragInteractor",
"../../util/Geometry"
], function(
declare,
m,
DragInteractor,
g
){

/*=====
var DragInteractor = ibm_ilog.diagram.interactors.DragInteractor;
=====*/

var RotateHandleInteractor =
declare("ibm_ilog.diagram.editor.interactors.RotateHandleInteractor", [DragInteractor], {
	//
	//	summary:
	//		This is a sample interactor. It allows to rotate the entities much like 
	//		the resize adorner resizes them. It works if connected to the ResizeHandles like the
	//		ResizeHandleInteractor is connected.
	//	

	//	
	//	_handle: /*ibm_ilog.diagram.editor.adorners.ResizeHandle*/
	//	
	_handle: null,

	initialize: function ( /* ibm_ilog.diagram.editor.adorners.ResizeHandle */ handle) {
		this._handle = handle;
		this._viewport = handle.getViewport();
		this._initialize();
		return this;
	},

	_getInitialEventSource: function () {
		return this._handle;
	},

	activate: function () {
		var a = this._handle._adorner;
		if(a._adorned) {
			this._transform = a._adorned.getTransformToContainer(a._viewport.getSurface()).inverse();
		}
		this.inherited(arguments);
	},

	getDefaultConnections: function () {
		var map = this.inherited(arguments);
		map.start = {
			src: this._getInitialEventSource(),
			srcEvt: "onmousedown",
			connectTo: "_dragPreStart",
			filter: this._buildInputFilter({shift:true,button:0}),
			gfxConnect:true
		};
		return map;
	},

	_getPivot: function (ge) {
		return g.getRectCenter(ge.getBounds());
	},

	_getAngle: function (pivot, p) {
		return Math.atan2(p.x - pivot.x, p.y - pivot.y);
	},

	_dragMove: function () {
		this.inherited(arguments);

		var ge = this._handle._adorner._adorned;
		var p = this._getPivot(ge);
		var a2 = this._getAngle(this._current, p);
		var a1 = this._getAngle(this._last, p);
		ge.applyLeftTransform(m.rotateAt(a1 - a2, p));
	}

});

return RotateHandleInteractor;

});

},
'ibm_ilog/diagram/editor/adorners/ResizeAdorner':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/adorners/ResizeAdorner", [
"dojo/_base/declare",
"../../base",
"../../adorners/AdornerWithHandles",
"../adorners/ResizeHandle",
"../../util/Geometry"
], function(
declare,
iid,
AdornerWithHandles,
ResizeHandle,
g
){

/*=====
var AdornerWithHandles = ibm_ilog.diagram.adorners.AdornerWithHandles;
=====*/

	var Point = g.Point;

	var ResizeAdorner =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.ResizeAdorner', [AdornerWithHandles], {
	//
	//	summary:
	//		An adorner with handles to resize the adorned.
	//	description:
	//		This Adorner creates 4 ResizeHandles, one at each corner of the 
	//		adorned bouding box.
	//		Each ResizeHandle allows to grab that corner of the bounding box 
	//		and resize the adornee by moving that corner.
	//
	initialize: function () {
		this.inherited(arguments);

		this._createResizeHandle("hndTL", Point(0, 0));
		this._createResizeHandle("hndTR", Point(1, 0));
		this._createResizeHandle("hndBL", Point(0, 1));
		this._createResizeHandle("hndBR", Point(1, 1));
	},

	_createResizeHandle: function (attachPoint, p) {
		var h = this._createHandle(ResizeHandle, attachPoint);
		if (h) {
			h.setup(p);
		}
	}

}));

return ResizeAdorner;

});

},
'ibm_ilog/diagram/editor/DiagramSerializer':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/DiagramSerializer", [
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/config",
"dojo/_base/array",
"dojox/gfx",
"dojox/gfx/matrix",
"../util/GraphUtil",
"../util/Serializer",
"../util/ErrorReporter",
"./undo/MultipleAction",
"./undo/ConnectAction",
"./undo/PasteNodeAction"
], function(
declare,
lang,
config,
array,
gfx,
m,
gu,
Serializer,
R,
MultipleAction,
ConnectAction,
PasteNodeAction
){

var mixinAtts = function mixinAtts(target,src,these) {
//	var count = 0;
	for(var i = 0; i < these.length; i++ ) {
		if(src[these[i]] !== undefined) {

// debugging:
//			if(target[these[i]]) {
//				console.log("overriding ",these[i], ",",target[these[i]], ",",src[these[i]]);
//			} else {
//				console.log("adding     ",these[i], ",",target[these[i]], ",",src[these[i]]);
//			}

			target[these[i]] = src[these[i]];
			
//			count ++;
		}
	}
//	return count;
};

var serializeAtt = function serializeAtt(obj,t,name) {
	var v;
	if(obj["get"+name]){
		v = obj["get"+name]();
		if(v){ t[name] = v; }
	}
};

var deserializeAtt = function deserializeAtt(obj,t,name) {
	if(name in t) {
		obj["set"+name](t[name]);
	}
};	

serializeShapeStates = function serializeShapes ( shape ){
	
	var t = {}, v;
	
	if(shape._isIBMDiagramGraph) {
		return; // we skip the Graph object at subgraphs 
	}
	
	if(shape instanceof gfx.Group){
		t.children = array.map(shape.children, serializeShapeStates);
	}

	if(shape.getLayout) {
		v = shape.getLayout();
		if(v) {
			t.layout = v.getConfig();
		}
	}
	
	serializeAtt(shape,t,"ExplicitSize");

	mixinAtts(t,shape,["selectedStyle"]);
	mixinAtts(t,shape,["minimumSize","maximumSize", "valign", "halign", "col", "row","margins"]);

	return t;	// shape
};

function deserializeShapeStates(shape,t) {

	if(shape._isIBMDiagramGraph) {
		return;
	}

	if(shape instanceof gfx.Group){
		
		if(!t.children) {
			//console.log("not an array @ t:",shape,t);
		} else {
			if(shape.children.length != t.children.length) {
				//console.log("not of same length:",shape.children.length,t.children.length);
			} else {
				mixinAtts(shape,t,["selectedStyle"]);
				
				if(t.layout) {
					shape.setLayout(t.layout);
				}

				deserializeAtt(shape,t,"ExplicitSize");
				
				mixinAtts(shape,t,["minimumSize","maximumSize", "valign", "halign", "col", "row","margins"]);
			}
		}
		
		for(var i = 0; i< shape.children.length; i++) {
			deserializeShapeStates(shape.children[i],t.children[i]);
		}
	}
};

var DiagramSerializer =
declare("ibm_ilog.diagram.editor.DiagramSerializer",null,{
	_serializer: null,
	_notifiyingObject: null,
	_diagram: null,
	_transformFunction: null,
	
	constructor: function(diagram,transformFunction,notifiyingObject){
		this._notifiyingObject = notifiyingObject;
		this._diagram = diagram;
		this._transformFunction = transformFunction;
		this._initializeSerializer();
	}, 
	serialize: function(toSerialize){
		return this._serializer.serialize(toSerialize);
	},
	deserialize: function(serialized,container){
		return this._serializer.deserialize(serialized,container);
	},
	_initializeSerializer: function(){
		var thiz = this;
		this._serializer = new Serializer({
			getId: function(ge) {
				return ge.getId();
			},
			serializeNodeData: function(ge){
				var serializedData = {
					id:ge.getId(),
					label:ge.getLabel(),
					transform:m.clone(ge.getTransform()),
					uibb:ge.getBounds(this.getDiagram().getViewport().getSurface()),
					template:ge._template,
					shapesStates:serializeShapeStates(ge)
				};
				this.getNotifiyingObject().onSerialize(ge,serializedData);
				return serializedData;
			},
			deserializeNodeData: function(s,newByOldId,container){
			    var node = this.getDiagram().createNode(s.template,null,container.graph);
			    var t = this.getTransformFunction()(s.transform,container.graph,s);
			    node.setTransform(t);
			    node.setLabel(s.label);

			    deserializeShapeStates(node,s.shapesStates);
			    if (config.useGfxLayout) {
					node.invalidate();
				}
			    
			    var undoAction = this._createNodeUndoAction(s,node.getId(),t,container,false);
			    this.getNotifiyingObject().onDeserialize(s,node,container,undoAction);
			    container.undo.addAction(undoAction);
			    return {created:node};
			},
			serializeSubgraphData: function(ge){
				var serializedData = {
					id:ge.getId(),
					label:ge.getLabel(),
					collapsed:ge.isCollapsed(),
					clss:ge.constructor,
					transform:m.clone(ge.getTransform()),
					uibb:ge.getBounds(this.getDiagram().getViewport().getSurface()),
					template:ge._template,
					collapsedShapeStates:serializeShapeStates(ge._collapsedGroup),
					expandedShapeStates:serializeShapeStates(ge._expandedGroup)
				};
				this.getNotifiyingObject().onSerialize(ge,serializedData);
				return serializedData;
			},
			deserializeSubgraphData: function(s,newByOldId,container){
			    var sg = this.getDiagram().createSubgraph(s.template,null,container.graph,s.clss);
			    var t = this.getTransformFunction()(s.transform,container.graph,s);
			    sg.setLabel(s.label);

			    // TODO this is a hack to prevent current imposibility of creating subgraphs while collapsed
			    // assign position after deserializing
			    setTimeout(function(){
				    if(s.collapsed!=sg.isCollapsed()) {
				    	sg._setCollapsed(s.collapsed,false); // TODO allow animation control publicly at Subgraph
				    }
				    sg.setTransform(t);
			    },1);

			    // TODO hack: hide if we can
			    
			    // TODO fixed by gino commented and added sg.setTransform(t);
			    
			    /*if(!container.graph._owningSubgraph) {
			    	sg.setTransform(m.translate(ibm_ilog.diagram._invisibleLocation,ibm_ilog.diagram._invisibleLocation));
			    } else {
				    sg.setTransform(t);
			    }*/
			    //sg.setTransform(t);

				deserializeShapeStates(sg._collapsedGroup,s.collapsedShapeStates);
				deserializeShapeStates(sg._expandedGroup,s.expandedShapeStates);
				if (config.useGfxLayout) {
					sg.invalidate();
				}
			    var undoGroup = new MultipleAction();
			    var undoAction = this._createNodeUndoAction(s,sg.getId(),t,container,true);
			    this.getNotifiyingObject().onDeserialize(s,sg,container,undoAction);
			    undoGroup.addAction(undoAction);
			    container.undo.addAction(undoGroup);
			    return {created:sg,graph:sg.getGraph(),undo:undoGroup};
			},
			serializeLinkData: function(ge){
				var serializedData = {
					startId:ge.getStartNode().getId(),
					endId:ge.getEndNode().getId(),
					shapeType:ge.getShapeType(),
					transform:m.clone(ge.getTransform()),
					intermediatePoints:ge.getIntermediatePoints()
				};
				this.getNotifiyingObject().onSerialize(ge,serializedData);
				return serializedData;
			},
			deserializeLinkData: function(s,newByOldId,container){
				if(newByOldId.contains(s.startId) && newByOldId.contains(s.endId)) {
					var link = container.graph.createLink();
					var start = newByOldId.item(s.startId).created;
					var end = newByOldId.item(s.endId).created;
					link.setStartNode(start);
					link.setEndNode(end);
					link.setShapeType(s.shapeType);
					var points = lang.clone(s.intermediatePoints);
					if (points) {
					    var t = this.getTransformFunction()(s.transform,container.graph,null);
						for (var i = 0; i < points.length; i++) {
							points[i] = t.transformPoint(points[i]);
						}
					}
					link.setIntermediatePoints(points);
					this.getDiagram()._onLinkCreated(link,start,end,this.getDiagram());
					var undoAction = this._createLinkUndoAction(link,container);
					this.getNotifiyingObject().onDeserialize(s,link,container,undoAction);
					container.undo.addAction(undoAction);
					return {created:link};
				}
			},
			_createNodeUndoAction: function(s,newId,t,container,isSubgraph){
			    var action = new PasteNodeAction();
			    action.elementId = newId;
			    action.parentId = this.getDiagram().getUndoManager().getParentId(container.graph);
			    action.template = s.template;
			    action.transformation = m.clone(t);
			    action.label = s.label;
			    action.isSubgraph = isSubgraph;
			    action.collapsed = s.collapsed;
			    return action;
			},
			_createLinkUndoAction: function(link,container){
				var action = new ConnectAction(this.getDiagram(),link,container.graph);
				return action;
			},
			getDiagram: lang.hitch(thiz,function(){
				return this._diagram;
			}),
			getNotifiyingObject: lang.hitch(thiz,function(){
				if(this._notifiyingObject){
					return this._notifiyingObject;
				}else{
					//Dummy notifyingObject
					return {onSerialize:function(){},onDeserialize:function(){}};
				}
			}),
			getTransformFunction: lang.hitch(thiz,function(){
				
				if(this._transformFunction){
					return this._transformFunction;
				}else{
					return function(t){return t;};
				}
			})
		});
	}
});

return DiagramSerializer;

});

},
'ibm_ilog/diagram/editor/undo/GroupAction':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/undo/GroupAction", [
"dojo/_base/declare",
"./UserCustomizedAction",
"./UndoActionList"
], function(
declare,
UserCustomizedAction,
UndoActionList
){
	
/*=====
var UserCustomizedAction = ibm_ilog.diagram.editor.undo.UserCustomizedAction;
=====*/

	var GroupAction =
	declare("ibm_ilog.diagram.editor.undo.GroupAction", [UserCustomizedAction], {
		//	
		// summary:
		//		this action undo/redo any Group action.
		//		This action must be modified for the user if any user defined action is done on a Group action.
		//
		
	_elements: null,
	_subgraph: null,
	_subgraphName: null,
	constructor:function(){
		//	
		// summary:
		//		creates a new instance, setting the corresponding label
		this._label = UndoActionList.Group;
	},
	setElements: function(elements){
		//	
		// summary:
		//		sets the elements list to be group
		this._elements = [];
		dojo.forEach(elements,function(ge){this._elements.push(ge.getId());},this);
	},
	getElements: function(){
		//	
		// summary:
		//		gets the elements list to be group
		return this._elements;
	},
	setSubgraph: function(subgraph){
		//	
		// summary:
		//		sets the subgraph where to group
		this._subgraph = subgraph.getId();
	},
	getSubgraph: function(){
		//	
		// summary:
		//		gets the subgraph where to group
		return this._subgraph;
	},
	redoFunction: function(){
		var elements = this._getNewList();
		var D = this.getUndoManager().getDiagram();
		var result = GroupAction.EditingUtils.groupElements(D,elements,this._subgraphName);
		this.getUndoManager().registerGraphElementReplacement(this._subgraph,result.subgraph.getId());
		this._subgraph = result.subgraph.getId();
	},
	undoFunction: function(){
		var newElements = this._getNewList();
		var D = this.getUndoManager().getDiagram();
		var sg = this.getUndoManager().getRegisteredGraphElement(this._subgraph);
		GroupAction.EditingUtils.groupReparent(D,newElements,sg.getParent(),sg);
		this._subgraphName = sg.getLabel();
		sg.getParent().remove(sg); 
		sg.dispose();
	},
	_getNewList: function(){
		var newElements = [];
		var elements = this.getElements();
		dojo.forEach(elements, dojo.hitch(this, function(item){
			var newItem = this.getUndoManager().getRegisteredGraphElement(item);
			newElements.push(newItem);
		}));
		return newElements;
	}
	});
	
	return GroupAction;
	
});

},
'ibm_ilog/diagram/editor/undo/ReorderAction':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/undo/ReorderAction", [
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/array",
"./Action",
"./UndoActionList"
], function(
declare,
lang,
array,
Action,
UndoActionList
){

/*=====
var Action = ibm_ilog.diagram.editor.undo.Action;
=====*/

	var ReorderAction =
	declare("ibm_ilog.diagram.editor.undo.ReorderAction", [Action], {
		//
		//	summary:
		//		this action undo / redo a reordering action.
		_newElementList: null,
		_oldElementList: null,
	
	constructor:function(){
		//	
		// summary:
		//		creates a new instance, setting the corresponding label
		this._label = UndoActionList.Reorder;
		this.initialize(lang.hitch(this,this._undoFunction),lang.hitch(this,this._redoFunction));
	},
	setNewElementList: function(elementList){
		//	
		// summary:
		//		sets the new element list
		this._newElementList = [];
		array.forEach(elementList,function(ge){this._newElementList.push(ge.getId());},this);
	},
	setOldElementList: function(elementList){
		//	
		// summary:
		//		sets the old element list
		this._oldElementList = [];
		array.forEach(elementList,function(ge){this._oldElementList.push(ge.getId());},this);
	},
	_undoFunction: function(){
		var elements = this._getList(this._oldElementList);
		ReorderAction.EditingUtils.setChildrenOrder(elements);
	},
	_redoFunction: function(){
		var elements = this._getList(this._newElementList);
		ReorderAction.EditingUtils.setChildrenOrder(elements);
	},
	_getList: function(elements){
		var newElements = [];
		array.forEach(elements, lang.hitch(this, function(item){
			var newItem = this.getUndoManager().getRegisteredGraphElement(item);
			newElements.push(newItem);
		}));
		return newElements;
	}
	});
	
	return ReorderAction;
	
});

},
'ibm_ilog/diagram/layer_editing_dojo_requires':function(){
// wrapped by build app
define(["dijit","dojo","dojox"], function(dijit,dojo,dojox){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
dojo.provide('ibm_ilog.diagram.layer_editing_dojo_requires');

dojo["require"]('dojo.dnd.Source');
dojo["require"]('dojox.collections.Dictionary');
dojo["require"]('dojox.gfx.matrix');

});

},
'ibm_ilog/diagram/editor/adorners/ComponentAdorner':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/adorners/ComponentAdorner", [
"dojo/_base/declare",
"dojox/gfx/matrix",
"../../base",
"../../templating",
"../../adorners/Adorner",
"../../util/GraphUtil",
"../../util/Geometry"
], function(
declare,
m,
iid,
templating,
Adorner,
GraphUtil,
g
){

/*=====
var Adorner = ibm_ilog.diagram.adorners.Adorner;
=====*/

	var Rect = g.Rect;
	
	var __invisibleLocation = g.Rect(iid._invisibleLocation, iid._invisibleLocation, iid._invisibleSize, iid._invisibleSize);

	var ComponentAdorner =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.ComponentAdorner', [Adorner], {

	//	summary:
	//		An adorner for adorning components of Graph elements. 
	//
		
	//
	// _component: dojox.gfx.Shape
	//
	_component: null,
	
	//
	//	_componentBounds: dojox.gfx.Rect
	//
	_componentBounds: null,
	
	
	setComponent: function( /*Shape|string|null*/ component ) {
		//
		// 	summary:
		//		Sets the attachPoint name of visual shape associated with the property. 
		//		If null the whole element shape is asummed.
		//
		if(component && typeof(component) == "string") {
			this._component = this[component];
		} else {
			this._component = component;
		}
	},

	getComponent: function() {
		//
		//	summary:
		//		Returns the attachPoint name of the visual shape associated with the property. 
		//
		return this._component;
	},
	
	_computeElementBoundsChanged: function () {
		//
		//	summary:
		//		Recomputes the geometric values published to the template (adds 
		//		property component bounds to the values already computed in the 
		//		superclass)   
		//
	  var c,bb;
	  // compute component bounds	  
	  if(this._component && this._required() ) {
			c = this._component;
			  
			bb = c.getBoundingBox();
			if(bb) { // gfx does not support this properly, some renderers may fail. Fallback to node BB
				var pm = this._diagram.getGraph()._getRealMatrix().inverse();
				var cm = c.getParent()._getRealMatrix() || m.identity;
				var t = m.multiply(pm,cm);
				this._componentBounds = t.transformRectangle(bb);
		  } else {
		  	this._componentBounds = null;
		  }
	  } else {
	  	this._componentBounds = null;
	  }
	  this.inherited(arguments);
	},
	
	_updateLayout: function() {
		//
		//	summary:
		//		Publish new geometric values (causes template bindings to be applied if changed).
		//
		
		this.startDTLBatch();

		this.inherited(arguments);
		
		// also publish component-related coords (fallback to element coords if not present)
		
		var bb = __invisibleLocation;
		if (this._adorned) {
			bb = this._viewport.contentToClient().transformRectangle(this._componentBounds || this._elementBounds);
		}
		this.setCompWidth(bb.width);
		this.setCompHeight(bb.height);
		this.setCompRight(bb.x + bb.width);
		this.setCompBottom(bb.y + bb.height);
		this.setCompLeft(bb.x);
		this.setCompTop(bb.y);
		this.setCompCenterX(bb.width / 2);
		this.setCompCenterY(bb.height / 2);
		
		this.endDTLBatch();
	}
	
}));

templating.declareBindableProperty(ComponentAdorner, "compLeft", null);
templating.declareBindableProperty(ComponentAdorner, "compTop", null);
templating.declareBindableProperty(ComponentAdorner, "compBottom", null);
templating.declareBindableProperty(ComponentAdorner, "compRight", null);
templating.declareBindableProperty(ComponentAdorner, "compWidth", null);
templating.declareBindableProperty(ComponentAdorner, "compHeight", null);
templating.declareBindableProperty(ComponentAdorner, "compCenterX", null);
templating.declareBindableProperty(ComponentAdorner, "compCenterY", null);

return ComponentAdorner;

});

},
'ibm_ilog/diagram/editor/undo/UndoManager':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/undo/UndoManager", [
"dojo/_base/declare",
"dojo/_base/connect",
"dojox/collections/Dictionary",
"../../util/LimitedStack",
"../../util/GraphUtil"
], function(
declare,
connect,
Dictionary,
LimitedStack,
gu
){
	
	var UndoManager =
	declare("ibm_ilog.diagram.editor.undo.UndoManager", [], {
	//
	//	summary:
	//		this class is the central component of the Undo Management system.
	//	The undo management provides the user the ability to undo applied changes to the diagram, and after an undo operation, the redo of the undone
	//	action. This feature is available out of the box in the DiagramEditor, and support not only all standard changes that can be applied through 
	//  the DiagramEditor, but also any simple property change that the user could apply programmatically, with the corresponding undo object registration.
	//	More complex operation can also be supported by the Undo Management system, but the user would be responsible for the implementation of the custom undo action
	//
	_undoList:null,
	_redoList:null,
	_geList: null,
	_geReplacementList: null,
	_diagram: null,
	_maximumStackSize: null,
	
	constructor:function(diagram){
		//
		//	summary:
		//		creates a new instance of UndoManager
		//
		this._undoList = new LimitedStack();
		this._redoList = new LimitedStack();
		this._geReplacementList = new Dictionary();
		this._geList = new Dictionary();
		this._diagram = diagram;
		this._connectOnCreate();
	},
	
	_connectOnCreate: function(){
		connect.connect(this._diagram,'onNodeCreated',this,this._registerGraphElement);
		connect.connect(this._diagram,'onLinkCreated',this,this._registerGraphElement);
		connect.connect(this._diagram,'onSubgraphCreated',this,this._registerGraphElement);
		connect.connect(this._diagram,'beforeGraphElementDispose',this,function(ge){this._unregisterGraphElement(ge.getId());});
		
		//adds the top level graph
		// workaround to add id to topLevelGraph 
		var graph = this._diagram.getGraph();
		graph.getId = function(){return 'topLevelGraph';};
		this._registerGraphElement(graph,this._diagram);
	},
	
	_registerGraphElement: function(ge,diagram){
		//
		//	summary:
		//		register a new ge id
		var id = ge.getId();
		this._geList.add(id,ge);
	},
	
	_unregisterGraphElement: function(id){
		//
		//	summary:
		//		unregister a ge id
		this._geList.remove(id);
	},
	
	addAction:function(action){
		//
		//	summary:
		//		adds an action to the undo action stack (clearing the redo stack) 	
		this._undoList.push(action);
		this._redoList.clear();
		action.setUndoManager(this);
		this.onChange(action);
	},
	
	undoAction:function(){
		//
		//	summary:
		//		unstacks an action from the undo stack, apply the undo operation and stack it on the redo stack
		if(this._undoList.count > 0){
			var action = this._undoList.pop();
			action.undo();
			this._redoList.push(action);
			this.onChange(action);
		}
	},
	
	redoAction:function(){
		//
		//	summary:
		//		unstack an action from the redo stack, apply the redo operation and stack it on the undo stack
		if(this._redoList.count > 0){
			var action = this._redoList.pop();
			action.redo();
			this._undoList.push(action);
			this.onChange(action);
		}
		
	},
	
	getUndoStack:function(){
		//
		//	summary:
		//		returns a copy of the undo stack
		return this._undoList.clone();
	},
	
	getRedoStack:function(){
		//
		//	summary:
		//		returns a copy of the redo stack
		return this._redoList.clone();
	},

	getUndoStackCount:function(){
		//
		//	summary:
		//		returns the size of the undo stack
		return this._undoList.count;
	},
	
	getRedoStackCount:function(){
		//
		//	summary:
		//		returns the size of the redo stack
		return this._redoList.count;
	},

	onChange:function(action){
		//
		//	summary:
		//		this method is called when and undo or redo action is applied
	},
	
	getRegisteredGraphElement: function(id){
		//
		//	summary:
		//		gets the registered graph element corresponding to the given id, looking for the replacement if necessary
		if(!id){
			return null;
		}
		var replacementId = this.getRegisteredGraphElementReplacement(id);
		return this._geList.item(replacementId);
	},
	
	registerGraphElementReplacement: function(oldId,newId){
		//
		//	summary:
		//		register when a graph element id is replaced by another (when a ge is removed and by a undo/redo operation a replacement is created again, with a new Id)
		this._geReplacementList.add(oldId,newId);
	},
	
	getRegisteredGraphElementReplacement: function(id){
		//
		//	summary:
		//		gets the registered replacement for the given ge id. Look for it recursively so as to find the last replacement.
		//		if not replacement is registered the given ge id is returned.
		
		var newId = this._geReplacementList.item(id);
		if(newId && newId!=id){
			var otherId = this.getRegisteredGraphElementReplacement(newId);
			if(newId && otherId && newId!=otherId){
				newId = otherId;
				this._geReplacementList.add(id,newId);
			}
		}
		return newId?newId:id;
	},
	
	getRegisteredParent: function(id){
		//
		//	summary:
		//		return the graph parent for the given id.
		//		If the id correspond to a subgraph, the inner graph is returned.
		var parent = this.getRegisteredGraphElement(id);
		if(parent._isIBMDiagramSubgraph){
			return parent.getGraph();
		}
		return parent;
	},
	
	getParentId: function(parent){
		//
		//	summary:
		//		get the Parent id.
		//		If the given parent is a graph from a subgraph, return the subgraph id. 
		//		If the parent is the top level graph, the graph id is returned
		var sg = gu.getOwningSubgraph(parent);
		return sg?sg.getId():parent.getId();
	},
	
	setMaximumStackSize: function(stackSize){
		//
		//	summary:
		//		sets the maximum stack size
		this._maximumStackSize = stackSize;
		var notify = stackSize && (this._undoList.count>stackSize || this._undoList.count>stackSize);
		this._undoList.setMaxSize(stackSize);
		this._redoList.setMaxSize(stackSize);
		if(notify){
			this.onChange(null);
		}
	},
	
	getMaximumStackSize: function(){
		//
		//	summary:
		//		gets the maximum stack size
		return this._maximumStackSize;
	},
	
	getDiagram: function(){
		//
		//	summary:
		//		gets the used Diagram
		return this._diagram;
	},
	
	reset: function(){
		this._undoList.clear();
		this._redoList.clear();
		this._geReplacementList.clear();
		this._geList.clear();
		this.onChange(null);
	}
	});
	
	return UndoManager;
	
});

},
'ibm_ilog/diagram/editor/adorners/TextEditAdorner':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/adorners/TextEditAdorner", [
"dojo/_base/declare",
"dojo/_base/lang",
"dojo/_base/config",
"dojo/_base/event",
"dojo/keys",
"dojo/dom-style",
"dijit/focus",
"dijit/form/_TextBoxMixin",
"dojox/gfx",
"dojox/dtl",
"../../base",
"../../templating",
"../../gfxwidget/GfxWidget",
"./ComponentAdorner",
"../undo/SimpleAction",
"dojo/has!isBidiInDojoDiagrammer?../../util/BidiUtil:"
], function(
declare,
lang,
config,
event,
keys,
style,
focus,
textboxmix,
gfx,
dtl,
iid,
templating,
GfxWidget,
ComponentAdorner,
SimpleAction,
BidiUtil
){
	
/*=====
var ComponentAdorner = ibm_ilog.diagram.editor.adorners.ComponentAdorner;
=====*/

var TextEditAdorner = iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.TextEditAdorner', [ComponentAdorner], {

	//	summary:
	//		An adorner for editing string-valued properties of Graph elements. 
	//	description:
	//		TextEditAdorner is an adorner that displays a TextBox for editing a 
	//		property of a Graph element. The user must provide an attachPoint name for 
	//		the property which is used to calculate the position of the TextBox, and 
	//		also a getter and setter of the property at the Graph element.   
	//	usage:
	//		The following code starts editing the "label" attribute of "node", using 
	//		getLabel/setLabel as accessorsm and "textShape" as value representation for
	//		reference when positioning the TextBox
	//
	//		textEditAdorner.setAccessors(
	//			function(adorned){
	//				return adorned.getLabel();
	//			},
	//			function(adorned,value){
	//				adorned.setLabel(value);
	//			});
	//		textEditAdorner.setComponent("textShape");
	//		textEditAdorner.setAdorned(node);
	//
	
	//
	// _lastAdorned: GraphElement
	//
	_lastAdorned: null,

	//
	//	_textbox: dijit.form.TextBox
	//
	_textbox: null,
		
	//
	//	_gettter: accessor to get the value of the property from the graph element
	//
	_getter: null,
	
	//
	//	_settter: accessor to set the value of the property to the graph element
	//
	_setter: null,

	setComponentAttachPoint: function(a) {
		//
		//	summary:
		//		Sets the component original attachpoint		 
		//
		this._componentAttachPoint = a;
	},

	getComponentAttachPoint: function() {
		//
		//	summary:
		//		Returns the attachPoint name of the visual shape associated with the property. 
		//
		return this._componentAttachPoint;
	},

	initialize: function () {
		this.inherited(arguments);
		
		// get textbox from template attachPoint  

		// this.textbox is the GfxWidget declared at the template
		this._textbox = this.textbox._widget;
	},

	setAccessors: function(getter,setter) {
		//
		//	summary:
		//		Configure the receiver with the setter and getter functions for the property on the graph element. 
		//
		this._getter = getter;
		this._setter = setter;
	},

	_onBlur: function() {
		//
		//	summary:
		//		unlink the adorner when the textbox looses focus
		//
		this.setAdorned(null);
	},
	
	_getTextBoxValue: function(){
		var value = this._textbox.get("value");
		// prevent DTL from escaping HTML, even if the binding was not marked with |safe.
		value = dtl.mark_safe(value);
		return value;
	},
	
	_setTextBoxValue: function(value){
		this._textbox.set("value", value);
	},
	
	_onKey: function(e) {
		//
		//	summary:
		//		Handle special keys:
		//			Enter: accepts the value and sets it to the currently adorned graph element.
		//			Esc: cancels the operation and hides the adorner.
		//
		if(e.keyCode==keys.ENTER && !e.shiftKey) { // ENTER
			var value = this._getTextBoxValue();
			if(value!=this._getter(this._lastAdorned)) {
				var action = this._createUndoAction(this._lastAdorned,value);
				this._setter(this._lastAdorned,value);
				this._diagram.getUndoManager().addAction(action);
			}
			event.stop(e);
			this.setAdorned(null);
			focus.focus(this._diagram.domNode);
		} else if(e.keyCode==keys.ESCAPE) { // ESC
			event.stop(e);
			this.setAdorned(null);
			focus.focus(this._diagram.domNode);
		}
		else if (config.isBidiInDojoDiagrammer) { //Bidi support
		    var textdir = this._diagram.textDir;
		    if ((textdir === undefined) || (textdir === ""))
		        return;
		    if (textdir == "auto") {
		        var value = this._getTextBoxValue();
	            textdir = BidiUtil.checkDir(value);
		        if (textdir == "rtl")
		          this._textbox.set("dir", "rtl");				         
		        else 
		          this._textbox.set("dir", "ltr");
		   }
		}		
	},
	
	_onPaste: function() {
		//
		//	summary:
		//      resolve "auto" text direction for pasted text
		//		unlink the adorner when the textbox looses focus
		//

	    var textdir = this._diagram.textDir;
	    if ((textdir === undefined) || (textdir === ""))
	        return;
	    if (textdir == "auto") {
	        var value = this._getTextBoxValue();
	        textdir = BidiUtil.checkDir(value);
	        if (textdir == "rtl")
	           this._textbox.set("dir", "rtl");		         
	        else 
	           this._textbox.set("dir", "ltr");
	   }
	},
	
	_createUndoAction: function(adorned,value){
		//
		//	summary:
		//		Create an Undo object for the operation of changing the 
		//		associated property to "value" on "adorned"
		//
		var action = new SimpleAction('EditText');
		action.setOldValue(adorned.getLabel());
		action.setNewValue(value);
		action.setModifiedElementId(adorned.getId());
		action.setter = this._setter;
		action.changeFunction = lang.hitch(action,function(value){	
			var modifiedObject = this.getModifiedElement();
			this.setter(modifiedObject,value);
		});
		return action;
	},
	
	clear: function() {
		//
		//	summary:
		//		Clear the value of the TextBox
		//
		this._setTextBoxValue("");
	},
	
	reset: function() {
		//
		//	summary:
		//		Rest the value of the TextBox to the original value found at the adorned object
		//
		var value = this._getter(this._lastAdorned);
		
		//set text direction to TextBox
        if (config.isBidiInDojoDiagrammer) {
		    var textdir = this._diagram.textDir;
		    if (textdir == "auto")
		        textdir = BidiUtil.checkDir(value);
            if (textdir == "rtl")
		        this._textbox.set("dir", "rtl");
            else if (textdir == "ltr")
		        this._textbox.set("dir", "ltr");
		} 	
				
		this._setTextBoxValue(value);
	},
	
	setOptions: function(options) {
		// instantiation options
		// TODO check why this is not working.
		if(options.style) {
			style.set(this._textbox.focusNode,options.style);
		}
	},

	setAdorned: function(e) {
		//
		//	summary:
		//		Change the adorned object. This causes the TextBox to appear at the corresponding 
		//		location (based on the location of the graph element and the location of the 
		//		property shown inside the element). 
		//		If null, the TextBox is hidden and unbinded.
		//
		this._disconnect("blur");
		this._disconnect("key");
		if (config.isBidiInDojoDiagrammer)
		    this._disconnect("paste");				
		this.clear();
		this.inherited(arguments);
		if(e) {
			this._lastAdorned = e;
			this.reset();
			this._textbox.focus();
			textboxmix.selectInputText(this._textbox.focusNode);

			// If the textbox looses focus, cancel.
			this._connect("blur",this._textbox,"onBlur",this,"_onBlur");

			// Handle Enter and Esc keys
			this._connect("key",this._textbox,"onKeyPress",this,"_onKey");
			
			//for contextual text direction, text direction of editor depends on pasted text 
			if (config.isBidiInDojoDiagrammer)
			    this._connect("paste",this._textbox,"_onInput",this,"_onPaste");				
		} else {
			this._textbox.domNode.blur();
		}
	},
		
	_updateLayout: function() {
		//
		//	summary:
		//		Publish new geometric values (causes template bindings to be applied if changed).
		//
		
		this.startDTLBatch();

		this.inherited(arguments);
		
		if(this._componentAttachPoint && this._componentAttachPoint.getFont) {
			var z = gfx.normalizedLength(this._componentAttachPoint.getFont().size);
			this.setRefFontPxSize(z*this._component._getRealMatrix().yy);
		}

		this.endDTLBatch();
	}
	
}));

templating.declareBindableProperty(TextEditAdorner, "refFontPxSize", 10);

return TextEditAdorner;

});

},
'ibm_ilog/diagram/editor/interactors/ConnectionKeyInteractor':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/interactors/ConnectionKeyInteractor", [
"dojo/_base/declare",
"../../Link",
"../../interactors/Interactor",
"../undo/ConnectAction",
"../undo/MultipleAction",
"../undo/UndoActionList",
"../EditingUtils"
], function(
declare,
Link,
Interactor,
ConnectAction,
MultipleAction,
UndoActionList,
EditingUtils
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var ConnectionKeyInteractor =
declare("ConnectionKeyInteractor", [Interactor], {
	//summary:
	//		This interactor connects two or more Nodes through the keyboard interaction.
	//		This interactor has 1 connection: connect.
	
	_diagram: null,
	_linkShapeType: null,
	initialize: function (diagram) {
	// summary:
    //		initialize the new instance.
    // diagram: ibm_ilog.diagram.widget.Diagram
    //		the associated diagram.		
		this._diagram = diagram;
		return this._initialize();
		var linkStyle = this._viewport.getDiagram().linkStyle;
		this._linkShapeType = linkStyle?linkStyle.shapeType:Link.LinkShapeType.Straight;
	},
	setLinkShapeType: function(linkShapeType){
		// Summary:
		//		sets the link shape type
		this._linkShapeType = linkShapeType;
	},
	getKeyInteractorId: function(){
		// summary:
	    //		returns the Interactor Id
		return ConnectionKeyInteractor.KeyInteractorId;
	},
	getDefaultConnections: function () {
		// summary:
		//		returns the default event mapping
		
		return {
			connect: {
			hotKey: 74,/* j key */	
			connectTo: "connect",
			filter: this._buildInputFilter({ctrl:true,shift:false})
			}
		};
	},
	connect: function(e){
		// Summary:
		//		connects all the selected nodes in the order that they are selected.
		//		If there is a link in the selection or there is just one element selected, this function does nothing.
		var sel = this._diagram.getSelection().get();
		var linkSelection = false;
		var nodeSelection = false;
		var D = this._diagram;
		sel.forEach(function(elem){
			elem = D.asGraphElement(elem);
			if(elem._isIBMDiagramLink){
				linkSelection = true;
			}else{
				nodeSelection = true;
			}
		});
		if(linkSelection && nodeSelection){
			return false;
		}else{
			if(linkSelection){
				return this.invertLinks(sel);
			}else{if(nodeSelection){
				return this.connectNodes(sel);
			}}
		}
	},
	
	invertLinks: function(sel){
		if(sel.count < 1){
			return false;
		}
		var mAction = new MultipleAction(UndoActionList.InvertLink);
		for(var index = 0;index <sel.count;index++){
			var link = sel.item(index);
			var a = EditingUtils.invertLink(link);
			mAction.addAction(a);
		}
		var um = this._diagram.getUndoManager();
		um.addAction(mAction);
		
		return true;
	},
	connectNodes: function(sel){
		if(sel.count < 2){
			return false;
		}
		var mAction = new MultipleAction(UndoActionList.Connect);
		var links = [];
		var added = 0;
		for(var index = 1;index <sel.count;index++){
			var a = this._doConnect(sel.item(index-1),sel.item(index),links);
			if(a){
				mAction.addAction(a);
				added++;
			}
		}
		if(added>0){
			var um = this._diagram.getUndoManager();
			um.addAction(mAction);
			this._diagram.getSelection().add(links,true);
		}
		
		return true;
	},
	_doConnect: function(start,end,links) {
		//	summary:
		//			
		if(this._diagram.allowCreateLink(start,end)){
			var link = this._diagram.connectNodes(start,end);
			links.push(link);
			var parent = link.getParent();
			var undoAction = this._createConnectUndoAction(this._diagram,link,parent);
			this._diagram.onLinkUpdated(this._diagram,link,true,undoAction);
			return undoAction;
		}else{
			//TODO add onMessage call
			return null;
		}
	},
	_createConnectUndoAction: function(diagram,link,parent){
		var action = new ConnectAction(diagram,link,parent);
		return action;
	}
});

ConnectionKeyInteractor.KeyInteractorId = "Connect";

return ConnectionKeyInteractor;

});

},
'ibm_ilog/diagram/editor/adorners/LinkIntermediatePointsHandle':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/adorners/LinkIntermediatePointsHandle", [
"dojo/_base/declare",
"../../base",
"../../templating",
"../../adorners/HighlightedHandle",
"../interactors/LinkIntermediatePointsHandleInteractor"
], function(
declare,
iid,
templating,
HighlightedHandle,
LinkIntermediatePointsHandleInteractor
){
	
/*=====
var HighlightedHandle = ibm_ilog.diagram.adorners.HighlightedHandle;
=====*/

	var LinkIntermediatePointsHandle =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.LinkIntermediatePointsHandle',[HighlightedHandle],{
		// Summary:
		//		this class is the handle that manage the link intermediate points. 
		//		Contains the instance of LinkIntermediatePointsHandleInteractor that enables to remove and edit these points.
		
		//
		//	_location: handle position
		//
		_index: null,
		setUp: function(index) {
		// Summary:
		//		sets the handle Intermediate point index
			
			this._index = index;
			this.addInteractor(new LinkIntermediatePointsHandleInteractor().initialize(this));
			return this;
		},
		getIndex: function(){
			// Summary:
			//		returns the index of the adorned link intermediate point
			return this._index;
		},
		changeBindings:function(intermediatePoints){
			// Summary:
			//		modify the handle internal bindings
			var point = intermediatePoints[this._index];
			this.startDTLBatch();
			this.setIntPointPosX(point.x);
			this.setIntPointPosY(point.y);
			this.endDTLBatch();
		}
	}));

	LinkIntermediatePointsHandle.templateId = "LinkIntermediatePointsHandle";
	templating.declareBindableProperty(LinkIntermediatePointsHandle, "intPointPosX", -99999);
	templating.declareBindableProperty(LinkIntermediatePointsHandle, "intPointPosY", -99999);

	return LinkIntermediatePointsHandle;
	
});

},
'ibm_ilog/diagram/editor/adorners/ConnectionTargetAdorner':function(){
/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define("ibm_ilog/diagram/editor/adorners/ConnectionTargetAdorner", [
"dojo/_base/declare",
"../../base",
"../../adorners/AdornerWithHandles",
"../adorners/ConnectionTargetHandle",
"../../util/Geometry"
], function(
declare,
iid,
AdornerWithHandles,
ConnectionTargetHandle,
g
){
/*=====
var AdornerWithHandles = ibm_ilog.diagram.adorners.AdornerWithHandles;
=====*/

	var Point = g.Point;
	
	var ConnectionTargetAdorner =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.ConnectionTargetAdorner',[AdornerWithHandles],{

    	initialize: function() {
    		this.inherited(arguments);

    		this._createHandle(ConnectionTargetHandle,"hndT").setup(Point(0.5,0));
    		this._createHandle(ConnectionTargetHandle,"hndR").setup(Point(1,0.5));
    		this._createHandle(ConnectionTargetHandle,"hndB").setup(Point(0.5,1));
    		this._createHandle(ConnectionTargetHandle,"hndL").setup(Point(0,0.5));
    	},
    
    	setConnectionInteractor: function(connectionInteractor){
    		this["hndT"].setConnectionInteractor(connectionInteractor);
    		this["hndR"].setConnectionInteractor(connectionInteractor);
    		this["hndB"].setConnectionInteractor(connectionInteractor);
    		this["hndL"].setConnectionInteractor(connectionInteractor);
    	},
    	
    	activate: function() {
    		this._activateHandle("hndT");
    		this._activateHandle("hndR");
    		this._activateHandle("hndB");
    		this._activateHandle("hndL");
    	},
    	
    	deactivate: function() {
    		this._deactivateHandle("hndT");
    		this._deactivateHandle("hndR");
    		this._deactivateHandle("hndB");
    		this._deactivateHandle("hndL");
    	}

    }));

	return ConnectionTargetAdorner;
	
});

}}});

require(["dojo/i18n"], function(i18n){
i18n._preloadLocalizations("ibm_ilog/diagram/nls/ibm_diagram_editing", []);
});
define("ibm_ilog/diagram/ibm_diagram_editing", [], 1);
