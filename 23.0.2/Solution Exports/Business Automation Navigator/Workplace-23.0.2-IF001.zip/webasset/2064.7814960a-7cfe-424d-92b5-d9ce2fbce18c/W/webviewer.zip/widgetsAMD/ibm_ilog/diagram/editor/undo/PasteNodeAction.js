/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"./UserCustomizedAction",
"./UndoActionList"
], function(
declare,
lang,
UserCustomizedAction,
UndoActionList
){
	
/*=====
var UserCustomizedAction = ibm_ilog.diagram.editor.undo.UserCustomizedAction;
=====*/

var PasteNodeAction =
declare("ibm_ilog.diagram.editor.undo.PasteNodeAction", [UserCustomizedAction], {
	elementId: null,
	parentId: null,
	template: null,
	transformation: null,
	label: null,
	isSubgraph: null,
	collapsed:false,
	constructor:function(){
		this.setLabel(UndoActionList.Paste);
		this.initialize(lang.hitch(this,this._undoFunction),lang.hitch(this,this._redoFunction));
	},
	_undoFunction: function(){
		var ge = this.getUndoManager().getRegisteredGraphElement(this.elementId);
		ge.getParent().remove(ge);
		ge.dispose();
	},
	_redoFunction: function(){
		var container = this.getUndoManager().getRegisteredParent(this.parentId);
		var ge;
		if(this.isSubgraph){
			ge = this.getUndoManager().getDiagram().createSubgraph(this.template,null,container);
		    ge.setCollapsed(this.collapsed);
		}else{
			ge = this.getUndoManager().getDiagram().createNode(this.template,null,container);
		}
	    ge.setTransform(this.transformation);
	    ge.setLabel(this.label);
	    this.getUndoManager().registerGraphElementReplacement(this.elementId,ge.getId());
	}
});

return PasteNodeAction;

});
