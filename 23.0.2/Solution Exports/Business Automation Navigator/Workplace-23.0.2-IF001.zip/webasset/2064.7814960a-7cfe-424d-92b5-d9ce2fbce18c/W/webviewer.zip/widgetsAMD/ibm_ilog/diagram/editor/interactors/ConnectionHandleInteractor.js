/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"../../main",
"dojo/_base/declare",
"dojox/gfx",
"../../interactors/DragInteractor",
"../interactors/ConnectionTargetInteractor",
"../undo/ConnectAction",
"../../Port",
"../../Link",
"../../util/GraphUtil"
], function(
iid,
declare,
gfx,
DragInteractor,
ConnectionTargetInteractor,
ConnectAction,
Port,
Link,
gu
){

/*=====
var DragInteractor = ibm_ilog.diagram.interactors.DragInteractor;
=====*/

var ConnectionHandleInteractor =
declare("ibm_ilog.diagram.editor.interactors.ConnectionHandleInteractor", [DragInteractor], {

	//	_handle: /*ibm_ilog.diagram.editor.adorners.ConnectionHandle*/
	_handle:null,
	_link:null,
	_linkShapeType: Link.LinkShapeType.Straight,
	_automaticPortType: false,
	_allowFreeLinks: false,
	_target: null,
	_targetPosition: null,
	
	_targetInteractor: null,
	
	_declareStates: function() {
	// Summary:
	//		Add the crtl start to the original states
		this.inherited(arguments);	
		this._declareState("idle",["start","startCtrl"]);
	},
	
	getDefaultConnections:function(){
		//
		//	summary:
		//		returns the default event mapping
		//
    		var map = this.inherited(arguments);
    		map.startCtrl = {src:this._getInitialEventSource(),srcEvt:"onmousedown",connectTo:"_dragCrtlPreStart",filter:this._buildInputFilter({ctrl:true,button:0}), gfxConnect:true};
    		return map;
    },
	
	initialize: function( /* ibm_ilog.diagram.editor.ConnectionHandle */ connectionHandle ) {
		this._handle = connectionHandle;
		this._viewport = connectionHandle.getViewport();
		var linkStyle = this._viewport.getDiagram().linkStyle;
		this._linkShapeType = linkStyle?linkStyle.shapeType:Link.LinkShapeType.Straight;
		this._targetInteractor = new ConnectionTargetInteractor().initialize(this._handle._adorner._viewport._diagram,this);
		this._initialize();
		return this;
	},
	
	setTarget: function(target){
		// Summary:
		//		sets the target node that will be the end node of the new link.
		//		this function is called by the ConnectionTargetInteractor
		this._target = target;
	},
	
	setPortPosition: function(position){
		// Summary:
		//		sets the target port position that will be the end port position of the new link.
		//		this function is called by the ConnectionTargetHandleInteractor
		this._targetPosition = position;
	},
	
	setAllowFreeLinks: function(allowFreeLinks){
		// Summary:
		//		controls if the free links (links with no final nodes) are allowed
		this._allowFreeLinks = allowFreeLinks;
	},
	
	setLinkShapeType: function(linkShapeType){
		// Summary:
		//		sets the link shape type
		this._linkShapeType = linkShapeType;
	},
	
	_getInitialEventSource: function() {
		return this._handle;
	},
	
	_dragCrtlPreStart: function(e) {
		this._dragPreStart(e);
		this._automaticPortType = true;
	},
	
    _dragPreStart: function(e) {
		this._allowFreeLinks = this._viewport.getDiagram().getAllowFreeLinks();
		this._handle.interactionBegun(this);
		this._automaticPortType = false;
		this.inherited(arguments);
	},
	
	_dragMove: function(e) {
    	this.inherited(arguments);
		
    	var A = this._handle._adorner;
    	var V = A._viewport;
    	var D = V.getDiagram();
		if( this._link == null ){
			this._targetPosition = null;
			this._link = D.createTemplatedShape(Link, Link.defaultTemplate, D.getGraph());
			//this._link = D.createLinkShape(D.getGraph());
			var startPort = this._createPort(this._automaticPortType,this._handle.getPortPosition());
			var start = A._adorned;
			start.addPort(startPort);
			this._link.setStartPort(startPort);
			this._link.setShapeType(this._linkShapeType);
			this._targetInteractor.setUp(start,true,this._allowFreeLinks);
			this._targetInteractor.activate();
		}
		
		var point = V.eventContentLocation(e);
		var t = D.getGraph().getShapeToContainerTransform(D.getGraph().getParent()).inverse();
		point = t.transformPoint(point);
		this._link.setFallbackEndPoint(point);
		
		this._link.validateLinkShape();
	},

	_dragEnd: function(e) {
		this.inherited(arguments);
		var A = this._handle._adorner;
		var V = A._viewport;
		var D = V._diagram;
		
		if( this._link != null ){
			if(this._target){
				var endPort = this._createPort(false,this._targetPosition);
				var start = this._link.getStartNode();
				var end = this._target;
				if(D.allowCreateLink(start,end)){
					end.addPort(endPort);
					this._link.setEndPort(endPort);
					//reparent the link, with the lower common parent
					var cParent = gu.lowestCommonAncestor(start,end);
					if(cParent != this._link.getParent()){
						if(iid.isVml){
							// workaround for VML remove/add bug, occurs here since fixVmlAdd flag was added
							var oldParent = this._link.getParent();
							if(oldParent) { oldParent.remove(this._link); }
							cParent.rawNode.appendChild(this._link.rawNode);
							gfx.shape.Container.add.call(cParent, this._link);
							gfx.utils.forEach(this._link, function(s){
								if(s.setFill) s.setFill(s.getFill());
								if(s.setStroke) s.setStroke(s.getStroke());
							});
						} else {
							cParent.add(this._link);
						}
					}
					var undoAction = this._createUndoAction(D,this._link,cParent);
					D._onLinkCreated(this._link,start,end,D);
					D.onLinkUpdated(D,this._link,true,undoAction);
					if(D._isIBMDiagramEditor){
						D.getUndoManager().addAction(undoAction);
					}
					this._link.validateLinkShape();
				}else{
					D.getGraph().remove(this._link);
					this._link.dispose();
					//TODO add onMessage call
				}
			}else{
				if(!this._allowFreeLinks){
					D.getGraph().remove(this._link);
					this._link.dispose();
					//TODO add onMessage call
				}else{
					var undoAction = null;
					if(D._isIBMDiagramEditor){
						undoAction = this._createUndoAction(D,this._link,D.getGraph());
						D.getUndoManager().addAction(undoAction);
					}
					D.onLinkCreated(this._link,this._link.getStartNode(),null,D);
					D.onLinkUpdated(D,this._link,true,undoAction);
				}
			}
			
			this._link =null;
			this._targetInteractor.deactivate();
		}
		this._handle.interactionEnded(this);
	},
	
	_createPort: function(automaticPortType,position){
		var port;
		if(automaticPortType || !position){
			port = new Port.AutomaticPort();
		}else{
			port = new Port.BasicPort();
			port.setPosition(position);
		}
		return port;
	},
	_createUndoAction: function(diagram,link,parent){
		var action = new ConnectAction(diagram,link,parent);
		return action;
	}
});

return ConnectionHandleInteractor;

});