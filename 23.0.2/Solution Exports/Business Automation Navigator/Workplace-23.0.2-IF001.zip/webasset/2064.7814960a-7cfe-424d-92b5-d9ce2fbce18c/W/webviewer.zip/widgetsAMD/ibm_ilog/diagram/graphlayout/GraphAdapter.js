/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojox/gfx/matrix",
"ibm_ilog/graphlayout/AbstractGraphLayoutModel",
"ibm_ilog/graphlayout/internalutil/GraphModelUtil",
"ibm_ilog/graphlayout/internalutil/HashTable",
"../Port",
"../Link",
"../util/Batch"
],
function(
declare,
matrix,
AbstractGraphLayoutModel,
GraphModelUtil,
HashTable,
port,
Link,
Batch
){

var ReshapeLinkStyle = GraphModelUtil.ReshapeLinkStyle;
var ReshapeLinkMode = GraphModelUtil.ReshapeLinkMode;
var BasicPort = port.BasicPort;

/*=====
var AbstractGraphLayoutModel = ibm_ilog.graphlayout.AbstractGraphLayoutModel;
=====*/

var GraphAdapter =
declare("ibm_ilog.diagram.graphlayout.GraphAdapter", AbstractGraphLayoutModel, {
	// summary:
	//		The implementation of the graph model interface to layout the contents of a Graph.
	
	_graph: null,
	
	_global: null, // work in global surface coordinates
	
	getGraph: function(){
		return this._graph;
	},
	
	constructor: function(graph, layout) {
		this._graph = graph;
		this._originatingLayout = layout;
	},

	/* old implementation (no swim lanes)...
	_filter: function(f)
	{
        var children = this._graph.children;
        var list = dojoilter(children, f, this);
        return list;
	},
	
	_isGraphChild: function(obj) {
		return obj.getParent() == this._graph;
	},
	*/
	
	// new implementation: swim lanes are "flattened"
	_filterChildren: function(f)
	{
		return this._filterChildrenImpl(this._graph.children, f, []);
	},
	
	_filterChildrenImpl: function(children, f, list)
	{
        var n = children.length;
        for(var i = 0; i < n; i++){
        	var child = children[i];
        	if(child._flattenForGL && !child._collapsed){
        		this._filterChildrenImpl(child._graph.children, f, list);
        	} else {
        		if(f.call(this, child))
        			list.push(child);
        	}
        }
        return list;
	},
	
	_isGraphChild: function(obj) {
		var parent = obj.getParent();
		while(parent && parent._flattenForGL){
			var subgraph = parent._owningSubgraph;
			if(subgraph)
				parent = subgraph.getParent();
			else
				break;
		}
		return parent == this._graph;
	},

    isNode: function(o) {
		return o._isIBMDiagramNode && !(o._flattenForGL && !o._collapsed) && this._isGraphChild(o);
	},
	
	_isNodeOrLink: function(o) { 
		return this.isNode(o) || this._isLink(o);		
	},
	
    getNodes: function() {
    	return this._filterChildren(this.isNode);
	},
	
    isLink: function(o) {
		if (o._isIBMDiagramLink && this._isGraphChild(o)) {
			var start = this._getVisibleStartNode(o);
			if (!start) 
				return false;
			var end = this._getVisibleEndNode(o);
			if (!end) 
				return false;
			return this._isGraphChild(start) && this._isGraphChild(end)
		}
		return false;
	},
	
    getLinks: function() { 
    	return this._filterChildren(this.isLink);
	},

    isIntergraphLink: function(o) { 
		if (o._isIBMDiagramLink && this._isGraphChild(o)) {
			var start = this._getVisibleStartNode(o);
			if (!start) 
				return false;
			var end = this._getVisibleEndNode(o);
			if (!end) 
				return false;
			return !this._isGraphChild(start) || !this._isGraphChild(end);
		}
		return false;
	},
	
    getIntergraphLinks: function() { 
    	return this._filterChildren(this.isIntergraphLink);
	},
	
    isSubgraph: function(o) { 
		return o._isIBMDiagramSubgraph && !(o._flattenForGL && !o._collapsed) && this._isGraphChild(o);
	},
	
    getSubgraphs: function(){
    	return this._filterChildren(this.isSubgraph);
	},
	
    getLinksFrom: function(node) { 
		var linksFrom = node.getLinks(true, false); 
		return dojo.filter(linksFrom, this.isLink, this)
	},
	
    getLinksTo: function(node) { 
		var linksTo = node.getLinks(false, true);
		return dojo.filter(linksTo, this.isLink, this)
	},
	
    getFrom: function(link) { return this._getVisibleStartNode(link); },
    getTo: function(link) { return this._getVisibleEndNode(link); },
	
	_getVisibleStartNode: function(link)
	{
		// summary:
		//		Gets the visible start node of a link, taking into account collapsed subgraphs.
		// tags:
		//		private
		var port = link._startPort;
		if (link._isIntergraphLinkAtStart)
			port = link._getVisiblePort(port);
		if(port)
			return port._owner;
		return null;
	},
	
	_getVisibleEndNode: function(link)
	{
		// summary:
		//		Gets the visible end node of a link, taking into account collapsed subgraphs.
		// tags:
		//		private
		var port = link._endPort;
		if (link._isIntergraphLinkAtEnd)
			port = link._getVisiblePort(port);
		if(port)
			return port._owner;
		return null;
	},
	
	getNodesAndAllLinks : function() {
		// summary:
		//		Gets the nodes, the links and the intergraph links contained in the graph associated with this graph model.
		// description:
		//		Gets the nodes, the links and the intergraph links contained in the graph associated with this graph model.
		//		This method is used only in the ibm_ilog.diagram.graphlayout.ServerSideLayout class, it is not part of the
		//		base graph model interface.
    	return this._filterChildren(this._isNodeOrLink);
	},
	
	getAllLinks : function() {
		// summary:
		//		Gets all the links and intergraph links contained in the graph associated with this graph model.
		// description:
		//		Gets all the links and intergraph links contained in the graph associated with this graph model.
		//		This method is used only in the ibm_ilog.diagram.graphlayout.Animation class, it is not part of the
		//		base graph model interface.
    	return this._filterChildren(this._isLink);
	},
	
    _isLink: function(o) { 
		return o._isIBMDiagramLink && this._isGraphChild(o) && 
			this._getVisibleStartNode(o) && this._getVisibleEndNode(o);
	},
	
    boundingBox: function(nodeOrLink){
		var rect;
		if (nodeOrLink._isIBMDiagramNode) {
			rect = nodeOrLink.getBounds(this._graph);
		}
		else {
			rect = nodeOrLink.getLocalBoundingBox();
			if (this._graph != nodeOrLink.getParent()) {
				var t = nodeOrLink.getTransformToContainer(this._graph);
				rect = t.transformRectangle(rect);
			}
		}
		if(this._global){
			var p1 = {x:rect.x, y:rect.y};
			var p2 = {x:rect.x+rect.width, y:rect.y+rect.height};
			p1 = this._localToGlobal(p1);
			p2 = this._localToGlobal(p2);
			rect.x = p1.x; rect.y = p1.y;
			rect.width = p2.x - p1.x;
			rect.height = p2.y - p1.y;
		}
		return rect;
	},
	
    moveNode: function(node, x, y) {
		if(this._global){
			var p = {x:x, y:y};
			p = this._globalToLocal(p);
			x = p.x; y = p.y;
		}
		node.move(x, y, this._graph); 
	},
	
    getLinkPoints: function(link) {
		var points = link.getPoints();
		if(this._global){
			for(var i = 0; i < points.length; i++)
				points[i] = this._localToGlobal(points[i]);
		} else if(link.getParent() != this._graph){
			var t = link.getShapeToContainerTransform(this._graph);
			for(var i = 0; i < points.length; i++)
				points[i] = t.transformPoint(points[i]);
		}
		return points;
	},
	
	getLinkPointAt: function(link, index) {
		// Faster than the default implementation in AbstractGraphLayoutModel.
		// Could be even faster if we'd want to provide Link.getPointAt.
		var points = link.getPoints();
		var point = points[index];
		if(this._global){
			 point = this._localToGlobal(point);
		} else if(link.getParent() != this._graph){
			var t = link.getShapeToContainerTransform(this._graph);
			point = t.transformPoint(point);
		}
		return point;
	},
	
    reshapeLink: function(link, style, fromPoint, fromPointMode, points, startIndex, length, toPoint, toPointMode){
		
		link.setTransform(null); // in case link was translated...
		
		if(this._global){
			if(fromPoint)
				fromPoint = this._globalToLocal(fromPoint);
			if(toPoint)
				toPoint = this._globalToLocal(toPoint);
			if(points){
				for(var i = 0; i < length; i++){
					points[startIndex+i] = this._globalToLocal(points[startIndex+i]);
				}
			}
		} else if(link.getParent() != this._graph){
			var t = link.getShapeToContainerTransform(this._graph);
			t = t.inverse();
			if(fromPoint)
				fromPoint = t.transformPoint(fromPoint);
			if(toPoint)
				toPoint = t.transformPoint(toPoint);
			if(points){
				for(var i = 0; i < length; i++){
					points[startIndex+i] = t.transformPoint(points[startIndex+i]);
				}
			}
		}
		
		// set link style:
		switch (style) {
			case ReshapeLinkStyle.IGNORE:
				break;
			case ReshapeLinkStyle.STRAIGHT:
				link.setShapeType(Link.LinkShapeType.Straight);
				break;
            case ReshapeLinkStyle.DIRECT:
                link.setShapeType(Link.LinkShapeType.Free);
                break;
			case ReshapeLinkStyle.ORTHOGONAL:
				link.setShapeType(length > 0 ? Link.LinkShapeType.OrthogonalEditable :
											   Link.LinkShapeType.Straight);
				break;
			case ReshapeLinkStyle.POLYLINE:
				link.setShapeType(Link.LinkShapeType.Free);
				break;
		}
		
		var parent = link.getParent();
		
		// start point:
		switch(fromPointMode){
			case ReshapeLinkMode.IGNORE:
			case ReshapeLinkMode.FIX:
				break;
			case ReshapeLinkMode.MOVE:
			 	this._movePort(link, true, fromPoint, false, parent);
			 	break;
			case ReshapeLinkMode.CLIP:
			 	this._movePort(link, true, null, true, parent);
			 	break;
			case ReshapeLinkMode.MOVE_AND_CLIP:
			 	this._movePort(link, true, fromPoint, true, parent);
			 	break;
		}
		
		// end point:
		switch(toPointMode){
			case ReshapeLinkMode.IGNORE:
			case ReshapeLinkMode.FIX:
				break;
			case ReshapeLinkMode.MOVE:
			 	this._movePort(link, false, toPoint, false, parent);
			 	break;
			case ReshapeLinkMode.CLIP:
			 	this._movePort(link, false, null, true, parent);
			 	break;
			case ReshapeLinkMode.MOVE_AND_CLIP:
			 	this._movePort(link, false, toPoint, true, parent);
			 	break;
		}
		
		// intermediate points:
		
		if(length > 0){
			if(startIndex != 0 || length != points.length)
				points = points.slice(startIndex, length - startIndex);
		} else {
			points = null;
		}
		link.setIntermediatePoints(points);
	},
	
	_movePort : function(link, start, point, clip, parent) {
		var port = start ? link.getStartPort() : link.getEndPort();
		// special case for intergraph links and collapsed subgraphs:
		var collapsed = false;
		if ((start && link._isIntergraphLinkAtStart) ||
		(!start && link._isIntergraphLinkAtEnd)) {
			var collapsedPort = link._getVisiblePort(port);
			if (collapsedPort != port) {
				// the link is an intergraph link,
				// and its start/end node is in a collapsed subgraph:
				// use the collapsed port instead.
				collapsed = true;
				port = collapsedPort;
			}
		}
		var node = port.getOwner();
		
		// can we reuse the same port?
		// AV: instead of checking that the port is our BasicPort, we could
		// check model.hasMoveableConnectionPoint. This would allow people 
		// to create their own movable ports as direct subclasses of PortBase,
		// while overriding accordingly the default implementation of
		// model.hasMoveableConnectionPoint. However, this use-case is unlikely
		// (people can always subclass BasicPort), and the current implementation
		// is faster (avoids to retrieve again the port). So let's stay with it. 
		if(!port._isIBMDiagramBasicPort || port.getLinksCount() > 1){
			// no, create a new one.
			port = new BasicPort();
			node.addPort(port);
			// special case for intergraph links and collapsed subgraphs:
			if (collapsed) {
				// the link is an intergraph link,
				// and its start/end node is in a collapsed subgraph:
				// we must not replace the actual start/end port of the link,
				// instead, we change the getCollapsedPort function of the subgraph
				// so that it will return the new BasicPort for this link.
				if (!node._collapsedPorts) {
					// first time we do this for this subgraph: initialize the hash table
					// and replace the function
					node._collapsedPorts = new HashTable();
					node.getCollapsedPort = function(link, port){
						return this._collapsedPorts.item(link);
					};
				}
				// remember to return the new BasicPort for this link.
				node._collapsedPorts.add(link, port);
			}
			else {
				if (start) 
					link.setStartPort(port);
				else 
					link.setEndPort(port);
			}
		}
		
		if (point) {
			var bounds = port.getConnectionBounds(parent);
			port.setPosition({
				x: (point.x - bounds.x) / bounds.width,
				y: (point.y - bounds.y) / bounds.height
			});
		}
		else {
			port.setPosition({
				x: 0.5,
				y: 0.5
			});
		}
		
		port.setOffset({x:0, y:0});
		port.setClipOnShape(clip);
	},
	
    hasMoveableConnectionPoint: function(link, origin) {
		var port = origin ? link._startPort : link._endPort;
		if (origin ? link._isIntergraphLinkAtStart : link._isIntergraphLinkAtEnd) {
			port = link._getVisiblePort(port);
		}
		// AVA: In case there wouldn't be a guarantee that in any situation
		// link._startPort / _getVisiblePort do return a (non-null) port, we would need 
		// to modify GraphAdapter such that it creates the port on the fly if necessary. 
		// But apparently there is always a port.
		return !port ||
		  // Testing _isIBMDiagramBasicPort just as GraphAdapter._movePort. Needed 
		  // because port.setPosition/isMovable are both defined on 
		  // BasicPort, not on its parent portBase.  
		  (port._isIBMDiagramBasicPort && port.isMovable());
	},
	
    hasPinnedConnectionPoint: function(link, origin) { 
		// Note that hasPinned =! !hasMoveable.
		// Whenever the port is *not* a BasicPort, GraphAdapter replaces it with a BasicPort.
		// So it considers it as movable. 
		// We identify user's intention to "pin" a port when the port is
		// a BasicPort with port.movable == false.
		
		var port = origin ? link._startPort : link._endPort;
		if (origin ? link._isIntergraphLinkAtStart : link._isIntergraphLinkAtEnd) {
			port = link._getVisiblePort(port);
		}
		// AVA: In case there wouldn't be a guarantee that in any situation
		// link._startPort / _getVisiblePort do return a (non-null) port, we would need 
		// to modify GraphAdapter such that it creates the port on the fly if necessary. 
		// But apparently there is always a port.
		return port &&
		  // Testing _isIBMDiagramBasicPort just as GraphAdapter._movePort. Needed 
		  // because port.setPosition/isMovable are both defined on 
		  // BasicPort, not on its parent portBase.  
		  port._isIBMDiagramBasicPort && !port.isMovable();
	},
	
    getLinkWidth: function(link) { return link.getStrokeWidth(); },
	
    createGraphModel: function(subgraph) { 
		var submodel = new GraphAdapter(subgraph.getGraph());
		//submodel.setRootModel(this.getRoot() || this);
		return submodel;
	},
	
	getParent: function() {
		var root = this.getRoot();
		if(root == null || root == this)
			return null;
		if (this._graph._owningSubgraph) {
			var parentGraph = this._graph._owningSubgraph.getParent();
			if(parentGraph == root._graph)
				return root;
			var parentSubgraph = parentGraph._owningSubgraph;
			if (parentSubgraph) 
				return root.getGraphModel(parentSubgraph);
			else 
				return root;
		}
		return null;
	},
	
    setOriginatingLayout: function(layout) {
        this._originaringLayout = layout;
    },
    getOriginatingLayout: function() {
        return this._originaringLayout;
    },
	
	afterLayout: function()
	{
		// Make sure subgraphs have their final size at the end of the layout,
		// for recursive layout. TODO: check if we can do better...
		if (this._graph._owningSubgraph) {
			Batch.endBatch();
            // do not call _doLayout explicitly as the layout is now handled
            // by the gfxlayout if it applies.
            if (dojo.config.useGfxLayout && this._graph._owningSubgraph.getLayout())
                return;
            this._graph._owningSubgraph._graphChanged();
		}
	},
	
	_localToGlobal : function(p)
	{
		var m = this._graph._getRealMatrix();
		if (m) {
			var m2 = this._global._getRealMatrix();
			m2 = matrix.invert(m2);
			m = matrix.multiply(m2, m);
			p = matrix.multiplyPoint(m, p);
		}
		return p;
	},
	
	_globalToLocal : function(p)
	{
		var m = this._graph._getRealMatrix();
		if (m) {
			var m2 = this._global._getRealMatrix();
			m = matrix.invert(m);
			m = matrix.multiply(m, m2);
			p = matrix.multiplyPoint(m, p);
		}
		return p;
	},
	
	saveAndEnableViewCoordinates: function(rootModel)
	{
		this._oldGlobal = this._global;
		this._global = rootModel._graph;
	},
	
	restoreAndDisableViewCoordinates: function()
	{
		this._global = this._oldGlobal;
	},
	
	getTransform: function(subModel)
	{
		return subModel._graph.getShapeToContainerTransform(this._graph);
	}	
});

return GraphAdapter;

});
