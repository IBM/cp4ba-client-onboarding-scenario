/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/declare", "dojo/_base/array", "dojo/_base/connect", "dojox/collections/Dictionary", "./ErrorReporter"],
function(declare, array, connect, Dictionary, R){

var HandleSet = declare("ibm_ilog.diagram.util.HandleSet", null, {

	_connectionHandles: null,

	constructor: function () {
		this._connectionHandles = new Dictionary();
	},

	_connect: function (id, source, eventName, target, handlerName, connector, disconnector) {
		//
		//	summary:
		//		dojo.connects and stores handle in the receiver with given id
		//
		var h;
		connector = connector || connect.connect;
		disconnector = disconnector || connect.disconnect;
		if (this._connectionHandles.containsKey(id)) {
			R.warn("ConnectionStillActive", id);
		} else {
			switch (arguments.length) {
			case 5:
			case 7:
				h = connector(source, eventName, target, handlerName);
				break;
			default:
				R.error("InvalidNumberOfArguments", arguments, 5, 7);
				break;
			}
		}

		if (h) {
			this._addHandle(id, h, source, disconnector);
		}
	},

	_isConnected: function (id) {
		//
		//	summary:
		//		dojo.connects and stores handle in the receiver with given id
		//
		return this._connectionHandles.containsKey(id);
	},

	_disconnect: function (id) {
		//
		//	summary:
		//		dojo.connects and stores handle in the receiver with given id
		//
		var handle = this._connectionHandles.item(id);
		if (this._connectionHandles.remove(id)) {
			handle.disconnector(handle.h, handle.src);
		}
	},

	_addHandle: function ( /*String*/ id, /*dojo handler*/ handle, /*Obj*/ src, /*Function*/ disconnector) {
		//
		// summary:
		//		add a handle to the handles list
		// handle:
		//		the handle to be added
		//
		this._connectionHandles.add(id, {
			h: handle,
			src: src,
			disconnector: disconnector
		});
	},


	_disconnectAll: function () {
		//
		// summary:
		//		release all the handles.
		//
		array.forEach(this._connectionHandles.getValueList(), function (handle) {
			handle.disconnector(handle.h, handle.src);
		});
		this._connectionHandles.clear();
	}
});

HandleSet.gfxConnector = function(src,evt,object,handler) {
	return src.connect(evt,object,handler);
};

HandleSet.gfxDisconnector = function(handle,src) {
	return src.disconnect(handle);
};

return HandleSet;

});