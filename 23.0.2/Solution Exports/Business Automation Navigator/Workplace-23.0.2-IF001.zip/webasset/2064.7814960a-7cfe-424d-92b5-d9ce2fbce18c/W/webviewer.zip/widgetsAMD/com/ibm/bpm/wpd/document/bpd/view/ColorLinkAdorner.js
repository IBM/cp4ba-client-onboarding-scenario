/**
 * An adorner that colors a link a particular color and sets it a particular width.
 * An example of an adorner that does not use a base ILog adorner.
 */
define([
   "dojo/_base/declare", "dojo/_base/lang", "dojox/gfx/_base", "./Adorner", "./adornerConstants", "./ilogDiagramUtils"
], function(declare, lang, gfx, Adorner, adornerConstants, ilogDiagramUtils) {
   return declare([
      Adorner
   ], {

      color : null,
      width : null,

      constructor : function(args) {
         lang.mixin(this, args);
         if (!this.color)
            this.color = "#1B75BC"; // Default colour 

         if (!this.width)
            this.width = 4;
      },

      adorn : function() {
         try {
            // If already adorned, nothing to do.
            if (this.adorned)
               return;
            // If not a link, then don't know what to do.
            if (this.adornerTarget.type != adornerConstants.TYPE_LINK)
               return;
            // Resolve the link.
            var gfxLink = ilogDiagramUtils.getGfxLinkById(this.adornerTarget.ilogDiagram, this.adornerTarget.id);
            if (!gfxLink)
               return;
            // Remember the original colors and widths
            var pathStroke = gfxLink._path.strokeStyle;
            var arrowStroke = gfxLink._endArrow.strokeStyle;
            var normalizedColor = gfx.normalizeColor(this.color);
            this.unAdornInfo.pathColor = pathStroke.color;
            this.unAdornInfo.pathWidth = pathStroke.width;
            this.unAdornInfo.arrowColor = arrowStroke.color;
            this.unAdornInfo.arrowFillColor = gfxLink._endArrow.fillStyle;
            // Set the link - means the path, arrow stroke and arrow fill.
            pathStroke.color = normalizedColor;
            pathStroke.width = this.width;
            gfxLink._path.setStroke(pathStroke);
            arrowStroke.color = normalizedColor;
            gfxLink._endArrow.setStroke(arrowStroke);
            gfxLink._endArrow.setFill(normalizedColor);
            this.adorned = true;
         } catch (e) {
            console.error(e);
         }
      },

      unAdorn : function() {
         try {
            // If not adorned, nothing to do.
            if (!this.adorned)
               return;
            // If not a link, then don't know what to do.
            if (this.adornerTarget.type != adornerConstants.TYPE_LINK)
               return;
            // Resolve the link.
            var gfxLink = ilogDiagramUtils.getGfxLinkById(this.adornerTarget.ilogDiagram, this.adornerTarget.id);
            if (!gfxLink)
               return;
            // Reset from saved info
            if (!this.unAdornInfo)
               return;
            var pathStroke = gfxLink._path.strokeStyle;
            pathStroke.color = this.unAdornInfo.pathColor;
            pathStroke.width = this.unAdornInfo.pathWidth;
            gfxLink._path.setStroke(pathStroke);
            var arrowStroke = gfxLink._endArrow.strokeStyle;
            arrowStroke.color = this.unAdornInfo.arrowColor;
            gfxLink._endArrow.setStroke(arrowStroke);
            gfxLink._endArrow.setFill(this.unAdornInfo.arrowFillColor);
            this.inherited(arguments);
         } catch (e) {
            console.error(e);
         }
      }

   });

});
