/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"../../base",
"../../adorners/HighlightedHandle",
"../interactors/ConnectionHandleInteractor"
], function(
declare,
iid,
HighlightedHandle,
ConnectionHandleInteractor
){

/*=====
var HighlightedHandle = ibm_ilog.diagram.adorners.HighlightedHandle;
=====*/

	var ConnectionHandle =
	iid.gfxDeclaration(declare('ibm_ilog.diagram.editor.adorners.ConnectionHandle',[HighlightedHandle],{
		
		//
		//	_location: Point
		//
		location: null,
		
		setup: function(location) {
			this.location = location;
			this.addInteractor(new ConnectionHandleInteractor().initialize(this));
			return this;
		},
		
		getPortPosition:function(){
			return this.location;
		}
	}));
	
	ConnectionHandle.templateId = "ConnectionHandle";

	return ConnectionHandle;
	
});
