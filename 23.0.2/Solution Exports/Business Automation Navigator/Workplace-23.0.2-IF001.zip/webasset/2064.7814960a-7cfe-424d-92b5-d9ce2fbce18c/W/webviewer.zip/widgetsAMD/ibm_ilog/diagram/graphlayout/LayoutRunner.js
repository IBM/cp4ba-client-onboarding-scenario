/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare", "dojo/_base/config", "dojo/_base/connect",
"require",
"../gfxlayout/Engine", "../util/Batch"
], function(declare, config, connect, require, gfxlayout, Batch){

// The following classes are (tentatively) loaded dynamically when we perform a layout,
// they are used when we do a hierarchical layout and the diagram contains swim lanes.

var SwimLane = null;
var HierarchicalLayout = null;
var HierarchicalNodeGroup = null;
var HierarchicalSwimLaneConstraint = null;
var Direction = null;
var _classesRequired = false;

var _requireClasses = function()
{
	if(!_classesRequired){
		try {
			HierarchicalLayout = require("ibm_ilog/graphlayout/hierarchical/HierarchicalLayout");
			HierarchicalNodeGroup = require("ibm_ilog/graphlayout/hierarchical/HierarchicalNodeGroup");
			HierarchicalSwimLaneConstraint = require("ibm_ilog/graphlayout/hierarchical/HierarchicalSwimLaneConstraint");
			Direction = require("ibm_ilog/graphlayout/Direction");
			SwimLane = require("../SwimLane");
		} catch(err){}
	}
	_classesRequired = true;
}

var LayoutRunner = 
declare("ibm_ilog.diagram.graphlayout.LayoutRunner", null, {
	// summary:
	//		This class provides the graph layout API for a Graph object.
	// tags:
	//		private
	
	_nodeLayout: null,
	_linkLayout: null,
	_nodeLayoutActive: true,
	_linkLayoutActive: true,
	_automaticNodeLayout: false,
	_automaticLinkLayout: false,
	_animatedLayout: false,
	_autoFitOnLayout: false,
	_rml: null,
	_graphAdapter: null,
	_layoutProvider: null,
	
	setNodeLayout: function(/*ibm_ilog.graphlayout.GraphLayout*/layout){
		// summary:
		//		Sets the graph layout algorithm that will be executed on the contents of this graph
		//		when performGraphLayout is called.
		// layout: ibm_ilog.graphlayout.GraphLayout:
		//		The graph layout algorithm that will be executed on the contents of this graph
		//		when performGraphLayout is called.
		
		if (layout != this._nodeLayout) {
			this._detachLayout(this._nodeLayout, true);
			this._nodeLayout = layout;
			this._attachLayout(this._nodeLayout, true);
			this._invalidateSubLayouts();
			this._checkAutoLayout();
		}
	},
	
	getNodeLayout: function(){
		// summary:
		//		Gets the graph layout algorithm that will be executed on the contents of this graph
		//		when performGraphLayout is called.
		// returns: ibm_ilog.graphlayout.GraphLayout:
		//		The graph layout algorithm that will be executed on the contents of this graph
		//		when performGraphLayout is called.
		
		return this._nodeLayout;
	},
	
	setNodeLayoutActive: function(active){
		// summary:
		//		Activates or deactivates the graph layout specified by setNodeLayout().
		// active: boolean:
		//		True to activate the graph layout, false to deactivate it.
		// description:
		//		If the graph layout is active, it will be performed when performGraphLayout() is called.
		//		For example, you can call setNodeLayoutActive(false) if you want to perform only a link layout.
		
		if (active != this._nodeLayoutActive) {
			this._nodeLayoutActive = active;
			// Update the multiple layout instance
			var rml = this._rml;
			if (rml != null) {
				var ml = rml.getLayout(null);
				ml.setFirstGraphLayoutActive(active);
			}
			// We must refresh the sub-layouts because they may be an inherited copy of this one.
			this._invalidateSubLayouts();
			this._checkAutoLayout();
		}
	},
	
	isNodeLayoutActive: function(){
		// summary:
		//		Returns true if the graph layout is active, or false otherwise.
		// returns: boolean:
		//		True if the graph layout is active, false otherwise.
		
		return this._nodeLayoutActive;
	},
	
	setAutomaticNodeLayout: function(automatic){
		// summary:
		//		Determines if the graph layout must be executed automatically
		//		whenever the graph changes.
		// automatic: boolean:
		//		If true, the graph layout will be executed automatically whenever the graph changes.
		//		If false, the graph layout must be executed by calling performGraphLayout explicitly.
		
		if (automatic != this._automaticNodeLayout) {
			this._automaticNodeLayout = automatic;
			if (automatic) 
				this._checkAutoLayout();
		}
	},
	
	isAutomaticNodeLayout: function(){
		// summary:
		//		Returns the flag specifying if the graph layout must be executed automatically
		//		whenever the graph changes.
		// returns: Boolean
		//		True if the graph layout will be executed automatically whenever the graph changes.
		//		False if the graph layout is executed only by calling performGraphLayout explicitly.
		return this._automaticNodeLayout;
	},
	
	setLinkLayout: function(/*ibm_ilog.graphlayout.GraphLayout*/layout){
		// summary:
		//		Sets the link layout algorithm that will be executed on the contents of this graph
		//		when performGraphLayout is called.
		// layout: ibm_ilog.graphlayout.GraphLayout:
		//		The link layout algorithm that will be executed on the contents of this graph
		//		when performGraphLayout is called.
		
		if (layout != this._linkLayout) {
			this._detachLayout(this._linkLayout, false);
			this._linkLayout = layout;
			this._attachLayout(this._linkLayout, false);
			this._invalidateSubLayouts();
			this._checkAutoLayout();
		}
	},
	
	getLinkLayout: function(){
		// summary:
		//		Gets the link layout algorithm that will be executed on the contents of this graph
		//		when performGraphLayout is called.
		// returns: ibm_ilog.graphlayout.GraphLayout:
		//		The link layout algorithm that will be executed on the contents of this graph
		//		when performGraphLayout is called.
		
		return this._linkLayout;
	},
	
	setLinkLayoutActive: function(active){
		// summary:
		//		Activates or deactivates the link layout specified by setLinkLayout().
		// active: boolean:
		//		True to activate the link layout, false to deactivate it.
		// description:
		//		If the link layout is active, it will be performed when performGraphLayout() is called.
		//		For example, you can call setLinkLayoutActive(false) if you want to perform only a graph layout.
		
		if (active != this._linkLayoutActive) {
			this._linkLayoutActive = active;
			// Update the multiple layout instance
			var rml = this._rml;
			if (rml != null) {
				var ml = rml.getLayout(null);
				ml.setSecondGraphLayoutActive(active);
			}
			// We must refresh the sub-layouts because they may be an inherited copy of this one.
			this._invalidateSubLayouts();
			this._checkAutoLayout();
		}
	},
	
	isLinkLayoutActive: function(){
		// summary:
		//		Returns true if the link layout is active, or false otherwise.
		// returns: boolean:
		//		True if the link layout is active, false otherwise.
		
		return this._linkLayoutActive;
	},
	
	setAutomaticLinkLayout: function(automatic){
		// summary:
		//		Determines if the link layout must be executed automatically
		//		whenever the graph changes.
		// automatic: boolean:
		//		If true, the link layout will be executed automatically whenever the graph changes.
		//		If false, the link layout must be executed by calling performGraphLayout explicitly.
		
		if (automatic != this._automaticLinkLayout) {
			this._automaticLinkLayout = automatic;
			if (automatic) 
				this._checkAutoLayout();
		}
	},
	
	isAutomaticLinkLayout: function(){
		// summary:
		//		Returns the flag specifying if the link layout must be executed automatically
		//		whenever the graph changes.
		// returns Boolean:
		//		True if the link layout will be executed automatically whenever the graph changes.
		//		False if the link layout is executed only by calling performGraphLayout explicitly.
		return this._automaticLinkLayout;
	},
	
	setAnimatedLayout: function(animated){
		// summary:
		//		Determines if an animation must be displayed after a graph layout has been performed.
		// animated: boolean:
		//		If true, an animation moves the nodes and reshapes the links from their position/shape
		//		before the layout to their position/shape after the layout.
		
		this._animatedLayout = animated;
	},
	
	isAnimatedLayout: function(){
		// summary:
		//		Returns the flags that determines if an animation must be displayed after a graph layout has been performed.
		// returns: boolean:
		//		True if graph layout is animated, false otherwise.
		
		return this._animatedLayout;
	},
	
	setAutoFitOnLayout: function(autoFit){
		// summary:
		//		Determines if fitToContents is called after a graph layout is performed.
		// autoFit: boolean:
		//		If true, fitToContents() is automatically called to show all the graph after a graph layout is performed.
		
		this._autoFitOnLayout = autoFit;
	},
	
	isAutoFitOnLayout: function(){
		// summary:
		//		Returne the boolean that determines if fitToContents is called after a graph layout is performed.
		// returns: boolean:
		//		True if fitToContents() is automatically called to show all the graph after a graph layout is performed.
		return this._autoFitOnLayout;
	},
	
	performGraphLayout: function(/*boolean*/recursive){
		// summary:
		//		Executes the graph layout and/or the link layout specified by the setNodeLayout()
		//		and setLinkLayout methods.
		// description:
		//		If a non-null graph layout has been specified by calling setNodeLayout(),
		//		and if the graph layout is active (that is, unless setNodeLayoutActive(false) has been called),
		//		then the graph layout algorithm is performed on the contents of this graph.
		//		Then, if a non-null link layout has been specified by calling setLinkLayout(),
		//		and if the link layout is active (that is, unless setLinkLayoutActive(false) has been called),
		//		then the link layout algorithm is performed on the contents of this graph.
		// recursive: boolean:
		//		If true, the graph layout is executed recursively on all Subgraphs contained in this Graph.
		//		If false, the graph layout is executed only on this Graph.
		
		if(arguments.length == 0)
			recursive = true;
		this._performGraphLayout(false, recursive);
	},
	
	onLayoutAnimationStart: function(){
		// summary:
		//		Called when the graph layout animation starts, if isAnimatedGraphLayout() is true.
		this._inLayoutAnimation = true;
	},
	
	onLayoutAnimate: function(v){
		// summary:
		//		Called on each step of the graph layout animation, if isAnimatedGraphLayout() is true.
		// v: number:
		//		A value between 0 and 100 specifying the progress of the animation.
	},
	
	onLayoutAnimationEnd: function(){
		// summary:
		//		Called when the graph layout animation ends, if isAnimatedGraphLayout() is true.
		this._inLayoutAnimation = false;
	},
	
	_performGraphLayout: function(auto, recursive){
	
		if (!this._rml) 
			return;
		
		// summary:
		//		Internal function that actually performs the layout.
		// auto: boolean:
		//		True if an auto-layout must be performed, false if an explicit layout is performed.
		//		If auto = true, the _automaticNodeLayout/_automaticLinkLayout flags are tested
		//		 to see which layout is in automatic mode.
		// recursive: boolean:
		//		If true, the graph layout is executed recursively on all Subgraphs contained in this Graph.
		//		If false, the graph layout is executed only on this Graph.
		
		var autoGraph = this._automaticNodeLayout;
		var autoLink = this._automaticLinkLayout;
		var animated = this._animatedLayout;
		
		// clear the auto graph layout flags to avoid infinite loops:
		// node move -> _onChange -> _checkAutoLayout -> auto-layout -> node move -> etc
		this._automaticNodeLayout = false;
		this._automaticLinkLayout = false;
		
        if (config.useGfxLayout){
            gfxlayout.Engine.layout();
        }
        
		var animation;
		if (this._animatedLayout) {
			animation = new LayoutRunner.Animation(this, recursive);
			animation.beforeLayout(recursive);
		}
		
		
		var swimLanes;

		// See if Hierarchical layout and SwimLane classes are loaded
		_requireClasses();
		
		 // Testing SwimLane below is enough since _requireClasses also require the hierarchical classes,
		 // so if SwimLane is there then all hierarchical classes + Direction must be there too.
		if (SwimLane &&
			this._nodeLayout &&
			this._nodeLayout instanceof HierarchicalLayout) {
			swimLanes = SwimLane._beforeLayout(this, this._nodeLayout, Direction, HierarchicalNodeGroup, HierarchicalSwimLaneConstraint);
		}
		
		if (this._rml) {
			
			this._refreshSubLayouts();
			
			var layout;
			if (recursive) 
				layout = this._rml;
			else 
				layout = this._rml.getLayout(null);
			layout.performLayout(true);
		}
		
		if (this._animatedLayout) {
			animation.afterLayout(recursive);
			animation = null;
		}
		
		if (!auto) 
			Batch.endBatch();
		
		if(swimLanes)
			SwimLane._afterLayout(this, this._nodeLayout, swimLanes);
		
		if (this._autoFitOnLayout && !this._animatedLayout) // animation will do the fit
			this.fitToContents();
		
		this._automaticNodeLayout = autoGraph;
		this._automaticLinkLayout = autoLink;
	},
	
	_attachLayout: function(layout, first){
		// tags:
		//		private 
		
		if (!layout) 
			return;
		
		var rml = this._rml;
		if (!rml) {
			var provider = new LayoutRunner._LayoutProvider(this);
			rml = new LayoutRunner.RecursiveMultipleLayout(null, provider);
			rml.setFirstGraphLayoutActive(LayoutRunner.RecursiveMultipleLayout.MIXED);
			rml.setSecondGraphLayoutActive(LayoutRunner.RecursiveMultipleLayout.MIXED);
			rml.attach(new LayoutRunner.GraphAdapter(this, rml));
			this._rml = rml;
		}
		
		var ml = rml.getLayout(null);
		
		if (first) {
			ml.setFirstGraphLayout(layout);
			ml.setFirstGraphLayoutActive(this._nodeLayoutActive);
		}
		else {
			ml.setSecondGraphLayout(layout);
			ml.setSecondGraphLayoutActive(this._linkLayoutActive);
		}
		
		// Before 22 april 2011, it was: 
		// layout.attach(new ibm_ilog.diagram.graphlayout.GraphAdapter(this, layout));
		// Fix for the configuration of local parameters (e.g. Hierarchical constraints) in 
		// subgraphs:
		layout.attach(rml.getGraphModel());
		
		layout._graphParameterChangedConnect =
			connect.connect(layout, "onParameterChanged", this, this._onLayoutParameterChanged);
	},
	
	_detachLayout: function(layout, first){
		// tags:
		//		private
		
		if (!layout) 
			return;
		
		var rml = this._rml;
		if (rml) {
			var ml = rml.getLayout(null);
			if (first) 
				ml.setFirstGraphLayout(null);
			else 
				ml.setSecondGraphLayout(null);
			
			if (!this._nodeLayout && !this._linkLayout) {
				rml.detach();
				this._rml = null;
			}
		}
		
		if(layout._graphParameterChangedConnect)
			connect.disconnect(layout._graphParameterChangedConnect);
	},
	
	_onLayoutParameterChanged: function(parameterName){
		// summary:
		//		Invalidates subgraph layouts when a layout property is changed.
		
		if (this._inLayoutParameterChanged || this._inAutoLayout) 
			return;
		if (parameterName == "ParametersUpToDate" || // User changed some other property.
				// Constraints of Hierarchical layout are not copied from parent
				// layout to inherited layout, hence we do not need to invalidate 
				// sublayouts when constraints are added to a parent layout.
				parameterName == "Constraints")
			return;
			
		try {
			this._inLayoutParameterChanged = true;
			
			var rml = this._rml;
			if (rml != null && !rml.isLayoutRunning()) {
				var ml = rml.getLayout(null);
				if (ml != null && !ml.isLayoutRunning()) {
					// OK, we are not in auto-layout, no layout is running,
					// we are not called recursively, we can do our stuff.					
					this._invalidateSubLayouts();
				}
			}
		}
		finally {
			delete this._inLayoutParameterChanged;
		}
	},
	
	_getParentGraph: function(){
		if (this._owningSubgraph) 
			return this._owningSubgraph.getParent();
		else 
			return null;
	},
	
	_invalidateSubLayouts: function(){
		for (var p = this; p != null; p = p._getParentGraph()) 
			p._sublayoutsInvalid = true;
	},
	
	_refreshSubLayouts: function(){
		// summary:
		//		Clears the layouts allocated by the layout provider for the subgraphs of this
		//		container. This method must be called every time a sub-layout is subject to change,
		//		that is:
		//		- when the toplevel layout itself changes (i.e., the GraphLayout.LinkLayout properties),
		//		- when a property of a toplevle layout changes,
		//		- when the Graph/LinkLayoutActive properties change
		//		- when a subgraph is added (because the sublayout must be attached immediately
		//		  if we are in auto-layout, so that the layout is done is something changes in
		//		  the subgraph.
		
		if (!this._sublayoutsInvalid) 
			return;
		delete this._sublayoutsInvalid;
		
		var rml = this._rml;
		if (rml != null) {
			var model = rml.getGraphModel();
			
			// Call the recursive method to go down into the subgraphs of this
			// container.
			//
			this._refreshSubLayoutsRec(rml.getLayoutProvider(), model, model);
		}
		
		var parent = this._getParentGraph();
		if (parent != null) 
			parent._refreshSubLayouts();
	},
	
	_refreshSubLayoutsRec: function(provider, topmodel, model){
		// summary:
		//		Recursive helper method for the previous method.
		
		var subgraphs = model.getSubgraphs();
		for (var i = 0; i < subgraphs.length; i++) {
			var submodel = topmodel.getGraphModel(subgraphs[i]);
			provider.setPreferredLayout(submodel, null);
			provider.getGraphLayout(submodel);
			this._refreshSubLayoutsRec(provider, topmodel, submodel);
		}
	},
    
	_checkAutoLayout: function(){
		// summary:
		//		Checks if an auto-layout must be performed and, if yes, schedule it.
		
		if (!this._inLayoutAnimation &&
		((this._nodeLayout && this._automaticNodeLayout && this._nodeLayoutActive) ||
		(this._linkLayout && this._automaticLinkLayout && this._linkLayoutActive))) {
			Batch.add(this);
		}
	},
	
	_endBatch: function(){
	
		var rml = this._rml;
		if (!rml) 
			return;
		
		try {
			if (!this._automaticNodeLayout) 
				rml.setFirstGraphLayoutActive(LayoutRunner.RecursiveMultipleLayout.INACTIVE);
			if (!this._automaticLinkLayout) 
				rml.setSecondGraphLayoutActive(LayoutRunner.RecursiveMultipleLayout.INACTIVE);
	
			this._inAutoLayout = true;
			
			this._performGraphLayout(true, true);
			
		}
		finally {
			this._inAutoLayout = false;
			
			if (!this._automaticNodeLayout) 
				rml.setFirstGraphLayoutActive(LayoutRunner.RecursiveMultipleLayout.MIXED);
			if (!this._automaticLinkLayout) 
				rml.setSecondGraphLayoutActive(LayoutRunner.RecursiveMultipleLayout.MIXED);
		}
	},
	
	_getActualLayout: function(first){
		// tags:
		//		private
		var toplevelGraph = null;
		for (var graph = this; graph != null; graph = graph._getParentGraph()) 
			toplevelGraph = graph;
		if (toplevelGraph && toplevelGraph._rml) {
			toplevelGraph._refreshSubLayouts();
			var ml = toplevelGraph._rml.getLayout(this._owningSubgraph);
			if(ml){
				if(first)
					return ml.getFirstGraphLayout();
				else
					return ml.getSecondGraphLayout();
			}
		}
		return null;
	},
	
	_getActualNodeLayout: function(){
		// summary:
		//		Gets the node layout that is actually executed on this graph.
		//		The actual layout can be inherited from another graph higher in the hierarchy.
		// tags:
		//		private
		return this._getActualLayout(true);
	},
	
	_getActualLinkLayout: function(toplevelGraph){
		// summary:
		//		Gets the link layout that is actually executed on this graph.
		//		The actual layout can be inherited from another graph higher in the hierarchy.
		// tags:
		//		private
		return this._getActualLayout(false);
	}
});

return LayoutRunner;

});
