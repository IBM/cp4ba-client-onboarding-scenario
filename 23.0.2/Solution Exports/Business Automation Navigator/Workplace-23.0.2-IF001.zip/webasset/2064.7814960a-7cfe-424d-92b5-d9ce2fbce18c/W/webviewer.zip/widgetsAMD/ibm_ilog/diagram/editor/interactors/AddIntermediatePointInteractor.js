/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/event",
"../../interactors/Interactor",
"../EditingUtils",
"../../util/Geometry"
], function(
declare,
event,
Interactor,
EditingUtils,
g
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var AddIntermediatePointInteractor =
declare("ibm_ilog.diagram.editor.interactors.AddIntermediatePointInteractor", [Interactor], {
	// summary:
	//		this interactor is created in the LinkIntermediatePointAdorner and have the functionality 
	//		to add intermediate points to the adorned link
	
	
	//	_handle: /*LinkIntermediatePointsHandle*/
	_adorner: null,
	_viewport: null,
	
	_declareStates: function () {
		this._declareState("idle", ["add"]);
		//this._declareState("active", ["end"]);
	},

	getDefaultConnections: function () {
		// summary:
		//		returns the default event mapping
		
		return {
			add: {
				src: this._getInitialEventSource(),
				srcEvt: "onmousedown",
				connectTo: "_addIntermediatePoint",
				filter: this._buildInputFilter({shift:true,button:0}),
				gfxConnect:true
			}
		};
	},
	
	initialize: function( /* LinkIntermediatePointsAdorner */ adorner ) {
		// summary:
		//		sets the LinkIntermediatePointsAdorner and initialize its superclass
		this._adorner = adorner;
		this._viewport = adorner.getViewport();
		this._initialize();
		return this;
	},
	
	_getInitialEventSource: function() {
		return this._adorner._path;
	},
	
	_addIntermediatePoint: function(e) {
		// summary:
		//		Add the intermediate point to the adorned link
		var link = this._adorner.getAdorned();
		var V = this._adorner.getViewport();
		var D = V.getDiagram();
		if(link){
			var intermediatePoints = link.getIntermediatePoints();
			var point = V.eventContentLocation(e);
			var t = link.getShapeToContainerTransform(D.getGraph().getParent()).inverse();
			var pointT = t.transformPoint(point);
			var index = this._getCloserSegmentIndex(link,intermediatePoints,pointT);
			EditingUtils.addItermediatePoint(D,link,pointT,index);
			this._adorner.rebindAdorned();
		}
		event.stop(e);
	},
	_getCloserSegmentIndex: function(link,intermediatePoints,point){
		// summary:
		//		return the index of the closer link segment to the point
    	var distance = Number.MAX_VALUE;
    	var index = -1;
    	var startPoint = link._pathPoints[0];
    	var endPoint = link._pathPoints[link._pathPoints.length - 1];
    	intermediatePoints = [startPoint].concat(intermediatePoints).concat([endPoint]);
    	for(var i=1;i<intermediatePoints.length;i++){
    		var a = intermediatePoints[i-1];
    		var b = intermediatePoints[i];
    		var d = g.getPointToSegmentDistance(a,b,point);
    		if(distance>d){
    			distance = d;
    			index = i-1;
    		}
    	}
    	return index;
    }
});

return AddIntermediatePointInteractor;

});
