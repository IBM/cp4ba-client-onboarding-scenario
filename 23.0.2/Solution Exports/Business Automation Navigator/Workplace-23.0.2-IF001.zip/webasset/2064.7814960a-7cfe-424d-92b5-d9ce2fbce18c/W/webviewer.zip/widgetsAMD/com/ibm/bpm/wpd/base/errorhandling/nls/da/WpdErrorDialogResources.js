define({      
//begin v1.x content
    errorDialogTitle: "IBM BPM-fejl",
    moreDetails: "Flere detaljer...",
    closeMessage: "Luk alle fejlmeddelelser",
    contentMessage: "Der er opstået en fejl."
//end v1.x content
});

