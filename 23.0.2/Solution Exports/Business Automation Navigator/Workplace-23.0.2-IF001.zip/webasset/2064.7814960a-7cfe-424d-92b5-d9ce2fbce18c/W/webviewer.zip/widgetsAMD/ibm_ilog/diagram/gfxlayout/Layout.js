/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["dojo/_base/lang", "dojo/_base/declare", "./Engine"],
function(lang, declare, Engine){

var Layout = declare('ibm_ilog.diagram.gfxlayout.Layout', null, {

    // the Group attached to this layout
    _container: null,
    
    
    // summary:
    //     The base class for Layout implementations.
    // description:
    //     A Layout instance is responsible for arranging the children of a GFX container
    //     according to positioning and sizing constraints.
    
    constructor: function(args) {
        // summary:
        //     Creates and initializes a new ibm_ilog.diagram.gfxlayout.Layout instance.
        // args : Object : a mixin set of parameters.
        
        lang.mixin(this, args);
    },
	
	getConfig:function(){
		// summary:
		// Gets the current configuration of this layout instance.
		// returns: Object
		//	An object that represents the layout current configuration.
		return {}; /*Object*/
	},
    
    _attach: function(/*dojox.gfx.Group*/container) {
        // summary:
        //     Associates this layout to the specified container.
        // container: dojox.gfx.Group:
        //     The container to associate.
        
        this._container = container;
    },
    
    _detach: function() {
        // summary:
        //     Detach this layout from its associated container.
        
        this._container = null;
    },
    
    onLayoutPropertyChanged: function() {
        // summary:
        //     Fires a layout property changed event.
        // description:
        //     This method should be called by layout subclasses when a property change needs
        //     the layout to be refreshed. 
        
        this.invalidate();
    },
    
    invalidate: function() {
        // summary:
        //     Invalidates this layout.
        // description:
        //     This method post a layout request to the layout engine.
        
        if (this.__inLayout) 
            return;
        //ibm_ilog.diagram.gfxlayout.postInvalidate(this._container);
        this._container.invalidate();
    },
    
    
    computePreferredSize: function(proposedSize) {
        // summary:
        //     compute the preferred size of the associated container according to the layout strategy.
        
        return proposedSize;
    },
    
    adjustBBox : function(/*Rectangle*/bbox){
        // summary:
        //     Adjusts the specified rectangle according to the constraints of this layout.
        return bbox;
    },

    inLayout:function(){
        // summary:
        //     Indicates whether this layout is in a layout session.
        return this.__inLayout; 
    },
    
    doLayout: function(/*Rect*/contBounds) {
        // summary:
        //     Applies this layout to the associated container.
        
        try {
            this.__inLayout = true;
            this.layoutChildren(contBounds);        
        } finally {
            this.__inLayout = false;
        }
    },
    
    layoutChildren: function(/*Rect*/contBounds) {
        // summary:
        //     Applies this layout strategy to the associated container within the specified bounds.
        //     Subclass must override this method to implement their own layout logic. 
    },
    
    placeChildInSlot: function(/*dojox.gfx.Shape*/shape, /*dojox.gfx.Rectangle*/slotBounds, /*Boolean*/hAlign, /*Boolean*/vAlign) {
        // summary:
        //     Places the specified object in the given slotBounds.
        // description:
        //     This method should be invoked by layout implementation to place a shape within
        //     the given slot bounds, taking into account the vertical and horizontal alignment
        //     contraints of the shape (specified by means of the 'valign' and 'halign' properties
        //     on the shape object) and the margins, if any (specified by means of the 'margins'
        //     property.
        // shape : dojox.gfx.Shape: the shape.
        // slotBounds : Rectangle : the slot bounds (i.e the bounds where the shape must lie in)
        // hAlign: Boolean : indicates whether the shape must be aligned horizontally according to
        //      the value of its halign property.
        // vAlign: Boolean : indicates whether the shape must be aligned vertically according to
        //      the value of its valign property.
        
        var checkW = true, checkH = true, shapeBounds = shape.getPreferredSize();
        if (shape.margins){
            slotBounds = this._applyMargins(slotBounds, shape.margins);
        }
        if (hAlign) {
            if (!vAlign) {
                shapeBounds.y = slotBounds.y;
                shapeBounds.height = slotBounds.height;
            }
            var halign = shape.halign || 'stretch';
            switch (halign) {
                case 'left':
                    shapeBounds.x = slotBounds.x;
					// the width should not be greater than the slot width
					shapeBounds.width = Math.min(shapeBounds.width, slotBounds.width);
                    break;
                case 'center':
					// the width should not be greater than the slot width
					shapeBounds.width = Math.min(shapeBounds.width, slotBounds.width);
                    shapeBounds.x = slotBounds.x + (slotBounds.width - shapeBounds.width) / 2;
                    break;
                case 'right':
					// the width should not be greater than the slot width
					shapeBounds.width = Math.min(shapeBounds.width, slotBounds.width);
                    shapeBounds.x = slotBounds.x + slotBounds.width - shapeBounds.width;
                    break;
                default:
                case 'stretch':
                    shapeBounds.width = slotBounds.width;
			        shapeBounds = shape._checkMinMaxSize(shapeBounds);
                    shapeBounds.x = slotBounds.x + (slotBounds.width - shapeBounds.width)/2;
                    checkW = false;
					break;
            }
        }
        if (vAlign){
            if (!hAlign) {
                shapeBounds.x = slotBounds.x;
                shapeBounds.width = slotBounds.width;
            }
            var valign = shape.valign || 'stretch';
            switch (valign) {
                case 'top':
                    shapeBounds.y = slotBounds.y;
					// the height should not be greater than the slot height
					shapeBounds.height = Math.min(shapeBounds.height, slotBounds.height);
                    break;
                case 'center':
					// the height should not be greater than the slot height
					shapeBounds.height = Math.min(shapeBounds.height, slotBounds.height);
                    shapeBounds.y = slotBounds.y + (slotBounds.height - shapeBounds.height) / 2;
                    break;
                case 'bottom':
					// the height should not be greater than the slot height
					shapeBounds.height = Math.min(shapeBounds.height, slotBounds.height);
                    shapeBounds.y = slotBounds.y + slotBounds.height - shapeBounds.height;
                    break;
                default:
                case 'stretch':
                    shapeBounds.height = slotBounds.height;
			        shapeBounds = shape._checkMinMaxSize(shapeBounds);
                    shapeBounds.y = slotBounds.y + (slotBounds.height - shapeBounds.height)/2;
					checkH = false;
                    break;
            }
        }
        // check Min/Max size
		if (checkW || checkH)
        	shapeBounds = shape._checkMinMaxSize(shapeBounds);
        
        shape.layout(shapeBounds);
    },
    
    // margins stuff
    
    _inflateH: function(/*Number*/val, /*Object||Array*/margins) {
        // summary:
        //     Enlarge the specified value by the given horizontal margins.
        // val : Number : the value to inflate.
        // margins: Object || Array: the margins. If the parameter is an array,
        //          the left and right margins are expected to be at index 0 and 2 respectively.
        
        if (margins instanceof Array) {
            // left and right are indexes 0 and 2;
            if (margins.length > 0) 
                val += margins[0];
            if (margins.length > 2) 
                val += margins[2];
        } else {
            val += 2 * margins;
        }
        return val;
    },
    
    _inflateV: function(/*Number*/val, /*Object||Array*/margins) {
        // summary:
        //     Enlarge the specified value by the given vertical margins.
        // val : Number : the value to inflate.
        // margins: Object || Array: the margins. If the parameter is an array,
        //          the top and bottom margins are expected to be at index 1 and 3 respectively.

        if (margins instanceof Array) {
            // top and bottom are indexes 1 and 3;
            if (margins.length > 1) 
                val += margins[1];
            if (margins.length > 3) 
                val += margins[3];
        } else {
            val += 2 * margins;
        }
        return val;
    },
    
    _inflateRect:function(/*dojox.gfx.Rectangle*/rect, /*Object||Array*/margins){
        // summary:
        //     Enlarge the specified rect by the given margins.
        // rect: Rectangle: the rectangle to inflate.
        // margins: Object || Array: the margins. If the parameter is an array,
        //          the top and bottom margins are expected to be at index 1 and 3 respectively, and
        //          the left and right margins are expected to be at index 0 and 2 respectively.
        
        rect = lang.clone(rect);
        if (margins instanceof Array) {
            // left
            if (margins.length > 0) {
                rect.x -= margins[0];
                rect.width += margins[0];
            }
            // top
            if (margins.length > 1) {
                rect.y -= margins[1];
                rect.height += margins[1];
            }
            // right
            if (margins.length > 2) {
                rect.width += margins[2];
            }
            // bottom
            if (margins.length > 3) {
                rect.height += margins[3];
            }
        } else {
            rect.x -= margins;
            rect.width += 2 * margins;
            rect.y -= margins;
            rect.height += 2 * margins;
        }
        return rect;
    },
        
    _applyMargins: function(/*dojox.gfx.Rectangle*/rect, /*Object||Array*/margins) {
        // summary:
        //     Applies the specified margins to given rect. This operation is the
        //     opposite of the _inflateRect method.
        // rect: Rectangle: the rectangle to inflate.
        // margins: Object || Array: the margins. If the parameter is an array,
        //          the top and bottom margins are expected to be at index 1 and 3 respectively, and
        //          the left and right margins are expected to be at index 0 and 2 respectively.
        
        rect = lang.clone(rect);
        if (margins instanceof Array) {
            // left
            if (margins.length > 0) {
                rect.x += margins[0];
                rect.width -= margins[0];
            }
            // top
            if (margins.length > 1) {
                rect.y += margins[1];
                rect.height -= margins[1];
            }
            // right
            if (margins.length > 2) {
                rect.width -= margins[2];
            }
            // bottom
            if (margins.length > 3) {
                rect.height -= margins[3];
            }
        } else {
            rect.x += margins;
            rect.width -= 2 * margins;
            rect.y += margins;
            rect.height -= 2 * margins;
        }
        if (rect.width<0)
            rect.width = 0;
        if (rect.height<0)
            rect.height = 0; 
        return rect;
    }

    
});

return Layout;

});
