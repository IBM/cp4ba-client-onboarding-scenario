/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
  "dojo/_base/lang",	// #1 (for dojo.clone)
  "dojox/gfx/matrix",	// #2 
  "./Geometry" 			// #3
  ],
  function(
    lang,		// #1 (for dojo.clone)
    matrix,		// #2
    Geometry	// #3
    ) {
	
	// TODO: Change to this when AMD conversion is complete:
	// var gu = {...
	var gu = lang.setObject("ibm_ilog.diagram.util.ClippingUtil", {
			
    getClippedPoint: function(bbox/*Rectangle*/,
                              p1/*Point*/, p2/*Point*/) { 
		// Summary:
	    // 		Returns the clipped point at rectangle (node bounding box), assuming 
	    // 		that p1 (attach point for a link in a graph) is inside the bounding box,
	    // 		and p2 (control point for a link) is outside that bounding box.
	    // bbox: 
		//		The rectangle (bounding box).
	    // p1: 
		//		The point (attach point) to which the unclipped line (link)
		//		is attached.
	    // p2:
		//		The auxiliary control point. For the purpose of
	    //      clipping, the line (link) can be considered as a ray that 
	    //      starts at the attach point and goes through the control point.
	    // return:
		//		The clipped point.
		//

      var intersectionPoints = [];
      var numIntersections = this.lineIntersectsRect(p1, p2, bbox, intersectionPoints);      
      // choose the result from the intersections
      return this.bestClipPointOnRay(p1, p2, intersectionPoints, numIntersections);
    },
			
	bestClipPointOnRay: function(startPoint/*Point*/, controlPoint/*Point*/,intersectionPoints/*Points Array*/,numIntersections){
		// Summary:
	    // 		Selects the best of n intersection points of a ray for clipping.
	    // 		If any intersection point is on the ray, it returns the one that is
	    // 		farthest from the start of the ray.
	    // 		If no intersection point is on the ray, it returns the one that is closest
	    // 		to the starting point of the ray.
	    // startPoint: 
		//		The starting point of the ray.
	    // controlPoint: 
		//		Another point of the ray.
	    // intersectionPoints:
		//		An array of intersection points. Typically,
	    //      these are the intersection points of a line through starting and
	    //      control points and the border shape of a node.
	    // numIntersections:
		//		The number of valid intersections in the array.
	    // return:
		//		The best of the intersection points.
		//
		      switch (numIntersections) {
		        case 0:
		          return {x:startPoint.x,y:startPoint.y};
		        case 1:
		          return intersectionPoints[0];
		      }
		      // case that we have 2 ore more intersections. Search the best one.
		      
		      var anyOnRay = false;
		      var closestPoint = null;
		      var farthestPoint = null;
		      var dx;
		      var dy;
		      var distSquare;
		      var closestDistSquare = Number.MAX_VALUE;
		      var farthestDistSquare = -1;
		      
		      for (var i = 0; i < numIntersections; i++) {
		        if (intersectionPoints[i] == null) continue;
		        dx = intersectionPoints[i].x - startPoint.x;
		        dy = intersectionPoints[i].y - startPoint.y;
		        distSquare = dx * dx + dy * dy;
		        if (this.pointOnRay(startPoint, controlPoint, intersectionPoints[i])) {
		          anyOnRay = true;
		          if (distSquare > farthestDistSquare) {
		            farthestDistSquare = distSquare;
		            farthestPoint = intersectionPoints[i];
		          }
		        }
		        else if (!anyOnRay && distSquare <= closestDistSquare) {
		          closestDistSquare = distSquare;
		          closestPoint = intersectionPoints[i];
		        }
		      }
		      
		      return anyOnRay ? farthestPoint : closestPoint;
		    },
		    
		    pointOnRay: function(p1/*Point*/, p2/*Point*/,testPoint/*Point*/){
		    	// Summary:
			    // 		Returns <code>true</code> if the input test point is on a ray.
			    // p1:
			    //		The start point of the ray.
			    // p2: 
			    // 		Another point on the ray.
			    // testPoint: 
			    //	 	The point to be tested.
		      var dx = (p2.x > p1.x ? p2.x - p1.x : p1.x - p2.x);
		      var dy = (p2.y > p1.y ? p2.y - p1.y : p1.y - p2.y);
		      
		      // compare in x or y direction. Choose the direction where the points
		      // have the larger span, to avoid rounding errors
		      if (dx > dy) {
		        if (p1.x < p2.x && p1.x <= testPoint.x)
		          return true;
		        if (p1.x > p2.x && p1.x >= testPoint.x)
		          return true;
		      }
		      else {
		        if (p1.y < p2.y && p1.y <= testPoint.y)
		          return true;
		        if (p1.y > p2.y && p1.y >= testPoint.y)
		          return true;
		      }
		      return false;
		    },
		    
 
		    
		    lineIntersectsSegment: function(p1/*Point*/,p2/*Point*/, p3/*Point*/, p4/*Point*/, res){
		    	// Summary:
			    // 		Calculates the intersection between a line and a line segment.
			    // p1: 
			    // 		 A point on the line.
			    // p2: 
			    // 		 Another point on the line.
			    // p3: 
			    // 		 The first end point of the line segment.
			    // p4: 
			    // 		 The second end point of the line segment.
			    // res: 
			    // 		 Container for the resulting intersection point.
			    // return: 
			    // 		 <code>true</code> if the line intersects the segment
			    //         at a unique point.
		      if (this.pointsEquals(p3,p4)) {
		        // test whether p3 is on the line p1-p2
		        if ((p3.x - p1.x) * (p2.y - p1.y) == (p2.x - p1.x) * (p3.y - p1.y)) {
		          res.x = p3.x;
		          res.y = p3.y;
		          return true;
		        }
		      }
		      else
		        if (this.GetLineIntersection(p1, p2, p3, p4, res) != null) {
		          var dx = (p4.x > p3.x ? p4.x - p3.x : p3.x - p4.x);
		          var dy = (p4.y > p3.y ? p4.y - p3.y : p3.y - p4.y);
		          
		          // compare in x or y direction. Choose the direction where the points
		          // have the larger span, to avoid rounding errors.
		          
		          if (dx > dy) {
		            if (p3.x <= res.x && res.x <= p4.x ||
		              p4.x <= res.x && res.x <= p3.x)
		              return true;
		          }
		          else {
		            if (p3.y <= res.y && res.y <= p4.y ||
		              p4.y <= res.y && res.y <= p3.y)
		              return true;
		          }
		        }
		      return false;
		    },
		    
		    
		    // Checking intersection with a polyline isn't that easy.
		    // First, we check the intersection with all polygon segments.
		    // However, it may happen that a line hits exactly the corner point
		    // between two adjacent polygon segments. Due to rounding errors, the
		    // intersection point may appear outside of both polygon segments (this
		    // happens frequently if the one segment is nearly horizontal and the other
		    // is nearly vertical. Therefore we need a special corner test.
		    //
		    // Example,    Due to rounding errors,
		    //             GetLineIntersction \
		    //             may return          \
		    //             this point ------->  X
		    //             which appears         +----------|
		    //             to be outside         |\
		    //             of both polygon       | \
		    //             segments              |  \
		    //                                   |   \
		    //                                   |    \ line
		    //                                   -     \
		    //
		    // If a line doesn't cross adjacent segments (a,b) and (b,c), but crosses
		    // the segment (a,c), we know that it MUST cross the polygon a-b-c at a
		    // point close to b, but we had rounding errors during the calculation that
		    // makes the calculated point appear outside (a,b) and (b,c). In this case,
		    // we report b as the intersection point.
		    

		    lineIntersectsPolyPoints: function(p1/*Point*/, p2/*Point*/, points, closed, res){
			    // Calculates the intersections between a line and a polyline or polygon.
			    // p1: 
			    // 		  One point of the line.
			    // p2: 
			    // 		  Another point on the line.
			    // points: 
			    // 		  The points of the polyline or polygon.
			    // closed: 
			    // 		  <code>true</code> if it is a polygon,
			    //        <code>false</code> if it is a polyline.
			    // res: 
			    // 		  Container for the resulting intersection points.
			    //            This container must must be large enough to get all
			    //            intersection points.
			    // return: 
			    // 		  The number of intersections.
		      var numIntersections = 0;
		      var pa = null;
		      var pb = null;
		      var pc = null;
		      var intersectsFirstSegment = false;
		      var intersectsAB = false;
		      var intersectsBC = false;
		      var prevCrossPoint = null;
		      var crossPoint = {};
		      var pab = {x:0,y:0};
		      var pbc = {x:0,y:0};
		      
		      for (var i = 0; i < points.length; i++) {
		        pc = points[i];
		        // segment test
		        if (pb != null) {
		          if (this.lineIntersectsSegment(p1, p2, pb, pc, crossPoint)) {
		            if (prevCrossPoint == null || !this.pointsEquals(prevCrossPoint,crossPoint)) {
		              res[numIntersections++] = prevCrossPoint = crossPoint;
		              crossPoint = {};
		              intersectsBC = true;
		              if (i == 1)
		                intersectsFirstSegment = true;
		            }
		          }
		        }
		        // corner test
		        if (pa != null && !intersectsAB && !intersectsBC) {
		          pab.x = 0.5 * (pa.x + pb.x);
		          pab.y = 0.5 * (pa.y + pb.y);
		          pbc.x = 0.5 * (pb.x + pc.x);
		          pbc.y = 0.5 * (pb.y + pc.y);
		          if (this.lineIntersectsSegment(p1, p2, pab, pbc, crossPoint)) {
		            if (prevCrossPoint == null || !this.pointsEquals(prevCrossPoint,pb))
		              res[numIntersections++] = prevCrossPoint = pb;
		          }
		        }
		        
		        pa = pb;
		        pb = pc;
		        intersectsAB = intersectsBC;
		      }
		      
		      var firstCrossPoint = (numIntersections > 0 ? res[0] : null);
		      
		      if (points.length > 2 && closed) {
		        pc = points[0];
		        // segment test
		        if (this.lineIntersectsSegment(p1, p2, pb, pc, crossPoint)) {
		          if ((prevCrossPoint == null || !this.pointsEquals(prevCrossPoint,crossPoint)) &&
		            (firstCrossPoint == null || !this.pointsEquals(firstCrossPoint,crossPoint))) {
		              res[numIntersections++] = crossPoint;
		              crossPoint = {};
		              intersectsBC = true;
		            }
		        }
		        // and two more corner tests
		        if (!intersectsAB && !intersectsBC) {
		          pab.x = 0.5 * (pa.x + pb.x);
		          pab.y = 0.5 * (pa.y + pb.y);
		          pbc.x = 0.5 * (pb.x + pc.x);
		          pbc.y = 0.5 * (pb.y + pc.y);
		          if (this.lineIntersectsSegment(p1, p2, pab, pbc, crossPoint)) {
		            if ((prevCrossPoint == null || !this.pointsEquals(prevCrossPoint,pb)) &&
		              (firstCrossPoint == null || !this.pointsEquals(firstCrossPoint,pb)))
		              res[numIntersections++] = prevCrossPoint = pb;
		          }
		        }
		        pa = points[0];
		        if (!intersectsFirstSegment && !intersectsBC) {
		          pab.x = 0.5 * (pa.x + pc.x);
		          pab.y = 0.5 * (pa.y + pc.y);
		          pbc.x = 0.5 * (pb.x + pc.x);
		          pbc.y = 0.5 * (pb.y + pc.y);
		          if (this.lineIntersectsSegment(p1, p2, pab, pbc, crossPoint)) {
		            if ((prevCrossPoint == null || !this.pointsEquals(prevCrossPoint,pc)) &&
		              (firstCrossPoint == null || !this.pointsEquals(firstCrossPoint,pc)))
		              res[numIntersections++] = pc;
		          }
		        }
		      }
		      
		      return numIntersections;
		    },
		    
    	lineIntersectsRect: function(p1/*Point*/, p2/*Point*/, 
                                 	 rect/*Rectangle*/,
                                 	 res) {
		// Summary:
		// 		Calculates the intersections between a line and a rectangle.
		// p1: 
		// 		One point of the line.
		// p2: 
		// 		Another point on the line.
		// rect: 
		// 		The rectangle to test.
		// res: 
		// 		Container of two for the resulting intersection points.
		// return: 
		// 		 The number of intersections.

      	// get the corner points of the bounding box
		var pts = [];
		pts[0] = {x:rect.x, y:rect.y};
		pts[1] = {x:rect.x + rect.width, y:pts[0].y};
		pts[2] = {x:pts[1].x, y:rect.y + rect.height};
		pts[3] = {x:rect.x, y:pts[2].y};
      
      	// get the intersections between the line through attach and control
      	// point and the polygon defined by pts.
      
      	return this.lineIntersectsPolyPoints(p1, p2, pts, true, res);
    	},
		    
		    lineIntersectsEllipse:function(p1/*Point*/, p2/*Point*/, rect/*dojox.gfx.Rectangle*/, res){
		    	// Summary:
			    // 		Calculates both intersections between a line and an ellipse.
			    // p1: 
			    // 		One point of the line.
			    // p2: 
			    // 		Another point on the line.
			    // rect: 
			    // 		The bounding box of the ellipse.
			    // res: 
			    // 		Container of two for the resulting intersection points.
			    // return: 
			    // 		 The number of intersections.
		      var dx = p2.x - p1.x;
		      var dy = p2.y - p1.y;
		      var a = 0.5 * rect.width;
		      var b = 0.5 * rect.height;
		      var cx = rect.x + a;
		      var cy = rect.y + b;
		      var x;
		      var y;
		      var f;
		      var g;
		      var z;
		      var sqrtz;
		      
		      if (dx == 0.0 && dy == 0.0)
		        return 0;
		      
		      if ((dx > 0.0 ? dx : -dx) > (dy > 0.0 ? dy : -dy)) {
		        f = dy/dx;
		        g = p1.y - cy - f * (p1.x - cx);
		        z = b * b + a * a * f * f - g * g;
		        if (z < 0.0)
		          return 0;
		        
		        if (z == 0.0) {
		          x = - f * g * a * a / (b * b + a * a * f * f);
		          y = f * x + g;
		          res[0] = {x:(x + cx),y:(y + cy)};
		          return 1;
		        }
		        else {
		          sqrtz = Math.sqrt(z);
		          x = (a * b * sqrtz - f * g * a * a) / (b * b + a * a * f * f);
		          y = f * x + g;
		          res[0] = {x:(x + cx),y:(y + cy)};
		          x = (- a * b * sqrtz - f * g * a * a) / (b * b + a * a * f * f);
		          y = f * x + g;
		          res[1] = {x:(x + cx),y:(y + cy)};
		          return 2;
		        }
		      }
		      else {
		        f = dx/dy;
		        g = p1.x - cx - f * (p1.y - cy);
		        z = a * a + b * b * f * f - g * g;
		        if (z < 0.0)
		          return 0;
		        
		        if (z == 0.0) {
		          y = - f * g * b * b / (a * a + b * b * f * f);
		          x = f * y + g;
		          res[0] = {x:(x + cx),y:(y + cy)};
		          return 1;
		        }
		        else {
		          sqrtz = Math.sqrt(z);
		          y = (a * b * sqrtz - f * g * b * b) / (a * a + b * b * f * f);
		          x = f * y + g;
		          res[0] = {x:(x + cx),y:(y + cy)};
		          y = (- a * b * sqrtz - f * g * b * b) / (a * a + b * b * f * f);
		          x = f * y + g;
		          res[1] = {x:(x + cx),y:(y + cy)};
		          return 2;
		        }
		      }
		    },
		    
		    lineIntersectsArc:function(p1/*Point*/, p2/*Point*/,rect/*dojox.gfx.Rectangle*/, startAngle, deltaAngle,res){
		    	// Summary:
		    	// 		Calculates both intersections between a line and an arc (a partial ellipse).
			    // p1: 
			    // 		 One point of the line.
			    // p2: 
			    // 		 Another point on the line.
			    // rect: 
			    // 		 The bounding box of the complete ellipse.
			    // startAngle: 
			    // 		 The angle of the starting point in degrees (0 .. 360).
			    // deltaAngle: 
			    // 		 The angle range of the arc from the starting point to
			    //                   the end point in degrees (0 .. 360).
			    // res: 
			    // 		 Container of two for the resulting intersection points.
			    // return: 
			    // 		 The number of intersections.
		      var tempRes = [];
		      var numPoints = this.lineIntersectsEllipse(p1, p2, rect, tempRes);
		      
		      var i;
		      var j = 0;
		      for (i = 0; i < numPoints; i++) {
		        if (this.ellipticAngle(rect, tempRes[i], startAngle) <= deltaAngle){
		        	j++;
		        	res.push(tempRes[i]);
		        }
		      }
		      
		      return j;
		    },
		    
		    lineIntersectsPartialEllipse: function(p1/*Point*/, p2/*Point*/,rx,ry, startPoint,endPoint,fa,fs,alpha,res){
		    	//Summary:
		    	// 		Calculates both intersections between a line and a partial ellipse.
		    	var center = this.ellipseEndpointToCenterParameterization(startPoint,endPoint,fa,fs,rx,ry,alpha);
		    	var rect = {x:center.x-(rx), y:center.y-(ry), width:rx*2, height:ry*2};
		    	
		    	var pp1 = this._rotatePointAt(p1,center,-alpha);
		    	var pp2 = this._rotatePointAt(p2,center,-alpha);
		    	
		    	var angle;
		    	var delta;
		    	if(fs==1){
		    		angle = this.ellipticAngle(rect, endPoint, 0);
		    		delta = this.ellipticAngle(rect, startPoint, angle);
		    	}else{
		    		angle = this.ellipticAngle(rect, startPoint, 0);
		    		delta = this.ellipticAngle(rect, endPoint, angle);
		    	}
		    	angle = angle + alpha;
		    	var length = res.length
		    	this.lineIntersectsArc(pp1, pp2,rect, angle, delta,res);
		    	if((res.length - length) >= 1){
		    		res[res.length-1] = this._rotatePointAt(res[res.length-1],center,alpha);
		    	}
		    	return res.length - length;
		    	
		    },
		    
		    _rotatePointAt: function(point,center,angle){
		    	var _m = matrix;
		    	var mRot = _m.rotategAt(angle,center);
		    	return _m.multiplyPoint(mRot,point);
		    },
		    
		    
		    lineIntersectsQuadSpline: function(p1/*Point*/, p2 /*Point*/,c/*Array*/,startIndex,res){
		    	// Summary:
		    	// 		Calculates the two intersections between a line and a quadratic Bezier spline.
			    // p1:
		    	// 		 One point of the line.
			    // p2:
		    	// 		 Another point on the line.
			    // c:
		    	// 		  An array of control points of the spline.
			    // startIndex:
		    	// 		 The index of the first valid control point in the array <code>c</code>.
			    //       There must be three valid control points of the spline in the array.
			    // res:
		    	// 		 Container of two for the resulting intersection points.
			    // return:
		    	// 		 The number of intersections.
		    	
		    	
		       // the spline parameters
		      var cx = c[startIndex].x;
		      var bx = 2 * (c[startIndex + 1].x - cx);
		      var ax = c[startIndex + 2].x - bx - cx;
		      var cy = c[startIndex].y;
		      var by = 2 * (c[startIndex + 1].y - cy);
		      var ay = c[startIndex + 2].y - by - cy;
		      
		      // the line parameters
		      var DistX = p2.x - p1.x;
		      var DistY = p2.y - p1.y;
		      
		      // is it a line? if not, return no solution
		      if (DistX == 0.0 && DistY == 0.0)
		        return 0;
		      
		      // the spline formula is (with t = 0..1):
		      //
		      //     x =  ax * t^2 + bx * t + cx
		      //     y =  ay * t^2 + by * t + cy
		      //
		      // calculate all parameters t of intersection points
		      
		      var numSolutions;
		      var t = [0,0];
		      var f;
		      var g;
		      
		      if ((DistX > 0.0 ? DistX : -DistX) > (DistY > 0.0 ? DistY : -DistY)) {
		        f = DistY/DistX;
		        g = p1.y - f * p1.x;
		        numSolutions = this.calcQuadSolution(f*ax-ay, f*bx-by, f*cx-cy+g, t);
		      }
		      else {
		        f = DistX/DistY;
		        g = p1.x - f * p1.y;
		        numSolutions = this.calcQuadSolution(f*ay-ax, f*by-bx, f*cy-cx+g, t);
		      }
		      
		      // Only those solutions between 0 and 1 are relevant
		      var numPoints = 0;
		      for (var i = 0; i < numSolutions; i++) {
		        if (0 <= t[i] && t[i] <= 1) {
		          res[numPoints++] ={x:(ax * t[i] * t[i] + bx * t[i] + cx),y:(ay * t[i] * t[i] + by * t[i] + cy)};
		        }
		      }
		      
		      return numPoints;
		    },
		   
		   lineIntersectsCubicSpline: function(p1/*Point*/, p2/*Point*/, c/*Array*/, startIndex, res){
			    // Summary:
			    // 		Calculates all three intersections between a line and a cubic Bezier spline.
			    // p1:
		    	// 		 One point of the line.
			    // p2:
		    	// 		 Another point on the line.
			    // c:
		    	// 		  An array of control points of the spline.
			    // startIndex:
		    	// 		 The index of the first valid control point in the array <code>c</code>.
			    //                   There must be four valid control points of the spline in the array.
			    // res:
		    	// 		 Container of three for the resulting intersection points.
			    // return:
		    	// 		 The number of intersections.
		    	
		    	// the spline parameters
		      var dx = c[startIndex].x;
		      var cx = 3 * (c[startIndex + 1].x - dx);
		      var bx = 3 * (c[startIndex + 2].x - c[startIndex + 1].x) - cx;
		      var ax = c[startIndex + 3].x - bx - cx - dx;
		      var dy = c[startIndex].y;
		      var cy = 3 * (c[startIndex + 1].y - dy);
		      var by = 3 * (c[startIndex + 2].y - c[startIndex + 1].y) - cy;
		      var ay = c[startIndex + 3].y - by - cy - dy;
		      
		      // the line parameters
		      var DistX = p2.x - p1.x;
		      var DistY = p2.y - p1.y;
		      
		      // is it a line? if not, return no solution
		      if (DistX == 0.0 && DistY == 0.0)
		        return 0;
		      
		      // the spline formula is (with t = 0..1):
		      //
		      //     x =  ax * t^3 + bx * t^2 + cx * t + dx
		      //     y =  ay * t^3 + by * t^2 + cy * t + dy
		      //
		      // calculate all parameters t of intersection points
		      
		      var numSolutions;
		      var t = [0,0,0];
		      var f;
		      var g;
		      
		      if ((DistX > 0.0 ? DistX : -DistX) > (DistY > 0.0 ? DistY : -DistY)) {
		        f = DistY/DistX;
		        g = p1.y - f * p1.x;
		        numSolutions = this.calcCubicSolution(f*ax-ay, f*bx-by, f*cx-cy, f*dx-dy+g, t);
		      }
		      else {
		        f = DistX/DistY;
		        g = p1.x - f * p1.y;
		        numSolutions = this.calcCubicSolution(f*ay-ax, f*by-bx, f*cy-cx, f*dy-dx+g, t);
		      }
		      
		      // Only those solutions between 0 and 1 are relevant
		      var numPoints = 0;
		      for (var i = 0; i < numSolutions; i++) {
		        if (0 <= t[i] && t[i] <= 1)
		          res[numPoints++] ={x:((ax * t[i] * t[i] * t[i] + bx * t[i] * t[i] + cx * t[i] + dx)),y:((ay * t[i] * t[i] * t[i] + by * t[i] * t[i] + cy * t[i] + dy))};
		      }
		      
		      return numPoints;
		    },

		    GetLineIntersection: function( p1LA/*Point*/, p2LA/*Point*/,p1LB/*Point*/, p2LB/*Point*/,result){
		    	// Summary:
			    // 		Returns the intersection point between two lines.
			    //  p1LA:
			    // 		 One point on the first line.
			    //  p2LA:
			    // 		 Another point on the first line.
			    //  p1LB:
			    // 		 One point on the second line.
			    //  p2LB:
			    // 		 Another point on the second line.
			    //  result:
			    // 		 If not <code>null</code>, this point is used a container
			    //               for the return value and is filled with the intersection
			    //               point if the lines intersect.
			    //               If <code>null</code>, a new point is allocated internally
			    //               and returned, if the lines intersect.
			    // return:
			    // 		 The unique intersection point, or <code>null</code> if the two lines are parallel.
			    
		      return this.GetLineIntersection1( p1LA.x, p1LA.y, p2LA.x, p2LA.y,p1LB.x, p1LB.y, p2LB.x, p2LB.y,result);
		    },
		    
		    
		    GetLineIntersection1: function(ax1, ay1, ax2, ay2, bx1, by1, bx2, by2, result){
		    	// Summary:
		    	// 		Returns the intersection point between two lines.
			    //  ax1:
			    // 		  The x coordinate of the first point on the first line.
			    //  ay1:
			    // 		  The y coordinate of the first point on the first line.
			    //  ax2:
			    // 		  The x coordinate of the second point on the first line.
			    //  ay2:
			    // 		  The y coordinate of the second point on the first line.
			    //  bx1:
			    // 		  The x coordinate of the first point on the second line.
			    //  by1:
			    // 		  The y coordinate of the first point on the second line.
			    //  bx2:
			    // 		  The x coordinate of the second point on the second line.
			    //  by2:
			    // 		  The y coordinate of the second point on the second line.
			    //  result:
			    // 		  If not <code>null</code>, this point is used a container
			    //               for the return value and is filled with the intersection
			    //               point if the lines intersect.
			    //               If <code>null</code>, a new point is allocated internally
			    //               and returned, if the lines intersect.
			    // return:
			    // 		  The unique intersection point, or <code>null</code> if the two lines are parallel.
		    	
		      var dx1 = ax2 - ax1;
		      var dy1 = ay2 - ay1;
		      var dx2 = bx2 - bx1;
		      var dy2 = by2 - by1;
		      
		      // if cross determinantes are equal, the segments are parallel
		      var dx1y2 = dx1 * dy2;
		      var dx2y1 = dx2 * dy1;
		      
		      if (dx1y2 == dx2y1)
		        return null;
		      
		      // for precision, first handle vertical case, then general case
		      if (ax1 == ax2)
		        result.x = ax1;
		      else if (bx1 == bx2)
		        result.x = bx1;
		      else
		        result.x = (ax1 * dx2y1 - bx1 * dx1y2 + (by1  - ay1) * dx1 * dx2) / (dx2y1 - dx1y2);
		      
		      // for precision, first handle horizontal case, then general case
		      if (ay1 == ay2)
		        result.y = ay1;
		      else if (by1 == by2)
		        result.y = by1;
		      else
		        result.y =  (ay1 * dx1y2 - by1 * dx2y1 + (bx1 - ax1) * dy1 * dy2) / (dx1y2 - dx2y1);
		      
		      return result;
		    },
		    
		 // --------------------------------------------------------------------------
		 // Auxiliaries related to arcs / ellipses
		    
		    ellipticAngle: function(rect/*dojox.gfx.Rectangle*/, p/*Point*/, startAngle){
		    // Summary:
		    // 		Returns the elliptic angle of point p relative to the center of rect where
		    // 		the rect is considered the bounding box of an ellipse and startAngle
		    // 		indicates the origin of the elliptic scale.
		    //  rect:
	    	// 		 The bounding box of the complete ellipse.
		    //  p:
	    	// 		 The point whose elliptic angle is calculated.
		    //  startAngle:
	    	// 		 The angle that defines the 0 point.
		    // return:
	    	// 		 The elliptic angle (relative to startAngle). The value is between 0 and 360.
		      var dx = p.x - rect.x - rect.width / 2;
		      var dy = rect.y + rect.height / 2 - p.y;
		      var x = dx / rect.width;
		      var y = dy / rect.height;
		      var a = 180.0 / Math.PI *  Math.atan2(y, x);
		      a -= startAngle;
		      while (a < 0.0) a += 360.0;
		      while (a > 360.0) a -= 360.0;
		      return a;
		    },
		    
		    retrieveArcPointFromAngle: function(rect/*dojox.gfx.Rectangle*/, angle){
		    // Summary:
	    	// 		Returns the point on an arc from an elliptic angle.
		    //  rect:
	    	// 		 The bounding box of the complete ellipse.
		    //  angle:
	    	// 		 The elliptic angle to be considered.
		    //  p:
	    	// 		 Container for the resulting point.	
		    	
		      angle = angle * Math.PI / 180.0;
		      var p ={};
		      p.x = rect.x + 0.5 * rect.width * (1 + Math.cos(angle));
		      p.y = rect.y + 0.5 * rect.height * (1 - Math.sin(angle));
		      return p;
		    },
		    
		    
		    arcStartPoint: function(rect/*dojox.gfx.Rectangle*/, startAngle){
		    // Summary:
		    // 		Returns the starting point of an arc (a partial ellipse).
		    //  rect:
		    // 		 The bounding box of the complete ellipse.
		    //  startAngle:
			// 		  The angle of the starting point in degrees (0 .. 360).
		    // return:
			// 		  The starting point.
		    	
		      var angle = startAngle;
		      var p = retrieveArcPointFromAngle(rect, angle);
		      
		      // now, EllipticAngle should return 0.0. However, due to rounding, it
		      // may return a value representing an angle close to 0.0. We can accept
		      // angles slightly larger than 0 degree, but not angles slightly smaller
		      // than 0 degree because they would create gaps between the arc and the
		      // point. Note that an angle smaller than 0 degree is calculated as
		      // a value around 359.
		      
		      var testAngle = ellipticAngle(rect, p, startAngle);
		      
		      if (testAngle > 180.0) {
		        // search a valid angle by choosing a delta offset
		        var delta = 0.0;
		        while (testAngle > 180.0) {
		          delta += 0.004;
		          angle = startAngle + delta;
		          p = retrieveArcPointFromAngle(rect, angle);
		          testAngle = ellipticAngle(rect, p, startAngle);
		        }
		        // try to reduce the delta offset until the angle gets invalid
		        var bestDelta = delta;
		        while (testAngle < 180.0) {
		          bestDelta = delta;
		          delta = delta/8;
		          angle = startAngle + delta;
		          p = retrieveArcPointFromAngle(rect, angle);
		          testAngle = ellipticAngle(rect, p, startAngle);
		        }
		        // now get the resulting point from the last valid angle
		        angle = startAngle + bestDelta;
		        p = retrieveArcPointFromAngle(rect, angle);
		      }
		      return p;
		    },
		    
		    
		    arcEndPoint: function(rect/*dojox.gfx.Rectangle*/, startAngle, deltaAngle){
		    // Summary:
		    // 		Returns the end point of an arc (a partial ellipse).
		    // rect:
		    // 		  The bounding box of the complete ellipse.
		    // startAngle:
		    // 		  The angle of the starting point in degrees (0 .. 360).
		    // deltaAngle:
		    // 		  The angle range of the arc from the starting point to the end point in degrees (0 .. 360).
		    // return:
		    // 		  The end point.
		    	
		      if (deltaAngle == 0.0)
		        return arcStartPoint(rect, startAngle);
		      
		      var angle = startAngle + deltaAngle;
		      var p = retrieveArcPointFromAngle(rect, angle);
		      
		      // now, EllipticAngle should return deltaAngle. However, due to rounding,
		      // it may return a value representing an angle close to deltaAngle. We can
		      // accept angles slightly smaller than deltaAngle, but not angles slightly
		      // larger than deltaAngle because they would create gaps between the arc
		      // and the point.
		      
		      var testAngle = ellipticAngle(rect, p, startAngle);
		      
		      if (testAngle > deltaAngle) {
		        // search a valid angle by choosing a delta offset
		        var delta = 0.0;
		        while (testAngle > deltaAngle) {
		          delta += 0.004;
		          angle = startAngle + deltaAngle - delta;
		          p = retrieveArcPointFromAngle(rect, angle);
		          testAngle = ellipticAngle(rect, p, startAngle);
		        }
		        // try to reduce the delta offset until the angle gets invalid
		        var bestDelta = delta;
		        while (testAngle < deltaAngle) {
		          bestDelta = delta;
		          delta = delta/8;
		          angle = startAngle + deltaAngle - delta;
		          p = retrieveArcPointFromAngle(rect, angle);
		          testAngle = ellipticAngle(rect, p, startAngle);
		        }
		        // now get the resulting point from the last valid angle
		        angle = startAngle + deltaAngle - bestDelta;
		        p = retrieveArcPointFromAngle(rect, angle);
		      }
		      return p;
		    },
		    
		    pointsEquals: function(p1,p2){
		    	return p1.x==p2.x && p1.y==p2.y;
		    },
		    
		    calcLinearSolution: function( a, b, result){
		    // Summary:
		    // 		 Calculates the solution of the equation a * x + b = 0.
		    //  a:
		    // 		 Parameter of the equation.
		    //  b:
		    // 		 Parameter of the equation.
		    //  result:
		    // 		 Container for the result. The array must have size 1.
		    // return:
		    // 		  The number of solutions. Return -1 if the equation is redundant, that is, if every x is a solution.
		    
		    	
		      if (a == 0.0) {
		        if (b == 0.0) return -1;
		        return 0;
		      }
		      result[0] = -b / a;
		      return 1;
		    },	
		    
		    calcQuadSolution: function( a, b, c, result) {
		    // Summary:
		    // 		 Calculates the solution of the equation a * x^2 + b * x + c = 0.
		    //  a:
		    // 		  Parameter of the equation.
		    //  b:
		    // 		  Parameter of the equation.
		    //  c:
		    // 		  Parameter of the equation.
		    //  result:
		    // 		  Container for the result. The array must have size 2.
		    // return:
		    // 		  The number of solutions. Return -1 if the equation is redundant, that is, if every x is a solution.
		    	
		    	
		      if (a == 0.0)
		        return this.calcLinearSolution(b, c, result);
		      
		      // solution is (+/- sqrt(b^2 - 4ac) - b)/(2a)
		      
		      var D = b * b - 4 * a * c;
		      if (D < 0) return 0;
		      if (D == 0) {
		        result[0] = -b / (2 * a);
		        return 1;
		      }
		      var sqrtD = Math.sqrt(D);
		      result[0] = (sqrtD - b) / (2 * a);
		      result[1] = (-sqrtD - b) / (2 * a);
		      return 2;
		    },	  
		    
		    calcCubicSolution: function(a, b, c, d, result){
		    // Summary:
		    // 		 Calculates the solution of the equation a * x^3 + b * x^2 + c * x + d = 0.
		    // a:
		    // 		  Parameter of the equation.
		    // b:
		    // 		  Parameter of the equation.
		    // c:
		    // 		  Parameter of the equation.
		    // d:
		    // 		  Parameter of the equation.
		    // result:
		    // 		  Container for the result. The array must have size 3.
		    // return:
		    // 		  The number of solutions. Return -1 if the equation is redundant, that is, if every x is a solution.
		    	
		    	
		      if (a == 0.0)
		        return this.calcQuadSolution(b, c, d, result);
		      
		      // We use a variant of the Cardan-Tartaglia formula (see any good
		      // mathematics formula collectione, e.g., Bronstein 1985, pp. 131-132)
		      
		      var oneThird = 1.0 / 3.0;
		      var z = b / (3 * a);
		      var r = 3 * a * a;
		      var p = (3 * a * c - b * b) / r;
		      var q = (2 * b * b * b - 9 * a * b * c + 9 * r * d) / (9 * r * a);
		      var sgn;
		      
		      // now, solve y^3 + p * y + q = 0  and x = y - z
		      
		      if (p == 0.0) {
		        // 1 solution: y = - q^(1/3)
		        sgn = (q >= 0.0 ? 1.0 : -1.0);
		        result[0] = -sgn * Math.pow(sgn * q, oneThird) - z;
		        return 1;
		      }
		      
		      var cubicPThird = p * p * p / 27;
		      var squareQHalf = q * q / 4;
		      var D = cubicPThird + squareQHalf;
		      
		      if (D < 0) {
		        // The formula of Cardan, Bombelli, and others.
		        // The background is basically the same as below, except that we
		        // need to get the square root of a negative number and hence end up
		        // in the complex number world. Luckily, the i-part of the complex
		        // numbers eliminate each other in the end result.
		        
		        // 3 solutions
		        var rho = Math.sqrt(-cubicPThird);
		        var phi = Math.acos(-q / (2 * rho));
		        sgn = (rho >= 0.0 ? 1.0 : -1.0);
		        var f = 2 * sgn * Math.pow(sgn * rho, oneThird);
		        result[0] = f * Math.cos(phi / 3) - z;
		        result[1] = f * Math.cos((phi + 2 * Math.PI) / 3) - z;
		        result[2] = f * Math.cos((phi + 4 * Math.PI) / 3) - z;
		        return 3;
		      } else {
		        // The original Cardan-Tartaglia formula. The background is this:
		        // (u + v)^3 - 3uv(u + v) - u^3 - v^3 = 0
		        // hence y = (u+v) is a solution iff p=-3uv and u^3+v^3+q = 0
		        // With v=-p/(3u) follows u^3-p^3/(27u^3)+q = 0
		        // that is u^6 + q u^3 - p^3/27 = 0
		        // With u1 = u^3 follows u1^2 + q u1 - p^3/27 = 0.
		        // This quadratic formula can be solved with the standard mechanism to u1,
		        // hence u and v can be obtained. The second solution can be found by
		        // factorizing the first solution.
		        
		        var u1 = (q > 0
		          ? // Avoid rounding errors due to cancellation
		          cubicPThird / (Math.sqrt(D) + q / 2)
		          : Math.sqrt(D) - q / 2);
		        sgn = (u1 >= 0.0 ? 1.0 : -1.0);
		        var u = sgn * Math.pow(sgn * u1, oneThird);
		        
		        // u cannot be zero, because p != 0. Only if p = 0 follows D = q/2
		        // hence u1 = 0 hence u = 0. But just to be sure of rounding problems,
		        // we repeat:
		        
		        if (u == 0.0) {
		          // see above, case p==0.0
		          sgn = (q >= 0.0 ? 1.0 : -1.0);
		          result[0] = -sgn * Math.pow(sgn * q, oneThird) - z;
		          return 1;
		        }
		        
		        var v = -p / (3 * u);
		        if (u == v) {
		          // 2 solutions
		          result[0] = u + v - z;
		          result[1] = -0.5 * (u + v) - z;
		          return 2;
		        } else {
		          // 1 solution
		          result[0] = u + v - z;
		          return 1;
		        }
		      }
		    },	  
		    
		    // --------------------------------------------------------------------------
			// Auxiliaries related to matrix
		    
		    multiplyVectorial: function(matrix,vector){
		    // Summary:
		    //		multiplies a 2x2 matrix towards a 2x1 vector
		    	var rta = [0,0];
		    	for(var i=0;i<2;i++){
		    		for(var j=0;j<2;j++){
		    			rta[i] = rta[i] + ( matrix[i][j] * vector[j]);
		    		}
		    	}
		    	return rta;
		    },
		    multiplyScalar: function(vector,scalar){
			    // Summary:
			    //		multiplies a matrix towards a scalar
			    	var rta = lang.clone(vector);
			    	for(var i=0;i<vector.length;i++){
			    			rta[i] = vector[i]* scalar;
			    	}
			    	return rta;
			},
			add: function(v1,v2){
			    // Summary:
			    //		adds a 2x2 matrix towards a 2x2 matrix
			    	var rta = [0,0];
			    		for(var j=0;j<2;j++){
			    			rta[j] = v1[j] + v2[j];
			    		}
			    	return rta;
			    },
			
			ellipseEndpointToCenterParameterization: function(p1,p2,fa,fs,rx,ry,alphaDegrees){
				//Summary:
			    //		Change the parameterization of an ellipse, from endpoint to center.
			    var	alpha = this.toRadians(alphaDegrees); 
				
				//Step 1: Compute (x1', y1') according to the formula
				var m1 = [[Math.cos(alpha),Math.sin(alpha)],[-Math.sin(alpha),Math.cos(alpha)]];
				var v1 = [(p1.x-p2.x)/2,(p1.y-p2.y)/2];
				var pt = this.multiplyVectorial(m1,v1);
				
				//Step 2: Compute (cX', cY') according to the formula
				var t1 = Math.pow(rx,2)*Math.pow(ry,2);
				var t2 = Math.pow(rx,2)*Math.pow(pt[1],2);
				var t3 = Math.pow(ry,2)*Math.pow(pt[0],2);
				var sqrt = Math.pow((t1 - t2 - t3)/(t2 + t3),(1/2));
				var v2 =[rx*pt[1]/ry,-ry*pt[0]/rx];
				var ct = this.multiplyScalar(v2,sqrt);//(cX', cY')
				
				//the - sign is chosen if fa = fs   
				if(fa==fs){
					ct = this.multiplyScalar(ct,-1);
				}
				
				//Step 3: Compute (cX, cY) from (cX', cY')
				var m2 = [[Math.cos(alpha),-Math.sin(alpha)],[Math.sin(alpha),Math.cos(alpha)]];
				var v3 = [(p1.x+p2.x)/2,(p1.y+p2.y)/2];
				var center = this.add(this.multiplyVectorial(m2,ct),v3);
				
				return {x:center[0],y:center[1]};
				
			},
			ellipticalAngle: function(startPoint,endPoint,center){
				var v1 = {x:startPoint.x-center.x,y:startPoint.y-center.y};
				var v2 = {x:endPoint.x-center.x,y:endPoint.y-center.y};
				return vectorsAngle(v1,v2);
			},
			vectorsAngle: function(v1,v2){ 
				var t1 = v1.x*v2.x+v1.y*v2.y;
				var t2 = this.vectorLenght(v1)*this.vectorLenght(v2);
				return Math.acos(t1/t2);
			},
			vectorLenght: function(v){
				return Math.pow(Math.pow(v.x,2)+Math.pow(v.y,2),1/2);
			},
			toDegrees: function(radian){
				return (360*radian)/(2*Math.PI);
			},
			toRadians: function(degrees){
				return (degrees*2*Math.PI)/360;
			},
			
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////    GFX SHAPES CLIPPING FUNCTIONS     ///////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			
		clipToShape: function(node,graph,shape,bounds,unusedPoint, connectionPoint, referencePoint,completeResult){	
				
				var result = [],resultPoint,numberOfResults = 0, clipConnectionPoint = {}, points, poli, 
					s, stype = shape.getShape ? shape.getShape().type : null; 
				clipConnectionPoint.x = connectionPoint.x;
				clipConnectionPoint.y = connectionPoint.y;
				
				if(stype === 'rect'){
					s = shape.getShape();
					points = [{x:s.x,y:s.y},{x:s.x+s.width,y:s.y},{x:s.x+s.width,y:s.y+s.height},{x:s.x,y:s.y+s.height},{x:s.x,y:s.y}];
					poli = this._transformPoints(shape/*node*/,graph,points);
					numberOfResults = this.lineIntersectsPolyPoints(referencePoint,clipConnectionPoint,poli,true,result);
				}else if(stype === 'circle' || stype === 'ellipse'){
					numberOfResults = this.lineIntersectsEllipse(referencePoint,clipConnectionPoint,bounds,result);
				}else if(stype === 'polyline'){
					points = shape.getShape().points;
					poli = this._transformPoints(shape/*node*/,graph,points);
					numberOfResults = this.lineIntersectsPolyPoints(referencePoint,clipConnectionPoint,poli,true,result);
				}else if(stype === 'path'){
					numberOfResults = this._clipOnPath(node,graph,shape,unusedPoint, clipConnectionPoint, referencePoint,result);
				}else if (shape instanceof Object && shape.width && shape.height){
					// workaround to deal with raw rectangle
					s = shape;
					points = [{x:s.x,y:s.y},{x:(s.x+s.width),y:s.y},{x:(s.x+s.width),y:(s.y+s.height)},{x:s.x,y:(s.y+s.height)},{x:s.x,y:s.y}];
					numberOfResults = this.lineIntersectsPolyPoints(referencePoint,clipConnectionPoint,points,true,result);
				}
				
				if(completeResult){
					completeResult.points = this._filterPoints(result,clipConnectionPoint, referencePoint);
					completeResult.numberOfResults = completeResult.points.length;
				}
				
				if(numberOfResults>0){
					// FIXME using the original results because the bounding box is not being calculated correctly
					//var resultPoint = this.bestClipPointOnRay(referencePoint,clipConnectionPoint,completeResult.points,completeResult.numberOfResults);
					
					resultPoint = this.bestClipPointOnRay(clipConnectionPoint,referencePoint,result,numberOfResults);
					return resultPoint;
				}else{
					return null;
				}
			},
			
			_filterPoints: function(points,p1,p2){
				var g = Geometry;
				var result = [];
				var rect = g.createRect(p1,p2);
				for(pn in points){
					var p = points[pn];
					if(g.containsPoint(rect,p)){
						result.push(p);
					}
				}
				return result;
			},
			
			_transformPoints: function(node,graph,points){
				// Summary:
				//		transform the given points, to the absolute graph coordinates
				
				var result = [];
				for(pn in points){
					var p = points[pn];
					p = this._transformPoint(node,graph,p);
					result.push(p);
				}
				return result;
			},
			
			_transformPoint: function(node,graph,point){
				// Summary:
				//		transform the given point, to the absolute graph coordinates
				var _m = matrix;
				//var p2 = _m.multiplyPoint(node.getTransform(), point);
				var p2 =  _m.multiplyPoint(node.getShapeToContainerTransform(graph), point);
				return p2;
			},
			
			_clipOnPath: function(node,graph,shape,unusedPoint, connectionPoint, referencePoint,intersections){
				// Summary:
				//		return the connection point, clipping to a Path shape.
				var segments = shape.segments;
				var lastPoint = this._transformPoint(shape/*node*/,graph,{x:0,y:0});
				var reflectionControlPoint = {};
				var firstPointPath = this._transformPoint(shape/*node*/,graph,{x:0,y:0});
				for(var index in segments){
					var segment = segments[index];
					var action = segment.action;
					var args = segment.args;
						if( action == 'M'){ //absolute move
							lastPoint = {x:segments[index].args[0],y:segments[index].args[1]};
							reflectionControlPoint = {}; 
							firstPointPath = lastPoint; continue;}
						if( action == 'm'){ //relative move
							lastPoint =  this._changeToAbsolute( {x:segments[index].args[0],y:segments[index].args[1]},lastPoint);
							reflectionControlPoint = {}; 
							firstPointPath = lastPoint; continue;}
						if( action == 'Z' || action == 'z' ){ // close path
							lastPoint = this._clipOnLinearPath(shape/*node*/,graph,lastPoint,firstPointPath,connectionPoint,referencePoint,reflectionControlPoint,intersections);
							continue;}
						if( action == 'L' ){//absolute line
							var p2 = {x:args[0],y:args[1]};
							lastPoint = this._clipOnLinearPath(shape/*node*/,graph,lastPoint,p2,connectionPoint,referencePoint,reflectionControlPoint,intersections);
							continue;}
						if( action == 'l' ){//relative line
							var p2 = this._changeToAbsolute({x:args[0],y:args[1]},lastPoint);
							lastPoint = this._clipOnLinearPath(shape/*node*/,graph,lastPoint,p2,connectionPoint,referencePoint,reflectionControlPoint,intersections);
							continue;}
						if( action == 'H' ){//horizontal absolute line
							var p2 =  {x:args[0],y:lastPoint.y};
							lastPoint = this._clipOnLinearPath(shape/*node*/,graph,lastPoint,p2,connectionPoint,referencePoint,reflectionControlPoint,intersections);
							continue;}
						if( action == 'h' ){//horizontal relative line
							var p2 = {x:args[0]+lastPoint.x,y:lastPoint.y};
							lastPoint = this._clipOnLinearPath(shape/*node*/,graph,lastPoint,p2,connectionPoint,referencePoint,reflectionControlPoint,intersections);
							continue;}
						if( action == 'V' ){//vertical absolute line
							var p2 = {x:lastPoint.x,y:args[0]};
							lastPoint = this._clipOnLinearPath(shape/*node*/,lastPoint,p2,connectionPoint,referencePoint,reflectionControlPoint,intersections);
							continue;}
						if( action == 'v' ){//vertical relative line
							p2 = {x:lastPoint.x,y:args[0]+lastPoint.y};
							lastPoint = this._clipOnLinearPath(shape/*node*/,graph,lastPoint,p2,connectionPoint,referencePoint,reflectionControlPoint,intersections);
							continue;}
						if( action == 'C' || action == 'c' || action == 'S' || action == 's' ){ // cubic bezier
							lastPoint = this._clipOnCubicPath(shape/*node*/,graph,segment, connectionPoint, referencePoint, lastPoint, reflectionControlPoint, intersections);
							continue;}
						if( action == 'Q' || action == 'q' || action == 'T' || action == 't'){ // quadratic bezier
							lastPoint = this._clipOnQuadraticPath(shape/*node*/,graph,segment, connectionPoint, referencePoint, lastPoint, reflectionControlPoint, intersections);
							continue;}
						if( action == 'A' || action == 'a' ){ 
							lastPoint = this._clipOnArcPath(shape/*node*/,graph,segment, connectionPoint, referencePoint, lastPoint, reflectionControlPoint, intersections);
							continue;}
				}
				return intersections.length;
			},
			
			_clipOnLinearPath: function(node,graph,p1,p2,connectionPoint,referencePoint,reflectionControlPoint,intersections){
				// Summary:
				//		return the connection point, clipping to a Linear Path shape.
				var crossPoint = {};
				
				if (this.lineIntersectsSegment(connectionPoint,referencePoint,this._transformPoint(node,graph,p1), this._transformPoint(node,graph,p2), crossPoint)) {
		            intersections.push(crossPoint);
				}
				reflectionControlPoint.action = 'l';
				return p2;
			},
			
			_clipOnQuadraticPath: function(node,graph,segment,connectionPoint,
																		referencePoint,lastPoint,reflectionControlPoint,intersections){
				// Summary:
				//		return the connection point, clipping to a Quadratic Bezier Path shape.
				var args = segment.args;
				var result = [];
				var p1;
				var p2;
				
				// DIFFERENCE BETWEEN Q (normal) AND T (smooth) 
				if( segment.action.toLowerCase() == 'q'){
					p1 = {x:args[0],y:args[1]};
					p2 = {x:args[2],y:args[3]};
				}else{ // case T
					p2 = {x:args[0],y:args[1]};
					if( reflectionControlPoint != {} && reflectionControlPoint.action.toLowerCase() == 'q' ){
						p1 = {x:lastPoint.x+reflectionControlPoint.x, y:lastPoint.y+reflectionControlPoint.y};
					}else{
						p1 = {x:lastPoint.x, y:lastPoint.y};
					}
				}
				
				// RELATIVE Transform
				if( segment.action == 'q'){
					p1 = this._changeToAbsolute(p1,lastPoint);
					p2 = this._changeToAbsolute(p2,lastPoint);
				}
				if( segment.action == 't'){
					p2 = this._changeToAbsolute(p2,lastPoint);
				}
				
				// set reflection point
				reflectionControlPoint.x = p2.x-p1.x;
				reflectionControlPoint.y = p2.y-p1.y;
				reflectionControlPoint.action = 'q';
				
				var points = [lastPoint,p1,p2];
				var controlPoints = this._transformPoints(node,graph,points);
				var n = this.lineIntersectsQuadSpline(referencePoint,connectionPoint,controlPoints,0,result);
				for(var index in result){
					intersections.push(result[index]);
				}
				return p2;
			},
			
			_clipOnCubicPath: function(node,graph,segment,connectionPoint,referencePoint,
																lastPoint,reflectionControlPoint,intersections){
				// Summary:
				//		return the connection point, clipping to a Cubic Bezier Path shape.
				
				var args = segment.args;
				var result = [];
				var p1;
				var p2;
				var p3;
				if( segment.action.toLowerCase() == 'c'){
					p1 = {x:args[0],y:args[1]};
					p2 = {x:args[2],y:args[3]};
					p3 = {x:args[4],y:args[5]};
				}else{ // case T
					p2 = {x:args[0],y:args[1]};
					p3 = {x:args[2],y:args[3]};
					if( reflectionControlPoint != {} && reflectionControlPoint.action.toLowerCase() == 'c' ){
						p1 = {x:lastPoint.x+reflectionControlPoint.x, y:lastPoint.y+reflectionControlPoint.y};
					}else{
						p1 = {x:lastPoint.x, y:lastPoint.y};
					}	
				}
				
				if( segment.action == 'c'){
					p1 = this._changeToAbsolute(p1,lastPoint);
					p2 = this._changeToAbsolute(p2,lastPoint);
					p3 = this._changeToAbsolute(p3,lastPoint);
				}
				if( segment.action == 's'){
					p2 = this._changeToAbsolute(p2,lastPoint);
					p3 = this._changeToAbsolute(p3,lastPoint);
				}
				
				reflectionControlPoint.x = p3.x-p2.x;
				reflectionControlPoint.y = p3.y-p2.y;
				reflectionControlPoint.action = 'c';
				
				var points = [lastPoint,p1,p2,p3];
				var controlPoints = this._transformPoints(node,graph,points);
				var n = this.lineIntersectsCubicSpline(referencePoint,connectionPoint,controlPoints,0,result);
				for(var index in result){
					intersections.push(result[index]);
				}
				return p3;
			},
			
			_clipOnArcPath:function(node,graph,segment, connectionPoint, referencePoint, 
															lastPoint, reflectionControlPoint, intersections){
				// Summary:
				//		return the connection point, clipping to a partial arc Path.
				var args = segment.args;
				var p2 = {x:args[5],y:args[6]};
				var rx = args[0];
				var ry = args[1];
				var	xAxisRotation = args[2];
				var largeArcFlag = args[3]; 
				var sweepFlag =	args[4];
				
				if(segment.action == 'a'){
					p2 = this._changeToAbsolute(p2,lastPoint);
				}
				var result = [];
				var n = this.lineIntersectsPartialEllipse(referencePoint,connectionPoint,rx,ry, 
					this._transformPoint(node,graph,lastPoint),
					this._transformPoint(node,graph,p2),largeArcFlag,sweepFlag,xAxisRotation,result);
				for(var index in result){
					intersections.push(result[index]);
				}
				
				reflectionControlPoint.action = 'a';
				
				return p2;
				
			},
			
			_changeToAbsolute: function(point, lastPoint){
				// Summary:
				//		return the given point, changing its relative coordinates to absolute, according to the last point.
				return {x: point.x+lastPoint.x, y:point.y+lastPoint.y}
			},		
			
			_eof:function(){}
	});
	
  return gu;
});
