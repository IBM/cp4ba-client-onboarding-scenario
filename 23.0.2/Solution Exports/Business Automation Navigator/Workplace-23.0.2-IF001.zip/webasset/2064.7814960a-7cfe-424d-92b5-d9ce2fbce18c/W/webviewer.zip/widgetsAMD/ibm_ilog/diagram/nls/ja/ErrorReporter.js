/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
// NLS_CHARSET=UTF-8

define({
	//-------------------------------------------------------
	// ErrorReporter internals
	//
	
	// Explanation: An unexpected internal error has occurred in the Dojo Diagrammer code.
	// User action: This is an internal error and the cause is not immediately known. If the error persists, consult the support pages.
	Unknown: "不明なエラーです。",
	// Explanation: The 'error' or 'warning' method of ibm_ilog.diagram.util.ErrorReporter has been called with an invalid identifier.
	// User action: Verify that identifiers passed to ibm_ilog.diagram.util.ErrorReporter methods are valid.
	InvalidErrorId: "ストリング \"${errorId}\" は有効なエラー ID ではありません。",
	// Explanation: The ibm_ilog.diagram.util.ErrorReporter.declareError method is called with an identifier that is already declared.
	// User action: Verify that the declared error identifier is not already declared.
	ErrorIdAlreadyDeclared: "エラー ID \"${errorId}\" は、既に登録されています。",

	
	//-------------------------------------------------------
	// Generic-JavaScript
	//
	// Explanation: A user-defined subclass of a Dojo Diagrammer base class does not define a required method.
	// User action: Verify that all required methods are declared in your subclass.
	SubclassResponsibility: "${methodName} は、サブクラスに実装されていなければなりません。",
	// Explanation: An object is null and it is expected to not be null.
	// User action: Verify that you provide an object that is not null for the object that is specified in the error message.
	NullPointerException:"${objectName} がヌルで検出されました。",
	// Explanation: An object is null and it is expected to not be null.
	// User action: Verify that you provide an object that is not null for the object that is specified in the error message. The error message also contains a hint to help you find the class that contains the error.
	NullPointerException2:"${objectName} がヌルで検出されました [ヒント: ${where}]。",
	// Explanation: An error that was caused by another nested error has occurred.
	// User action: Refer to the user action for the nested error whose identifier is contained in the error message.
	Wrapped:"${process}: でエラーがありました (${error})。",
	// Explanation: An unexpected argument value was passed to a function.
	// User action: The function name, expected value (or value range) and actual argument value are contained in the error message. Verify that the argument value is correct.
	UnexpectedArgument:"予期しない引数タイプまたは範囲です。",
	
	// Explanation: A function was called with an invalid number of arguments.
	// User action: The expected and actual number of arguments are contained in the error message. Verify that the number of arguments are correct.
	InvalidNumberOfArguments:"${numberOfArgs} が検出されましたが、想定されていたのは以下のいずれかです: ${options}",
	
	// Explanation: An unexpected value was returned by a function.
	// User action: The function name, expected return value type and actual return value type are contained in the error message. Verify that the returned value type is correct.
	UnexpectedReturnValueType: "予期されない戻り値タイプです。${functionName}() から想定されていたタイプ: ${expectedType}。取得タイプ: ${actualType}",


	//-------------------------------------------------------
	// Generic-Graph/Diagram
	//
	
	// Explanation: A function expects a graph element (for example, a node, link, or subgraph) but another type of object was found.
	// User action: Verify that a graph element is supplied.
	GraphElementExpected: "予期されたグラフ要素: グラフ、ノード、リンク、またはサブグラフ。", 

	
	//-------------------------------------------------------
	// DataStore
	//
	// Explanation: The Diagram widget processed a data item that is not contained in the data store specified as the nodesStore or linksStore attributes
	// User action: Verify that the data store contains the item that is specified as the nodesStore or linksStore attributes of the Diagram widget.
	NotInDataStore:"エンティティーがデータ・ストアにありません。",
	// Explanation: The nodesQuery or linksQuery attribute of the Diagram widget is specified as a string, and it should be an object.
	// User action: Verify that the nodesQuery or linksQuery attribute is an object and not a string.
	CannotUseAStringForAQuery:"保管照会文は、ストリングではなく、オブジェクトとして定義する必要があります。",
	// Explanation: The nodesStore attribute of the Diagram widget is not specified.
	// User action: Specify the nodesStore attribute on the Diagram widget.
	NodesStoreRequired:"ウィジェットは、ノード・ストアを定義する必要があります。",	
	// Explanation: The data store that is specified as the nodesStore or linksStore attribute does not implement the dojo.data.api.Indentity interface.
	// User action: Specify a data store that implements the dojo.data.api.Indentity interface.
	StoresMustSupportIdentity:"ストアは、フィーチャー 'dojo.data.api.Read' をサポートしなければなりません。",
	// Explanation: The data store that is specified as the nodesStore or linksStore attribute does not implement the dojo.data.api.Read interface.
	// User action: Specify a data store that implements the dojo.data.api.Read interface.
	StoresMustSupportRead:"ストアは、フィーチャー 'dojo.data.api.Read' をサポートしなければなりません。",
	
	// Explanation: An error occurred while loading the data store specified as the nodesStore attribute of the Diagram widget.
	// User action: The error message contains the the nested error. Correct the nested error.
	UnexpectedErrorOnNodesStoreFetch:"NodesStore フェッチ時にエラーが発生しました: (${errorString})",
	// Explanation: An error occurred while loading the data store specified as the linksStore attribute of the Diagram widget.
	// User action: The error message contains the the nested error. Correct the nested error.
	UnexpectedErrorOnLinksStoreFetch:"LinksStore フェッチ時にエラーが発生しました: (${errorString})",

	
	//-------------------------------------------------------
	// Overview
	//

	// Explanation: The diagram attribute of the Overview widget is not defined.
	// User action: Define the diagram attribute of the Overview widget.
	OverviewDiagramMissing:"概要ウィジェットには、ダイアグラム・ウィジェットが必要です (属性 'diagram'==${diagram})。",

	
	//-------------------------------------------------------
	// WAI
	//

	// Explanation: The internal Web Accessibility Initiative (WAI) node was not found for the given graph element.
	// User action: Use the createNode/createLink/createSubgraph methods of the diagram, not the graph methods to create elements in a diagram.
	MissingWaiNode:"WAI-ARIA ノードがグラフ要素: ${element} に対して見つかりませんでした。",

	//-------------------------------------------------------
	// ServerSideLayout
	//

	// Explanation: The specified graph layout algorithm is not supported for server-side layout.
	// User action: Use another graph layout algorithm that supports server-side layout, or use client-side graph layout.
	UnsupportedAlgorithm: "${algorithmClass} アルゴリズムは、サーバー・サイド・グラフ・レイアウトに対してサポートされていません。",  
	

	//-------------------------------------------------------
	// Interactors
	//
	// Explanation: The InteractorManager.push method was called while an interactor is already contained in the active stack.
	// User action: Do not push an interactor while an interactor is already contained in the active stack.
	RestrictedToOneInteractor:"アクティブなスタックにプッシュできるインタラクターは、1 つのみです。", 
	// Explanation: The InteractorManager.get method was called with an invalid interactor identifier.
	// User action: Verify that the identifier passed to the InteractorManager.get method is valid.
	InvalidInteractorId: "インタラクター ID ${interactorId} は無効です。", 
	// Explanation: An Interactor object attempted to connect to an invalid event name.
	// User action: Verify that the connection objects returned by the getDefaultConnections() method of the interactor contain valid event names.
	InvalidInteractorEvent: "無効なインタラクター・イベント: ${name}", 
	// Explanation: An invalid filter definition was defined in an interactor object.
	// User action: Verify that the connection objects returned by the getDefaultConnections() method of the interactor contain valid filter definitions.
	InvalidInputFilterSpec: "イベント \"${name}\" に対してインタラクター入力フィルター仕様が無効です。",  


	//-------------------------------------------------------
	// UI events/connections
	//
	// Explanation: An internal connection is made to an event while another connection is still active.
	// User action: This is an internal error. If the error persists, consult the support pages.
	ConnectionStillActive: "接続 ${id} がまだ接続されています。", 
	// Explanation: An internal connection to an event has failed.
	// User action: This is an internal error. If the error persists, consult the support pages.
	EventConnectionFailed: "イベント: ${eventName} に接続できませんでした。", 


	//-------------------------------------------------------
	// Viewport
	//
	// Explanation: The maximum zoom is set to a value less than the minimum zoom.
	// User action: Set the maximum zoom to a value greater than the minimum zoom.
	MaxZoomBelowMin: "最大ズームを最小ズーム以下に設定することはできません。", 
	// Explanation: The minimum zoom is set to a value greater than the maximum zoom.
	// User action: Set the minimum zoom to a value less than the maximum zoom.
	MinZoomAboveMax: "最小ズームを最大ズーム以上に設定することはできません。", 

	
	//-------------------------------------------------------
	// User-defined functions
	//
	// Explanation: An error occurred while starting the user-defined drop function.
	// User action: The error message contains the error that occurred in the user-defined drop function. Correct this error. 
	DropUserFunctionError: "ユーザー除去機能でエラーが発生しました: ${error}",
	// Explanation: An error occurred while starting the user-defined undo function.
	// User action: The error message contains the error that occurred in the user-defined undo function. Correct this error. 
	UndoUserActionError:"${action} での適用時にユーザー・アクションの取り消しでエラーが発生しました: (${error})。",
	
	//-------------------------------------------------------
	// Swim lanes
	
	// Explanation: An attempt to create a SwimLane element was made while the GFX layout feature is not enabled.
	// User action: Enable GFX layout by specifying 'gfxLayout: true' in the global djConfig object.
	SwimLanesRequireGfxLayout: "スイムレーンが使用される場合 GFX レイアウトが使用可能になっていなければなりません (djConfig.useGfxLayout=true)",
	
	//-------------------------------------------------------
	// Dojo
	
	// Explanation: A Dojo Diagrammer feature that requires at least a specific version of Dojo was used.
	// User action: Configure the application to use at least the specified version of Dojo, or do not use the feature.
	UnsupportedDojoFeature: "このフィーチャーは、このバージョンの Dojo. Requires Dojo ${version} では使用不可です。",	
	
	//-------------------------------------------------------
	LASTERRORCODE: ""
	
});
