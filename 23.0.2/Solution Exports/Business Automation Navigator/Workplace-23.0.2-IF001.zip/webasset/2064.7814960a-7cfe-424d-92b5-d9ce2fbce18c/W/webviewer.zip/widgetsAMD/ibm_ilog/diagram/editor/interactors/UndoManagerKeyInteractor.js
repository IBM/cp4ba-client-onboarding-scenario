/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"../../interactors/Interactor"
], function(
declare,
Interactor
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var UndoManagerKeyInteractor =
declare("ibm_ilog.diagram.editor.interactors.UndoManagerKeyInteractor", [Interactor], {
	//summary:
	//		This interactor manages the UndoManager through the keyboard interaction.
	//		This interactor has 2 connections: undo, redo.
	
	_diagram: null,
	initialize: function (diagram) {
	// summary:
    //		initialize the new instance.
    // diagram: ibm_ilog.diagram.widget.Diagram
    //		the associated diagram.		
		this._diagram = diagram;
		return this._initialize();
	},
	undo: function(e){
		// summary:
	    //		this methods calls the UndoManager undoAction function.
		this._diagram.getUndoManager().undoAction();
	},
	redo: function(e){
		// summary:
	    //		this methods calls the UndoManager redoAction function.
		this._diagram.getUndoManager().redoAction();
	},
	getKeyInteractorId: function(){
		// summary:
	    //		returns the Interactor Id
		return UndoManagerKeyInteractor.KeyInteractorId;
	},
	getDefaultConnections: function () {
		// summary:
		//		returns the default event mapping
		
		return {
			redo: {
				hotKey: 89,//  letter Y
				connectTo: "redo",
				filter: this._buildInputFilter({ctrl:true,shift:false,alt:false})
			}, undo: {
				hotKey: 90,//  letter Z
				connectTo: "undo",
				filter: this._buildInputFilter({ctrl:true,shift:false,alt:false})
			}
		};
	}
});

UndoManagerKeyInteractor.KeyInteractorId = "UndoManager";

return UndoManagerKeyInteractor;

});
