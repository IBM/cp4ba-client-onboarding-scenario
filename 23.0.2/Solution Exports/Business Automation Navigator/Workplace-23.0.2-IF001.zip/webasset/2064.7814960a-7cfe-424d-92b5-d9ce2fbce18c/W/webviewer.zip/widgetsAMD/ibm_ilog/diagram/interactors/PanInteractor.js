/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"./DragInteractor",
"../util/Geometry"
],
function(
declare,
DragInteractor,
g
){

/*=====
var DragInteractor = ibm_ilog.diagram.interactors.DragInteractor;
=====*/

var PanInteractor =
declare("ibm_ilog.diagram.interactors.PanInteractor", [DragInteractor], {
	//
	//	summary:
	//		A PanInteractor controls the process of viewport panning
	//
	//
	//	_panViewStart: Rect
	//		initial position of the view rectangle when the current pan process started
	//	
	_panViewLast: null,

	_dragCursor: "move",

	_getInitialEventSource: function () {
		return this._viewport.getEventSource();
	},

	getDefaultConnections: function () {
		//
		//	summary:
		//		returns the default event mapping
		//
		var cs = this.inherited(arguments);
		cs.start.filter = this._buildInputFilter({shift:true,button:0});
		return cs;
	},

	_dragPreStart: function (e) {

		this.inherited(arguments);

		this._firstViewRect = this._viewport.getViewRect();

		var v = this._viewport;
	},

	_dragMove: function (e) {

		this.inherited(arguments);

		var v = this._viewport;

		var viewMovement = g.mulPoint(this._totalDelta, -1 / v.getZoom()); // scale delta to zoom level to get delta in model coords
		this._panViewLast = v.setViewRect(g.moveRect(this._firstViewRect, viewMovement), {instant:true});
	},

	_dragEnd: function (e) {
		var v = this._viewport;

		this.inherited(arguments);
	},

	_dragTouchPreStart: function (e) {

		this.inherited(arguments);

		this._firstViewRect = this._viewport.getViewRect();

	},

	_dragTouchMove: function (e) {
		this.inherited(arguments);
		if (e.touches.length > 1){
			return false;
		}
		
		var v = this._viewport;

		var viewMovement = g.mulPoint(this._totalDelta, -1 / v.getZoom()); // scale delta to zoom level to get delta in model coords
		this._panViewLast = v.setViewRect(g.moveRect(this._firstViewRect, viewMovement), {instant:true});
	},

	_dragTouchEnd: function (e) {
		this.inherited(arguments);
		if (e.touches.length > 0){
			this._firstViewRect = this._viewport.getViewRect();			
			return false;
		}
	},

	_setOnShapes: function ( /*Boolean*/ b) {
		// [AV] TODO this method needs refactoring
		if (b) {
			// background and shapes
			this._connections.start.src = this._viewport.getEventSource();
		} else {
			// only background
			this._connections.start.src = this._viewport.getEventSourceBackground();
		}
	},

	setOnShapes: function ( /*Boolean*/ b) {
		this._setOnShapes(b);
		this.reactivate();
	}
});

return PanInteractor;

});
