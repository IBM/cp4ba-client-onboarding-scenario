/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
// NLS_CHARSET=UTF-8

define({
	//-------------------------------------------------------
	// ErrorReporter internals
	//
	
	// Explanation: An unexpected internal error has occurred in the Dojo Diagrammer code.
	// User action: This is an internal error and the cause is not immediately known. If the error persists, consult the support pages.
	Unknown: "不明錯誤。",
	// Explanation: The 'error' or 'warning' method of ibm_ilog.diagram.util.ErrorReporter has been called with an invalid identifier.
	// User action: Verify that identifiers passed to ibm_ilog.diagram.util.ErrorReporter methods are valid.
	InvalidErrorId: "字串 ${errorId}\" 不是有效的錯誤 ID。",
	// Explanation: The ibm_ilog.diagram.util.ErrorReporter.declareError method is called with an identifier that is already declared.
	// User action: Verify that the declared error identifier is not already declared.
	ErrorIdAlreadyDeclared: "錯誤 ID \"${errorId}\" 已登錄。",

	
	//-------------------------------------------------------
	// Generic-JavaScript
	//
	// Explanation: A user-defined subclass of a Dojo Diagrammer base class does not define a required method.
	// User action: Verify that all required methods are declared in your subclass.
	SubclassResponsibility: "${methodName} 必須在子類別中實作。",
	// Explanation: An object is null and it is expected to not be null.
	// User action: Verify that you provide an object that is not null for the object that is specified in the error message.
	NullPointerException:"發現 ${objectName} 是空值。",
	// Explanation: An object is null and it is expected to not be null.
	// User action: Verify that you provide an object that is not null for the object that is specified in the error message. The error message also contains a hint to help you find the class that contains the error.
	NullPointerException2:"發現 ${objectName} 是空值 [提示：${where}]。",
	// Explanation: An error that was caused by another nested error has occurred.
	// User action: Refer to the user action for the nested error whose identifier is contained in the error message.
	Wrapped:"${process} 發生錯誤：(${error})。",
	// Explanation: An unexpected argument value was passed to a function.
	// User action: The function name, expected value (or value range) and actual argument value are contained in the error message. Verify that the argument value is correct.
	UnexpectedArgument:"非預期的引數類型或範圍。",
	
	// Explanation: A function was called with an invalid number of arguments.
	// User action: The expected and actual number of arguments are contained in the error message. Verify that the number of arguments are correct.
	InvalidNumberOfArguments:"找到 ${numberOfArgs} 但預期為其中一個 ${options} ",
	
	// Explanation: An unexpected value was returned by a function.
	// User action: The function name, expected return value type and actual return value type are contained in the error message. Verify that the returned value type is correct.
	UnexpectedReturnValueType: "非預期的回覆值類型。預期來自 ${functionName}():${expectedType} 的類型。取得：${actualType}",


	//-------------------------------------------------------
	// Generic-Graph/Diagram
	//
	
	// Explanation: A function expects a graph element (for example, a node, link, or subgraph) but another type of object was found.
	// User action: Verify that a graph element is supplied.
	GraphElementExpected: "預期的圖形元素：圖形、節點、鏈結或子圖形。", 

	
	//-------------------------------------------------------
	// DataStore
	//
	// Explanation: The Diagram widget processed a data item that is not contained in the data store specified as the nodesStore or linksStore attributes
	// User action: Verify that the data store contains the item that is specified as the nodesStore or linksStore attributes of the Diagram widget.
	NotInDataStore:"實體不在資料儲存庫中。",
	// Explanation: The nodesQuery or linksQuery attribute of the Diagram widget is specified as a string, and it should be an object.
	// User action: Verify that the nodesQuery or linksQuery attribute is an object and not a string.
	CannotUseAStringForAQuery:"您必須將儲存查詢定義為物件，而不是字串。",
	// Explanation: The nodesStore attribute of the Diagram widget is not specified.
	// User action: Specify the nodesStore attribute on the Diagram widget.
	NodesStoreRequired:"小組件需要定義節點儲存庫。",	
	// Explanation: The data store that is specified as the nodesStore or linksStore attribute does not implement the dojo.data.api.Indentity interface.
	// User action: Specify a data store that implements the dojo.data.api.Indentity interface.
	StoresMustSupportIdentity:"儲存庫必須支援 'dojo.data.api.Read' 特性。",
	// Explanation: The data store that is specified as the nodesStore or linksStore attribute does not implement the dojo.data.api.Read interface.
	// User action: Specify a data store that implements the dojo.data.api.Read interface.
	StoresMustSupportRead:"儲存庫必須支援 'dojo.data.api.Read' 特性。",
	
	// Explanation: An error occurred while loading the data store specified as the nodesStore attribute of the Diagram widget.
	// User action: The error message contains the the nested error. Correct the nested error.
	UnexpectedErrorOnNodesStoreFetch:"NodesStore 提取期間發生錯誤：(${errorString})",
	// Explanation: An error occurred while loading the data store specified as the linksStore attribute of the Diagram widget.
	// User action: The error message contains the the nested error. Correct the nested error.
	UnexpectedErrorOnLinksStoreFetch:"LinksStore 提取期間發生錯誤：(${errorString})",

	
	//-------------------------------------------------------
	// Overview
	//

	// Explanation: The diagram attribute of the Overview widget is not defined.
	// User action: Define the diagram attribute of the Overview widget.
	OverviewDiagramMissing:"「概觀」小組件需要「圖表」小組件（屬性 'diagram'==${diagram}）。",

	
	//-------------------------------------------------------
	// WAI
	//

	// Explanation: The internal Web Accessibility Initiative (WAI) node was not found for the given graph element.
	// User action: Use the createNode/createLink/createSubgraph methods of the diagram, not the graph methods to create elements in a diagram.
	MissingWaiNode:"找不到圖形元素 ${element} 的 WAI-ARIA 節點",

	//-------------------------------------------------------
	// ServerSideLayout
	//

	// Explanation: The specified graph layout algorithm is not supported for server-side layout.
	// User action: Use another graph layout algorithm that supports server-side layout, or use client-side graph layout.
	UnsupportedAlgorithm: "伺服器端圖形佈置不支援 ${algorithmClass} 演算法。",  
	

	//-------------------------------------------------------
	// Interactors
	//
	// Explanation: The InteractorManager.push method was called while an interactor is already contained in the active stack.
	// User action: Do not push an interactor while an interactor is already contained in the active stack.
	RestrictedToOneInteractor:"只能將一個互動器推送到作用中的堆疊中。", 
	// Explanation: The InteractorManager.get method was called with an invalid interactor identifier.
	// User action: Verify that the identifier passed to the InteractorManager.get method is valid.
	InvalidInteractorId: "互動器 ID ${interactorId} 無效。", 
	// Explanation: An Interactor object attempted to connect to an invalid event name.
	// User action: Verify that the connection objects returned by the getDefaultConnections() method of the interactor contain valid event names.
	InvalidInteractorEvent: "互動器事件無效：${name}", 
	// Explanation: An invalid filter definition was defined in an interactor object.
	// User action: Verify that the connection objects returned by the getDefaultConnections() method of the interactor contain valid filter definitions.
	InvalidInputFilterSpec: "事件 \"${name}\" 的互動器輸入過濾規格無效",  


	//-------------------------------------------------------
	// UI events/connections
	//
	// Explanation: An internal connection is made to an event while another connection is still active.
	// User action: This is an internal error. If the error persists, consult the support pages.
	ConnectionStillActive: "連線 ${id} 仍然連接中。", 
	// Explanation: An internal connection to an event has failed.
	// User action: This is an internal error. If the error persists, consult the support pages.
	EventConnectionFailed: "無法連接事件：${eventName}。", 


	//-------------------------------------------------------
	// Viewport
	//
	// Explanation: The maximum zoom is set to a value less than the minimum zoom.
	// User action: Set the maximum zoom to a value greater than the minimum zoom.
	MaxZoomBelowMin: "縮放上限不能設為低於縮放下限。", 
	// Explanation: The minimum zoom is set to a value greater than the maximum zoom.
	// User action: Set the minimum zoom to a value less than the maximum zoom.
	MinZoomAboveMax: "縮放下限不能設為高於縮放上限。", 

	
	//-------------------------------------------------------
	// User-defined functions
	//
	// Explanation: An error occurred while starting the user-defined drop function.
	// User action: The error message contains the error that occurred in the user-defined drop function. Correct this error. 
	DropUserFunctionError: "除去使用者函數時發生錯誤：${error}",
	// Explanation: An error occurred while starting the user-defined undo function.
	// User action: The error message contains the error that occurred in the user-defined undo function. Correct this error. 
	UndoUserActionError:"在套用於 ${action} 時，復原使用者動作發生錯誤：(${error})。",
	
	//-------------------------------------------------------
	// Swim lanes
	
	// Explanation: An attempt to create a SwimLane element was made while the GFX layout feature is not enabled.
	// User action: Enable GFX layout by specifying 'gfxLayout: true' in the global djConfig object.
	SwimLanesRequireGfxLayout: "使用泳道時 (djConfig.useGfxLayout=true)，必須啟用 GFX 佈置",
	
	//-------------------------------------------------------
	// Dojo
	
	// Explanation: A Dojo Diagrammer feature that requires at least a specific version of Dojo was used.
	// User action: Configure the application to use at least the specified version of Dojo, or do not use the feature.
	UnsupportedDojoFeature: "這項特性無法用於這個版本的 Dojo。需要 Dojo ${version}。",	
	
	//-------------------------------------------------------
	LASTERRORCODE: ""
	
});

