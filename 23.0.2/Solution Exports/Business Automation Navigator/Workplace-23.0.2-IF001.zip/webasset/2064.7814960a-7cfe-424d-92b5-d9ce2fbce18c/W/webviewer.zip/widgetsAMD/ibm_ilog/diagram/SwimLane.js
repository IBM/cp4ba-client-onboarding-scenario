/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"./main",
"dojo/_base/config", "dojo/_base/declare", "dojo/_base/lang",
"dojox/gfx", "dojox/gfx/matrix",
"./templating", "./templates/templates", "./Subgraph",
"./gfxlayout/CanvasLayout",
"./util/Batch", "./util/ErrorReporter"
],
function(iid,
config, declare, lang,
gfx, matrix,
templating, templates, Subgraph, CanvasLayout, Batch, ErrorReporter){

/*=====
Subgraph = ibm_ilog.diagram.Subgraph;
=====*/

var SwimLane =
declare("ibm_ilog.diagram.SwimLane", [Subgraph], {
	// summary:
	//		Represents a swim lane in a Dojo Diagrammer graph.
	// description:
	//		The <code>SwimLane</code> object is a special type of <code>Subgraph</code>
	//		used to divide a diagram into horizontal or vertical "stripes" that typically
	//		represent the different participants in a business process or workflow diagram.
	//		The differences with a plain <code>Subgraph</code> object are:
	//		<ul>
	//		  <li>
	//		    The swim lane has its own position and size, it does not adapt automatically to its contents.
	//		  </li>
	//		  <li>
	//		    The position and orientation of the title bar can be changed using the <code>setVertical()</code>
	//		    and <code>setRightToLeft()</code> methods.
	//		  </li>
	//		  <li>
	//		    Nested swim lanes (that is, swim lanes contained in another swim lane) can be automatically
	//		    stacked inside their parent lane (see <code>setStackSublanes</code>).
	//		  </li>
	//		</ul>
	
	_vertical: false,
	_rightToLeft: false,
	_stackSublanes: true,
	
	_isIBMDiagramSwimLane: true,
	_flattenForGL: true,
	_noTranslate: true,
	
	constructor: function()
	{
		if(!config.useGfxLayout)
			ErrorReporter.error("SwimLanesRequireGfxLayout");
		this._explicitSize = { width: 100, height: 100};
	},
	
    applyTemplate: function(/*String||Object*/template, /*Object||ibm_ilog.diagram.data.dtlbinding.BoundContext*/context) {
        // summary:
        //     Applies the specified template on this subgraph.
        
        var c = this.inherited(arguments);
        this._template = template;
        return c;
    },
	
	_subgraphInitialize: function()
	{
		this.inherited(arguments);
		if(this._graph){
			this._graph.setLayout(new _SwimLaneLayout());
			this._graph._flattenForGL = true; // we mark both the subgraph and its graph for efficiency
			var g = this._graph.getParent();
			if(g.declaredClass == gfx.Group.prototype.declaredClass)
				g.setLayout(new _GroupLayout());
		}
	},
	
	setVertical: function(vertical)
	{
		// summary:
		//		Sets the orientation of the swim lane.
		// description:
		//		Sets the orientation of the swim lane.
		// vertical: Boolean:
		//		If <code>true</code>, the title of the swim lane will be displayed at the top of the graph.
		//		If <code>false</code>, the title of the swim lane will be displayed (vertically)
		//		on the left (if <code>isRightToLeft()</code> is <code>false</code>) or
		//		on the right (if <code>isRightToLeft()</code> is <code>true</code>)
		//		of the graph.
		
		if(vertical != this._vertical){
			this._vertical = vertical;
			this.applyTemplate(this._template);
		}
        return this;
	},
	
	getVertical: function()
	{
		// summary:
		//		Gets the orientation of the swim lane.
		// description:
		//		Gets the orientation of the swim lane (see <code>setVertical</code>).
		
		return this._vertical;
	},
	
	setRightToLeft: function(rightToLeft)
	{
		// summary:
		//		Sets the horizontal direction of the swim lane.
		// description:
		//		Sets the horizontal direction of the swim lane.
		//		
		//		This property has an effect only if <code>isVertical()</code> is <code>false</code>.
		// rightToLeft: Boolean:
		//		If <code>false</code>, the title of the swim lane will be displayed on the left of the graph.
		//		If <code>rightToLeft</code> is <code>true</code>, the title of the swim lane
		//		will be displayed on the right of the graph.
		
		if(rightToLeft != this._rightToLeft){
			this._rightToLeft = rightToLeft;
			this.applyTemplate(this._template);
		}
        return this;
	},
	
	getRightToLeft: function()
	{
		// summary:
		//		Gets the horizontal direction of the swim lane.
		// description:
		//		Gets the horizontal direction of the swim lane (see <code>setRightToLeft()</code>.
		
		return this._rightToLeft;
	},
	
	setStackSublanes: function(stack)
	{
		// summary:
		//		Sets the sub-lane stacking mode.
		// description:
		//		Sets the sub-lane stacking mode.
		//		
		//		Sub-lanes (that is, <code>SwimLane</code> objects contained in this <code>SwimLane</code>)
		//		are stacked vertically if <code>getVertical()</code> is <code>false</code>, or
		//		horizontally if <code>getVertical()</code> is <code>true</code>.
		// stack: Boolean:
		//		If <code>true</code>, sub-lanes will be stacked, otherwise they will be left to their
		//		current position and size.
		
		if(stack != this._stackSublanes){
			this._stackSublanes = stack;
			this.invalidate();
		}
        return this;
	},
	
	getStackSublanes: function()
	{
		// summary:
		//		Gets the sub-lane stacking mode.
		// description:
		//		Gets the sub-lane stacking mode (see <code>setStackSublanes()</code>).
		
		return this._stackSublanes;
	},
	
	getNested: function()
	{
		// summary:
		//		Returns true if this swim lane is a nested lane contained in another swim lane.
		
		var parent = this.getParent();
		return parent && parent._owningSubgraph && parent._owningSubgraph._isIBMDiagramSwimLane;
	},
	
	canCollapse: function() {
		// summary:
		//		Returns false if this swim lane is nested.
		// returns:
		//		True if this SwimLane is not nested, false if it is nested.
		
		return !this.getNested(); // Boolean
	},
	
    applyLayout: function(rect)
	{
		this.inherited(arguments);
		if (this._graphRect) {
			var gr = this._graphRect.getBoundingBox();
			var t = this._graphRect.getShapeToContainerTransform(this._graph);
			gr = t.transformRectangle(gr);
			this._graph.setMoveLimits(gr);
		}
	}
});

// The default template for SwimLanes
SwimLane.defaultTemplate = iid.declareTemplate(templates.defaultSwimLaneTemplate);

SwimLane.nodeType = gfx.Group.nodeType;
SwimLane.defaultShape = {
    type: 'swimlane'
};

templating.declareBindableProperty(SwimLane, "poolSpacing", 20);

/*=====
var CanvasLayout = ibm_ilog.diagram.gfxlayout.CanvasLayout;
=====*/

var _SwimLaneLayout =
declare('ibm_ilog.diagram._SwimLaneLayout', CanvasLayout, {
	// summary:
	//		A private subclass of CanvasLayout used in swim lanes to stack sub-lanes.
	// tags:
	//		private
	
    layoutChildren: function(contBounds) {
        var children = this._container.children, count = children.length, o, i;
        if (count === 0)
            return;
        var sl = this._container._owningSubgraph;
        var pos = 0;
        for (i=0; i<count;++i) {
            var child  = children[i];
            // Process only panels (ie a Group with a Layout)
            if (!child.children || !child.getLayout())
                continue;
			var sz = child._isIBMDiagramSwimLane ?
						child.getExplicitSize() :
						child.getPreferredSize();
            var x = 0, y = 0, w = sz.width, h = sz.height;
            // Stack sub-lanes if required.
            if(sl && sl._stackSublanes && child._isIBMDiagramSwimLane){
				var graphRect = sl._graphRect || sl._graphBackground;
           		var gbb = graphRect.getBoundingBox();
            	if(sl._vertical){
            		x = pos;
            		h = gbb.height;
            		pos += w;
            	} else {
            		y = pos;
            		w = gbb.width;
            		pos += h;
            	}
            	child.setExplicitSize({width:w, height:h});
            	var gt = sl._graph.getTransform();
            	if(gt){
            		var p = {x:x, y:y};
            		p = gt.inverse().transformPoint(p);
            		x = p.x; y = p.y;
            	}
            	//child.move(x, y);
				// move the top-left point of the child lane's base shape instead,
				// for the case when nodes are outside of the swim lane
				var baseShape = child.getBaseShape();
		        var rect = baseShape.getBoundingBox();
				var t = baseShape.getShapeToContainerTransform(this._container);
				rect = t.transformRectangle(rect);
				var dx = x - rect.x;
				var dy = y - rect.y;
				if(dx !== 0 || dy !== 0)
					child.applyLeftTransform(matrix.translate(dx, dy));
            }
            child.layout({x:0,y:0,width:w,height:h});
        }
    }
});

var _GroupLayout =
declare('ibm_ilog.diagram._GroupLayout', CanvasLayout, {
	// summary:
	//		A private subclass of Layout used in swim lanes...
	// tags:
	//		private
	
    layoutChildren: function(contBounds) {
        var children = this._container.children, count = children.length, o, i;
        if (count === 0)
            return;
        for (i=0; i<count;++i) {
            var child  = children[i];
            // Process only panels (ie a Group with a Layout)
            if (!child.children || !child.getLayout())
                continue;
            var sz = child.getPreferredSize();
            child.layout({x:0,y:0,width:sz.width,height:sz.height});
        }
    }
});

lang.mixin(SwimLane, {
	
	// automaticHierarchicalLayout: boolean
	//		Controls whether swim lanes are automatically laid out when a Hierarchical layout
	//		is performed on the graph. If the flag is set to false, the beforeHierarchicalLayout/afterHierarchicalLayout
	//		methods are called respectively before and after the layout, to let applications implement their own layout.
	automaticHierarchicalLayout: true,
	
	beforeHierarchicalLayout: function(graph, hl){
		// summary:
		//		Called if automaticHierarchicalLayout is set to false before a Hierarchical layout
		//		is performed on the graph.
		// description:
		//		Called if automaticHierarchicalLayout is set to false before a Hierarchical layout
		//		is performed on the graph. This method must return an  array of swim lanes, that will
		//		be passed back to afterHierarchicalLayout.
		// graph: ibm_ilog.diagram.Graph
		//		The toplevel graph on which the layout is performed.
		// hl: ibm_ilog.graphlayout.hierarchical.HierarchicalLayout
		//		The hierarchical layout that is being performed.
		// returns:
		//		An array of Swimlane objects that will be passed back to afterHierarchicalLayout.
		return []; // Array
	},
	
	afterHierarchicalLayout: function(graph, hl, swimlanes){
		// summary:
		//		Called if automaticHierarchicalLayout is set to false after a Hierarchical layout
		//		is performed on the graph.
		// description:
		//		Called if automaticHierarchicalLayout is set to false after a Hierarchical layout
		//		is performed on the graph. This method should perform a custom layout on the swim lanes.
		// graph: ibm_ilog.diagram.Graph
		//		The toplevel graph on which the layout is performed.
		// hl: ibm_ilog.graphlayout.hierarchical.HierarchicalLayout
		//		The hierarchical layout that is being performed.
		// swimlanes: Array
		//		The array of SwimLane obejcts that was returned by beforeHierarchicalLayout.
	},
	
	_beforeLayout: function(graph, hl, Direction, HierarchicalNodeGroup, HierarchicalSwimLaneConstraint)
	{
		// summary:
		//		Creates HierarchicalSwimLaneConstraint objects for all swim lanes in the graph.
		
		if (!this.automaticHierarchicalLayout) {
			return this.beforeHierarchicalLayout(graph, hl);
		}
		
		// collect all swim lanes
		var swimlanes = [];
		this._getSwimLanes(graph, swimlanes);
		
		var n = swimlanes.length;
		
		if(n == 0)
			return null;
		
		var l = swimlanes[0];

		var dir = l._vertical ?
				Direction.BOTTOM :
					(l._rightToLeft ?
							Direction.LEFT :
								Direction.RIGHT);
		
		if(dir == Direction.RIGHT)
			swimlanes.reverse();
		
		hl.setFlowDirection(dir);
		
		// create a swim lane constraint for each lane
		for(var i = 0; i < n; i++){
			l = swimlanes[i];
			
			// add all nodes in a node group
			var g = new HierarchicalNodeGroup();
			var children = l._graph.children;
			for(var j = 0; j < children.length; j++){
				var node = children[j];
				if(node._isIBMDiagramNode && !node._isIBMDiagramSwimLane)
					g.add(node);
			}
			
			// compute margins
			var m = l.getGraphMargin();
			var wm = m;
			var em = m;
			if(l._isFirstLaneInPool || l._isLastLaneInPool){
				m = l.getPoolSpacing()/2;
				if(l._vertical || l._rightToLeft){
					if(l._isFirstLaneInPool)
						wm += m;
					if(l._isLastLaneInPool)
						em += m;
				} else {
					if(l._isFirstLaneInPool)
						em += m;
					if(l._isLastLaneInPool)
						wm += m;
				}
			}
			
			// create the constraint
			var c = new HierarchicalSwimLaneConstraint(g, 0, i, wm, em);
			l._hierarchicalConstraint = c;
			hl.addConstraint(c);
		}
		
		// return the swim lane (or null if empty)
		return swimlanes.length > 0 ? swimlanes : null;
	},
	
	_getSwimLanes: function(graph, list)
	{
		var children = graph.children;
		var n = children.length;
		for(var i = 0; i < n; i++){
			var child = children[i];
			if(child._isIBMDiagramSwimLane){
				// expand all swim lanes, collapsed lanes are not well supported by graph layout.
				if(child.isCollapsed())
					child.setCollapsed(false, false);
				var old = list.length;
				// first see if it has nested swim lanes in it:
				if (child._graph)
					this._getSwimLanes(child._graph, list);
				if(list.length == old) // no: return it in the list.
					list.push(child);
				else {
					// don't stack lanes automatically during layout
					child._oldStackSublanes = child._stackSublanes;
					child.setStackSublanes(false);
				}
				// mark the first and last lane/sublane inside toplevel lanes,
				// so we can add spacing margins
				if(!child.getParent()._owningSubgraph){
					list[old]._isFirstLaneInPool = true;
					list[list.length-1]._isLastLaneInPool = true;
				}
			}
		}
		
		return list;
	},
	
	_afterLayout: function(graph, hl, swimlanes)
	{
		// summary:
		//		Updates the position/size of all swim lanes according to info computed by the hierarchical layout.
		
		if (!this.automaticHierarchicalLayout) {
			this.afterHierarchicalLayout(graph, hl, swimlanes);
			return;
		}
		
		// First update the swim lanes that actually contain nodes
		// (those that correspond to constraints)
		var n = swimlanes.length;
		var i, l;
		for(i = 0; i < n; i++){
			l = swimlanes[i];
			var c = l._hierarchicalConstraint;
			var bb = c.getCalcBoundingBox();
			
			// add north/south margins, and remove extra west/east margin
			// corresponding to pool spacing.
			var m = l.getGraphMargin();
			var wm = c.getWestMinMargin() - m;
			var em = c.getEastMinMargin() - m;
			if(l._vertical){
				bb.y -= m;
				bb.height += 2*m;
				bb.x += wm;
				bb.width -= wm + em;
			} else {
				bb.x -= m;
				bb.width += 2*m;
				bb.y += l._rightToLeft ? wm : em;
				bb.height -= wm + em;
			}
			this._moveResizeLane(graph, l, bb);
		}
		
		// make sure all sublanes have the correct size already...
		Batch.endBatch();
		
		// Now, update swim lanes that contain other swim lanes,
		// and that must just fit their children lanes
		this._updateParentLanes(graph);
		
		// cleanup
		for(i = 0; i < n; i++){
			l = swimlanes[i];
			hl.removeConstraint(l._hierarchicalConstraint);
			delete l._hierarchicalConstraint;
		}
	},
	
	_moveResizeLane: function(graph, sl, rect)
	{
		// summary:
		//		Moves/resizes a lane so that its 'graph rect' becomes rect.
		//		Rect is given in 'graph' coordinates.
		
		// we will work in the coord system of the lane, so transform
		// the rect (which is passed in graph coords) to this system:
		var t = sl.getTransformToContainer(graph);
		if(t)
			rect = t.inverse().transformRectangle(rect);
		
		// get current lane's subgraph rect, to compute header width/height
		var graphRect = sl._graphRect || sl._graphBackground;
		var gr = graphRect.getBoundingBox();
        var t = graphRect.getShapeToContainerTransform(sl) || matrix.identity;
		gr = t.transformRectangle(gr);

		// current lane bounds: we do not use the real bounds including all nodes,
		// because at this point nodes can be completely ouside of the lane, 
		// instead we get the current explicit size and the current transform...
		t = sl.getTransform();
		var bb = {
				x: t ? t.dx : 0,
				y: t ? t.dy : 0,
				width : sl.getExplicitSize().width || sl.getBounds().width,
				height : sl.getExplicitSize().height || sl.getBounds().height
		};
		
		// lane translation to get to the desired position
		// (taking into account subgraph offsets)
		var dx = rect.x - gr.x - bb.x;
		var dy = rect.y - gr.y - bb.y;
		
		// resize lane (also taking into account diff between graph rect and lane bbox)
		var sz = bb;
		var w = rect.width + sz.width - gr.width;
		var h = rect.height + sz.height - gr.height;
		sl.setExplicitSize({width:w, height:h});
		
		// translate the lane,
		sl.applyLeftTransform(matrix.translate(dx, dy));
		
		// and inversely translate its graph
		// so that nodes still appear at the same position (computed by the layout)
		
		sl._graph.applyLeftTransform(matrix.translate(-dx, -dy));
	},
	
	_updateParentLanes: function(graph)
	{
		var children = graph.children;
		var n = children.length;
		for(var i = 0; i < n; i++){
			var child = children[i];
			if(child._isIBMDiagramSwimLane && !child._hierarchicalConstraint){
				var graphBounds = child._graph.getBoundingBox();
				t = child._graph.getShapeToContainerTransform(graph);
				if(t)
					graphBounds = t.transformRectangle(graphBounds);
				this._moveResizeLane(graph, child, graphBounds);
				this._updateParentLanes(child._graph);
				child.setStackSublanes(child._oldStackSublanes);
				delete child._oldStackSublanes;
			}
		}
	}
});

return SwimLane;

});

