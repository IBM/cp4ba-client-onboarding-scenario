/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/keys",
"../../interactors/Interactor",
"../undo/SimpleAction",
"../undo/UndoActionList",
"../../util/Geometry"
], function(
declare,
keys,
Interactor,
SimpleAction,
UndoActionList,
Geometry
){

/*=====
var Interactor = ibm_ilog.diagram.interactors.Interactor;
=====*/

var ResizeKeyInteractor =
declare("ibm_ilog.diagram.editor.interactors.ResizeKeyInteractor", [Interactor], {
	//summary:
	//		This interactor manages the graphElements resizing through the keyboard interaction.
	//		This interactor has 8 connections: reduceWidth, fineReduceWidth, increaseWidth, fineIncreaseWidth, 
	//		reduceHeight, fineReduceHeight, increaseHeight, fineIncreaseHeight.
	
	_diagram: null,
	_increment: null,
	_fineIncrement: null,
	initialize: function (diagram) {
	// summary:
    //		initialize the new instance.
    // diagram: ibm_ilog.diagram.widget.Diagram
    //		the associated diagram.		
		this._diagram = diagram;
		this.setIncrement(10);
		this.setFineIncrement(1);
		return this._initialize();
	},
	setIncrement: function(increment){
		// summary: 
		//		sets the resize increment
		// increment: integer
		//		the increment to be set
		this._increment = increment;
	},
	getIncrement: function(){
		// summary: 
		//		gets the resize increment
		return this._increment;
	},
	setFineIncrement: function(increment){
		// summary: 
		//		sets the resize fine increment
		// increment: integer
		//		the fine increment to be set
		this._fineIncrement = increment;
	},
	getFineIncrement: function(){
		// summary: 
		//		gets the resize fine increment
		return this._fineIncrement;
	},
	reduceHeight: function(e){
		// summary: 
		//		Reduces the focused element height from the right bottom corner
		this._resize({x:0,y:-this._increment});
	},
	increaseHeight: function(e){
		// summary: 
		//		Increases the focused element height from the right bottom corner
		this._resize({x:0,y:this._increment});
	},
	increaseWidth: function(e){
		// summary: 
		//		Increases the focused element width from the right bottom corner
		this._resize({x:this._increment,y:0});
	},
	reduceWidth: function(e){
		// summary: 
		//		Reduces the focused element width from the right bottom corner
		this._resize({x:-this._increment,y:0});
	},
	fineReduceHeight: function(e){
		// summary: 
		//		Finely reduces the focused element height from the right bottom corner
		this._resize({x:0,y:-this._fineIncrement});
	},
	fineIncreaseHeight: function(e){
		// summary: 
		//		Finely increases the focused element height from the right bottom corner
		this._resize({x:0,y:this._fineIncrement});
	},
	fineIncreaseWidth: function(e){
		// summary: 
		//		Finely increases the focused element width from the right bottom corner
		this._resize({x:this._fineIncrement,y:0});
	},
	fineReduceWidth: function(e){
		// summary: 
		//		Finely reduces the focused element width from the right bottom corner
		this._resize({x:-this._fineIncrement,y:0});
	},
	getKeyInteractorId: function(){
		// summary:
	    //		returns the Interactor Id
		return ResizeKeyInteractor.KeyInteractorId;
	},
	getDefaultConnections: function () {
		// summary:
		//		returns the default event mapping
		
		return {
			reduceWidth: {
				hotKey: keys.LEFT_ARROW,
				connectTo: "reduceWidth",
				filter: this._buildInputFilter({ctrl:true,shift:false})
			}, fineReduceWidth: {
				hotKey: keys.LEFT_ARROW,
				connectTo: "fineReduceWidth",
				filter: this._buildInputFilter({ctrl:true,shift:true})
			}, increaseWidth: {
				hotKey: keys.RIGHT_ARROW,
				connectTo: "increaseWidth",
				filter: this._buildInputFilter({ctrl:true,shift:false})
			}, fineIncreaseWidth: {
				hotKey: keys.RIGHT_ARROW,
				connectTo: "fineIncreaseWidth",
				filter: this._buildInputFilter({ctrl:true,shift:true})
			}, reduceHeight: {
				hotKey: keys.UP_ARROW,
				connectTo: "reduceHeight",
				filter: this._buildInputFilter({ctrl:true,shift:false})
			}, fineReduceHeight: {
				hotKey: keys.UP_ARROW,
				connectTo: "fineReduceHeight",
				filter: this._buildInputFilter({ctrl:true,shift:true})
			}, increaseHeight: {
				hotKey: keys.DOWN_ARROW,
				connectTo: "increaseHeight",
				filter: this._buildInputFilter({ctrl:true,shift:false})
			}, fineIncreaseHeight: {
				hotKey: keys.DOWN_ARROW,
				connectTo: "fineIncreaseHeight",
				filter: this._buildInputFilter({ctrl:true,shift:true})
			}
		};
	},
	_resize: function(delta){
		var ge = this._diagram.getFocusedElement();
		if(ge && !ge._IBMDiagramLink){
			var startBB = ge.getBounds();
			var endBB = Geometry.cloneRect(startBB);
			var min = ge.minimumSize;
		
			endBB.width = Math.max(min.width,startBB.width + delta.x);
			endBB.height = Math.max(min.height,startBB.height + delta.y);
		
			ge.setBounds(endBB);
			this._diagram.getUndoManager().addAction(this._createUndoAction(ge, startBB, endBB));
		}
	},
	_createUndoAction: function(ge, startBB, endBB){
		var action = new SimpleAction(UndoActionList.Resize);
		action.setOldValue(startBB);
		action.setNewValue(endBB);
		action.setMethodOrProperty('setBounds');
		action.setModifiedElementId(ge.getId());
		return action;
	}
});

ResizeKeyInteractor.KeyInteractorId = "Resize";

return ResizeKeyInteractor;

});
