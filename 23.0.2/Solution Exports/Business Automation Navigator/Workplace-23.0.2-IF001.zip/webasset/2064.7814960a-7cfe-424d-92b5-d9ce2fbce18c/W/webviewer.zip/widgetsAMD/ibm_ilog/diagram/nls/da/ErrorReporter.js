/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
// NLS_CHARSET=UTF-8

define({
	//-------------------------------------------------------
	// ErrorReporter internals
	//
	
	// Explanation: An unexpected internal error has occurred in the Dojo Diagrammer code.
	// User action: This is an internal error and the cause is not immediately known. If the error persists, consult the support pages.
	Unknown: "Ukendt fejl.",
	// Explanation: The 'error' or 'warning' method of ibm_ilog.diagram.util.ErrorReporter has been called with an invalid identifier.
	// User action: Verify that identifiers passed to ibm_ilog.diagram.util.ErrorReporter methods are valid.
	InvalidErrorId: "Strengen \"${errorId}\" er ikke en gyldig fejl-id.",
	// Explanation: The ibm_ilog.diagram.util.ErrorReporter.declareError method is called with an identifier that is already declared.
	// User action: Verify that the declared error identifier is not already declared.
	ErrorIdAlreadyDeclared: "Fejl-id'en \"${errorId}\" er allerede registreret.",

	
	//-------------------------------------------------------
	// Generic-JavaScript
	//
	// Explanation: A user-defined subclass of a Dojo Diagrammer base class does not define a required method.
	// User action: Verify that all required methods are declared in your subclass.
	SubclassResponsibility: "${methodName} skal være implementeret som en underklasse.",
	// Explanation: An object is null and it is expected to not be null.
	// User action: Verify that you provide an object that is not null for the object that is specified in the error message.
	NullPointerException:"${objectName} var NULL.",
	// Explanation: An object is null and it is expected to not be null.
	// User action: Verify that you provide an object that is not null for the object that is specified in the error message. The error message also contains a hint to help you find the class that contains the error.
	NullPointerException2:"${objectName} var NULL [tip: ${where}].",
	// Explanation: An error that was caused by another nested error has occurred.
	// User action: Refer to the user action for the nested error whose identifier is contained in the error message.
	Wrapped:"Fejl ved ${process}: (${error}).",
	// Explanation: An unexpected argument value was passed to a function.
	// User action: The function name, expected value (or value range) and actual argument value are contained in the error message. Verify that the argument value is correct.
	UnexpectedArgument:"Uventet argumenttype eller interval.",
	
	// Explanation: A function was called with an invalid number of arguments.
	// User action: The expected and actual number of arguments are contained in the error message. Verify that the number of arguments are correct.
	InvalidNumberOfArguments:"Fundet ${numberOfArgs} og forventede ${options}",
	
	// Explanation: An unexpected value was returned by a function.
	// User action: The function name, expected return value type and actual return value type are contained in the error message. Verify that the returned value type is correct.
	UnexpectedReturnValueType: "Uventet returværditype. Forventede type fra ${functionName}():${expectedType}. Fik: ${actualType}",


	//-------------------------------------------------------
	// Generic-Graph/Diagram
	//
	
	// Explanation: A function expects a graph element (for example, a node, link, or subgraph) but another type of object was found.
	// User action: Verify that a graph element is supplied.
	GraphElementExpected: "Grafelement forventet: Graf, node, link eller undergraf.", 

	
	//-------------------------------------------------------
	// DataStore
	//
	// Explanation: The Diagram widget processed a data item that is not contained in the data store specified as the nodesStore or linksStore attributes
	// User action: Verify that the data store contains the item that is specified as the nodesStore or linksStore attributes of the Diagram widget.
	NotInDataStore:"Entiteten findes ikke i datalageret.",
	// Explanation: The nodesQuery or linksQuery attribute of the Diagram widget is specified as a string, and it should be an object.
	// User action: Verify that the nodesQuery or linksQuery attribute is an object and not a string.
	CannotUseAStringForAQuery:"Du skal definere lagerforespørgslen som et objekt, ikke som en streng.",
	// Explanation: The nodesStore attribute of the Diagram widget is not specified.
	// User action: Specify the nodesStore attribute on the Diagram widget.
	NodesStoreRequired:"Widgetten kræver, at der er defineret et nodelager.",	
	// Explanation: The data store that is specified as the nodesStore or linksStore attribute does not implement the dojo.data.api.Indentity interface.
	// User action: Specify a data store that implements the dojo.data.api.Indentity interface.
	StoresMustSupportIdentity:"Lageret skal understøtte funktionen 'dojo.data.api.Read'.",
	// Explanation: The data store that is specified as the nodesStore or linksStore attribute does not implement the dojo.data.api.Read interface.
	// User action: Specify a data store that implements the dojo.data.api.Read interface.
	StoresMustSupportRead:"Lageret skal understøtte funktionen 'dojo.data.api.Read'.",
	
	// Explanation: An error occurred while loading the data store specified as the nodesStore attribute of the Diagram widget.
	// User action: The error message contains the the nested error. Correct the nested error.
	UnexpectedErrorOnNodesStoreFetch:"Fejl under NodesStore-hentning: (${errorString})",
	// Explanation: An error occurred while loading the data store specified as the linksStore attribute of the Diagram widget.
	// User action: The error message contains the the nested error. Correct the nested error.
	UnexpectedErrorOnLinksStoreFetch:"Fejl under LinksStore-hentning: (${errorString})",

	
	//-------------------------------------------------------
	// Overview
	//

	// Explanation: The diagram attribute of the Overview widget is not defined.
	// User action: Define the diagram attribute of the Overview widget.
	OverviewDiagramMissing:"Oversigtswidgetten kræver en diagramwidget (attribute 'diagram'==${diagram}).",

	
	//-------------------------------------------------------
	// WAI
	//

	// Explanation: The internal Web Accessibility Initiative (WAI) node was not found for the given graph element.
	// User action: Use the createNode/createLink/createSubgraph methods of the diagram, not the graph methods to create elements in a diagram.
	MissingWaiNode:"Noden WAI-ARIA findes ikke for grafelement: ${element}",

	//-------------------------------------------------------
	// ServerSideLayout
	//

	// Explanation: The specified graph layout algorithm is not supported for server-side layout.
	// User action: Use another graph layout algorithm that supports server-side layout, or use client-side graph layout.
	UnsupportedAlgorithm: "Algoritmen ${algorithmClass} understøttes ikke for graflayout på serversiden.",  
	

	//-------------------------------------------------------
	// Interactors
	//
	// Explanation: The InteractorManager.push method was called while an interactor is already contained in the active stack.
	// User action: Do not push an interactor while an interactor is already contained in the active stack.
	RestrictedToOneInteractor:"Det er kun muligt at udføre push af én interaktor i den aktive stak.", 
	// Explanation: The InteractorManager.get method was called with an invalid interactor identifier.
	// User action: Verify that the identifier passed to the InteractorManager.get method is valid.
	InvalidInteractorId: "Interaktor-id'en ${interactorId} er ugyldig.", 
	// Explanation: An Interactor object attempted to connect to an invalid event name.
	// User action: Verify that the connection objects returned by the getDefaultConnections() method of the interactor contain valid event names.
	InvalidInteractorEvent: "Ugyldig interaktorhændelse: ${name}", 
	// Explanation: An invalid filter definition was defined in an interactor object.
	// User action: Verify that the connection objects returned by the getDefaultConnections() method of the interactor contain valid filter definitions.
	InvalidInputFilterSpec: "Ugyldig filterspecifikation for interaktorinput for hændelsen ${name}\"",  


	//-------------------------------------------------------
	// UI events/connections
	//
	// Explanation: An internal connection is made to an event while another connection is still active.
	// User action: This is an internal error. If the error persists, consult the support pages.
	ConnectionStillActive: "Forbindelsen ${id} er stadig tilsluttet.", 
	// Explanation: An internal connection to an event has failed.
	// User action: This is an internal error. If the error persists, consult the support pages.
	EventConnectionFailed: "Kan ikke oprette forbindelse til hændelsen: ${eventName}.", 


	//-------------------------------------------------------
	// Viewport
	//
	// Explanation: The maximum zoom is set to a value less than the minimum zoom.
	// User action: Set the maximum zoom to a value greater than the minimum zoom.
	MaxZoomBelowMin: "Kan ikke angive maksimumszoom, der er mindre end minimumszoom.", 
	// Explanation: The minimum zoom is set to a value greater than the maximum zoom.
	// User action: Set the minimum zoom to a value less than the maximum zoom.
	MinZoomAboveMax: "Kan ikke angive minimumszoom, der er større end maksimumszoom.", 

	
	//-------------------------------------------------------
	// User-defined functions
	//
	// Explanation: An error occurred while starting the user-defined drop function.
	// User action: The error message contains the error that occurred in the user-defined drop function. Correct this error. 
	DropUserFunctionError: "Fejl ved sletning af brugerfunktion: ${error}",
	// Explanation: An error occurred while starting the user-defined undo function.
	// User action: The error message contains the error that occurred in the user-defined undo function. Correct this error. 
	UndoUserActionError:"Fejl ved fortrydelse af brugerhandling under aktivering ved ${action}: (${error}).",
	
	//-------------------------------------------------------
	// Swim lanes
	
	// Explanation: An attempt to create a SwimLane element was made while the GFX layout feature is not enabled.
	// User action: Enable GFX layout by specifying 'gfxLayout: true' in the global djConfig object.
	SwimLanesRequireGfxLayout: "GFX-layout skal aktiveres, når der bruges svømmebaner (djConfig.useGfxLayout=true)",
	
	//-------------------------------------------------------
	// Dojo
	
	// Explanation: A Dojo Diagrammer feature that requires at least a specific version of Dojo was used.
	// User action: Configure the application to use at least the specified version of Dojo, or do not use the feature.
	UnsupportedDojoFeature: "Funktionen er ikke tilgængelig i denne version af Dojo. Kræver Dojo ${version}.",	
	
	//-------------------------------------------------------
	LASTERRORCODE: ""
	
});

