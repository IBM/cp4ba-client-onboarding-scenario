/**
 * A manager for the traveled/projected adornements for portal. Use is:
 * 
 * <pre>
 * var t = new TraveledAndProjectedPathManager(ilogDiagram);
 * t.setTraveledPath(linkIds); // [] of string
 * t.setProjectedPath(nodeIds); // [] of string 
 * t.adorn();
 * </pre>
 * 
 * You can also unAdorn() and destroy().
 * 
 * This class manages the user pressing the reroute button (i.e. it will recreate the
 * projectedPathAdorner and projectedPathRerouteAdorner adorners from the newly computed path).
 * 
 * You can use aspect.after to listen for the user rerouting by monitoring the
 * onProjectedPathRerouted() method.
 */
define([
   "dojo/_base/declare",
   "dojo/_base/lang",
   "dojo/aspect",
   "./adornerConstants",
   "./ilogDiagramUtils",
   "./adornerUtils",
   "./pathAdornerUtils",
   "./PathElement",
   "./PathAdorner",
   "./PathExplorer"
], function(declare, lang, aspect, adornerConstants, ilogDiagramUtils, adornerUtils, pathAdornerUtils, PathElement, PathAdorner, PathExplorer) {
   return declare([], {

      traveledPathAdorner : null,
      projectedPathAdorner : null,
      projectedPathRerouteAdorner : null,
      traveledPathExplorer : null,
      projectedPathExplorer : null,
      rerouteListener : null,
      diagram : null,
      bpdViewer : null,
      autoRedraw : null,
      mode : null,
      MODE_RW : "MODE_RW",
      MODE_RO : "MODE_RO",
      debug: true,

      constructor : function(bpdViewer) {
         this.bpdViewer = bpdViewer; 
         this.diagram = bpdViewer.ilogDiagrammer;
         this.mode = this.MODE_RW;
         this.autoRedraw = false;
      },

      setTraveledPath : function(linkIds) {
         this.createTraveledPathExplorer(linkIds);
         this.createTraveledPathAdorner(linkIds);
      },

      setProjectedPath : function(nodeIds, mode, autoRedraw) {
         if (typeof autoRedraw != "undefined") {
            this.autoRedraw = autoRedraw;
         } 
         if (typeof mode != "undefined") {
            this.mode = mode;
         }
         this.createProjectedPathExplorer(nodeIds);
         this.createProjectedPathColoredLinkAdorner(this.projectedPathExplorer.asLinkOnlyPath());
         this.createProjectedPathRerouteLinkAdorner();
      },

      createTraveledPathExplorer : function(linkIds) {
         var pe = new PathExplorer(this.diagram);
         if (this.debug) {
            console.debug("TraveledAndProjectedPathManager > Traveled Path diagram dump:");
            pe.dumpNodesAndLinks();
         }
         var completePath = pe.asPathFromOnlyLinks(linkIds);
         pe.setBasePath(pe.asPathElements(completePath));
         this.traveledPathExplorer = pe;
         if (this.debug) {
            console.debug("TraveledAndProjectedPathManager > Traveled Path:");
            this.traveledPathExplorer.dumpBasePath();
         }
      },

      createTraveledPathAdorner : function(linkIds) {
         if (this.traveledPathAdorner) {
            this.traveledPathAdorner.destroy();
            this.traveledPathAdorner = null;
         }
         if (!linkIds)
            return;
         // Create the traveled path adorner
         this.traveledPathAdorner = pathAdornerUtils.createColorLinksPathAdorner(this.bpdViewer, linkIds, "#1b75bc", 3);
      },

      createProjectedPathExplorer : function(nodeIds) {
         var pe = new PathExplorer(this.diagram);
         if (this.debug) {
            console.debug("TraveledAndProjectedPathManager > Projected Path diagram dump:");
            pe.dumpNodesAndLinks();
         }
         var completePath = pe.asPathFromOnlyNodes(nodeIds);
         pe.setBasePath(pe.asPathElements(completePath));
         this.projectedPathExplorer = pe;
         if (this.debug) {
            console.debug("TraveledAndProjectedPathManager > Projected Path:");
            this.projectedPathExplorer.dumpBasePath();
         }
      },

      createProjectedPathColoredLinkAdorner : function(linkIds) {
         if (this.projectedPathAdorner) {
            this.projectedPathAdorner.destroy();
            this.projectedPathAdorner = null;
         }
         if (!linkIds)
            return;
         // Create the projected path adorner
         this.projectedPathAdorner = pathAdornerUtils.createColorLinksPathAdorner(this.bpdViewer, linkIds, "#f5901c", 3);
      },

      createProjectedPathRerouteLinkAdorner : function() {
         var _this = this;
         // Clean up
         if (this.projectedPathRerouteAdorner) {
            this.projectedPathRerouteAdorner.destroy();
            this.projectedPathRerouteAdorner = null;
         }
         if (this.rerouteListener) {
            this.rerouteListener.remove();
            this.rerouteListener = null;
         }
         // If we are in read only mode, then we don't want to do anything else since no 
         // alternate path buttons can appear.
         if (this.mode === this.MODE_RO) {
            return;
         }
         // We must exclude nodes in the traveled path so as to preclude loops
         var exclusionList = null;
         if (this.traveledPathExplorer) {
            exclusionList = this.traveledPathExplorer.asNodeOnlyPath();
         }
         // Function that will be called when a fork button is pressed
         var selectFork = function(pathElement) {
            // Recompute the path going through the selected link.
            var pathElements = _this.projectedPathExplorer.computeNewPathTakingFork(pathElement, true, exclusionList);
            var path = _this.projectedPathExplorer.asPath(pathElements);
            // Reset the projected colored and reroute adorners
            // If we need to redraw then reset everything
            if (_this.autoRedraw) {
               _this.setProjectedPath(_this.projectedPathExplorer.asNodeOnlyPath(path));
               _this.projectedPathAdorner.adorn();
               _this.projectedPathRerouteAdorner.adorn();
            }
            else {
               // Keep track of the new path but keep the UI as is.
               _this.createProjectedPathExplorer(_this.projectedPathExplorer.asNodeOnlyPath(path));
            }
         };
         // Compute the forks
         var pathElements = this.projectedPathExplorer.computeAlternateForks(exclusionList, false);
         // If there are forks...
         if (pathElements && pathElements.length > 0) {
            // Adorn the path
            this.projectedPathRerouteAdorner = new PathAdorner();
            for ( var i = 0; i < pathElements.length; i++) {
               adorner = adornerUtils.createRerouteToLinkAdorner(pathElements[i]);
               pathElements[i].addAdorner(adorner);
               this.projectedPathRerouteAdorner.addElement(pathElements[i]);
            }
            // When the click button is pressed, set up the new path.
            this.rerouteListener = aspect.after(this.projectedPathRerouteAdorner, "onAdornerEvent", function(
               path,
               pathElement,
               adorner,
               eventName,
               data) {
               if (eventName === "ADORNER_CLICKED") {
                  //console.log("Button clicked for link:" + pathElement.id);
                  selectFork(pathElement);
                  _this.onProjectedPathRerouted();
               }
            }, true);
         }
      },

      getTraveledPathAdorner : function() {
         return this.traveledPathAdorner;
      },

      getProjectedPathAdorner : function() {
         return this.projectedPathAdorner;
      },

      getProjectedPathRerouteAdorner : function() {
         return this.projectedPathRerouteAdorner;
      },

      adorn : function() {
         if (this.getTraveledPathAdorner()) {
            this.getTraveledPathAdorner().adorn();
         }
         if (this.getProjectedPathAdorner()) {
            this.getProjectedPathAdorner().adorn();
         }
         if (this.getProjectedPathRerouteAdorner()) {
            this.getProjectedPathRerouteAdorner().adorn();
         }
      },

      unAdorn : function() {
         if (this.getTraveledPathAdorner()) {
            this.getTraveledPathAdorner().unAdorn();
         }
         if (this.getProjectedPathAdorner()) {
            this.getProjectedPathAdorner().unAdorn();
         }
         if (this.getProjectedPathRerouteAdorner()) {
            this.getProjectedPathRerouteAdorner().unAdorn();
         }
         if (this.rerouteListener) {
            this.rerouteListener.remove();
         }
      },

      destroy : function() {
         if (this.getTraveledPathAdorner()) {
            this.getTraveledPathAdorner().destroy();
            this.traveledPathAdorner = null;
         }
         if (this.getProjectedPathAdorner()) {
            this.getProjectedPathAdorner().destroy();
            this.projectedPathAdorner = null;
         }
         if (this.getProjectedPathRerouteAdorner()) {
            this.getProjectedPathRerouteAdorner().destroy();
            this.projectedPathRerouteAdorner = null;
         }
         if (this.rerouteListener) {
            this.rerouteListener.remove();
            this.rerouteListener = null;
         }
      },

      getCurrentProjectedPath : function() {
         return this.projectedPathExplorer.asNodeOnlyPath();
      },

      onProjectedPathRerouted : function() {
         // To be listened to
      }
      
   });

});