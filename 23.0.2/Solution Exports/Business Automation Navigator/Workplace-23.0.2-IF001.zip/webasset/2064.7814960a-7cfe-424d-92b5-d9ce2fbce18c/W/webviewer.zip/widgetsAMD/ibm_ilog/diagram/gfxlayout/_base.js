/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define(["../main",
"dojo/_base/lang", "dojo/_base/config", "dojo/_base/sniff", "dojo/dom-style",
"dojox/gfx", "dojox/gfx/matrix",
"../_base/gfxext", "../_base/diagext",
"../util/Geometry", "../util/ErrorReporter",
"dojo/has!config-isBidiInDojoDiagrammer?../util/BidiUtil:"],
function(iid, lang, config, has, domstyle, gfx, matrix, gfxext, diagext, Geometry, ErrorReporter, BidiUtil){

	// TODO: Change to this when AMD conversion is complete:
	// var gfxlayout = {};
	var gfxlayout = lang.getObject("ibm_ilog.diagram.gfxlayout", true);
	
	// ensures the explicitSize is updated when the font is changed.
	gfxext.patchMethod(gfx.Text, "setFont", null, function(){
		this.__shapeSet();
	});
	
	// Returns the size of the given string when rendered by the specified Text shape.
	var getTextSize = function(/*dojox.gfx.Text*/sh, /*String*/ txt){
		if (!txt || txt.length == 0) 
			return null;
		if (iid.isSvg && !iid.isSvgWeb) {
			if (!sh.rawNode.firstChild) 
				return null;
			//Fix for svg in FF. When the text starts with lamed, tzadik, may be other letters, the text width after Bidi conversion is smaller, than 
			//the width of the text before convertion, we have to apply Bidi conversion on the text before measurement, to prevent 
			//additional truncation
			if (config.isBidiInDojoDiagrammer && sh.getShape().__beforeBidi && has("ff")) {
				var shape = lang.clone(sh.getShape());
				shape.text = txt;
				shape = BidiUtil.bidiFormat.call(sh, shape);
				txt = shape.text;
			}
			// summary: get the text width in pixels
			var rawNode = sh.rawNode, oldParent = rawNode.parentNode, _measurementNode = rawNode.cloneNode(true);
			_measurementNode.style.visibility = "hidden";
			// solution to the "orphan issue" in FF
			var _height = 0, _width = 0, _x = 0, _y = 0;
			_measurementNode.firstChild.nodeValue = txt;
			oldParent.appendChild(_measurementNode);
			try {
				var bbox = _measurementNode.getBBox();
				_width = parseInt(bbox.width, 10);
				_height = parseInt(bbox.height, 10);
							
			} catch (e){return null;}
			oldParent.removeChild(_measurementNode);
			return {
				width: _width,
				height: _height
			};
		} else if (iid.isVml) {
			var oldShape = sh.getShape();
			
			var rawNode = sh.rawNode, _display = rawNode.style.display;
			sh._suspendInvalidate = true;
			sh.setShape({
				text: txt
			});
			sh.getTextWidth();
			var _width = gfx.pt2px(parseFloat(rawNode.currentStyle.width));
			var _height = gfx.pt2px(parseFloat(rawNode.currentStyle.height));
			// in VML, the width/height we get are in view coordinates
			var m = sh._getRealMatrix();
			if (m && !m.isIdentity()) {
				var sz = {
					x: 0,
					y: 0,
					width: _width,
					height: _height
				};
				sz = m.inverse().transformRectangle(sz);
				_width = sz.width;
				_height = sz.height;
			}
			sh.setShape(oldShape);
			sh._suspendInvalidate = false;
			return {
				width: _width,
				height: _height
			};
			
			/*
			 var rawNode = sh.rawNode, oldParent = rawNode.parentNode,
			 _measurementNode = rawNode.cloneNode(true);
			 oldParent.appendChild(_measurementNode);
			 _measurementNode.style.display = "inline";
			 // find text path
			 var t = null, c = _measurementNode.childNodes;
			 for(var i = 0; i < c.length; ++i){
			 var tag = c[i].tagName;
			 if(tag == "textpath"){
			 t = c[i];
			 }
			 }
			 t.string = txt;
			 t.on = true;
			 
			 
			 var bcr = _measurementNode.getBoundingClientRect();
			 console.log((bcr.right - bcr.left) + " " + (bcr.bottom - bcr.top));
			 return {x:bcr.left, y:bcr.top, width: bcr.width || (bcr.right - bcr.left), height: bcr.height || (bcr.bottom - bcr.top)};
			 */
		} else if (iid.isSilverlight) {
			var oldtext = sh.rawNode.text;
			sh.rawNode.text = txt;
			var bb = {
				width: sh.rawNode.actualWidth,
				height: sh.rawNode.actualHeight
			};
			sh.rawNode.text = oldtext;
			return bb;
		} else if (sh.getTextWidth) {
			if(iid.isSvgWeb && !sh.parent)
				return null;
			// this works for Canvas
			var oldtext = sh.shape.text;
			sh.shape.text = txt;
			var w = sh.getTextWidth();
			sh.shape.text = oldtext;
			var font = sh.getFont();
			var fz = font ? font.size : gfx.defaultFont.size;
			var h = gfx.normalizedLength(fz);
			return {
				width: w,
				height: h
			};
		}
	};
	
	//
	// An extension to gfx Shape classes to add features required by the layout system.
	//
	gfxlayout._LayoutShapeExt = {
	
		_explicitSize: null,
		
		// Called when a setShape (or any methods that modify the bbox) is invoked.
		__shapeSet: function(){
			if (this._suspendInvalidate) {
				return;
			}
			// getBoundingBox may return null (for ex when the Text is not in the hierarchy yet)
			var bbox = this.getBoundingBox();
			// in Chrome, a (0,0,0,0) bbox is returned for undetermined node state instead of null.
			// So we treat such a bbox as null to force the _expliciteSize computation later
			// (see defect 2105)
			if (bbox && bbox.x === 0 && bbox.y === 0 && bbox.width === 0 && bbox.height === 0)
				bbox = null;
			this._explicitSize = bbox;
		},
		
		getExplicitSize: function(){
			// summary:
			//     Returns the explicit size of this shape.
			// description: 
			//     This method returns the size as computed by the getBoundingBox() method
			//     of the shape explicit geometry (that is, the geometry explicitely set and
			//     not the geometry computed by the layout).
			return this._explicitSize;
		},
		
		getPreferredSize: function(){
			// summary:
			// returns the preferred size as computed by the computePreferredSize() method.
			
			return {
				width: this._preferredSize.width,
				height: this._preferredSize.height
			};
		},
		
		computePreferredSize: function(/*Size*/proposedSize){
			// summary:
			//     Computes the preferred size of this shape according to the specified proposed size,
			//     and ensures it is conformed with the minimum and maximum size of this shape.
			// proposedSize: Size: the proposed size.        
			
			var sz = this._computePreferredSize(proposedSize);
			this._preferredSize = this._checkMinMaxSize(sz);
			return {
				width: this._preferredSize.width,
				height: this._preferredSize.height
			};
		},
		
		/*protected*/
		_computePreferredSize: function(/*Size*/proposedSize){
			// summary:
			//     Computes the preferred size of this shape. 
			// description:
			//     This method is invoked by the public computePreferredSize() method. Subclasses should override
			//     this method for specific implementation.
			
			var rect = this._explicitSize;
			if (!rect) 
				rect = this._explicitSize = this.getBoundingBox();
			if (!rect) 
				rect = Geometry.EmptyRect;
			var t = this.getTransform();
			if (t) {
				// do not modify rect as it breaks under IE9
				var rt = {
					x: rect.x || 0,
					y: rect.y || 0,
					width: rect.width,
					height: rect.height
				}
				rect = t.transformRectangle(rt);
			}
			return {
				width: rect.width,
				height: rect.height
			};
		},
		
		_checkMinMaxSize: function(/*Size*/bounds){
			// summary:
			//     Ensures the specified bounds fits the minimum and maximum size.
			
			return this._checkMaxSize(this._checkMinSize(bounds));
		},
		
		_checkMaxSize: function(bounds){
			// summary:
			//     Ensures the specified bounds fits the maximum size.
			
			var sz = this.maximumSize;
			if (sz && sz.height) {
				bounds.height = Math.min(sz.height, bounds.height);
			}
			if (sz && sz.width) {
				bounds.width = Math.min(sz.width, bounds.width);
			}
			return bounds;
		},
		
		_checkMinSize: function(bounds){
			// summary:
			//     Ensures the specified bounds fits the minimum size.
			
			var sz = this.minimumSize;
			if (sz && sz.height) {
				bounds.height = Math.max(sz.height, bounds.height);
			}
			if (sz && sz.width) {
				bounds.width = Math.max(sz.width, bounds.width);
			}
			return bounds;
		},
		
		//_suspendInvalidate: false,
		_suspendInvalidate: 0,
		
		suspendInvalidate: function(){
			// summary:
			//    Suspends the invalidate propagation to the parent hierarchy.
			
			//this._suspendInvalidate = true;
			++this._suspendInvalidate;
		},
		
		resumeInvalidate: function(/*Boolean*/invalidate){
			// summary:
			//     Resumes the invalidate propagation to the parent hierarchy.
			// invalidate: Boolean: Indicates whether a call to invalidate() should be done.
			
			//this._suspendInvalidate = false;
			
			--this._suspendInvalidate;
			if (this._suspendInvalidate < 0) {
				this._suspendInvalidate = 0;
				// TODO: throw Error
			}
			if (invalidate && !this._suspendInvalidate) 
				//if (invalidate) 
				this.invalidate();
		},
		
		invalidate: function(){
			// summary:
			//     Invalidates this shape.
			// description:
			//     Call this method when a change occurs on this shape that could impact its
			//     bounding box. The default implementation propagates the invalidation to
			//     the parent hierarchy.
			if (this._suspendInvalidate) 
				return;
			var p = this.getParent();
			if (p && p.invalidate) {
				// indicates the size must be recomputed for all the parent layout chain
				p.invalidate();
			}
		},
		
		layout: function(/*Rectangle*/rect){
			// summary:
			//     Lays out this shape into the specified rectangle.
			
			try {
				this.suspendInvalidate();
				this.applyLayout(rect);
			} finally {
				this.resumeInvalidate();
			}
		},
		
		/*protected*/
		applyLayout: function(/*Rectangle*/rect){
			// summary:
			//     Invoked by the public layout() method to layout this shape into this specified rect.
			//     Subclasses should override this method to implement their own logic. The default
			//     implementation computes the transform needed to fit the specified rect.
			var t = this.getTransform() || matrix.identity;
			// 'disable' the transform set previously by the layout
			// so here, t is all the transforms except the one from the layout
			if (this.__oldLayoutTransform && !this.__oldLayoutTransform.isIdentity()) {
				t = matrix.multiply(this.__oldLayoutTransform.inverse(), t);
			}
			var bbox = this.getBoundingBox();
			if (t && bbox) 
				bbox = t.transformRectangle(bbox);
			if (bbox) {
				this.__oldLayoutTransform = matrix.createFromRectangles(bbox, rect);
				t = matrix.multiply(this.__oldLayoutTransform,t);
				this.setTransform(t);
			} else {
				var dx = rect.x, dy = rect.y;
				if (dx != 0 || dy != 0) {
					this.__oldLayoutTransform = matrix.translate(dx, dy);
					t = matrix.multiply(this.__oldLayoutTransform, t);
					this.setTransform(t);
				} else {
					this.__oldLayoutTransform = null;
				}
				
			}
		}
	};
	
	lang.extend(gfx.shape.Shape, gfxlayout._LayoutShapeExt);
	
	//
	// A fix for missing gfx.Text.getBoundingBox
	//
	
	gfxlayout._ellipsis = String.fromCharCode(8230);
	
	var _truncate = function(txt, width){
		var t = txt, c = txt.length, tw = getTextSize(this, t);
		tw = tw ? tw.width : 0;
		while (c > 0 && tw > width) {
			// drop 2 chars
			c -= 2;
			// and count ellipsis
			t = txt.slice(0, c) + gfxlayout._ellipsis;
			tw = getTextSize(this, t);
			tw = tw ? tw.width : 0;
		}
		// t='...' and still > width
		if (tw > width) 
			t = '';
		return t;
	};
	
	lang.extend(gfx.Text, {
	
		_truncateMode: 'default',
		
		_truncatesFn: _truncate,
		
		setTruncateMode: function(mode){
			// summary:
			// 		Sets the method used to truncate the text.
			// description:
			//		This method is called by the applyLayout() function when the text set on this shape
			//		is wider than the available space so that it fits into the specified space. By default,
			//		the text is truncated with ellipsis as much as needed to fit the available width. You can
			//		specify a custom function or disable the behavior. The custom Function should obey the
			//		following specification:
			//		function foo(text, width) {
			//			// summary: Returns the new text.
			//			// text: String : the text to truncate.
			//			// width: Number: the slot width.
			//			// returns : the truncated text.
			//		}
			// mode: null||'default'||Function
			//		null to disable, 'default' to enable the default mode, or a Function for a custom implementation.
			
			if (mode != this._truncateMode) {
				var old = this._truncateMode;
				this._truncateMode = mode;
				if (!mode) {
					this._truncatesFn = null;
				} else if (mode == 'default') {
					this._truncatesFn = _truncate;
				} else if (typeof(mode) == "function") {
					this._truncatesFn = mode;
				}
				this.invalidate();
			}
		},
		
		getTruncateMode: function(){
			// summary:
			//		Returns the truncate mode.
			
			return this._truncateMode;
		},
		
		applyLayout: function(rect){
			// fix for #1855: on IE, when the text is changed, setShape calls setTransform internally,
			// this will trigger a layout before __setShape was called, thus before ___realtext was set to the new text.
			// So, to know if __realtext is valid, we also check the sh.text against a __disptext (displayed text) property,
			// that we set (below in this method) to the actually displayed (truncated) text.
			var sh = this.getShape(), nsh = {}, txt = "";
			//fix for regression bugs #3282 and 3287, bidi defects, on SVG (FF) and Silverlight, (not VML), the bidi text in subgraph displayed reversed
			//if the text was Bidi transformed,  for truncation, we should use the text before transformation (__realtext, but __disptext could not be set yet)
			if (config.isBidiInDojoDiagrammer && sh.__beforeBidi && (iid.isSilverlight || (iid.isSvg && has("ff")))) {
				txt = this.__realtext ? this.__realtext : sh.text;
    		} else {		
			    txt = (this.__realtext && this.__disptext == sh.text) ? this.__realtext : sh.text;
			}
			var sz = getTextSize(this, txt), sbbox = this.getBoundingBox();
			// if bbox is null (means not in the dom or hidden)
			// do nothing
			if (!sbbox) 
				return;
			
			// If the text is transformed, first apply the inverse transform to the rect:
			var tr = this.getTransform();
			if (tr && !tr.isIdentity()) 
				rect = tr.inverse().transformRectangle(rect);
			
			// Compute the text origin
			
			var h = sz.height, w = sz.width;
			
			switch (sh.align) {
				case 'start':
					nsh.x = rect.x;
					break;
				case 'middle':
					nsh.x = rect.x + rect.width / 2;
					break;
				case 'end':
					nsh.x = rect.x + rect.width;
			}
			// Patch for Canvas: if dir="rtl", text is displayed rtl relative to the align position
			// (I guess maybe SVG should do the same, but the fact is that it does not.
			//  Maybe one day we'll need to do the same for SVG?...)
			if(iid.isCanvas && (sh.align == 'start' || sh.align == 'end')){
				// go up to the GFX Surface to find a DOM node
				for(var p = this.getParent(); p; p = p.getParent()){
					if(p.declaredClass == gfx.Surface.prototype.declaredClass){
						// Look at the computed 'direction' style,
						// seems the easier way to get the inherited direction value...
						var style = domstyle.getComputedStyle(p.rawNode);
						if(style && style.direction == "rtl"){
							if(sh.align == 'start')
								nsh.x += rect.width;
							else
								nsh.x -= rect.width;
						}
						break;
					}
				}
			}
			var ascent = sh.y - sbbox.y;
			nsh.y = rect.y + (rect.height - h) / 2 + ascent;
			
			// check if text is larger than the given rect. 
			// In this case: cut the text and add ellipsis
			if (this._truncatesFn && txt && txt.length > 0 && Math.round(rect.width) > 0 && w > rect.width) {
				txt = this._truncatesFn.call(this, txt, rect.width);
			}
			nsh.text = txt;
			this.__disptext = txt;
			if (config.isBidiInDojoDiagrammer) {
				if (sh.textDir) 
					nsh.textDir = sh.textDir;
				if (sh.ceType) 
					nsh.ceType = sh.ceType;
			}
			this.__setShapeInt = true;
			try {
				this.setShape(nsh);
			} finally {
				this.__setShapeInt = false;
			}
		},
		
		__shapeSet: function(callee){
			if (!this.__setShapeInt && callee === 'setShape') {
				if (config.isBidiInDojoDiagrammer) {
					var tt = this.getShape().__beforeBidi;
					this.__realtext = tt ? tt : this.getShape().text;
				} else 
					this.__realtext = this.getShape().text;
			}
			
			// under IE, we need to reset the explicitSize, as the text bbox may be computed
			// in the createShape() call, and at this time, the _suspendInvalidate is not called yet
			// and the node might be in an incomplete state.	
			if (iid.isVml && this._suspendInvalidate) {
				this._explicitSize = null;
				return;
			}
			gfxlayout._LayoutShapeExt.__shapeSet.call(this);
		}
	});
	
	lang.extend(gfx.Rect, {
		applyLayout: function(rect){
			var t = this.getTransform();
			if (t && !t.isIdentity()) {
				//TODO: if t is translation:=> do a resize instead
				var oldBounds = this.getBoundingBox();
				oldBounds = t.transformRectangle(oldBounds);
				this.applyLeftTransform(matrix.createFromRectangles(oldBounds, rect));
			} else {
				this.setShape(rect);
			}
		}
	});
	
	lang.extend(gfx.Ellipse, {
		applyLayout: function(rect){
			var t = this.getTransform();
			//TODO: if t is translation:=> do a resize instead
			if (t && !t.isIdentity()) {
				var oldBounds = this.getBoundingBox();
				oldBounds = t.transformRectangle(oldBounds);
				this.applyLeftTransform(matrix.createFromRectangles(oldBounds, rect));
			} else {
				var sh = {
					cx: rect.x + rect.width / 2,
					cy: rect.y + rect.height / 2,
					rx: rect.width / 2,
					ry: rect.height / 2
				};
				this.setShape(sh);
			}
		}
	});
	
	lang.extend(gfx.Circle, {
		applyLayout: function(rect){
			var t = this.getTransform();
			//TODO: if t is translation:=> do a resize instead
			if (t && !t.isIdentity()) {
				var oldBounds = this.getBoundingBox();
				oldBounds = t.transformRectangle(oldBounds);
				this.applyLeftTransform(matrix.createFromRectangles(oldBounds, rect));
			} else {
				var sh = {
					cx: rect.x + rect.width / 2,
					cy: rect.y + rect.height / 2,
					r: Math.min(rect.width / 2, rect.height / 2)
				};
				this.setShape(sh);
			}
		}
	});
	
	//
	// An extension to gfx Group to add layout capabilities.
	//
	gfxlayout._PanelExt = {
	
		_ibmd_layoutMgr: null,
		
		__shapeSet: function(){
		
		},
		
		setLayout: function(/*ibm_ilog.diagram.gfxlayout.Layout || Object*/layoutOpt){
			// summary:
			//     Sets the layout manager for this container.
			// layoutOpt: ibm_ilog.diagram.gfxlayout.Layout || layoutOpt:
			//     Either a layout instance or a plain JS object that describes the layout to instantiate and its parameters.
			//     In case it is a plain JS object, the object must contain a 'type' property of type String that gives the
			//     name of the Layout subclass to instantiate. The 'layoutOpt' parameter is then passed to the constructor to
			//     configure the layout.
			
			if (this._ibmd_layoutMgr) 
				this._ibmd_layoutMgr._detach();
			var layout = null;
			// layoutOpt is either a Layout instance or a plain JS object that describes the class and its parameters.
			if (layoutOpt instanceof gfxlayout.Layout) {
				layout = layoutOpt;
			} else if (layoutOpt) {
				var t = layoutOpt.type;
				if (!t) 
					ErrorReporter.error("UnexpectedArgument", this, "setLayout", "layoutOpt.type", layoutOpt);
				var type = lang.getObject(t, false);
				if (typeof(type) == "function") {
					layout = new type(layoutOpt);
				} else {
					ErrorReporter.error("UnexpectedArgument", this, "setLayout", "layoutOpt.type", layoutOpt);
				}
			}
			this._ibmd_layoutMgr = layout;
			if (this._ibmd_layoutMgr) {
				this._ibmd_layoutMgr._attach(this);
				this._ibmd_layoutMgr.invalidate();
			}
		},
		
		getLayout: function(){
			// summary:
			//     Gets the layout manager set on this container.
			
			return this._ibmd_layoutMgr; /*ibm_ilog.diagram.gfxlayout.Layout*/
		},
		
		_needsLayout: false,
		
		needsLayout: function(){
			// summary:
			//     Marks this container as needed to be layed out the next pass.
			this._needsLayout = true;
		},
		
		_oldLayoutRect: null,
		
		applyLayout: function(/*Rectangle*/rect){
			// summary: Lays out this container.
			// rect: Rectangle: 
			
			if (this._ibmd_layoutMgr) {
				// check a layout is needed: either because computePreferredSize as marked it as needed, or
				// if the rect is different from the previous one.
				var doIt = this._needsLayout || !this._oldLayoutRect ||
				this._oldLayoutRect.width !== rect.width ||
				this._oldLayoutRect.height !== rect.height;
				if (doIt) {
					this._oldLayoutRect = lang.clone(rect);
					try {
						// Delegate to the layout manager.
						// Layout is done relative to the parents (ie. (0,0) )
						this._ibmd_layoutMgr.doLayout({
							x: 0,
							y: 0,
							width: rect.width,
							height: rect.height
						});
					} finally {
						this._needsLayout = false;
					}
				}
				// then positioned this container to the right coord
				//
				// remove the previous transform set by the layout
				var t = this.getTransform() || matrix.identity;
				// 'disable' the transform set previously by the layout
				// so here, t is all the transforms except the one from the layout
				if (this.__oldLayoutTransform && !this.__oldLayoutTransform.isIdentity()) {
					t = matrix.multiply(this.__oldLayoutTransform.inverse(), t);
				}
				var bbox = this.getBoundingBox();
				if (t && bbox) 
					bbox = t.transformRectangle(bbox);
				var dx = rect.x, dy = rect.y;
				if (dx != 0 || dy != 0) {
					this.__oldLayoutTransform = matrix.translate(dx, dy);
					t = matrix.multiply(this.__oldLayoutTransform,t);
					var oldt = this.getTransform();
					if (!(oldt != null && oldt.isSame(t))) 
						this.setTransform(t);
				} else {
					this.__oldLayoutTransform = null;
				}
			} else {
				gfxlayout._LayoutShapeExt.applyLayout.call(this, rect);
			}
		},
		
		_recomputeSize: false,
		
		invalidate: function(){
			// summary:
			//     Invalidates this shape.
			
			if (this._suspendInvalidate) 
				return;
			var p = this.getParent();
			var lmgr = this._ibmd_layoutMgr;
			// do nothing if a layout is running or no parent and no layout        
			if ((!lmgr && !p) || (lmgr && lmgr.inLayout())) 
				return;
			// marks the panel so that its preferred size needs to be recomputed the next pass.
			this._recomputeSize = true;
			// propagate to the parent hierarchy
			if (p && p._ibmd_layoutMgr) 
				p.invalidate();
			else if (lmgr) 
				// no parent or no parent panel, invalidate this one
				gfxlayout.postInvalidate(this);
		},
		
		_oldProposedSize: null,
		
		_computePreferredSize: function(proposedSize){
			// summary:
			//     Computes the preferred size of this panel.
			
			var sz;
			// empty ? nothing to do
			if (this.children.length == 0) 
				return this.getExplicitSize();
			if (this._ibmd_layoutMgr) {
				// recompute the size only if it has been explicitely marked as needed
				// or if the proposed size is different from the previous one.
				if (this._explicitSize) {
					proposedSize = this._explicitSize;
				}
				if (this._recomputeSize === true) {
					try {
						sz = this._computeLayoutPreferredSize(proposedSize);
						this.needsLayout();
					} finally {
						this._recomputeSize = false;
					}
				} else if (!this._oldProposedSize ||
				proposedSize.width !== this._oldProposedSize.width ||
				proposedSize.height !== this._oldProposedSize.height) {
				
					sz = this._computeLayoutPreferredSize(proposedSize);
					this.needsLayout();
				} else {
					// do not recompute the size.
					sz = this.getPreferredSize();
				}
			} else {
				// call bbox
				sz = gfxlayout._LayoutShapeExt._computePreferredSize.call(this, proposedSize);
			}
			return sz;
		},
		
		_computeLayoutPreferredSize: function(proposedSize){
			// summary:
			//     Computes the preferred size with the layout.
			
			this._oldProposedSize = {
				width: proposedSize.width,
				height: proposedSize.height
			};
			var sz = this._ibmd_layoutMgr.computePreferredSize(proposedSize);
			var t = this.getTransform();
			if (t) {
				var rect = {
					x: 0,
					y: 0,
					width: sz.width,
					height: sz.height
				};
				rect = t.transformRectangle(rect);
				sz.width = rect.width;
				sz.height = rect.height;
			}
			return sz;
		},
		
		getExplicitSize: function(){
			// summary:
			//     Returns the explicit size of this container.
			
			if (!this._explicitSize) {
				this._explicitSize = {
					width: -1, // = auto
					height: -1 // = auto
				};
			}
			return {
				width: this._explicitSize.width,
				height: this._explicitSize.height
			};
		},
		
		setExplicitSize: function(size){
			// summary:
			//     Sets the explicit size of this shape.
			
			this._explicitSize = {
				width: size.width,
				height: size.height
			};
			this.invalidate();
		},
		
		_computeBoundingBox: function(){
			// if it has been marked as modified, ensure it is validated before computing the bounding box
			if (this._recomputeSize && this._ibmd_layoutMgr) 
				gfxlayout.doPendingValidate(this);
			var bbox = diagext.BoundingBoxFix._computeBoundingBox.call(this);
			if (bbox && this._ibmd_layoutMgr) {
				return this._ibmd_layoutMgr.adjustBBox(bbox);
			} else {
				return bbox;
			}
		}
	};
	
	lang.extend(gfx.Group, gfxlayout._PanelExt);
	
	return gfxlayout;
});
