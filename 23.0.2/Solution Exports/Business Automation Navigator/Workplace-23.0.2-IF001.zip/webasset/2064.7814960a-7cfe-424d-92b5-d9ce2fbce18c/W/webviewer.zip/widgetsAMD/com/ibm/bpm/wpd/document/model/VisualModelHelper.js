define([],

function() {

var _helper = {

decorateNodesWithImage : function(model, params){
	var userCounts = {};
	var activityIds = [];

	for (var i=0; i< params.length; i++) {	
		
		this.addPropertyToNode(model, params[i].activityId, 'decorator', params[i].imagePath, "UserTask");
		
		if(userCounts[params[i].activityId]){
            userCounts[params[i].activityId]++;
        } else {
			userCounts[params[i].activityId] = 1;
			activityIds.push(params[i].activityId);
        }
	}
	
	var str;
	for(var i=0; i<activityIds.length; i++){
		if(userCounts[params[i].activityId]>1){
			str = ['(', userCounts[params[i].activityId],')'].join('');
			this.addPropertyToNode(model, params[i].activityId, 'decoratorCount', str);
		}
	}
},

addPropertyToNode : function(model, nodeId, propertyName, value, bpmn2TaskTypeFilter ){
	//traverse the model to find the nodes
	var node;
	for (var i=0; i<model["items"].length; i++) {
		node = model["items"][i];		
		if(node.id == nodeId && (typeof(bpmn2TaskTypeFilter)=="undefined" || (bpmn2TaskTypeFilter==node.bpmn2TaskType) ) ){
			node[propertyName] = value;
		}
	}		
}

}

return _helper;

});
