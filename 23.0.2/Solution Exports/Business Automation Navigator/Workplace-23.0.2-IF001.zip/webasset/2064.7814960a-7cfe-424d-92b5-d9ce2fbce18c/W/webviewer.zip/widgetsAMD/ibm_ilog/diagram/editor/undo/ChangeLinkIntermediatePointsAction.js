/*
 * Licensed Materials - Property of IBM
 * © Copyright IBM Corporation 2010,2012. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 */
define([
"dojo/_base/declare",
"dojo/_base/lang",
"./Action",
"./UndoActionList"
], function(
declare,
lang,
Action,
UndoActionList
){

/*=====
var Action = ibm_ilog.diagram.editor.undo.Action;
=====*/

	var ChangeLinkIntermediatePointsAction =
	declare("ibm_ilog.diagram.editor.undo.ChangeLinkIntermediatePointsAction", [Action], {
		//	
		// summary:
		//		this action undo/redo any Connect action.
		//		This action must be modified for the user if any user defined action is done on a connect action.
		//
		_linkId: null,
		_newPoint: null,
		_oldPoint:null,
		_index:null,
		_operation: null,
	constructor:function(diagram,link){
		//	
		// summary:
		//		creates a new instance, setting the corresponding label
		this._linkId = link.getId();
		this.initialize(lang.hitch(this,this._undoFunction),lang.hitch(this,this._redoFunction));
	},
	setRemovePointOperation: function(index,oldPoint){
		this._operation = 0;
		this._label = UndoActionList.RemoveIntermediatePoint;
		this._index = index;
		this._oldPoint = lang.clone(oldPoint);
	},
	setAddPointOperation: function(index,point){
		this._operation = 1;
		this._label = UndoActionList.AddIntermediatePoint;
		this._index = index;
		this._newPoint = lang.clone(point);
	},
	setModifyPointOperation: function(index,newPoint,oldPoint){
		this._operation = 2;
		this._label = UndoActionList.ModifyIntermediatePoint;
		this._index = index;
		this._oldPoint = lang.clone(oldPoint);
		this._newPoint = lang.clone(newPoint);
	},
	getLink: function(){
		//	
		// summary:
		//		returns the link, looking for replaces if necessary
		return this.getUndoManager().getRegisteredGraphElement(this._linkId);
	},
	_undoFunction: function(){
		var link = this.getLink();
		switch(this._operation){
			case 0: // Remove
				this._addPoint(link,this._index,this._oldPoint);
				break;
			case 1: // Add
				this._removePoint(link,this._index);
				break;
			case 2: // Modify
				this._modifyPoint(link,this._index,this._oldPoint);
				break;
			}
	},
	_redoFunction: function(){
		var link = this.getLink();
		switch(this._operation){
			case 0: // Remove
				this._removePoint(link,this._index);
				break;
			case 1: // Add
				this._addPoint(link,this._index,this._newPoint);
				break;
			case 2: // Modify
				this._modifyPoint(link,this._index,this._newPoint);
				break;
			}
	},
	_removePoint: function(link,index){
		var intermediatePoints = link.getIntermediatePoints();
		intermediatePoints = intermediatePoints.slice(0,index).concat(intermediatePoints.slice(index+1))
		link.setIntermediatePoints(intermediatePoints);
	},
	_addPoint: function(link,index,point){
		var intermediatePoints = link.getIntermediatePoints();
		intermediatePoints = intermediatePoints.slice(0,index).concat([point]).concat(intermediatePoints.slice(index));
		link.setIntermediatePoints(intermediatePoints);
	},
	_modifyPoint: function(link,index,point){
		var intermediatePoints = link.getIntermediatePoints();
		intermediatePoints[index].x = point.x;
		intermediatePoints[index].y = point.y;
		link.setIntermediatePoints(intermediatePoints);
	}
	});
	
	return ChangeLinkIntermediatePointsAction;
	
});
