/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof SlideoutPanel
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof SlideoutPanel
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof SlideoutPanel
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof SlideoutPanel
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof SlideoutPanel
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof SlideoutPanel
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof SlideoutPanel
 * @method triggerFormulaUpdates
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 * </table>
 */
workplace_control_InitSlideoutPanel = function (utilities, taskUtils, domStyle, domClass)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            EVT_ON_CLOSE: "eventON_CLOSE",
            EVT_ON_SHOW: "eventON_SHOW",
            _setStack: function _setStack(view, targetView) {
                bpmext.log.info("SlideoutPanel._setStack LOG >> ", view);
                var i, targetViewIndex, paneCount = view._instance.stack.getPaneCount();

                view._instance.panelOptions = {};
                view._instance.currentView = {};

                for(i=0; i<paneCount; i++){
                    if(view._instance.stack.getViewInPane(i) && view._instance.stack.getViewInPane(i).context.viewid === targetView){
                        targetViewIndex = i;
                        view._instance.currentView = view._instance.stack.getViewInPane(i);
                        view._instance.stack.setCurrentPane(targetViewIndex);
                        break;
                    }
                }

                if(view._instance.currentView && view._instance.currentView.SLIDEOUT_OPTIONS){
                    var slideoutOptions = view._instance.currentView.SLIDEOUT_OPTIONS;
                    if(slideoutOptions.title!=null){
                        view._instance.title.setLabel(slideoutOptions.title);
                    }
                    if(slideoutOptions.subtitle!=null){
                        view._instance.subtitle.setLabel(slideoutOptions.subtitle);
                    }
                    if(slideoutOptions.primaryBtnText!=null){
                        view._instance.primaryButton.setText(slideoutOptions.primaryBtnText);
                        view._instance.primaryButton.setVisible(true,true);
                    }else{
                        view._instance.primaryButton.setVisible(false,true);
                    }
                    if(slideoutOptions.secondaryBtnText!=null){
                        view._instance.secondaryButton.setText(slideoutOptions.secondaryBtnText);
                        view._instance.secondaryButton.setVisible(true,true);
                    }else{
                        view._instance.secondaryButton.setVisible(false,true);
                    }
                    if(slideoutOptions.primaryBtnEvent!=null){
                        view._instance.panelOptions.primaryBtnEvent = dojo.clone(slideoutOptions.primaryBtnEvent);
                    }
                    if(slideoutOptions.secondaryBtnEvent!=null){
                        view._instance.panelOptions.secondaryBtnEvent = dojo.clone(slideoutOptions.secondaryBtnEvent);
                    }
                    if(slideoutOptions.onPanelClose!=null){
                        view._instance.panelOptions.onPanelClose = dojo.clone(slideoutOptions.onPanelClose);
                    }
                    if(slideoutOptions.onPanelShow!=null){
                        view._instance.panelOptions.onPanelShow = dojo.clone(slideoutOptions.onPanelShow);
                    }
                    if(slideoutOptions.width!=null){
                        view._instance.panelOptions.width = dojo.clone(slideoutOptions.width);
                    }
                    if(slideoutOptions.progressBarOptions!=null){
                        view._instance.panelOptions.progressBarOptions = dojo.clone(slideoutOptions.progressBarOptions);
                    }
                }
            },
            _executeEvent: function _executeEvent(view, targetEvent) {
                bpmext.log.info("SlideoutPanel._executeEvent LOG >> ", view);
                if(targetEvent && targetEvent.method){
                    targetEvent.method(targetEvent.args);
                    if(targetEvent.closeOnEvtComplete){
                        view.closePanel();
                    }
                }
            },
            _setButton: function _setButton(buttonControl, buttonOption){
                bpmext.log.info("SlideoutPanel._setButton LOG >> ", buttonControl);
                if(buttonControl && buttonOption){
                    if(buttonOption.visible!=null){
                        buttonControl.setVisible(buttonOption.visible, true);
                    }
                    if(buttonOption.enable!=null){
                        buttonControl.setEnabled(buttonOption.enable);
                    }
                    if(buttonOption.text!=null){
                        buttonControl.setText(buttonOption.text);
                    }
                }
            },
            _getProgressViewIndex: function _getProgressViewIndex(view){
                bpmext.log.info("SlideoutPanel._getProgressViewIndex LOG >> ", view);
                var index, pathName = view.context.parentView().context.controlidpath;
                if (/\[\d+\]$/.test(pathName)) {
                    index = parseInt(pathName.substring(pathName.lastIndexOf("[")+1,pathName.lastIndexOf("]")));
                } else{
                    index = -1;
                }
                return index;
            }
        };

		/*
        Public control methods *************************************************************
        */
        /**
         * @instance
         * @memberof SlideoutPanel
         * @method primaryButtonHandler
         * @desc primary button event handler
         */
        this.constructor.prototype.primaryButtonHandler = function primaryButtonHandler() {
            bpmext.log.info("SlideoutPanel.primaryButtonHandler ENTER >>", this);

            this._proto._executeEvent(this, this._instance.panelOptions.primaryBtnEvent);

            bpmext.log.info("SlideoutPanel.primaryButtonHandler EXIT >>", this);
        };

        /**
         * @instance
         * @memberof SlideoutPanel
         * @method secondaryButtonHandler
         * @desc secondary button event handler
         */
        this.constructor.prototype.secondaryButtonHandler = function secondaryButtonHandler() {
            bpmext.log.info("SlideoutPanel.secondaryButtonHandler ENTER >>", this);

            this._proto._executeEvent(this, this._instance.panelOptions.secondaryBtnEvent);

            bpmext.log.info("SlideoutPanel.secondaryButtonHandler EXIT >>", this);
        };

        /**
         * @instance
         * @memberof SlideoutPanel
         * @method closePanel
         * @desc Triggered the event to close the slideout panel
         */
        this.constructor.prototype.closePanel = function closePanel() {
            taskUtils.EVENTS.SLIDEOUT_PANEL_CLOSE.publish();
        };


        /**
         * @instance
         * @memberof SlideoutPanel
         * @method closeSlideOut
         * @desc Closes the slideout panel
         */
        this.constructor.prototype.closeSlideOut = function closeSlideOut() {
            bpmext.log.info("SlideoutPanel.closeSlideOut ENTER >>", this);

            this._proto._executeEvent(this, this._instance.panelOptions.onPanelClose);
            bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ON_CLOSE);

            this._instance.panelOptions = {};
            this._instance.currentView = {};
            this._instance.progressBar.setViewData([], true);
            var panelDom = this.context.element;
            domClass.add(panelDom, "collapseSlideout");
            domStyle.set(panelDom, {
                right: "-100%"
            });
            var innerPanelDom = this._instance.panelLayout.context.element;
            domStyle.set(innerPanelDom, {
                "background-color": "unset"
            });
            this.hide(true);
            document.body.classList.remove("modal-open");

            bpmext.log.info("SlideoutPanel.closeSlideOut EXIT >>", this);
        };

        /**
         * @instance
         * @memberof SlideoutPanel
         * @method showPanel
         * @desc Shows the slideout panel
         */
        this.constructor.prototype.showPanel = function showPanel() {
            bpmext.log.info("SlideoutPanel.showPanel ENTER >>", this);
            var self = this;
            if(this._instance.currentView){
                if(this._instance.panelOptions){
                  //Set Width
                    var domElement = this._instance.panelLayout.context.element.querySelector(".ContentBox");
                    if(this._instance.panelOptions.width){
                        domStyle.set(domElement, {
                            width: this._instance.panelOptions.width
                        });
                    }else{
                        domStyle.set(domElement, {
                            width: taskUtils.DEFAULT_SLIDEOUT_PANEL_WIDTH
                        });
                    }
                    //Progress Bar
                    if(this._instance.panelOptions.progressBarOptions && this._instance.panelOptions.progressBarOptions.progressBarSteps && this._instance.panelOptions.progressBarOptions.progressBarSteps.length > 0){
                        this.setProgressSteps(this._instance.panelOptions.progressBarOptions.progressBarSteps);
                        this._instance.progressBar.setVisible(true);
                    }else{
                        this._instance.progressBar.setVisible(false, true);
                    }

                    this._proto._executeEvent(this, this._instance.panelOptions.onPanelShow);
                }

                bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ON_SHOW);
                if (this._instance.currentView.setVisible) {
                    this._instance.currentView.setVisible(true);
                }
                this.show();
                document.body.classList.add("modal-open");
                var panelDom = this.context.element;
                domClass.remove(panelDom, "collapseSlideout");
                domStyle.set(panelDom, {
                    right: 0
                });
                var innerPanelDom = this._instance.panelLayout.context.element;
                domStyle.set(innerPanelDom, {
                    "background-color": "rgba(0,0,0,0.5)"
                });

                panelDom.setAttribute("role", "dialog");
                panelDom.setAttribute("aria-labelledby", this._instance.title._instance.label.id);
                panelDom.setAttribute("aria-modal", "true");

                setTimeout(function() {
                    self._instance.closeButton.context.element.querySelector(".SPARKIcon").focus();
                }, 50);
            }
            bpmext.log.info("SlideoutPanel.showPanel EXIT >>", this);
        };

        /**
         * @instance
         * @memberof SlideoutPanel
         * @method setProgressSteps
         * @desc Add steps to the progress bar
         */
        this.constructor.prototype.setProgressSteps = function setProgressSteps(steps) {
            bpmext.log.info("SlideoutPanel.setProgressSteps ENTER >>", this);
            if(steps){
                this._instance.progressBar.context.binding.set("value", steps);
            }
            bpmext.log.info("SlideoutPanel.setProgressSteps EXIT >>", this);
        };

        /**
         * @instance
         * @memberof SlideoutPanel
         * @method setProgressText
         * @desc Sets the text of progress view
         */
        this.constructor.prototype.setProgressText = function setProgressText(view) {
            bpmext.log.info("SlideoutPanel.setProgressText ENTER >>", this);
            var progressIndex = this._proto._getProgressViewIndex(view);
            var steps = this._instance.progressBar.context.binding.get("value");
            if(progressIndex > -1 && steps && steps.items.length > progressIndex){
                view.setText(steps.get(progressIndex).displayText);
            }
            bpmext.log.info("SlideoutPanel.setProgressText EXIT >>", this);
        };

        /**
         * @instance
         * @memberof SlideoutPanel
         * @method setProgressIcon
         * @desc Sets the icon of progress view
         */
        this.constructor.prototype.setProgressIcon = function setProgressIcon(view) {
            bpmext.log.info("SlideoutPanel.setProgressIcon ENTER >>", this);
            var viewStep = this._proto._getProgressViewIndex(view) + 1;
            var steps = this._instance.progressBar.context.binding.get("value");
            if( steps &&
                this._instance.panelOptions &&
                this._instance.panelOptions.progressBarOptions &&
                this._instance.panelOptions.progressBarOptions.currentStep &&
                this._instance.panelOptions.progressBarOptions.currentStep > 0 &&
                this._instance.panelOptions.progressBarOptions.currentStep <= steps.items.length
            ){
                var currentStepIndex = this._instance.panelOptions.progressBarOptions.currentStep;
                var className, domElement = view.context.parentView().context.element;
                if(viewStep === currentStepIndex){
                    view.setIcon("ci"); // leave blank just use blue circle
                    view.setIconSize("16px");
                    className = "currentProgress";
                }else if ( viewStep < currentStepIndex ){
                    view.setIcon("ci-checkmark-outline");
                    view.setIconSize("16px");
                    className = "completedProgress";
                }else{
                    view.setIcon("ci-radio-button");
                    view.setIconSize("16px");
                    className = "futureProgress";
                }
                domClass.add(domElement, className);
            }
            bpmext.log.info("SlideoutPanel.setProgressIcon EXIT >>", this);
        };

		 /*
        Coach NG Load Lifecycle method *************************************************************
         */
        this.constructor.prototype.load = function ()
        {
            var view = this;

            bpmext.log.info("SlideoutPanel.load ENTER >>", this);

            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ON_CLOSE);
            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ON_SHOW);

            this._instance.closeButton = bpmext.ui.getView("Icon1", this);
            this._instance.title = bpmext.ui.getView("Title", this);
            this._instance.subtitle = bpmext.ui.getView("Subtitle", this);

            this._instance.stack = bpmext.ui.getContainer("Stack", this);

            this._instance.primaryButton = bpmext.ui.getView("PrimaryButton", this);
            this._instance.secondaryButton = bpmext.ui.getView("SecondaryButton", this);

            this._instance.panelLayout = bpmext.ui.getContainer("PanelLayout", this);
            this._instance.progressBar = bpmext.ui.getContainer("ProgressBar", this);
            this._instance.progressBar.setViewData([{displayText: "", value: "0"}], true);

            taskUtils.EVENTS.SLIDEOUT_PANEL_EXPAND.subscribe(function (eventName, eventData) {
                this._proto._setStack(this, eventData.targetView);
                this.showPanel();
            }, this);

            taskUtils.EVENTS.SLIDEOUT_PANEL_CLOSE.subscribe(function () {
                this.closeSlideOut();
            }, this);

            taskUtils.EVENTS.SLIDEOUT_SET_PRIMARY_BTN.subscribe(function (eventName, eventData){
                this._proto._setButton(this._instance.primaryButton, eventData);
            }, this);

            taskUtils.EVENTS.SLIDEOUT_SET_SECONDARY_BTN.subscribe(function (eventName, eventData){
                this._proto._setButton(this._instance.secondaryButton, eventData);
            }, this);

            this.context.element.querySelector(".Vertical_Layout").onclick = function(e){
                if(e.target.parentElement.id === view.context.element.id){
                    view.closePanel();
                }
            };

            var secondaryButton = this._instance.secondaryButton._instance.btn;
            var primaryButton = this._instance.primaryButton._instance.btn;
            var closeButton = this._instance.closeButton._instance.btn;

            primaryButton.onkeydown = function(event) {
                if (event.key === "Tab") {
                    if (event.shiftKey) {
                        return;
                    }
                    event.preventDefault();
                    closeButton.focus();
                }
            };

            secondaryButton.onkeydown = function(event) {
                if (primaryButton.classList.contains("disabled") && event.key === "Tab") {
                    if (event.shiftKey) {
                        return;
                    }
                    event.preventDefault();
                    closeButton.focus();
                }
            };

            closeButton.onkeydown = function(event) {
                if (event.key === "Tab" && event.shiftKey) {
                    event.preventDefault();
                    if (primaryButton.classList.contains("disabled")) {
                        secondaryButton.focus();
                    } else {
                        primaryButton.focus();
                    }
                }

                if (event.key === " " || event.key === "Spacebar") {
                    event.preventDefault();
                    view.closePanel();
                }
            };

            this.setVisible(false, false);

            this.loadView(this);

            bpmext.log.info("SlideoutPanel.load EXIT >>", this);
		};

        /*
        Coach NG VIew Lifecycle method *************************************************************
         */
        this.constructor.prototype.view = function ()
        {
            try
            {
                utilities.handleVisibility(this.context);
            }
            catch (e)
            {
                //{#feature: US-1330 Added RT localization}
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if(e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                }
            }
        };

		/*
        Coach NG Unload Lifecycle method *************************************************************
         */
        this.constructor.prototype.unload = function ()
        {
            bpmext.ui.unloadView(this);
        };
    }
};