/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof CaseList
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof CaseList
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof CaseList
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof CaseList
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof CaseList
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof CaseList
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof CaseList
 * @method triggerFormulaUpdates
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>This event is fired whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On Case Launched:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when a case is launched from the case list.</td>
 *               </tr>
 *           </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">case {object}</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">instance data</td>
 *               </tr>
 *       </table>
 *     </td>
 *   </tr>
 * </table>
 */
workplace_control_InitCaseList = function (utilities, taskUtils, wpResources, domConstruct, resourceUtils, domClass, domAttr)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            //Event constants
            EVT_ONINSTANCE_LAUNCHED : "eventON_CASE_LAUNCHED",

            _errorLoadInstances: function _errorLoadInstances(view, data) {
                bpmext.log.error("CaseList._errorLoadInstances ERROR >> There was an error loading the instances (data): " + data, view);
                //show the NoInstances view and hide the others
                view._instance.casesTable.setVisible(false, true);
                view._instance.loadingTable.setVisible(false, true);
                view._instance.paginationView.setVisible(false, true);
                view._instance.noCasesToDisplayView.setVisible(true, true);

                if (data && data.response && data.response.data && data.response.data.status === 500 && data.response.data.errorNumber === "CWMFS4021E") {
                    view._instance.startCaseBtn.setEnabled(false, true);
                    view._instance.filtersButton.setEnabled(false, true);
                    view._instance.searchBar.setEnabled(false, true);
                }
            },

            _getType: function _getType(view, data) {
            	var systemInfo, type = view._instance.processesResource.TYPE.PROCESSES;
            	if(data.systemID) {
            		systemInfo = resourceUtils.getFederatedSystemInfo(data.systemID);
            		if(systemInfo.systemType === "SYSTEM_TYPE_CASE") {
            			type = view._instance.processesResource.TYPE.CASES;
            		} else if (data.isWorkstream || data.bpdName === "Configurable Workstream" || data.processName === "Configurable Workstream") {
            			type = view._instance.processesResource.TYPE.WORKSTREAMS;
            		}
            	}
            	return type;
            },
            _retrieveRolePage: function _retrieveRolePage(rolepages){
            	//find and return cshs page associated to role if exists otherwise return non-cshs
            	var rolePage = {};
            	var pageIndex = null;
            	for (var i = 0; i < rolepages.length; i++) {
            		if(rolepages[i].viewCaseInstanceUsingCSHSPage === "true"){
            			pageIndex = i;
            			break;
            		}
            	}
            	rolePage = pageIndex ? rolepages[i] : rolepages[0]
            	return rolePage;
            },
            _launchCase:  function _launchCaseInstance(view, data) {
                bpmext.log.info("CaseList._launchCaseInstance LOG >> (data): " + data, view);
                var curSystemInfo, runURLPrefix = dojoConfig.App._bpmContextRootMap.teamworks, tosName, servletURLPrefix, piid = data.piid || data.PI_PIID, templateID = data.templateId || data.PT_PTID;
				if(data.systemID) {
					curSystemInfo = resourceUtils.getFederatedSystemInfo(data.systemID);
    				runURLPrefix = curSystemInfo.taskCompletionUrlPrefix;
    				servletURLPrefix = curSystemInfo.restUrlPrefix;
            		tosName = curSystemInfo.targetObjectStoreName;
				}

				if(data.type === view._instance.processesResource.TYPE.CASES) {
					if(view._instance.allCaseTypes && view._instance.allCaseTypes.length > 0) {
                     	for (var i = 0; i < view._instance.allCaseTypes.length; i++) {
                     		if(view._instance.allCaseTypes[i].casetypeSymbolicName === templateID) {
                     			if(view._instance.allCaseTypes[i].roleCasePageinfo.length > 0){ // checks if any override role cases details page.
                     				var rolePage = view._proto._retrieveRolePage(view._instance.allCaseTypes[i].roleCasePageinfo);
                         			data.openInNewWindow = !(rolePage.viewCaseInstanceUsingCSHSPage === "true");
                         			data.roleName = rolePage.roleName;
                         			data.viewCaseInstanceServletPath = view._instance.allCaseTypes[i].viewCaseInstanceServletPath;
                         			
                     			}else{
                     				data.openInNewWindow = (view._instance.allCaseTypes[i].viewCaseInstanceUsingCSHSPage === "false");
                         			data.viewCaseInstanceServletPath = view._instance.allCaseTypes[i].viewCaseInstanceServletPath;
                     			}
                     			break;
                     		}
                     	}
                    } else {
                    	// set a default servlet path
                    	data.viewCaseInstanceServletPath = "casedetails";
                    }
					///https://catling1.fyre.ibm.com:9443/CaseManager/casedetails?TargetObjectStore=tos&caseId=30559D74-0000-CF15-8C32-8ED62FCCA235
					data.runURL = servletURLPrefix
						+ data.viewCaseInstanceServletPath + "?TargetObjectStore=" + tosName + "&caseId=" + piid;
					if(data.roleName){
						data.runURL = data.runURL +"&Role="+data.roleName
					}
				} else {
					data.runURL = runURLPrefix + "/launchInstanceUI?origin=workplace&instanceId=" + piid;
				}

				if(data.openInNewWindow) {
					taskUtils.EVENTS.NOTIFICATION_OPEN_NAVIGATOR.publish({url:data.runURL, name:templateID});
				} else {
					taskUtils.EVENTS.SERVICE_LAUNCHED.publish(data);
				}
            },

            _launchInstance: function _launchInstance(view, data) {
                bpmext.log.info("CaseList._launchInstance LOG >> (data): " + data, view);
                bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONINSTANCE_LAUNCHED, data);
                
                var openNewWindow = false;
                if (view._instance.userPrefs[wpResources.user.PREFERENCE.portalOpenTaskInNewWindow] == "generalPreference.fields.openTaskInNewWindow.default"){
                    wpResources.config.get().then(function(mashupsConfig) {
                        openNewWindow = mashupsConfig.openTaskInNewWindow;
                    });
                } else if (view._instance.userPrefs[wpResources.user.PREFERENCE.portalOpenTaskInNewWindow] == "generalPreference.fields.openTaskInNewWindow.yes") {
                    openNewWindow = true;
                }

                if (view.context.options.openInNewWindow || openNewWindow){
                    data.openInNewTab = view.context.options.openInNewWindow.get("value") || openNewWindow;
                }
                
                if(data.openInNewTab){
                    var curSystemInfo, runURLPrefix = dojoConfig.App._bpmContextRootMap.teamworks, tosName, servletURLPrefix, piid = data.piid || data.PI_PIID, templateID = data.templateId || data.PT_PTID;
                    if(data.systemID) {
                        curSystemInfo = resourceUtils.getFederatedSystemInfo(data.systemID);
                        runURLPrefix = curSystemInfo.taskCompletionUrlPrefix;
                        servletURLPrefix = curSystemInfo.restUrlPrefix;
                        tosName = curSystemInfo.targetObjectStoreName;
                    }

                    if(data.type === view._instance.processesResource.TYPE.CASES) {
                        if(view._instance.allCaseTypes && view._instance.allCaseTypes.length > 0) {
                            for (var i = 0; i < view._instance.allCaseTypes.length; i++) {
                                if(view._instance.allCaseTypes[i].casetypeSymbolicName === templateID) {
                                    data.openInNewWindow = (view._instance.allCaseTypes[i].viewCaseInstanceUsingCSHSPage === "false");
                                    data.viewCaseInstanceServletPath = view._instance.allCaseTypes[i].viewCaseInstanceServletPath;
                                    break;
                                }
                            }
                        } else {
                            // set a default servlet path
                            data.viewCaseInstanceServletPath = "casedetails";
                        }
                        data.runURL = servletURLPrefix
                            + data.viewCaseInstanceServletPath + "?TargetObjectStore=" + tosName + "&caseId=" + piid;
                    } else {
                        data.runURL = runURLPrefix + "/launchInstanceUI?origin=workplace&instanceId=" + piid;
                    }
                    window.open(data.runURL, '_blank').focus();
                }else if (data.isWorkstream) {
                    taskUtils.EVENTS.BEFORE_VIEW_INSTANCE.publish(data);
                } else {
                   this._launchCase(view, data);
                }
            },

            _errorLaunchInstance: function _errorLaunchTask(data) {
                bpmext.log.info("CaseList._errorLaunchInstance ERROR >> (data): " + data, this);
            },

            _updatePager: function _updatePager(view){
                bpmext.log.info("CaseList._updatePager LOG >> ENTER: ", view);
                view._instance.casesTable.setPageSize(view._instance.pageSize);
                //Cache the page size
                view._instance.pageSize = view._instance.casesTable.getOption("pageSize");
            },

            _getQueryOptions: function _getQueryOptions(view) {
                var queryOption = {};
            	if(view._instance.filterByProject && view._instance.filterByProject !== "") {
            		queryOption.projectFilter = view._instance.filterByProject.split(",");
            	}
                if(view._instance.searchTerm && view._instance.searchTerm !== ""){
                    queryOption.fullTextSearchFilter = view._instance.searchTerm;
                }
                queryOption.caseScope = view._instance.caseScope;
                queryOption.offset = parseInt(view._instance.paginationView.getCurPageNumber())-1;
                if(view._instance.currentSort != null){
                    queryOption.limit = 0;
                }else{
                    queryOption.limit = view._instance.paginationView.getPerPage() || 10;
                }
                if (view._instance.filterConditions) {
                    var filterConditions = dojo.clone(view._instance.filterConditions), dateString;
                    for (var x = 0; x < filterConditions.length; x++) {
                    	var field = filterConditions[x].field, operator = filterConditions[x].operator, value = filterConditions[x].value;
                        if (field === "interaction") {
                            if (value && value !== view._instance.processesResource.INTERACTION.ALL) {
                        		queryOption.statusFilter = [value];
                            }
                        } else if (field === "type") {
                    		queryOption.type = value;
                        } else if (field === "projectFilter") {
                    		queryOption.projectFilter = queryOption.projectFilter? queryOption.projectFilter.concat(value): [value];
                        } else if (field === "creationDate") {
                            dateString = view._proto._convertToJSON(value);
                        	if(operator === "LessThan") {
                        		queryOption.createdBefore = dateString;
                        	} else if (operator === "GreaterThan"){
                        		queryOption.createdAfter = dateString;
                        	} else{
                                queryOption.createdBefore = view._proto._getEndDate(dateString);
                                queryOption.createdAfter = view._proto._getStartDate(dateString);
                            }
                        } else if (field === "lastModificationTime") {
                            dateString = view._proto._convertToJSON(value);
                        	if(operator === "LessThan") {
                        		queryOption.modifiedBefore = dateString;
                        	} else if (operator === "GreaterThan"){
                        		queryOption.modifiedAfter = dateString;
                        	} else{
                                queryOption.modifiedBefore = view._proto._getEndDate(dateString);
                                queryOption.modifiedAfter = view._proto._getStartDate(dateString);
                            }
                        } else if (field === "lastModifiedBy") {
                        	queryOption.lastModifiedBy = value;
                        } else if (field === "createdBy") {
                        	queryOption.starterId = [value];
                        	/**
                        	if(operator === taskUtils.OPERATOR.EQUALS) {
                        		queryOption.createdBy = value;
                        	} else if(operator === taskUtils.OPERATOR.CONTAINS) {
                        		queryOption.createdBy = "*" + value + "*";
                        	} else if(operator === taskUtils.OPERATOR.STARTS_WITH) {
                        		queryOption.createdBy = value + "*";
                        	}**/
                        }
                    }
                }

                return queryOption;
            },

            _generateInstanceQueryObject: function _generateInstanceQueryObject(view, sort) {
                return wpResources.isFederated ? {
                    calcStats: true,
                    sort: view._proto._getSortingOrder(sort),
                    fields: view._proto._getQueryFields(view),
                    conditions: view._proto._getQueryConditions(view),
                    interaction: view._proto._getQueryInteraction(view),
                    limit: view._proto._getQuerySize(view),
                    offset: parseInt(view._instance.paginationView.getCurPageNumber())-1,
                    includeBusinessData: false,
                    type: view._instance.processesResource.TYPE.CASES
                } : this._getQueryOptions(view);
            },

            _getSortingOrder: function _getSortingOrder(sort) {
                if (!sort) {
                    sort = [];
                }else if (!Array.isArray(sort)){
                    sort = [sort]
                }

                var ascending = wpResources.tasks.SORT_BY.ASCENDING;
                return sort || [ascending("PI_DUE"), ascending("PI_CREATED")];
            },

            _getQueryFields: function _getQueryFields(view) {
                var selectedCols = view._instance.selectedCols || [];

                var fields = dojo.clone(selectedCols);
                fields =  (fields || []).map(function (field) {
                    return field.name;
                });

                fields.push("instanceAtRiskDate");
                fields.push("bpdName");
                fields.push("instanceId");
                fields.push("instanceCompletionDate");
                fields.push("instanceLastModificationDate");
                fields.push("instanceStageStatus");
                fields.push("bpdId");
                fields.push("instanceHealth");
                fields.push("instanceLastModifier");
                fields.push("instanceStarterId");
                fields.push("processAppName");
                
                return fields;
            },

            _getQueryConditions: function _getQueryConditions(view) {
                var filterConditions = view._instance.filterConditions || [];
                var searchTerm = view._instance.searchTerm || "";
                var quickFilterConditions = dojo.clone(view._instance.quickFilterConditions);

                var conditions = dojo.clone(filterConditions);
                conditions = conditions.filter(function (condition) {
                    return condition.field !== "interaction";
                });

                for(var x = conditions.length - 1 ; x>=0; x--){
                    var date = Date.parse(conditions[x].value);
                    if(!isNaN(date) && !/^\d+$/.test(conditions[x].value)){
                        if(conditions[x].operator === taskUtils.OPERATOR.EQUALS){
                            var day = 86400000; //24*60*60*1000
                            var currentValue = conditions[x].value;
                            var startDate = new Date(new Date(currentValue).getTime()-1);
                            var endDate = new Date(new Date(currentValue).getTime()+day);// from local time 00:00 to 23:59
                            var startDateString = JSON.stringify(new Date(startDate.toUTCString())).replace(/"/g, "");
                            var endDateString = JSON.stringify(new Date(endDate.toUTCString())).replace(/"/g, "");
                            conditions[x].operator = taskUtils.OPERATOR.GREATER_THAN;
                            conditions[x].value = startDateString;
                            conditions.push(wpResources.tasks.OPERATOR.LESS_THAN(conditions[x].field, endDateString));
                        }
                    }
                }

                if (searchTerm) {
                    conditions.unshift(wpResources.tasks.OPERATOR.FULL_TEXT_SEARCH(searchTerm || ""));
                }

                if (quickFilterConditions) {
                    conditions = conditions.concat(quickFilterConditions);
                }

                return conditions;
            },

            _getQueryInteraction: function _getQueryInteraction(view) {
                var filterConditions = view._instance.filterConditions || [];

                if (!filterConditions || !Array.isArray(filterConditions)) {
                    filterConditions = [];
                }

                return filterConditions.reduce(function(interaction, condition) {
                    return interaction ? interaction : condition.field === "interaction" ? condition.value : interaction;
                }, "");
            },

            _getQuerySize: function _getQuerySize(view) {
                return view._instance.paginationView.getPerPage() || 10;
            },
            /*********** CONSTRUCT SAVE SEARCH OBJECT END ***********/

            _actualLoadInstances: function _actualLoadInstances(view, queryOption) {
                view._instance.processesResource.get(queryOption).then(function(data) {
                	resourceUtils.populateFederatedSystems(data.federationResult);
                    if (!!data && ((!!data.processes && !!data.processes.length > 0) || (!!data.items && !!data.items.length > 0))) {
                        var col, totalCount = data.stats? data.stats.total: data.overview.Total, processes = data.items || data.processes;
                        var showActionMenu = !view.context.options.hideActionMenu.get("value");
                        taskUtils.EVENTS.SET_STATS.publish(data);
                        view._instance.paginationView.setItemLength(totalCount);
                        bpmext.log.info("CaseList._loadInstances LOG >> Instances to display: " + processes.length, view);
                        //set visibility
                        view._instance.casesTable.setVisible(true);
                        view._instance.noCasesToDisplayView.setVisible(false, true);

                        view._instance.now = new Date();
                        view._instance.currentCols = [];
                        var columnWidths = view._instance.columnWidths || [];
                        var selectedCols = view._instance.selectedCols || [];
                        //Create the column definition for the table(s) based on the selected columns
                        selectedCols.forEach(function (column) {
                            // Dont have to go through each attribute in non-federated env
                            var length =  data.attributeInfo && data.attributeInfo.length || 1;
                            for (var i = 0; i < length; i++) {
                                var curCol = column;
                                if(data.attributeInfo){
                                    curCol = data.attributeInfo[i];
                                }
                                var attrName = curCol.sourceAttribute || curCol.name;
                                if (!!attrName && column.name === attrName) {
                                    if (curCol.name === "riskState" || curCol.sourceAttribute === "instanceStatus") {
                                        //Use a 'C'ustom render on the column
                                        col = {
                                                visibility: true,
                                                sortable: false,
                                                renderAs: "C",
                                                label: taskUtils.getLabelFromInstanceProperty(curCol.sourceAttribute || curCol.name),
                                                dataElementName: curCol.name
                                        };
                                        view._instance.currentCols.push(col);
                                    } else if(curCol.name === "name" || curCol.sourceAttribute === "instanceName") {
                                        col = {
                                                visibility: true,
                                                sortable: true,
                                                renderAs: "C",
                                                dataElementName: curCol.name,
                                                label: taskUtils.getLabelFromInstanceProperty(curCol.sourceAttribute || curCol.name),
                                                name: curCol.name
                                        };
                                        view._instance.currentCols.push(col);
                                    } else {
                                        if (!wpResources.isFederated){
                                            col = {
                                                visibility: true,
                                                sortable: true,
                                                renderAs: "H",
                                                dataElementName: curCol.name,
                                                label: taskUtils.getLabelFromInstanceProperty(curCol.sourceAttribute || curCol.name),
                                                name: curCol.name
                                            };
                                            switch(col.name) {
                                                case "dueDate":
                                                case "creationDate":
                                                    col.type = taskUtils.COLUMN_TYPES.TIMESTAMP;
                                                    col.options = {dateOptions: {selector: "date", formatLength: "medium"}};
                                                    break;
                                                default:
                                                    col.type = taskUtils.COLUMN_TYPES.STRING;
                                            }
                                        }else{
                                            var attrName = curCol.sourceAttribute;
                                            var displayName = taskUtils.getLabelFromInstanceProperty(attrName);
                                            if(column.isBusinessData) {
                                            	if(column.value.indexOf("<") != -1) {
                                                    displayName = column.value.substring(0, column.value.indexOf("<"));
                                                } else {
                                                    displayName = column.value;
                                                }
                                            } 
                                            col = {
                                                visibility: true,
                                                sortable: true,
                                                renderAs: "H",
                                                dataElementName: curCol.name,
                                                label: displayName,
                                                name: attrName,
                                                rearrangeColumn: true
                                            };
            
                                            switch(curCol.type) {
                                                case "BOOLEAN":
                                                    col.type = taskUtils.COLUMN_TYPES.BOOLEAN;
                                                    break;
                                                case "TIMESTAMP":
                                                    col.type = taskUtils.COLUMN_TYPES.TIMESTAMP;
                                                    col.options = {dateOptions: {selector: "date", formatLength: "medium"}};
                                                    break;
                                                case "NUMBER":
                                                case "DECIMAL":
                                                    var isDecimal = processes.some(function(item){
                                                        return item[curCol.name] && item[curCol.name] % 1 !== 0;
                                                    });
                                                    col.type = isDecimal ? taskUtils.COLUMN_TYPES.DECIMAL : taskUtils.COLUMN_TYPES.NUMBER;
                                                    break;
                                                case "STRING":
                                                default:
                                                    if(column.isBusinessData) {
                                                        col.renderAs = "C";
                                                    }
                                                    col.type = taskUtils.COLUMN_TYPES.STRING;
                                            }
                                        }

                                        view._instance.currentCols.push(col);
                                        break;
                                    }
                                }
                            }

                            // Add width for persistance
                            for(var ndx = 0; ndx < columnWidths.length; ndx++){
                                if(columnWidths[ndx].name === curCol.name){
                                    col.width = columnWidths[ndx].value;
                                    columnWidths.splice(ndx, 1);
                                    break;
                                }
                            }
                        });

                         //add actions picker
                         if(showActionMenu){
                            view._instance.currentCols.push({
                                visibility: true,
                                sortable: false,
                                renderAs: "C",
                                label: " ",
                                dataElementName: "actionMenu",
                                rearrangeColumn: false
                            });
                         }

                        if(columnWidths && columnWidths.length){
                            view._instance.currentCols[view._instance.currentCols.length - 1].width = columnWidths[0].value;
                        }
                        if (view._instance.currentSort == null){
                            view._instance.casesTable.setColumns(view._instance.currentCols);
                        }

                        if (processes) {
                            view._instance.instances = { attributes: data.attributeInfo, items: data.items };
                            if (wpResources.isFederated){
                                var sort = view.context.options.caseSort.get("value");
                                if (sort && sort.name !== "" && sort.value !== ""){
                                    var srcAttrName, srcAttb, fromSS;
                                    ((view._instance.instances && view._instance.instances.attributes) || []).forEach(function (attribute) {
                                        srcAttrName = attribute.name;
                                        srcAttb = (attribute.sourceAttribute && attribute.sourceAttribute.indexOf(".")==0) ? attribute.sourceAttribute.substring(1) : attribute.sourceAttribute;
                                        // srcAttb is from saved search
                                        if (srcAttrName === sort.name || srcAttb === sort.name) {
                                            view._instance.field = srcAttrName;
                                            fromSS = srcAttb === sort.name ? true : false;
                                        }
                                    });
                                    view._instance.currentSort = sort.value === "ascending" ? true : sort.value === "descending" ? false : null;
                                }
                            }

	                        var stats = {};
	                        if (!status || status === view._instance.processesResource.INTERACTION.ALL) {
	                            stats = data.stats || data.overview || overview;
	                        } else {
	                            var total = data.overview ? data.overview.Total : data.stats && data.stats.total;
	                            stats["Total"] = total;
	                            stats[status] = total;
	                        }

                            var items = processes;
                            if (wpResources.isFederated){
                                items = view._proto._filterBusinessData(data);
                            }
                            items = view._proto._processesFilter(view, items);
                        	for (var i = 0; i < items.length; i++) {
                				items[i].type = view._proto._getType(view, items[i]);

                			}
                            var defaultCol = taskUtils.DEFAULT_FEDERATED_INSTANCE_CASE_COLUMNS;
                            var nonDefaultCol = [];
                            var columns = view._instance.selectedCols;
                            for(var i=0; i<columns.length; i++){
                                var val1 = columns[i], found = false;
                                for(var j=0; j<defaultCol.length; j++){
                                    var val2 = defaultCol[j];
                                    if(val1.name == val2){
                                        found = true;
                                        break;
                                    }
                                }
                                !found && nonDefaultCol.push(val1);
                            }
                            var isDefaultSearchFilter = (view._instance.filterConditions.length === 1) && (view._instance.filterConditions[0].value === wpResources.processes.INTERACTION.ACTIVE);
                            if (view._instance.currentSort != null && view._instance.field != null){
                                taskUtils.EVENTS.SET_INSTANCE_BADGE.publish({text:bpmext.localization.formatMsg("SearchBar", "filterApplied"),clearSS:false, caseMode:true});
                                // No need to manually sort since federated Rest API supports sorting
                                if (!wpResources.isFederated){
                                    items = view._proto._sortColumns(view, items);
                                    var increment = (view._instance.paginationView.getCurPageNumber()-1) * view._instance.paginationView.getPerPage();
                                    items = items.slice(increment, increment + view._instance.paginationView.getPerPage());
                                }
                                if(fromSS){
                                    view.updateSortIcons(view._instance.casesTable, view._instance.field,  view._instance.currentSort);
                                }
                            }else if(view._instance.currentSort == null && view._instance.field == "PI_DUE" && isDefaultSearchFilter && nonDefaultCol.length == 0){
                                taskUtils.EVENTS.SET_INSTANCE_BADGE.publish({text:"",clearSS: false,caseMode: true});
                            }

                            view._instance.casesTable.setViewData(items, true);
                            view._instance.loadingTable.setVisible(false, true);
                            view._instance.casesTable.setVisible(true, true);
                            view._instance.pageSize = view._instance.paginationView.getPerPage();
                            var changed = view._proto._arrayDeepEqual(view._instance.instancesItems, items);
                            view._instance.instancesItems = items;

                            // Show pagination if number of tasks is more than page size
                            if(totalCount > view._instance.pageSize){
                                view._instance.paginationView.setVisible(true, true);
                            }else{
                                view._instance.paginationView.setVisible(false, true);
                            }

                            view._instance.casesTable.setOption("showFooter", true);
                            view._instance.casesTable.setOption("showTableStats", true);
                            view._instance.casesTable.setOption("showPager", true);
                            view._proto._updatePager(view);
                            if (changed) {
                                view._proto._updateMetaBusinessDataFields(view, {refresh: true});
                            }
                        } else {
                            view._instance.casesTable.setVisible(false, true);
                            view._instance.paginationView.setVisible(false, true);
                            view._instance.noCasesToDisplayView.setVisible(true, true);
                            view._instance.loadingTable.setVisible(false, true);
                        }

                        //set the list of systems if they were returned
                        view._instance.systems = data.federationResult;
                    } else {
                        //show the NoInstances view and hide the others
                        view._instance.casesTable.setVisible(false, true);
                        view._instance.paginationView.setVisible(false, true);
                        view._instance.noCasesToDisplayView.setVisible(true, true);
                        view._instance.loadingTable.setVisible(false, true);
                        bpmext.log.info("CaseList._loadInstances LOG >> No instances to display.", view);
                    }
                }, function (error) {
                    view._proto._errorLoadInstances(view, error);
                });
            },

            _actualLoadInstancesWrapper: function _actualLoadInstancesWrapper(view) {
            	bpmext.log.info("CaseList._actualLoadInstancesWrapper ENTER >>");
            	var queryOption = this._generateInstanceQueryObject(view, view._instance.sort);
                view._proto._actualLoadInstances(view, queryOption);
            },

            _loadInstances: function _loadInstances(view) {
            	bpmext.log.info("CaseList._loadInstances ENTER >>");
            	var delay = 500;
                var t = delay + new Date().getTime();
            	if (view._instance.runCurrentTimer) {
            		if (t < view._instance.runCurrentTimerTime) {
            			return;
            		}
            		clearTimeout(view._instance.runCurrentTimer);
            		view._instance.runCurrentTimer = undefined;
            		view._instance.runCurrentTimerTime = undefined;
            	}
            	view._instance.runCurrentTimerTime = t;
            	view._instance.runCurrentTimer = setTimeout(function() {
            		view._instance.runCurrentTimer = undefined;
            		view._instance.runCurrentTimerTime = undefined;
                    view._instance.casesTable.setVisible(false, true);
                    view._instance.noCasesToDisplayView.setVisible(false, true);
                    view.reloadSkeletonTable();
        			view._proto._actualLoadInstancesWrapper(view);
            	}, delay);
            	bpmext.log.info("CaseList._loadInstances EXIT >>", view);
            },

            _showCaseList: function _showCaseList(view) {
                // setting root history
                taskUtils.EVENTS.OPEN_INSTANCE_LIST.publish();
                view.setVisible(true, true);
                view.refreshCaseList();
            },

            _processesFilter: function(view, items) {
                if (!view._instance.errorInstances) {
                    return items;
                }

                return items.filter(function (process) {
                    var processKey = (process.systemID || "") + "_" + (process.piid || "");
                    return !view._instance.errorInstances[processKey];
                });
            },

            _filterBusinessData: function(data) {
                var items = data.items, attributeInfo = data.attributeInfo, businessDataField = [];
                attributeInfo.forEach(function(attribute){
                    if (attribute.content.indexOf("bd.") == 0){
                        businessDataField.push(attribute.name);
                    }
                });
                items.forEach(function(item){
                    item.businessData = {};
                    for (var i = 0; i < businessDataField.length; i ++){
                        if (businessDataField[i] in item){
                            item.businessData[businessDataField[i]] = item[businessDataField[i]];
                        }
                    }
                });

                return items;
            },

            _getExpandedRowData: function _getExpandedRowData(view, instance, rowData) {
                var messages = bpmext.localization.formatMsg;
                var systemData = new Map(), businessData = new Map();
                systemData.set(messages("instanceList", "bpdName"), rowData.processName || rowData.bpdName || rowData.PT_NAME);
                if (rowData.type === view._instance.processesResource.TYPE.CASES) {	
                	var stageDisplayName, stageStatus = rowData.CI_STAGE_STATUS, caseTypeName = rowData.PT_PTID, summaryProps;
                	if(stageStatus) {
                		stageDisplayName = view._instance.allCaseStages[stageStatus];
                		if(stageDisplayName) {
                			systemData.set(messages("searchFilter", "stage"), stageDisplayName);
                		}
                	}
                	systemData.set(messages("searchFilter", "modifiedBy"), rowData.CI_LAST_MODIFIER);
                	if(rowData.PI_LAST_MODIFICATION){
                		systemData.set(messages("searchFilter", "lastModificationTime"), taskUtils.formatDate(rowData.PI_LAST_MODIFICATION, true));
                	}
                	if(rowData.CI_HEALTH !== "No Info") {
                		systemData.set(messages("searchFilter", "health"), rowData.CI_HEALTH);
                	}
                	systemData.set(messages("searchFilter", "creationDate"), taskUtils.formatDate(rowData.PI_CREATED, true));
                	// show case summary 
                	summaryProps = view._instance.caseSummaryProps[caseTypeName];
                	if (rowData.businessData && summaryProps) {
                		summaryProps.forEach(function(obj) {
                			var symbolicName, displayName, formatValue, propertyType;
                			if(typeof(obj) === "object") {
                				symbolicName = obj.propertySymbolicName;
                				displayName = obj.propertyDisplayName;
                				propertyType = obj.propertyType;
                			} else {
                				symbolicName = obj;
                				displayName = obj.substring(obj.indexOf("_") + 1);
                			}
                			formatValue = rowData.businessData[symbolicName];
                			if(formatValue) {
                				if(propertyType === "datetime") {
                					formatValue = taskUtils.formatDate(formatValue, true);
                				} 
                				businessData.set(displayName, formatValue);
                			}
                        });
                	}
                } else {
                    if (rowData.completionDate || rowData.executionState == "Completed" || rowData.PI_STATUS == "Completed") {
                        var completedDate = rowData.completedDate || rowData.lastModificationTime || rowData.PI_COMPLETED;
                        systemData.set(messages("CaseList", "completedOn"), taskUtils.formatDate(completedDate, true));
                    }
                    if (rowData.dueDate || rowData.PI_DUE) {
                        systemData.set(messages("instanceUI", "dueDate"), taskUtils.formatDate(rowData.dueDate || rowData.PI_DUE, true));
                    }
                    systemData.set(messages("searchFilter", "lastModificationTime"), taskUtils.formatDate(rowData.lastModificationTime || rowData.PI_LAST_MODIFICATION, true));
                    systemData.set(messages("searchFilter", "creationDate"), taskUtils.formatDate(rowData.creationDate || rowData.PI_CREATED, true));

                    if (instance.businessData) {
                    	for (var label in instance.businessData) {
                    		if (label === "Workstream_Description") {
                                continue;
                            }
                            var value = instance.businessData[label], formatValue, businessObject;
                            
                            // get the type and display
                            view._instance.businessData.forEach(function(obj) {
                                if (obj.name === label) {
                                    businessObject = obj;
                                    return;
                                }
                            });
                            if(businessObject && value) {
                                formatValue = value;
                                if (businessObject.type === "Date") {
                                    formatValue = taskUtils.formatDate(value, true);
                                }
                                businessData.set(businessObject.display, formatValue);
                            } else {
                                if (view._proto._isIsoDate(value)) {
                                    businessData.set(label, taskUtils.formatDate(value, true));
                                } else {
                                    businessData.set(label, value);
                                }
                            }
                        }
                    }
                }

                return {
                    systemData: systemData,
                    businessData: businessData,
                    taskOrInstance: instance,
                    rowData: rowData || instance
                };
            },

            /**
             * @param {string} str
             * @return {boolean}
             */
            _isIsoDate: function _isIsoDate(str) {
                if (!str) {
                    return false;
                }
                return /\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}.\d{3}Z/.test(str);
            },

            _setCaseInfo: function _setCaseInfo(view, caseTypes) {
            	bpmext.log.info("CaseList._setCaseInfo ENTER >>", view);
            	var caseInfo = resourceUtils.processCaseTypeInfo(caseTypes);
            	view._instance.allCaseTypes = caseInfo.allCaseTypes;
            	view._instance.allCaseStages = caseInfo.allCaseStages;
            	view._instance.caseSummaryProps = caseInfo.caseSummaryProps;
            },

            _convertToJSON: function _convertToJSON(date){
                if(typeof date == "string"){
                    return date;
                }else{
                    return date.toJSON ? date.toJSON() : date;
                }
            },

            _getStartDate: function _getStartDate(dateString){
                if(dateString){
                    var currentValue = dateString;
                    var startDate = new Date(new Date(currentValue).getTime()-1);
                    return JSON.stringify(new Date(startDate.toUTCString())).replace(/"/g, "");
                }
            },

            _getEndDate: function _getEndDate(dateString){
                if(dateString){
                    var day = 86400000; //24*60*60*1000
                    var currentValue = dateString;
                    var endDate = new Date(new Date(currentValue).getTime()+day);// from local time 00:00 to 23:59
                    return JSON.stringify(new Date(endDate.toUTCString())).replace(/"/g, "");
                }
            },

            _updateMetaBusinessDataFields: function _updateMetaBusinessDataFields(view, options) {
                options = options || {};
                wpResources.searches.getMetaBusinessDataFields(options.refresh).then(
                    function (businessData) {
                        var columnsToDisplay = [];
                        columnsToDisplay = (businessData || [])
                            .map(function(column) {
                                column.display = taskUtils.getLabelFromID(column.name);
                                return column;
                            });
                        view._instance.businessData = columnsToDisplay;
                    }, function (error) {
                        view._proto._errorLoadInstances(view, error);
                    }
                );
            },

            /**
             * @param {any[]} arr1
             * @param {any[]} arr2
             * @return {boolean}
             * 
             * This function doesn't work with circular arrays
             */
            _arrayDeepEqual: function _arrayDeepEqual(arr1, arr2) {
                return JSON.stringify(arr1) === JSON.stringify(arr2);
            },


            _sortColumns: function _sortColumns(view, processes) {
                if(view._instance.currentSort != null && processes.length > 0){
                    var field = view._instance.field, asc = view._instance.currentSort;
                    if (asc){
                        if(isNaN(processes[0][field])){
                            processes.sort(function(a, b){
                                if (a[field] == null){
                                    return -1;
                                }else if (b[field] == null){
                                    return 1;
                                }
                                return a[field].localeCompare(b[field]);
                            });
                        }else{
                            processes.sort(function(a, b){return a[field]-b[field];});
                        }
                    }else{
                        if(isNaN(processes[0][field])){
                            processes.sort(function(a,b){
                                if (a[field] == null){
                                    return -1;
                                }else if (b[field] == null){
                                    return 1;
                                }
                                return a[field].localeCompare(b[field]);
                            });
                            processes.reverse();
                        }else{
                            processes.sort(function(a, b){return b[field]-a[field];});
                        }
                    }

                    return processes;
                }
            },
            
            /************ ACTION MENU CELL ************/
            _setActionMenu: function _setActionMenu(view, data) {
                var iconWrapper = domConstruct.create("div", {"class": "Icon"});
                var btnWrapper = domConstruct.create("div", {
                    "class": "OverflowIconBtn SPARKIcon btn",
                    "role": "button",
                    "tabindex": "0",
                    "aria-label": bpmext.localization.formatMsg("controlTaskList", "overFlowMenu"),
                    "aria-haspopup": "true",
                    "parentViewName": view.ui.getAbsoluteName(),
                    "taskId": data["TASK.TKIID"] || data["tkiid"] || "",
                    "processId": data["PROCESS_INSTANCE.PIID"] || data["piid"] || "",
                    "systemID": data["systemID"] || "",
                    "templateId": data["PT_PTID"] || "",
                    "caseInstanceName": data["PI_NAME"] || "",
                    "isWorkstream": data["IS_WORKSTREAM"] || data["isWorkstream"] || "",
                    "type": data["type"] || ""
                }, iconWrapper);

                var btnLabel = domConstruct.create("span", {
                    "class": "btn-label icon ci"
                }, btnWrapper);

                var icon = utilities.getCarbonIcon("ci-overflow-menu-vertical");
                domConstruct.place(icon, btnLabel);

                btnWrapper.addEventListener("click", function(){
                    view._proto._openOverflowMenuHandler(view, this);
                }, true);

                btnWrapper.addEventListener("keydown", function(event){
                    // if input key is space or enter key
                    if (event.key === "Enter" || event.key === " " || event.key === "Spacebar") {
                        view._proto._openOverflowMenuHandler(view, this);
                    }
                }, true);

                return iconWrapper;
            },

            _openOverflowMenuHandler: function(view, ele){
                var actionIcon = ele,
                    actionsMenu = view._instance.actionsMenu;

                // remove active class
                domClass.remove(actionIcon, "active");

                var processId = actionIcon.getAttribute("processId"),
                    systemID = actionIcon.getAttribute("systemID"),
                    templateId = actionIcon.getAttribute("templateId"),
                    caseInstanceName = actionIcon.getAttribute("caseInstanceName"),
                    isWorkstream = actionIcon.getAttribute("isWorkstream"),
                	isCaseInstance = actionIcon.getAttribute("type") === "Case";
                // Load actions menu
                actionsMenu.loadMenu(processId, null, systemID, isWorkstream, null, ele, isCaseInstance, templateId, caseInstanceName);

                // Add active class
                domClass.add(actionIcon, "active");
            },

            _setButtonTooltip: function _setButtonTooltip(view){
            	//set tooltip for search button
           	 	var searchButtonCtl = view._instance.searchBar._instance.searchIcon.context.element.querySelector('.SPARKIcon[role="button"]');
	         	searchButtonCtl.onmouseenter = function() {
	         		view._instance.searchTP = bpmext.ui.util.showTooltip(
            	 		searchButtonCtl,
            	 		bpmext.localization.formatMsg("caseList", "searchBarTooltip"),
            	 		{horizontalPos: "LEFT", plainText: false, smartPositioning: true, alwaysShow: true}
	                 );
	         	};
	         	searchButtonCtl.onmouseleave = function() {
        	 		bpmext.ui.util.closeTooltip(view._instance.searchTP, searchButtonCtl);
        	 	};
            	// set tooltip for filter button
            	var filterButtonCtl = view._instance.filtersButton.context.element.querySelector('.SPARKIcon[role="button"]');
            	filterButtonCtl.onmouseenter = function () {
                    if (!view._instance.filterTP) {
                        view._instance.filterTP = bpmext.ui.util.showTooltip(
                            filterButtonCtl,
                            bpmext.localization.formatMsg("controlTaskList", "filterTooltip"),
                            {horizontalPos: "LEFT", plainText: false, smartPositioning: true, alwaysShow: true}
                        );
                    }
            	};
            	filterButtonCtl.onmouseleave = function() {
                    if (view._instance.filterTP) {
                        bpmext.ui.util.closeTooltip(view._instance.filterTP, filterButtonCtl);
                        view._instance.filterTP = null;
                    }
                };

                filterButtonCtl.onfocus = function () {
                    if (!view._instance.filterTP) {
                        view._instance.filterTP = bpmext.ui.util.showTooltip(
                            filterButtonCtl,
                            bpmext.localization.formatMsg("controlTaskList", "filterTooltip"),
                            {horizontalPos: "LEFT", plainText: false, smartPositioning: true, alwaysShow: true}
                        );
                    }
            	};
            	filterButtonCtl.onblur = function() {
                    if (view._instance.filterTP) {
                        bpmext.ui.util.closeTooltip(view._instance.filterTP, filterButtonCtl);
                        view._instance.filterTP = null;
                    }
                };

            	// set tooltip for refresh button
                var refreshButtonCtl = view._instance.refreshButton.context.element.querySelector('.SPARKIcon[role="button"]');
                var currentTime, secondsSinceRefresh, minutesSinceRefresh, lastRefreshedText;

                refreshButtonCtl.onmouseenter = function (){
                        currentTime = new Date();
                        secondsSinceRefresh = Math.floor((currentTime - view._instance.lastRefreshed)/1000);
                        if (secondsSinceRefresh > 60){
                            minutesSinceRefresh = Math.floor(secondsSinceRefresh/60);
                            if(minutesSinceRefresh > 30){
                                lastRefreshedText = bpmext.localization.formatMsg("controlTaskList", "maxRefreshButtonTooltip");
                            }
                            else{
                                lastRefreshedText = bpmext.localization.formatMsg("controlTaskList", "minuteRefreshButtonTooltip", minutesSinceRefresh);
                            }
                        }
                        else{
                            lastRefreshedText = bpmext.localization.formatMsg("controlTaskList", "secondRefreshButtonTooltip", secondsSinceRefresh);
                        }
    
                        view._instance.lastRefreshedTP = bpmext.ui.util.showTooltip(
                            refreshButtonCtl,
                            lastRefreshedText,
                            {horizontalPos: "LEFT", plainText: false, smartPositioning: true, alwaysShow: true}
                        );
                };

                refreshButtonCtl.onmouseleave = function() {
                    bpmext.ui.util.closeTooltip(view._instance.lastRefreshedTP, refreshButtonCtl);
                };

                // set tooltip for start workflow button if overflow
                var startButtonCtl = view._instance.startCaseBtn.context.element.querySelector('[role="button"]');
                var startInitialWidth = startButtonCtl.offsetWidth;
                var startButtonTooltip = false;
                startButtonCtl.onmouseenter = function () {
                    if (startInitialWidth > startButtonCtl.offsetWidth || startButtonCtl.offsetWidth < "170") {
                        startButtonTooltip = true;
                        view._instance.startTP = bpmext.ui.util.showTooltip(
                            startButtonCtl,
                            bpmext.localization.formatMsg("workplace", "addCase"),
                            {horizontalPos: "LEFT", plainText: false, smartPositioning: true, alwaysShow: true}
                        );
                    };
                };
                startButtonCtl.onmouseleave = function() {
                    if (startButtonTooltip) {
                        startButtonTooltip = false;
                        bpmext.ui.util.closeTooltip(view._instance.startTP, startButtonCtl);
                    };
                };
            },

            _getCurrentUserInfo: function _getCurrentUserInfo (view) {
                // refresh user's information
                return wpResources.user.get().then(function(currentUser) {
                    view._instance.userPrefs = currentUser.userPreferences;
                });
            },
        };

        /*
        Public control methods *************************************************************
         */

        /**
		 * @instance
		 * @memberof CaseList
		 * @method initCaseList
         * @param {View} view The view to initialize
		 * @desc Initializes the instance list.
         */
        this.constructor.prototype.initCaseList =  function initCaseList(){};


        /**
		 * @instance
		 * @memberof CaseList
		 * @method launchInstance
         * @param {Row} row The table row that contains the instance record.
		 * @desc Opens the instance details for the given row.
         */
        this.constructor.prototype.launchInstance = function launchInstance(row) {
	        this._proto._launchInstance(this, row);
        };

        /**
		 * @instance
		 * @memberof CaseList
		 * @method callLaunchInstanceEvent
         * @param {Data} data The instance data
		 * @desc Calls the 'On instance launched' event
         */
        this.constructor.prototype.callLaunchInstanceEvent = function callLaunchInstanceEvent(data) {
	        bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONINSTANCE_LAUNCHED, data);
        };

        /**
		 * @instance
		 * @memberof CaseList
		 * @method reload
		 * @desc Reloads the case list.
         */
        this.constructor.prototype.reload = function reload() {
            bpmext.log.info("CaseList.reload ENTER >>", this);
            this.isVisible() && this._proto._loadInstances(this);
            bpmext.log.info("CaseList.reload EXIT >>", this);
        };

        /**
		 * @instance
		 * @memberof CaseList
		 * @method openFilter
		 * @desc The event handler for the slideout toggle.
         */
        this.constructor.prototype.openFilter = function openFilter() {
            bpmext.log.info("CaseList.openFilter ENTER >>", this);
            taskUtils.EVENTS.OPEN_SEARCH_FILTER.publish("Case"); 
            bpmext.log.info("TaskList.openFilter EXIT >>", this);
        };

        /**
		 * @instance
		 * @memberof CaseList
		 * @method createStatusCell
         * @param {View} theView The current view
         * @param {Cell} cell The table cell where the status information will be displayed.
         * @return {div} The div with the formatted status information
		 * @desc Creates the status cell with the appropriate highlighting based on the current instance status.
         */
        this.constructor.prototype.createStatusCell = function createStatusCell(theView, cell) {
            if (!cell) {
                return;
            }

            var field = (cell || {}).varName;
            if (field === "skeleton" || field === "skeletonActionMenu"){
                var span = document.createElement("span");
                span.classList.add("skeleton"); 
                if (field === "skeleton" ){
                    return span;
                } else if (field === "skeletonActionMenu"){
                    var skeletonAMDiv = this._proto._setActionMenu(this, data);
                    domConstruct.place(skeletonAMDiv, span);
                    return span;
                }
            }

            var view = this, data;
            var div = domConstruct.create("div");
            if (this._instance.selectedCols[cell.colIndex] !== undefined) {
            	if (this._instance.selectedCols[cell.colIndex].name === "riskState" || this._instance.selectedCols[cell.colIndex].name === "instanceStatus") {
                    //create  status cell
                    var instanceId;
                    if (cell && cell.row && cell.row.data) {
                        data = cell.row.data;
                    }
                    if (data) {
                        var instanceStatusIconSpan = domConstruct.toDom("<span class='statusIcon'></span>");
                        domConstruct.place(instanceStatusIconSpan, div);

                        var statusImageURL = taskUtils.getInstanceDueStatusImageURL(data, true);
                        if (statusImageURL) {
                            var imageSpan = domConstruct.toDom("<img src='" + statusImageURL +"' alt='" + bpmext.localization.formatMsg("instanceList", "InstanceStatus") +"'></img>");
                            domConstruct.place(imageSpan, instanceStatusIconSpan);
                        }

                        var labelSpan = domConstruct.toDom("<span class='InstanceStatusLabel'></span>");
                        labelSpan.innerText = taskUtils.getDueStatusLabel(data);
                        domConstruct.place(labelSpan, div);
                        instanceId = data.PI_PIID || data.piid ;
                    }
                    div.setAttribute("id", "instance_" + instanceId);
                } else if (this._instance.selectedCols[cell.colIndex].name === "name" || this._instance.selectedCols[cell.colIndex].name === "instanceName") {
                    if (cell && cell.row && cell.row.data) {
                        cell.setSortValue(cell.getFormattedValue().toLowerCase());
                        data = cell.row.data;

                        data.isWorkstream = data.isWorkstream || taskUtils.isWorkstreamProcess(data);
                        data.isWorkstream = (data.isWorkstream || data.bpdName === "Configurable Workstream" || data.processName === "Configurable Workstream" || data.PT_NAME === "Configurable Workstream") ? true : data.isWorkstream;

                        var instanceName;
                        if(this.context.options.enableCaseDetails.get("value")){
                            instanceName = domConstruct.create("a", {
                                "href": "javascript:void(0)",
                                "target": "_self",
                                "aria-label": data.name || data.PI_NAME + " " + bpmext.localization.formatMsg("instanceList", "workflow")
                            }, div);
                            instanceName.addEventListener("click", function () {
                                view.launchInstance(data);
                            });
                        }else{
                            instanceName = domConstruct.create("span", {
                                "aria-label": data.name || data.PI_NAME + " " + bpmext.localization.formatMsg("instanceList", "workflow")
                            }, div);
                        }
                        instanceName.innerText = data.name || data.PI_NAME || data.bpdName;
                    }
                }else{
                    if (cell && cell.row && cell.row.data) {
                        data = cell.row.data;
                        div.innerText = data[field] || "";
                    }
                }
            }else if (field === "actionMenu") {
                if (cell && cell.row && cell.row.data) {
                    data = cell.row.data;
                    data.isWorkstream = data.isWorkstream || taskUtils.isWorkstreamProcess(data);
                    data.isWorkstream = (data.isWorkstream || data.bpdName === "Configurable Workstream" || data.processName === "Configurable Workstream") ? true : data.isWorkstream;
                    cell.parentNode.setAttribute("aria-label", bpmext.localization.formatMsg("controlTaskList", "overFlowMenu"));

                    var actionMenuBtn = this._proto._setActionMenu(this, data);
                    domConstruct.place(actionMenuBtn, div);
                }
            }
            return div;
        };

        /**
		 * @instance
		 * @memberof CaseList
		 * @method setSearchTerm
         * @param {string} searchTerm The search term to filter the task list.
         * @return {boolean} True if the search term has changed, false otherwise
		 * @desc Sets the search term. If a search term is provided, it overrides any previously specified search conditions.
         */
        this.constructor.prototype.setSearchTerm = function setSearchTerm(searchTerm) {
            var hasChanged = this._instance.searchTerm !== searchTerm;
            this._instance.searchTerm = searchTerm;
            return hasChanged;
        };
        /**
		 * @instance
		 * @memberof CaseList
		 * @method setFilterConditions
         * @param {NameValuePair[]} conditions The list of filter conditions.
         * @return {boolean} True if the filter conditions have changed, false otherwise
		 * @desc Sets the list of conditions to filter the instance list. If a search term is provided, it overrides any previously specified search conditions.
         */
        this.constructor.prototype.setFilterConditions = function setFilterConditions(conditions, rawConditions) {
            var hasChanged = false;
            if (this._instance.filterConditions !== null) {
                hasChanged = (JSON.stringify(this._instance.filterConditions) !== JSON.stringify(conditions));
            }
            this._instance.filterConditions = conditions;

            //Update config option
            this.setOption("searchFilters", rawConditions);

            return hasChanged;
        };

        /**
		 * @instance
		 * @memberof CaseList
		 * @method setQuickFilterConditions
         * @param {NameValuePair[]} conditions The list of filter conditions.
         * @return {boolean} True if the filter conditions have changed, false otherwise
		 * @desc Sets the list of conditions to filter the task list. If a search term is provided, it overrides the previously specified search conditions.
         */
        this.constructor.prototype.setQuickFilterConditions = function setQuickFilterConditions(conditions) {
            var hasChanged = false;
            if (this._instance.quickFilterConditions !== null) {
                hasChanged = (JSON.stringify(this._instance.quickFilterConditions) !== JSON.stringify(conditions));
            }
            this._instance.quickFilterConditions = conditions;

            return hasChanged;
        };

        /**
		 * @instance
		 * @memberof CaseList
		 * @method displayExpandedTaskRow
         * @return {boolean} True if the filter conditions have changed, false otherwise
		 * @desc Sets the list of conditions to filter the instance list. If a search term is provided, it overrides any previously specified search conditions.
         */
        this.constructor.prototype.displayExpandedTaskRow = function displayExpandedTaskRow(table, row) {
            var view = this, td = row.td, rowData = row.data, buttonView = row.views[0], rowContainer, openButton, data, piid = rowData.PI_PIID || rowData.piid;
            rowContainer = td.children[0];

            openButton = buttonView.context.element.querySelector("button");
            buttonView.setVisible(true);
            openButton.onclick = function openInstanceUI() {
                view._proto._launchInstance(view, rowData);
            };
            if (rowData.businessData) {
            	data = view._proto._getExpandedRowData(view, rowData, rowData);
                taskUtils.createExpandableRow(view, utilities, rowContainer, data);
            } else {
            	// send another request to fetch business data
            	var fetchError = function (error) {
                    !!error && !!error.errorMessage && taskUtils.publishError(error.errorMessage);
                    bpmext.log.error("ERROR >> There was an error fetching business data: " + error);
                };

            	view._instance.processResource.getBusinessData({piids: [piid]}).then(function(bdRes) {
            		var bdArrays, businessData = {}, processBusinessData = bdRes.processBusinessData || (bdRes.data && bdRes.data.processBusinessData);
            		if(processBusinessData && processBusinessData.length > 0) {
            			if(processBusinessData[0].piid === piid) {
            				bdArrays = processBusinessData[0].businessData;
                			for (var i = 0; i < bdArrays.length; i++) {
                				businessData[bdArrays[i].alias] = bdArrays[i].value;
                			}
                			row.data.businessData = businessData;
                			data = view._proto._getExpandedRowData(view, rowData, rowData);
                            taskUtils.createExpandableRow(view, utilities, rowContainer, data);
            			}
            		} else {
                        data = view._proto._getExpandedRowData(view, rowData, rowData);
                        taskUtils.createExpandableRow(view, utilities, rowContainer, data);
                    }
            	}, fetchError);
            }
        };

        /**
		 * @instance
		 * @memberof CaseList
		 * @method paginationHandler
		 * @desc Handler for when the pagination view's value changes
         */
        this.constructor.prototype.paginationHandler = function paginationHandler() {
            if(this.isVisible() && this._instance.paginationView){
                this.refreshCaseList();
            }
        };

        this.constructor.prototype.reloadSkeletonTable = function reloadSkeletonTable() {
            this._instance.loadingTable.setVisible(false, true);
            var perPage = this._instance.paginationView.getPerPage();
            var skeletonData = taskUtils.createSkeletonTableData(perPage ? perPage : taskUtils.DEFAULT_PER_PAGE);
            var skeletonColumn = taskUtils.createSkeletonTableColumns(4);
            this._instance.loadingTable.setColumns(skeletonColumn);
            this._instance.loadingTable.setViewData(skeletonData, true);
            this._instance.loadingTable.setVisible(true, true);
        };

        /**
		 * @instance
		 * @memberof CaseList
		 * @method onResizeColumn
		 * @desc Sets the column widths to the columnWidths binding
         */
        this.constructor.prototype.onResizeColumn = function onResizeColumn(view, cspecs) {
            var newColumnWidths = [];
            var i;
            for(i = 0; i< cspecs.length; i++){
                newColumnWidths[cspecs[i].columnOrder] = {
                    name: cspecs[i].name || cspecs[i].dataElementName,
                    value: cspecs[i].width ? cspecs[i].width : null
                };
            }
            this.setOption("columnWidths", newColumnWidths);
        };

        /**
		 * @instance
		 * @memberof CaseList
		 * @method onActionMenuClosed
         * @param {View} actionsMenuView The actions menu view
         * @param {Element} actionsMenuTargetElement The action menu button that was clicked to invoke the menu.
		 * @desc Called when the actions menu is closed.
         */
        this.constructor.prototype.onActionMenuClosed = function onActionMenuClosed(actionsMenuView, actionsMenuTargetElement) {
            // close action menu from task table
            if (!!actionsMenuTargetElement && !!actionsMenuTargetElement.firstElementChild) {
                var classes = actionsMenuTargetElement.firstElementChild.getAttribute("class");
                actionsMenuTargetElement.firstElementChild.setAttribute("class", classes.replace(" active", "").trim());
            }

            // close action menu that open from task cards
            if (actionsMenuTargetElement && actionsMenuTargetElement.classList && actionsMenuTargetElement.classList.contains("active")) {
                actionsMenuTargetElement.classList.remove("active");
            }
            if(actionsMenuTargetElement){
                actionsMenuTargetElement.focus();
            }

        };

        /**
		 * @instance
		 * @memberof CaseList
		 * @method onColumnSorting
		 * @desc Triggered on column sorting
		 */
        this.constructor.prototype.onColumnSorting = function onColumnSorting(target, field, order) {
            this._instance.currentSort = order === "ascending" ? true : order === "descending" ? false : null;

			if (!wpResources.isFederated){
                if (this._instance.instancesItems && this._instance.instancesItems.length > 0 && this._instance.instancesItems[0].hasOwnProperty(field)) {
                    this._instance.field = field;
                    this.reload();
                    this._instance.lastRefreshed = new Date();
                    return false;
                }
            }
            
            // Matching attribute name
            var srcAttrName, attributeName, srcAttb, fromSS, selSrcAttb;
            var sort = this._instance.currentSort;
            ((this._instance.instances && this._instance.instances.attributes) || []).forEach(function (attribute) {
                srcAttrName = attribute.name;
                srcAttb = (attribute.sourceAttribute && attribute.sourceAttribute.indexOf(".")==0) ? attribute.sourceAttribute.substring(1) : attribute.sourceAttribute;
                // srcAttb is from saved search
                if (srcAttrName === field || srcAttb === field) {
                    attributeName = srcAttrName;
                    fromSS = srcAttb === field ? true : false;
                    selSrcAttb = srcAttb;
                    if(!fromSS){
                        // Set back to default sort when order is none
                        if (order === "none"){
                            selSrcAttb = "instanceCreationDate";
                            sort = true;
                        }
                        taskUtils.EVENTS.CHANGE_CASE_SORT_FILTER.publish({field: selSrcAttb, order: sort ? "ASC" : sort === false ? "DESC" : null});
                    }
                }
            });
            if (selSrcAttb){
                this._instance.sort = {field: selSrcAttb, order: sort ? "ASC" : sort === false ? "DESC" : null};
                this.context.options.caseSort.set("value", {name: selSrcAttb, value: order});
            }

            // Sorting on original field
            if (attributeName) {
                this._instance.field = fromSS ? field : attributeName;
                this.refreshCaseList();

                // Manually update sort icons when sorting from saved search
                if (fromSS) {
                    this.updateSortIcons(this._instance.casesTable, attributeName, this._instance.currentSort);
                }
                return false;
            }
        };

         /**
		 * @instance
		 * @memberof CaseList
		 * @method updateSortIcons
		 * @desc Update sort icons displayed on table headers
         */
          this.constructor.prototype.updateSortIcons = function(view, col, asc) {
            if(view._instance.headerRow != null){
                var children = view._instance.headerRow.childNodes;
                var i;
                if(col != null){
                    for(i = 0; i < children.length; i++){
                        var c = children[i];
                        if(c.tagName != "TH")
                            continue;

                        if(c.__varName != null){
                            var sorterTh = c;
                            var sorterDiv = sorterTh.querySelector(".sorter");
                            var icon = sorterDiv && sorterDiv.querySelector(".ci");

                            if(c.__varName != col) {
                                // Set not selected columns to default sort
                                domClass.remove(sorterTh, "asc desc");
                                domAttr.set(sorterTh, "aria-sort", "none");
                                if (icon) {
                                    utilities.replaceCarbonIcon(icon, "ci-arrows");
                                } else if (sorterDiv) {
                                    sorterDiv.appendChild(utilities.getCarbonIcon("ci-arrows"));
                                }
                            } else {
                                var replacedIconName = "ci-arrows";
                                if (c.__varName === "PRIORITY") {
                                    asc = asc === undefined ? undefined : !asc;
                                }
                                if (asc) {
                                    icon.style.transform = "none";
                                    domClass.remove(sorterTh, "desc");
                                    domClass.add(sorterTh, "asc");
                                    replacedIconName = "ci-arrow-up";
                                } else if (asc === false) {
                                    domClass.remove(sorterTh, "asc");
                                    domClass.add(sorterTh, "desc");
                                    replacedIconName = "ci-arrow-down";
                                } else {
                                    domClass.remove(sorterTh, "asc desc");
                                }

                                if (icon) {
                                    utilities.replaceCarbonIcon(icon, replacedIconName);
                                } else if (sorterDiv) {
                                    domConstruct.place(utilities.getCarbonIcon(replacedIconName), sorterDiv, "first");
                                }
                            }
                        }
                    }
                }
            }
        };

        /**
		 * @instance
		 * @memberof CaseList
		 * @method refreshCaseList
		 * @desc Refresh case list when the refresh button is clicked
         */
        this.constructor.prototype.refreshCaseList = function refreshCaseList() {
            this.reload();
            this._instance.lastRefreshed = new Date();
        };
        
        /**
		 * @instance
		 * @memberof CaseList
		 * @method hideStartBtn
		 * @desc hide the start case button
         */
        this.constructor.prototype.hideStartBtn = function hideStartBtn() {
        	this._instance.startCaseBtn.setVisible(false, true);
        };
        
        /**
		 * @instance
		 * @memberof CaseList
		 * @method setSelectedColumns
         * @param {NameValuePair[]} columns The list of selected columns.
         * @return {boolean} True if the selected columns have changed, false otherwise
		 * @desc Sets the selected columns that the task list displays, and reloads the list.
         */
         this.constructor.prototype.setSelectedColumns = function setSelectedColumns(columns) {
            var hasChanged = (JSON.stringify(this._instance.selectedCols) !== JSON.stringify(columns));
            if(columns && hasChanged === true) {
                this._instance.selectedCols = dojo.clone(columns);
            }
            return hasChanged;
        };


        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function ()
        {
            bpmext.log.info("CaseList.load ENTER >>", this);
            var opts = this.context.options, view = this;
            if (!opts.enableCaseDetails){
                bpmext.ui.substituteConfigOption(this, "enableCaseDetails", false);
            }
            if (!view.context.binding) {
                view.context.binding = bpmext.ui.substituteObject(view, "binding", "cases", {});
            }
            if (!opts.filterByProject) {
                bpmext.ui.substituteConfigOption(view, "filterByProject", "");
            }
            if (!opts.caseScope) {
                bpmext.ui.substituteConfigOption(view, "caseScope", "");
            }
            if (!opts.columns) {
                bpmext.ui.substituteConfigOption(this, "columns", []);
            }
            if (!opts.searchFilters) {
                bpmext.ui.substituteConfigOption(this, "searchFilters", null);
            }
            if (!opts.showRefresh) {
                bpmext.ui.substituteConfigOption(this, "showRefresh", false);
            }
            if(!opts.columnWidths){
                bpmext.ui.substituteConfigOption(this, "columnWidths", null);
            }
            if (!opts.enableAddCase){
                bpmext.ui.substituteConfigOption(this, "enableAddCase", false);
            }

            if (!opts.hideStatusColumn){
                bpmext.ui.substituteConfigOption(this, "hideStatusColumn", false);
            }

            if (!opts.caseSort) {
                bpmext.ui.substituteConfigOption(this, "caseSort", null);
            }

            if (!opts.openInNewWindow) {
                bpmext.ui.substituteConfigOption(this, "openInNewWindow", false);
            }

            if (!opts.hideActionMenu) {
                bpmext.ui.substituteConfigOption(this, "hideActionMenu", false);
            }

            if (!opts.hideSearchBar) {
                bpmext.ui.substituteConfigOption(this, "hideSearchBar", false);
            }

            if (!opts.enableSearchFilter) {
                bpmext.ui.substituteConfigOption(this, "enableSearchFilter", false);
            }

            if (!opts.enableCopyLink){
                bpmext.ui.substituteConfigOption(this, "enableCopyLink", false);
            }

            var savedSort = opts.caseSort.get("value");
            if (savedSort && savedSort.name != ""){
                view._instance.sort = {field: savedSort.name, order: savedSort.value === "ascending" ? "ASC" : savedSort.value === "descending" ? "DESC" : null}; 
            }
            view._instance.caseScope = opts.caseScope.get("value");
			view._instance.filterByProject = opts.filterByProject.get("value");

            view._instance.selectedCols = [];
            if (wpResources.isFederated){
                var defaultCol = taskUtils.DEFAULT_FEDERATED_INSTANCE_CASE_COLUMNS;
                var columns = opts.columns.get("value").length() > 0 ? opts.columns.get("value").toJSObject().items : defaultCol;
                if(opts.columns.get("value").length() === 0) {
                    taskUtils.DEFAULT_FEDERATED_INSTANCE_CASE_COLUMNS.forEach(function(val) {
                        view._instance.selectedCols.push({name: val, value: taskUtils.getLabelFromInstanceProperty(val)});
                    });
                } else {
                    view._instance.selectedCols = columns;
                    var nonDefaultCol = [];
                    for(var i=0; i<columns.length; i++){
                        var val1 = columns[i], found = false;
                        for(var j=0; j<defaultCol.length; j++){
                            var val2 = defaultCol[j];
                            if(val1.name == val2){
                                found = true;
                                break;
                            }
                        }
                        !found && nonDefaultCol.push(val1);
                    }
                    if(nonDefaultCol.length>0){
                        taskUtils.EVENTS.SET_INSTANCE_BADGE.publish({text:bpmext.localization.formatMsg("SearchBar", "filterApplied"),clearSS:false, caseMode: true});
                    }
                }

            }else{
                taskUtils.DEFAULT_INSTANCE_COLUMNS.forEach(function(val) {
                    view._instance.selectedCols.push({name: val, value: taskUtils.getLabelFromInstanceProperty(val)});
                });
            }

            if(opts.searchFilters.get("value") && opts.searchFilters.get("value").length() > 0) {
                this._instance.filterConditions = opts.searchFilters.get("value").items;
                var isDefaultSearchFilter = (this._instance.filterConditions.length === 1) && (this._instance.filterConditions[0].value === wpResources.processes.INTERACTION.ACTIVE);
                if(!isDefaultSearchFilter){
                    taskUtils.EVENTS.SET_INSTANCE_BADGE.publish({text:bpmext.localization.formatMsg("SearchBar", "filterApplied"),clearSS:false, caseMode: true});
                }
            }else{
                this._instance.filterConditions = [{
                    "field": "interaction",
                    "operator":"Equals",
                    "value": wpResources.processes.INTERACTION.ACTIVE
                }];
            }

            // Resize columns
            this._instance.columnWidths = opts.columnWidths.get("value") && opts.columnWidths.get("value").length() > 0 ? opts.columnWidths.get("value").toJSObject().items : null;
            
            //Pagination
            this._instance.paginationView = bpmext.ui.getView("Pagination1", this);
            this._instance.paginationView.setVisible(false, true);

            //Skeleton Loading
            this._instance.loadingTable = bpmext.ui.getContainer("SkeletonLoadingTable", this);
            this.reloadSkeletonTable();
            
            //get child CVs
            this._instance.casesTable = bpmext.ui.getContainer("CasesTable", this);
            this._instance.casesTable.setTitle(bpmext.localization.formatMsg("caseList", "cases"));
            this._instance.noCasesToDisplayView = bpmext.ui.getContainer("NoCasesToDisplayView", this);
            this._instance.noCasesToDisplayView.setVisible(false, true);
            this._instance.labelView = bpmext.ui.getContainer("CaseListHeaderLabelLayout", this);
            this._instance.searchBar = bpmext.ui.getView("Saved_Search_Drop_Down1", this);
            this._instance.filtersButton = bpmext.ui.getView("CaseListFiltersButton", this);
            this._instance.startCaseBtn = bpmext.ui.getView("AddCaseButton", this);
            this._instance.refreshButton = bpmext.ui.getView("ReloadCaseListButton", this);
            this._instance.actionsMenu = bpmext.ui.getView("Actions_Menu", this);
            this._instance.getLink = bpmext.ui.getView("GetLink", this);

            // Refresh button
            if (this.context.options.showRefresh.get("value") === true) {
                this._instance.refreshButton.setVisible(true, true);
                var refreshButtonDom = this._instance.refreshButton.context.element.querySelector(".SPARKIcon.btn");
                refreshButtonDom.setAttribute("aria-label", bpmext.localization.formatMsg("controlTaskList", "refresh"));
            } else{
                this._instance.refreshButton.setVisible(false, true);

                // Show the refresh button if the notification server is down
                taskUtils.EVENTS.SHOW_REFRESH_BUTTON.subscribe(function (){
                    this._instance.refreshButton.setVisible(true, true);
                }, this);
            }
            
            if(!this.context.options.enableAddCase.get("value")){
                this._instance.startCaseBtn.setVisible(false, true);
            }

            if (this._instance.labelView && !this.isLabelVisible()) {
                this._instance.labelView.setVisible(false, true);
            }

            if (this.context.options.hideStatusColumn.get("value") === true) {
                //remove the first item in each list which is the status column
                this._instance.selectedCols.shift();
                taskUtils.DEFAULT_INSTANCE_COLUMNS.shift();
            }

            
            if(this.context.options.hideSearchBar.get("value")){
                 this._instance.searchBar.setVisible(false, true);
             } else {
             	this._proto._setButtonTooltip(this);
             }
            

            if (this.context.options.enableSearchFilter.get("value")) {
                this._instance.filtersButton.setVisible(true, true);
            }else{
                this._instance.filtersButton.setVisible(false, true);
            }
            

            if(!this.context.options.enableCopyLink.get("value")){
                this._instance.actionsMenu.context.options.disableActions.get("value").items.push("ACTION_GET_LINK");
            }

            //add dummy row to empty state table
            this._instance.noCasesToDisplayView.setViewData([{name: 0}], true);
            this._instance.noTasksImage = bpmext.ui.getView("NoTasksImage", this._instance.noCasesToDisplayView);
            var image = this._instance.noTasksImage.context.element.querySelector("img");
            image.tabIndex = -1;
            var headerId = bpmext.ui.getView("NoCasesHeader", this._instance.noCasesToDisplayView).context.element.id;
            image.setAttribute("aria-labelledby", headerId);

            view._instance.casesTable.setPageSizeRange(1, 999);
            view._instance.pageSize =  view._instance.casesTable.getOption("pageSize") || 10;

            view._instance.processesResource = wpResources.processes;
            view._instance.processResource = wpResources.process;

            bpmext.ui.registerEventHandlingFunction(view, view._proto.EVT_ONINSTANCE_LAUNCHED, "instance");
            
            this._proto._getCurrentUserInfo(this);
            view._proto._showCaseList(view);

            this._instance.lastRefreshed = new Date();
            this._proto._setButtonTooltip(this);

            taskUtils.EVENTS.UPDATE_USER_PREFERENCES.subscribe(function(eventName, eventData){
                if (eventData) {
                    var prefs = eventData;
                    for (var key in prefs){
                        this._instance.userPrefs[key] = prefs[key];
                    }
                }
            }, this);

            taskUtils.EVENTS.TASKLIST_TASK_RESOURCE_ASSIGNED.subscribe(taskUtils.throttle(dojo.hitch(this, "reload")), this);
	        taskUtils.EVENTS.TASK_FIELD_CHANGED.subscribe(taskUtils.throttle(dojo.hitch(this, "reload")), this);

            taskUtils.EVENTS.ACTION_PERFORMED.subscribe(this.refreshCaseList, this);
            // reload when return from Team dashboard
            taskUtils.EVENTS.FORCED_REFRESH.subscribe(this.refreshCaseList, this);
            
            taskUtils.EVENTS.MODIFY_CASE_INSTANCE_FILTER.subscribe(function(eventName, eventData){
            	//only reload if the filter has changed
            	if (this.setFilterConditions(eventData.filterCondition, eventData.filterWithoutDateProcess) === true) {
            		this.refreshCaseList();
            	}
            }, this);
            //Listen for the event to set the filter conditions
			taskUtils.EVENTS.MODIFY_CASE_INSTANCE_QUICK_FILTER.subscribe(function(eventName, eventData){
                //only reload if the filter has changed
                if (this.setQuickFilterConditions(eventData.filterCondition)) {
                    this.reload();
                }
			}, this);
            // taskUtils.EVENTS.SET_DEFAULT_INSTANCE_STATS.subscribe(function(eventName){
            //     if (this.setQuickFilterConditions("")) {
            //         this.reload();
            //     }
            // }, this);
            taskUtils.EVENTS.INSTANCE_ERROR.subscribe(function(eventName, eventData) {
                var key = (eventData.systemID || "") + "_" + (eventData.piid || "");
                if (!this._instance.errorInstances) {
                    this._instance.errorInstances = {};
                } else if (!this._instance.errorInstances[key]) {
                    this._instance.errorInstances[key] = eventData;
                }
            }, this);

            taskUtils.EVENTS.CASETYPE_READY.subscribe(function(eventName, eventData) {
            	this._instance.allCaseTypes = eventData;
            }, this);

            taskUtils.EVENTS.MODIFY_CASE_INSTANCE_SEARCH_TERM.subscribe(function(eventName, eventData) {
            	//add a wildcard
            	if (eventData) {
            		eventData = eventData + "*";
            	}
            	if(this.setSearchTerm(eventData)){
            		this.refreshCaseList();
            	}
            }, this);

             taskUtils.EVENTS.CLEAR_INSTANCE_FIELDS.subscribe(function(eventName, eventData) {
            	 if(!eventData) return;
                 var filterConditions = [{
                     "field": "interaction",
                     "operator":"Equals",
                     "value": wpResources.processes.INTERACTION.ACTIVE
                 }];
                 this._instance.currentSort = null;
                 this._instance.field = "instanceCreationDate";
                 this.context.options.caseSort.set("value", {name: this._instance.field, value: "none"});
                 if (!wpResources.isFederated && this.setFilterConditions(filterConditions, filterConditions) === true) {
                     this.refreshCaseList();
                 }
             }, this);

             taskUtils.EVENTS.MODIFY_CASE_INSTANCE_COLUMNS.subscribe(function(eventName, eventData){
                 //only reload if the columns have changed
                 if (wpResources.isFederated && this.setSelectedColumns(eventData) === true) {
                     this._instance.currentSort = null;
                     this.refreshCaseList();
                 }
             }, this);

            taskUtils.EVENTS.GET_LINK.subscribe(function(eventName, eventData) {
                var data;
                if (this.isVisible() && eventData && eventData.process) {
                    data = {name: "Workplace", type: "instance", data: {piid: eventData.process.piid, systemID: eventData.process.systemID}};
                    this._instance.getLink.copyLink(data);
                }
            }, this);
            
            taskUtils.EVENTS.VIEW_CASE_INSTANCE.subscribe(function(eventName, eventData) {
                var data;
                if (eventData && eventData.caseInstanceId) {
                	data = {type: view._instance.processesResource.TYPE.CASES, piid: eventData.caseInstanceId, templateId:eventData.templateId, name: eventData.caseInstanceName, systemID: eventData.systemId};
                    this._proto._launchCase(this, data);
                }
            }, this);

            taskUtils.EVENTS.SLIDEOUT_PANEL_CLOSE.subscribe(function () {
                setTimeout(function() {
                    var filterButtonCtl = view._instance.filtersButton.context.element.querySelector('.SPARKIcon[role="button"]');
                    filterButtonCtl.blur();
                });
            }, this);
            taskUtils.EVENTS.SORT_CASELIST.subscribe(function(eventName, eventData){
                view.onColumnSorting(null, eventData.field, eventData.order);
            }, this);
            
            if(resourceUtils.exposedResources && resourceUtils.exposedResources.caseTypes) {
            	this._proto._setCaseInfo(view, resourceUtils.exposedResources.caseTypes);
            } else {
            	var fetchError = function (error) {
                    !!error && !!error.errorMessage && taskUtils.publishError(error.errorMessage);
                    bpmext.log.error("ERROR >> There was an error fetching casetypes: " + error);
                    if (error && error.response && error.response.data && error.response.data.status === 500 && error.response.data.errorNumber === "CWMFS4021E") {
                        view._proto._errorLoadInstances(view, error);
                    }
                };
                wpResources.config.get().then(function(config) {
                    var options = {
                        excludeReferencedFromToolkit: !!config.excludeReferencedFromToolkit,
                        subtypes: [
                            wpResources.exposed.SERVICE_SUBTYPE.STARTABLE_SERVICE,
                            wpResources.exposed.SERVICE_SUBTYPE.DASHBOARD
                        ]
                    };

                    wpResources.exposed.get(options).then(
                        function (exposedData) {
                            var data = resourceUtils.buildResources(exposedData, options);
                            view._proto._setCaseInfo(view, data.caseTypes);
                        },
                        fetchError
                    );
                }, fetchError);
            }
            view._proto._updateMetaBusinessDataFields(view);
            this.loadContainer(this);
            bpmext.log.info("CaseList.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try
            {
                utilities.handleVisibility(this.context);
            }
            catch (e)
            {
                //{#feature: US-1330 Added RT localization}
                //bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e, this);
                if(e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    //bpmext.log.error("  Call stack: " + e.stack);
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack), this);
                }
            }
        };

        this.constructor.prototype.change = function (event)
        {
            bpmext.log.info("CaseList.change ENTER >> (event): " + event, this);
            bpmext.log.info("CaseList.change ENTER >>", this);
        };

        this.constructor.prototype.unload = function ()
        {
            bpmext.ui.unloadView(this);
        };
    }
};