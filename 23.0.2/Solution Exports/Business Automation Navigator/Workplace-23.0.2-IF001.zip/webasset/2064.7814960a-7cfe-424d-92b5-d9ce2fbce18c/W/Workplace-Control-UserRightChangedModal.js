/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof UserRightChangedModal
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof UserRightChangedModal
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof UserRightChangedModal
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof UserRightChangedModal
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof UserRightChangedModal
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof UserRightChangedModal
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof UserRightChangedModal
 * @method triggerFormulaUpdates
 */


/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 * </table>
 */
workplace_control_InitUserRightChangedModal = function (utilities, taskUtils)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
        };


        /*
        Public control methods *************************************************************
         */

         /**
		 * @instance
		 * @memberof UserRightChangedModal
		 * @method closeModal
		 * @desc Closes the dialog
		 */
        this.constructor.prototype.closeModal = function() {
			bpmext.log.info("UserRightChangedModal.closeModal ENTER >> ",this);
			this._instance.modalSection.hide();
            this.hide();
			bpmext.log.info("UserRightChangedModal.closeModal EXIT << ");
        };
        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function (){
            bpmext.log.info("UserRightChangedModal.load ENTER >>", this);

            var messages = bpmext.localization.formatMsg;

            this._instance.modalSection = bpmext.ui.getContainer("UserRightChangedModalSection", this);
            this._instance.modalSection.setPrimaryButtonText(messages("workplace", "ok"));
            this._instance.modalSection.setSecondaryButtonText(" ");

            this._instance.panel = bpmext.ui.getContainer("UserRightChangedPanel", this);
            //CV in Panel
            this._instance.changeMessage = bpmext.ui.getView("UserRightChangedMessage", this);

            this._instance.panel.setTitle(messages("savedSearchList", "userSavedSearchRightsChanged"));

			taskUtils.EVENTS.USER_RIGHT_CHANGED.subscribe(function(eventName, eventData){
				this._instance.changeMessage.setLabel(eventData.msg);
                this._instance.modalSection.show();
                this.show();
                taskUtils.setTabCycle(this);
			}, this);

            this.loadContainer(this);

            bpmext.log.info("UserRightChangedModal.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try {
                utilities.handleVisibility(this.context);
            }
            catch (e){
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e, this);
                if(e.stack) {
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack), this);
                }
            }
        };

        this.constructor.prototype.change = function () {

        };

        this.constructor.prototype.unload = function () {
            bpmext.ui.unloadContainer(this);
        };
    }
};