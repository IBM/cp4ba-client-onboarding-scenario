/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof WorkstreamActionsMenu
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof WorkstreamActionsMenu
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof WorkstreamActionsMenu
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof WorkstreamActionsMenu
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof WorkstreamActionsMenu
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof WorkstreamActionsMenu
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof WorkstreamActionsMenu
 * @method triggerFormulaUpdates
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On Show:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when the actions menu is shown</td>
 *               </tr>
 *           </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *               </tr>
 *       </table>
 *     </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On Hide:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when the actions menu is hidden</td>
 *               </tr>
 * </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *               </tr>
 *           </table>
 *       </td>
 *   </tr>
 * </table>
 */

workplace_control_InitWorkstreamActionsMenu = function(utilities, taskUtils, wpResources, domClass, resourceUtils) {
    "use strict";
    this._instance = {};

    if (!this.constructor.prototype._proto) {
        this.constructor.prototype._proto = {
            EVT_ONSHOW: "eventON_SHOW",
            EVT_ONHIDE: "eventON_HIDE",
            WORKSTREAM_ACTIONS: {
                "ACTION_VIEW_INSTANCE": {
                    label: bpmext.localization.formatMsg("actionsMenu", "ACTION_LAUNCH_TASK_NEW_WINDOW"),
                    icon: "ci-launch",
                    command: taskUtils.EVENTS.BEFORE_VIEW_INSTANCE
                },
                "ACTION_VIEW_PROCESS_DIAGRAM": {
                    label: bpmext.localization.formatMsg("actionsMenu", "ACTION_VIEW_PROCESS_DIAGRAM"),
                    icon: "ci-view",
                    command: taskUtils.EVENTS.VIEW_PROCESS_DIAGRAM
                },
            	 "ACTION_FOLLOW_INSTANCE": {
                     label: bpmext.localization.formatMsg("WorkstreamActionsMenu", "FOLLOW"),
                     icon: "ci-star",
                     command: taskUtils.EVENTS.FOLLOW_INSTANCE
                 },
                 "ACTION_UNFOLLOW_INSTANCE": {
                     label: bpmext.localization.formatMsg("WorkstreamActionsMenu", "UNFOLLOW"),
                     icon: "ci-star-filled",
                     command: taskUtils.EVENTS.UNFOLLOW_INSTANCE
                 },
                "ACTION_CHANGE_INSTANCE_DUEDATE": {
                    label: bpmext.localization.formatMsg("WorkstreamActionsMenu", "MODIFY"),
                    icon: "ci-edit",
                    command: taskUtils.EVENTS.MODIFY_INSTANCE
                },
                "ACTION_ABORT_INSTANCE": {
                    label: bpmext.localization.formatMsg("WorkstreamActionsMenu", "TERMINATE"),
                    icon: "ci-stop",
                    command: taskUtils.EVENTS.TERMINATE_INSTANCE_EVENT
                },
                "ACTION_RESUME_INSTANCE": {
                    label: bpmext.localization.formatMsg("WorkstreamActionsMenu", "RESUME"),
                    icon: "ci-play",
                    command: taskUtils.EVENTS.RESUME_INSTANCE_EVENT
                },
                "ACTION_RETRY_INSTANCE": {
                    label: bpmext.localization.formatMsg("WorkstreamActionsMenu", "RETRY"),
                    icon: "ci-redo",
                    command: taskUtils.EVENTS.RETRY_INSTANCE_EVENT
                },
                "ACTION_SUSPEND_INSTANCE": {
                    label: bpmext.localization.formatMsg("WorkstreamActionsMenu", "SUSPEND"),
                    icon: "ci-pause",
                    command: taskUtils.EVENTS.SUSPEND_INSTANCE_EVENT
                }
            },

            ACTIONS_SEQUENCE: ["ACTION_VIEW_INSTANCE", "ACTION_VIEW_PROCESS_DIAGRAM", "SEPARATOR", "ACTION_FOLLOW_INSTANCE", "ACTION_UNFOLLOW_INSTANCE", "ACTION_CHANGE_INSTANCE_DUEDATE", "SEPARATOR", "ACTION_ABORT_INSTANCE", "ACTION_RETRY_INSTANCE", "ACTION_SUSPEND_INSTANCE", "ACTION_RESUME_INSTANCE"],

            _loadMenu: function(view, actions) {
                //Hide popup menu if it is already visible
                view._instance.popupMenu.setMenuVisible(false);

                //Attach popup menu to target element
                view._instance.popupMenu.setTargetElement(view._instance.targetElement);

                view._instance.menuItems = [];

                actions = actions || [];
                view._proto.ACTIONS_SEQUENCE.forEach(function (action) {
                    if(!view._proto._isActionDisabled(view, action)) {
                        if (actions.indexOf(action) !== -1) {
                            var curAction = view._proto.WORKSTREAM_ACTIONS[action];
                            view._instance.menuItems.push({
                                command: curAction.command,
                                itemType: "L",
                                icon: curAction.icon,
                                itemText: curAction.label
                            });
                        } else if (action === "SEPARATOR" && view._instance.menuItems.length > 0) {
                            view._instance.menuItems.push({
                                itemType: "S"
                            });
                        }
                    }
                });

                // Remove view instance action when inside run url
                if (view._instance.hideOpenInNewWindow) {
                    if(taskUtils.EVENTS.BEFORE_VIEW_INSTANCE.equals(view._instance.menuItems[0].command)){
                        view._instance.menuItems.splice(0,1);
                    }

                    if(taskUtils.EVENTS.VIEW_PROCESS_DIAGRAM.equals(view._instance.menuItems[0].command)){
                        view._instance.menuItems.splice(0,1);
                    }
                }

                view._instance.popupMenu.removeAllMenuItems();
                view._instance.popupMenu.setMenuItems(view._instance.menuItems);

                if (view._instance.menuItems.length > 0) {
                    view._instance.handelBtnVisibility && view._instance.menuBtnView.setVisible(true, true);
                    view._instance.showMenuAfterLoad && view.open();
                    bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONSHOW, view._instance.targetElement);
                } else {
                    view._instance.handelBtnVisibility && view._instance.menuBtnView.setVisible(false, true);
                }
            },

            _isActionDisabled: function(view, action) {
                var disabledActions = view.context.options.disableActions.get("value").items;
                var disabled = false;

                if(disabledActions.indexOf(action) !== -1) {
                    disabled = true;
                }

                return disabled;
            },

            _getActions: function (view) {
                var piid = view._instance.piid;
                var systemID = view._instance.systemID;

                wpResources.process.get({piid: piid, systemID: systemID}).then(function (workstream) {
                    var actions = workstream && workstream.actions;
                    var workstreamName = workstream && workstream.name;
                    
                    var curSystemInfo, runURLPrefix = dojoConfig.App._bpmContextRootMap.teamworks, piid = workstream.piid || workstream.PI_PIID, templateID = workstream.templateId || workstream.PT_PTID;
                    if(workstream.systemID) {
                        curSystemInfo = resourceUtils.getFederatedSystemInfo(workstream.systemID);
                        if (curSystemInfo){
                            runURLPrefix = curSystemInfo.taskCompletionUrlPrefix;
                        }
                    }
                    workstream.runURL = runURLPrefix + "/launchInstanceUI?origin=workplace&instanceId=" + piid;

                    if (parent && parent === parent.parent && workstream.runURL == (window.location.pathname + window.location.search)){
                        view._instance.hideOpenInNewWindow = true;
                    }

                    view._instance.workstreamName = view._instance.workstreamName || workstreamName;
                    view._instance.process = workstream;
                    view._proto._loadMenu(view, actions);
                });
            },

            _updateFollowActions: function(view) {
            	var currentActions = view._instance.menuItems, followObj = view._proto.WORKSTREAM_ACTIONS["ACTION_FOLLOW_INSTANCE"], unfollowObj = view._proto.WORKSTREAM_ACTIONS["ACTION_UNFOLLOW_INSTANCE"];
            	currentActions.forEach(function(action){
            		if(action.icon === "ci-star") {
            			action.icon = unfollowObj.icon;
            			action.command = unfollowObj.command;
            			action.itemText = unfollowObj.label;
            		} else if(action.icon === "ci-star-filled") {
            			action.icon = followObj.icon;
            			action.command = followObj.command;
            			action.itemText = followObj.label;
            		}
            	});

            	view._instance.popupMenu.removeAllMenuItems();
                view._instance.popupMenu.setMenuItems(view._instance.menuItems);
            }
        };


        /*
        Public control methods *************************************************************
         */

         /**
          * @instance
          * @memberof WorkstreamActionsMenu
          * @method loadMenu
          * @param {Object} targetElement The DOM element relative to which the action menu should open
          * @param {Object} ident Mandatory, identifier of the workstream
          * @param {String} ident.piid Mandatory, Process id of the workstream
          * @param {String} ident.systemID Optional, This parameter is required when federated
          * @param {String} ident.workstream Optional, Name of the workstream
          * @param {Array} [ident.actions] Optional, A list of action that can be performed by the given workstream
          * @desc Function to load the actions menu
          */
        this.constructor.prototype.loadMenu = function(targetElement, ident, actions) {
            if (ident && ident.piid) {
                this._instance.piid = ident.piid;
                this._instance.systemID = ident.systemID;
                this._instance.workstreamName = ident.workstreamName;

                if (this.isMenuOpen()) {
                    // close the action menu if it is already opened
                    this.close();
                } else if (this._instance.targetElement && (this._instance.targetElement !== targetElement)) {
                    // if the action menu for previous target element is not open remove the pop up effect
                    this.onPopupClosed();
                }

                this._instance.targetElement = targetElement;

                if (!Array.isArray(actions) || !ident.workstreamName) {
                    // Call to get a list of actions only of actions is not passed in or invalid passed in workstream name
                    this._proto._getActions(this);
                } else {
                    this._proto._loadMenu(this, actions);
                }
            }
        };

        /**
         * @instance
         * @memberof WorkstreamActionsMenu
         * @method onActionClick
         * @param
         * @desc Called when an action is selected from the Actions menu. The function broadcasts an event based on the action selected
         */
        this.constructor.prototype.onActionClick = function onActionClick(popupMenuView, action) {
            var parent = this.ui.getParent().ui.getParent();
            if (!parent.context) {
                parent = this.ui.getParent();
            }

            if (taskUtils.EVENTS.BEFORE_VIEW_INSTANCE.equals(action)) {
                var data = {
                    piid: this._instance.piid, 
                    systemID: this._instance.systemID,
                    openInNewTab: true
                }
                taskUtils.EVENTS.BEFORE_VIEW_INSTANCE.publish(data);
            }else if (taskUtils.EVENTS.VIEW_PROCESS_DIAGRAM.equals(action)) {
                var view = this;
                // Get user preferences to see items should be opened in new tab
                wpResources.user.get({refresh: true})
                    .then(dojo.hitch(view, function(user) {
                        view._instance.userPrefs = user.userPreferences;
                        var piid = this._instance.piid;
                        var processName = this._instance.workstreamName;
                        var data = {
                            process: view._instance.process
                        };
        
                        if (parent.context && parent.context.options) {
                            if (parent.context.options.openTaskInNewTab){
                                data.openTaskInNewTab = parent.context.options.openTaskInNewTab.get("value");
                            } else if (this._instance.userPrefs[wpResources.user.PREFERENCE.portalOpenTaskInNewWindow] == "generalPreference.fields.openTaskInNewWindow.yes"){
                                data.openTaskInNewTab = this._instance.userPrefs[wpResources.user.PREFERENCE.portalOpenTaskInNewWindow] == "generalPreference.fields.openTaskInNewWindow.yes"
                            } else if(this._instance.userPrefs[wpResources.user.PREFERENCE.portalOpenTaskInNewWindow] == "generalPreference.fields.openTaskInNewWindow.default" && !data.openTaskInNewTab){
                                wpResources.config.get().then(function(mashupsConfig) {
                                    data.openTaskInNewTab = mashupsConfig.openTaskInNewWindow;
                                });
                            }
                        }
        
                        if(resourceUtils.exposedResources.urls && resourceUtils.exposedResources.urls.length > 0) {
                            var exposedData = resourceUtils.exposedResources;
                            var urls = exposedData.urls;
        
                            urls.every(function(item){
                                if (item.display === "Workplace Process Diagram"){
                                    var runURL =  item.runURL + "&tw.local.processInstanceId=" + piid;
                                    if (data.openTaskInNewTab){
                                        window.open(runURL, '_blank').focus();
                                        
                                        // Close task viewer when instance ui is embedded in an iframe
                                        if (parent && parent.parent && parent !== parent.parent) {
                                            try {
                                                var data1 = {
                                                    name: "closeTaskViewer"
                                                };
                                                parent.parent.postMessage(JSON.stringify(data1), "*");
                                            } catch (e) {
                                                bpmext.log.error("InstanceUI.closeTaskViewer " + bpmext.localization.formatMsg("general", "ERROR") + ": " + e);
                                                if (e.stack) {
                                                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                                                }
                                            }
                                        }
                                        taskUtils.EVENTS.CLOSE_TASK_VIEWER.publish();
                                        return false;
                                    }else{
                                        data.service = JSON.parse(JSON.stringify(item));
                                        data.service.runURL = runURL;
                                        data.name = processName + " " + bpmext.localization.formatMsg("workplace", "processDiagram");
                                        action.publish(data);
                                        return false;
                                    }
                                }
                                return true;
                            });
                        }else{
                            var fetchError = function (error) {
                                !!error && !!error.errorMessage && taskUtils.publishError(error.errorMessage);
                                bpmext.log.error("ERROR >> There was an error fetching dashboards: " + error);
                                // Hide loading skeleton table 
                                if (error && error.response && error.response.data && error.response.data.status === 500 && error.response.data.errorNumber === "CWMFS4021E") {
                                    taskUtils.EVENTS.NO_FEDERATED_SYSTEM.publish(error);
                                }
                            };
        
                            wpResources.config.get().then(function(config) {
                                // Dashboard toolkit is not exposed in OCP
                                var options = {
                                    excludeReferencedFromToolkit: !!config.excludeReferencedFromToolkit,
                                    includeDescription: true,
                                    filterByName: ["Workplace Process Diagram"],
                                    subtypes: [
                                        wpResources.exposed.SERVICE_SUBTYPE.URL
                                    ]
                                };
            
                                wpResources.exposed.get(options).then(
                                    function (exposedData) {
                                        var expData = resourceUtils.buildResources(exposedData, options);
                                        var urls = expData.urls;
        
                                        urls.every(function(item){
                                            if (item.display === "Workplace Process Diagram"){
                                                var runURL =  item.runURL + "&tw.local.processInstanceId=" + piid;
                                                if (data.openTaskInNewTab){
                                                    window.open(runURL, '_blank').focus();
                                                    // Close task viewer when instance ui is embedded in an iframe
                                                    if (parent && parent.parent && parent !== parent.parent) {
                                                        try {
                                                            var data1 = {
                                                                name: "closeTaskViewer"
                                                            };
                                                            parent.parent.postMessage(JSON.stringify(data1), "*");
                                                        } catch (e) {
                                                            bpmext.log.error("InstanceUI.closeTaskViewer " + bpmext.localization.formatMsg("general", "ERROR") + ": " + e);
                                                            if (e.stack) {
                                                                bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                                                            }
                                                        }
                                                    }
                                                    taskUtils.EVENTS.CLOSE_TASK_VIEWER.publish();
                                                    return false;
                                                }else{
                                                    data.service = JSON.parse(JSON.stringify(item));
                                                    data.service.runURL = runURL;
                                                    data.name = processName + " " + bpmext.localization.formatMsg("workplace", "processDiagram");
                                                    action.publish(data);
                                                    return false;
                                                }
                                            }
                                            return true;
                                        });
                                    },
                                    fetchError
                                );
                            }, fetchError);
                        }
                    }));

                
            } else if (taskUtils.EVENTS.MODIFY_INSTANCE.equals(action)) {
			    taskUtils.EVENTS.MODIFY_INSTANCE_OPEN.publish();
            } else if (taskUtils.EVENTS.FOLLOW_INSTANCE.equals(action)) {
            	taskUtils.EVENTS.FOLLOW_INSTANCE.publish();
            } else if (taskUtils.EVENTS.UNFOLLOW_INSTANCE.equals(action)) {
			    taskUtils.EVENTS.UNFOLLOW_INSTANCE.publish();
            } else {
                var queryAction;
                if (taskUtils.EVENTS.TERMINATE_INSTANCE_EVENT.equals(action)) {
                    queryAction = wpResources.process.ACTIONS.TERMINATE;
                } else if (taskUtils.EVENTS.RETRY_INSTANCE_EVENT.equals(action)) {
                    queryAction = wpResources.process.ACTIONS.RETRY;
                } else if (taskUtils.EVENTS.SUSPEND_INSTANCE_EVENT.equals(action)) {
                    queryAction = wpResources.process.ACTIONS.SUSPEND;
                } else if (taskUtils.EVENTS.RESUME_INSTANCE_EVENT.equals(action)) {
                    queryAction = wpResources.process.ACTIONS.RESUME;
                }
                var deferAction = function (piid, action, systemID) {
                    return function () {
                        wpResources.process.performAction({piid: piid, action: action, systemID: systemID}).then(function(){
                            taskUtils.EVENTS.ACTION_PERFORMED.publish();
                        });
                    };
                }(this._instance.piid, queryAction, this._instance.systemID);

                var confirmRequiredAction = [taskUtils.EVENTS.TERMINATE_INSTANCE_EVENT];
                if (confirmRequiredAction.indexOf(action) > -1) {
                    taskUtils.EVENTS.PERFORM_WORKSTREAM_ACTION.publish({
                        action: action,
                        deferAction: deferAction,
                        workstreamName: this._instance.workstreamName
                    });
                } else {
                    deferAction();
                }
            }
        };

        /**
         * @instance
         * @memberof WorkstreamActionsMenu
         * @method onPopupOpen
         * @param {View} popupMenuView The popup view
         * @desc Called when the actions menu popup is opened
         */
        this.constructor.prototype.onPopupOpen = function onPopupOpen() {
            var menuButtonEle = this._instance.targetElement;
            !!menuButtonEle && domClass.add(menuButtonEle,"active");
            bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONSHOW, this._instance.targetElement);
        };

        /**
         * @instance
         * @memberof WorkstreamActionsMenu
         * @method onPopupClosed
         * @param {View} popupMenuView The popup view
         * @desc Called when the actions menu popup is closed
         */
        this.constructor.prototype.onPopupClosed = function onPopupClosed() {
            var menuButtonEle = this._instance.targetElement;
            !!menuButtonEle && domClass.remove(menuButtonEle,"active");
            bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONHIDE, this._instance.targetElement);
        };

        /**
         * @instance
         * @memberof WorkstreamActionsMenu
         * @method isMenuOpen
         * @desc Returns a true/false indicating if the Actions menu open
         * @return {boolean}
         */
        this.constructor.prototype.isMenuOpen = function isMenuOpen() {
            return this._instance.popupMenu.isMenuVisible();
        };

        /**
         * @instance
         * @memberof WorkstreamActionsMenu
         * @method open
         * @desc Function to open the actions menu
         */
        this.constructor.prototype.open = function open () {
            this._instance.popupMenu.setMenuVisible(true);
        };

        /**
         * @instance
         * @memberof WorkstreamActionsMenu
         * @method close
         * @desc Function to close the actions menu
         */
        this.constructor.prototype.close = function close () {
            this._instance.popupMenu.setMenuVisible(false);
        };

        /**
         * @instance
         * @memberof WorkstreamActionsMenu
         * @method getMenuItemCount
         * @desc Gets number of actions in the action menu
         */
        this.constructor.prototype.getMenuItemCount = function getMenuItemCount () {
            return this._instance.popupMenu.getMenuItemCount();
        };

        /**
         * @instance
         * @memberof WorkstreamActionsMenu
         * @method updateFollowActions
         * @desc update the follow action menu
         */
        this.constructor.prototype.updateFollowActions = function updateFollowActions () {
            return this._proto._updateFollowActions(this);
        };

        /**
         * @instance
         * @memberof WorkstreamActionsMenu
         * @method handelBtnVisibilityOnEmpty
         * @param {View} view View of the control button / icon
         * @param {Boolean} handle Handel the visibility on true
         * @desc Handle button's visibility base on popup menu context
         */
        this.constructor.prototype.handelBtnVisibilityOnEmpty = function hideMenuButtonOnEmpty (view, handle) {
            if (view && view.setVisible) {
                this._instance.menuBtnView = view;
                this._instance.handelBtnVisibility = !!handle;
            } else {
                this._instance.menuBtnView = undefined;
                this._instance.handelBtnVisibility = false;
            }
        };

        /**
         * @instance
         * @memberof WorkstreamActionsMenu
         * @method showMenuAfterLoad
         * @param {Boolean} show Showing the menu on loaded
         * @desc Shows the menu once menu been loaded
         */
        this.constructor.prototype.showMenuAfterLoad = function showMenuAfterLoad (show) {
            this._instance.showMenuAfterLoad = !!show;
        };

        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function() {
            try {
                var view = this;
                var opts = this.context.options;

                if (!opts.disableActions) {
                    bpmext.ui.substituteConfigOption(this, "disableActions", []);
                }

                view._instance.menuItems = [];
                this._instance.handelBtnVisibility = false;
                this._instance.showMenuAfterLoad = false;

                view._instance.popupMenu = bpmext.ui.getContainer("Workstream_Action_Menu", this);
                view._instance.popupMenu._proto._setDisabler(view._instance.popupMenu, false);

                bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONSHOW);
                bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONHIDE);

                taskUtils.EVENTS.UPDATE_FOLLOW_ACTION.subscribe(this.updateFollowActions, this);

                this.loadView(this);
            } catch (error) {
                bpmext.log.error(error);
            }
        };

        this.constructor.prototype.view = function() {
            try {
                utilities.handleVisibility(this.context);
            } catch (e) {
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if (e.stack) {
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                }
            }
        };

        this.constructor.prototype.change = function (event){
            bpmext.log.info("WorkstreamActionsMenu.change ENTER >> (event): " + event, this);
            if (event.type === "config") {
                switch (event.property) {
                    case "_metadata.visibility": {
                        this.view();
                        break;
                    }
                }
            }
            bpmext.log.info("WorkstreamActionsMenu.change ENTER >>", this);
        };
        this.constructor.prototype.unload = function() {
            bpmext.ui.unloadView(this);
        };
    }
};