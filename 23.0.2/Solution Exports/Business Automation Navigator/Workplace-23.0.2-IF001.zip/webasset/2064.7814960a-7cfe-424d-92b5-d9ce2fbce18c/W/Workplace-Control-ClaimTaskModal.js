/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof ClaimTaskModal
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof ClaimTaskModal
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof ClaimTaskModal
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof ClaimTaskModal
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof ClaimTaskModal
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof ClaimTaskModal
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof ClaimTaskModal
 * @method triggerFormulaUpdates
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 * </table>
 */
workplace_control_InitClaimTaskModal = function (utilities, taskUtils, wpResources, domAttr)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            _loadModal: function __loadModal(view){
                bpmext.log.info("ClaimTaskModal.__loadModal LOG >>", view);
                if(view._instance.task.state !== wpResources.task.STATE.CLAIMED && view._instance.skipClaimDialog !== true){
                    //no user is assigned check user preference if we need to show claim task modal
                    view._proto._getUserPreference(view);
                }else{
                    //user is assigned to task therefore we can directly launch task
                    view._proto._publishTaskLaunched(view, view._instance.task, view._instance.systemData, view._instance.skipClaimDialog);
                }
                view._instance.skipClaimDialog = false;
            },
            _publishTaskLaunched : function _publishTaskLaunched(view, task, systemData) {
                taskUtils.EVENTS.CALL_LAUNCH_TASK_EVENT.publish(task);

                if (view._instance.openTaskInNewTab){
                    window.open(task.runURL, '_blank').focus();
                    // Close task viewer when task list is embedded in an iframe
                    if (parent && parent !== parent.parent) {
                        try {
                            var data = {
                                name: "closeTaskViewer"
                            };
                            parent.parent.postMessage(JSON.stringify(data), "*");
                        } catch (e) {
                            bpmext.log.error("InstanceUI.closeTaskViewer " + bpmext.localization.formatMsg("general", "ERROR") + ": " + e);
                            if (e.stack) {
                                bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                            }
                        }
                    }
                    taskUtils.EVENTS.CLOSE_TASK_VIEWER.publish();
                }else{
                    taskUtils.EVENTS.TASK_LAUNCHED.publish({task: task, systemData: systemData});

                    //if the task is being loaded in an iframe, try to post the task launch request to the parent
                    if (parent && parent !== parent.parent) {
                        try {
                            var data = {
                                name: "launchTask",
                                task: task
                            };
                            parent.parent.postMessage(JSON.stringify(data), "*");
                        } catch (e) {
                            bpmext.log.error("ConfigurationWizard._notifyPortal() " + bpmext.localization.formatMsg("general", "ERROR") + ": " + e);
                            if (e.stack) {
                                bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                            }
                        }
                    }
                }
            },
            
            _showClaimTask: function _showClaimTask(view, show, claim) {
            	if (show) {
            		view._instance.doNotShowCheckbox.setChecked(false);
                    view._instance.modalSection.show();
                    view.show();
                    taskUtils.setTabCycle(view);
                    if (claim) {
                    	view._instance.claimRestCall = true;
                    }
            	} else if (claim) {
            		// directly send claim rest call
            		wpResources.task.claim(viwe._instance.task).then(dojo.hitch(view, function () {
                		view._proto._publishTaskLaunched(view, view._instance.task, view._instance.systemData);
                	}));
                	
                }
            },
            
            _getUserPreference: function _getUserPreference(view) {
                bpmext.log.info("ClaimTaskModal._getUserPreference LOG >>", view);
                try {
                    wpResources.user.get()
                        .then(dojo.hitch(view, function(user) {
                        	wpResources.config.get().then(dojo.hitch(view, function(config) {
                        		 if (user.userPreferences) {
                                     var alertOnAssignAndRun = user.userPreferences[wpResources.user.PREFERENCE.alertOnAssignAndRun]?user.userPreferences[wpResources.user.PREFERENCE.alertOnAssignAndRun]:"true";
                                     this._instance.alertOnAssignAndRun = alertOnAssignAndRun;
                                     
                                     if (taskUtils.isExternalTask(this._instance.task)) {
                                     	// external UI
                                     	if (config.doNotClaimExternalUI) {
                                     		// claim not allowed, directly launch
                                     		this._proto._publishTaskLaunched(this, this._instance.task, this._instance.systemData);
                                     	} else {
                                     		// claim allowed, need send separate claim request for external task
                                     		if(this._instance.alertOnAssignAndRun==="true"){
                                                //Auto Claim is false show claim modal
                                                this._proto._showClaimTask(view, true, true);
                                            } else {
                                                //Auto Claim is true launch task
                                            	this._proto._showClaimTask(view, false, true);
                                            }
                                     	}
                                     } else {
                                     	if(this._instance.alertOnAssignAndRun==="true"){
                                             //Auto Claim is false show claim modal
                                     		this._proto._showClaimTask(view, true, false);
                                         } else {
                                             //Auto Claim is true launch task
                                             this._proto._publishTaskLaunched(this, this._instance.task, this._instance.systemData);
                                         }
                                     }
                                 } else {
                                     bpmext.log.error("Claim Task Modal", "Unable to get user info");
                                 }
                        	})) 
                           
                        }));
                } catch (error) {
                    bpmext.log.error(error.message);
                }
            },
            _updateUserPreference: function _updateUserPreference(view) {
                bpmext.log.info("ClaimTaskModal._updateUserPreference LOG >>", view);
                try {
                    var prefs = { };
                    prefs[wpResources.user.PREFERENCE.alertOnAssignAndRun] = "false";
                    wpResources.user.setPreferences({preferences: prefs});
                } catch (error) {
                    bpmext.log.error(error.message);
                }
            },

            _shouldProcessEvents: function _shouldProcessEvents(view, event) {
                return view._instance.targetEvents.some(function (event1) {
                    return event1.name === event;
                });
            }
        };


        /*
        Public control methods *************************************************************
         */

        /**
		 * @instance
		 * @memberof ClaimTaskModal
		 * @method closeModal
		 * @desc Closes the modal dialog
         */
        this.constructor.prototype.closeModal = function() {
			bpmext.log.info("ClaimTaskModal.closeModal ENTER >> ",this);
            this.setVisible(false, true);
            this._instance.modalSection.setVisible(false, true);
			bpmext.log.info("ClaimTaskModal.closeModal EXIT << ");
        };

        /**
		 * @instance
		 * @memberof ClaimTaskModal
		 * @method claimAction
		 * @desc Claims the task and closes the modal
         */
        this.constructor.prototype.claimAction = function() {
            bpmext.log.info("ClaimTaskModal.claimAction ENTER >> ", this);
            if(this._instance.doNotShowCheckbox.isChecked()){
                // Do not show again is checked we need to update user preference
                this._proto._updateUserPreference(this);
            }
            if (this._instance.claimRestCall) {
            	wpResources.task.claim(this._instance.task).then(dojo.hitch(this, function () {
            		this._proto._publishTaskLaunched(this, this._instance.task, this._instance.systemData);
            	}));
            } else {
            	this._proto._publishTaskLaunched(this, this._instance.task, this._instance.systemData);
            }
            
            this.closeModal();
			bpmext.log.info("ClaimTaskModal.claimAction EXIT << ");
        };

        /**
		 * @instance
		 * @memberof ClaimTaskModal
		 * @method setTargetEvents
         * @param {[]} events Array of event names that this modal will respond to
		 * @desc Sets the events that this modal will respond to
         */
        this.constructor.prototype.setTargetEvents = function(events) {
            bpmext.log.info("ClaimTaskModal.setTargetEvents ENTER >> ", events);
            this._instance.targetEvents = events ? events : [];
			bpmext.log.info("ClaimTaskModal.setTargetEvents EXIT << ");
        };

        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function (){
            bpmext.log.info("ClaimTaskModal.load ENTER >>", this);

            var view = this;
            this._instance.modalSection = bpmext.ui.getContainer("ModalSection", this);
            this._instance.modalSection.setPrimaryButtonText(bpmext.localization.formatMsg("claimTaskModal", "claim"));
            this._instance.modalSection.setSecondaryButtonText(bpmext.localization.formatMsg("claimTaskModal", "cancel"));
            //CV in ModalSection
            this._instance.panel = bpmext.ui.getContainer("Panel", this);
            //CV in Panel
            this._instance.claimTaskMessage = bpmext.ui.getView("ClaimTaskMessage", this);
            this._instance.doNotShowCheckbox = bpmext.ui.getView("DoNotShowCheckbox", this);
            this._instance.modalSection._instance.modalDialog.ariaLabel = bpmext.localization.formatMsg("claimTaskModal", "claimTask");
            this._instance.panel.setTitle(bpmext.localization.formatMsg("claimTaskModal", "claimTask"));
            this._instance.claimTaskMessage.setLabel(bpmext.localization.formatMsg("claimTaskModal", "claimTaskMessage"));
            this._instance.doNotShowCheckbox.setLabel(bpmext.localization.formatMsg("claimTaskModal", "doNotShowMessage"));

            this.setTargetEvents();

            var panelHeaderIcon = this._instance.panel.context.element.querySelector("div.panel-heading-controls > div.panel-heading-icon > i");
            !!panelHeaderIcon && domAttr.remove(panelHeaderIcon, "tabindex");

			var getTaskStats = function(eventName, eventData){
                if (!view._proto._shouldProcessEvents(view, eventName)) {
                    return;
                }
                
                // check if the task has been opened in the history stack
                var ident = {tkiid: eventData.task.tkiid, systemID: eventData.task.systemID};
                var prevHistoryIndex = taskUtils.viewHistory.fetchHistoryIndexByIdentData(ident);
                
                // if a duplicate launch entity has been detected, fall back to previous previous entity
                if (prevHistoryIndex > -1 && !eventData.openTaskInNewTab) {
                    return taskUtils.viewHistory.loadHistoryItem(prevHistoryIndex);
                }

                // Get task stats
                view._instance.systemData = eventData.systemData;
                view._instance.task = eventData.task;
                view._instance.skipClaimDialog = eventData.skipClaim;
                view._instance.openTaskInNewTab = eventData.openTaskInNewTab;
				
				// Open tasks in a new tab when opening from Instance UI runUrl
                if (eventData.origin == "Instance_UI1" && parent && parent === parent.parent){
                    view._instance.openTaskInNewTab = true;
                }
                
                if (eventData.skipClaim) {
                    view._proto._loadModal(view);
                } else if (!eventData.origin || view.ui.getAncestor(eventData.origin)) {
                    view._proto._loadModal(view);
                } else if (eventData.openTaskInNewTab) {
                    var parent = view.ui.getParent().ui.getParent();
                    if (!parent.context) {
                        parent = view.ui.getParent();
                    }
                    // Need to check the origin or else it will open the task twice
                    if (eventData.origin == "TaskViewer1" && parent.context.viewid != 'Instance_UI'){
                        view._proto._loadModal(view);
                    }
                }
			};
			taskUtils.EVENTS.TASK_BEFORE_LAUNCH.subscribe(getTaskStats, this);
            taskUtils.EVENTS.INSTANCE_TASK_BEFORE_LAUNCH.subscribe(getTaskStats, this);
            taskUtils.EVENTS.TASK_CONFIRM_CLAIM.subscribe(getTaskStats, this);
            taskUtils.EVENTS.TEAM_TASK_BEFORE_LAUNCH.subscribe(getTaskStats, this);
            taskUtils.EVENTS.TEAM_MEMBER_TASK_BEFORE_LAUNCH.subscribe(getTaskStats, this);

            this.loadContainer(this);

            bpmext.log.info("ClaimTaskModal.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try {
                utilities.handleVisibility(this.context);
            }
            catch (e){
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e, this);
                if(e.stack) {
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack), this);
                }
            }
        };

        this.constructor.prototype.change = function (event){
            bpmext.log.info("ClaimTaskModal.change ENTER >> (event): " + event, this);
            bpmext.log.info("ClaimTaskModal.change ENTER >>", this);
        };

        this.constructor.prototype.unload = function (){
            bpmext.log.info("ClaimTaskModal.unload ENTER >> ", this);
            bpmext.ui.unloadContainer(this);
            bpmext.log.info("ClaimTaskModal.unload ENTER >>", this);
        };
    }
};