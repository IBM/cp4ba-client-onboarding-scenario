/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof RecentWorkstream
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof RecentWorkstream
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof RecentWorkstream
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof RecentWorkstream
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof RecentWorkstream
 * @method setData
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On Process Launched:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when a process is launched</td>
 *               </tr>
 *           </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">item {object}</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">process data</td>
 *               </tr>
 *       </table>
 *     </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On Service Launched:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when a service is launched</td>
 *               </tr>
 * </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">item {object}</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">service data</td>
 *               </tr>
 *           </table>
 *       </td>
 *   </tr>
 * </table>
 */
workplace_control_InitRecentWorkstream = function (utilities, taskUtils, wpResources) {
	"use strict";
	this._instance =
	{
		buttonClicked: null,
	};

	if (!this.constructor.prototype._proto) {
		this.constructor.prototype._proto =
		{
			EVT_ONLOAD: "eventON_LOAD",
			EVT_ONPROCESS_LAUNCHED: "eventON_PROCESS_LAUNCHED",
			EVT_ONSERVICE_LAUNCHED: "eventON_SERVICE_LAUNCHED",
			EVT_ONTEAM_LAUNCHED: "eventON_TEAM_LAUNCHED",

			_setViewData: function _setViewData(view, data, createPseudoBinding) {
				var ctx = view.context;
				if (ctx) {
					if (ctx.binding) {
						ctx.binding.set("value", data);
					} else if (createPseudoBinding) {
						ctx.binding = bpmext.ui.substituteObject(view);
						ctx.binding.set("value", data);
					}
				}
			},

			_setPrimaryButton: function _setPrimaryButton(view) {
				var selectedItem = view._instance.selectedWorkstream, eventData = {}, buttonTxt = bpmext.localization.formatMsg("workplace", "next");
				if (selectedItem && (selectedItem.type === "process" || selectedItem.type === "casetype")) {
					buttonTxt = bpmext.localization.formatMsg("taskCard", "launch");
				}
				eventData = {
					enable: !!selectedItem,
					text: buttonTxt
				};
				taskUtils.EVENTS.SLIDEOUT_SET_PRIMARY_BTN.publish(eventData);
			},

			_errorLoadResource: function () {
				bpmext.log.error("Resources load - error", this);
			},

			_groupWorkStreams: function _groupWorkStreams(data) {
				var items = [], groupArray = [];
				if (data) {
					items = dojo.clone(data);
					for (var i = 0; i < items.length; i += 3) {
						var obj = {};
						if (i < items.length) {
							for (var j = 0; j < 3; j += 1) {
								obj[j] = items[i + j];
							}
							groupArray.push(obj);
						}
					}
				}
				return groupArray;
			},

			_updateData: function (view, originalList) {
				view._instance.recentsLabel.setVisible(false, true);
				view._instance.recentsCaseLabel.setVisible(false, true);

				view._instance.collapseCases.setVisible(wpResources.isFederated, true);
				view._instance.NoRecentCasesFound.setVisible(false, true);
				view._instance.NoRecentsWorkflowsFound.setVisible(false, true);
				var cases = [];
				var workstreams = [];
				for (var i = 0; i <= originalList.length; i++) {
					if (originalList[i] && originalList[i].type === 'casetype') {
						cases = cases.concat(originalList[i]);
					}

					if (originalList[i] && (originalList[i].type === 'APPROVAL' ||
						originalList[i].type === "CHECKLIST" ||
						originalList[i].type === "process" ||
						originalList[i].type === "service")) {
						workstreams = workstreams.concat(originalList[i]);
					}
				}
				workstreams = workstreams.slice(0, view._instance.recentLimit);
				cases = cases.slice(0, view._instance.recentLimit);
				var isRecentWorkflowEmpty = workstreams.length === 0;
				var isRecentCaseEmpty = cases.length === 0;
				view._instance.recentWorkstreams = this._groupWorkStreams(workstreams);
				view._instance.recentCases = this._groupWorkStreams(cases);
				this._setViewData(view._instance.workstreamsCV, view._instance.recentWorkstreams, true);
				this._setViewData(view._instance.caseCV, view._instance.recentCases, true);

				setTimeout(function () {
					view._instance.NoRecentCasesFound.setVisible(isRecentCaseEmpty, !isRecentCaseEmpty);
					view._instance.NoRecentsCaseImage._instance.img.setAttribute("title", bpmext.localization.formatMsg("workplace", "emptyCube"));
					view._instance.NoRecentsCaseImage._instance.img.setAttribute("alt", bpmext.localization.formatMsg("workplace", "emptyCube"));
					view._instance.NoRecentsWorkflowsFound.setVisible(isRecentWorkflowEmpty, !isRecentWorkflowEmpty);
					view._instance.NoRecentsWorkflowImage._instance.img.setAttribute("title", bpmext.localization.formatMsg("workplace", "emptyCube"));
					view._instance.NoRecentsWorkflowImage._instance.img.setAttribute("alt", bpmext.localization.formatMsg("workplace", "emptyCube"));

					// Accessibility
					if (view._instance.NoRecentCasesFound.isVisible() || view._instance.NoRecentsWorkflowsFound.isVisible()) {
						taskUtils.setTabCycle(view);
					}
				}, 50);
			},

			_updateRecentList: function (eItem, aInstance, view) {
				var recentList = view._instance.recentWorkstreams, processName = aInstance && (aInstance.bpdName || aInstance.processName),
					// check whether the process has in the recent list, if not, combine with the exposed item and put at the first; if yes, move it to the first; if there are multiple same name configurable workstreams, only keep the latest one
					existing = false;
				for (var i = 0; i < recentList.length; i++) {
					var item = recentList[i];
					if (processName === taskUtils.CONFIGURABLE_WORKSTREAM && item.name === aInstance.name) {
						existing = true;
						recentList.splice(i, 1);
						recentList.unshift(aInstance);
					} else if ((eItem && item.display === eItem.display)) {
						existing = true;
						recentList.splice(i, 1);
						recentList.unshift(item);
					}
				}
				if (!existing) {
					if (processName === taskUtils.CONFIGURABLE_WORKSTREAM) {
						recentList.unshift(aInstance);
					} else {
						view._instance.allCV._instance.allWorkstreams.forEach(function (item) {
							if (eItem && eItem.display === item.display) {
								recentList.unshift(item);
							}
						});
					}
				}
				this._updateData(recentList, view);
			},

			_getOrderId: function (dashboard) {
				if (!dashboard) {
					return;
				}
				var orderId = "",
					itemId, systemId, idx, index;
				if (dashboard.ID && dashboard.itemID) {
					orderId = dashboard.ID;
					itemId = dashboard.itemID;
					systemId = dashboard.systemID;
					idx = itemId.lastIndexOf("-");
					if (idx !== -1) {
						orderId += itemId.slice(idx);
					}
					if (systemId) {
						index = systemId.lastIndexOf("-");
						if (index !== -1) {
							orderId += systemId.slice(index);
						}
					}
					orderId += "/";
				} else if (dashboard.bpdName === "Configurable Workstream" || dashboard.processName === "Configurable Workstream" || dashboard.PT_NAME === "Configurable Workstream") {
					var name = dashboard.name || dashboard.PI_NAME;
					orderId = name + "-" + dashboard.type;
				} else {
					orderId = dashboard.systemID + "-" + dashboard.casetypeSymbolicName;
				}
				return orderId.toLowerCase();
			},

			_getFavorite: function (view, targetView) {
				var path = targetView.context.controlidpath;
				var regex = /\[(-?\d+)\]/;
				var i = path.match(regex)[1];
				var j = path.charAt(path.length - 1);
				return view._instance.workstreamsCV.context.binding.get("value").items[i][j];
			},

			_getFavoriteCase: function (view, targetView) {
				var path = targetView.context.controlidpath;
				var regex = /\[(-?\d+)\]/;
				var i = path.match(regex)[1];
				var j = path.charAt(path.length - 1);
				return view._instance.caseCV.context.binding.get("value").items[i][j];
			}
		};

		/*
		Public control methods *************************************************************
		 */

		/**
		* @instance
		* @memberof RecentWorkstream
		* @method goNext
		* @desc Go to step2
		*/
		this.constructor.prototype.goNext = function goNext() {
			bpmext.log.info("RecentWorkstream.goNext ENTER>>", this);
			var selectedItem = this._instance.selectedWorkstream;
			if (selectedItem.PT_NAME === "Configurable Workstream" || selectedItem.bpdName === "Configurable Workstream") {
				taskUtils.EVENTS.LOAD_STACK_PANE.publish({ targetView: "Name_Workstream1" });
				taskUtils.EVENTS.OPEN_NAME_WORKSTREAM.publish({
					selectedWorkstream: selectedItem,
					allExposedResource: this._instance.allCV._instance.allExposedItem,
					caller: "RECENT_WORKSTREAM"
				});
			} else {
				taskUtils.EVENTS.SLIDEOUT_PANEL_CLOSE.publish();
				taskUtils.EVENTS.LAUNCH_RESOURCE.publish(selectedItem);
			}
		};

		/**
				 * @instance
				 * @memberof RecentWorkstream
				 * @method closeSlideout
				 * @desc Closes the dialog
				 */
		this.constructor.prototype.closeSlideout = function closeSlideout() {
			taskUtils.EVENTS.SLIDEOUT_PANEL_CLOSE.publish();
		};

		/**
				 * @instance
				 * @memberof RecentWorkstream
				 * @method selectWorkflow
				 * @desc select a workflow
				 */
		this.constructor.prototype.selectWorkflow = function selectWorkflow(target, index) {
			bpmext.log.info("RecentWorkstream.selectWorkflow ENTER >>", this);
			var data = this._instance.recentWorkstreams[target.ui.getIndex()];
			if (data && data[index] && data[index].snapshots && data[index].snapshots.length > 0) {
				target.openSnapshotLinks(data[index]);
			}
			this._instance.selectedWorkstream = data[index];
			this._proto._setPrimaryButton(this);
		};

		/**
				 * @instance
				 * @memberof RecentCases
				 * @method selectCase
				 * @desc select a workflow
				 */
		this.constructor.prototype.selectCase = function selectCase(target, index) {
			bpmext.log.info("RecentWorkstream.selectCase ENTER >>", this);
			var data = this._instance.recentCases[target.ui.getIndex()];
			if (data && data[index] && data[index].snapshots && data[index].snapshots.length > 0) {
				target.openSnapshotLinks(data[index]);
			}
			this._instance.selectedWorkstream = data[index];
			this._proto._setPrimaryButton(this);
		};

		/**
				 * @instance
				 * @memberof RecentWorkstream
				 * @method selectSnapshot
				 * @desc select a snapshot
				 */
		this.constructor.prototype.selectSnapshot = function selectSnapshot(item) {
			bpmext.log.info("RecentWorkstream.selectSnapshot ENTER >>", this);
			this._instance.selectedWorkstream = item;
			this._proto._setPrimaryButton(this);
		};

		/**
 * @instance
 * @memberof RecentWorkstream
 * @method setWorkStreamData
 * @desc set name and description
 */
		this.constructor.prototype.setWorkStreamData = function (target, index) {
			bpmext.log.info("RecentWorkstream.setWorkStreamName ENTER>>", this);
			var stream = this._instance.recentWorkstreams[target.ui.getIndex()], name, desc;
			var lastStream = this._instance.recentWorkstreams[this._instance.recentWorkstreams.length - 1]
			var obj = stream[index];
			if (obj) {
				target.setVisible(true);
				name = obj.display || obj.name;
				desc = obj.itemDescription || obj.casetypeDescription;
				if (obj.type === "casetype") {
					target.setVisible(false, true);
					target.setTitle(obj.display + " (" + obj.solutionName + ")");

					target._instance.card.context.element.firstElementChild.setAttribute("role", "menu")
					target._instance.card.context.element.firstElementChild.setAttribute("aria-label",
						obj.display + " (" + obj.solutionName + ")"
						+ " " + bpmext.localization.formatMsg("workplace", "card"));
				} else {
					target.setTitle(name);

					target._instance.card.context.element.firstElementChild.setAttribute("role", "menu")
					target._instance.card.context.element.firstElementChild.setAttribute("aria-label",
						name + " " + bpmext.localization.formatMsg("workplace", "card"));
				}
				target.setDescription(desc);
				if (obj.snapshots && obj.snapshots.length > 0) {
					target.setSnapshotData(obj, target);
				}
				if (obj.type === "CHECKLIST") {
					target.setTopIcon("ci-list-checked");
				} else if (obj.type === "APPROVAL") {
					target.setTopIcon("ci-network-3");
				} else {
					target.setTopIcon("ci-flow-data");
				}
			} else {
				target.setVisible(false, true);
			}

			// Accessibility
			if (lastStream === stream && index === Object.keys(lastStream).length - 1 && this._instance.firstWorkflowLoad) {
				taskUtils.setTabCycle(this);
			}
		};

		/**
		* @instance
		* @memberof RecentCase
		* @method setCaseData
		* @desc set name and description
		*/
		this.constructor.prototype.setCaseData = function (target, index) {
			bpmext.log.info("RecentWorkstream.setCaseData ENTER>>", this);
			var stream = this._instance.recentCases[target.ui.getIndex()], name, desc;
			var lastStream = this._instance.recentCases[this._instance.recentCases.length - 1]
			var obj = stream[index];
			if (obj) {
				target.setVisible(false, true);
				name = obj.display || obj.name;
				desc = obj.itemDescription || obj.casetypeDescription;
				if (obj.type === "casetype") {
					target.setVisible(true);
					target.setTitle(obj.display + " (" + obj.solutionName + ")");

					target._instance.card.context.element.firstElementChild.setAttribute("role", "menu")
					target._instance.card.context.element.firstElementChild.setAttribute("aria-label",
						obj.display + " (" + obj.solutionName + ")"
						+ " " + bpmext.localization.formatMsg("workplace", "card"));
				}
				target.setDescription(desc);
				target.setTopIcon("ci-Portfolio");
				if (obj.snapshots && obj.snapshots.length > 0) {
					target.setSnapshotData(obj, target);
				}
			} else {
				target.setVisible(false, true);
			}

			// Accessibility
			if (lastStream === stream && index === Object.keys(lastStream).length - 1 && this._instance.firstWorkflowLoad) {
				taskUtils.setTabCycle(this);
			}
		};

		/**
 * @instance
 * @memberof RecentWorkstream
 * @method configWorkStream
 * @desc create a new workStream
 */
		this.constructor.prototype.configWorkStream = function () {
			bpmext.log.info("RecentWorkstream.configWorkStream ENTER>>", this);
			taskUtils.EVENTS.OPEN_CONFIG.publish(this._instance.allCV._instance.allExposedItem);
		};

		/**
 * @instance
 * @memberof RecentWorkstream
 * @method refresh
 * @desc Reloads the launch list
 */
		this.constructor.prototype.refresh = function () {
			bpmext.log.info("RecentWorkstream.refresh ENTER>>", this);

			this._instance.needRefresh = true;
		};

		/**
				 * @instance
				 * @memberof RecentWorkstream
				 * @method loadFavorites
				 * @desc Set the favorite workstream icons to filled
				 */
		this.constructor.prototype.loadRecentFavorites = function loadRecentFavorites(favoriteView, targetView) {
			var item = this._proto._getFavorite(this, targetView);
			var view = this;

			this.context.options.favorites.get("value").items.forEach(function (favorite) {
				if (view._proto._getOrderId(item) === favorite) {
					favoriteView.setLabel(bpmext.localization.formatMsg("workplace", "favoriteFilled"));
					favoriteView.setIcon("ci-favorite-filled");
				}
			});
		};

		/**
				 * @instance
				 * @memberof RecentCase
				 * @method loadRecentCaseFavorites
				 * @desc Set the favorite case icons to filled
				 */
		this.constructor.prototype.loadRecentCaseFavorites = function loadRecentCaseFavorites(favoriteView, targetView) {
			var item = this._proto._getFavoriteCase(this, targetView);
			var view = this;

			this.context.options.favorites.get("value").items.forEach(function (favorite) {
				if (view._proto._getOrderId(item) === favorite) {
					favoriteView.setLabel(bpmext.localization.formatMsg("workplace", "favoriteFilled"));
					favoriteView.setIcon("ci-favorite-filled");
				}
			});
		};

		/**
				 * @instance
				 * @memberof RecentWorkstream
				 * @method manageFavorites
				 * @desc Add workstream to favorites list when selected and remove when deselected
				 */
		this.constructor.prototype.manageRecentFavorites = function manageRecentFavorites(label, targetView, event) {
			event.stopImmediatePropagation();
			var item = this._proto._getFavorite(this, targetView);
			var view = this;

			var favoritesList = this.context.options.favorites.get("value").items;
			if (label === bpmext.localization.formatMsg("workplace", "favorite")) {
				var newList = favoritesList.filter(function (favorite) {
					return view._proto._getOrderId(item) !== favorite;
				});
				this.context.options.favorites.set("value", newList);
			} else {
				favoritesList.push(view._proto._getOrderId(item));
				this.context.options.favorites.set("value", favoritesList);
			}
		};

		/**
				 * @instance
				 * @memberof RecentCase
				 * @method manageRecentCaseFavorites
				 * @desc Add case to favorites list when selected and remove when deselected
				 */
		this.constructor.prototype.manageRecentCaseFavorites = function manageRecentCaseFavorites(label, targetView, event) {
			event.stopImmediatePropagation();
			var item = this._proto._getFavoriteCase(this, targetView);
			var view = this;

			var favoritesList = this.context.options.favorites.get("value").items;
			if (label === bpmext.localization.formatMsg("workplace", "favorite")) {
				var newList = favoritesList.filter(function (favorite) {
					return view._proto._getOrderId(item) !== favorite;
				});
				this.context.options.favorites.set("value", newList);
			} else {
				favoritesList.push(view._proto._getOrderId(item));
				this.context.options.favorites.set("value", favoritesList);
			}
		};

		this.constructor.prototype.setPanelOptions = function setPanelOptions(title, subtitle) {
			this._instance.MODAL_OPTIONS = {
				title: title,
				subtitle: subtitle,
				primaryBtnText: bpmext.localization.formatMsg("workplace", "next"),
				primaryBtnEvent: { method: dojo.hitch(this, this.goNext), args: null, closeOnEvtComplete: false },
				progressBarOptions: null,
				width: window.innerWidth > 700 ? ((700 / window.innerWidth) * 100 + "%") : "100%"
			};
		};

		this.constructor.prototype.setWorkflowsPanelview = function (target) {
			taskUtils.EVENTS.WORKFLOW_EXPAND.subscribe(function (eventName, eventData) {
				this._instance.buttonClicked = eventData.targetView;
				if (!target.isExpanded() && this._instance.buttonClicked === "Recent_Workflow_Expand") {
					target.expand();
				}

			}, this);

			taskUtils.EVENTS.WORKFLOW_COLLAPSE.subscribe(function (eventName, eventData) {
				this._instance.buttonClicked = eventData.targetView;
				if (target.isExpanded() && this._instance.buttonClicked === "Recent_Workflow_Collapse") {
					target.collapse();
				}
			}, this);
		};

		this.constructor.prototype.setCasePanelview = function (target) {
			taskUtils.EVENTS.CASE_EXPAND.subscribe(function (eventName, eventData) {
				this._instance.buttonClicked = eventData.targetView;
				if (!target.isExpanded() && this._instance.buttonClicked === "Recent_Case_Expand") {
					target.expand();
				}
			}, this);

			taskUtils.EVENTS.CASE_COLLAPSE.subscribe(function (eventName, eventData) {
				this._instance.buttonClicked = eventData.targetView;
				if (target.isExpanded() && this._instance.buttonClicked === "Recent_Case_Collapse") {
					target.collapse();
				}
			}, this);
		};

		/*
		Coach NG Lifecycle methods *************************************************************
		 */
		this.constructor.prototype.load = function () {
			bpmext.log.info("RecentWorkstream.load ENTER >>", this);
			var view = this, opts = this.context.options;
			if (!this.context.binding) {
				this.context.binding = bpmext.ui.substituteObject(this, "binding", "resources", {});
			}
			if (!opts.workStreams) {
				bpmext.ui.substituteConfigOption(this, "workStreams", []);
			}

			if (!opts.recentLimit) {
				bpmext.ui.substituteConfigOption(this, "recentLimit", taskUtils.DEFAULT_RECENT_NUM);
			}

			if (!opts.hideProcesses) {
				bpmext.ui.substituteConfigOption(this, "hideProcesses", false);
			}

			if (!opts.hideServices) {
				bpmext.ui.substituteConfigOption(this, "hideServices", false);
			}

			if (opts.hideProcesses.get("value")) {
				view._instance.hideProcesses = true;
			}
			if (opts.hideServices.get("value")) {
				view._instance.hideServices = true;
			}
			if (!opts.favorites) {
				bpmext.ui.substituteConfigOption(this, "favorites", []);
			}

			view._instance.recentLimit = opts.recentLimit.get("value");

			this._instance.collapseCases = bpmext.ui.getContainer("Collapsible_PanelCases", this);
			this._instance.NoRecentsWorkflowsFound = bpmext.ui.getContainer("NoRecentsWorkflowVL", view);
			this._instance.NoRecentsWorkflowImage = bpmext.ui.getView("NoRecentsWorkflowImage", view);
			this._instance.NoRecentCasesFound = bpmext.ui.getContainer("NoRecentsCaseVL", view);
			this._instance.NoRecentsCaseImage = bpmext.ui.getView("NoRecentsCaseImage", view);
			this._instance.cpanelCV = bpmext.ui.getContainer("RecentWorkstreamPanel", this);
			this._instance.recentCasePanel = bpmext.ui.getContainer("RecentCasePanel", this);
			this._instance.workstreamsCV = bpmext.ui.getContainer("WorkstreamsVL", this);
			this._instance.caseCV = bpmext.ui.getContainer("CaseVL", this);
			this._instance.recentsLabel = bpmext.ui.getView("RecentWorkstreamsLabel", this);
			this._instance.recentsLabel._instance.outputText.setAttribute("role", "heading");
			this._instance.recentsLabel._instance.outputText.setAttribute("aria-level", "3");
			this._instance.recentsCaseLabel = bpmext.ui.getView("RecentCaseLabel", this);
			this._instance.recentsCaseLabel._instance.outputText.setAttribute("role", "heading");
			this._instance.recentsCaseLabel._instance.outputText.setAttribute("aria-level", "3");
			this._instance.allCV = view.ui.getSibling("Launch_list");
			this._instance.needRefresh = true;

			taskUtils.EVENTS.OPEN_RECENT.subscribe(function () {
				var subtitle, title;
				this._instance.allCV = view.ui.getSibling("Launch_list");
				if (this._instance.needRefresh) {
					this._instance.needRefresh = false;
					view._instance.allCV.generateRecent(view._instance.allCV._instance.allWorkstreams, view);
				} else {
					view._proto._updateData(view, view._instance.recentList);
				}
				this._instance.selectedWorkstream = null;
				this._proto._setPrimaryButton(this);
				taskUtils.EVENTS.LOAD_STACK_PANE.publish({ targetView: this.context.viewid });
				this._instance.firstWorkflowLoad = true;

				taskUtils.EVENTS.TAB_TITLE.subscribe(function (eventName, eventData) {
					this._instance.buttonClicked = eventData.targetView;
					if (this._instance.buttonClicked === "Workflow_Recent_Title") {
						if (view._instance.allCV._instance.allExposedItem.configurableWorkstream.itemID === taskUtils.CONFIGURABLE_WORKSTREAM_PROCESS_ID) {
							subtitle = bpmext.localization.formatMsg("ConfigPanel", "subtitle");
						} else {
							subtitle = bpmext.localization.formatMsg("ConfigPanel", "noWorkstreamSubtitle");
						}
						title = bpmext.localization.formatMsg("ConfigPanel", "title");
						this.setPanelOptions(title, subtitle);
					} else if (this._instance.buttonClicked === "Case_Recent_Title") {
						subtitle = bpmext.localization.formatMsg("ConfigPanel", "caseSubtitle");
						title = bpmext.localization.formatMsg("ConfigPanel", "caseTitle");
						this.setPanelOptions(title, subtitle);
					}
				}, this);
			}, this);

			taskUtils.EVENTS.TAB_TITLE.subscribe(function (eventName, eventData) {
				this._instance.buttonClicked = eventData.targetView;
			}, this);

			taskUtils.EVENTS.WORKSTREAM_LAUNCHED.subscribe(function (eventName, data) {
				view._proto._updateRecentList(data.item, data.instance, data.view);
			});

			taskUtils.EVENTS.WORKFLOW_EXPAND.subscribe(function (eventName, eventData) {
				this._instance.buttonClicked = eventData.targetView;
			}, this);

			taskUtils.EVENTS.CASE_EXPAND.subscribe(function (eventName, eventData) {
				this._instance.buttonClicked = eventData.targetView;
			}, this);

			taskUtils.EVENTS.CASE_COLLAPSE.subscribe(function (eventName, eventData) {
				this._instance.buttonClicked = eventData.targetView;
			}, this);

			taskUtils.EVENTS.WORKFLOW_COLLAPSE.subscribe(function (eventName, eventData) {
				this._instance.buttonClicked = eventData.targetView;
			}, this);

			bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONPROCESS_LAUNCHED, "resources");
			bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONSERVICE_LAUNCHED, "resources");
			bpmext.ui.registerEventHandlingFunction(view, view._proto.EVT_ONTEAM_LAUNCHED, "resources");

			// refresh launch list
			taskUtils.EVENTS.PROCESSES_UPDATING.subscribe(this.refresh, this);
			taskUtils.EVENTS.PROCESSES_UPDATED.subscribe(this.refresh, this);
			taskUtils.EVENTS.FORCED_REFRESH.subscribe(this.refresh, this);

			this.loadContainer(this);

			bpmext.log.info("RecentWorkstream.load EXIT >>", this);
		};

		this.constructor.prototype.view = function () {
			try {
				utilities.handleVisibility(this.context);
			}
			catch (e) {
				//{#feature: US-1330 Added RT localization}
				//bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
				bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
				if (e.stack) {
					//{#feature: US-1330 Added RT localization}
					//bpmext.log.error("  Call stack: " + e.stack);
					bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
				}
			}
		};

		this.constructor.prototype.change = function (event) {
			bpmext.log.info("RecentWorkstream.change ENTER >> (event): " + event, this);
			if (event.type === "config") {
				switch (event.property) {
					case "_metadata.visibility": {
						this.view();
						break;
					}
				}
			}
			bpmext.log.info("RecentWorkstream.change EXIT >>", this);
		};

		this.constructor.prototype.unload = function () {
			bpmext.ui.unloadView(this);
		};
	}
};