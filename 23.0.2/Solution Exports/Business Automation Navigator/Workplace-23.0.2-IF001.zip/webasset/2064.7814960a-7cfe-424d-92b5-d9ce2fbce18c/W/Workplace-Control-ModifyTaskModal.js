/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2023. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
 /**
 * @ignore
 * @instance
 * @memberof ModifyTaskModal
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof ModifyTaskModal
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof ModifyTaskModal
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof ModifyTaskModal
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof ModifyTaskModal
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof ModifyTaskModal
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof ModifyTaskModal
 * @method triggerFormulaUpdates
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 * </table>
 */
workplace_control_InitModifyTaskModal = function (utilities, taskUtils, wpResources, domAttr)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            _loadModal: function _loadModal(view) {
                bpmext.log.info("ModifyTaskModal._loadModal LOG >> ", view);
                this._setTaskInfo(view);//sets ui
                this._setItemVisible(view);//check permission to hide ui
            },
            _setTaskInfo: function _setTaskInfo(view) {
                bpmext.log.info("ModifyTaskModal._setTaskInfo LOG >> ", view);
                // Set due date
                view._instance.dueDateTimePicker.clear(); // remove any value to clear validation errors
                view._instance.dueDateTimePicker.setDate(new Date(view._instance.task.dueTime));

                // Set priority
                view._instance.prioritySelector.setSelectedItem(view._instance.task.priority);

                // Set task assignment
                view._instance.userTypeAheadText.setText("");
                view._instance.userCheckbox.setChecked(false);
                view._instance.teamCheckbox.setChecked(false);
                
                if(this._hasAction(view, "ACTION_REASSIGNTOUSER")) {
                	view._instance.userCheckbox.setVisible(true, true);
                	this._getFilteredUser(view);//get list of user this task can be assigned to
                } else {
                	view._instance.userCheckbox.setVisible(false, true);
                }
                
                if(view._instance.task.assignedToType===taskUtils.ASSIGNED_TO_TYPE.USER) {
                    //When task is assigned to user, need show back to team controls and assign to user controls
                    //view._instance.userCheckbox.setVisible(false, true);
                    view._instance.statusLabel.setText(bpmext.localization.formatMsg("modifyTaskModal", "assignedToUser") +" "+ view._instance.task.assignedToDisplayName);
                    
                    if(this._hasAction(view, "ACTION_CANCELCLAIM")) {
                    	view._instance.teamCheckbox.setVisible(true, true);
                    } else {
                    	view._instance.teamCheckbox.setVisible(false, true);
                    }
                } else {
                    //When task is assigned to group only show assign to user controls
                    view._instance.teamCheckbox.setVisible(false, true);
                    view._instance.statusLabel.setText(bpmext.localization.formatMsg("modifyTaskModal", "assignedToGroup"));
                }
            },
            _getFilteredUser: function _getFilteredUser(view) {
                bpmext.log.info("ModifyTaskModal._getFilteredUser LOG >>", view);
                try {
                    var taskId = view._instance.task.tkiid,
                        systemID = view._instance.task.systemID;
                    wpResources.users.get({assignTaskidFilter: taskId, includeFilter: "activeOnly", systemID: systemID})
                        .then(dojo.hitch(view, function(users) {
                            if (users.length>0) {
                                var userList=[], fullNameList = [];
                                for(var i = 0; i < users.length; i++){
                                    userList.push(users[i].fullName + " (" + users[i].userName + ")");
//                                  fullNameList.push(users[i].fullName);
                                }
                                this._instance.validUsers = userList;

                                this._instance.userTypeAheadText.context.options.itemList.set("value", userList);
//                                this._instance.userTypeAheadText.context.options.displayItemList.set("value", fullNameList);
                            }else{
                                this._instance.userCheckbox.setVisible(false, true);
                            }
                        }));
                } catch (error) {
                    bpmext.log.error(error.message);
                }
            },

            _hasAction: function _hasAction(view, action) {
        		return view._instance.availableActions && view._instance.availableActions.indexOf(action)!==-1;
        	},

            _setItemVisible: function _setItemVisible(view) {
                bpmext.log.info("ModifyTaskModal._setItemVisible LOG >>", view);
                var permission = view._instance.modifyTask;
                if(permission.any){
                    if(!permission.due || !this._hasAction(view, "ACTION_UPDATEDUEDATE")) {
                        view._instance.dueDateTimePicker.setVisible(false, true);
                    } else {
                        view._instance.dueDateTimePicker.setVisible(true, true);
                    }
                    if(!permission.priority || !this._hasAction(view, "ACTION_UPDATEPRIORITY")) {
                        view._instance.prioritySelector.setVisible(false, true);
                    } else {
                        view._instance.prioritySelector.setVisible(true, true);
                    }
                    if(!permission.reassign || !(this._hasAction(view, "ACTION_REASSIGNTOUSER") || this._hasAction(view, "ACTION_CANCELCLAIM"))) {
                        view._instance.taskAssignmentPanel.setVisible(false, true);
                    } else {
                        view._instance.taskAssignmentPanel.setVisible(true, true);
                    }
                } else {
                    view.hide();
                }
            },

            _hideModel: function _hideModel(view){
                bpmext.log.info("ModifyTaskModal._hideModel LOG >>", view);
                view._instance.modalSection.setVisible(false);
                view.setVisible(false, true);
            },

            _validateTypeAhead: function _validateTypeAhead(view, userName, validUsers) {
                bpmext.log.info("ModifyTaskModal._validateTypeAhead LOG >>", view);
                var message, isValidUsername = true;
                if(view._instance.userCheckbox.isChecked()){
                    if (!userName) {
                        isValidUsername = false;
                        message = "userCannotBeEmpty";
                    } else {
                        isValidUsername = (validUsers || []).indexOf(userName) > -1;
                        message = "userNotInTeam";
                    }
                    view._instance.userTypeAheadText.setValid(isValidUsername, bpmext.localization.formatMsg("modifyTaskModal", message));
                }
                return isValidUsername;
            },

            _updateDate: function _updateDate(view, newDate) {
                return wpResources.task.setDueDate({tkiid: view._instance.task.tkiid, dueDate: newDate, systemID: view._instance.task.systemID});
            },

            _updatePriority: function _updatePriority(view, newPriority) {
                return wpResources.task.setPriority({tkiid: view._instance.task.tkiid, priority: newPriority, systemID: view._instance.task.systemID});
            },

            _assignBackToGroup: function _assignBackToGroup(view) {
                return wpResources.task.assignBackToGroup(view._instance.task);
            },

            _assignToUser: function _assignToUser(view, newUser) {
                return wpResources.task.assignToUser({tkiid: view._instance.task.tkiid, username: newUser, systemID: view._instance.task.systemID});
            },

            _postTaskInfo: function _postTaskInfo(view) {
                bpmext.log.info("ModifyTaskModal._postTaskInfo LOG >>", view);
                try {
                    var currentPriority, newPriority, currentDate, newDate, newUser;
                    var dateChanged = false, priorityChanged = false, sentBackToGroup = false, assignedUser = false;
                    //Find Delta
                    if(view._instance.dueDateTimePicker.isVisible()){
                        currentDate = new Date(view._instance.task.dueTime);
                        newDate = view._instance.dueDateTimePicker.getDate();
                        if(currentDate.getTime() !== newDate.getTime()){
                            dateChanged = true;
                        }
                    }
                    if(view._instance.prioritySelector.isVisible()){
                        currentPriority = view._instance.task.priority.toString();
                        newPriority = view._instance.prioritySelector.getData().toString();
                        if(currentPriority !== newPriority){
                            priorityChanged = true;
                        }
                    }
                    if(view._instance.teamCheckbox.isVisible() && view._instance.teamCheckbox.isChecked()){
                        sentBackToGroup = true;           
                    } else if(view._instance.userCheckbox.isVisible() && view._instance.userCheckbox.isChecked()){
                        newUser = view._instance.userTypeAheadText.getData();
                        if(newUser){
                            assignedUser = true;
                            if (newUser.lastIndexOf('(') != -1 && newUser.lastIndexOf('(') != newUser.length-1){
                                newUser = newUser.substring(newUser.lastIndexOf('(')+1, newUser.lastIndexOf(')'));
                            }
                        }
                    }
                    //Synchronous updates
                    var updateTask = function (view, newDate, newPriority, dateChanged, priorityChanged, sentBackToGroup) {
                        if(dateChanged && priorityChanged){
                            view._proto._updateDate(view, newDate).then(function(){
                                view._proto._updatePriority(view, newPriority);
                            });
                        } else if(dateChanged){
                            view._proto._updateDate(view, newDate);
                        } else if(priorityChanged){
                            view._proto._updatePriority(view, newPriority);
                        }
                        //Close TaskViewer when sending back to team
                        if(sentBackToGroup){
                            taskUtils.EVENTS.CLOSE_TASK_VIEWER.publish();
                        }
                    };

                    //Synchronous assignment and updates
                    if(sentBackToGroup){
                        view._proto._assignBackToGroup(view).then(function(){
                            updateTask(view, newDate, newPriority, dateChanged, priorityChanged, sentBackToGroup, assignedUser);
                        });
                    }else if(assignedUser){
                        view._proto._assignToUser(view, newUser).then(function(){
                            updateTask(view, newDate, newPriority, dateChanged, priorityChanged, sentBackToGroup, assignedUser);
                        });
                    }else{
                        updateTask(view, newDate, newPriority, dateChanged, priorityChanged, sentBackToGroup, assignedUser);
                    }
                } catch (error) {
                    bpmext.log.error(error.message);
                }
            }
        };


        /*
        Public control methods *************************************************************
         */

         /**
		 * @instance
		 * @memberof ModifyTaskModal
		 * @method closeModal
		 * @desc Closes the modal dialog
		 */
        this.constructor.prototype.closeModal = function() {
			bpmext.log.info("ModifyTaskModal.closeModal ENTER >> ",this);
			this._proto._hideModel(this);
			bpmext.log.info("ModifyTaskModal.closeModal EXIT << ");
        };

         /**
		 * @instance
		 * @memberof ModifyTaskModal
		 * @method onClose
		 * @desc closes open dialogs
		 */
        this.constructor.prototype.onClose = function() {
            this._instance.dueDateTimePicker.close();
        };

         /**
		 * @instance
		 * @memberof ModifyTaskModal
		 * @method saveModal
		 * @desc Saves the data on the dialog
		 */
        this.constructor.prototype.saveModal = function() {
            bpmext.log.info("ModifyTaskModal.saveModal ENTER >> ", this);
            //Before saving check if date and assigned user is valid
            if(this.validateInput()){
                this._proto._postTaskInfo(this);
                this.closeModal();
            }
			bpmext.log.info("ModifyTaskModal.saveModal EXIT << ");
        };

         /**
		 * @instance
		 * @memberof ModifyTaskModal
		 * @method toggleUserTypeAhead
		 * @desc Controls the visibility of the user type-ahead box and the save button
		 */
        this.constructor.prototype.toggleUserTypeAhead = function() {
            bpmext.log.info("ModifyTaskModal.toggleUserTypeAhead ENTER >> ", this);
            //hide or show user type ahead if assigned to user checkbox is unchecked or checked
            this._instance.userTypeAheadText.setVisible(this._instance.userCheckbox.isChecked(), true);
            //check the if user type ahead is empty, if empty then disable save button
            this.validateInput();
			bpmext.log.info("ModifyTaskModal.toggleUserTypeAhead EXIT << ");
        };

         /**
		 * @instance
		 * @memberof ModifyTaskModal
		 * @method validateInput
         * @returns {Boolean} the boolean value for the validity of the date time picker value
		 * @desc Controls the visibility of date picker and enables or disables the save button
		 */
        this.constructor.prototype.validateInput = function() {
            bpmext.log.info("ModifyTaskModal.validateInput ENTER >> ", this);
            var valid = false, validDate = false;
            //Only enable save button if there is a valid date
            validDate = this._instance.dueDateTimePicker.getDate() && this._instance.dueDateTimePicker.isValid();
            var newUser = this._instance.userTypeAheadText.getData();
            valid = validDate && this._proto._validateTypeAhead(this, newUser, this._instance.validUsers);
            this._instance.modalSection.setPrimaryButtonEnabled(!!valid);

			bpmext.log.info("ModifyTaskModal.validateInput EXIT << ");
            return valid;
        };

        /**
		 * @instance
		 * @memberof ModifyTaskModal
		 * @method toggleCheckbox
		 * @desc Controls the checkbox selection
		 */
        this.constructor.prototype.toggleCheckbox = function(target) {
            bpmext.log.info("ModifyTaskModal.toggleCheckbox ENTER >> ", this);
            if(target.isChecked()){
                if (target == this._instance.userCheckbox){
                    this._instance.teamCheckbox.setChecked(!target.isChecked())
                }else{
                    this._instance.userCheckbox.setChecked(!target.isChecked())
                }
            }

			bpmext.log.info("ModifyTaskModal.toggleCheckbox EXIT << ");
        };
        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function (){
            bpmext.log.info("ModifyTaskModal.load ENTER >>", this);

            var view = this;
            this._instance.modalSection = bpmext.ui.getContainer("ModalSection", this);
            this._instance.modalSection.setPrimaryButtonText(bpmext.localization.formatMsg("modifyTaskModal", "save"));
            this._instance.modalSection.setSecondaryButtonText(bpmext.localization.formatMsg("modifyTaskModal", "cancel"));
            //CV in ModalSection
            this._instance.panel = bpmext.ui.getContainer("Panel", this);
            //CV in Panel
            this._instance.dueDateTimePicker = bpmext.ui.getView("DueDateTimePicker", this);
            this._instance.prioritySelector = bpmext.ui.getView("PrioritySelector", this);
            this._instance.statusLabel = bpmext.ui.getView("StatusLabel", this);
            this._instance.taskAssignmentPanel = bpmext.ui.getContainer("TaskAssignmentPanel", this);
            //CV in TaskAssignmentPanel
            this._instance.userCheckbox = bpmext.ui.getView("UserCheckbox", this);
            this._instance.userTypeAheadText = bpmext.ui.getView("UserTypeAheadText", this);
            this._instance.teamCheckbox = bpmext.ui.getView("TeamCheckbox", this);
            //Assign labels and texts to controls
            this._instance.modalSection._instance.modalDialog.ariaLabel = bpmext.localization.formatMsg("modifyTaskModal", "modifyTask");
            this._instance.panel.setTitle(bpmext.localization.formatMsg("modifyTaskModal", "modifyTask"));
            this._instance.dueDateTimePicker.setLabel(taskUtils.getLabelFromTaskProperty("taskDueDate"));
            this._instance.prioritySelector.setLabel(taskUtils.getLabelFromTaskProperty("taskPriority"));
            this._instance.statusLabel.setLabel(bpmext.localization.formatMsg("modifyTaskModal", "taskAssignment"));
            this._instance.userCheckbox.setLabel(bpmext.localization.formatMsg("modifyTaskModal", "assignToUser"));
            this._instance.teamCheckbox.setLabel(bpmext.localization.formatMsg("modifyTaskModal", "assignToGroup"));
            this._instance.userTypeAheadText.setPlaceholder(bpmext.localization.formatMsg("modifyTaskModal", "userTypeAheadPlaceholder"));
           //Add item for single select
            for(var priorityLevel in taskUtils.PRIORITY){
                var priorityLevelValue = taskUtils.PRIORITY[priorityLevel];
                this._instance.prioritySelector.appendItem( priorityLevelValue, taskUtils.getPriorityLabel(priorityLevelValue));
            }

            var panelHeaderIcon = this._instance.panel.context.element.querySelector("div.panel-heading-controls > div.panel-heading-icon > i");
            !!panelHeaderIcon && domAttr.remove(panelHeaderIcon, "tabindex");

            this._instance.dueDateInput = this._instance.dueDateTimePicker.context.element.querySelector("input");
            this._instance.userInput = this._instance.userTypeAheadText.context.element.querySelector("input");

            //Defect 345431 to prevent save button from active when due date is being modified
            var validationHandler = function(){
                view.validateInput();
            };

            //Defect 345431 to prevent save button from active when user name is being modified
            this._instance.dueDateInput.onfocus = validationHandler;
            this._instance.dueDateInput.onblur  = validationHandler;
            this._instance.userInput.onfocus = validationHandler;
            this._instance.userInput.onblur  = validationHandler;

            taskUtils.EVENTS.MODIFY_TASK.subscribe(function(eventName, eventData){
                if(eventData.view.ui.getParent() === this.ui.getParent()){
                    this._instance.task = eventData.task;
                    this._instance.modifyTask = eventData.canUserModifyTask;
                    this._instance.availableActions = eventData.task.actions;
                    this._proto._loadModal(this);
                    // Show modify task modal
                    this._instance.modalSection.show();
                    this.show();
                    taskUtils.setTabCycle(this);
                }
                // Get task stats
			}, this);

            this.loadContainer(this);

            bpmext.log.info("ModifyTaskModal.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try {
                utilities.handleVisibility(this.context);
            }
            catch (e){
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e, this);
                if(e.stack) {
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack), this);
                }
            }
        };

        this.constructor.prototype.change = function (event){
            bpmext.log.info("ModifyTaskModal.change ENTER >> (event): " + event, this);
            bpmext.log.info("ModifyTaskModal.change ENTER >>", this);
        };

        this.constructor.prototype.unload = function (){
            bpmext.log.info("ModifyTaskModal.unload ENTER >> ", this);
            bpmext.ui.unloadContainer(this);
            bpmext.log.info("ModifyTaskModal.unload ENTER >>", this);
        };
    }
};