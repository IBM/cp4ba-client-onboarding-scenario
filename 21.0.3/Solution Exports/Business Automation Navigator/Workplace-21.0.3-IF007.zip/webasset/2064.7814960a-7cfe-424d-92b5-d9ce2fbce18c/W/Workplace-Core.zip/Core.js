/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
(function(){-1!==document.location.href.indexOf("mode\x3ddeveloper")&&(dojoConfig.isDeveloperMode=!0);var a=dojoConfig.isDebug?"Workplace-Core-Orig.zip":"Workplace-Core.zip",a=dojoConfig.isDeveloperMode?"../../../../../workplace/files/Core":com_ibm_bpm_coach.getManagedAssetUrl(a,com_ibm_bpm_coach.assetType_WEB,"SYSWPT");require({packages:[{name:"com.ibm.bpm.workplace.localization",location:a+"/com/ibm/bpm/workplace/localization"},{name:"com.ibm.bpm.workplace.resources",location:a+"/com/ibm/bpm/workplace/resource",
main:"WPResources"},{name:"com.ibm.bpm.workplace.core",location:a}]},[],function(){document.querySelector("html")&&(console.debug("Initializing Workplace Core"),require(["com.ibm.bpm.workplace.localization"],function(a){a.initMessages(null)}),require(["com.ibm.bpm.workplace.resources"],function(a){require(["com.ibm.bpm.workplace.resources/resourceBase"],function(c){c.isAppEngine||a.config.get().then(function(a){if(a.walkme.enable){var b=document.createElement("script");b.type="text/javascript";b.async=
!0;b.src=a.walkme.url;a=document.getElementsByTagName("script")[0];a.parentNode.insertBefore(b,a);window._walkmeConfig={smartLoad:!0}}})})}))})})();