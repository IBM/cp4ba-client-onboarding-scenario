/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define([],function(){function k(a){return/\s/.test(a)?"w":/\d/.test(a)?"d":a===a.toUpperCase()?a===a.toLowerCase()?"n":"u":a===a.toLowerCase()?"l":"n"}return{compose:function(a){return function(b){return(a||[]).reduce(function(a,b,f){return b.apply(b,0<f?[a]:a)},b)}},composeMap:function(a){return function(b){a.length&&1>a.length||a.map(function(a){return a.apply(a,b)})}},getAbbreviation:function(a){a=a||"";0>a.indexOf(" ")&&(a=a.replace(/([a-z0-9])([A-Z])/g,"$1 $2"));return a.toLocaleUpperCase().split(" ").reduce(function(a,
c){return 3>a.length?a+c[0]:a},"")},safeGet:function(a,b){return b.reduce(function(a,b){return a&&a[b]},a)},formatDate:function(a,b){"string"===typeof a&&(a=new Date(a));var c={dateStyle:"medium"};b&&(c.timeStyle="short");return a.toLocaleString(dojo.locale,c)},hasDatePassed:function(a){"string"===typeof a&&(a=new Date(a));return a<new Date},getDaysUntil:function(a){function b(a){"string"===typeof a&&(a=new Date(a));return new Date(a.toDateString())}"string"===typeof a&&(a=new Date(a));return Math.round((b(a).getTime()-
b(new Date).getTime())/864E5)},getLabelFromID:function(a){var b=0;a=a.replace(/_/g," ").trim();var c,e,f,g,h,d="";if(0<a.length)for(c=a.charAt(b++),e=k(c);c;)b<a.length?(g=a.charAt(b++),h=k(g)):h=g=void 0,"w"!==e&&("d"===e?(f&&"d"!==f&&(d+=" "),d+=c):"w"===f||void 0===f?("w"===f&&(d+=" "),d="l"===e?d+c.toUpperCase():d+c):d="u"!==e||"u"===f&&"l"!==h?d+c:d+(" "+c)),f=e,c=g,e=h;return d},throttleTrailingEdge:function(a,b){var c=!0;return function(){var e=arguments;c&&(c=!1,setTimeout(function(){c=!0;
a.apply(null,e)},b))}}}});