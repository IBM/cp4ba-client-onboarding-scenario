/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define("com.ibm.bpm.workplace.resources/TasksResource", ["./resourceBase"], function(resource) {
    "use strict";
    var ROUTE = resource._buildUrl("${urlPrefix}/v1/tasks", {
            urlPrefix: resource.contextRoot.federatedURL || resource.contextRoot.rest
        }),
        NAMESPACE_GET_ALL = "TASKS_GET_ALL",
        INTERACTION = {
            ALL: "all",
            CLAIMED: "claimed",
            AVAILABLE: "available",
            COMPLETED: "completed",
            CLAIMED_AND_AVAILABLE: "claimed_and_available"
        },
        SORT_BY = {
            /**
             * Create an Ascending sort Operator object
             *
             * @param {String} field - name of the field to apply the sort order to
             */
            ASCENDING: function ASCENDING(field) {
                return { order: "ASC", field: "" + field };
            },
            /**
             * Create a Descending sort Operator object
             *
             * @param {String} field - name of the field to apply the sort order to
             */
            DESCENDING: function DESCENDING(field) {
                return { order: "DESC", field: "" + field };
            }
        },
        ORGANIZATION = {
            BY_TASK: "byTask",
            BY_INSTANCE: "byInstance"
        },
        OPERATOR = {
            /**
             * Create Equals (==) operator object
             *
             * @param {String} field - name of the field, this is the left hand side of the operator
             * @param {String} value - value to apply operator on
             */
            EQUALS: function EQUALS(field, value) {
                return { operator: "Equals", field: "" + field, value: "" + value };
            },
            /**
             * Create Not Equals (!=) operator object
             *
             * @param {String} field - name of the field, this is the left hand side of the operator
             * @param {String} value - value to apply operator on
             */
            NOT_EQUALS: function NOT_EQUALS(field, value) {
                return { operator: "NotEquals", field: "" + field, value: "" + value };
            },
            /**
             * Create Contains operator object
             *
             * @param {String} field - name of the field, this is the left hand side of the operator
             * @param {String} value - value to apply operator on
             */
            CONTAINS: function CONTAINS(field, value) {
                return { operator: "Contains", field: "" + field, value: "" + value };
            },
            /**
             * Create Starts With operator object
             *
             * @param {String} field - name of the field, this is the left hand side of the operator
             * @param {String} value - value to apply operator on
             */
            STARTS_WITH: function STARTS_WITH(field, value) {
                return { operator: "StartsWith", field: "" + field, value: "" + value };
            },
            /**
             * Create Equals (<) operator object
             *
             * @param {String} field - name of the field, this is the left hand side of the operator
             * @param {String} value - value to apply operator on
             */
            LESS_THAN: function LESS_THAN(field, value) {
                return { operator: "LessThan", field: "" + field, value: "" + value };
            },
            /**
             * Create Equals (>) operator object
             *
             * @param {String} field - name of the field, this is the left hand side of the operator
             * @param {String} value - value to apply operator on
             */
            GREATER_THAN: function GREATER_THAN(field, value) {
                return { operator: "GreaterThan", field: "" + field, value: "" + value };
            },
            /**
             * Create Full Search operator object
             *
             * @param {String} value - value to use for full search
             */
            FULL_TEXT_SEARCH: function FULL_TEXT_SEARCH(value) {
                return { operator: "FullTextSearch", value: "" + value };
            }
        },
        ALIAS = function ALIAS(field, alias) {
            return { field: "" + field, alias: "" + alias };
        },
        DEFAULT_SIZE = resource.DEFAULT_TASK_LIST_SIZE,
        KIND = "KIND",
        KIND_COMMENT = "KIND_COMMENT";

    // add pseudo operators
    OPERATOR.BEFORE = OPERATOR.LESS_THAN;
    OPERATOR.AFTER = OPERATOR.GREATER_THAN;

    /**
     * Retrieve a list of task instance entities via a query or a specified saved search.
     * @param {Object} [options] - optional params to pass to the API
     * @param {Number} [options.size] - number of items to return
     * @param {Boolean} [options.calcStats] - true to return result statistics, default is true
     * @param {Number} [options.offset] - offset is calculated via [options.offset] x [options.size]
     * @param {Number} [options.id] - id of the saved search. Must be numeric
     * @param {String} [options.name] - alphanumeric name of the saved search
     * @param {String[]} [options.fields] - list of fields to include in the result of the search
     * @param {String} [options.organization] - Grouping of the results. Default is #ORGANIZATION.BY_TASK See #ORGANIZATION
     * @param {Boolean} [options.shared] - true if the search is to be shared, default is false
     * @param {Object[]} [options.teams] - list of teams to share the saved search with
     * @param {String} [options.interaction] - type of interaction of this query. Default is #INTERACTION.CLAIMED_AND_AVAILABLE, See #INTERACTION
     * @param {Object[]} [options.conditions] - list of conditions to define the search query. You can use the Operators from #OPERATORS
     * @param {Object[]} [options.sort] - list of columns to sort by. You can use the operators from the #SORT_BY
     * @param {Object[]} [options.aliases] - list of fields and their aliases. you can use #ALIAS to generate the alias objects
     *
     * @returns {Promise} Promise that resolves to results of running the saved search
     */
    function get(options) {
        var url = ROUTE,
            query = {},
            data = {};

        // prepare query params
        query = {
            calcStats: (options && options.calcStats) || true,
            size: (options && options.size) || DEFAULT_SIZE
        };
        if (options && options.offset) {
            query.offset = parseInt(options.offset) * query.size;
        }

        // prepare data params
        data = {
            size: query.size,
            id: (options && options.id) || 0,
            name: (options && options.name) || "",
            fields: (options && options.fields) || [],
            organization: (options && options.organization) || ORGANIZATION.BY_TASK,
            shared: options && options.shared === true,
            teams: (options && options.teams) || [],
            interaction: (options && options.interaction) || INTERACTION.CLAIMED_AND_AVAILABLE,
            conditions: (options && options.conditions) || [],
            sort: (options && options.sort) || [],
            aliases: (options && options.aliases) || []
        };

        return resource
            .put(url, {
                query: query,
                data: JSON.stringify(data) // data needs to be a string to bypass dojo's objectToQuery
            })
            .then(
                function success(res) {
                    var retData = resource.isFederated ? res : res.data;
                    //strip out non-participating tasks (ie comments)
                    if (options.includeAllTaskKinds !== true && retData.items) {
                        retData.items = retData.items.filter(function(item) {
                            return (item[KIND] !== KIND_COMMENT);
                        });
                    }

                    if(options.skipPublish !== true) {
                        resource.cbr.notifyNamespace({ namespace: NAMESPACE_GET_ALL }, retData);
                    }
                    return retData;
                },
                function error(err) {
                    if (err && err.response && err.response.data) {
                        var data = err.response.data.Data || err.response.data;
                        if (data.exceptionType === "com.ibm.bpm.wle.api.TooManyPotentialSearchResultsException") {
                            resource.showError(bpmext.localization.formatMsg("Errors", "tooManyResultsError"), err);
                        } else if (data.exceptionType === "com.ibm.bpm.wle.api.InvalidQuerySearchFilterException") {
                            resource.showError(bpmext.localization.formatMsg("Errors", "invalidQuerySearchFilterError"), err);
                        } else {
                            resource.showError(data.errorMessage || data.message, err);
                        }
                    }
                    resource.cbr.notifyNamespace({ namespace: NAMESPACE_GET_ALL, failure: true }, err);
                    throw err;
                }
            );
    }

    get.register = function register(context, successCallback, errorCallback) {
        return resource.cbr.addCallback(NAMESPACE_GET_ALL, {context: context, success: successCallback, failure: errorCallback});
    };

    get.default_size = DEFAULT_SIZE;

    //module.exports
    return {
        get: get,
        INTERACTION: INTERACTION,
        SORT_BY: SORT_BY,
        ORGANIZATION: ORGANIZATION,
        OPERATOR: OPERATOR,
        ALIAS: ALIAS
    };
});
