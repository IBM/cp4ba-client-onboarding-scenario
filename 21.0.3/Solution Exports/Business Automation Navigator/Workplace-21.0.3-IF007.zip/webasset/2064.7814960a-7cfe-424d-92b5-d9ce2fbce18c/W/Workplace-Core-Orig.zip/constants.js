/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define([], function() {
    "use strict";
    var CONSTANTS = {};
    CONSTANTS.TYPES = {
    	PROCESS: "process",
    	SERVICE: "service",
    	CASETYPE: "casetype"
    };
    CONSTANTS.COLUMN_TYPES = {
        BOOLEAN: "Checkbox",
        TIMESTAMP: "Date",
        NUMBER: "Integer",
        LINK: "Link",
        STRING: "Text",
        DECIMAL: "Decimal"
    };

    CONSTANTS.ASSIGNED_TO_TYPE = {
        USER: "user",
        GROUP: "group"
    };

    CONSTANTS.PRIORITY = {
        LOWEST: 50,
        LOW: 40,
        NORMAL: 30,
        HIGH: 20,
        HIGHEST: 10
    };

    CONSTANTS.OPERATOR = {
        EQUALS: "Equals",
        NOT_EQUALS: "NotEquals",
        CONTAINS: "Contains",
        STARTS_WITH: "StartsWith",
        GREATER_THAN: "GreaterThan",
        LESS_THAN: "LessThan",
        FULL_TEXT_SEARCH: "FullTextSearch"
    };

    CONSTANTS.DEFAULT_SELECTED_COLUMNS = ["taskStatus", "taskPriority", "taskSubject", "taskDueDate"];

    CONSTANTS.DEFAULT_MANDATORY_COLUMNS = [
        { name: "taskStatus", value: "taskStatus" },
        { name: "taskSubject", value: "taskSubject" },
        { name: "taskDueDate", value: "taskDueDate" },
    ];

    CONSTANTS.DEFAULT_MANDATORY_INSTANCE_COLUMNS = [
        { name: "instanceCreationDate", value: "instanceCreationDate" },
        { name: "instanceDueDate", value: "instanceDueDate" },
        { name: "instanceName", value: "instanceName" },
    ];

    CONSTANTS.DEFAULT_INSTANCE_COLUMNS = ["riskState", "name", "creationDate", "dueDate"];
    CONSTANTS.DEFAULT_FEDERATED_INSTANCE_COLUMNS = ["instanceStatus", "instanceName", "instanceCreationDate", "instanceDueDate"];

    // These attribute are excluded in search filter and column selector as they are not accepted in the conditions field
    CONSTANTS.NON_SEARCHABLE_FIELDS = [
        "bpdId",
        "instanceSnapshotId",
        "assignedToRole",
        "taskNarrative",
        "taskId",
        "taskClosedBy",
        "taskSentTime",
        "taskReadTime",
        "taskReceivedFrom",
    ];
    CONSTANTS.HIDDEN_MINI_COLUMN_FIELDS = [
        "workflowApplication",
        "caseFolderId",
        "caseFolderServerName", 
        "instanceLastModifier"   
    ];
    CONSTANTS.HIDDEN_COLUMN_FIELDS = [
        "bpdId", 
        "instanceSnapshotId", 
        "assignedToRole", "taskNarrative", 
        "taskCreatedByBpdFlowObjectId", 
        "startingDocumentId", 
        "startingDocumentServerName", 
        "parentCaseId", 
        "parentActivityId", 
        "taskId", 
        "taskSentTime", 
        "taskReceivedFrom", 
        "taskActivityName", 
        "taskIsAtRisk",
        "isWorkstream",
        "taskState"
    ];
    CONSTANTS.HIDDEN_PX_COLUMN_FIELDS = CONSTANTS.HIDDEN_COLUMN_FIELDS.concat([
        "workflowApplication",
        "caseFolderId",
        "caseFolderServerName",
    ]);
    CONSTANTS.HIDDEN_INSTANCE_COLUMN_FIELDS = [
        "InstanceStatus", 
        "bpdId", 
        "assignedToRole", 
        "taskNarrative", 
        "taskCreatedByBpdFlowObjectId", 
        "instanceSnapshotId", 
        "parentActivityId", 
        "parentCaseId",
        "isWorkstream"
    ];
    CONSTANTS.HIDDEN_PX_INSTANCE_COLUMN_FIELDS = CONSTANTS.HIDDEN_INSTANCE_COLUMN_FIELDS.concat([
        "workflowApplication",
        "instanceHealth",
        "instanceStageStatus",
        "instanceLastModifier"   
    ]);

    CONSTANTS.DEFAULT_SLIDEOUT_PANEL_WIDTH = "40%";

    CONSTANTS.DEFAULT_RECENT_NUM = 5;

    CONSTANTS.DEFAULT_RETRIEVE_INSTANCES_NUM = 50;

    CONSTANTS.CONFIGURABLE_WORKSTREAM = "Configurable Workstream";
    CONSTANTS.CONFIGURABLE_WORKSTREAM_PROCESS_ID = "25.e63cfd88-de50-45e3-b9d2-8d99350e343e";
    CONSTANTS.CONFIGURATION_WIZARD = "Workstream Configuration Wizard";
    CONSTANTS.CONFIGURATION_WIZARD_CSHS_ID = "1.e89fb138-30ec-4ba8-968d-27637692da0b";
    CONSTANTS.CASEINSTANCEUICSHS = "CaseDetailPage";

    CONSTANTS.Workstream_CSHS_ITEM_ID = {
			DEFINITIONS: "1.11d4f259-27fa-4fc7-b07c-e9d918ce59e5",
			TEAMS: "1.383e9698-38d4-41d8-bf99-c62737698c51"
    };
    CONSTANTS.Workstreams_InlineTasks = [
        "1.044c9181-8d0b-4c85-b0d6-9347d394a30f" //Configure task
    ];

    CONSTANTS.COMMON_SEARCHABLEFIELDS = [
		{"name": "type", "type": "enum"},
		{"name": "creationDate", "type":"Date"},
		{"name": "lastModificationTime", "type":"Date"}
	];

    CONSTANTS.CASE_SEARCHABLEFIELDS = [
    	{"name": "createdBy", "type":"string"},
		{"name": "projectFilter", "type":"enum"},
		{"name": "caseType", "type": "enum"},
		{"name": "caseStage", "type":"enum"},
		{"name": "lastModifiedBy", "type":"string"}
    ];

    CONSTANTS.DEFAULT_THROTTLE_DURATION = 2 * 1000; // 2 seconds
    
    CONSTANTS.DEFAULT_PER_PAGE = 10;

    CONSTANTS.DEFAULT_SCOPE_FILTERS=["bpdName","instanceProcessApp", "workflowApplication"];
    CONSTANTS.DEFAULT_PX_SCOPE_FILTERS=["bpdName","instanceProcessApp"];

    return CONSTANTS;
});
