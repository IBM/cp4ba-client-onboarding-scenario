/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define([], function () {
    "use strict";
    function compose(funcs) {
        return function (args) {
            return (funcs || []).reduce(function (prev, func, idx) {
                return func.apply(func, idx > 0 ? [prev] : prev);
            }, args);
        };
    }

    function composeMap(funcs) {
        return function (args) {
            if (funcs.length && funcs.length < 1) {
                return;
            }

            funcs.map(function (func) {
                return func.apply(func, args);
            });
        };
    }

    function getAbbreviation(name) {
        name = name || "";

        // Parse camel case team name
        if (name.indexOf(" ") < 0) {
            name = name.replace(/([a-z0-9])([A-Z])/g, "$1 $2");
        }

        // Set team name abbreviation
        return name
            .toLocaleUpperCase()
            .split(" ")
            .reduce(function (abbr, word) {
                return abbr.length < 3 ? abbr + word[0] : abbr;
            }, "");
    }

    /**
     * Safely get values from a deeply nested object
     * Example:
     *  var obj1 = {
     *      a: {
     *          b: {
     *              c: [1, 2, 3, 4]
     *          }
     *      }
     *  },
     *  properPath = ["a", "b", "c", 0],
     *  invalidPath = "a.b.d.0".split(".");
     *
     *  console.log(safeGet(obj1, properPath)); => 1
     *  console.log(safeGet(obj1, invalidPath)); => undefined
     *
     * @param {Object} obj - object on which to resolve the path defined by items
     * @param {String[]} items - Array containing the elements to check for and return its value
     */
    function safeGet(obj, items) {
        return items.reduce(function (acc, i) {
            return acc && acc[i];
        }, obj);
    }

    /**
     * @param {Date | string} date
     * @return {string}
     */
    function formatDate(date, includeTime) {
        if (typeof date === "string") {
            date = new Date(date);
        }
        var options = {dateStyle: "medium"};
        if (includeTime) {
            options.timeStyle = "short";
        }
        return date.toLocaleString(dojo.locale, options);
    }

    /**
     * @param {Date | string} date
     * @return {boolean}
     */
    function hasDatePassed(date) {
        if (typeof date === "string") {
            date = new Date(date);
        }
        var now = new Date();
        return date < now;
    }

    /**
     * @param {Date | string} date
     * @return {Integer} - negative if the
     */
    function getDaysUntil(date) {
        if (typeof date === "string") {
            date = new Date(date);
        }
        function removeTime(date) {
            if (typeof date === "string") {
                date = new Date(date);
            }
            return new Date(date.toDateString());
        }
        return Math.round((removeTime(date).getTime() - removeTime(new Date()).getTime()) / (1000 * 3600 * 24));
    }

    function getCharacterType(c) {
		if (/\s/.test(c)) {
			return "w"; // whitespace
		}
		if (/\d/.test(c)) {
			return "d"; // digit
		}
		if (c === c.toUpperCase()) {
			if (c === c.toLowerCase()) {
				return "n"; // type not defined
			}
			return "u"; // uppercase
		}
		if (c === c.toLowerCase()) {
			return "l";	// lower case
		}
		return "n"; // type not defined
	}

    /**
     * This will get a nice display name based on the id passed in.
     */
    function getLabelFromID(field) {
		var i=0, work = field.replace(/_/g," ").trim(), current, currentType, beforeType, after, afterType, result = "";
		if (work.length > 0) {
			current = work.charAt(i++);
			currentType = getCharacterType(current);
			while (current) {
				if (i < work.length) {
					after = work.charAt(i++);
					afterType = getCharacterType(after);
				} else {
					after = undefined;
					afterType = undefined;
				}
				if (currentType !== "w") {
					if (currentType === "d") {
						if (beforeType && beforeType !== "d") {
							result += " ";
						}
						result += current;
					} else if ((beforeType === "w") || (beforeType === undefined)) {
						if (beforeType === "w") {
							result += " ";
						}
						if (currentType === "l") {
							result += current.toUpperCase();
						} else {
							result += current;
						}
					} else if ((currentType === "u") && ((beforeType !== "u") ||  (afterType === "l"))) {
						result += " " + current;
					} else {
						result += current;
					}

				}
				beforeType = currentType;
				current = after;
				currentType = afterType;
			}
		}
		return result;
	}


    /**
    * This will throttle all the invocations to the provided function and only execute on the trailing edge.
    * Meaning if you invoke the function 50 times, in a period of 1 second; the function will be called
    * once per specified period and using the arguments provided to the very first invocation of the function.
    *
    * Note: trailing edge is not the default behaviour of dojo.throttle
    *
    * @param {Function} callback - function that needs to be throttled
    * @param {Number} period - duration in milliseconds to throttle callback execution
    */
    function throttleTrailingEdge(callback, period) {
        // flag to indicate if we should run or not
        var canRun = true;
        return function throttlingFunc() {
            // capture the arguments given to the function
            var args = arguments;
            // if we can run then create the timeout
            if (canRun) {
                // set the flag to false so that subsequent invocations don't make it through the guard
                canRun = false;
                // create the timeout to trigger the function after the duration
                setTimeout(function throttlingFuncTimeout() {
                    // set the flag to true to reset the throttling behaviour
                    canRun = true;
                    // invoke the function with the captured args
                    callback.apply(null, args);
                }, period);
            }
        };
    }

    return {
        compose: compose,
        composeMap: composeMap,
        getAbbreviation: getAbbreviation,
        safeGet: safeGet,
        formatDate: formatDate,
        hasDatePassed: hasDatePassed,
        getDaysUntil: getDaysUntil,
        getLabelFromID: getLabelFromID,
        throttleTrailingEdge: throttleTrailingEdge
    };
});
