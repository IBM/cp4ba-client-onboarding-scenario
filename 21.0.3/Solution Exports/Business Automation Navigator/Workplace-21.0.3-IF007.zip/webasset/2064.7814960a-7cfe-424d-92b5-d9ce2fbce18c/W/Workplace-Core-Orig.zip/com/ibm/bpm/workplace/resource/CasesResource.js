/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define("com.ibm.bpm.workplace.resources/CasesResource", ["./resourceBase"], function(resource) {
    "use strict";
    var ROUTE = resource._buildUrl("${urlPrefix}/${pathParam}", {
            urlPrefix: resource.contextRoot.federatedURL || "/CaseManager/CASEREST",
            pathParam: resource.isFederated ? "v2/processInstances" : "v1/cases?TargetObjectStore=tos"
        });


    /**
     * Get a list of Cases Instance
     *
     * @returns {Promise} promise that resolved to the response object
     */
    function get() {
        return resource.get(ROUTE);
    }

    return {
        get: get
    };
});
