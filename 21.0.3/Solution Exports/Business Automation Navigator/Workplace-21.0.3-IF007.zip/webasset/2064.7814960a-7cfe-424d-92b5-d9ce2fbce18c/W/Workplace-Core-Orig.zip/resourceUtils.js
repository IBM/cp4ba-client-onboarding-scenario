/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define(["dojo/_base/lang", "dojo/_base/array", "./constants"], function(lang, array, constants) {
    "use strict";
    var resourceUtils = {};

    resourceUtils.systemSearches = [
        "portal.savedsearch.inbox",
        "portal.savedsearch.help_reqs",
        "portal.savedsearch.history",
        "IBM.PI_PROCESSLIST_ALL",
        "IBM.DEFAULTALLPROCESSLIST_75",
        "portal.savedsearch.alerts",
        "IBM.DEFAULTALLTASKSLIST_75",
        "IBM.PI_TASKLIST_ALL",
        "IBM.PI_PROCESSLIST_TASKLESS",
    ];

  //Exclude Workflow Configurator
    resourceUtils.EXCLUDE_LIST = [
    	"25.48532397-d2d7-4fd6-9de2-bc79787f97bc", // Workflow Configurator
    	"25.e63cfd88-de50-45e3-b9d2-8d99350e343e" // Configurable Workstream
    ];

    resourceUtils.federatedSystemsInfo = {};

    resourceUtils.exposedResources = {};
    /**
     * @param {Object[]|Object} exposed - exposed resources, if given an object, exposed.items should be an Array
     * @param {Object} [params]
     * @param {String[]} [params.excludeReferencedFromToolkit] - Comma-separated list of types or service subtypes that should be excluded from referenced toolkits. See #SERVICE_SUBTYPE
     * @param {function} [params.filter] - given an exposed item, should you keep the item?
     * @returns {Object} - Object with exposed resources
     */
    resourceUtils.buildResources = function(exposed, params) {
        var result = {
                all: [],
                dashboards: [],
                services: [],
                urls: [],
                processes: [],
                caseTypes:[],
                configurableWorkstream: {}
            },
            isFederated = false,
            exposedItemsList = [];

        if (Array.isArray(exposed)) {
            exposedItemsList = lang.clone(exposed);
        } else {
            isFederated = true;
            exposedItemsList = lang.clone(exposed.items);
            resourceUtils.populateFederatedSystems(exposed.federationResult);
        }

        var hasTips = array.some(exposedItemsList, function(item) {
            return item.tip === true;
        });
        var processStringFound = false,
            startableServiceStringFound = false,
            itemProcessMap = [],
            snapshots,
            shouldFilter = false;

        if (params.excludeReferencedFromToolkit) {
            processStringFound = params.excludeReferencedFromToolkit.indexOf("process") > -1;
            startableServiceStringFound = params.excludeReferencedFromToolkit.indexOf("startable_service") > -1;
        }

        array.forEach(exposedItemsList, function(item) {
        	if(item.itemID === resourceUtils.EXCLUDE_LIST[1]) {
        		result.configurableWorkstream = item;
        	}
            if (params.shouldFilter) {
                shouldFilter = params.shouldFilter(item);
            }
            var keepItem = true;
            if (item.type === "service" && item.subtype === "dashboard") {
                if (!!item.topLevelToolkitAcronym && !shouldFilter) {
                    // don't keep toolkit items unless overridden by shouldFilter
                    keepItem = false;
                }
            }
            // if it's a workstream definition, filter out the tip version
            if(item.processAppAcronym === "RWFC" && item.tip === true) {
        		keepItem = false;
        	}
            // On Process Server only: Remove processes and startable_services that are in toolkits, unless excludeReferencedFromToolkit contains "startable_service" or "process"
            //  249049: Mismatch between Heritage/Responsive portal showing exposed entries in toolkits (only in Process Server)
            if (hasTips === false) {
                // If this processes or startable_services was defined in a toolkit, don't keep it unless excludeReferencedFromToolkit contains "startable_service" or "process"
                if (
                    item.topLevelToolkitAcronym &&
                    ((item.type === "process" && processStringFound === false) ||
                        (item.type === "service" &&
                            item.subtype &&
                            item.subtype === "startable_service" &&
                            startableServiceStringFound === false))
                ) {
                    // don't keep toolkit item for processes and startable_services
                    keepItem = false;
                }
            }
            if (resourceUtils.EXCLUDE_LIST.indexOf(item.itemID) !== -1) {
				keepItem = false;
			}
            if (keepItem) {
                // Process Center uses the itemID and branchID as the key, but Process Server uses just the itemID
                item.key = item.key || (hasTips ? item.itemID + ":" + item.branchID : item.itemID);
                item.displayName = item.title || item.display;
                if (isFederated) {
                    var federatedSystemInfo = resourceUtils.getFederatedSystemInfo(item.systemID);
                    if (federatedSystemInfo) {
                        item.systemDisplayName = federatedSystemInfo.displayName;
                    }
                }
                array.forEach(result.all, function(exposedResource) {
                    if (item.displayName === exposedResource.displayName) {
                        if (item.processAppAcronym !== exposedResource.processAppAcronym) {
                            exposedResource.showProcessAppName = true;
                            item.showProcessAppName = true;
                        }
                        if (
                            item.processAppName === exposedResource.processAppName &&
                            item.key !== exposedResource.key
                        ) {
                            exposedResource.showTrackName = true;
                            item.showTrackName = true;
                        }
                    }
                });
                result.all.push(item);

                // Group snapshots for matching name, track and process app & type/subtype.
                var uniqueType = resourceUtils.getUniqueType(item);
                if (uniqueType) {
                    if (!itemProcessMap[uniqueType]) {
                        itemProcessMap[uniqueType] = {};
                    }
                    if (!itemProcessMap[uniqueType][item.processAppID]) {
                        itemProcessMap[uniqueType][item.processAppID] = {};
                    }
                    if (!itemProcessMap[uniqueType][item.processAppID][item.key]) {
                        itemProcessMap[uniqueType][item.processAppID][item.key] = {};
                    }
                    if (itemProcessMap[uniqueType][item.processAppID][item.key][item.display]) {
                        if (isFederated) {
                            if (itemProcessMap[uniqueType][item.processAppID][item.key][item.display].multipleSystems) {
                                item.multipleSystems = true;
                            } else {
                                if (
                                    item.systemID ===
                                    itemProcessMap[uniqueType][item.processAppID][item.key][item.display].systemID
                                ) {
                                    item.multipleSystems = false;
                                } else {
                                    item.multipleSystems = true;
                                    itemProcessMap[uniqueType][item.processAppID][item.key][
                                        item.display
                                    ].multipleSystems = true;
                                    snapshots =
                                        itemProcessMap[uniqueType][item.processAppID][item.key][item.display].snapshots;
                                    if (snapshots) {
                                        array.forEach(snapshots, function(snapshot) {
                                            snapshot.multipleSystems = true;
                                        });
                                    }
                                }
                            }
                        }
                        if (!itemProcessMap[uniqueType][item.processAppID][item.key][item.display].snapshots) {
                            var tmp = lang.clone(itemProcessMap[uniqueType][item.processAppID][item.key][item.display]);
                            tmp.isSnapshot = true;
                            itemProcessMap[uniqueType][item.processAppID][item.key][item.display].snapshots = [tmp];
                        }
                        snapshots = itemProcessMap[uniqueType][item.processAppID][item.key][item.display].snapshots;
                        if (item.isDefault) {
                            // default item should be first in the list, since we're making this the "default" snapshot, we need to swap out the top level stuff
                            resourceUtils.swapItem(itemProcessMap, uniqueType, item, result);
                        } else {
                            var i = 0;
                            while (i < snapshots.length && snapshots[i].isDefault) {
                                i++;
                            }
                            tmp = new Date(item.snapshotCreatedOn).getTime();
                            while (i < snapshots.length && new Date(snapshots[i].snapshotCreatedOn).getTime() > tmp) {
                                i++;
                            }
                            while (
                                i < snapshots.length &&
                                new Date(snapshots[i].snapshotCreatedOn).getTime() === tmp &&
                                snapshots[i].tip
                            ) {
                                i++;
                            }
                            if (i < snapshots.length) {
                                if (i === 0) {
                                    resourceUtils.swapItem(itemProcessMap, uniqueType, item, result);
                                } else {
                                    snapshots.push(item);
                                    item.isSnapshot = true;
                                }
                            } else {
                                snapshots.push(item);
                                item.isSnapshot = true;
                            }
                        }
                    } else {
                        itemProcessMap[uniqueType][item.processAppID][item.key][item.display] = item;
                        item.multipleSystems = false;
                    }

                    if (item.startURL) {
                        item.runURL = item.startURL;
                    }

                    if (!item.isSnapshot && (!params.shouldFilter || shouldFilter)) {
                        if (uniqueType === "DASHBOARD") {
                            item.icon = "icon-dashboard";
                            item.orderingId = resourceUtils.getOrderId(item);
                            result.dashboards.push(item);
                        } else if (uniqueType === "SERVICE") {
                            item.icon = "icon-service";
                            result.services.push(item);
                        } if (uniqueType === "URL") {
                            result.urls.push(item);
                        } else if (uniqueType === "PROCESS") {
                            item.icon = "icon-process";
                            result.processes.push(item);
                        } else if (uniqueType === "CASETYPE") {
                        	item.icon = "icon-case";
                            result.caseTypes.push(item);
                        }
                    } else {
                        item.icon = item.tip ? "tip" : "snapshot";
                    }
                }
            }
        });
        resourceUtils.exposedResources = result;
        return result;
    };

    resourceUtils.getOrderId = function(dashboard) {
        var orderId = "";
        if (dashboard.ID && dashboard.itemID) {
            orderId = dashboard.ID;
            var itemId = dashboard.itemID,
                systemID = dashboard.systemID;
            var idx = itemId.lastIndexOf("-");
            if (idx !== -1) {
                orderId += itemId.slice(idx);
            }
            if (systemID) {
                var index = systemID.lastIndexOf("-");
                if (index !== -1) {
                    orderId += systemID.slice(index);
                }
            }
            orderId += "/";
        }
        return orderId;
    };

    resourceUtils.swapItem = function(itemProcessMap, uniqueType, item, exposedResources) {
        var tmp = itemProcessMap[uniqueType][item.processAppID][item.key][item.display],
            i,
            snapshots = itemProcessMap[uniqueType][item.processAppID][item.key][item.display].snapshots;
        if (uniqueType === "DASHBOARD") {
            i = exposedResources.dashboards.indexOf(tmp);
            if (i > -1) {
                exposedResources.dashboards.splice(i, 1);
            }
        } else if (uniqueType === "SERVICE") {
            i = exposedResources.services.indexOf(tmp);
            if (i > -1) {
                exposedResources.services.splice(i, 1);
            }
        } else if (uniqueType === "PROCESS") {
            i = exposedResources.processes.indexOf(tmp);
            if (i > -1) {
                exposedResources.processes.splice(i, 1);
            }
        }
        tmp = lang.clone(item);
        tmp.isSnapshot = true;
        if (tmp.startURL) {
            tmp.runURL = item.startURL;
        }
        snapshots.splice(0, 0, tmp);
        item.snapshots = snapshots;
        itemProcessMap[uniqueType][item.processAppID][item.key][item.display] = item;
    };

    resourceUtils.getUniqueType = function(item) {
        var type = null;
        if ((item.type === constants.TYPES.SERVICE && item.subtype === "dashboard") || item.type === "scoreboard") {
            type = "DASHBOARD";
        } else if (item.type === constants.TYPES.SERVICE && item.subtype === "startable_service") {
            type = "SERVICE";
        } else if (item.type === constants.TYPES.SERVICE && item.subtype === "url") {
            type = "URL";
        } else if (item.type === constants.TYPES.PROCESS && item.startURL) {
            type = "PROCESS";
        } else if (item.type === constants.TYPES.CASETYPE && item.startable) {
            type = "CASETYPE";
        }
        return type;
    };

    resourceUtils.buildSavedSearches = function(searchList) {
        var list = [];
        for (var i = 0; i < searchList.length; i++) {
            if (resourceUtils.systemSearches.indexOf(searchList[i].name) === -1) {
                var item = {
                    display: searchList[i].name,
                    name: searchList[i].name,
                    title: searchList[i].name,
                    tip: false,
                    branchID: "branchId",
                    branchName: "branchName",
                    isDefault: true,
                    isMobileReady: true,
                    isSavedSearch: true,
                    ID: searchList[i].id,
                    shared: searchList[i].shared,
                    owner: searchList[i].owner
                };
                if (searchList[i].organization === "byTask") {
                    item.itemID = "TQ." + searchList[i].name;
                } else {
                    item.itemID = "PQ." + searchList[i].name;
                }
                list.push(item);
            }
        }
        return list;
    };

    resourceUtils.getFederatedSystemInfo = function(systemID) {
        if (resourceUtils.federatedSystemsInfo[systemID]) {
            return resourceUtils.federatedSystemsInfo[systemID];
        }
        return null;
    };

    resourceUtils.populateFederatedSystems = function(federationResult) {
        if (federationResult) {
            array.forEach(federationResult, function(federatedSystem) {
                if (!Object.prototype.hasOwnProperty.call(resourceUtils.federatedSystemsInfo, federatedSystem.systemID)) {
                    resourceUtils.federatedSystemsInfo[federatedSystem.systemID] = federatedSystem;
                }
            });
        }
    };

    resourceUtils.processCaseTypeInfo = function(caseTypes) {
    	var projects = {}, obj, shortName, displayName, stageStatus, caseSummaryProps = {}, caseStages = {}, result = {};
    	for (var i = 0; i < caseTypes.length; i++) {
    		obj = caseTypes[i];
    		displayName = obj.solutionName || obj.processAppName;
    		shortName = obj.processAppAcronym || obj.solutionPrefix;
    		if (!Object.prototype.hasOwnProperty.call(projects, shortName)) {
    			projects[shortName] = displayName;
    		}
    		if(obj.casestages && obj.casestages.stages) {
    			for (var j = 0; j < obj.casestages.stages.length; j++) {
        			stageStatus = obj.casestages.stages[j].symbolicName;
        			if (!Object.prototype.hasOwnProperty.call(caseStages, stageStatus)) {
        				caseStages[stageStatus] = obj.casestages.stages[j].displayName;
            		}
        		}
    		}
    		
    		if(obj.caseSummaryViewProperties && !obj.caseSummaryViewProperties.isWellKnownProperites) {
				caseSummaryProps[obj.casetypeSymbolicName] = obj.caseSummaryViewProperties.summaryViewProperties;
    		}

    	}
    	result.allCaseTypes = caseTypes;
    	result.allCaseSolution = projects;
    	result.allCaseStages = caseStages;
    	result.caseSummaryProps = caseSummaryProps;
        return result;
    };

    return resourceUtils;
});
