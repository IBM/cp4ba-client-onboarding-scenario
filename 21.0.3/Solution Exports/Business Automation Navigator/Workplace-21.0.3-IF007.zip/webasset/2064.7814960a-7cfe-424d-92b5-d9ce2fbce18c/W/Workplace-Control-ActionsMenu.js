/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof ActionsMenu
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof ActionsMenu
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof ActionsMenu
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof ActionsMenu
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof ActionsMenu
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof ActionsMenu
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof ActionsMenu
 * @method triggerFormulaUpdates
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On Show:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when the actions menu is shown</td>
 *               </tr>
 *           </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *               </tr>
 *       </table>
 *     </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On Hide:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when the actions menu is hidden</td>
 *               </tr>
 * </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *               </tr>
 *           </table>
 *       </td>
 *   </tr>
 * </table>
 */

workplace_control_InitActionsMenu = function(utilities, all, taskUtils, wpResources, resourceUtils) {
    "use strict";
    this._instance = {
        actions: {}
    };

    if (!this.constructor.prototype._proto) {
        this.constructor.prototype._proto = {
            EVT_ONSHOW: "eventON_SHOW",
            EVT_ONHIDE: "eventON_HIDE",
            TASK_ACTIONS: {
                "ACTION_LAUNCH_TASK": {
                    label: bpmext.localization.formatMsg("actionsMenu", "ACTION_LAUNCH_TASK"),
                    icon: "ci-launch",
                    command: taskUtils.EVENTS.TASK_BEFORE_LAUNCH
                },
                "ACTION_MODIFY_TASK": {
                    label: bpmext.localization.formatMsg("actionsMenu", "ACTION_MODIFY_TASK"),
                    icon: "ci-edit",
                    command: taskUtils.EVENTS.MODIFY_TASK
                },
                "ACTION_VIEW_INSTANCE": {
                    label: bpmext.localization.formatMsg("actionsMenu", "ACTION_VIEW_INSTANCE"),
                    icon: "ci-view",
                    command: taskUtils.EVENTS.BEFORE_VIEW_INSTANCE
                },
                "ACTION_MODIFY_INSTANCE": {
                    label: bpmext.localization.formatMsg("actionsMenu", "ACTION_MODIFY_INSTANCE"),
                    icon: "ci-edit",
                    command: taskUtils.EVENTS.MODIFY_INSTANCE
                },
                "ACTION_VIEW_PROCESS_AUDIT": {
                    label: bpmext.localization.formatMsg("actionsMenu", "ACTION_VIEW_PROCESS_AUDIT"),
                    icon: "ci-recently-viewed",
                    command: taskUtils.EVENTS.VIEW_PROCESS_AUDIT
                },
                "ACTION_VIEW_PROCESS_DIAGRAM": {
                    label: bpmext.localization.formatMsg("actionsMenu", "ACTION_VIEW_PROCESS_DIAGRAM"),
                    icon: "ci-view",
                    command: taskUtils.EVENTS.VIEW_PROCESS_DIAGRAM
                },
                "ACTION_GET_LINK":{
                    label: bpmext.localization.formatMsg("workplace", "copyLink"),
                    icon: "ci-link",
                    command: taskUtils.EVENTS.GET_LINK
                },
                "ACTION_REASSIGN_BACK":{
                    label: bpmext.localization.formatMsg("actionsMenu", "ACTION_REASSIGN_BACK"),
                    icon: "ci-events",
                    command: taskUtils.EVENTS.REASSIGN_BACK
                }
            },
            CASE_INSTANCE_ACTIONS: {
                "ACTION_VIEW_INSTANCE": {
                	label: bpmext.localization.formatMsg("actionsMenu", "ACTION_VIEW_INSTANCE"),
                    icon: "ci-view",
                    command: taskUtils.EVENTS.VIEW_CASE_INSTANCE
                }
            },
            TASK_ACTIONS_SEQUENCE: ["ACTION_LAUNCH_TASK", "ACTION_MODIFY_TASK", "SEPARATOR", "ACTION_VIEW_INSTANCE", "ACTION_MODIFY_INSTANCE", "ACTION_VIEW_PROCESS_AUDIT", "ACTION_VIEW_PROCESS_DIAGRAM", "SEPARATOR", "ACTION_GET_LINK", "ACTION_REASSIGN_BACK"],
            CASE_INSTANCE_ACTIONS_SEQUENCE: ["ACTION_VIEW_INSTANCE"],

            addActionItem: function(action) {
                if(!this._proto._isActionDisabled(this, action)) {
                    if (this._instance.actions.indexOf(action) !== -1) {
                        this._instance.menuItems.push({
                            command: {action: this._proto.TASK_ACTIONS[action].command, item: this._instance.task},
                            itemType: "L",
                            icon: this._proto.TASK_ACTIONS[action].icon,
                            itemText: this._proto.TASK_ACTIONS[action].label
                        });
                    } else if (action === "SEPARATOR" && this._instance.menuItems.length > 0) {
                        this._instance.menuItems.push({
                            itemType: "S"
                        });
                    }
                }
            },

            populateActionMenu: function(view) {
            	if (!view) {
            		view = this;
            	}
                if (view._instance.menuItems.length > 0) {
                    //Populate popup menu with actions
                	view._instance.popupMenu.setMenuItems(view._instance.menuItems);
                	view._instance.popupMenu.setMenuVisible(true);
                	view._instance.menuItems = []; //Defect#330372
                }
                bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONSHOW, view._instance.targetElement);
            },

            _loadMenu: function(view) {
                //Hide popup menu if it is already visible
                view._instance.popupMenu.setMenuVisible(false);

                //Attach popup menu to target element
                view._instance.popupMenu.setTargetElement(view._instance.targetElement);

                view._instance.menuItems = [];
                if(view._instance.isCaseInstance) {
                	view._instance.actions = view._proto.CASE_INSTANCE_ACTIONS_SEQUENCE;
                	view._proto.CASE_INSTANCE_ACTIONS_SEQUENCE.forEach(function (action) {
                		view._instance.menuItems.push({
                            command: {action: view._proto.CASE_INSTANCE_ACTIONS[action].command},
                            itemType: "L",
                            icon: view._proto.CASE_INSTANCE_ACTIONS[action].icon,
                            itemText: view._proto.CASE_INSTANCE_ACTIONS[action].label
                        });
                	});
                	this.populateActionMenu(view);
                } else if (view._instance.processId || view._instance.taskId) {
                    this._getActions(view)
                    .then(dojo.hitch(view, function(actions) {
                        var view = this;
                        view._instance.actions = actions;
                        this._proto.TASK_ACTIONS_SEQUENCE.forEach(dojo.hitch(view, view._proto.addActionItem));
                    }), this._handleServiceError)
                    .always(dojo.hitch(view, view._proto.populateActionMenu));
                }
            },
            _getActions: function(view) {
                var processId = view._instance.processId,
                    taskId = view._instance.taskId,
                    systemID = view._instance.systemID;

                //Get actions from services
                return all({
                        process: wpResources.process.get({ piid: processId, parts: "actions", systemID: systemID }),
                        task: wpResources.task.get({ tkiid: taskId, includeURL: true, systemID: systemID })
                    })
                    //Process actions returned by services
                    .then(dojo.hitch(view, this._processActions), dojo.hitch(view, this._handleServiceError));
            },
            _processActions: function(data) {
                var actions = [];
                if (data.task && !data.task.message) {
                    this._instance.task = data.task;
                    this._instance.process = data.process;
                    var taskActions = data.task.actions;
                    var processActions = data.process.actions;

                    //Can the task be launched?
                    if((taskUtils.isUserTask(data.task)) && (taskActions.indexOf("ACTION_CLAIM") !== -1 || taskActions.indexOf("ACTION_COMPLETE") !== -1)) {
                        actions.push("ACTION_LAUNCH_TASK");                      
                    }

                    //Can the task be modified?
                    if (this._instance.modifyTask && this._instance.modifyTask.any && (taskActions.indexOf("ACTION_UPDATEDUEDATE") !== -1||taskActions.indexOf("ACTION_UPDATEPRIORITY") !== -1||taskActions.indexOf("ACTION_REASSIGNTOUSER") !== -1||taskActions.indexOf("ACTION_CANCELCLAIM") !== -1)) {
                        actions.push("ACTION_MODIFY_TASK");
                    }
                    
                    // Can the task be reassigned back to team
                    if (this._instance.modifyTask && this._instance.modifyTask.reassign && (taskActions.indexOf("ACTION_CANCELCLAIM") !== -1)) {
                        actions.push("ACTION_REASSIGN_BACK");
                    }

                    //Process level actions
                    processActions.forEach(dojo.hitch(this, function(action) {
                        switch (action) {
                            case "ACTION_VIEW_INSTANCE":
                                // always show on non-AE scenario, but only show when isWorkstream is true on AE.
                                var isWorkstream = this._instance.isWorkstream === "true" || taskUtils.isWorkstreamProcess(data.process);
                                data.task.isWorkstream = isWorkstream;
                                actions.push("ACTION_VIEW_INSTANCE");
                                break;
                            case "ACTION_CHANGE_INSTANCE_DUEDATE":
                                actions.push("ACTION_MODIFY_INSTANCE");
                                break;
                            case "ACTION_VIEW_PROCESS_AUDIT":
                                actions.push("ACTION_VIEW_PROCESS_AUDIT");
                                break;
                            case "ACTION_VIEW_PROCESS_DIAGRAM":
                                actions.push("ACTION_VIEW_PROCESS_DIAGRAM");
                                break;
                        }
                    }));
                }else if (data.process){
                    this._instance.process = data.process;
                    var processActions = data.process.actions;

                    //Process level actions
                    processActions.forEach(dojo.hitch(this, function(action) {
                        switch (action) {
                            case "ACTION_VIEW_INSTANCE":
                                // always show on non-AE scenario, but only show when isWorkstream is true on AE.
                                var isWorkstream = this._instance.isWorkstream === "true" || taskUtils.isWorkstreamProcess(data.process);
                                data.process.isWorkstream = isWorkstream;
                                actions.push("ACTION_VIEW_INSTANCE");
                                break;
                            case "ACTION_CHANGE_INSTANCE_DUEDATE":
                                actions.push("ACTION_MODIFY_INSTANCE");
                                break;
                            case "ACTION_VIEW_PROCESS_AUDIT":
                                actions.push("ACTION_VIEW_PROCESS_AUDIT");
                                break;
                            case "ACTION_VIEW_PROCESS_DIAGRAM":
                                actions.push("ACTION_VIEW_PROCESS_DIAGRAM");
                                break;
                        }
                    }));
                }

                actions.push("ACTION_GET_LINK");

                return actions;
            },
            _isActionDisabled: function(view, action) {
                var disabledActions = view.context.options.disableActions.get("value").items;
                var disabled = false;
                if(disabledActions.indexOf(action) !== -1) {
                    disabled = true;
                }
                return disabled;
            },
            _canUserModifyTask: function(view) {
                try {
                    wpResources.user.get()
                        .then(dojo.hitch(view, function(user) {
                            if (user.modifyTask) {
                                view._instance.modifyTask = user.modifyTask;
                            } else {
                                view._instance.modifyTask = null;
                                bpmext.log.error("Actions menu", "Unable to get modify task user info");
                            }
                        }));
                } catch (error) {
                    bpmext.log.error(error.message);
                }
                return true;
            },
            _handleServiceError: function(error) {
                //the task has probably already been deleted, try to handle by removing it from the task list
                var taskView = this.ui.getParent();
                if (taskView && taskView.context.binding) {
                    var x, length, taskList = taskView.context.binding.get("value").get("items");
                    length = taskList && taskList.length() || 0;
                    for (x = 0; x < length; x++) {
                        if (taskList.items[x]["TASK.TKIID"] === this._instance.taskId) {
                            taskList.remove(x);
                            taskView._proto._loadTasks.call(taskView, taskView.context.binding.get("value"));
                            break;
                        }
                    }
                }
                bpmext.log.error(error.message);
            }
        };


        /*
        Public control methods *************************************************************
         */

         /**
          * @instance
          * @memberof ActionsMenu
          * @method loadMenu
          * @param {String|Number} processId - The process id the task is associated with
          * @param {String|Number} taskId - Task ID
          * @param {String} systemID- System ID
          * @param {String} templateId- case type symbolic name
          * @param {String} isWorkstream - either "true" or "false" to indicate whether or not the task is associated with a workstream
          * @param {String} isCaseInstance - either "true" or "false" to indicate whether or not the instance is a case instance
          * @param {Object} targetElement The DOM element relative to which the action menu should open
          * @desc Function to load the actions menu
          */
        this.constructor.prototype.loadMenu = function(processId, taskId, systemID, isWorkstream, dashboards, targetElement, isCaseInstance, templateId) {
            if (!processId && !taskId && !dashboards) {
                 return;
             }

            if (this.isMenuOpen()) {
                // close the action menu if it is already opened
                this.close();
            } else if (this._instance.targetElement && (this._instance.targetElement !== targetElement)) {
                // if the action menu for previous target element is not open remove the pop up effect
                this.onPopupClosed();
            }

            this._instance.processId = processId;
            this._instance.taskId = taskId;
            this._instance.systemID = systemID;
            this._instance.templateId = templateId;
            this._instance.isWorkstream = isWorkstream;
            this._instance.isCaseInstance = isCaseInstance;
            this._instance.targetElement = targetElement;
            this._instance.tkiid = taskId + "-" + systemID;
            this._instance.piid = processId + "-" + systemID;

            this._proto._loadMenu(this);
        };

        /**
         * @instance
         * @memberof ActionsMenu
         * @method onActionClick
         * @param
         * @desc Called when an action is selected from the Actions menu. The function broadcasts an event based on the action selected
         */
        this.constructor.prototype.onActionClick = function onActionClick(popupMenuView, actionWrapper) {

            var data = {view: this};

            var parent = this.ui.getParent().ui.getParent();
            if (!parent.context) {
                parent = this.ui.getParent();
            }
            data.origin = parent.context.viewid;

            var action = actionWrapper.action;
        	if (taskUtils.EVENTS.TASK_BEFORE_LAUNCH.equals(action)) {
                action = this._instance.taskLaunchingEvent || action;
                if (parent.context && parent.context.options && parent.context.options.skipClaimForTasks) {
                    data.skipClaim = parent.context.options.skipClaimForTasks.get("value");
                }
            }

            if (taskUtils.EVENTS.SERVICE_LAUNCHED.equals(action)) {
                data.service = actionWrapper.item;
            } else {
                if(this._instance.task != null){
                    data.task = this._instance.task;
                    data.canUserModifyTask = this._instance.modifyTask;
                }else{
                    data.process = this._instance.process;
                }
            }

            if (taskUtils.EVENTS.VIEW_CASE_INSTANCE.equals(action)) {
            	taskUtils.EVENTS.VIEW_CASE_INSTANCE.publish({"caseInstanceId": this._instance.processId, "templateId": this._instance.templateId, "systemId": this._instance.systemID});
            	return;
            }
            //Special processing for non workstreams view instance
            if (taskUtils.EVENTS.BEFORE_VIEW_INSTANCE.equals(action)) {
                if(this._instance.task != null){
                    var task = this._instance.task;
                    if (task.isWorkstream !== true) {
                        action = taskUtils.EVENTS.SERVICE_LAUNCHED;

                        data.piid = task.piid;
                        data.systemID = task.systemID;
                        data.task = undefined;
                        var process = this._instance.process;
                        if (process) {
                            var curSystemInfo, runURLPrefix = dojoConfig.App._bpmContextRootMap.teamworks;
                            if(process.systemID) {
                                curSystemInfo = resourceUtils.getFederatedSystemInfo(process.systemID);
                                runURLPrefix = curSystemInfo.taskCompletionUrlPrefix;
                            }
                            data.name = process.name;
                            data.runURL = runURLPrefix + "/launchInstanceUI?origin=workplace&instanceId=" + data.piid;
                        } else {
                            data.systemID = this._instance.systemID;
                            data.name = task ? task.processInstanceName : undefined;
                        }
                    }
                }else{
                    taskUtils.EVENTS.BEFORE_VIEW_INSTANCE.publish(this._instance.process);
                    return;
                }
            }
            action.publish(data);
        };

        /**
         * @instance
         * @memberof ActionsMenu
         * @method onPopupOpen
         * @param {View} popupMenuView The popup view
         * @desc Called when the actions menu popup is opened
         */
        this.constructor.prototype.onPopupOpen = function onPopupOpen() {
            bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONSHOW, this._instance.targetElement);
        };

        /**
         * @instance
         * @memberof ActionsMenu
         * @method onPopupClosed
         * @param {View} popupMenuView The popup view
         * @desc Called when the actions menu popup is closed
         */
        this.constructor.prototype.onPopupClosed = function onPopupClosed() {
            bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONHIDE, this._instance.targetElement);
        };

        /**
         * @instance
         * @memberof ActionsMenu
         * @method isMenuOpen
         * @desc Returns a true/false indicating if the Actions menu open
         * @return {boolean}
         */
        this.constructor.prototype.isMenuOpen = function isMenuOpen() {
            return this._instance.popupMenu.isMenuVisible();
        };

        /**
         * @instance
         * @memberof ActionsMenu
         * @method open
         * @desc Function to open the actions menu
         */
        this.constructor.prototype.open = function open() {
            this._instance.popupMenu.setMenuVisible(true);
        };

        /**
         * @instance
         * @memberof ActionsMenu
         * @method close
         * @desc Function to close the actions menu
         */
        this.constructor.prototype.close = function close() {
            this._instance.popupMenu.setMenuVisible(false);
        };

        /**
         * @instance
         * @memberof ActionsMenu
         * @method settingTaskLaunchingEvents
         * @param eventName
         * @desc Customized task launching events
         */
        this.constructor.prototype.settingTaskLaunchingEvents = function settingTaskLaunchingEvents(eventName) {
            if (eventName) {
                this._instance.taskLaunchingEvent = eventName;
            }
        };

        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function() {
            try {
                var view = this;
                var opts = this.context.options;

                if (!opts.disableActions) {
                    bpmext.ui.substituteConfigOption(this, "disableActions", ["ACTION_VIEW_PROCESS_AUDIT","ACTION_VIEW_PROCESS_DIAGRAM"]); // temporarily  disable audit history and view process diagram
                }

                view._instance.menuItems = [];

                view._instance.popupMenu = bpmext.ui.getContainer("Popup_Menu1", this);
                view._instance.popupMenu._proto._setDisabler(view._instance.popupMenu, false);

                view._proto._canUserModifyTask(view);

                bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONSHOW);
                bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONHIDE);

                this.loadView(this);
            } catch (error) {
                bpmext.log.error(error);
            }
        };

        this.constructor.prototype.view = function() {
            try {
                utilities.handleVisibility(this.context);
            } catch (e) {
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if (e.stack) {
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                }
            }
        };

        this.constructor.prototype.change = function() {};

        this.constructor.prototype.unload = function() {
            bpmext.ui.unloadView(this);
        };
    }
};