/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
 /**
 * @ignore
 * @instance
 * @memberof GetLink
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof GetLink
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof GetLink
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof GetLink
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof GetLink
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof GetLink
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof GetLink
 * @method triggerFormulaUpdates
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 * </table>
 */
workplace_control_InitGetLink = function (utilities, taskUtils, wpResources, domAttr)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
        };


        /*
        Public control methods *************************************************************
         */

         /**
		 * @instance
		 * @memberof GetLink
		 * @method copyLink
         * @param {string} context The current context as a JSON string
		 * @desc Gets the cuurent link and copies it to the clipboard
		 */
        this.constructor.prototype.copyLink = function(context) {
            bpmext.log.info("GetLink.copyLink ENTER >> ", this);

            taskUtils.copyToClipboard(null, taskUtils.getLink(this, context));
            taskUtils.publishAlert({title: bpmext.localization.formatMsg("workplace", "copied"), text: "", timeout: 3000});

            bpmext.log.info("GetLink.copyLink EXIT << ");
        };

        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function (){
            bpmext.log.info("GetLink.load ENTER >>", this);

            this.loadView(this);

            bpmext.log.info("GetLink.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try {
                utilities.handleVisibility(this.context);
            }
            catch (e){
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e, this);
                if(e.stack) {
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack), this);
                }
            }
        };

        this.constructor.prototype.change = function (/*event*/){
        };

        this.constructor.prototype.unload = function (){
            bpmext.log.info("GetLink.unload ENTER >> ", this);
            bpmext.ui.unloadView(this);
            bpmext.log.info("GetLink.unload ENTER >>", this);
        };
    }
};