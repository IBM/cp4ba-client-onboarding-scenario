/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2020. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof WorkflowCard
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof WorkflowCard
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof WorkflowCard
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof WorkflowCard
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof WorkflowCard
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof WorkflowCard
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof WorkflowCard
 * @method triggerFormulaUpdates
 */

workplace_control_InitWorkflowCard = function (utilities) {
    "use strict";
    this._instance = {
    };

    if (!this.constructor.prototype._proto) {
        this.constructor.prototype._proto = {
            EVT_ONCARD_CLICK: "eventON_CARD_CLICK",
            EVT_ONICON_CLICK: "eventON_BOTTOM_ICON_CLICK",
            EVT_ONLOAD : "eventON_LOAD",
            EVT_FAVORITE_CLICK : "eventON_FAVORITE_CLICK",
            EVT_FAVORITE_LOAD : "eventON_FAVORITE_LOAD",
            EVT_SNAPSHOT_CLICK: "eventON_SNAPSHOT_CLICK",

            _translate: function _translate() {
                var args = [].slice.call(arguments);
                args.unshift("PropertiesModal");
                return bpmext.localization.formatMsg.apply(null, args);
            },

			 _getSnapshotData: function(target) {
                 var data = target.ui.getParent(true).context.binding.get("value").items, cPath = target.context.controlidpath, index = 0;
                 var str = "snapshotLink";
	 			 if(cPath.indexOf(str) !== -1) {
	 				 index = cPath.substring(cPath.indexOf(str) + str.length + 1, cPath.length-1);
	 			 }
	 			 return data[index];
	         },

	         _getSnapshotName: function(snapshot) {
            	var name = snapshot && snapshot.tip ? bpmext.localization.formatMsg("workplace", "tip"): snapshot.snapshotName;
            	if (snapshot.multipleSystems) {
            		name = name + " (" + snapshot.systemDisplayName + ")";
            	}
            	return name;
            },

            _setViewData: function _setViewData(view, data, createPseudoBinding) {
                var ctx = view.context;
                if(ctx){
                    if(ctx.binding){
                        ctx.binding.set("value", data);
                    } else if (createPseudoBinding) {
                        ctx.binding = bpmext.ui.substituteObject(view);
                        ctx.binding.set("value", data);
                    }
                }
	         }
        };


        /*
        Public control methods *************************************************************
        */

        /**
         * @instance
         * @memberof WorkflowCard
         * @method setTopIcon
         * @desc Sets the icon above the title
         */
        this.constructor.prototype.setTopIcon = function setTopIcon(icon) {
			this._instance.topIcon.setIcon(icon);
		};

       /**
         * @instance
         * @memberof WorkflowCard
         * @method setTitle
         * @desc Sets the title of the card
         */
        this.constructor.prototype.setTitle = function setTitle(title) {
			this._instance.title.setText(title);
        };

        /**
         * @instance
         * @memberof WorkflowCard
         * @method setDescription
         * @desc Sets the description of the card
         */
        this.constructor.prototype.setDescription = function setDescription(desc) {
			this._instance.description.setText(desc);
        };

        /**
         * @instance
         * @memberof WorkflowCard
         * @method setSnapshotData
         * @desc Sets the snapshot data of the card
         */
        this.constructor.prototype.setSnapshotData = function setSnapshotData(data) {
			var multiVL = this._instance.multiSnapshot;
            this._instance.allSnapshots = data.snapshots;
            this._instance.visibleSnapshots = data.snapshots.slice(0,5);
			this._proto._setViewData(multiVL, this._instance.allSnapshots, true);
        };

        /**
         * @instance
         * @memberof WorkflowCard
         * @method setSnapshotName
         * @desc Sets the snapshot name of the card
         */
        this.constructor.prototype.setSnapshotName = function setSnapshotName(target) {
			if (target != null){
				var data = this._proto._getSnapshotData(target);
				target.setText(this._proto._getSnapshotName(data));
			}
		};

		 /**
         * @instance
         * @memberof WorkflowCard
         * @method openSnapshotLinks
         * @desc Open the snapshot links of the card
         */
		 this.constructor.prototype.openSnapshotLinks = function openSnapshotLinks(data) {
			 var multiVL = this._instance.multiSnapshot, showMore = this._instance.showMore;
			 if(multiVL.getVisibility() === "NONE") {
                 if(data.snapshots.length > 5){
                    showMore.setVisible(true,true);
                 }
                 multiVL.setVisible(true, true);
			 } else {
                this._instance.multiSnapshot.context.element.querySelector(".layoutSec").scrollTop = 0;
                 multiVL.setVisible(false, true);
                 showMore.setVisible(false,true);
                 if(this._instance.visibleSnapshots.length > 5){
                    this._instance.visibleSnapshots  = this._instance.allSnapshots.slice(0,5);
                    this._proto._setViewData(multiVL, data.snapshots, true);
                    this._instance.multiSnapshot.context.element.querySelector(".layoutSec").classList.remove("scrollable");
                 }
			 }
		};

		 /**
         * @instance
         * @memberof WorkflowCard
         * @method selectSnapshot
         * @desc Select a snapshot of the card
         */
		this.constructor.prototype.selectSnapshot = function selectSnapshot(target, event) {
			event.stopImmediatePropagation();
			var selectedItem = this._proto._getSnapshotData(target);
			bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_SNAPSHOT_CLICK, selectedItem);
			return false;
		};
         /**
         * @instance
         * @memberof WorkflowCard
         * @method showMore
         * @desc Show more snapshots
         */
		this.constructor.prototype.showMore = function showMore(event) {
            event.stopImmediatePropagation();
            var snapshotVL = this._instance.multiSnapshot.context.element.querySelector(".layoutSec");
            this._instance.visibleSnapshots = this._instance.allSnapshots;
            snapshotVL.scrollTop = 150;
            this._instance.showMore.setVisible(false,true);
            snapshotVL.classList.add("scrollable");
        };
        
         /**
         * @instance
         * @memberof WorkflowCard
         * @method setBottomIcon
         * @desc Sets the icon below the description
         */
        this.constructor.prototype.setBotomIcon = function setBotomIcon(icon) {
			this._instance.bottomIcon.setIcon(icon);
        };

        /**
         * @instance
         * @memberof WorkflowCard
         * @method isTitleOverflown
         * @desc Checks if title text is overflown
         */
        this.constructor.prototype.isTitleOverflown = function isTitleOverflown() {
            var element = this._instance.title.context.element.querySelector("p");
			return element.scrollHeight > element.clientHeight || element.scrollWidth > element.clientWidth;
        };

        /**
         * @instance
         * @memberof WorkflowCard
         * @method isDescriptionOverflown
         * @desc Checks if description text is overflown
         */
        this.constructor.prototype.isDescriptionOverflown = function isDescriptionOverflown() {
            var element = this._instance.description.context.element.querySelector("p");
			return element.scrollHeight > element.clientHeight || element.scrollWidth > element.clientWidth;
        };


        /**
         * @instance
         * @memberof WorkflowCard
         * @method onFavoriteClicked
         * @desc Called when the favorites icon is clicked
         */
        this.constructor.prototype.onFavoriteClicked = function onFavoriteClicked(targetView, event) {
			event.stopImmediatePropagation();
            if (targetView.getLabel() === bpmext.localization.formatMsg("workplace", "favorite")) {
				targetView.setLabel(bpmext.localization.formatMsg("workplace", "favoriteFilled"));
				targetView.setIcon("ci-favorite-filled");
			} else {
				targetView.setLabel(bpmext.localization.formatMsg("workplace", "favorite"));
                targetView.setIcon("ci-favorite");
            }
            bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_FAVORITE_CLICK, targetView.getLabel());
        };

        /**
         * @instance
         * @memberof WorkflowCard
         * @method onFavoriteLoad
         * @desc Called when the favorites icon is loaded
         */
        this.constructor.prototype.onFavoriteLoad = function onFavoriteLoad(targetView) {
            bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_FAVORITE_LOAD, targetView);
        };

        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function () {
            try {
                var view = this;
                var opts = view.context.options;

                this._instance.topIcon = bpmext.ui.getView("TopIcon", this);
                this._instance.bottomIcon = bpmext.ui.getView("BottomIcon", this);
                this._instance.title = bpmext.ui.getView("Title", this);
                this._instance.description = bpmext.ui.getView("Description", this);
                this._instance.card = bpmext.ui.getContainer("Card", this);
                this._instance.multiSnapshot = bpmext.ui.getContainer("multiSnapshot", this);
                this._instance.showMore = bpmext.ui.getView("showMoreLink", this);

                bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONICONCLICK);
                bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONCARDCLICK);
                bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONLOAD);
                bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_FAVORITE_CLICK, "label");
                bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_FAVORITE_LOAD, "favoriteView");
                bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_SNAPSHOT_CLICK, "item");

                view._instance.topIcon.setVisible(true, true);
                if(opts.topIcon){
                    view._instance.topIcon.setIcon(opts.topIcon.get("value"));
                }
                if(opts.topIconSize){
                    view._instance.topIcon.setIconSize(opts.topIconSize.get("value"));
                }

                if(opts.bottomIcon && opts.isBottomIconVisible.get("value")){
                    view._instance.bottomIcon.setVisible(true, true);
                    view._instance.bottomIcon.setIcon(opts.bottomIcon.get("value"));
                    if(opts.bottomIconSize){
                        view._instance.bottomIcon.setIconSize(opts.bottomIconSize.get("value"));
                    }
                }else{
                    view._instance.bottomIcon.setVisible(false, true);
                }

                var mouseOverTooltip = function(view){
                    var timeout = null;
                    var titleElt = null;
                    var descElt = null;
                    var title = view._instance.title;
                    var desc = view._instance.description;
                    if(view.isTitleOverflown()){
                        title.context.element.onmouseenter = function(){
                            timeout = setTimeout(function() {
                                var text = title.getText();
                                titleElt = bpmext.ui.util.showTooltip(title.context.element, text, {
                                    horizontalPos: "LEFT",
                                    smartPositioning: true,
                                    alwaysShow: true
                                });
                            },1000);
                        };
                        title.context.element.onmouseleave = function() {
                            // Clear any timers set to timeout
                            clearTimeout(timeout);
                            if(titleElt != null){
                                bpmext.ui.util.closeTooltip(titleElt, title.context.element);
                                titleElt = null;
                            }
                        };
                    }

                    if(view.isDescriptionOverflown()){
                        desc.context.element.onmouseenter = function(){
                            timeout = setTimeout(function() {
                                var text = desc.getText();
                                descElt = bpmext.ui.util.showTooltip(desc.context.element, text, {
                                    horizontalPos: "LEFT",
                                    smartPositioning: true,
                                    alwaysShow: true
                                });
                            },1000);
                        };
                        desc.context.element.onmouseleave = function() {
                            // Clear any timers set to timeout
                            clearTimeout(timeout);
                            if(descElt != null){
                                bpmext.ui.util.closeTooltip(descElt, desc.context.element);
                                descElt = null;
                            }
                        };
                    }
                };

                var onClickHandler = function (itemName) {
                    return function sidebarClickHandler () {
                        bpmext.ui.executeEventHandlingFunction(view, view._proto["EVT_ON" + itemName.toUpperCase() + "_CLICK"]);
                        if (!e) var e = window.event;
                        e.cancelBubble = true;
                        if (e.stopPropagation) e.stopPropagation();
                    };
                };

                this._instance.card.context.element.onkeydown = function(event) {
                    if (event.key === "Enter") {
                        this.click();
                    }
                };

                bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONLOAD);
                this._instance.bottomIcon.context.element.addEventListener("click", onClickHandler("icon"));
                this._instance.card.context.element.addEventListener("click", onClickHandler("card"));

                this.loadContainer(this);
                mouseOverTooltip(this);

            } catch (error) {
                bpmext.log.error(error);
            }
        };

        this.constructor.prototype.view = function () {
            try {
                utilities.handleVisibility(this.context);
            } catch (e) {
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if (e.stack) {
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                }
            }
        };

        this.constructor.prototype.change = function () { };

        this.constructor.prototype.unload = function () {
            bpmext.ui.unloadView(this);
        };
    }
};