/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof SearchBar
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof SearchBar
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof SearchBar
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof SearchBar
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof SearchBar
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof SearchBar
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof SearchBar
 * @method triggerFormulaUpdates
 */

workplace_control_InitSearchBar = function (taskUtils, wpResources, utilities, resourceUtils, domStyle, domClass, domAttr)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            _loadDropdown: function (view) {
                bpmext.log.info("TaskList._loadDropdown ENTER >>");
                view._instance.disableSearchIconClick = true;
                view._instance.searchBar.setVisible(false,true);
                view._instance.closeIcon.setVisible(false,true);
                view._instance.dropDownMenu.setMenuVisible(false);

                view._instance.menuItems = [];

                if (!view.context.options.disabledFulltextSearch.get("value")) {
                    view._proto._getFulltextSearch(view);
                }

                if (!!view.context.options.showSavedSearches.get("value")) {
                    view._proto._getSavedSearches(view);
                } else {
                    view._proto._showDropdown(view);
                }
                bpmext.log.info("TaskList._loadDropdown EXIT >>", view);
            },
            _getFulltextSearch: function (view) {
                view._instance.recents = view.getRecentBindingArray();
                if(view._instance.recents && view._instance.recents.length>0){
                    view._instance.menuItems.push({
                        itemType: "H",
                        itemText: "<div><span>" + bpmext.localization.formatMsg("SearchBar", "recentHeader") + "<a class='clearAll' tabindex='0'>"+bpmext.localization.formatMsg("SearchBar", "clearAll")+"</a></span></div>"
                    });
                    for (var x = 0; x < view._instance.recents.length; x++) {
                        view._instance.menuItems.push({
                            command: {isSavedSearch:false, index:x+1+"", display:view._instance.recents[x]},
                            itemType: "L",
                            itemText: view._instance.recents[x],
                            icon: "ci-close"
                        });
                    }
                }
            },
            _getSavedSearches: function (view) {
                bpmext.log.info("TaskList._getSavedSearches ENTER >>");
                wpResources.searches.get().then(function (savedSearches) {
                    view._instance.searches = resourceUtils.buildSavedSearches(savedSearches);
                    if (view._instance.searches && view._instance.searches.length > 0) {
                        taskUtils.EVENTS.LOAD_MODAL.publish({showModal:false, modal:"Saved search"});
                        view._instance.menuItems.push({
                            itemType: "H",
                            itemText: "<div><span>" + bpmext.localization.formatMsg("SearchBar", "savedSearchesHeader") + "<a class='viewAll' tabindex='0'>"+bpmext.localization.formatMsg("SearchBar", "viewAll")+"</a></span></div>"
                        });
                        var amountOfResults = view._instance.searches.length > 10 ? 10 : view._instance.searches.length;
                        for (var x = 0; x < amountOfResults; x++) {
                            view._instance.menuItems.push({
                                command: {isSavedSearch:true, ID:view._instance.searches[x].ID, display:view._instance.searches[x].display},
                                itemType: "L",
                                itemText: view._instance.searches[x].display
                            });
                        }
                    }

                    view._proto._showDropdown(view);
                });
                bpmext.log.info("TaskList._getSavedSearches EXIT >>", view);
            },
            _filterItems: function (view) {
                bpmext.log.info("TaskList._filterItems ENTER >>");
                var filteredResults=[], x;

                if(view._instance.recents){
                    var filteredRecents = view._instance.recents.filter(function(item){
                        return item.toLowerCase().includes(view._instance.filterCondition.toLowerCase());
                    });
                    if(filteredRecents.length>0) {
                        filteredResults.push({
                            itemType: "H",
                            itemText: "<div><span>" + bpmext.localization.formatMsg("SearchBar", "recentHeader") + "<a class='clearAll'>"+bpmext.localization.formatMsg("SearchBar", "clearAll")+"</a></span></div>"
                        });
                        for (x = 0; x < filteredRecents.length; x++) {
                            filteredResults.push({
                                command: {isSavedSearch:false, index:x+1+"", display:filteredRecents[x]},
                                itemType: "L",
                                itemText: filteredRecents[x],
                                icon: "ci-close"
                            });
                        }
                    }
                }
                if(view._instance.searches){
                    var filteredSearches = view._instance.searches.filter(function(item){
                        return item.display.toLowerCase().includes(view._instance.filterCondition.toLowerCase());
                    });
                    if(filteredSearches.length>0) {
                        filteredResults.push({
                            itemType: "H",
                            itemText: "<div><span>" + bpmext.localization.formatMsg("SearchBar", "savedSearchesHeader") + "<a class='viewAll'>"+bpmext.localization.formatMsg("SearchBar", "viewAll")+"</a></span></div>"
                        });
                        var amountOfResults = filteredSearches.length > 10 ? 10 : filteredSearches.length;
                        for (x = 0; x < amountOfResults; x++) {
                            filteredResults.push({
                                command: {isSavedSearch:true, ID:filteredSearches[x].ID, display:filteredSearches[x].display},
                                itemType: "L",
                                itemText: filteredSearches[x].display
                            });
                        }
                    }
                }

                view._instance.dropDownMenu.setMenuItems((view._instance.filterCondition && filteredResults.length>0) ? filteredResults:view._instance.menuItems);
                view._proto._addClearAllHandler(view);
                view._proto._addViewAllHandler(view);
                view._proto._addDeleteIconClass(view);
                view._proto._setWidth(view, true);
                bpmext.log.info("TaskList._filterItems EXIT >>", view);
            },
            _setWidth: function (view, keepVisible) {
                bpmext.log.info("TaskList._setWidth ENTER >>");
                var searchBarDom = view._instance.searchLayout.context.element;
                var dropDownDom = view._instance.dropDownMenu._getMenuDom();
                if (searchBarDom.offsetWidth > dropDownDom.offsetWidth) {
                    domStyle.set(dropDownDom, "width", searchBarDom.offsetWidth + "px");
                } else {
                    domStyle.set(searchBarDom, "width", dropDownDom.offsetWidth + "px");
                }
                if (!keepVisible) {
                    view._instance.dropDownMenu.setTargetElement(view._instance.searchLayout.context.element);
                    view._instance.dropDownMenu.setMenuVisible(false);
                    view._instance.dropDownMenu.setMenuVisible(true);
                }
                setTimeout(function() { view._instance.searchBar._instance.text.focus(); });
                bpmext.log.info("TaskList._setWidth EXIT >>", view);
            },
            _unsetWidth: function (view) {
                bpmext.log.info("TaskList._unsetWidth ENTER >>");
                var searchBarDom = view._instance.searchLayout.context.element;
                var dropDownDom = view._instance.dropDownMenu._getMenuDom();
                domClass.remove(searchBarDom, "expandedSearch");
                domStyle.set(dropDownDom, "width", "unset");
                domStyle.set(searchBarDom, "width", "unset");
                bpmext.log.info("TaskList._unsetWidth EXIT >>", view);
            },
            _addDeleteIconClass: function (view) {
                bpmext.log.info("TaskList._addDeleteIconClass ENTER >>");
                var dropDownDom = view._instance.dropDownMenu._getMenuDom();
                var itemListDom = dropDownDom.querySelectorAll(".dropdown-icon.ci");
                for (var x = 0; x < itemListDom.length; x++) {
                    domClass.add(itemListDom[x], "delete");
                    domAttr.set(itemListDom[x], "tabindex", 0);
                    var deleteIcon = itemListDom[x];
                    deleteIcon.onkeydown = function (e) {
                        if (e.key === "Enter") {
                            e.stopPropagation();
                            e.currentTarget.click();
                        }
                    };
                }
                bpmext.log.info("TaskList._addDeleteIconClass EXIT >>", view);
            },
            _addClearAllHandler: function (view) {
                bpmext.log.info("TaskList._addClearAllHandler ENTER >>");
                var dropDownDom = view._instance.dropDownMenu._getMenuDom();
                var clearAllDom = dropDownDom.querySelector(".dropdown-header span a.clearAll");
                if(clearAllDom){
                    clearAllDom.onclick = function () {
                        view.clearAllRecentSearches();
                        view._proto._setWidth(view);
                        view._instance.searchBar.setText("");
                    };
                    clearAllDom.onkeydown = function (e) {
                        if (e.key === "Enter") {
                            view.clearAllRecentSearches();
                            view._proto._setWidth(view);
                            view._instance.searchBar.setText("");
                        }
                    };
                }
                bpmext.log.info("TaskList._addDeleteIconClass EXIT >>", view);
            },
            _addViewAllHandler: function (view) {
                bpmext.log.info("TaskList._addViewAllHandler ENTER >>");
                var dropDownDom = view._instance.dropDownMenu._getMenuDom();
                var viewAllDom = dropDownDom.querySelector(".dropdown-header span a.viewAll");
                if(viewAllDom){
                    viewAllDom.onclick = function () {
                        view.closeSearchBar();
                        taskUtils.EVENTS.CREATE_SAVED_SEARCH.publish();
                    };
                    viewAllDom.onkeydown = function (e) {
                        if (e.key === "Enter") {
                            view.closeSearchBar();
                            taskUtils.EVENTS.CREATE_SAVED_SEARCH.publish();
                        }
                    };
                }
                bpmext.log.info("TaskList._addDeleteIconClass EXIT >>", view);
            },
            _showDropdown: function (view) {
                bpmext.log.info("TaskList._showDropdown ENTER >>");
                view._instance.dropDownMenu.setMenuItems(view._instance.menuItems);
                view._instance.dropDownMenu.setMenuVisible(true);
                view._instance.searchBar.setVisible(true,true);
                view._instance.closeIcon.setVisible(true,true);
                view._proto._addClearAllHandler(view);
                view._proto._addViewAllHandler(view);
                view._proto._addDeleteIconClass(view);
                domClass.add(view._instance.searchLayout.context.element, "expandedSearch");
                view._proto._setWidth(view);
                view._instance.disableSearchIconClick = false;
                bpmext.log.info("TaskList._showDropdown EXIT >>", view);
            },

            _setSavedSearchPillText: function (view, stringValue) {
                view._instance.savedSearchPillText.setLabel(stringValue);
                view._instance.savedSearchPill.setVisible(true);
            },
            _setFilterPillText: function (view, stringValue) {
                view._instance.filterPillText.setLabel(stringValue);
                view._instance.filterPill.setVisible(true);
            },
            _setFullTextPillText: function (view, stringValue) {
                view._instance.fullTextPillText.setLabel(stringValue);
                view._instance.fullTextPill.setVisible(true);
            },
            _setQuickFilterPillText: function (view, stringValue) {
                view._instance.quickFilterPillText.setLabel(stringValue);
                view._instance.quickFilterPill.setVisible(true);
            },
            _loadAndClearDeferredSection: function _loadSavedSearchDeferredSection(view, modalName) {
                if(view._instance.onPageLoad){
                    view._instance.onPageLoad = false;
                    taskUtils.EVENTS.LOAD_MODAL.publish({showModal:false, modal:modalName, clearFields:true});
                    view._instance.savedSearchPill.setVisible(false,true);
                }
            },
            _removeFullTextPill: function _removeFullTextPill(view, update){
                view._instance.fullTextPill.setVisible(false, true);
                view._instance.searchBar.setText("");
                var opts = view.context.options;
                if(update){
                    view.resetFullTextSearch();
                    if(!opts.instanceMode.get("value")){
                        view._proto._loadAndClearDeferredSection(view, "Saved search");
                    }
                }
            },
            _removeQuickFilterPill: function _removeQuickFilterPill(view, update){
                view._instance.quickFilterPill.setVisible(false, true);
                var opts = view.context.options;
                if(update){
                    if(!view._instance.instanceMode){
                        taskUtils.EVENTS.SET_DEFAULT_STATS.publish();
                    }else{
                        taskUtils.EVENTS.SET_DEFAULT_INSTANCE_STATS.publish();
                    }
                }
            }
        };


        /*
        Public control methods *************************************************************
         */
        /**
         * @instance
         * @memberof SearchBar
         * @method openSearchBar
         * @desc Opens the search bar for inputting full text to search
         */
        this.constructor.prototype.openSearchBar = function openFilter() {
            bpmext.log.info("SearchBar.openSearchBar ENTER >>", this);
            if(!this._instance.disableSearchIconClick && !this._instance.searchBar.isVisible()){
                this._instance.searchBar.setText("");
                this.openDropdown();
            }
            bpmext.log.info("SearchBar.openSearchBar EXIT >>", this);
        };
        /**
         * @instance
         * @memberof SearchBar
         * @method closeSearchBar
         * @desc Closes the search bar for inputting full text to search
         */
        this.constructor.prototype.closeSearchBar = function closeSearchBar() {
            bpmext.log.info("SearchBar.openSearchBar ENTER >>", this);
            this._instance.searchBar.hide(true);
            this._instance.searchBar.setText("");
            this._instance.closeIcon.hide(true);
            this._proto._unsetWidth(this);
            this.hideDropdown();
            bpmext.log.info("SearchBar.openSearchBar EXIT >>", this);
        };
        /**
         * @instance
         * @memberof SearchBar
         * @method openDropdown
         * @desc Opens the dropdown section
         */
        this.constructor.prototype.openDropdown = function openDropdown() {
            bpmext.log.info("SearchBar.openDropdown ENTER >>", this);
            this._proto._loadDropdown(this);
            bpmext.log.info("SearchBar.openDropdown EXIT >>", this);
        };
        /**
         * @instance
         * @memberof SearchBar
         * @method hideDropdown
         * @desc Closes the dropdown section
         */
        this.constructor.prototype.hideDropdown = function openDropdown() {
            bpmext.log.info("SearchBar.hideDropdown ENTER >>", this);
            this._instance.dropDownMenu.setMenuVisible(false);
            bpmext.log.info("SearchBar.hideDropdown EXIT >>", this);
        };
        /**
         * @instance
         * @memberof SearchBar
         * @method filterDropdown
         * @desc Filter the dropdown section
         */
        this.constructor.prototype.filterDropdown = function filterDropdown() {
            bpmext.log.info("SearchBar.filterDropdown ENTER >>", this);
            this._instance.filterCondition = this._instance.searchBar.context.element.querySelector("input").value;
            this._proto._filterItems(this);
            bpmext.log.info("SearchBar.filterDropdown EXIT >>", this);
        };
        /**
         * @instance
         * @memberof SearchBar
         * @param {String} searchTerm The string to execute the full text search
         * @method executeFulltextSearch
         * @desc Execute the full text search
         */
        this.constructor.prototype.executeFulltextSearch = function executeFulltextSearch(searchTerm) {
            bpmext.log.info("SearchBar.filterDropdown ENTER >>", this);
            if (!searchTerm) {
                //There is a new full text search, add to list
                searchTerm = this._instance.filterCondition;
                this._instance.currentItem = searchTerm;
                if (this._instance.filterCondition) {
                    this._instance.recents = this.getRecentBindingArray();

                    var index = this._instance.recents.indexOf(this._instance.filterCondition);
                    if (index > -1) {
                        this._instance.recents.splice(index, 1);
                    }
                    this._instance.recents.unshift(this._instance.filterCondition);
                    if (this._instance.recents.length > 5) {
                        this._instance.recents.pop();
                    }

                    this.setRecentBindingArray(this._instance.recents);
                }
            }

            if (this._instance.instanceMode) {
                taskUtils.EVENTS.MODIFY_INSTANCE_SEARCH_TERM.publish(searchTerm);
                taskUtils.EVENTS.RESET_INSTANCE_FILTER.publish();
                this._proto._setFullTextPillText(this, searchTerm);
            } else {
                if(searchTerm){
                    this._proto._setFullTextPillText(this, searchTerm);
                }
                taskUtils.EVENTS.MODIFY_TASK_SEARCH_TERM.publish(searchTerm);
            }
            this.closeSearchBar();
            bpmext.log.info("SearchBar.filterDropdown EXIT >>", this);
        };
        /**
         * @instance
         * @memberof SearchBar
         * @method executeFulltextSearch
         * @desc Resets the full text search
         */
        this.constructor.prototype.resetFullTextSearch = function resetFullTextSearch() {
            bpmext.log.info("SearchBar.filterDropdown ENTER >>", this);
            if (this._instance.instanceMode) {
                taskUtils.EVENTS.MODIFY_INSTANCE_SEARCH_TERM.publish("");
            } else {
                taskUtils.EVENTS.MODIFY_TASK_SEARCH_TERM.publish("");
            }
            bpmext.log.info("SearchBar.filterDropdown EXIT >>", this);
        };
        /**
         * @instance
         * @memberof SearchBar
         * @method launchItem
         * @param {String} action The item command
         * @desc Launches the item selected
         */
        this.constructor.prototype.launchItem = function launchItem(action) {
            bpmext.log.info("SearchBar.launchItem ENTER >>", this);
            var itemDom = window.event.target, view = this;
            if (domClass.contains(itemDom, "delete") || itemDom.tagName === "svg" || itemDom.tagName === "use") {
                var indexSelected = action.index;
                this.deleteRecentItem(indexSelected - 1);
                this.resetFullTextSearch();
                this._proto._loadDropdown(this);
            } else {
                if (action.isSavedSearch) {
                    this._instance.currentSavedSearch = action.ID;
                    this._instance.currentSavedSearchName = action.display;
                    this.launchSavedSearchByID(action);
                    this._instance.searchBar.setText("");
                    setTimeout(function() {
                        view._instance.savedSearchCloseBtn._instance.btn.focus();
                    }); 
                } else {
                    this.executeFulltextSearch(action.display);
                    setTimeout(function() {
                        this._instance.fullTextCloseBtn._instance.btn.focus();
                    }); 
                }
                this._instance.currentItem = action;
                this.closeSearchBar();
            }
            bpmext.log.info("SearchBar.launchItem EXIT >>", this);
        };
        /**
         * @instance
         * @memberof SearchBar
         * @method launchSavedSearchByID
         * @param {String} data The saved search ID
         * @desc Runs the saved search by ID
         */
        this.constructor.prototype.launchSavedSearchByID = function (data) {
            bpmext.log.info("SearchBar.launchSavedSearchByID ENTER: >>");
            taskUtils.EVENTS.SAVED_SEARCH_LAUNCHED.publish({ search: (data || "") });
            var targetView = this.ui.getParent();
            var option = taskUtils.safeGet(targetView, ["context","options","savedSearchName"]);
            if(!data && option){
                option.set("value","");
            }
        };
        /**
         * @instance
         * @memberof SearchBar
         * @method getCurrentLaunchedItem
         * @desc Get the command of the current item
         */
        this.constructor.prototype.getCurrentLaunchedItem = function () {
            bpmext.log.info("SearchBar.getCurrentLaunchedItem ENTER: >>");
            return this._instance.currentItem;
        };
        /**
         * @instance
         * @memberof SearchBar
         * @method getCurrentSavedSearchLaunched
         * @desc Get the id of the currently launched saved search
         */
        this.constructor.prototype.getCurrentSavedSearchLaunched = function () {
            bpmext.log.info("SearchBar.getCurrentSavedSearchLaunched ENTER: >>");
            return this._instance.currentSavedSearch;
        };
        /**
         * @instance
         * @memberof SearchBar
         * @method deleteRecentItem
         * @param {Number} index The index of item to be deleted
         * @desc Deletes the specified item in the recent searches list
         */
        this.constructor.prototype.deleteRecentItem = function (index) {
            bpmext.log.info("SearchBar.deleteRecentItem ENTER: >>");
            this._instance.recents = this.getRecentBindingArray();
            if (index > -1) {
                this._instance.recents.splice(index, 1);
                this.setRecentBindingArray(this._instance.recents);
            }

        };
        /**
         * @instance
         * @memberof SearchBar
         * @method clearAllRecentSearches
         * @desc Deletes all the recent searches
         */
        this.constructor.prototype.clearAllRecentSearches = function () {
            bpmext.log.info("SearchBar.clearAllRecentSearches ENTER: >>");
            this.setRecentBindingArray([]);
            this.resetFullTextSearch();
            this._proto._loadDropdown(this);
        };
        /**
         * @instance
         * @memberof SearchBar
         * @method getRecentBindingArray
         * @return {List} The binding of recent searches
         * @desc Get the binding of recent searches
         */
        this.constructor.prototype.getRecentBindingArray = function () {
            bpmext.log.info("SearchBar.getRecentBinding ENTER: >>");
            var opts = this.context.options;
            return this._instance.instanceMode ? opts.recentInstanceSearches.get("value").items : opts.recentTaskSearches.get("value").items;
        };
        /**
         * @instance
         * @memberof SearchBar
         * @method setRecentBindingArray
         * @param {List}recentSearchList The binding of recent searches
         * @desc Set the binding of recent searches
         */
        this.constructor.prototype.setRecentBindingArray = function (recentSearchList) {
            bpmext.log.info("SearchBar.setRecentBindingArray ENTER: >>");
            var opts = this.context.options;
            if (this._instance.instanceMode) {
                opts.recentInstanceSearches.set("value", recentSearchList);
            } else {
                opts.recentTaskSearches.set("value", recentSearchList);
            }
        };
        /**
         * @instance
         * @memberof SearchBar
         * @method updatePosition
         * @desc Updates the position of the dropdown
         */
        this.constructor.prototype.updatePosition = function () {
            this._proto._setWidth(this);
        };
        /**
         * @instance
         * @memberof SearchBar
         * @method isExpanded
         * @return {Boolean} true if search bar is expanded
         * @desc Checks if the search bar is expanded
         */
        this.constructor.prototype.isExpanded = function () {
            return this._instance.closeIcon.isVisible();
        };
        /**
         * @instance
         * @memberof SearchBar
         * @method removeCurrentSavedSearch
         * @desc Remove handler for the saved search pill displayed
         */
        this.constructor.prototype.removeCurrentSavedSearch = function (update) {
            this._instance.currentSavedSearch = "";
            this._instance.currentItem = "";
            this._instance.savedSearchPill.setVisible(false, true);
            this._instance.filterPill.setVisible(false,true);
            if(update){
                this._proto._loadAndClearDeferredSection(this, "Saved search");
                this.launchSavedSearchByID();
            }
        };
        /**
         * @instance
         * @memberof SearchBar
         * @method removeQuickFilter
         * @desc Remove handler for the saved search pill displayed
         */
        this.constructor.prototype.removeQuickFilter = function (update) {
            if (!this.checkVisibility()) {
                return;
            }
            this._proto._removeQuickFilterPill(this, true);
        };
        /**
         * @instance
         * @memberof SearchBar
         * @method removeFullText
         * @desc Remove handler for the saved search pill displayed
         */
        this.constructor.prototype.removeFullText = function (update) {
            if (!this.checkVisibility()) {
                return;
            }
            this._proto._removeFullTextPill(this, true);
        };
        /**
         * @instance
         * @memberof SearchBar
         * @method setCurrentSavedSearchPill
         * @desc set handler for the saved search pill displayed
         */
        this.constructor.prototype.setCurrentSavedSearchPill = function (searchId, unsaved) {
            if(searchId && searchId !== ""){
                var view = this, unsavedChar = unsaved ? "*" : "";
                var targetView = view.ui.getParent();
                var option = taskUtils.safeGet(targetView, ["context","options","savedSearchName"]);
                if(searchId === this.getCurrentSavedSearchLaunched()){
                    view._proto._setSavedSearchPillText(view, this._instance.currentSavedSearchName + unsavedChar);
                    if(!unsaved && option){
                        option.set("value",view._instance.currentSavedSearchName);
                        taskUtils.EVENTS.SAVED_SEARCH_PILL_SET.publish({id: view.getCurrentSavedSearchLaunched()});
                        view._instance.filterPill.setVisible(false, true);
                    }
                }else{
                    wpResources.searches.get({ id: searchId }).then(function (search) {
                        if (search) {
                            view._proto._setSavedSearchPillText(view, search.name + unsavedChar);
                            view._instance.currentSavedSearchName = search.name;
                            if(!unsaved && option){
                                option.set("value",view._instance.currentSavedSearchName);
                                taskUtils.EVENTS.SAVED_SEARCH_PILL_SET.publish({id: view.getCurrentSavedSearchLaunched()});
                                view._instance.filterPill.setVisible(false, true);
                            }
                        }
                    });
                }
                view._instance.currentSavedSearch = searchId;
            }
        };
        /**
         * @instance
         * @memberof SearchBar
         * @method removeAllFilter
         * @desc Remove handler for the filter pill displayed
         */
        this.constructor.prototype.removeAllFilter = function (update) {
            if (!this.checkVisibility()) {
                return;
            }

            this._instance.filterCount = 0;
            this._instance.searchBar.setText("");
            var opts = this.context.options;
            if(update){
            	this.resetFullTextSearch();
            	if(opts.instanceMode.get("value")){
                    taskUtils.EVENTS.CLEAR_INSTANCE_FIELDS.publish();
                } else {
                    taskUtils.EVENTS.CLEAR_TASK_FILTERS.publish();
                    this._proto._loadAndClearDeferredSection(this, "Saved search");
                    this.launchSavedSearchByID();
                }
            }

            this._instance.filterPill.setVisible(false, true);
        };

        /**
         * @instance
         * @memberof SearchBar
         * @method checkVisibility
         * @desc Iteratively checking if the current view is visible
         */
        this.constructor.prototype.checkVisibility = function () {
            var view = this;
            while (!!view) {
                if (!view.isVisible()) {
                    return false;
                } else {
                    view = view.context && view.context.parentView();
                }
            }
            return true;
        };
        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function ()
        {
            bpmext.log.info("SearchBar.load ENTER >>", this);

            var view = this, opts = this.context.options;

            if (!opts.recentTaskSearches) {
                bpmext.ui.substituteConfigOption(this, "recentTaskSearches", []);
            }
            if (!opts.recentInstanceSearches) {
                bpmext.ui.substituteConfigOption(this, "recentInstanceSearches", []);
            }
            if (!opts.instanceMode) {
                bpmext.ui.substituteConfigOption(this, "instanceMode", false);
            }

            if (!opts.placeholder) {
                bpmext.ui.substituteConfigOption(this, "placeholder", "");
            }

            if (!opts.showSavedSearches) {
                bpmext.ui.substituteConfigOption(this, "showSavedSearches", false);
            }

            if (!opts.disabledFulltextSearch) {
                bpmext.ui.substituteConfigOption(this, "disabledFulltextSearch", false);
            } 
            
            if (!wpResources.isFederated) {
                view.context.options.disabledFulltextSearch.set("value", true);
            }

            this._instance.onPageLoad = true;
            var targetView = this.ui.getParent();
            var option = taskUtils.safeGet(targetView, ["context","options","savedSearchName"]);
            if (option) {
                var persistedSearch = option.get("value");
                if(persistedSearch){
                    try{
                        wpResources.searches.get({name:persistedSearch}).then(dojo.hitch(view,
                            function(search){
                                if(search){
                                    view.setCurrentSavedSearchPill(search.id, false);
                                }
                            }
                        ));
                    } catch (error) {
                        bpmext.log.error(error.message);
                    }
                }
            }

            this._instance.instanceMode = opts.instanceMode.get("value");

            this._instance.searchLayout = bpmext.ui.getContainer("searchLayout", this);
            this._instance.dropDownMenu = bpmext.ui.getContainer("dropDownMenu", this);
            this._instance.dropDownMenu.context.options.customFocus.set("value", true);
            this._instance.searchIcon = bpmext.ui.getView("searchIcon", this);
            this._instance.searchBar = bpmext.ui.getView("searchBar", this);
            this._instance.closeIcon = bpmext.ui.getView("closeIcon", this);
            this._instance.savedSearchPill = bpmext.ui.getContainer("saveSearchBadge", this);
            this._instance.savedSearchPillText = bpmext.ui.getView("saveSearchBadgeText", this);
            this._instance.savedSearchCloseBtn = bpmext.ui.getView("removeIcon", this);
            this._instance.filterPill = bpmext.ui.getContainer("filterBadge", this);
            this._instance.filterPillText = bpmext.ui.getView("filterBadgeText", this);
            this._instance.fullTextPill = bpmext.ui.getContainer("fullTextBadge", this);
            this._instance.fullTextPillText = bpmext.ui.getView("fullTextBadgeText", this);
            this._instance.fullTextCloseBtn = bpmext.ui.getView("removeIcon3", this);
            this._instance.quickFilterPill = bpmext.ui.getContainer("quickFilterBadge", this);
            this._instance.quickFilterPillText = bpmext.ui.getView("quickFilterBadgeText", this);
            this._instance.tooltip = bpmext.ui.getContainer("Tooltip1", this);
            this._instance.unsavedIndicator = bpmext.ui.getView("unsavedIndicator", this);

            if (view.context.options.disabledFulltextSearch.get("value")) {
                this._instance.searchLayout.setVisible(false, true);
            }
            
            var pHolder = opts.placeholder.get("value");
            if (!pHolder) {
                pHolder = opts.instanceMode.get("value") ? bpmext.localization.formatMsg("instanceList", "searchBarPlaceholder") : bpmext.localization.formatMsg("controlTaskList", "searchBarPlaceholder");
            }
            this._instance.searchBar.setPlaceholder(pHolder);

            this._instance.searchLayout.context.element.setAttribute("role", "search");
            this._instance.searchLayout.context.element.setAttribute("aria-label", pHolder);

            this._instance.searchIcon._instance.btn.onfocus = function() {
                view._instance.searchIcon._instance.btn.removeAttribute("role");
                view._instance.searchIcon._instance.btn.removeAttribute("aria-label");
                view.openSearchBar();
            }

            var searchBarDom = this._instance.searchBar.context.element.querySelector("input");
            domAttr.set(searchBarDom, "role", "searchbox");
            domAttr.set(searchBarDom, "autocomplete", "off");
            searchBarDom.onkeydown = function (e) {
                if (e.key === "Enter") {
                    view.executeFulltextSearch();
                    setTimeout(function() { view._instance.fullTextCloseBtn._instance.btn.focus(); }); 
                    view._instance.searchIcon._instance.btn.tabIndex = 0;
                } else if (e.key === "ArrowUp" || e.key === "Up" || e.key === "ArrowDown" || e.key === "Down") {
                    view._instance.searchIcon._instance.btn.tabIndex = 0;
                    var dropDownElements = taskUtils.getFocusElementList(view._instance.dropDownMenu._instance.menuTbl, true);
                    view._instance.focusIndex = 0;
                    dropDownElements[view._instance.focusIndex].focus();
                } else if (!taskUtils.isElementVisible(view._instance.dropDownMenu._instance.wrapper) && searchBarDom.value === "") {
                    view._instance.dropDownMenu.setMenuVisible(true);
                }
            };
            searchBarDom.onfocus = function() {
                view._instance.searchIcon._instance.btn.tabIndex = -1;
            }
            searchBarDom.onblur = function (e) {
                if(e.relatedTarget !== view._instance.closeIcon._instance.btn && !view._instance.dropDownMenu._instance.menuTbl.contains(e.relatedTarget)) {
                    view.closeSearchBar();
                    setTimeout(function() { view._instance.searchIcon._instance.btn.tabIndex = 0; });
                }
            }
            view._instance.closeIcon._instance.btn.onblur = function (e) {
                if(e.relatedTarget !== searchBarDom) {
                    view.closeSearchBar();
                    setTimeout(function() { view._instance.searchIcon._instance.btn.tabIndex = 0; });
                }
            }
            view._instance.focusIndex = 0;
            view._instance.dropDownMenu._instance.wrapper.onkeydown = function(e) {
                var dropDownElements = taskUtils.getFocusElementList(view._instance.dropDownMenu._instance.menuTbl, true);
                if(e.key === "ArrowUp" || e.key === "Up"){
                    if (dropDownElements[view._instance.focusIndex] === dropDownElements[0]) {
                        view._instance.focusIndex = dropDownElements.length - 1;
                        dropDownElements[view._instance.focusIndex].focus();
                    } else {
                        view._instance.focusIndex = view._instance.focusIndex - 1;
                        dropDownElements[view._instance.focusIndex].focus();
                    }
                } else if (e.key === "ArrowDown" || e.key === "Down") {
                    if (dropDownElements[view._instance.focusIndex] === dropDownElements[dropDownElements.length - 1]) {
                        view._instance.focusIndex = 0;
                        dropDownElements[view._instance.focusIndex].focus();
                    } else {
                        view._instance.focusIndex = view._instance.focusIndex + 1;
                        dropDownElements[view._instance.focusIndex].focus();
                    }				
                } else if (e.key === "Escape" || e.key === "Esc" || e.key === "Tab") {
                    searchBarDom.focus();
                }
            }
            var closeHandler = function closeHandler () { this.closeSearchBar(); };

            taskUtils.EVENTS.LOAD_STACK_PANE.subscribe(function(eventName, eventData){
                if(eventData.showModal){
                    view.closeSearchBar();
                }
            }, this);
            taskUtils.EVENTS.TASK_LAUNCHED.subscribe(closeHandler, this);
            taskUtils.EVENTS.SERVICE_LAUNCHED.subscribe(closeHandler, this);
            taskUtils.EVENTS.CLOSE_SEARCH_BAR.subscribe(closeHandler, this);

            if(opts.instanceMode.get("value")){
                taskUtils.EVENTS.SET_INSTANCE_BADGE.subscribe(function (eventName, eventData){
                    if (!this.checkVisibility()) {
                    	return;
                	}
                    if(eventData && eventData.text){
                        view._proto._setQuickFilterPillText(view, eventData.text);
                    }else{
                        view._proto._removeQuickFilterPill(view, true);
                    }
                }, this);
            }else{
                taskUtils.EVENTS.SET_TASK_BADGE.subscribe(function (eventName, eventData){
                    if (!this.checkVisibility()) {
                    	return;
                	}
                    if(eventData.clearSS){
                        view.removeCurrentSavedSearch(false);
                        if(eventData.text){
                            view._proto._setFilterPillText(view, eventData.text);
                        }else{
                            view.removeAllFilter(true);
                        }
                    }else if(!view._instance.savedSearchPill.isVisible()){
                        if(eventData.text){
                            view._proto._setFilterPillText(view, eventData.text);
                        }else{
                            view.removeAllFilter(false);
                        }
                    }
                }, this);
                taskUtils.EVENTS.SET_QUICK_FILTER.subscribe(function (eventName, eventData){
                    if (!this.checkVisibility()) {
                    	return;
                	}
                    if(eventData && eventData.text){
                        view._proto._setQuickFilterPillText(view, eventData.text);
                    }else{
                        view._proto._removeQuickFilterPill(view, true);
                    }
                }, this);
                taskUtils.EVENTS.SAVED_SEARCH_LAUNCHED.subscribe(function (eventName, eventData) {
                    if (!this.checkVisibility()) {
                    	return;
                	}
                    if (eventData && eventData.search) {
                        view.setCurrentSavedSearchPill(eventData.search.ID || eventData.search.id, false);
                        if(view._instance.filterPill.isVisible()){
                            view.removeAllFilter(false);
                        }
                    }else{
                        view.removeCurrentSavedSearch(false);
                    }
                }, this);
                taskUtils.EVENTS.SET_SS_UNSAVED.subscribe(function (eventName, eventData){
                    if (!this.checkVisibility()) {
                    	return;
                	}
                    if(eventData){
                        view.setCurrentSavedSearchPill(view.getCurrentSavedSearchLaunched(),true);
                    }else{
                        view.setCurrentSavedSearchPill(view.getCurrentSavedSearchLaunched());
                    }
                }, this);
            }

            taskUtils.EVENTS.SAVED_SEARCH_CLEARED.subscribe(function () {
                if(opts.instanceMode.get("value")){
                    view._instance.quickFilterPill.setVisible(false,true);
                }
                view._instance.savedSearchPill.setVisible(false,true);
                var targetView = view.ui.getParent();
                var option = taskUtils.safeGet(targetView, ["context","options","savedSearchName"]);
                if(option){
                    option.set("value","");
                }
            }, this);

            this.loadContainer(this);

            bpmext.log.info("SearchBar.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try
            {
                utilities.handleVisibility(this.context);
            }
            catch (e)
            {
                //{#feature: US-1330 Added RT localization}
                //bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e, this);
                if (e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    //bpmext.log.error("  Call stack: " + e.stack);
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack), this);
                }
            }
        };

        this.constructor.prototype.change = function (event)
        {
            bpmext.log.info("SearchBar.change ENTER >> (event): " + event, this);
            if (event && event.type === "config") {
                switch (event.property) {
                    case "_metadata.visibility": {
                        this.view();
                        break;
                    }
                    case "placeholder": {
                        this._instance.searchBar.setPlaceholder(event.newVal);
                        break;
                    }
                    case "disabledFulltextSearch": {
                        if (this._instance.searchLayout) {
                            this._instance.searchLayout.setVisible(!event.newVal, true);
                        }
                        break;
                    }
                }
            }
            bpmext.log.info("SearchBar.change ENTER >>", this);
        };

        this.constructor.prototype.unload = function ()
        {
            bpmext.ui.unloadView(this);
        };
    }
};