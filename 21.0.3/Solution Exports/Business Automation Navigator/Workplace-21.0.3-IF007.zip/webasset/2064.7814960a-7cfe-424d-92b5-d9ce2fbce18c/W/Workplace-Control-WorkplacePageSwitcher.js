/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof WorkplacePageSwitcher
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof WorkplacePageSwitcher
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof WorkplacePageSwitcher
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof WorkplacePageSwitcher
 * @method setData
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 * </table>
 */
workplace_control_InitWorkplacePageSwitcher = function (utilities, taskUtils, wpResources, resourceUtils, domClass) {
    "use strict";
    this._instance = {
        servicesList: {}, 
        urlsList: {}
    };

    if (!this.constructor.prototype._proto) {
        this.constructor.prototype._proto = {
            ACTIONS: {
                BEFORE_VIEW_WORKPLACE: {
                    type: "page",
                    value: "Workplace",
                    label: bpmext.localization.formatMsg("workplace", "workplace"),
                    icon: "ci-workspace",
                    command: taskUtils.EVENTS.BEFORE_VIEW_WORKPLACE
                },
                BEFORE_VIEW_TEAM_DASHBOARD: {
                    type: "page",
                    value: "TeamDashboard",
                    label: bpmext.localization.formatMsg("TeamDashboard", "TeamDashboard"),
                    icon: "ci-events",
                    command: taskUtils.EVENTS.BEFORE_VIEW_TEAM_DASHBOARD
                },
                ACTION_CREATE_WORKSTREAM: {
                    type: "service",
                    value: "createWorkstream",
                    label: bpmext.localization.formatMsg("workstream", "DEFINITIONS"),
                    icon: "ci-network-3",
                    relatedItemId: taskUtils.Workstream_CSHS_ITEM_ID.DEFINITIONS,
                    command: taskUtils.EVENTS.SERVICE_LAUNCHED

                },
                ACTION_VIEW_MANAGE_TEAMS: {
                    type: "service",
                    value: "manageTeams",
                    label: bpmext.localization.formatMsg("workstream", "TEAMS"),
                    icon: "ci-events",
                    relatedItemId: taskUtils.Workstream_CSHS_ITEM_ID.TEAMS,
                    command: taskUtils.EVENTS.SERVICE_LAUNCHED
                }, 
                ACTION_VIEW_CUSTOM_DASHBOARD:{
                    type: "service",
                    value: "viewCustomDashboard",
                    label: "",
                    icon: "ci-dashboard",
                    command: taskUtils.EVENTS.SERVICE_LAUNCHED
                },
                ACTION_EMAIL_NOTIFICATION: {
                    label: bpmext.localization.formatMsg("EmailNotificationModal", "emailNotification"),
                    icon: "ci-email",
                    command: taskUtils.EVENTS.SET_EMAIL_NOTIFICATION
                }
            },

            ACTIONS_SEQUENCE: ["BEFORE_VIEW_WORKPLACE", "SEPARATOR", "ACTION_EMAIL_NOTIFICATION", "SEPARATOR"],

            /********* LOAD SERVICES START ********/
            _setExternalServices: function _setExternalServices(view) {
                if (view.isRetrieveServicesDisabled()) {
                    view._instance.servicesList = [];
                    view._proto._updateMenuItems(view);
                } else {
                    view._proto._fetchExternalServices(view);
                }
            },

            _fetchExternalServices: function _fetchExternalServices(view) {
                var fetchError = function (error) {
                    !!error && !!error.errorMessage && taskUtils.publishError(error.errorMessage);
                    bpmext.log.error("ERROR >> There was an error fetching dashboards: " + error);
                };

                wpResources.config.get().then(function(config) {
                    var options = {
                        excludeReferencedFromToolkit: !!config.excludeReferencedFromToolkit,
                        includeDescription: true,
                        subtypes: [
                            wpResources.exposed.SERVICE_SUBTYPE.STARTABLE_SERVICE,
                            wpResources.exposed.SERVICE_SUBTYPE.DASHBOARD,
                            wpResources.exposed.SERVICE_SUBTYPE.URL
                        ]
                    };

                    wpResources.exposed.get(options).then(
                        function (exposedData) {
                            var data = resourceUtils.buildResources(exposedData, options);
                            view._proto._loadDashboards(view, data);
                        },
                        fetchError
                    );
                }, fetchError);
            },

            _loadDashboards: function _loadDashboards(view, data) {
                var action, relatedItemId;
                var serviceAndDashboards = data.dashboards.concat(data.services), urlObjs = data.urls;
                var searchEntries = Object.keys(view._proto.ACTIONS).reduce(function (entries, actionName) {
                    action = view._proto.ACTIONS[actionName];
                    if (action.type === "service" && !!action.relatedItemId) {
                        entries[action.relatedItemId] = actionName;
                    }
                    return entries;
                }, {});

                // register services
                serviceAndDashboards.forEach(function(dashboard) {
                    relatedItemId = searchEntries[dashboard.itemID];
                    if (!!relatedItemId) {
                        view._instance.servicesList[relatedItemId] = dashboard;
                    }else{
                        view._instance.servicesList[dashboard.itemID] = dashboard;
                    }
                });
                urlObjs.forEach(function (urlObj) {
                    view._instance.urlsList[urlObj.itemID] = urlObj;
                });

                view._proto._updateMenuItems(view);
                view._instance.initialized = true;

                if(view._instance.pendingOpenPageEvent) {
                    view._proto._openPage(view, view._instance.pendingOpenPageEvent.eventData);
                    view._instance.pendingOpenPageEvent = null;
                }
            },
            /********* LOAD SERVICES END ********/




            /********* INIT SETTINGS START ********/
            _initSettings: function _initSettings(view) {
                var currentViewIdent = taskUtils.viewHistory.getViewRootIdent();

                // as the workplace is the main page by default
                if (!currentViewIdent) {
                    // set ident only when the root ident is not set
                    taskUtils.viewHistory.setViewRootIdent(view._proto.ACTIONS.BEFORE_VIEW_WORKPLACE.value);
                }
            },
            /********* INIT SETTINGS END ********/




            /********* INIT POPUP MENU START ********/
            _initPopupMenu: function _initPopupMenu(view) {
                //Attach popup menu to target element
                view._instance.anchorElement = view._proto._getAnchorElement(view);
                view._instance.popupMenu.setTargetElement(view._instance.anchorElement);

                view._proto._updateMenuItems(view);
            },

            _getAnchorElement: function _getAnchorElement(view) {
                return view._instance.menuIcon.context.element.querySelector('.btn[role="button"]');
            },

            _updateMenuItems: function _updateMenuItems(view) {
                view._instance.menuItems = view._proto._getMenuItems(view);
                
                // hide the icon if there is less than one item showing in the pop up
                view._instance.menuIcon.setVisible(view._instance.menuItems.length > 0, true);

                view._instance.popupMenu.removeAllMenuItems();
                view._instance.popupMenu.setMenuItems(view._instance.menuItems);

                // refresh menu position
                if (view._instance.popupMenu.isMenuVisible()) {
                    view._instance.popupMenu.setMenuVisible(false);
                    view._instance.popupMenu.setMenuVisible(true);
                }
            },
            /********* INIT POPUP MENU END ********/




            /********* CONSTRUCTING MENU ITEMS START ********/
            _getMenuItems: function _getMenuItems(view) {
                return taskUtils.compose([
                    function (sequence) {return view._proto._appendActionsToSequence(view, sequence);},
                    function (sequence) {return view._proto._appendServicesToSequence(view, sequence);},
                    function (sequence) {return view._proto._appendSystemActionsToSequence(view, sequence);},
                    function (sequence) {return view._proto._filteringDisabledActions(view, sequence);},
                    view._proto._trimTailingSeparators,
                    function (sequence) {return view._proto._formingMenuItems(view, sequence);},
                ])([view._proto.ACTIONS_SEQUENCE || []]);
            },

            _appendActionsToSequence: function _appendActionsToSequence(view, sequence) {
                sequence = sequence || [];
                if (view.shouldShowTeamPerformanceDashboard()) {
                    sequence = sequence.concat([
                        view._proto.ACTIONS.BEFORE_VIEW_TEAM_DASHBOARD.command.name,
                        "SEPARATOR"
                    ]);
                }

                return sequence;
            },

            _appendSystemActionsToSequence: function _appendSystemActionsToSequence(view, sequence) {
                sequence = sequence || [];
                return sequence;
            },

            _appendServicesToSequence: function _appendServicesToSequence(view, sequence) {
                sequence = sequence || [];
                var customDashboards = [];

                // Move all custom dashboards to the bottom
                Object.keys(view._instance.servicesList).forEach(function (key) {
                    if (key === "ACTION_VIEW_MANAGE_TEAMS" || key === "ACTION_CREATE_WORKSTREAM"){
                        sequence = sequence.concat([key, "SEPARATOR"]);
                    }else if (view._instance.servicesList[key].subtype === "dashboard") {                       
                        customDashboards = customDashboards.concat([key, "SEPARATOR"]);
                    }
                });
                // Get index of darker separators
                view._instance.separator = (sequence.length/2)-1;
                sequence = sequence.concat(customDashboards);

                return sequence;
            },

            _filteringDisabledActions: function(view, sequence) {
                return (sequence || []).reduce(function (seq, action) {
                    if (!view._proto._isActionDisabled(view, action)) {
                        seq.push(action);
                    }
                    return seq;
                }, []);
            },

            _isActionDisabled: function(view, action) {
                var disabledActions = view.getDisabledActions();
                return disabledActions.indexOf(action) >= 0;
            },

            _trimTailingSeparators: function(sequence) {
                return (sequence || []).reverse().reduce(function (seq, action) {
                    // duplicate actions
                    if (seq.length > 0 && seq[seq.length - 1] === action) {
                        return seq;
                    }

                    // tailing SEPARATORs
                    if (seq.length === 0 && action === "SEPARATOR") {
                        return seq;
                    }

                    seq.push(action);
                    return seq;
                }, []).reverse();
            },

            _formingMenuItems: function _formingMenuItems(view, sequence) {
                var curAction, service;

                return (sequence || []).reduce(function(menuItems, action) {
                    if (action === "SEPARATOR") {
                        menuItems.push({
                            itemType: "S"
                        });
                    } else {
                        curAction = view._proto.ACTIONS[action];

                        if (curAction == null) {
                            curAction = view._proto.ACTIONS["ACTION_VIEW_CUSTOM_DASHBOARD"];
                            curAction.label = view._instance.servicesList[action].displayName;
                        }
                        if (curAction.type === "service") {
                            service = view._instance.servicesList[action];
                            curAction.command = dojo.clone(curAction.command);
                            curAction.command.servicesName = curAction.label;
                            curAction.command.execute = function (view, service, displayName) {
                                return function () {
                                    service.displayName = displayName;
                                    view._proto._launchServices(view, service);
                                };
                            }(view, service, curAction.label);
                        }

                        menuItems.push({
                            command: curAction.command,
                            itemType: "L",
                            icon: curAction.icon,
                            itemText: curAction.label
                        });

                    }
                    return menuItems;
                }, []);
            },
            /********* CONSTRUCTING MENU ITEMS END ********/




            /********* PAGE LAUNCHING METHODS START ********/
            _launchWorkplace: function _launchWorkplace() {
                taskUtils.EVENTS.BEFORE_VIEW_WORKPLACE.publish();
            },

            _launchTeamDashboard: function _launchTeamDashboard(view) {
                var teamSummariesDS = bpmext.ui.getContainer("/Workplace_Content_Wrapper1/Team_Dashboard_DS");

                // iteratively check if the deferred view gets loaded,
                // trigger the event after the view gets loaded
                var checkedLoaded = function () {
                    if (!teamSummariesDS.isLoaded()) {
                        view._instance.defferTimeout = setTimeout(function () {
                            checkedLoaded();
                        }, 200);
                    } else {
                        taskUtils.EVENTS.BEFORE_VIEW_TEAM_DASHBOARD.publish();
                        delete view._instance.defferTimeout;
                    }
                };

                // block load events
                if (!!teamSummariesDS && !view._instance.defferTimeout) {
                    // load view if it's not loaded, load it
                    !teamSummariesDS.isLoaded() && teamSummariesDS.lazyLoad(0);

                    checkedLoaded();
                }
            },

            _launchServices: function _launchServices(view, service) {
                var serviceActionId = view._proto._getActionId(view, service.displayName);
                taskUtils.EVENTS.SERVICE_LAUNCHED.publish({
                    view: view,
                    service: service,
                    serviceActionId: serviceActionId,
                    origin: "Workplace_Content_Wrapper1"
                });
            },
            /********* PAGE LAUNCHING METHODS END ********/



            /********* TOOLTIP START ********/
            _appendTooltips: function _appendTooltips(view) {
                var btn = view._instance.menuIcon.context.element.querySelector(".btn.SPARKIcon");
                bpmext.ui.util.showTooltip(
                    btn,
                    bpmext.localization.formatMsg("PageSwitcher", "psTooltip"),
                    {horizontalPos: "RIGHT", verticalPos: "BOTTOM", smartPositioning: true, openDelay: 0.5}
                );
            },
            /********* TOOLTIP END ********/



            /********* SEARCH BAR START ********/
            _refreshMenuItems: function (view) {
                // Refresh menu position
                if (view._instance.popupMenu.isMenuVisible()) {
                    view._instance.popupMenu.setMenuVisible(false);
                    view._instance.popupMenu.setMenuVisible(true);
                }
            },

            _setSearchBarWidth: function (view) {
                var menuIconSize = view._instance.menuIcon.context.element.offsetWidth + 1;
                var searchIconSize = view._instance.searchIcon.context.element.offsetWidth;
                var width = view._instance.popupMenu._getMenuDom().offsetWidth - menuIconSize - searchIconSize;
                view._instance.searchBar.setWidth("0");
                view._instance.searchBar.setWidth(width);
            },
            /********* SEARCH BAR END ********/

            _openPage: function(view, eventData) {
                //only process if the current page switcher is visible
                var action, command, label, itemId, snapshotId;
                var name = (eventData.data && eventData.data.actionId) ? eventData.data.actionId : eventData.name;

                if (view.isVisible()) {
                    Object.keys(view._proto.ACTIONS).forEach(function(key) {
                        if (view._proto.ACTIONS[key].value === name) {
                            action = view._proto.ACTIONS[key];
                            label = action.label;
                        }
                    });
                    
                    if (eventData.data && eventData.data.isPreview) {
                    	taskUtils.EVENTS.LAUNCH_FROM_PREVIEW.publish();
                    }
                    label = eventData.name, itemId = eventData.data && eventData.data.itemID, snapshotId = eventData.data && eventData.data.snapshotID;
                    if ((!action || action === view._proto.ACTIONS.ACTION_VIEW_CUSTOM_DASHBOARD) && eventData.type === "dashboard") {
                        action = view._proto.ACTIONS.ACTION_VIEW_CUSTOM_DASHBOARD;
                        var foundItem = view._instance.servicesList[itemId];
                        if (foundItem) {
                        	if (snapshotId && foundItem.snapshots && foundItem.snapshots.length > 0) {
                        		for (var i=0; i < foundItem.snapshots.length; i++) {
                        			if (snapshotId === foundItem.snapshots[i].snapshotID) {
                        				view._proto._launchServices(view,foundItem.snapshots[i]);
                        				break;
                        			}
                        		}
                        	} else {
                        		view._proto._launchServices(view, foundItem);
                        	}
                        }
                    } else if (eventData.type === "url") {
                        view._proto._launchServices(view, view._instance.urlsList[itemId]);
                    } else if (eventData.type === "task") {
                        //look up task by id and system id then raise event
                        wpResources.task.get({tkiid: eventData.data.tkiid, includeURL: true, systemID: eventData.data.systemID}).then(function(task) {
                            taskUtils.EVENTS.TASK_BEFORE_LAUNCH.publish({task: task});
                        }, 
                        function() 
                        {
                            taskUtils.publishAlert({title: "", text: bpmext.localization.formatMsg("Errors", "launchTask"), timeout: 5000});
                        });
                    } else if (eventData.type === "instance" || eventData.type === "case") {

                        if (eventData.data.type === wpResources.processes.TYPE.CASES) {
                            //case
                            if (eventData.name) {
                                eventData.data.name = eventData.name;
                            }
                            if (eventData.data.runURL) {
                                taskUtils.EVENTS.SERVICE_LAUNCHED.publish(eventData.data);
                            }

                        } else {
                            //process
                            //look up instance by id and system id then raise event
                            wpResources.process.get({piid: eventData.data.piid, systemID: eventData.data.systemID}).then(
                                function(instance) {
                                    var curSystemInfo, runURLPrefix = dojoConfig.App._bpmContextRootMap.teamworks;
                                    if(eventData.data.systemID) {
                                        curSystemInfo = resourceUtils.getFederatedSystemInfo(eventData.data.systemID);
                                        runURLPrefix = curSystemInfo.taskCompletionUrlPrefix;
                                    }
                                    instance.runURL = runURLPrefix + "/launchInstanceUI?origin=workplace&instanceId=" + instance.piid;

                                    taskUtils.EVENTS.SERVICE_LAUNCHED.publish(instance);
                                }, 
                                function() 
                                {
                                    taskUtils.publishAlert({title: "", text: bpmext.localization.formatMsg("Errors", "launchWorkflow"), timeout: 5000});
                                }
                            );
                        }
                    } else {
                        command = dojo.clone(action.command);
                        command.servicesName = label || "";
                        view.proceedCommand("", command);
                    }
                }

            },

            _getActionId: function(view, label) {
                var actionId = null;
                Object.keys(view._proto.ACTIONS).forEach(function(key) {
                    if (view._proto.ACTIONS[key].label === label) {
                        actionId = view._proto.ACTIONS[key].value;
                    }
                });
                return actionId;
            },

            _addIframeLoadEvent: function(view) {
                // Get launchTaskViewer iframe then the iframe inside that
                var iframe = document.getElementsByTagName("iframe");
                if(iframe.length != 0){
                    var innerIframe = iframe[0].contentWindow.document.getElementsByTagName("iframe");
                    if (innerIframe.length != 0){
                        innerIframe[0].contentWindow.document.onclick = function() {
                            if (!view.context.element.contains(e.target) && view._instance.popupMenu.isMenuVisible()){
                                view._instance.popupMenu.setMenuVisible(false, true);
                                view._instance.searchLayout.setVisible(false,true);
                            } 
                        };
                    }else{
                        iframe[0].contentWindow.document.onclick = function() {
                            if (!view.context.element.contains(e.target) && view._instance.popupMenu.isMenuVisible()){
                                view._instance.popupMenu.setMenuVisible(false, true);
                                view._instance.searchLayout.setVisible(false,true);
                            } 
                        };
                    }
                }
            }
        };

        /**
         * @instance
         * @memberof WorkplacePageSwitcher
         * @method setDisabledActions
         * @desc Set disabled actions
         */
        this.constructor.prototype.setDisabledActions = function setDisabledActions(actions) {
            this.context.options.disableActions.set("value", actions);
        };

        /**
         * @instance
         * @memberof WorkplacePageSwitcher
         * @method getDisabledActions
         * @desc Get a list of disabled actions
         */
        this.constructor.prototype.getDisabledActions = function getDisabledActions() {
            var disableActions = this.context.options.disableActions.get("value");
            return (disableActions && disableActions.items) || [];
        };

        /**
         * @instance
         * @memberof WorkplacePageSwitcher
         * @method showPopupMenu
         * @desc Function to open the actions menu
         */
        this.constructor.prototype.showPopupMenu = function showPopupMenu() {
            if(!this._instance.popupMenu.isMenuVisible()){
                this._proto._updateMenuItems(this);
                this._instance.popupMenu.setMenuVisible(true, true);
                if(this._instance.menuItems.length/2 > 8){
                    this._instance.searchBar.setText("");
                    this._instance.searchLayout.setVisible(true, true);
                    this._proto._setSearchBarWidth(this);
                }
                //Add darker separators between custom dashboards
                var items = document.querySelectorAll(".Popup_Menu.dropdown-menu.open[data-menuidpath*='Page_Switcher'] div.divider");
                if (items[this._instance.separator]) {
                    domClass.add(items[this._instance.separator], "darker");
                }
            }else{
                //Remove darker separators between custom dashboards
                var items = document.querySelectorAll(".Popup_Menu.dropdown-menu.open[data-menuidpath*='Page_Switcher'] div.divider");
                if (items[this._instance.separator]) {
                    domClass.remove(items[this._instance.separator], "darker");
                }
                this._instance.popupMenu.setMenuVisible(false, true);
                this._instance.searchLayout.setVisible(false,true);
            }
        };

        /**
         * @instance
         * @memberof WorkplacePageSwitcher
         * @method onPopupMenuShow
         * @desc Function triggered when menu shows up
         */
        this.constructor.prototype.onPopupMenuShow = function onPopupMenuShow() {
            this._proto._addIframeLoadEvent(this);
            !!this._instance.anchorElement && domClass.add(this._instance.anchorElement, "active");
        };

        /**
         * @instance
         * @memberof WorkplacePageSwitcher
         * @method onPopupMenuClose
         * @desc Function triggered when menu disappears
         */
        this.constructor.prototype.onPopupMenuClose = function onPopupMenuClose() {
            !!this._instance.anchorElement && domClass.remove(this._instance.anchorElement, "active");
        };

        /**
         * @instance
         * @memberof WorkplacePageSwitcher
         * @method proceedCommand
         * @desc Function triggered when menu item being clicked
         */
        this.constructor.prototype.proceedCommand = function proceedCommand(target, command) {
            if (command.name === this._proto.ACTIONS.ACTION_EMAIL_NOTIFICATION.command.name) {
                taskUtils.EVENTS.SET_EMAIL_NOTIFICATION.publish(this);
                this._instance.popupMenu.setMenuVisible(false, true);
                this._instance.searchLayout.setVisible(false,true);
            } else {
                var currentViewIdent, newViewIdent, rootSwitched, notOnRootPage;
                var viewHistory = taskUtils.viewHistory.getViewHistory();

                currentViewIdent = taskUtils.viewHistory.getViewRootIdent();
                newViewIdent = command.servicesName || this._proto.ACTIONS[command.name].value;

                rootSwitched = newViewIdent !== null && currentViewIdent !== newViewIdent;
                notOnRootPage = viewHistory.length > 1;

                // make sure that click on the page where you at will not trigger any events
                if (rootSwitched || notOnRootPage) {
                    bpmext.log.info("UPDATE Workplace_Content_Selector from" + currentViewIdent + " to " + newViewIdent);

                    taskUtils.viewHistory.setViewRootIdent(newViewIdent);
                    taskUtils.EVENTS.ROOT_CONTENT_SWITCHED.publish({activeCommand: command});

                    // Refresh launch list if coming from 'Manage workstream teams' dashboard
                    if (currentViewIdent === "Manage workstream teams"){
                        taskUtils.EVENTS.FORCED_REFRESH.publish();
                    }

                    // flush all histories when page gets switched
                    taskUtils.viewHistory.resetViewHistory();

                    if (command.name === this._proto.ACTIONS.BEFORE_VIEW_WORKPLACE.command.name) {
                        this._proto._launchWorkplace(this);
                    } else if (command.name === this._proto.ACTIONS.BEFORE_VIEW_TEAM_DASHBOARD.command.name) {
                        this._proto._launchTeamDashboard(this);
                    } else if (!!command.servicesName && !!command.execute) {
                        command.execute();
                    }
                    this._instance.popupMenu.setMenuVisible(false, true);
                    this._instance.searchLayout.setVisible(false, true);
                }
            };
        };

        /**
		 * @instance
		 * @memberof WorkplacePageSwitcher
		 * @method shouldShowTeamPerformanceDashboard
		 * @desc Determine to show the team performance dashboard or not
		 */
		this.constructor.prototype.shouldShowTeamPerformanceDashboard = function() {
            return wpResources.isFederated;
        };

        /**
		 * @instance
		 * @memberof WorkplacePageSwitcher
		 * @method isRetrieveServicesDisabled
		 * @desc Whether the retrieve services action is disabled
		 */
		this.constructor.prototype.isRetrieveServicesDisabled = function isRetrieveServicesDisabled() {
            return this.context.options.disableRetrieveServices.get("value");
        };

        /**
		 * @instance
		 * @memberof WorkplacePageSwitcher
		 * @method setRetrieveServicesDisabled
		 * @desc Set retrieve services action disabled or not
		 */
		this.constructor.prototype.setRetrieveServicesDisabled = function setRetrieveServicesDisabled(enable) {
            !!this.context.options.disableRetrieveServices && this.context.options.disableRetrieveServices.set("value", !!enable);
        };

        /**
		 * @instance
		 * @memberof WorkplacePageSwitcher
		 * @method filterItems
		 * @desc Filter items in the pop-up menu
		 */
		this.constructor.prototype.filterItems = function filterItems() {
            var menuItems = this._instance.menuItems, addSeparator = false;
            var searchBar = this._instance.searchBar._instance.text;
            var searchTerm = this._instance.searchBar.context.element.querySelector("input").value;
            var filteredItems = menuItems.filter(function(item){
                if (item.itemText){
                    if (item.itemText.toLowerCase().includes(searchTerm.toLowerCase())){
                        addSeparator = true;
                        return item;
                    }
                }else if (addSeparator){
                    addSeparator = false;
                    return item;
                }
            });

            filteredItems = this._proto._trimTailingSeparators(filteredItems);
            this._instance.popupMenu.removeAllMenuItems();
            this._instance.popupMenu.setMenuItems(filteredItems);

            this._proto._refreshMenuItems(this);
            this._proto._setSearchBarWidth(this);

            setTimeout(function() { searchBar.focus(); });
        };

        /**
         * @instance
         * @memberof WorkplacePageSwitcher
         * @method logout
         * @desc Log out from Workplace
         */
        this.constructor.prototype.logout = function logout() {
            var task = this._instance.potentialReassignFromNextTaskDashboard;
            // if it's next task dashboard and return task to team on logout is configured as true, return the task to team before logout.
            if(task) {
                wpResources.user.get().then(function(currentUser) {
                    if (currentUser.showNextTaskDashboard && currentUser.returnTaskToTeamOnLogout && task.state === "STATE_CLAIMED" && task.owner === currentUser.userName) {
                        wpResources.task.assignBackToGroup(task); 
                    }
                    window.top.location = wpResources.user.getLogoutPage();
                })
            } else {
                window.top.location = wpResources.user.getLogoutPage();
            }
            
        };

        /**
         * @instance
         * @memberof WorkplacePageSwitcher
         * @method redirectToKC
         * @desc Redirect to Knowledge Center
         */
        this.constructor.prototype.redirectToKC = function redirectToKC() {
            window.open("https://ibm.biz/BdfzVZ", "_blank");
        };
        

        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function () {
            bpmext.log.info("WorkplacePageSwitcher.load ENTER >>", this);

            var opts = this.context.options;
            var view = this;

            if (!opts.disableActions) {
                bpmext.ui.substituteConfigOption(this, "disableActions", []);
            }

            if (!opts.disableRetrieveServices) {
                bpmext.ui.substituteConfigOption(this, "disableRetrieveServices", false);
            }

            // Controls
            this._instance.popupMenu = bpmext.ui.getContainer("PopupMenu", this);
            this._instance.menuIcon = bpmext.ui.getView("MenuIcon", this);
            this._instance.searchIcon = bpmext.ui.getView("searchIcon", this);
            this._instance.searchBar = bpmext.ui.getView("searchBar", this);
            this._instance.searchLayout = bpmext.ui.getContainer("searchLayout", this);
            this._instance.getLink = bpmext.ui.getContainer("GetLink", this);
            this._instance.help = bpmext.ui.getView("Help", this);
            this._instance.logout = bpmext.ui.getView("Logout", this);

            if (view.context.isWorkflowPXServer && view.context.isWorkflowPXServer() === true){
                this._instance.logout.setVisible(true, true);
                this._instance.help.setVisible(true, true);
                taskUtils.addTooltip(this._instance.help, bpmext.localization.formatMsg("workplace", "help"), 500);
                taskUtils.addTooltip(this._instance.logout, bpmext.localization.formatMsg("workplace", "logout"), 500);
            }else{
                this._instance.logout.setVisible(false, true);
                this._instance.help.setVisible(false, true);
            }

            // Init controls
            this._proto._initPopupMenu(this);
            this._proto._initSettings(this);
            this._proto._setExternalServices(this);
            //this._proto._appendTooltips(this);

            this._instance.searchBar.context.element.querySelector("input").setAttribute("autocomplete", "off");
            this._instance.searchBar.setPlaceholder(bpmext.localization.formatMsg("PageSwitcher", "searchBarPlaceholder"));
            

            window.addEventListener("click", function(e){
                if (!view.context.element.contains(e.target) && view._instance.popupMenu.isMenuVisible()){
                    view._instance.popupMenu.setMenuVisible(false, true);
                    view._instance.searchLayout.setVisible(false,true);
                } 
            });

            this.loadView(this);

            //Sync selector content if there are used in multiple views
            taskUtils.EVENTS.ROOT_CONTENT_SWITCHED.subscribe(function() {
                // Do sync if needed
            }, this);

            //subscribe to open page requests to enable URL addressability
            taskUtils.EVENTS.OPEN_PAGE.subscribe(function(eventName,  eventData) {
                if (!view._instance.initialized) {
                    view._instance.pendingOpenPageEvent  = {eventData: eventData};
                } else {
                    view._proto._openPage(view, eventData);
                }
            }, view);

            //subscribe to the copy link event to copy the link
            taskUtils.EVENTS.COPY_LINK.subscribe(function() {
                if (view.isVisible() && view.context.getInheritedVisibility() !== "NONE") {
                    view._instance.getLink.copyLink();
                }
            }, view);

            view._instance.potentialReassignFromNextTaskDashboard = null;
            taskUtils.EVENTS.POTENTIAL_REASSIGN_BACK_TO_TEAM.subscribe(function(eventName,  eventData) {
                if (eventData.reassignTask) {
                    view._instance.potentialReassignFromNextTaskDashboard = eventData.reassignTask;
                }
            }, view);
        };

        this.constructor.prototype.view = function () {
            try {
                utilities.handleVisibility(this.context);
            } catch (e) {
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e, this);
                if (e.stack) {
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack), this);
                }
            }
        };

        this.constructor.prototype.change = function (event) {
            bpmext.log.info("WorkplacePageSwitcher.change ENTER >> (event): " + event, this);
            if (event.type === "config") {
                switch (event.property) {
                    case "_metadata.visibility": {
                        this.view();
                        break;
                    }
                    case "disableActions": {
                        this._proto._updateMenuItems(this);
                        break;
                    }
                    case "disableRetrieveServices": {
                        this._proto._setExternalServices(this);
                        break;
                    }
                }
            }
            bpmext.log.info("WorkplacePageSwitcher.change ENTER >>", this);
        };

        this.constructor.prototype.unload = function () {
            bpmext.log.info("WorkplacePageSwitcher.unload ENTER >> ", this);
            bpmext.ui.unloadView(this);
        };
    }
};
