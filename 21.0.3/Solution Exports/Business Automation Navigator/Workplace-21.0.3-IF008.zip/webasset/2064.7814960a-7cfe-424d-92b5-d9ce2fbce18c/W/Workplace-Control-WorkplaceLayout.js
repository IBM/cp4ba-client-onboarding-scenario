/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof WorkplaceLayout
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof WorkplaceLayout
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof WorkplaceLayout
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof WorkplaceLayout
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof WorkplaceLayout
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof WorkplaceLayout
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof WorkplaceLayout
 * @method triggerFormulaUpdates
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 * </table>
 */
workplace_control_InitWorkplaceLayout = function (utilities, domClass, taskUtils, wpResources)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            _generateHistoryCallbacks: function _generateHistoryCallbacks (view) {
                var onViewRestore = function (forcedRefresh) {
                    if (!view.isVisible()) {
                        if(forcedRefresh) {
                            view.refresh();
                        }

                        taskUtils.EVENTS.BEFORE_VIEW_WORKPLACE.publish();
                    }
                };

                var onViewClose = function () {
                    if (view.isVisible()) {
                        view.setVisible(false, true);
                    }
                };

                return {
                    identifier: "WorkplaceLayout",
                    displayName: bpmext.localization.formatMsg("workplace", "workplace"),
                    onViewRestore: onViewRestore,
                    onViewClose: onViewClose
                };
            },

            _localization: function _localization(view) {
                var taskTabTitle = bpmext.localization.formatMsg("workplace", "tasksTitle");
                wpResources.user.get().then(function(currentUser) {
                	if (currentUser.showNextTaskDashboard) {
                		taskTabTitle = bpmext.localization.formatMsg("workplace", "nextTaskTitle");
                        view._instance.statisticsIcon.setVisible(false, true);
                        view._instance.statistics.setVisible(false, true);
                        view._instance.isNextTaskMode = true;
                        if (currentUser.autoClaimNextTask) {
                        	// if auto-claim next task, hide workflow tab
                        	view._instance.tabSection.setPaneVisible(false, [1]);
                        }
                	} 
                	view._instance.tabSection.setTabText(taskTabTitle, 0);
                })           
                view._instance.tabSection.setTabText(bpmext.localization.formatMsg("workplace", "workflowsTitle"), 1);
                taskUtils.addTooltip(view._instance.copyLinkIcon, bpmext.localization.formatMsg("workplace", "copyLink"), 500);
            }
        };


        /*
        Public control methods *************************************************************
         */
		this.constructor.prototype.refresh = function() {
			taskUtils.EVENTS.FORCED_REFRESH.publish();
		};

        /**
		 * @instance
		 * @memberof WorkplaceLayout
		 * @method searchHandler
		 * @desc Publishes the event to task list to filter by the search text value
		 */
		this.constructor.prototype.searchHandler = function() {
            taskUtils.EVENTS.MODIFY_TASK_SEARCH_TERM.publish(this._instance.searchBoxView.getText());
        };

        /**
		 * @instance
		 * @memberof WorkplaceLayout
		 * @method loadSavedSearch
		 * @desc Load saved search stack
         */
        this.constructor.prototype.loadSavedSearch = function() {
            this._instance.showModal && this._instance.taskList.openFilter();
            this._instance.clearFields && taskUtils.EVENTS.CLEAR_TASK_FIELDS.publish();
        };

        /**
		 * @instance
		 * @memberof WorkplaceLayout
		 * @method loadInstanceFilter
		 * @desc Load instance filter stack
         */
        this.constructor.prototype.loadInstanceFilter = function() {
            this._instance.modal = "Instance filter";
            taskUtils.EVENTS.LOAD_MODAL.publish({showModal:true, modal:"Instance filter"});
            //taskUtils.EVENTS.LOAD_STACK_PANE.publish({targetView:"Instance_Search_Filter1"});
            this._instance.instanceList = bpmext.ui.getView("Instance_list1", this);
            this._instance.instanceList.openFilter();
        };
        
        this.constructor.prototype.instanceLoaded = function() {
            this._instance.instanceList = bpmext.ui.getView("Instance_list1", this);
            if (this._instance.isPreview) {
            	this._instance.instanceList.hideStartBtn();
            }
        };

        /**
		 * @instance
		 * @memberof WorkplaceLayout
		 * @method addWorkflowButtonClicked
		 * @desc create a new workStream
		 */
        this.constructor.prototype.addWorkflowButtonClicked = function() {
            this._instance.modal = "Launch list";
            taskUtils.EVENTS.LOAD_STACK_PANE.publish({targetView:"Launch_list"});
            taskUtils.EVENTS.OPEN_CONFIG.publish();
        };

        /**
		 * @instance
		 * @memberof WorkplaceLayout
		 * @method openModal
		 * @desc Open modal
		 */
        this.constructor.prototype.openModal = function() {
            if(this._instance.modal === "Launch list"){
                taskUtils.EVENTS.LOAD_STACK_PANE.publish({targetView:"Launch_list"});
            }else if(this._instance.modal === "Saved search"){
                taskUtils.EVENTS.LOAD_STACK_PANE.publish({targetView:"SavedSearch_Builder1", showModal:this._instance.showModal});
            }else if(this._instance.modal === "Instance filter"){
                taskUtils.EVENTS.LOAD_STACK_PANE.publish({targetView:"Instance_Search_Filter1"});
            }
        };

        /**
		 * @instance
		 * @memberof WorkplaceLayout
		 * @method onTabChanged
		 * @desc on tab changed
		 */
        this.constructor.prototype.onTabChanged = function() {
        	//closes the search bar if opened
            taskUtils.EVENTS.CLOSE_SEARCH_BAR.publish();
            if(this._instance.tabSection.getCurrentPane() == 1){
                this._instance.statistics._instance.instanceMode = wpResources.isFederated;
            	this._instance.deferredInstanceSection.lazyLoad();
            }else{
                this._instance.statistics._instance.instanceMode = false;
            }
            this._instance.statistics.setActiveFilterFocus();
            taskUtils.EVENTS.SET_STATS.publish();
        };

        /**
		 * @instance
		 * @memberof WorkplaceLayout
		 * @method onClose
		 * @desc on modal close
		 */
        this.constructor.prototype.onClose = function() {
            var activeTab = this._instance.tabSection._instance.navUl.querySelector(".active").firstElementChild.innerText;

            if (this._instance.modal === "Saved search" || this._instance.modal === "Instance filter") {
                if (activeTab === "Tasks") {
                    var savedSearchBtn = this._instance.taskList._instance.savedSearchBuilderLauncher;
                    savedSearchBtn._instance.btn.focus();
                } else if(this._instance.instanceList){
                    var savedSearchBtn = this._instance.instanceList._instance.filtersButton;
                    savedSearchBtn._instance.btn.focus();
                }

            } else {
                if (activeTab === "Tasks") {
                    var workflowBtn = this._instance.taskList._instance.addWorkflowButton;
                    workflowBtn._instance.btn.focus();
                } else if(this._instance.instanceList){
                    var workflowBtn = this._instance.instanceList._instance.startWorkflowBtn;
                    workflowBtn._instance.btn.focus();
                }
            }
        };

        /**
		 * @instance
		 * @memberof WorkplaceLayout
		 * @method copyLink
		 * @desc Copy the link
    	 */
        this.constructor.prototype.copyLink = function() {
            if (this.isVisible() && this.context.getInheritedVisibility() !== "NONE") {
                taskUtils.EVENTS.COPY_LINK.publish();
            }
       };
        
        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function (){
            bpmext.log.info("WorkplaceLayout.load ENTER >>", this);

            var view = this;

            //this._instance.searchBoxView = bpmext.ui.getView("WorkplaceSearch", this);
            //this._instance.searchBoxView.context.options.placeHolder.set("value", bpmext.localization.formatMsg("titleBar", "search"));
            this._instance.pageHeader = bpmext.ui.getView("PageHeaderTitle1", this);
            this._instance.pageHeader._instance.outputText.setAttribute("role", "heading");
            this._instance.pageHeader._instance.outputText.setAttribute("aria-level", "1");
            this._instance.tabSection = bpmext.ui.getContainer("Tab_Section1", this);
            this._instance.informationIcon = bpmext.ui.getView("InformationIcon", this);
            this._instance.taskList = bpmext.ui.getView("Task_List1", this);
            this._instance.statisticsIcon = bpmext.ui.getView("Statistics_Icon", this);
            this._instance.statistics = bpmext.ui.getView("Task_Statistics1", this);
            this._instance.copyLinkIcon = bpmext.ui.getView("CopyLinkIcon", this);
            this._instance.statisticsTooltipText = bpmext.localization.formatMsg("workplace", "hideStatistics");

            this._instance.deferredInstanceSection = bpmext.ui.getContainer("Deferred_Section1", this);
			// setting root history
            var historyCallbacks = this._proto._generateHistoryCallbacks(this);
            taskUtils.viewHistory.addToViewHistory(historyCallbacks);

            taskUtils.EVENTS.BEFORE_VIEW_WORKPLACE.subscribe(function() {
                if (!view.isVisible()) {
                    var historyCallbacks = view._proto._generateHistoryCallbacks(view);
                    taskUtils.viewHistory.addToViewHistory(historyCallbacks);

                    view.setVisible(true, true);
                }
            });
            
            taskUtils.EVENTS.SET_NEXT_TASK_MODE.subscribe(function(eventName, eventData) {
                view._instance.isNextTaskMode = eventData.isNextTaskMode;
                if (view._instance.isNextTaskMode) {
                	view._instance.tabSection.setTabText(bpmext.localization.formatMsg("workplace", "nextTaskTitle"), 0);
                	// if auto claim, need hide the workflow tab
                	if (eventData.autoClaimNextTask) {
                		view._instance.tabSection.setPaneVisible(false, [1]);
                	}
                } else {
                	view._instance.tabSection.setTabText(bpmext.localization.formatMsg("workplace", "tasksTitle"), 0);
                }
            }, this);

            //listen for the task filter event to make sure that the tab is set to the tasks tab when a filter action occurs
            taskUtils.EVENTS.MODIFY_TASK_FILTER.subscribe(function() {
                //view._instance.tabSection.setCurrentPane(0);
            });

            taskUtils.EVENTS.SET_QUICK_FILTER.subscribe(function() {
                view._instance.tabSection.setCurrentPane(0);
            });

            taskUtils.EVENTS.LOAD_MODAL.subscribe(function(eventName, eventData) {
                view._instance.showModal = !!eventData.showModal;
                view._instance.modal = eventData.modal;
                view._instance.clearFields = eventData.clearFields;
                view.openModal();
            });

            // Listen for when the CometD client fails to connect to the server more than 5 times
            taskUtils.EVENTS.COMETD_FAILED_TO_CONNECT.subscribe(function() {
                taskUtils.EVENTS.SHOW_REFRESH_BUTTON.publish();
            });

            //Register callback function for URL addressibility
            this._instance.openPage = function(context) {
                if (context) {
                    taskUtils.EVENTS.OPEN_PAGE.publish(context); 
                    if (context.data && context.data.isPreview) {
                    	view._instance.isPreview = true;
                    }
                }
            };
            if (this.context.subscribeAppState) {
                this.context.subscribeAppState(this._instance.openPage);
            }

            var statisticsIcon = view._instance.statisticsIcon.context.element;
            var ToggleStatistics = function() {
                if (view._instance.statistics.isVisible()) {
                    view._instance.statistics.setVisible(false, true);
                    view._instance.statisticsIcon.context.options.colorStyle.set("value", "Transparent");
                    view._instance.statisticsTooltipText = bpmext.localization.formatMsg("workplace", "showStatistics");
                } else {
                    view._instance.statistics.setVisible(true);
                    view._instance.statisticsIcon.context.options.colorStyle.set("value", "Default");
                    view._instance.statisticsTooltipText = bpmext.localization.formatMsg("workplace", "hideStatistics");
                }


                if (statisticsIcon.hasAttribute("aria-describedby")) {
                    document.getElementById(statisticsIcon.getAttribute("aria-describedby")).innerHTML = view._instance.statisticsTooltipText;
                }
            }

            var showTooltip = function() {
                if (!statisticsIcon.hasAttribute("aria-describedby")) {
                    view._instance.statisticsTooltip = bpmext.ui.util.showTooltip(
                        statisticsIcon,
                        view._instance.statisticsTooltipText,
                        {horizontalPos: "LEFT", smartPositioning: true, alwaysShow: true}
                    );
                    statisticsIcon.firstElementChild.setAttribute("aria-labelledby", view._instance.statisticsTooltip.querySelector('[role="tooltip"]').id);
                }

                if (view._instance.statistics.isVisible()) {
                    statisticsIcon.firstElementChild.setAttribute("style", "background: none !important");
                } else {
                    statisticsIcon.firstElementChild.setAttribute("style", "background: #ffff !important");
                }
            }

            var closeTooltip = function() {
                if (view._instance.statisticsTooltip && view._instance.statisticsTooltip.parentElement) {
                    bpmext.ui.util.closeTooltip(view._instance.statisticsTooltip, statisticsIcon);
                    statisticsIcon.firstElementChild.removeAttribute("aria-labelledby");
                }

                if (view._instance.statistics.isVisible()) {
                    statisticsIcon.firstElementChild.setAttribute("style", "background: #ffff !important");
                } else {
                    statisticsIcon.firstElementChild.setAttribute("style", "background: none !important");
                }
            }

            statisticsIcon.onclick = function(){
                ToggleStatistics();
            }

            statisticsIcon.onkeydown = function(event){
                if (event.key === "Enter" || event.key === "Spacebar" || event.key === " ") {
                    event.preventDefault();
                    ToggleStatistics();
                }
            }

            statisticsIcon.onmouseenter = function() {
                showTooltip();
            };

            statisticsIcon.onmouseleave = function() {
                closeTooltip()
            };

            statisticsIcon.firstElementChild.onfocus = function() {
                showTooltip();
            };
            
            statisticsIcon.firstElementChild.onblur = function() {
                closeTooltip();
            };

            //The layout is a good place to set the page context so that we know we are running the Workplace app
            domClass.add(document.getElementById("mainBody"), "Workplace");

            this._proto._localization(this);

            this.loadContainer(this);

            bpmext.log.info("WorkplaceLayout.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try {
                utilities.handleVisibility(this.context);
            }
            catch (e){
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e, this);
                if(e.stack) {
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack), this);
                }
            }
        };

        this.constructor.prototype.change = function (event){
            bpmext.log.info("WorkplaceLayout.change ENTER >> (event): " + event, this);
            bpmext.log.info("WorkplaceLayout.change ENTER >>", this);
        };

        this.constructor.prototype.unload = function (){
            bpmext.log.info("WorkplaceLayout.unload ENTER >> ", this);
            bpmext.ui.unloadContainer(this);
            bpmext.log.info("WorkplaceLayout.unload ENTER >>", this);
        };
    }
};