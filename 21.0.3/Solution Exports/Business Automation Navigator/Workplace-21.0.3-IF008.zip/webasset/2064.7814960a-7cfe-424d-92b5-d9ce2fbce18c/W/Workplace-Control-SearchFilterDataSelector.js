/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof SearchDataFilterSelector
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof SearchDataFilterSelector
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof SearchDataFilterSelector
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof SearchDataFilterSelector
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof SearchDataFilterSelector
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof SearchDataFilterSelector
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof SearchDataFilterSelector
 * @method triggerFormulaUpdates
 */

workplace_control_InitSearchFilterDataSelector = function (taskUtils, wpResources, utilities, resourceUtils, domStyle, domClass, domAttr)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            //Event constants
            EVT_ONCHANGE: "eventON_CHANGE",

            _loadDropdown: function (view, noDisplay) {
                bpmext.log.info("SearchDataFilterSelector._loadDropdown ENTER >>");
                var header;
                var messages = bpmext.localization;
                if (!view._instance.initialized) {
                    view._instance.menuItems = [];
                    var x, offset = 0;
                    if (view._instance.systemData) {
                        view._instance.menuItems.push({
                            itemType: "H",
                            itemText: "<div><span>" +  bpmext.localization.formatMsg("workplace", "intrinsicData") + "</span></div>"
                        });
                        offset++;
                        for (x = 0; x < view._instance.systemData.length; x++) {
                            var desc = view._instance.systemData[x].description? view._instance.systemData[x].description: view._instance.systemData[x].name;
                            view._instance.menuItems.push({
                                command: {index:x+offset+"", display: view._instance.systemData[x].name},
                                itemType: "L",
                                itemText: view._instance.systemData[x].value,
                                badgeShape: "R",
                                badgeText: view._proto._createOriginDescriptionDom(desc).innerHTML
                            });
                        }                    
                    }
                    
                    if (view._instance.businessData) {
                        header = view._instance.systemData ? bpmext.localization.formatMsg("workplace", "businessData") : bpmext.localization.formatMsg("workplace", "data"); 
                        view._instance.menuItems.push({
                            itemType: "H",
                            itemText: "<div><span>" +  header + "</span></div>"
                        });
                        offset = view._instance.systemData ? view._instance.systemData.length+1 : 0;
                        offset++;
                        for (x = 0; x < view._instance.businessData.length; x++) {
                            var desc = "";
                            if(view._instance.businessData[x].origins && view._instance.businessData[x].origins.length>0){
                                desc = messages.formatMsg("savedSearchBuilder","originateFrom", '"' + view._instance.businessData[x].origins[0].processName + '"' );
                            }
                            else{
                                desc = view._instance.businessData[x].value
                            }
                            view._instance.menuItems.push({
                                command: {index:x+offset+"", display: view._instance.businessData[x].name},
                                itemType: "L",
                                itemText: view._instance.businessData[x].value,
                                badgeShape: "R",
                                badgeText: view._proto._createOriginDescriptionDom(desc).innerHTML
                            });
                        }
                    }

                    view._instance.initialized = true;
                    if (!noDisplay) {
                        view._proto._showDropdown(view);
                    }
                } else {
                    view._proto._showDropdown(view);
                }

                bpmext.log.info("SearchDataFilterSelector._loadDropdown EXIT >>", view);
            },
            _filterItems: function (view) {
                bpmext.log.info("SearchDataFilterSelector._filterItems ENTER >>");
                var filteredResults=[];
                var hasBusinessData, businessDataIndex, hasSystemData, systemDataIndex = 0;
                view._instance.dropDownMenu.setMenuVisible(true);
                
                if (view._instance.filterCondition) {
                    view._instance.menuItems.forEach(function(item) {
                        if (item.itemType === "H") {
                            filteredResults.push(item);
                            if (filteredResults.length !== 1) {
                                //businessdata header
                                businessDataIndex = filteredResults.length -1;
                            }
                        } else if (item.itemText.toLowerCase().indexOf(view._instance.filterCondition.toLowerCase()) !== -1) {
                            filteredResults.push(item);
                            if (!businessDataIndex) {
                                hasSystemData = true;
                            } else {
                                hasBusinessData = true;
                            }
                        }
                    });
                    if (!hasBusinessData) {
                        filteredResults.splice(businessDataIndex, 1);
                    }
                    if (!hasSystemData) {
                        filteredResults.splice(systemDataIndex, 1);
                    }
                }
                else {
                    filteredResults = view._instance.menuItems;
                }

                if (filteredResults.length === 0) {
                    filteredResults.push({
                        itemType: "H",
                        itemText: "<div><span>" +  bpmext.localization.formatMsg("workplace", "noMatch") + "</span></div>"
                    });
                }

                view._instance.dropDownMenu.setMenuItems(filteredResults);
                view._proto._setWidth(view, true);
                bpmext.log.info("SearchDataFilterSelector._filterItems EXIT >>", view);
            },
            _setWidth: function (view, keepVisible) {
                bpmext.log.info("SearchDataFilterSelector._setWidth ENTER >>");
                var parentDiv, windowBottom, menuBottom, menuRect, top, menuDom, inputDomRect;

                var searchBarDom = view._instance.searchLayout.context.element.querySelector(".ContentBox");
                var dropDownDom = view._instance.dropDownMenu._getMenuDom();
                if (searchBarDom.offsetWidth > dropDownDom.offsetWidth) {
                    domStyle.set(dropDownDom, "width", searchBarDom.offsetWidth + "px");
                } else {
                    domStyle.set(searchBarDom, "width", dropDownDom.offsetWidth + "px");
                }
                if (!keepVisible) {
                    view._instance.dropDownMenu.setMenuVisible(false);
                    view._instance.dropDownMenu.setTargetElement(view._instance.searchLayout.context.element);
                    view._instance.dropDownMenu.setMenuVisible(true);
                }
                //close the menu if the parent is scrolled
                parentDiv = view.ui.getAncestor("Stack", true);
                if (parentDiv) {
                    parentDiv = parentDiv.context.element;
                    parentDiv.onscroll = function() {
                        view._instance.dropDownMenu.setMenuVisible(false);
                    };
                }

                //set the height and scroll bar of the menu if it is outside of the viewport
                windowBottom = window.scrollY + window.innerHeight;
                menuDom = view._instance.dropDownMenu._getMenuDom();
                inputDomRect = view._instance.searchBarInput.getBoundingClientRect();
                menuRect = menuDom.getBoundingClientRect();
                top = inputDomRect.top + inputDomRect.height;
                menuBottom = top + menuRect.height;
                if (menuBottom > windowBottom) {
                    menuDom.parentElement.style.height = (windowBottom - top - 10) + "px";
                    menuDom.parentElement.style.overflowY = "scroll";
                } else {
                    menuDom.parentElement.style.height = "";
                    menuDom.parentElement.style.overflowY = "";
                }

                bpmext.log.info("SearchDataFilterSelector._setWidth EXIT >>", view);
            },
            _showDropdown: function (view) {
                bpmext.log.info("SearchDataFilterSelector._showDropdown ENTER >>");
                view._instance.dropDownMenu.setMenuItems(view._instance.menuItems);
                view._instance.dropDownMenu.setMenuVisible(true);
                domClass.add(view._instance.searchLayout.context.element, "expandedSearch");
                view._proto._setWidth(view);
                setTimeout(function() { view._instance.searchBar._instance.text.focus(); }, 50);
                bpmext.log.info("SearchDataFilterSelector._showDropdown EXIT >>", view);
            },

            _focusDropdown: function (view) {
                if (view._instance.dropDownMenu.isMenuVisible()) {
                    var dropDownElements = taskUtils.getFocusElementList(view._instance.dropDownMenu._instance.menuTbl, true);
                    view._instance.focusIndex = 0;
                    dropDownElements[view._instance.focusIndex].focus();
                }
            },
            _createOriginDescriptionDom: function (description){
                var infoDom = document.createElement("div");
                var infoDomWrapper = document.createElement("span");
                domClass.add(infoDomWrapper, "menuitem-tooltip-icon");

                var tooltipWrapper = document.createElement("div");
                domClass.add(tooltipWrapper, "menuitem-tooltip");
                var tooltipCaret = document.createElement("div");
                domClass.add(tooltipCaret, "menuitem-tooltip-caret");
                var tooltipContent = document.createElement("div");

                var id = "menuitem-tooltip-content-" + bpmext.ui.makeUniqueId("");
                tooltipContent.id = id;
                var ciIcon = utilities.getCarbonIcon("ci-information");
                ciIcon.tabIndex = 0;
                domAttr.set(ciIcon, "aria-describedby", tooltipContent.id);
                ciIcon.ariaLabel = bpmext.localization.formatMsg("savedSearchBuilder", "information");
                infoDomWrapper.appendChild(ciIcon);

                domClass.add(tooltipContent, "menuitem-tooltip-content");
                var tooltipText = document.createTextNode(description);
                tooltipContent.appendChild(tooltipText);
                tooltipWrapper.appendChild(tooltipCaret);
                tooltipWrapper.appendChild(tooltipContent);
                infoDomWrapper.appendChild(tooltipWrapper);

                infoDom.appendChild(infoDomWrapper);

                return infoDom
            }
        };


        /*
        Public control methods *************************************************************
         */
        /**
         * @instance
         * @memberof SearchDataFilterSelector
         * @method openDropdown
         * @desc Opens the dropdown section
         */
        this.constructor.prototype.openDropdown = function openDropdown() {
            var view = this;
            bpmext.log.info("SearchDataFilterSelector.openDropdown ENTER >>", this);
            this._proto._loadDropdown(this);
            if (!this._instance.dropDownMenu.isVisible()) {
                this._instance.dropDownMenu.setMenuVisible(true);
            }

            this._instance.searchBarInput = this._instance.searchBar.context.element.querySelector("input");
            this._instance.dropDownBlur = function(event) {
                if (!view._instance.searchBarInput.contains(event.relatedTarget)
                    && !view._instance.dropDownMenu._instance.menuTbl.contains(event.relatedTarget) ) {
                    view.hideDropdown();
                }
            };

            this._instance.dropDownMenu._instance.wrapper.addEventListener("blur", this._instance.dropDownBlur, true);
            
            bpmext.log.info("SearchDataFilterSelector.openDropdown EXIT >>", this);
        };
        /**
         * @instance
         * @memberof SearchDataFilterSelector
         * @method hideDropdown
         * @desc Closes the dropdown section
         */
        this.constructor.prototype.hideDropdown = function hideDropdown() {
            bpmext.log.info("SearchDataFilterSelector.hideDropdown ENTER >>", this);
            if (this._instance.initialized) {
                this._instance.dropDownMenu.setMenuVisible(false);
                this._instance.dropDownMenu._instance.wrapper.removeEventListener("blur", this._instance.dropDownBlur, true);
            }
            bpmext.log.info("SearchDataFilterSelector.hideDropdown EXIT >>", this);
        };
        /**
         * @instance
         * @memberof SearchDataFilterSelector
         * @method filterDropdown
         * @desc Filter the dropdown section
         */
        this.constructor.prototype.filterDropdown = function filterDropdown() {
            bpmext.log.info("SearchDataFilterSelector.filterDropdown ENTER >>", this);
            this.openDropdown();
            this._instance.filterCondition = this._instance.searchBar.context.element.querySelector("input").value;
            this._proto._filterItems(this);
            bpmext.log.info("SearchDataFilterSelector.filterDropdown EXIT >>", this);
        };
        /**
         * @instance
         * @memberof SearchDataFilterSelector
         * @method launchItem
         * @param {String} action The item command
         * @desc Launches the item selected
         */
        this.constructor.prototype.launchItem = function launchItem(action) {
            var view = this;
            bpmext.log.info("SearchDataFilterSelector.launchItem ENTER >>", this);
            this._instance.searchBarInput.value = this._instance.menuItems[action.index].itemText;
            this._instance.currentItem = action;
            this._instance.searchBarInput.focus();
            this.hideDropdown();
            bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONCHANGE);
            bpmext.log.info("SearchDataFilterSelector.launchItem EXIT >>", this);
        };
        /**
         * @instance
         * @memberof SearchDataFilterSelector
         * @method getCurrentLaunchedItem
         * @desc Get the command of the current item
         */
        this.constructor.prototype.getCurrentLaunchedItem = function () {
            bpmext.log.info("SearchDataFilterSelector.getCurrentLaunchedItem ENTER: >>");
            return this._instance.currentItem;
        };
        /**
         * @instance
         * @memberof SearchDataFilterSelector
         * @method setSearchData
         * @param {Object[]} systemData The searchable system data
         * @param {Object[]} businessData The searchable business data
         * @desc Sets the data that can be searched
         */
        this.constructor.prototype.setSearchData = function (systemData, businessData) {
            this._instance.systemData = systemData;
            this._instance.businessData = businessData;
            return true;
        };

        /**
         * @instance
         * @memberof SearchDataFilterSelector
         * @method getItemCount
         * @returns {int} The number of items in the search list
         * @desc Gets the number of items in the search list
         */
        this.constructor.prototype.getItemCount = function () {
            return this._instance.menuItems.length;
        };


        /**
         * @instance
         * @memberof SearchDataFilterSelector
         * @method getData
         * @returns {Object} The data of the currently selected option
         * @desc Gets the data of the currently selected option
         */
        this.constructor.prototype.getData = function () {
            return this.getCurrentLaunchedItem() ? this.getCurrentLaunchedItem().display : "";
        };

        /**
         * @instance
         * @memberof SearchDataFilterSelector
         * @method toggleMenu
         * @desc Toggles the menu open and closed
         */
        this.constructor.prototype.toggleMenu =  function() {
            if (!this._instance.dropDownMenu.isMenuVisible()) {
                this.openDropdown();
            } else {
                this.hideDropdown();
            }
        };

        /**
         * @instance
         * @memberof SearchDataFilterSelector
         * @method setSelectedItem
         * @param {String} item The selected item
         * @desc Sets the selected item
         */
        this.constructor.prototype.setSelectedItem =  function(item) {
            var x, menuItem;
            if (!this._instance.initialized) {
                this._proto._loadDropdown(this, true);
            }

            for (x=0; x<this._instance.menuItems.length; x++) {
                if (this._instance.menuItems[x].command && item === this._instance.menuItems[x].command.display) {
                    menuItem = this._instance.menuItems[x];
                    break;
                }
            }
            if(menuItem) {
                this.launchItem(menuItem.command);
            }
    };


        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function ()
        {
            bpmext.log.info("SearchDataFilterSelector.load ENTER >>", this);

            var view = this;

            this._instance.menuItems = [];
            this._instance.systemData = [];
            this._instance.businessData = [];

            this._instance.searchLayout = bpmext.ui.getContainer("searchLayout", this);
            this._instance.dropDownMenu = bpmext.ui.getContainer("dropDownMenu", this);
            this._instance.dropDownMenu.context.options.customFocus.set("value", true);
            this._instance.searchBar = bpmext.ui.getView("searchBar", this);
            this._instance.dataSelectorToggle = bpmext.ui.getView("DataSelectorToggle", this);

            this._instance.searchBar.setPlaceholder(bpmext.localization.formatMsg("searchFilter", "selectValue"));

            this._instance.searchBarInput = this._instance.searchBar.context.element.querySelector("input");
            domAttr.set(this._instance.searchBarInput, "aira-haspopup", "true");
            domAttr.set(this._instance.searchBarInput, "autocomplete", "off");
            this._instance.searchBarInput.onkeydown = function(event) {
                if (event.key === "ArrowDown") {
                    view.openDropdown();
                    setTimeout(function () {
                        view._proto._focusDropdown(view);
                    }, 150);
                } else if (event.key === "Escape" || event.key === "Esc") {
                    event.preventDefault();
                    event.stopPropagation();
                    view.hideDropdown();
                } else if (event.key === "Enter") {
                    view.openDropdown();
                }
            };

            this._instance.searchBarInput.onclick = function() {
                setTimeout(function() { view.openDropdown(); });
            };

            this._instance.searchBarInput.onblur = function(event) {
                if (!view._instance.dropDownMenu._instance.menuTbl.contains(event.relatedTarget)) {
                    view.hideDropdown();
                }
            };

            this._instance.focusIndex = 0;
            this._instance.dropDownMenu._instance.wrapper.onkeydown = function(event) {
                var dropDownElements = taskUtils.getFocusElementList(view._instance.dropDownMenu._instance.menuTbl, true);
                if(event.key === "ArrowUp" || event.key === "Up"){
                    if (dropDownElements[view._instance.focusIndex] === dropDownElements[0]) {
                        view._instance.focusIndex = dropDownElements.length - 1;
                        dropDownElements[view._instance.focusIndex].focus();
                    } else {
                        view._instance.focusIndex = view._instance.focusIndex - 1;
                        dropDownElements[view._instance.focusIndex].focus();
                    }
                } else if (event.key === "ArrowDown" || event.key === "Down") {
                    if (dropDownElements[view._instance.focusIndex] === dropDownElements[dropDownElements.length - 1]) {
                        view._instance.focusIndex = 0;
                        dropDownElements[view._instance.focusIndex].focus();
                    } else {
                        view._instance.focusIndex = view._instance.focusIndex + 1;
                        dropDownElements[view._instance.focusIndex].focus();
                    }
                } else if (event.key === "Escape" || event.key === "Esc" || event.key === "Tab") {
                    event.preventDefault();
                    event.stopPropagation();
                    view._instance.searchBarInput.focus();
                }
            }

            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONCHANGE);
            this.loadContainer(this);

            bpmext.log.info("SearchDataFilterSelector.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try
            {
                utilities.handleVisibility(this.context);
            }
            catch (e)
            {
                //{#feature: US-1330 Added RT localization}
                //bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e, this);
                if (e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    //bpmext.log.error("  Call stack: " + e.stack);
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack), this);
                }
            }
        };

        this.constructor.prototype.change = function (event)
        {
            bpmext.log.info("SearchDataFilterSelector.change ENTER >> (event): " + event, this);
            if (event && event.type === "config") {
                switch (event.property) {
                    case "_metadata.visibility": {
                        this.view();
                        break;
                    }
                }
            }
            bpmext.log.info("SearchDataFilterSelector.change ENTER >>", this);
        };

        this.constructor.prototype.unload = function ()
        {
            bpmext.ui.unloadView(this);
        };
    }
};