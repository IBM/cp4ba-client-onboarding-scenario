/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof TaskCards
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof TaskCards
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof TaskCards
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof TaskCards
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof TaskCards
 * @method setData
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 * 
 *   <tr class=Prop>
 *       <td>On task opened:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when an active task card is clicked.</td>
 *               </tr>
 *           </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">Description</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">task {object}</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">task data</td>
 *               </tr>
 *       </table>
 *     </td>
 *   </tr>
 * 
 *   <tr class=Prop>
 *       <td>On instance opened:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when a completed task card is clicked.</td>
 *               </tr>
 *           </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">Description</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">task {object}</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">task data</td>
 *               </tr>
 *           </table>
 *       </td>
 *   </tr>
 * 
 *   <tr class=Prop>
 *       <td>On visibility change:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when a task lose focus.</td>
 *               </tr>
 *               <tr class=Prop>
 *                   <td>Example: </td>
 *                   <td><pre class="prettyprint"><code>console.log("View visibility changed")</code></pre></td>
 *               </tr>
 *           </table>
 *       </td>
 *   </tr>
 * </table>
 */
workplace_control_InitTaskCards = function (utilities, taskUtils, domClass, domConstruct, wpResources, domAttr)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            //Event constants
            EVT_ONTASK_LAUNCHED : "eventON_TASK_LAUNCHED",
            EVT_ONINSTANCE_LAUNCHED: "eventON_INSTANCE_LAUNCHED",
            EVT_ONVISIBILITYCHANGE: "eventON_VISIBILITYCHANGE",

            _setViewData: function _setViewData(view, data, createPseudoBinding){
                var ctx = view.context;

                if(ctx){
                    if(ctx.binding){
                        ctx.binding.set("value", data);
                    } else if (createPseudoBinding === true) {
                        ctx.binding = bpmext.ui.substituteObject(view);
                        ctx.binding.set("value", data);
                    }
                }
            },

            _getCurrentUserInfo: function _getCurrentUserInfo (view) {
                // refresh user's information
                return wpResources.user.get({refresh: true}).then(function(currentUser) {
                    view._instance.modifyTask = currentUser.modifyTask;
                    view._instance.currentUser = currentUser.userName;
                    view._instance.userGroups = currentUser.memberships;
                });
            },

            _isNotMute: function _isNotMute (view, task) {
                if (!task) {
                    return false;
                }

                if (view._instance.muteLaunchCompleteTask) {
                    if (view._proto._isTaskCompleted(view, task)) {
                        return false;
                    }
                }

                return true;

            },

            _isTaskCompleted: function _isTaskCompleted (view, task) {
                return taskUtils.getStatusLabel(task) === bpmext.localization.formatMsg("controlTaskList", "taskCompleted");
            },

            _isTaskLaunchableByCurrentUser: function _isTaskLaunchableByCurrentUser (view, task) {
                var hasRequiredFields = ["owner", "OWNER", "assignedToDisplayName", "ASSIGNED_TO_ROLE_DISPLAY_NAME"].reduce(function (acc, field) {
                    return acc || Object.prototype.hasOwnProperty.call(task, field);
                }, false);

                
                if (hasRequiredFields) {
                    var owner = task["OWNER"] || task.owner;
                    var groupName = task["ASSIGNED_TO_ROLE_DISPLAY_NAME"] || task.assignedToDisplayName;
                    return view._instance.userGroups.indexOf(groupName) > -1 || owner === view._instance.currentUser;
                }

                return true;
            },

            _addScrollBottomListener: function _addScrollBottomListener(view) {
                if (view._instance.scrollBottomFunc) {
                    view._proto._removeScrollBottomListener(view);
                }

                view._instance.scrollBottomFunc = function () {
                    var scrollHeight, totalHeight;
                    scrollHeight = document.body.scrollHeight;
                    totalHeight = window.pageYOffset + window.innerHeight;

                    // reach the bottom
                    if (totalHeight >= scrollHeight) {
                        view.loadNextBlock();
                    }
                };

                bpmext.log.info("TaskCards._addScrollBottomListener >>", this);
                // window.addEventListener("scroll", view._instance.scrollBottomFunc, true);
                view._instance.showMoreWrapper && view._instance.showMoreWrapper.setVisible(true, true);

            },

            _removeScrollBottomListener: function _removeScrollBottomListener(view) {
                if (!view._instance.scrollBottomFunc) {
                    return;
                }

                bpmext.log.info("TaskCards._removeScrollBottomListener >>", this);
                // window.removeEventListener("scroll", view._instance.scrollBottomFunc, true);
                view._instance.showMoreWrapper && view._instance.showMoreWrapper.setVisible(false, true);
                delete view._instance.scrollBottomFunc;
            },

            _justifyActionsMenuOptions: function _justifyActionsMenuOptions(view, rights) {
                var actionsMenu = view._instance.actionsMenu;

                var disabledActions = actionsMenu.context.options.disableActions.get("value").items || [];
                disabledActions = dojo.clone(disabledActions);

                // Disabled the launch task option if current user does not has right to access it
                var isDisabledLaunchTask = disabledActions.indexOf("ACTION_LAUNCH_TASK") > -1;
                if (rights.isTaskLaunchable && isDisabledLaunchTask) {
                    disabledActions.splice(disabledActions.indexOf("ACTION_LAUNCH_TASK"), 1);
                    actionsMenu.context.options.disableActions.set("value", disabledActions);
                } else if (!rights.isTaskLaunchable && !isDisabledLaunchTask) {
                    disabledActions.push("ACTION_LAUNCH_TASK");
                    actionsMenu.context.options.disableActions.set("value", disabledActions);
                }
            }
        };

        /*
        Public control methods *************************************************************
        */

        /**
		 * @instance
		 * @memberof TaskCards
		 * @method launchTask
         * @param {View} target The on click card view
		 * @desc Launch the task in task viewer
         */
        this.constructor.prototype.launchTask = function(target) {
            bpmext.log.info("TaskCards.launchTask ENTER >>: ", this, target);

            var parentView = this.ui.getParent();
            var task = this.ui.getOption("tasks").items[target.ui.getIndex()];
            parentView.launchTask(task);

            bpmext.log.info("TaskCards.launchTask EXIT >>: " + this);
        };

        /**
		 * @instance
		 * @memberof TaskCards
		 * @method setViewData
         * @param {Task[]} data New tasks list binding
		 * @desc Sets the data
         */
        this.constructor.prototype.setViewData = function(data, createPseudoBinding) {
            bpmext.log.info("TaskCards.setViewData ENTER >>", this, data);

            var view = this;

            var tasksPerBlock = this.context.options.tasksPerBlock.get("value");
            var blocksShowingOnload = this.context.options.blocksShowingOnload.get("value");

            var setTaskData = function (view, data, createPseudoBinding) {
                view.context.options.tasks.set("value", data);

                var numberOfBlocks = Math.ceil(data.length / tasksPerBlock);

                var placeHolders = [];
                for (var i=0; i < numberOfBlocks; i++) {
                    placeHolders.push([]);
                }

                // Reset block cursor
                view._instance.nextBlockIndex = Math.min(numberOfBlocks, blocksShowingOnload);
                view._instance.loadedTask = 0;

                // Register scroll bottom event if necessary
                if (numberOfBlocks > view._instance.nextBlockIndex) {
                    view._proto._addScrollBottomListener(view);
                } else {
                    view._proto._removeScrollBottomListener(view);
                }

                // Bind placeholders/empty blocks to the container
                view._instance.cardsWrapper = bpmext.ui.getContainer("TLCards", view);
                view._proto._setViewData(view._instance.cardsWrapper, placeHolders, createPseudoBinding);
            };

            if (Array.isArray(data) && data.length > 0) {
                if (!view._instance.currentUser && !view._instance.userGroups) {
                    view._proto._getCurrentUserInfo(this).then(function () {
                        setTaskData(view, data, createPseudoBinding);
                    });
                } else {
                    setTaskData(view, data, createPseudoBinding);
                }
            }

            bpmext.log.info("TaskCards.setViewData Exit >>", this);
        };

        /**
		 * @instance
		 * @memberof TaskCards
		 * @method loadBlock
         * @param {View} target Target block
		 * @desc Loads tasks into a block
         */
        this.constructor.prototype.loadBlock = function(target) {
            bpmext.log.info("TaskCards.loadBlock ENTER >>", this);

            var blockIndex = target.ui.getIndex();
            var tasksPerBlock = this.context.options.tasksPerBlock.get("value");

            // Prevent load extra blocks, and hide the placeholder if necessary
            if (blockIndex >= this._instance.nextBlockIndex) {
                target.setVisible(false, true);
                return;
            }

            // Get tasks fot the block
            var tasks = this.ui.getOption("tasks").items;
            var initTaskIndex = blockIndex * tasksPerBlock;
            var lastTaskIndex = Math.min((blockIndex + 1) * tasksPerBlock, tasks.length);
            var tasksInBlock = tasks.slice(initTaskIndex, lastTaskIndex);

            // Set block data
            this._proto._setViewData(target, tasksInBlock, true);

            bpmext.log.info("TaskCards.loadBlock Exit >>", this);
        };

        /**
		 * @instance
		 * @memberof TaskCards
		 * @method loadCardTitle
         * @param {View} target The on click card view
		 * @descOn load function of card title
         */
        this.constructor.prototype.loadCardTitle = function(target) {
            var task = this.ui.getOption("tasks").items[target.ui.getIndex()];
            if (task) {
                var taskName =  task["TAD_DISPLAY_NAME"] || task.displayName;
                target.setLabelVisible(false);
                target.setData(taskName);
            }
        },

        /**
		 * @instance
		 * @memberof TaskCards
		 * @method settingDetail
         * @param {View} target The on click card view
		 * @desc Sets card priority, due, assignee
         */
        this.constructor.prototype.settingDetail = function(target) {
            var task = this.ui.getOption("tasks").items[target.ui.getIndex()];
            if (task) {
                var priorityCtl = target.context.getSubview("Card_Priority", target)[0];
                var priority = taskUtils.getPriorityLabel(task["PRIORITY"] || task.priority);
                if (priority) {
                    priorityCtl.setLabel(bpmext.localization.formatMsg("taskCard", "cardPriority"));
                    priorityCtl.setData(priority);
                } else {
                    priorityCtl.setVisible(false, true);
                }

                var dueCtl = target.context.getSubview("Card_Due", target)[0];
                var due = task["DUE"] || task.dueTime;
                if (due) {
                    dueCtl.setData(taskUtils.formatDate(new Date(due)));
                    dueCtl.setLabel(bpmext.localization.formatMsg("taskCard", "cardDue"));
                } else {
                    dueCtl.setVisible(false, true);
                }

                var assigneeCtl = target.context.getSubview("Card_Assignee", target)[0];
                var assignee = task["OWNER"] || task.owner || task.teamDisplayName;
                if (assignee) {
                    assigneeCtl.setLabel(bpmext.localization.formatMsg("taskCard", "cardAssignee"));
                    assigneeCtl.setData(assignee);
                } else {
                    assigneeCtl.setVisible(false, true);
                }
            }
        },

        /**
		 * @instance
		 * @memberof TaskCards
		 * @method loadCardStatus
         * @param {View} target The on click card view
		 * @desc On load function of generate status inner html
         */
        this.constructor.prototype.loadCardStatus = function(target) {
            target.setLabelVisible(false);

            var task = this.ui.getOption("tasks").items[target.ui.getIndex()];

            var status;
            if (task) {
                var text = taskUtils.getStatusLabel(task);
                var className = taskUtils.getStatusClassName(task);
                status =  domConstruct.create("span", {
                    className: className + " taskStatsWrapper",
                    "aria-label":  bpmext.localization.formatMsg("taskCard", "taskStatus") + ": " + text
                });

                var statusImageURL = taskUtils.getTaskDueStatusImageURL(task, true);
                if (statusImageURL) {
                    var innerIcon = domConstruct.create("span", {className: "taskStatsIcon"});
                    domConstruct.place(innerIcon, status);

                    var taskStatsIcon = domConstruct.toDom("<img src='" + statusImageURL + "' alt=''></img>");
                    domConstruct.place(taskStatsIcon, innerIcon);
                }

                var innerText = domConstruct.create("span", {className: "taskStatsText", innerHTML: text});
                domConstruct.place(innerText, status);

            } else {
                status =  domConstruct.create("span");
            }

            target.setData(status.outerHTML);
        },

        /**
		 * @instance
		 * @memberof TaskCards
		 * @method settingActions
         * @param {View} target The on click card view
		 * @desc Sets card actions
         */
        this.constructor.prototype.settingActions = function(target) {
            var task = this.ui.getOption("tasks").items[target.ui.getIndex()];
            if (task) {
                var owner = task["OWNER"] || task.owner;

                var launchLink = target.context.getSubview("Launch_Task_Link", target)[0];
                launchLink.setLabelVisible(false);
                launchLink.setEnabled(false, true);

                if (this._instance.muteLaunchCompleteTask) {
                    if (this._proto._isTaskCompleted(this, task)) {
                        launchLink.setText(bpmext.localization.formatMsg("taskCard", "completed"));
                    } else if (!this._proto._isTaskLaunchableByCurrentUser(this, task)) {
                        launchLink.setText(bpmext.localization.formatMsg("taskCard", "notAuth"));
                    } else {
                        launchLink.setText(bpmext.localization.formatMsg("taskCard", owner ? "confirm" : "claim"));
                        launchLink.setEnabled(true, true);
                    }
                } else {
                    if (this._proto._isTaskCompleted(this, task)) {
                        launchLink.setText(bpmext.localization.formatMsg("taskCard", "completed"));
                    } else if (!this._proto._isTaskLaunchableByCurrentUser(this, task)) {
                        launchLink.setText(bpmext.localization.formatMsg("taskCard", "notAuth"));
                    } else {
                        launchLink.setText(bpmext.localization.formatMsg("taskCard", "launch"));
                        launchLink.setEnabled(true, true);
                    }
                }
            }
        },

        /**
		 * @instance
		 * @memberof TaskCards
		 * @method loadActionIcon
         * @param {View} target The on click card view
		 * @desc On click function of the overflow button, which opens the action menu
         */
        this.constructor.prototype.loadActionIcon = function(target) {
            var theView = this;
            var task = this.ui.getOption("tasks").items[target.ui.getIndex()];

            target.setVisible(this._proto._isNotMute(this, task), true);

            var actionIcon = target.context.element.querySelector("div.SPARKIcon.btn");

            domClass.add(actionIcon, "cardActionsIcon");

            actionIcon.setAttribute("aria-haspopup", "true");
            actionIcon.setAttribute("aria-label", bpmext.localization.formatMsg("taskCard", "taskActions"));
            actionIcon.setAttribute("title", bpmext.localization.formatMsg("taskCard", "taskActions"));
            actionIcon.setAttribute("parentViewName", this.ui.getAbsoluteName());

            if (task){
                var tkiid = task["TASK.TKIID"] || task.tkiid || "";
                actionIcon.setAttribute("taskId", tkiid);

                var piid = task["PROCESS_INSTANCE.PIID"] || task.piid || "";
                actionIcon.setAttribute("processId", piid);

                actionIcon.setAttribute("isWorkstream", task.IS_WORKSTREAM || "");

                actionIcon.setAttribute("isTaskLaunchable", this._proto._isTaskLaunchableByCurrentUser(this, task) + "");
            }

            var view = this;
            var openActionMenuHandler = function(targetIcon){
                var parentView = theView.ui.getParent();

                if(parentView) {
                    var processId = targetIcon.getAttribute("processId"),
                        taskId = targetIcon.getAttribute("taskId"),
                        systemID = targetIcon.getAttribute("systemID"),
                        isWorkstream = targetIcon.getAttribute("isWorkstream"),
                        isTaskLaunchable = actionIcon.getAttribute("isTaskLaunchable");

                    view._proto._justifyActionsMenuOptions(parentView, {
                        isTaskLaunchable: isTaskLaunchable === "true"
                    });

                    //Load actions menu
                    parentView._instance.actionsMenu.loadMenu(processId, taskId, systemID, isWorkstream, null, targetIcon);
                    domClass.add(targetIcon, "active");
                }
            };

            actionIcon.addEventListener("click", function(event){
                event.stopPropagation();
                openActionMenuHandler(this);
            }, true);

            actionIcon.addEventListener("keydown", function(event){
                event.stopPropagation();

                // if input key is space or enter key
                if (event.key === "Enter" || event.key === " " || event.key === "Spacebar") {
                    openActionMenuHandler(this);
                }
            }, true);

        },

        /**
		 * @instance
		 * @memberof TaskCards
		 * @method muteLaunchCompleteTask
         * @param {Boolean} mute Control to set overflow and launch button to invisible
		 * @desc Set overflow and launch button invisible on completed tasks
         */
        this.constructor.prototype.muteLaunchCompleteTask = function(mute) {
            this._instance.muteLaunchCompleteTask = !!mute;
        },

        /**
		 * @instance
		 * @memberof TaskCards
		 * @method loadCardWrapper
         * @param {View} target The on click card view
		 * @desc Loads card wrapper
         */
        this.constructor.prototype.loadCardWrapper = function (target) {
            var cardWrapperContext = target.context.element.querySelector("div.SPARKWell");

            var task = this.ui.getOption("tasks").items[target.ui.getIndex()];

            // Defect 341846, async loading will load an extra block when the actual size is less than async loading default size
            // need to find if the extra block is required to be shown
            target.setVisible(!!task, true);

            this._instance.loadedTask += 1;

            if (task) {
                var taskName =  task["TAD_DISPLAY_NAME"] || task.displayName;
                domAttr.set(cardWrapperContext, "role", "note");
                domAttr.set(cardWrapperContext, "aria-label", taskName);
            }
        };

        /**
		 * @instance
		 * @memberof TaskCards
		 * @method loadNextBlock
         * @param {View} target The on click card view
		 * @desc Launches activity summary modal
         */
        this.constructor.prototype.loadNextBlock = function() {
            var tasks = this.ui.getOption("tasks").items;
            var tasksPerBlock = this.context.options.tasksPerBlock.get("value");

            // Get list of blocks
            var blockIndex = this._instance.nextBlockIndex;
            var blocks = this._instance.cardsWrapper.context.getSubview("Display_Block");

            if (blockIndex >= blocks.length) {
                // Prevent loading blocks when all blocks are shown
                return;
            } else if (this._instance.loadedTask !== Math.min(blockIndex * tasksPerBlock, tasks.length)) {
                // Prevent the case that scrolling too fast, proceed only of all tasks are loaded
                return;
            }

            // Get tasks for current block
            var initTaskIndex = blockIndex * tasksPerBlock;
            var lastTaskIndex = Math.min((blockIndex + 1) * tasksPerBlock, tasks.length);
            var tasksInBlock = tasks.slice(initTaskIndex, lastTaskIndex);

            // Find the target block and set tasks data
            var target = blocks[blockIndex];
            if (target) {
                target.setVisible(true, true);
                this._proto._setViewData(target, tasksInBlock, true);

                // Move the block cursor to next index
                this._instance.nextBlockIndex += 1;
            }

            // If all blocks are shown, remove reach bottom events and show more link
            if (this._instance.nextBlockIndex >= blocks.length) {
                this._proto._removeScrollBottomListener(this);
            }
        };

        /*
        Coach NG Lifecycle methods *************************************************************
        */

        this.constructor.prototype.load = function ()
        {
            bpmext.log.info("TaskCards.load ENTER >>", this);

            var opts = this.context.options;

            if (!opts.tasks) {
                bpmext.ui.substituteConfigOption(this, "tasks", []);
            }

            if (!opts.tasksPerBlock) {
                bpmext.ui.substituteConfigOption(this, "tasksPerBlock", 5);
            }

            if (!opts.blocksShowingOnload) {
                bpmext.ui.substituteConfigOption(this, "blocksShowingOnload", 2);
            }

            this._instance.muteLaunchCompleteTask = false;

            // Backup method for the case that scroll button event is not working (show more does same thing as the event)
            this._instance.showMoreWrapper = bpmext.ui.getContainer("ShowMoreWrapper", this);
            this._instance.showMoreLink = bpmext.ui.getView("ShowMore", this);
            !!this._instance.showMoreLink && this._instance.showMoreLink.setText(bpmext.localization.formatMsg("taskCard", "showMore"));

            this.loadContainer(this);

            bpmext.log.info("TaskCards.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try
            {
                utilities.handleVisibility(this.context);
            }
            catch (e)
            {
                //{#feature: US-1330 Added RT localization}
                //bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if(e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    //bpmext.log.error("  Call stack: " + e.stack);
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                }
            }
        };

        this.constructor.prototype.change = function (event)
        {
            bpmext.log.info("TaskCards.change ENTER >>");
            if (event.type === "config") {
                switch (event.property) {
                    case "_metadata.visibility": {
                        this.view();
                        bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONVISIBILITYCHANGE);

                        // Get list of blocks
                        var blockIndex = this._instance.nextBlockIndex;
                        var cardWrapper = this._instance.cardsWrapper;

                        if (blockIndex && cardWrapper) {
                            var blocks = this._instance.cardsWrapper.context.getSubview("Display_Block");
                            var isVisible = event.newVal !== "NONE" && event.newVal !== "HIDDEN";

                            if (isVisible && blockIndex < blocks.length) {
                                this._proto._addScrollBottomListener(this);
                            } else {
                                this._proto._removeScrollBottomListener(this);
                            }
                        }

                        break;
                    }
                }
            }
            bpmext.log.info("TaskCards.change EXIT >>");
        };

        this.constructor.prototype.unload = function ()
        {
            this._proto._removeScrollBottomListener(this);
            bpmext.ui.unloadContainer(this);
        };
    }
};
