/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof HelpContent
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof HelpContent
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof HelpContent
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof HelpContent
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof HelpContent
 * @method setData
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 * </table>
 */
workplace_control_InitHelpContent = function (utilities, taskUtils) {
	"use strict";
	this._instance = {
	};

	if (!this.constructor.prototype._proto) {
		this.constructor.prototype._proto = {
			/**
			 * @param {View} view
			 */
			_setPrimaryButton: function _setPrimaryButton(view) {
				var isFormValid = view._instance.isNameValid && view._instance.isDescriptionValid;
				taskUtils.EVENTS.SLIDEOUT_SET_PRIMARY_BTN.publish({enable: isFormValid});
			}
		};

		/*
		Public control methods *************************************************************
		 */

		/**
         * @instance
         * @memberof HelpContent
         * @method closeSlideout
         * @desc Closes the dialog
         */
        this.constructor.prototype.closeSlideout = function closeSlideout() {
            this.hide(true);
		};

		/**
         * @instance
         * @memberof HelpContent
         * @method linkClicked
		 * @param page page identifier
         * @desc Launches the page associated with the link that is clicked
         */
		this.constructor.prototype.linkClicked = function linkClicked(page) {
            //Prevent the click event from propagating up
            if (window.event) {
                window.event.preventDefault();
                window.event.stopImmediatePropagation();
			}
			switch(page) {
				case "video1": //approval video
					window.open("https://ibm.biz/Bdqavn", "_blank");
					break;
				case "helpContent1": //overview
					window.open("https://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.workstream/topics/con_rwf_overview.html", "_blank");
					break;
				case "helpContent2": //configuring workstreams
					window.open("https://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.workstream/topics/tsk_rwf_defining.html", "_blank");
					break;
			}
	};

		/*
		Coach NG Lifecycle methods *************************************************************
		 */
		this.constructor.prototype.load = function () {
			bpmext.log.info("HelpContent.load ENTER >>", this);

			var _this = this;
			taskUtils.EVENTS.LAUNCH_HELP.subscribe(function(){
				taskUtils.EVENTS.SLIDEOUT_PANEL_EXPAND.publish({targetView:_this.context.viewid});
			});

			this.loadView(this);

			bpmext.log.info("HelpContent.load EXIT >>", this);
		};

		this.constructor.prototype.view = function () {
			try {
				utilities.handleVisibility(this.context);
			} catch (e) {
				//{#feature: US-1330 Added RT localization}
				//bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
				bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
				if (e.stack) {
					//{#feature: US-1330 Added RT localization}
					//bpmext.log.error("  Call stack: " + e.stack);
					bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
				}
			}
		};

		this.constructor.prototype.change = function (event) {
			bpmext.log.info("HelpContent.change ENTER >> (event): " + event, this);
			if (event.type === "config") {
				switch (event.property) {
					case "_metadata.visibility": {
						this.view();
						break;
					}
				}
			}
			bpmext.log.info("HelpContent.change EXIT >>", this);
		};

		this.constructor.prototype.unload = function () {
			bpmext.ui.unloadView(this);
		};

		this._instance.MODAL_OPTIONS = {
            title: bpmext.localization.formatMsg("HelpPanel", "learnMoreTitle"),
			subtitle: bpmext.localization.formatMsg("HelpPanel", "learnMoreSubtitle"),
			progressBarOptions:{},
			onPanelClose: {}
        };
	}
};