/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2020. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/

workplace_control_InitWorkflowFavorites = function (utilities, taskUtils) {
    "use strict";
    this._instance = {
    };

    if (!this.constructor.prototype._proto) {
        this.constructor.prototype._proto = {
            EVT_ONLOAD : "eventON_LOAD",

            _setViewData: function _setViewData(view, data, createPseudoBinding) {
                var ctx = view.context;
                if(ctx){
                    if(ctx.binding){
                        ctx.binding.set("value", data);
                    } else if (createPseudoBinding) {
                        ctx.binding = bpmext.ui.substituteObject(view);
                        ctx.binding.set("value", data);
                    }
                }
			 },

			 _setPrimaryButton: function _setPrimaryButton(view) {
	        	var selectedItem = view._instance.selectedWorkstream, eventData = {}, buttonTxt = bpmext.localization.formatMsg("workplace", "next");
	        	if(selectedItem && (selectedItem.type === "process" || selectedItem.type === "casetype")) {
	        		buttonTxt =  bpmext.localization.formatMsg("taskCard", "launch");
	        	}
	        	eventData = {
	        		enable: !!selectedItem,
	        		text: buttonTxt
	        	};
				taskUtils.EVENTS.SLIDEOUT_SET_PRIMARY_BTN.publish(eventData);
			},

             _groupWorkStreams: function _groupWorkStreams(data) {
				var items = [], groupArray = [];
				if(data) {
					items = dojo.clone(data);
					for(var i = 0; i < items.length; i += 3) {
						var obj = {};
						if(i < items.length){
							for(var j = 0; j < 3; j += 1) {
								obj[j] = items[i + j];
							}
							groupArray.push(obj);
						}
					}
				}
				return groupArray;
            },

			_getFavoriteWorkflows: function(view) {
				var favoritesList = view.context.options.favorites.get("value").items;
				var favoriteWorkflows = [];
				var all = view._instance.allCV._instance.allWorkstreams;
				var recents = view._instance.recentInstances;
				var workflows = [];
				if (all || recents) {
					var temp = all.concat(recents);
					workflows = temp.filter(function(item) {
						return item != null;
					});

					favoritesList.forEach(function(favorite) {
						 workflows.forEach(function(workflow) {
							if (view._proto._getOrderId(workflow) === favorite) {
								favoriteWorkflows.push(workflow);
							}
						});
					});
				}
				return favoriteWorkflows;
			},

            _updateData: function(view) {
				view._instance.NoFavoritesFound.setVisible(false, true);
                view._instance.favoriteWorkstreams = this._getFavoriteWorkflows(view);
				var isFavoritesEmpty = view._instance.favoriteWorkstreams.length === 0;
                view._instance.favoriteWorkstreams = this._groupWorkStreams(view._instance.favoriteWorkstreams);
                this._setViewData(view._instance.workstreamsCV, view._instance.favoriteWorkstreams, true);

				setTimeout(function() {
					view._instance.NoFavoritesFound.setVisible(isFavoritesEmpty, !isFavoritesEmpty);
					view._instance.NoFavoritesImage._instance.img.setAttribute("title", bpmext.localization.formatMsg("workplace", "emptyCube"));
					view._instance.NoFavoritesImage._instance.img.setAttribute("alt", bpmext.localization.formatMsg("workplace", "emptyCube"));
					// Accessibility
					if (view._instance.NoFavoritesFound.isVisible()) {
						taskUtils.setTabCycle(view);
					}
				}, 50);
            },

            _getOrderId: function(dashboard) {
				var orderId = "",
					itemId, systemId, idx, index;
				if(dashboard.ID && dashboard.itemID) {
					orderId = dashboard.ID;
					itemId = dashboard.itemID;
					systemId = dashboard.systemID;
					idx = itemId.lastIndexOf("-");
					if(idx !== -1) {
						orderId += itemId.slice(idx);
					}
					if(systemId) {
						index = systemId.lastIndexOf("-");
						if(index !== -1) {
							orderId += systemId.slice(index);
						}
					}
					orderId += "/";
				}  else if(dashboard.bpdName === "Configurable Workstream" || dashboard.processName === "Configurable Workstream" || dashboard.PT_NAME === "Configurable Workstream") {
					var name = dashboard.name || dashboard.PI_NAME;
					orderId = name + "-" + dashboard.type;
				} else {
					orderId = dashboard.systemID + "-" + dashboard.casetypeSymbolicName;
				}
				return orderId.toLowerCase();
			}
        };


        /*
        Public control methods *************************************************************
        */

		/**
		 * @instance
		 * @memberof WorkflowFavorites
		 * @method goNext
		 * @desc Go to step2
		 */
		this.constructor.prototype.goNext = function goNext() {
			bpmext.log.info("WorkflowFavorites.goNext ENTER>>", this);
			var selectedItem = this._instance.selectedWorkstream;
			if (selectedItem.bpdName === "Configurable Workstream" || selectedItem.processName === "Configurable Workstream") {
				taskUtils.EVENTS.LOAD_STACK_PANE.publish({targetView:"Name_Workstream1"});
				taskUtils.EVENTS.OPEN_NAME_WORKSTREAM.publish({
					selectedWorkstream: selectedItem,
					allExposedResource: this._instance.allCV._instance.allExposedItem,
					caller: "WORKFLOW_FAVORITES"
				});
			} else {
				taskUtils.EVENTS.SLIDEOUT_PANEL_CLOSE.publish();
				taskUtils.EVENTS.LAUNCH_RESOURCE.publish(selectedItem);
			}
		};

		/**
         * @instance
         * @memberof WorkflowFavorites
         * @method closeSlideout
         * @desc Closes the dialog
         */
        this.constructor.prototype.closeSlideout = function closeSlideout() {
            taskUtils.EVENTS.SLIDEOUT_PANEL_CLOSE.publish();
		};

		/**
         * @instance
         * @memberof WorkflowFavorites
         * @method selectSnapshot
         * @desc select a snapshot
         */
		this.constructor.prototype.selectSnapshot = function selectSnapshot(item) {
			bpmext.log.info("WorkflowFavorites.selectSnapshot ENTER >>", this);
			this._instance.selectedWorkstream = item;
			this._proto._setPrimaryButton(this);
		};

		/**
         * @instance
         * @memberof WorkflowFavorites
         * @method selectWorkflow
         * @desc select a workflow
         */
		this.constructor.prototype.selectWorkflow = function selectWorkflow(target, index) {
			bpmext.log.info("WorkflowFavorites.selectWorkflow ENTER >>", this);
			var data = this._instance.favoriteWorkstreams[target.ui.getIndex()];
			if(data && data[index] && data[index].snapshots && data[index].snapshots.length > 0) {
				target.openSnapshotLinks(data[index]);
			}
			this._instance.selectedWorkstream = data[index];
			this._proto._setPrimaryButton(this);
		};

        /**
		 * @instance
		 * @memberof WorkflowFavorites
		 * @method setWorkStreamData
		 * @desc set name and description
		 */
        this.constructor.prototype.setFavoriteWorkStreamData = function(target, index) {
            if (!this.isVisible()) {
                return;
            }
        	bpmext.log.info("WorkflowFavorites.setWorkStreamName ENTER>>", this);
            var stream = this._instance.favoriteWorkstreams[target.ui.getIndex()], name, description;
			var lastStream = this._instance.favoriteWorkstreams[this._instance.favoriteWorkstreams.length - 1]
			var obj = stream[index];
			if (obj){
				target.setVisible(true);
				name =  obj.display || obj.name;
				description = obj.itemDescription || obj.casetypeDescription;
				if(obj.type === "casetype"){
					target.setTitle(obj.display + " (" + obj.solutionName + ")");

					target._instance.card.context.element.firstElementChild.setAttribute("role", "form")
					target._instance.card.context.element.firstElementChild.setAttribute("aria-label",
						data[index].display + " (" + data[index].solutionName + ")"
						+ " " + bpmext.localization.formatMsg("workplace", "card"));
				} else{
					target.setTitle(name);

					target._instance.card.context.element.firstElementChild.setAttribute("role", "form")
					target._instance.card.context.element.firstElementChild.setAttribute("aria-label",
						name + " " + bpmext.localization.formatMsg("workplace", "card"));
				}
				target.setDescription(description);
				if(obj.snapshots && obj.snapshots.length > 0) {
					target.setSnapshotData(obj, target);
				}
				if (obj.type === "CHECKLIST"){
					target.setTopIcon("ci-list-checked");
				} else if(obj.type === "APPROVAL"){
					target.setTopIcon("ci-network-3");
				} else {
					target.setTopIcon("ci-flow-data");
				}
            } else {
				target.setVisible(false, true);
			}

			// Accessibility
			if (lastStream === stream && index === Object.keys(lastStream).length - 1 && this._instance.firstWorkflowLoad) {
				taskUtils.setTabCycle(this); 
			}
        };

        /**
		 * @instance
		 * @memberof WorkflowFavorites
		 * @method refresh
		 * @desc Reloads the favorites list
		 */
        this.constructor.prototype.refresh = function() {
			bpmext.log.info("WorkflowFavorites.refresh ENTER>>", this);

			this._instance.needRefresh = true;
        };

        this.constructor.prototype.removeFavorite = function(target, index) {
			var view = this;
			var stream = this._instance.favoriteWorkstreams[target.ui.getIndex()];
			this.context.options.favorites.get("value").items = this.context.options.favorites.get("value").items.filter(function(favorite) {
				return favorite !== view._proto._getOrderId(stream[index]);
			});
            this._proto._updateData(this);
        };

		this.constructor.prototype.setPanelOptions = function setPanelOptions(subtitle) {
			this._instance.MODAL_OPTIONS = {
				title: bpmext.localization.formatMsg("ConfigPanel", "title"),
				subtitle: subtitle,
				primaryBtnText: bpmext.localization.formatMsg("workplace", "next"),
				primaryBtnEvent: {method: dojo.hitch(this, this.goNext), args: null, closeOnEvtComplete: false},
				progressBarOptions: null,
				width: window.innerWidth>700? ((700/window.innerWidth) *100 + "%") : "100%"
			};
		};
        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function () {
            try {
                bpmext.log.info("FavoritesWorkstream.load ENTER >>", this);
                var view = this;
                var opts = view.context.options;

                if (!opts.favorites) {
                    bpmext.ui.substituteConfigOption(this, "favorites", []);
                }

				this._instance.NoFavoritesFound = bpmext.ui.getContainer("NoFavoritesVL", view);
				this._instance.NoFavoritesImage = bpmext.ui.getView("NoFavoritesImage", view);
                this._instance.workstreamsCV = bpmext.ui.getContainer("WorkstreamsVL", this);
				this._instance.favoritesLabel = bpmext.ui.getView("FavoriteWorkstreamsLabel", this);
				this._instance.favoritesLabel._instance.outputText.setAttribute("role", "heading");
				this._instance.favoritesLabel._instance.outputText.setAttribute("aria-level", "3");
				this._instance.allCV = view.ui.getSibling("Launch_list");
				this._instance.needRefresh = true;

                taskUtils.EVENTS.OPEN_FAVORITES.subscribe(function(){
                    var subtitle;
					if (this._instance.needRefresh) {
						this._instance.needRefresh = false;
						view._instance.allCV.generateRecent(view._instance.allCV._instance.allWorkstreams, this);
					} else {
						this._proto._updateData(view);
					}
					this._instance.selectedWorkstream = null;
					this._proto._setPrimaryButton(this);
                    taskUtils.EVENTS.LOAD_STACK_PANE.publish({targetView: view.context.viewid});
					if(this._instance.allCV._instance.allExposedItem.configurableWorkstream.itemID === taskUtils.CONFIGURABLE_WORKSTREAM_PROCESS_ID) {
						subtitle = bpmext.localization.formatMsg("ConfigPanel", "subtitle");
					} else {
						subtitle = bpmext.localization.formatMsg("ConfigPanel", "noWorkstreamSubtitle");
					}
					this.setPanelOptions(subtitle);
					this._instance.firstWorkflowLoad = true;
				}, this);

                taskUtils.EVENTS.WORKSTREAM_LAUNCHED.subscribe(function() {
                    view._proto._updateData(view);
				});

				// refresh launch list
				taskUtils.EVENTS.PROCESSES_UPDATING.subscribe(this.refresh, this);
				taskUtils.EVENTS.PROCESSES_UPDATED.subscribe(this.refresh, this);
				taskUtils.EVENTS.FORCED_REFRESH.subscribe(this.refresh, this);

                this.loadContainer(this);

                bpmext.log.info("WorkflowFavorites.load EXIT >>", this);
            } catch (error) {
                bpmext.log.error(error);
            }
        };

        this.constructor.prototype.view = function () {
            try {
                utilities.handleVisibility(this.context);
            } catch (e) {
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if (e.stack) {
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                }
            }
        };

        this.constructor.prototype.change = function (event) {
            bpmext.log.info("WorkflowFavorites.change ENTER >> (event): " + event, this);
			if (event.type === "config") {
                switch (event.property) {
                    case "_metadata.visibility": {
                        this.view();
                        break;
                    }
                }
            }
            bpmext.log.info("WorkflowFavorites.change EXIT >>", this);
        };

        this.constructor.prototype.unload = function () {
            bpmext.ui.unloadView(this);
        };
    }
};