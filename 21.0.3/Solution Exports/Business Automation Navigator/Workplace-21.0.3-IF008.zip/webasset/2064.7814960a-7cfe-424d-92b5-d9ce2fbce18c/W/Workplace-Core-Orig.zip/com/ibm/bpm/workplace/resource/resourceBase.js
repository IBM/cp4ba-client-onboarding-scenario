/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define("com.ibm.bpm.workplace.resources/resourceBase", [
    "dojo/_base/declare",
    "dojo/_base/config",
    "dojo/_base/lang",
    "dojo/string",
    "dojo/request",
    "./CallbackRegistry"
], function(declare, config, lang, string, request, cbr) {
    "use strict";
    var contextRoot,
        isFederated = false,
        isAppEngine = false;

    // compute all of the context roots and federation related flags
    if (window.dojoConfig && window.dojoConfig.App) {
        contextRoot = lang.clone(window.dojoConfig.App._bpmContextRootMap);
        // check if we are in App Engine
        if (contextRoot._proxyURI) {
            isAppEngine = true;
            // PFS is the only endpoint we talk to, so set us as federated
            isFederated = true;
            contextRoot.federatedURL = "/rest/bpm/federated";
            // we will let AE affix the context root for us
            contextRoot.rest = "";
        } else if ((contextRoot.bpmDataEndpoint || "").indexOf("federated") !== -1) {
            // check if we are federated or not
            isFederated = true;
            contextRoot.federatedURL = contextRoot.bpmDataEndpoint;
        }
    }

    var ResourceBaseDef = declare("BaseResource", null, {
        contextRoot: contextRoot,
        isFederated: isFederated,
        isAppEngine: isAppEngine,
        cbr: cbr,

        //Common value for several resources
        DEFAULT_TASK_LIST_SIZE: 500,

        /**
         * @returns an object containing default headers.
         */
        _getHeaders: function _getHeaders() {
            return {
                Accept: "application/json",
                "Accept-Language": config.locale,
                "Content-Type": "application/json"
            };
        },

        /**
         * Builds a URL by replacing ${key} with valid values from replacementMap
         *
         * @param {String} resource - A resource string , e.g. /v1/processes
         * @param {Object<String,String>} replacementMap - mapping of replacement key to replacement value
         * @param {Boolean} encode - true to call encodeURIComponent on each value in the replacement map, default is false
         * @returns {String} the resource string after replacement
         */
        _buildUrl: function _buildUrl(resource, replacementMap, encode) {
            if (replacementMap) {
                /* Encode arguments before substitution */
                if (encode) {
                    Object.keys(replacementMap).forEach(function(field) {
                        replacementMap[field] = encodeURIComponent(replacementMap[field]);
                    });
                }
                resource = string.substitute(resource, replacementMap);
            }

            return resource;
        },

        /**
         * Make a request using URL and Options
         * @param {String} url - the URL of the resource
         * @param {Object} options - options of the request, such as query, handleAs, method ...etc
         * @returns {Promise} - promise that resolves to the response object
         */
        makeRequest: function makeRequest(url, options) {
            if (url) {
                options = lang.mixin({ handleAs: "json" }, options);
                options.headers = lang.mixin(this._getHeaders(), options.headers);
                return request(url, options);
            }
        },
        /**
         * Make a GET request using URL and Options
         * @param {String} url - the URL of the resource
         * @param {Object} options - options of the request, such as query, handleAs, ...etc
         * @returns {Promise} - promise that resolves to the response object
         */
        get: function get(url, options) {
            return this.makeRequest(url, lang.mixin(options, { method: "GET" }));
        },
        /**
         * Make a POST request using URL and Options
         * @param {String} url - the URL of the resource
         * @param {Object} options - options of the request, such as query, handleAs, ...etc
         * @returns {Promise} - promise that resolves to the response object
         */
        post: function post(url, options) {
            return this.makeRequest(url, lang.mixin(options, { method: "POST" }));
        },
        /**
         * Make a PUT request using URL and Options
         * @param {String} url - the URL of the resource
         * @param {Object} options - options of the request, such as query, handleAs, ...etc
         * @returns {Promise} - promise that resolves to the response object
         */
        put: function put(url, options) {
            return this.makeRequest(url, lang.mixin(options, { method: "PUT" }));
        },
        /**
         * Make a DELETE request using URL and Options
         * @param {String} url - the URL of the resource
         * @param {Object} options - options of the request, such as query, handleAs, ...etc
         * @returns {Promise} - promise that resolves to the response object
         */
        del: function get(url, options) {
            return this.makeRequest(url, lang.mixin(options, { method: "DELETE" }));
        },
        /**
         * Show a message and log an error to the console
         * @param {Object} props - descriptor of the message to show
         * @param {string} props.title Alert title
         * @param {string} props.text Alert text
         * @param {string} props.style "S"=Success | "I"=Info | "P"=Primary | "W"=Warning | "D"=Danger
         * @param {integer} props.timeout time (in milliseconds) before alert automatically closes
         * @param {Object} [err] - associated error object
         */
        showMessage: function showMessage(props, err) {
            if (props) {
                require(["com.ibm.bpm.workplace.core/taskUtils"], function(taskUtils) {
                    // build the alert details
                    taskUtils.publishAlert(props);
                    if (err) {
                        // log the error in the console
                        console.error(props.text + "\n" + JSON.stringify(err).replace(/\\/g, ""));
                    }
                });
            }
        },
        /**
         * Show an error message and log an error to the console
         * @param {Object} props - error message to show
         * @param {Object} [err] - associated error object
         */
        showError: function showError(message, err) {
            this.showMessage({
                title: bpmext.localization.formatMsg("notifications", "notificationErrorTitle"),
                text: message,
                style: "E",
                timeout: 10000
            }, err);
        }
    });

    var ResourceBase = new ResourceBaseDef();

    return ResourceBase;
});
