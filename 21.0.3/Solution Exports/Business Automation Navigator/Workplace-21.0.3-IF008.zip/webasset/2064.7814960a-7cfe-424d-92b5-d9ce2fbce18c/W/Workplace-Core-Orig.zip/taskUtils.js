/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/* eslint-disable no-useless-escape */
define([
    "dojo/_base/lang",
    "./utils",
    "./events",
    "./viewHistory",
    "./constants",
    "./i18nUtils"
], function(lang, utils, events, viewHistory, constants, i18nUtils) {
    "use strict";

    var taskUtils = {};
    lang.mixin(taskUtils, utils);
    lang.mixin(taskUtils, events);
    lang.mixin(taskUtils, { viewHistory: viewHistory });
    lang.mixin(taskUtils, constants);
    lang.mixin(taskUtils, i18nUtils);

    taskUtils.isTaskCompleted = function(task) {
        return !!task && ((task.STATUS || task.status) === "Closed" || (task.STATE || task.state) === "STATE_FINISHED");
    };

    taskUtils.isUserTask = function(task) {
        return !!task && (task.serviceType === "HUMAN" || task.serviceType === "COACHFLOW" || task.serviceType === "APPLICATIONFLOW" || !task.serviceType);
    };

    taskUtils.processColumns = function(columns, listOfFieldsToIgnore, instanceMode) {
        var columnsToDisplay = [];
        columnsToDisplay = (columns || [])
            .filter(function(column) {
                return (listOfFieldsToIgnore || []).indexOf(column.name) < 0;
            })
            .map(function(column) {
                if(!!instanceMode){
                    column.value = taskUtils.getLabelFromInstanceProperty(column.name);
                    column.description = taskUtils.getInstanceSystemDataDescription(column.name);
                }else{
                    column.value = taskUtils.getLabelFromTaskProperty(column.name);
                    column.description = taskUtils.getTaskSystemDataDescription(column.name);
                }
                return column;
            });
        return columnsToDisplay;
    };

    taskUtils.getOriginProcess = function(origins) {
        var processArray = [], processObj = {};
        for(var i = 0; i < origins.length; i++) {
        	// simply get the processName
        	if(!processObj[origins[i].processName]) {
        		processObj[origins[i].processName] = origins[i];
        	}
        }
        processArray = Object.keys(processObj);
        return processArray;
    };
    
    taskUtils.processBusinessDataColumns = function(columns) {
        var columnsToDisplay = [], processOrigins, bdDisplayName;
        columnsToDisplay = (columns || [])
            .map(function(column) {
                bdDisplayName = taskUtils.getLabelFromID(column.name);
                //if the business data is defined in multiple process, show the process name
                if(column.origins && column.origins.length > 1) {
                    processOrigins = taskUtils.getOriginProcess(column.origins); 
                    if(processOrigins.length > 1) {
                    	bdDisplayName += " (" + processOrigins.join() + ")";
                    }
                }
                column.value = bdDisplayName;
                return column;
            });
        return columnsToDisplay;
    };

    taskUtils.setNotificationExistence = function(val) {
        taskUtils.isNotificationSystemExist = val;
    };

    taskUtils.getNotificationExistence = function() {
        return !!taskUtils.isNotificationSystemExist;
    };

    taskUtils.publishAlert = function(data) {
        var notificationsDOM = document.querySelector("[data-viewid='Notifications']"),
            notificationsViewPath = (notificationsDOM && notificationsDOM.getAttribute("control-name")) || undefined,
            notificationsView = notificationsViewPath && bpmext.ui.getView(notificationsViewPath);
        if (notificationsView && data) {
            notificationsView.appendAlert(data.title, data.text, data.style, data.timeout);
        }
    };

    taskUtils.publishError = function(msg) {
        var props = {
            title: bpmext.localization.formatMsg("notifications", "notificationErrorTitle"),
            text: msg,
            style: "E",
            timeout: 10000
        };
        taskUtils.publishAlert(props);
    };

    taskUtils.isWorkstreamProcess = function isWorkstreamProcess(process) {
        var RWF_IDENTS = [{
            isWorkstream: true,
            snapshotID: "2064.c8f265bc-b3af-448a-86e6-b68f5ba61b30",
            processAppAcronym: "RWF"
        }];

        return !!process && RWF_IDENTS.reduce(function (cumResult, ident) {
            return cumResult || Object.keys(ident).reduce(function (isWorkstream, field) {
                return isWorkstream || process[field] === ident[field];
            }, false);
        }, false);
    };

    taskUtils.createExpandableRow = function createExpandableRow(view, utilities, div, data) {
        var escape = view.context.htmlEscape.bind(view.context);

        [data.systemData, data.businessData].forEach(_filterHiddenValues);
        _createExpandedRowList(view, div, data);

        function _filterHiddenValues(map) {
            map.forEach(function (value, key) {
                if (value === null || typeof value === "undefined" || value === "") {
                    map.delete(key);
                }
            });
        }

        function _createExpandedRowList(view, container, data) {
            container.classList.add("expanded-row");

            if (data.description) {
                var descriptionParagraph = document.createElement("p");
                container.appendChild(descriptionParagraph);
                descriptionParagraph.classList.add("expanded-row__description");
                descriptionParagraph.textContent = data.description;
                if (_isEllipsisActive(descriptionParagraph)) {
                    bpmext.ui.util.showTooltip(
                        descriptionParagraph,
                        escape(data.description),
                        {horizontalPos: "LEFT", smartPositioning: true}
                    );
                }
            }

            var listContainer = document.createElement("div");
            container.appendChild(listContainer);
            listContainer.classList.add("expanded-row__lists");

            _createButtonColumn(listContainer, data.taskOrInstance);

            var systemList = document.createElement("ul");
            systemList.classList.add("expanded-row__list");
            listContainer.appendChild(systemList);
            _createExpandedColumn(view, systemList, data.systemData || data.caseData, data.rowData);

            if (data.businessData && data.businessData.size !== 0) {
                var businessList = document.createElement("ul");
                businessList.classList.add("expanded-row__list", "expanded-row__lists__list--business");
                listContainer.appendChild(businessList);
                _createExpandedColumn(view, businessList, data.businessData, data.rowData);
            }
        }

        function _createButtonColumn(listContainer, taskOrInstance) {

            var buttonColumn = document.createElement("div");
            buttonColumn.classList.add("expanded-row__lists__button-column");
            listContainer.appendChild(buttonColumn);

            var labelContainer = document.createElement("div");
            labelContainer.classList.add("expanded-row__lists__button-column__label");
            buttonColumn.appendChild(labelContainer);

            if (taskOrInstance) {
                _setDueTextAndIcon(labelContainer, taskOrInstance);
            }

            buttonColumn.appendChild(div.querySelector(".Button"));
        }

        function _setDueTextAndIcon(labelContainer, taskOrInstance) {
            var icon, url, daysUntil, iconLabel = document.createElement("p");
            iconLabel.classList.add("expanded-row__lists__button-column__label__text");

            if (taskOrInstance.executionState === "Completed" || taskOrInstance.completionTime || taskOrInstance.PI_STATUS === "Completed") {
                icon = utilities.getCarbonIcon("ci-checkmark-filled");
                icon.classList.add("expanded-row__lists__button-column__label__icon");
                icon.classList.add("success");
                labelContainer.appendChild(icon);
                labelContainer.appendChild(iconLabel);
                
                daysUntil = utils.getDaysUntil(taskOrInstance.completionTime || taskOrInstance.lastModificationTime || taskOrInstance.PI_COMPLETED);
                iconLabel.textContent = i18nUtils.getCompletedLabel(daysUntil);
                return;
            }

            url = i18nUtils.getTaskDueStatusImageURL(taskOrInstance);
            icon = document.createElement("img");
            icon.src = url;
            icon.setAttribute("alt", bpmext.localization.formatMsg("searchFilter", "status"));
            icon.classList.add("expanded-row__lists__button-column__label__icon");
            labelContainer.appendChild(icon);
            labelContainer.appendChild(iconLabel);

            if (taskOrInstance.dueDate || taskOrInstance.dueTime || taskOrInstance.PI_DUE) {
            	daysUntil = utils.getDaysUntil(taskOrInstance.dueDate || taskOrInstance.dueTime || taskOrInstance.PI_DUE);
                iconLabel.textContent = i18nUtils.getDueLabel(daysUntil);
            } else {
            	daysUntil = utils.getDaysUntil(taskOrInstance.lastModificationTime || taskOrInstance.PI_LAST_MODIFICATION);
                iconLabel.textContent = i18nUtils.getModifiedLabel(daysUntil);
            }
        }

        function _createExpandedColumn(view, list, data, rowData) {
            list.classList.add("expanded-row__lists__list");

            var i = 0;
            data.forEach(function(dataValue, key) {
                if (i === 9) {
                    var linkLi = document.createElement("li");
                    linkLi.classList.add("expanded-row__lists__list__item");
                    var link = _createViewAllLink(view, rowData, data);
                    linkLi.appendChild(link);
                    list.appendChild(linkLi);
                    i++;
                    return;
                } else if (i > 9) {
                    return;
                }
                var li = document.createElement("li");
                li.classList.add("expanded-row__lists__list__item");
                list.appendChild(li);

                var label = document.createElement("p");
                label.classList.add("expanded-row__lists__list__item__label");
                label.textContent = key;
                li.appendChild(label);

                var value = document.createElement("p");
                value.classList.add("expanded-row__lists__list__item__value");

                if (typeof dataValue === "string") {
                    value.textContent = dataValue;
                } else if (Array.isArray(dataValue)) { // support case multi-value which return as an array
                    value.textContent = dataValue.join();
                } else if (!!dataValue && typeof dataValue === "object") {
                    if (dataValue.type === "LINK") {
                        var a = document.createElement("a");
                        a.classList.add("expanded-row__lists__list__item__value__link");

                        a.setAttribute("href", "javascript:void(0)");
                        a.setAttribute("target", "_self");
                        a.setAttribute("aria-label", dataValue.value);

                        a.textContent = dataValue.value;

                        a.onclick = dataValue.onclick || function () {};

                        value.appendChild(a);
                    } else {
                        value.textContent = dataValue.value || "";
                    }
                } else {
                    value.textContent = dataValue;
                }
                li.appendChild(value);

                if (_isEllipsisActive(label)) {
                    bpmext.ui.util.showTooltip(
                        label,
                        escape(key),
                        {horizontalPos: "LEFT", smartPositioning: true}
                    );
                }

                if (_isEllipsisActive(value)) {
                    var tpContent = (!!dataValue && typeof dataValue === "object") ? dataValue.value : dataValue;
                    bpmext.ui.util.showTooltip(
                        value,
                        escape(tpContent),
                        {horizontalPos: "LEFT", smartPositioning: true}
                    );
                }
                i++;
            });
            return list;
        }

        function _createViewAllLink(view, rowData, data) {
            var a = document.createElement("a");
            bpmext.ui.util.showTooltip(
                a,
                bpmext.localization.formatMsg("instanceList", "openWorkflowTooltip"),
                { verticalPos: "BOTTOM", smartPositioning: true }
            );
            a.href = "javascript:void(0)";
            a.textContent = bpmext.localization.formatMsg("controlTaskList", "viewMore", data.size);
            a.addEventListener("keydown", function (event) {
                if (event.key === " " || event.key === "Enter" || event.key === "Spacebar") {
                    this.click();
                    event.preventDefault();
                }
            });
            a.onclick = function () {
                view._proto._launchInstance(view, rowData);
            };
            return a;
        }

        /**
         * Precondition; The element needs to be added to the DOM in order to have a width
         */
        function _isEllipsisActive(e) {
            return e.offsetWidth < e.scrollWidth ||
                    e.offsetHeight < e.scrollHeight;
        }
    };

    /**
     * Convenience function to throttle using the default throttle duration.
     * See Constants#DEFAULT_THROTTLE_DURATION
     *
     * @param {Function} callback - function to throttle
     */
    taskUtils.throttle = function (callback) {
        return taskUtils.throttleTrailingEdge(callback, taskUtils.DEFAULT_THROTTLE_DURATION);
    };
    
    /**
     * Convenience function to enable clipboard copy for the contents of an element when it is clicked.
     *
     * @param {Element} element - element to enable for clipboard copy
     */
    taskUtils.enableClipboard = function(element) {
        var _this = this;
        element.style.cursor = "pointer";
        element.addEventListener("click", function(event) {
            var result = _this.copyToClipboard(event.target);

            if(result) {
                var tooltip = bpmext.ui.util.showTooltip(
                    event.target,
                    bpmext.localization.formatMsg("workplace", "copied"),
                    {horizontalPos: "LEFT", smartPositioning: true, alwaysShow: true}
                );

                setTimeout(function() {
                    bpmext.ui.util.closeTooltip(tooltip, event.target);
                }, 2000);
            }
        });
    };

    /**
     * Convenience function to copy the contents of an element or string to the clipboard.
     *
     * @param {Element} element Element to enable for clipboard copy.  If this is not provided, the text parameter is used (optional)
     * @param {string} text Text to copy to the clipboard.  This is only used if the element is undefined (optional)
     * @returns {bool} True if the copy was successful; false otherwise
     */
    taskUtils.copyToClipboard = function(element, text) {
        var result = false;
        var selection, range;
        
         if (element instanceof HTMLInputElement && element.select) {
             selection = element.select();
         } else if (element) {
             //Not an input element but there is still some text selected on the page
            selection = window.getSelection();
            range = document.createRange();
            range.selectNodeContents(element);
            selection.removeAllRanges();
            selection.addRange(range);
         } else {
             //no element so create a temporary textarea and use the provided text
             var el = document.createElement("textarea");
             el.value = text;
             el.setAttribute("readonly", "");
             el.style.position = "absolute";
             el.style.left = "-9999px";
             document.body.appendChild(el);
             el.select();
             document.execCommand("copy");
             document.body.removeChild(el);
        }

        try {
            document.execCommand("copy");
            selection && selection.removeAllRanges && selection.removeAllRanges();
            result = true;
        } catch (e) {
            this.publishError("Failed to copy");
        }
        return result;
    };

    /**
     * Returns a URL link to the current page, or the page defined in the link Context
     * @param {View} view Any view, used to get the view context
     * @param {Object} linkContext The context of the link.  The object should have a name, type, and optional data 
     */
    taskUtils.getLink = function(view, linkContext) {
        var queryStrIndex = 0;
        var history, data, type, root;
        var link;

        if (!linkContext) {
            //No context provided, so use the view history
            type = "dashboard";
            root = this.viewHistory.getViewRootIdent();

            history = this.viewHistory.getViewHistory();
            history = history[history.length-1];
            data = history.data;
            if (data) {
                if (data.piid) {
                    if (data.type === "Case") {
                        type = "case";
                    } else {
                        type = "instance";
                    }
                } else if (data.tkiid) {
                    type = "task";
                }

                if (type === "dashboard" || type === "case") {
                    root = history.displayName;
                }
            }
            linkContext = {name: root, type: type, data: data};
        }

        if (view.context.getAddressableUrl) {
            link = view.context.getAddressableUrl(linkContext);
        } else {
            //fallback in case the view.context helper is not defined
            link = window.location.href;
            queryStrIndex = link.indexOf("?"); 
            if (queryStrIndex === -1) {
                link += "?";
            }
            if (link.lastIndexOf("&") > queryStrIndex) {
                link += "&";
            }
            link += "appState=" + JSON.stringify(linkContext);
        }

        return link;
    };

    taskUtils.isElementVisible = function(element) {
        return !!(element.offsetWidth || element.offsetHeight || element.getClientRects().length);
    };

    taskUtils.getFocusElementList = function(element, isPopup) {
        var tabbableSelector = "a[href], area[href], input:not([disabled]):not([tabindex=\'-1\']), " +
        "button:not([disabled]):not([tabindex=\'-1\']),select:not([disabled]):not([tabindex=\'-1\']), " +
        "textarea:not([disabled]):not([tabindex=\'-1\']), " +
        "iframe, object, embed, *[tabindex]:not([tabindex=\'-1\']), *[contenteditable=true]";

        if (isPopup) {
            tabbableSelector = ".mnTextItem, .delete, a[tabindex='0'], .menuitem-tooltip-icon > svg";
        }

        var elements = element.querySelectorAll(tabbableSelector);
        
        
        if (elements) {
            var filteredElements = Array.prototype.slice.call(elements).filter(function(el) {
                return taskUtils.isElementVisible(el);
            });
            return filteredElements;
        } else {
            return elements;
        }
    };

    taskUtils.setTabCycle = function(view) {
        var modalView = view.ui.get("ModalSection") ? view.ui.get("ModalSection") : view._instance.modalSection ? view._instance.modalSection : view.ui.getParent();
        var tabList = taskUtils.getFocusElementList(modalView.context.element, false);
        var primaryButton = modalView._instance.primaryButton ? modalView._instance.primaryButton._instance.btn : modalView._instance.primaryBtn;
        var closeButton = modalView._instance.closeButton ? modalView._instance.closeButton._instance.btn : modalView._instance.modalContent.querySelector(".panel-heading-icon.clickable");
        var isPrimaryBtnVisible = modalView._instance.primaryButton ? modalView._instance.primaryButton.isVisible() : taskUtils.isElementVisible(modalView._instance.primaryBtn);

        if (tabList.length === 0) { return; }

        function closeButtonFocus(event) {
            if (event.shiftKey) {
                return;
            }
            event.preventDefault();
            closeButton.focus();
        }

        view._instance.handleEvent  = function(event) {
            if (event.target === primaryButton) {
                if (event.key === "Tab") {
                    closeButtonFocus(event);
                }
            } else if (event.target === closeButton) {
                if (event.key === "Tab" && event.shiftKey) {
                    event.preventDefault();
                    if (primaryButton.classList.contains("disabled") || primaryButton.hasAttribute("disabled") || !isPrimaryBtnVisible) {
                        tabList[tabList.length - 1].focus();
                    } else {
                        primaryButton.focus();
                    }
                }

                if (event.key === " " || event.key === "Spacebar" || event.key === "Enter") {
                    event.preventDefault();
                    if (view.ui.get("ModalSection") || view._instance.modalSection) {
                        if(modalView.context.options.closeOnClick.get("value")) {
                            view.closeModal();
                        }
                    } else {
                        modalView.closePanel();
                    }
                }
            } else {
                if (!primaryButton.classList.contains("disabled") && !primaryButton.hasAttribute("disabled") && isPrimaryBtnVisible) { return; }
                if (event.key === "Tab") {
                    closeButtonFocus(event);
                }
            }
        };

        if (view._instance.lastElement) {
            view._instance.lastElement.removeEventListener("keydown", view._instance.boundEventHandler); 
            closeButton.removeEventListener("keydown", view._instance.boundEventHandler);
            primaryButton.removeEventListener("keydown", view._instance.boundEventHandler);
        }

        view._instance.boundEventHandler = view._instance.handleEvent.bind(view);
        view._instance.lastElement = tabList[tabList.length - 1];
        view._instance.lastElement.addEventListener("keydown", view._instance.boundEventHandler);
        closeButton.addEventListener("keydown", view._instance.boundEventHandler);
        primaryButton.addEventListener("keydown", view._instance.handleEvent);
        view._instance.firstWorkflowLoad = false;
    };

    /**
     * Adds a tooltip to an view
     * @param {View} view The view to add the toltip to
     * @param {String}  ttpText The text of the tooltip
     * @param {int} delay The tooltip delay in ms 
    */
    taskUtils.addTooltip = function(view, ttpText, delay) {
        // Add mouse hover tooltip
        var timeout,titleElt = null,icon = view.context.element;
        icon.onmouseenter = function(){
            timeout = setTimeout(function() {
                titleElt = bpmext.ui.util.showTooltip(icon, ttpText, {
                    horizontalPos: "LEFT",
                    smartPositioning: true,
                    alwaysShow: true
                });
            },delay);
        };
        icon.onmouseleave = function() {
            // Clear any timers set to timeout
            clearTimeout(timeout);
            if(titleElt != null){
                bpmext.ui.util.closeTooltip(titleElt, icon);
                titleElt = null;
            }
        };
    };

    return taskUtils;
});
