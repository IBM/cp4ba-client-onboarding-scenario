/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define("com.ibm.bpm.workplace.resources/ExposedResource", ["./resourceBase"], function (resource) {
    "use strict";
    var ROUTE = resource._buildUrl("${urlPrefix}/v1/${pathParam}", {
            urlPrefix: resource.contextRoot.federatedURL || resource.contextRoot.rest,
            pathParam: resource.isFederated ? "launchableEntities" : "exposed"
        }),
        SERVICE_SUBTYPE = {
            URL: "url",
            DASHBOARD: "dashboard",
            NOT_EXPOSED: "not_exposed",
            STARTABLE_SERVICE: "startable_service",
            INSTANCE_DETAILS_UI: "instance_details_ui",
            ADMINISTRATION_SERVICE: "administration_service"
        },
        // map to hold the query *string*s and its corresponding request
        requestStore = {};

    /**
     * Get a list of exposed resources
     *
     * @param {Object} [options] - optional params to pass to the underlying API
     * @param {String[]} [options.subtypes] - A comma-separated list of one or more service subtypes to be included in the result set. If service subtypes are not specified, all service subtypes are included. See #SERVICE_SUBTYPE
     * @param {Boolean} [options.excludeProcessStartUrl] - true to skip generation of process start url
     * @param {String[]} [options.excludeReferencedFromToolkit] - Comma-separated list of types or service subtypes that should be excluded from referenced toolkits. See #SERVICE_SUBTYPE
     * @param {String} [options.forUser] - User name of the user about whom information is required.
     * @param {Boolean} [options.includeDescription] - true to include item description for bpd process.
     * @param {String} [options.filterByName] - A comma separated list of item name that should be included in the result set
     * @param {Boolean} [options.refresh] - true to ignore promise in cache and make a new request
     * @returns {Promise} promise that resolves to the response object
     */
    function get(options) {
        var url = ROUTE,
            query = {},
            refresh = false,
            queryString = "default"; // default string for request with no options
        // the queryString will be built bit by bit because there is no guarantee
        // that JSON.stringify(query) will preserve the order of the properties
        
        // build query params
        if (options) {
            refresh = options.refresh;
            if (Array.isArray(options.subtypes)) {
                query.includeServiceSubtypes = options.subtypes.join();
                queryString += "-includeServiceSubtypes-" + query.includeServiceSubtypes;
            }
            if (typeof options.excludeProcessStartUrl === "boolean") {
                query.excludeProcessStartUrl = options.excludeProcessStartUrl;
                queryString += "-excludeProcessStartUrl-" + query.excludeProcessStartUrl;
            }
            if (Array.isArray(options.excludeReferencedFromToolkit)) {
                query.excludeReferencedFromToolkit = options.excludeReferencedFromToolkit.join();
                queryString += "-excludeReferencedFromToolkit-" + query.excludeReferencedFromToolkit;
            }
            if (options.forUser) {
                query.forUser = options.forUser;
                queryString += "-forUser-" + query.forUser;
            }
            if (typeof options.includeDescription === "boolean") {
                query.includeDescription = options.includeDescription;
                queryString += "-includeDescription-" + query.includeDescription;
            }
            if (Array.isArray(options.filterByName)) {
                query.filterByName = options.filterByName.join();
                queryString += "-filterByName-" + query.filterByName;
            }
        }

        // check the map if we have used the same query before or if we are told to refresh
        if (!requestStore[queryString] || refresh) {
            // make the REST call and store it in the map
            requestStore[queryString] = resource
                .get(url, {
                    query: query
                })
                .then(function success(res) {
                    var data = resource.isFederated ? res : res.data.exposedItemsList;
                    return data;
                });
        }
        // return the promise
        return requestStore[queryString];
    }

    // module.exports
    return {
        get: get,
        SERVICE_SUBTYPE: SERVICE_SUBTYPE
    };
});
