/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define("com.ibm.bpm.workplace.resources/AdhocActivityResource", ["./resourceBase"], function (resource) {
    "use strict";
    var ROUTE = "${urlPrefix}/v1/activity/${activityId}",
        CONSTANTS = {
            STATE: "executionState",
            STATE_READY: "READY",
            STATE_WORKING: "WORKING",
            STATE_DISABLED: "DISABLED",
            STATE_COMPLETED: "COMPLETED",
            EXECUTION_TYPE: "executionType",
            MANUAL: "MANUAL",
            AUTOMATIC: "AUTOMATIC",
            ID: "id",
            NAME: "name",
            OPTION_TYPE: "optionType",
            OPTION_TYPE_REQUIRED: "REQUIRED",
            REQUIRED: "required",
            REPEATABLE: "repeatable",
            START_TIME: "startTime",
            END_TIME: "endTime",
            DUE_DATE: "dueDate",
            TASK_ID: "taskId"
        },
        ACTIONS = {
            ACTION_VIEW_ACTIVITY: "ACTION_VIEW_ACTIVITY",
            ACTION_START_ACTIVITY: "ACTION_START_ACTIVITY",
            ACTION_DISABLE_ACTIVITY: "ACTION_DISABLE_ACTIVITY",
            ACTION_ENABLE_ACTIVITY: "ACTION_ENABLE_ACTIVITY"
        };

    /**
     * Get Activity details
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {Number} options.activityId - Activity Id to get details for
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     *
     * @returns {Promise} promise that resolved to the response object
     */
    function get(options) {
        var url;
        if (options && options.activityId) {
            url = resource._buildUrl(ROUTE, {
                urlPrefix: resource.contextRoot.rest,
                activityId: options.activityId
            });
            return resource
                .get(url, {
                    query: {
                        federationMode: resource.isFederated
                    },
                    systemID: options.systemID
                })
                .then(function success(res) {
                    var data = resource.isFederated ? res : res.data;
                    // add systemID to the returned object
                    if (res.systemID) {
                        data.systemID = res.systemID;
                    }
                    return data;
                }, function error(err) {
                    if (err && err.response && err.response.status === 404) {
                        resource.showError(bpmext.localization.formatMsg("Errors", "activityNotAvailable"), err);
                    }
                    throw err;
                });
        }
    }

    /**
     * Get Activity actions
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {Number} options.activityId - Activity Id to get actions for
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     *
     * @returns {Promise} promise that resolved to the response object
     */
    function getActions(options) {
        var url;
        if (options && options.activityId) {
            url = resource._buildUrl(ROUTE, {
                urlPrefix: resource.contextRoot.rest,
                activityId: options.activityId
            });
            url += "/availableActions";
            return resource
                .get(url, {
                    query: {
                        federationMode: resource.isFederated
                    },
                    systemID: options.systemID
                })
                .then(function success(res) {
                    var data = resource.isFederated ? res : res.data;
                    // add systemID to the returned object
                    if (res.systemID) {
                        data.systemID = res.systemID;
                    }
                    return data;
                }, function error(err) {
                    if (err && err.response && err.response.status === 404) {
                        resource.showError(bpmext.localization.formatMsg("Errors", "activityNotAvailable"), err);
                    }
                    throw err;
                });
        }
    }

    /**
     * Get Activity tasks
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {Number} options.activityId - Activity Id to get tasks for
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     *
     * @returns {Promise} promise that resolved to the response object
     */
    function getTasks(options) {
        var url;
        if (options && options.activityId) {
            url = resource._buildUrl(ROUTE, {
                urlPrefix: resource.contextRoot.rest,
                activityId: options.activityId
            });
            url += "/tasks";
            return resource
                .get(url, {
                    query: {
                        federationMode: resource.isFederated
                    },
                    systemID: options.systemID
                })
                .then(function success(res) {
                    var data = resource.isFederated ? res : res.data;
                    // add systemID to the returned object
                    if (res.systemID) {
                        data.systemID = res.systemID;
                    }
                    return data;
                }, function error(err) {
                    if (err && err.response && err.response.status === 404) {
                        resource.showError(bpmext.localization.formatMsg("Errors", "activityNotAvailable"), err);
                    }
                    throw err;
                });
        }
    }

    /**
     * Perform enable, disable or start of an activity
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {Number} options.activityId - Activity Id to perform the action on
     * @param {String} options.action - The action to perform on the process instance, [ACTION_START_ACTIVITY, ACTION_ENABLE_ACTIVITY, ACTION_DISABLE_ACTIVITY]
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     *
     * @returns {Promise} promise that resolved to the response object
     */
    function _performAction(options) {
        var url,
            query = {};

        if (options && options.activityId && options.action) {
            url = resource._buildUrl(ROUTE, {
                urlPrefix: resource.contextRoot.rest,
                activityId: options.activityId
            });

            // build query params
            query.action = options.action;

            return resource
                .put(url, {
                    query: query,
                    systemID: options.systemID
                })
                .then(function success(res) {
                    // add systemID to the returned object
                    if (res.systemID) {
                        res.data.systemID = res.systemID;
                    }
                    return res.data;
                });
        }
    }

    /**
     * Starts an activity
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {Number} options.activityId - Activity Id to start
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     *
     * @returns {Promise} promise that resolved to the response object
     */
    function startActivity(options) {
        options.action = ACTIONS.ACTION_START_ACTIVITY;
        return _performAction(options);
    }

    /**
     * Enables an activity
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {Number} options.activityId - Activity Id to enable
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     *
     * @returns {Promise} promise that resolved to the response object
     */
    function enableActivity(options) {
        options.action = ACTIONS.ACTION_ENABLE_ACTIVITY;
        return _performAction(options);
    }

    /**
     * Disables an activity
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {Number} options.activityId - Activity Id to disable
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     *
     * @returns {Promise} promise that resolved to the response object
     */
    function disableActivity(options) {
        options.action = ACTIONS.ACTION_DISABLE_ACTIVITY;
        return _performAction(options);
    }

    return {
        CONSTANTS: CONSTANTS,
        ACTIONS: ACTIONS,
        get: get,
        getActions: getActions,
        getTasks: getTasks,
        startActivity: startActivity,
        enableActivity: enableActivity,
        disableActivity: disableActivity
    };
});
