/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
(function() {
    "use strict";
    //setDeveloperMode
    if (document.location.href.indexOf("mode=developer") !== -1) {
        dojoConfig.isDeveloperMode = true;
    }
    var corePath = "../../../../../workplace/files/Core",
        zipFileName = dojoConfig.isDebug ? "Workplace-Core-Orig.zip" : "Workplace-Core.zip",
        baseLocation = dojoConfig.isDeveloperMode
            ? corePath
            : com_ibm_bpm_coach.getManagedAssetUrl(zipFileName, com_ibm_bpm_coach.assetType_WEB, "SYSWPT");

    require({
        packages: [
            {
                name: "com.ibm.bpm.workplace.localization",
                location: baseLocation + "/com/ibm/bpm/workplace/localization"
            },
            {
                name: "com.ibm.bpm.workplace.resources",
                location: baseLocation + "/com/ibm/bpm/workplace/resource",
                main: "WPResources"
            },
            {
                name: "com.ibm.bpm.workplace.core",
                location: baseLocation
            },
        ]
    }, [], function() { //{#feature: US-1330 Added RT localization dependency (ED)}
        if (document.querySelector("html")) {
            //{#bug: * Moved init log statement to when initialization actually occurs (to eliminate false reports of initialization)}
            console.debug("Initializing Workplace Core");

            //{#feature: US-1330 Added RT localization dependency (ED)}
            require(["com.ibm.bpm.workplace.localization"], function(localization) {
                localization.initMessages(null);
            });

            // require main resources module
            require(["com.ibm.bpm.workplace.resources"], function (wpResources) {
                // Inject walkme snippet
                require(["com.ibm.bpm.workplace.resources/resourceBase"], function (resourceBase) {
                    // don't inject walkme when running on AE -for now-
                    if (!resourceBase.isAppEngine) {
                        wpResources.config.get().then(function (cfg) {
                            if (cfg.walkme.enable) {
                                // see https://support.walkme.com/knowledge-base/snippet/
                                var walkme = document.createElement("script");
                                walkme.type = "text/javascript";
                                walkme.async = true;
                                walkme.src = cfg.walkme.url;
                                var s = document.getElementsByTagName("script")[0];
                                s.parentNode.insertBefore(walkme, s);
                                window._walkmeConfig = { smartLoad: true };
                            }
                        });
                    }
                });
            });
        }
    });
})();
