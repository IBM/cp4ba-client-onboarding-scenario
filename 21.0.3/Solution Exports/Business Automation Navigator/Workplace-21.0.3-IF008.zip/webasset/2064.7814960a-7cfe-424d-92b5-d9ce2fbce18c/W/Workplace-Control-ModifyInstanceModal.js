/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
 /**
 * @ignore
 * @instance
 * @memberof ModifyInstanceModal
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof ModifyInstanceModal
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof ModifyInstanceModal
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof ModifyInstanceModal
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof ModifyInstanceModal
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof ModifyInstanceModal
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof ModifyInstanceModal
 * @method triggerFormulaUpdates
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 * </table>
 */
workplace_control_InitModifyInstanceModal = function (utilities, taskUtils, wpResources, domAttr)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            EVT_ONINSTANCE_MODIFIED: "EVT_ONINSTANCE_MODIFIED",
            _loadModal: function _loadModal(view) {
                bpmext.log.info("ModifyInstanceModal._loadModal LOG >> (taskId): ", view);
                view._proto._getProcess(view);
            },
            _getProcess: function _getProcess(view) {
                bpmext.log.info("ModifyInstanceModal._getProcess LOG >>", view);
                if(view._instance.task != null){
                    try {
                        wpResources.process.get({piid:view._instance.task.piid, systemID: view._instance.task.systemID})
                            .then(dojo.hitch(view, function(process) {
                                if (process) {
                                    this._instance.process = process;
                                    this._proto._setProcessInfo(this);
                                } else {
                                    this._instance.process = null;
                                }
                            }));
                    } catch (error) {
                        bpmext.log.error(error.message);
                    }
                }else{
                    view._proto._setProcessInfo(view);
                }
            },
            _setProcessInfo: function _setProcessInfo(view) {
                bpmext.log.info("ModifyInstanceModal._setProcessInfo LOG >> (taskId): ", view);
                // Set due date
                if(view._instance.process.dueDate){
                    view._instance.dueDateTimePicker.setDate(new Date(view._instance.process.dueDate));
                    view._instance.disableDueDateCheckbox.setChecked(false);
                }else{
                    view._instance.dueDateTimePicker.setDate();
                    view._instance.disableDueDateCheckbox.setChecked(true);
                }
                // Set task assignment
            },
            _hideModel: function _hideModel(view){
                bpmext.log.info("ModifyInstanceModal._hideModel LOG >>", view);
                view._instance.modalSection.setVisible(false);
                view.setVisible(false, true);
            },
            _postDueDateInfo: function _postDueDateInfo(view) {
                bpmext.log.info("ModifyInstanceModal._postDueDateInfo LOG >>", view);
                try {
                    // update date
                    var updateDate = false;
                    var currentDate = view._instance.process.dueDate ? new Date(view._instance.process.dueDate) : null;
                    var newDate = view._instance.dueDateTimePicker.getDate();

                    if(!view._instance.disableDueDateCheckbox.isChecked()){
                        if(newDate){
                            if(currentDate){
                                if(currentDate.getTime() !== newDate.getTime()){
                                    //current process due date and new due date exists, are valid dates and are different then we would update date
                                    updateDate = true;
                                }
                            }else{
                                //current date is none which means due date is disabled but new date is a valid date so update date
                                updateDate = true;
                            }
                        }
                    }

                    var systemID = view._instance.task? view._instance.task.systemID : undefined;
                    var invokeModifyInstanceEvent = function() {
                        if (view._instance.closeEventDelay) {
                            delete view._instance.closeEventDelay;
                        }

                        view._instance.closeEventDelay = setTimeout(function () {
                            delete view._instance.closeEventDelay;

                            bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONINSTANCE_MODIFIED);
                            taskUtils.EVENTS.MODIFY_INSTANCE_CLOSE.publish();
    
                            //if the instance is being modified in an iframe, try to post the close instance event to the parent
                            if (parent && parent !== parent.parent) {
                                try {
                                    var data = {
                                        name: "modifyInstance"
                                    };
                                    parent.parent.postMessage(JSON.stringify(data), "*");
                                } catch (e) {
                                    bpmext.log.error("invokeModifyInstanceEvent " + bpmext.localization.formatMsg("general", "ERROR") + ": " + e);
                                    if (e.stack) {
                                        bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                                    }
                                }
                            }
                        }, wpResources.isFederated ? 1500 : 500);
                    };

                    if(updateDate){
                        //occurs when the above condition meets we would update process due date to a new date
                        wpResources.process.updateDueDate({piid:view._instance.process.piid, dueDate:newDate, systemID: systemID}).then(invokeModifyInstanceEvent);
                    }else{
                        if(currentDate){
                            /*none of the above conditions were met meaning the new date is empty, they are both not empty but are the same value or disable due date is checked but current process date exist
                            so we update the due date to none in order to disable due date*/
                            if(currentDate.getTime() !== newDate.getTime()||view._instance.disableDueDateCheckbox.isChecked()){
                                wpResources.process.updateDueDate({piid:view._instance.process.piid, systemID: systemID}).then(invokeModifyInstanceEvent);
                            }
                        }
                    }
                } catch (error) {
                    bpmext.log.error(error.message);
                }
            }
        };


        /*
        Public control methods *************************************************************
         */

         /**
		 * @instance
		 * @memberof ModifyInstanceModal
		 * @method closeModal
		 * @desc Closes the modal dialog
		 */
        this.constructor.prototype.closeModal = function() {
			bpmext.log.info("ModifyInstanceModal.closeModal ENTER >> ",this);
			this._proto._hideModel(this);
			bpmext.log.info("ModifyInstanceModal.closeModal EXIT << ");
        };

         /**
		 * @instance
		 * @memberof ModifyInstanceModal
		 * @method onClose
		 * @desc closes open dialogs 
		 */
        this.constructor.prototype.onClose = function() {
            this._instance.dueDateTimePicker.close();
        };

         /**
		 * @instance
		 * @memberof ModifyInstanceModal
		 * @method saveModal
		 * @desc Saves the data on the dialog
		 */
        this.constructor.prototype.saveModal = function() {
            bpmext.log.info("ModifyInstanceModal.saveModal ENTER >> ", this);
            if(this._instance.disableDueDateCheckbox.isChecked()){
                this._proto._postDueDateInfo(this);
                this.closeModal();
            }else{
                if(this.checkDueDateTimePicker()){
                    this._proto._postDueDateInfo(this);
                    this.closeModal();
                }
            }
			bpmext.log.info("ModifyInstanceModal.saveModal EXIT << ");
        };

         /**
		 * @instance
		 * @memberof ModifyInstanceModal
		 * @method updateDueDateTimePicker
		 * @desc Controls the visibility of date picker and enables or disables the save button
		 */
        this.constructor.prototype.updateDueDateTimePicker = function() {
            bpmext.log.info("ModifyInstanceModal.updateDueDateTimePicker ENTER >> ", this);
            //Controls the visibility of dueDateTimePicker and enable or disable of save button based on checkbox and date time picker
            if(this._instance.disableDueDateCheckbox.isChecked()){
                this._instance.modalSection.setPrimaryButtonEnabled(true);
                this._instance.dueDateTimePicker.setVisible(false,true);
            }else{
                this._instance.dueDateTimePicker.setVisible(true,true);
                this._instance.modalSection.setPrimaryButtonEnabled(!!this._instance.dueDateTimePicker.getDate());
            }

			bpmext.log.info("ModifyInstanceModal.updateDueDateTimePicker EXIT << ");
        };

        /**
		 * @instance
		 * @memberof ModifyInstanceModal
         * @param {instance} process The process object
		 * @method setupProcess
		 * @desc Set up modal process
		 */
        this.constructor.prototype.setupProcess = function(process) {
            bpmext.log.info("ModifyInstanceModal.setupProcess ENTER >> ", process);

            this._instance.process = process;
            this._proto._setProcessInfo(this);

			bpmext.log.info("ModifyInstanceModal.setupProcess EXIT << ");
        };

        /**
		 * @instance
		 * @memberof ModifyInstanceModal
		 * @method showModal
		 * @desc Display the modal
		 */
        this.constructor.prototype.showModal = function() {
            bpmext.log.info("ModifyInstanceModal.setProcess ENTER >> ", this);

            this._instance.modalSection.show();
            this.show();
            taskUtils.setTabCycle(this);
            bpmext.log.info("ModifyInstanceModal.setProcess EXIT >> ", this);
        };

         /**
		 * @instance
		 * @memberof ModifyInstanceModal
		 * @method checkDueDateTimePicker
         * @returns {Boolean} the boolean value for the validity of the date time picker value
		 * @desc Controls the visibility of date picker and enables or disables the save button
		 */
        this.constructor.prototype.checkDueDateTimePicker = function() {
            bpmext.log.info("ModifyInstanceModal.checkDueDateTimePicker ENTER >> ", this);
            var validDate = false;
            
            //Only enable save button if there is a valid date
            validDate = this._instance.dueDateTimePicker.getDate() && this._instance.dueDateTimePicker.isValid();
            this._instance.modalSection.setPrimaryButtonEnabled(!!validDate);

			bpmext.log.info("ModifyInstanceModal.checkDueDateTimePicker EXIT << ");
            return validDate;
        };

        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function (){
            bpmext.log.info("ModifyInstanceModal.load ENTER >>", this);

            var view = this;
            this._instance.modalSection = bpmext.ui.getContainer("ModalSection", this);
            this._instance.modalSection.setPrimaryButtonText(bpmext.localization.formatMsg("modifyTaskModal", "save"));
            this._instance.modalSection.setSecondaryButtonText(bpmext.localization.formatMsg("modifyTaskModal", "cancel"));
            //CV in ModalSection
            this._instance.panel = bpmext.ui.getContainer("Panel", this);
            //CV in Panel
            this._instance.disableDueDateCheckbox = bpmext.ui.getView("DisableDueDateCheckbox", this);
            this._instance.dueDateTimePicker = bpmext.ui.getView("DueDateTimePicker", this);
            //Assign labels and texts to controls
            this._instance.modalSection._instance.modalDialog.ariaLabel = bpmext.localization.formatMsg("modifyInstanceModal", "modifyInstance");
            this._instance.panel.setTitle(bpmext.localization.formatMsg("modifyInstanceModal", "modifyInstance"));
            this._instance.disableDueDateCheckbox.setLabel(bpmext.localization.formatMsg("modifyInstanceModal", "disableDueDate"));
            this._instance.dueDateTimePicker.setLabel(taskUtils.getLabelFromTaskProperty("taskDueDate"));
            this._instance.dueDateTimePicker.setPlaceholder(bpmext.localization.formatMsg("modifyInstanceModal", "dueDateTimePickerPlaceholder"));

            var panelHeaderIcon = this._instance.panel.context.element.querySelector("div.panel-heading-controls > div.panel-heading-icon > i");
            !!panelHeaderIcon && domAttr.remove(panelHeaderIcon, "tabindex");

            this._instance.dueDateInput = this._instance.dueDateTimePicker.context.element.querySelector("input");
            var validationHandler = function () {
                view.checkDueDateTimePicker();
            };
            //Defect 345431 to prevent save button from active when due date is being modified
            this._instance.dueDateInput.onfocus = validationHandler;
            this._instance.dueDateInput.onblur = validationHandler;

            taskUtils.EVENTS.MODIFY_INSTANCE_CLOSE.subscribe(this.closeModal, this);
			taskUtils.EVENTS.MODIFY_INSTANCE.subscribe(function(eventName, eventData){
                if(eventData.view.ui.getParent() === this.ui.getParent()){
                    // Get process stats
                    this._instance.task = eventData.task;
                    this._instance.process = eventData.process;
                    this._proto._loadModal(this);
                    // Show modify instance modal
                    this._instance.modalSection.show();
                    this.show();
                    taskUtils.setTabCycle(this);
                }
			}, this);

            this.loadContainer(this);

            bpmext.log.info("ModifyInstanceModal.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try {
                utilities.handleVisibility(this.context);
            }
            catch (e){
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e, this);
                if(e.stack) {
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack), this);
                }
            }
        };

        this.constructor.prototype.change = function (event){
            bpmext.log.info("ModifyInstanceModal.change ENTER >> (event): " + event, this);
            bpmext.log.info("ModifyInstanceModal.change ENTER >>", this);
        };

        this.constructor.prototype.unload = function (){
            bpmext.log.info("ModifyInstanceModal.unload ENTER >> ", this);
            bpmext.ui.unloadContainer(this);
            bpmext.log.info("ModifyInstanceModal.unload ENTER >>", this);
        };
    }
};