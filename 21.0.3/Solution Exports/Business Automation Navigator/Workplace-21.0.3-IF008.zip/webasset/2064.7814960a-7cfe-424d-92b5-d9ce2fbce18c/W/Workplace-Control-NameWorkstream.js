/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof NameWorkstream
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof NameWorkstream
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof NameWorkstream
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof NameWorkstream
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof NameWorkstream
 * @method setData
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On Process Launched:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when a process is launched</td>
 *               </tr>
 *           </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">item {object}</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">process data</td>
 *               </tr>
 *       </table>
 *     </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On Service Launched:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when a service is launched</td>
 *               </tr>
 * </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">item {object}</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">service data</td>
 *               </tr>
 *           </table>
 *       </td>
 *   </tr>
 * </table>
 */
workplace_control_InitNameWorkstream = function (utilities, taskUtils, wpResources) {
	"use strict";
	this._instance = {
		isNameValid: false
	};

	if (!this.constructor.prototype._proto) {
		this.constructor.prototype._proto = {
			_translate: function _translate() {
				var args = [].slice.call(arguments);
                args.unshift("NameWorkstream");
                return bpmext.localization.formatMsg.apply(null, args);
			},
			/**
			 * @param {Object} params
			 * @return {String}
			 */
			_paramsToString: function _paramsToString(params) {
				var str = "";
				for (var key in params) {
					if (params[key]) {
						str += "&" + key + "=" + encodeURIComponent(params[key]);
					}
				}
				return str;
			},

			/**
			 * @param {string} name
			 * @return {string} - the error message or "" if there is no error
			 */
			_getInvalidNameError: function _getInvalidNameError(view, name) {
				if (!name) {
					return view._proto._translate("nameMissing");
				}
				if (name.length > 64) {
					return view._proto._translate("nameTooLong");
				}
				if (/([\\]|[/]|["]|[']|[`])/.test(name)) {
					return view._proto._translate("invalidCharacter");
				}
				return "";
			},

			/**
			 * @param {View} view
			 */
			_setPrimaryButton: function _setPrimaryButton(view) {
				var isFormValid = view._instance.isNameValid;
				taskUtils.EVENTS.SLIDEOUT_SET_PRIMARY_BTN.publish({enable: isFormValid});
			},

			/**
			 * @param {View} view
			 * @param {object} data
			 * @param {string} data.selectedWorkstream.name
			 * @param {string} data.caller
			 * @desc If a recent or favorite workstream, populate the name, otherwise, clear it.
			 */
			_loadNameAndDescription: function _loadNameAndDescription(view, data) {
				var name = "";
				var description = "";
				if (data.caller === "RECENT_WORKSTREAM" || data.caller === "WORKFLOW_FAVORITES") {
					name = data.selectedWorkstream.name || data.selectedWorkstream.PI_NAME;
					if (data.selectedWorkstream.itemDescription || data.selectedWorkstream.Workstream_Description) {
						description = data.selectedWorkstream.itemDescription || data.selectedWorkstream.Workstream_Description || "";
					}
				}
				else if (data.caller === "STEP_1" && view._instance.caller === "STEP_1") {
					name = view._instance.workstreamName.getText();
					description = view._instance.workstreamDescription.getText();
				}
				view._instance.workstreamName.setText(name);
				view._instance.workstreamDescription.setText(description);
				view._instance.caller = data.caller;
			}
		};

		/*
		Public control methods *************************************************************
		 */

		this.constructor.prototype.setSecondaryBtnText = function setSecondaryBtnText() {
			switch(this._instance.caller) {
				case "STEP_1":
					return bpmext.localization.formatMsg("workplace", "back");
				case "RECENT_WORKSTREAM":
					return bpmext.localization.formatMsg("workplace", "back");
				default:
					return bpmext.localization.formatMsg("workplace", "back");
			}
		},
		/**
		 * @instance
		 * @memberof NameWorkstream
		 * @method launchWorkstreamConfigurator
		 * @desc Launches the Workstream Configurator
		 */
		this.constructor.prototype.launchWorkstreamConfigurator = function launchWorkstreamConfigurator() {
			var view = this;
			bpmext.log.info("NameWorkstream.refresh ENTER>>", this);
			var params = {
				"tw.local.name": this._instance.workstreamName.getData(),
				"tw.local.description": this._instance.workstreamDescription.getData() || ""
			};
			if(this._instance.workstream) {
				params["tw.local.piid"] = this._instance.workstream.piid || this._instance.workstream.PI_PIID;
			} else {
				params["tw.local.type"] = this._instance.type;
			}

			var options = {
				subtypes: ["url"],
				filterByName: [taskUtils.CONFIGURATION_WIZARD]
			};
			wpResources.exposed.get(options).then(function (exposedData) {
				var exposedItems = exposedData.items || exposedData;
				for (var i = 0; i < exposedItems.length; i++) {
					var item = exposedItems[i];
					if (item.itemID === taskUtils.CONFIGURATION_WIZARD_CSHS_ID) {
						// create a clone of the item to not modify the underlying object
						item = JSON.parse(JSON.stringify(item));
						item.runURL = (item.runURL || item.startURL) + view._proto._paramsToString(params);
						item.startURL = item.runURL;
						item.display = view._instance.workstreamName.getText();
						taskUtils.EVENTS.SERVICE_LAUNCHED.publish({ service: item });
						view._instance.workstreamName.setText("");
						view._instance.workstreamDescription.setText("");
						break;
					}
				}
				bpmext.log.info("NameWorkstream.refresh EXIT>>", this);
			});
		};

		/**
         * @instance
         * @memberof NameWorkstream
         * @method validateName
		 * @param {string} name
         * @desc Closes the dialog
         */
		this.constructor.prototype.validateName = function validateName(name) {
			bpmext.log.info("NameWorkstream.validateName ENTER >>", this);
			if (name === null || name === "undefined") {
				name = this._instance.workstreamName.getText();
			}
			var errorMessage = this._proto._getInvalidNameError(this, name);
			var isNameValid = errorMessage === "";
			this._instance.isNameValid = isNameValid;
			this._instance.workstreamName.setValid(isNameValid, errorMessage);
			this._proto._setPrimaryButton(this);
			bpmext.log.info("NameWorkstream.validateName EXIT >>", this);
		};

		/**
         * @instance
         * @memberof NameWorkstream
         * @method onShow
         * @desc Sets the secondary button text
         */
        this.constructor.prototype.onShow = function onShow() {
			taskUtils.EVENTS.SLIDEOUT_SET_SECONDARY_BTN.publish({text: this.setSecondaryBtnText()});
		};

		/**
         * @instance
         * @memberof NameWorkstream
         * @method goBack
         * @desc Goes to the previous Config panel page
         */
        this.constructor.prototype.goBack = function goBack() {
			switch(this._instance.caller) {
				case "STEP_1":
					taskUtils.EVENTS.OPEN_CONFIG.publish();
					break;
				case "ACTIVITIES":
					taskUtils.EVENTS.OPEN_ACTIVITIES.publish();
					break;
				case "RECENT_WORKSTREAM":
					taskUtils.EVENTS.OPEN_RECENT.publish();
					break;
				case "WORKFLOW_FAVORITES":
					taskUtils.EVENTS.OPEN_FAVORITES.publish();
					break;
				default:
					taskUtils.EVENTS.OPEN_CONFIG.publish();
					break;
			}
        };

		/*
		Coach NG Lifecycle methods *************************************************************
		 */
		this.constructor.prototype.load = function () {
			var view = this;
			bpmext.log.info("NameWorkstream.load ENTER >>", this);

			this._instance.instructions = bpmext.ui.getView("Instructions", this);
			this._instance.instructions.setVisible(false, true);
			this._instance.workstreamName = bpmext.ui.getView("WorkstreamName", this);
			this._instance.workstreamName.setLabel(this._proto._translate("workstreamName"));
			this._instance.workstreamName.setPlaceholder(this._proto._translate("namePlaceholder"));
			this._instance.workstreamDescription = bpmext.ui.getView("WorkstreamDescription", this);
			this._instance.workstreamDescription.setLabel(this._proto._translate("workstreamDescription"));
			this._instance.workstreamDescription.setPlaceholder(this._proto._translate("descriptionPlaceholder"));
			taskUtils.EVENTS.OPEN_NAME_WORKSTREAM.subscribe(function(eventName, data) {
				var selectedWorkstream = data.selectedWorkstream;
				this._instance.allExposedResource = data.allExposedResource;
				this._proto._loadNameAndDescription(this, data);
				if (!selectedWorkstream) {
					var message = "Event: " + eventName + ", NameWorkstream slideout wasn't provided with an activity type.";
					bpmext.log.error(message);
					return;
				}
				else if (typeof selectedWorkstream === "string") {
					this._instance.type = selectedWorkstream;
					this._instance.workstream = null;
				}
				else if (typeof selectedWorkstream === "object") {
					this._instance.type = null;
					this._instance.workstream = selectedWorkstream;
				}
				this._proto._setPrimaryButton(this);
				this._instance.workstreamName.setValid(true);
				this._instance.workstreamDescription.setValid(true);
				var view = this;
				// Accessibility
				setTimeout(function() {
					view._instance.workstreamName.context.element.querySelector("input").focus();
					taskUtils.setTabCycle(view); 
				});
            }, this);
			taskUtils.EVENTS.NAME_WORKSTREAM_LOADED.publish();

			bpmext.log.info("NameWorkstream.load EXIT >>", this);
		};

		this.constructor.prototype.view = function () {
			try {
				utilities.handleVisibility(this.context);
			} catch (e) {
				//{#feature: US-1330 Added RT localization}
				//bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
				bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
				if (e.stack) {
					//{#feature: US-1330 Added RT localization}
					//bpmext.log.error("  Call stack: " + e.stack);
					bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
				}
			}
		};

		this.constructor.prototype.change = function (event) {
			bpmext.log.info("NameWorkstream.change ENTER >> (event): " + event, this);
			if (event.type === "config") {
				switch (event.property) {
					case "_metadata.visibility": {
						this.view();
						break;
					}
				}
			}
			bpmext.log.info("NameWorkstream.change EXIT >>", this);
		};

		this.constructor.prototype.unload = function () {
			bpmext.ui.unloadView(this);
		};

		this._instance.MODAL_OPTIONS = {
            title: this._proto._translate("title"),
            subtitle: this._proto._translate("instructions"),
            primaryBtnText: bpmext.localization.formatMsg("workplace", "next"),
            primaryBtnEvent: {method: dojo.hitch(this, this.launchWorkstreamConfigurator), args: null, closeOnEvtComplete: true},
			secondaryBtnText: bpmext.localization.formatMsg("workplace", "back"),
            secondaryBtnEvent: {method: dojo.hitch(this, this.goBack), args: null, closeOnEvtComplete: false},
            progressBarOptions:{},
			onPanelClose: {},//"Not used"
			onPanelShow: {method: dojo.hitch(this, this.onShow), args: null},
			width: window.innerWidth>700? ((700/window.innerWidth) *100 + "%") : "100%",
			viewFrom: "NameWorkstream"
        };
	}
};