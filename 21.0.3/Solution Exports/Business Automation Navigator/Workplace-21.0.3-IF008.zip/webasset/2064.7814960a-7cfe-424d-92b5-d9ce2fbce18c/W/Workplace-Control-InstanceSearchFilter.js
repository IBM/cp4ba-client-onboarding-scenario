/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof InstanceSearchFilter
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof InstanceSearchFilter
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof InstanceSearchFilter
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof InstanceSearchFilter
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof InstanceSearchFilter
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof InstanceSearchFilter
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof InstanceSearchFilter
 * @method triggerFormulaUpdates
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 * </table>
 */
workplace_control_InitInstanceSearchFilter = function (utilities, taskUtils, wpResources)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            _getInteractionFromFilter: function _getInteractionIndexFromFilter(filter){
                bpmext.log.info("InstanceSearchFilter._getInteractionFromFilter LOG >>");
                for(var x=0;x<filter.length;x++){
                    if(filter[x].field==="interaction"){
                        return x;
                    }
                }
            }

        };


        /*
        Public control methods *************************************************************
         */

        /**
         * @instance
         * @memberof InstanceSearchFilter
         * @method initializeColumnSelector
         * @desc Calls the services to retrieve the current system and business data and populates the columns selector with the result
         */
        this.constructor.prototype.initializeColumnSelector = function initializeColumnSelector() {
            bpmext.log.info("InstanceSearchFilter.initializeColumnSelector ENTER: >>");
            var view = this;
            this._instance.mandatoryColumns = taskUtils.DEFAULT_MANDATORY_COLUMNS;
            this._instance.selectedCols = [];
            taskUtils.DEFAULT_SELECTED_COLUMNS.forEach(function(val) {
                view._instance.selectedCols.push({name: val, value: taskUtils.getLabelFromTaskProperty(val)});
            });
            wpResources.searches.getMetaFields()
            .then(function(systemData) {
                wpResources.searches.getMetaBusinessDataFields()
                    .then(function(businessData) {
                        var isPXServer = view.context.isWorkflowPXServer && view.context.isWorkflowPXServer() === true;
                        view._instance.systemData = taskUtils.processColumns(systemData, taskUtils.getFieldsToHide(isPXServer, true), true);
                        view._instance.businessData = taskUtils.processBusinessDataColumns(businessData);
                        view._instance.columnSelector.setColumns(view._instance.systemData, view._instance.businessData, view._instance.mandatoryColumns, view._instance.selectedCols);
                        view._instance.columnSelector.context.binding.set("value", view._instance.selectedCols);
                        view._instance.columnSelector.changeSelectedColumns(false, false);
                    });
                }
            );
        };

        /**
         * @instance
         * @memberof InstanceSearchFilter
         * @method showPanel
         * @desc list the available workstreams
         */
		this.constructor.prototype.showPanel = function showPanel() {
			bpmext.log.info("InstanceSearchFilter.showPanel ENTER >>", this);
            if(wpResources.isFederated){
                this._instance.searchFilter.setVisible(false, true);
                this._instance.clearButton.setVisible(false, true);
                this._instance.savedSearch.show();
            }else{
                this._instance.searchFilter.show();
                this._instance.clearButton.show();
                this._instance.savedSearch.setVisible(false, true);
            }

		};
        /**
         * @instance
         * @memberof InstanceSearchFilter
         * @method clearAllFields
         * @desc Clears all fields in the dialog
         */
        this.constructor.prototype.clearAllFields = function clearAllFields() {
            bpmext.log.info("InstanceSearchFilter.clearAllFields ENTER: >>");
            //Clear search filter
            this._instance.searchFilter.resetFilter(this._instance.searchFilter);
            //Set column selector to initialized fields
//            this.initializeColumnSelector();
        };

        /**
         * @instance
         * @memberof InstanceSearchFilter
         * @method clearButtonHandler
         * @desc Handler for clear button
         */
        this.constructor.prototype.clearButtonHandler = function clearButtonHandler() {
            bpmext.log.info("InstanceSearchFilter.clearButtonHandler ENTER: >>");
            this.clearAllFields();
        };

        /**
         * @instance
         * @memberof SavedSearchBuilder
         * @method closeInstanceFilter
         * @desc Closes the dialog
         */
        this.constructor.prototype.closeInstanceFilter = function closeInstanceFilter() {
            bpmext.log.info("SavedSearchBuilder.closeSavedSearch ENTER: >>");
            if(wpResources.isFederated){
                this._instance.savedSearch.closeSavedSearch();
            }else{
                this._instance.searchFilter.cleanUp();
                if(this._instance.searchFilter.getCurrentFilter()){
                    var sfModified = this._instance.searchFilter.compareFilterConditions([{name: "interaction", value: wpResources.processes.INTERACTION.ACTIVE, operator: "Equals"}], this._instance.searchFilter.getCurrentFilter(true));
                    if(!sfModified){
                        taskUtils.EVENTS.SET_INSTANCE_BADGE.publish();
                    }
                }
            }
        };

        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function ()
        {
            bpmext.log.info("InstanceSearchFilter.load ENTER >>", this);

            var view = this;
            //Filter
            this._instance.searchFilter = bpmext.ui.getContainer("SearchFilter", this);

            this._instance.clearButton = bpmext.ui.getView("clearButton", this);
    
            this._instance.savedSearch = bpmext.ui.getView("SavedSearch_Builder1", this);

            taskUtils.EVENTS.OPEN_SEARCH_FILTER.subscribe(function(){
                taskUtils.EVENTS.LOAD_STACK_PANE.publish({targetView:view.context.viewid});
                // Accessibility
                setTimeout(function() {
                    taskUtils.setTabCycle(view);
                }, 100);
            }, this);
            taskUtils.EVENTS.SET_DEFAULT_INSTANCE_STATS.subscribe(function () {
                if(wpResources.isFederated){
                    // Clear selected columns
                    view._instance.savedSearch.initializeColumnSelector(true);
                    view._instance.savedSearch.clearAllFields(false);
                }else{
                    view.clearAllFields();
                }
            }, this);

            if(wpResources.isFederated){
                this._instance.searchFilter.setVisible(false, true);
                this._instance.clearButton.setVisible(false, true);
                this._instance.savedSearch.show();
                taskUtils.EVENTS.CLEAR_INSTANCE_FIELDS.subscribe(function () {
                    view._instance.savedSearch.clearAllFields(false);
                }, this);
            }else{
                this._instance.searchFilter.show();
                this._instance.clearButton.show();
                this._instance.savedSearch._instance.searchFilter.setVisible(false, true);
                this._instance.savedSearch.setVisible(false, true);
            }

            this.loadContainer(this);

            

            bpmext.log.info("InstanceSearchFilter.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try
            {
                utilities.handleVisibility(this.context);
            }
            catch (e)
            {
                //{#feature: US-1330 Added RT localization}
                //bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e, this);
                if(e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    //bpmext.log.error("  Call stack: " + e.stack);
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack), this);
                }
            }
        };

        this.constructor.prototype.change = function (event)
        {
            bpmext.log.info("InstanceSearchFilter.change ENTER >> (event): " + event, this);
            bpmext.log.info("InstanceSearchFilter.change ENTER >>", this);
        };

        this.constructor.prototype.unload = function ()
        {
            bpmext.ui.unloadContainer(this);
        };

        this._instance.MODAL_OPTIONS = {
            title: wpResources.isFederated? bpmext.localization.formatMsg("instanceList", "pfsSearchFilterTitle") : bpmext.localization.formatMsg("instanceList", "searchFilterTitle"),
            subtitle: wpResources.isFederated? bpmext.localization.formatMsg("instanceList", "pfsSearchFilterSubtitle") : bpmext.localization.formatMsg("instanceList", "searchFilterSubtitle"),
            secondaryBtnText: bpmext.localization.formatMsg("savedSearchBuilder", "hide"),
            secondaryBtnEvent: {method: null, args: {}, closeOnEvtComplete: true},
            onPanelShow: {method: dojo.hitch(this, this.showPanel), args: false, closeOnEvtComplete: false},
            onPanelClose: {method: dojo.hitch(this, this.closeInstanceFilter), closeOnEvtComplete: false},
            progressBarOptions:{},
            viewFrom: "InstanceFilter"
        };
    }
};