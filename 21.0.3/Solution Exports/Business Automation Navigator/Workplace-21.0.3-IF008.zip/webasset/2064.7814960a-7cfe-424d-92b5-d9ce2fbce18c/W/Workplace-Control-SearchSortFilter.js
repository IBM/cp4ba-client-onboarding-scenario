/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof SearchSortFilter
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof SearchSortFilter
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof SearchSortFilter
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof SearchSortFilter
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof SearchSortFilter
 * @method setData
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On Change:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when the task filter is changed.</td>
 *               </tr>
 *           </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *               </tr>
 *       </table>
 *     </td>
 *   </tr>
 * </table>
 */
 workplace_control_InitSearchSortFilter = function (utilities, taskUtils, resourceUtils, wpResources, domAttr, domClass, domStyle)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto = {
            //Event constants
            EVT_ONCHANGE: "eventON_CHANGE",

            _loadDropdown: function (view, noDisplay) {
                bpmext.log.info("SearchSortFilter._loadDropdown ENTER >>");
                view._instance.mandatoryColumns = view.context.options.instanceMode.get("value") ? taskUtils.DEFAULT_MANDATORY_INSTANCE_COLUMNS : taskUtils.DEFAULT_MANDATORY_COLUMNS;
                var columns = view.context.options.instanceMode.get("value") ? taskUtils.DEFAULT_FEDERATED_INSTANCE_COLUMNS : taskUtils.DEFAULT_SELECTED_COLUMNS;
                
                if (!view._instance.initialized) {
                    view._instance.menuItems = [];
                    var x, offset = 0;
                    for (x = 0; x < columns.length; x++) {
                        var column = columns[x];
                        if(column) {
                            var desc;
                            var value =  view.context.options.instanceMode.get("value") ? taskUtils.getLabelFromInstanceProperty(column) : taskUtils.getLabelFromTaskProperty(column);
                            if(view.context.options.instanceMode.get("value")){
                                if(taskUtils.getInstanceSystemDataDescription(column)){
                                    desc = taskUtils.getInstanceSystemDataDescription(column);
                                }else{
                                    desc = value;
                                }
                            }else{
                                if(taskUtils.getTaskSystemDataDescription(column)){
                                    desc = taskUtils.getTaskSystemDataDescription(column);
                                }else{
                                    desc = value;
                                }
                            }
                            if(column !== "taskStatus") {
                                view._instance.menuItems.push({
                                    command: {index:x+offset+"", display: column},
                                    itemType: "L",
                                    itemText: value,
                                    badgeShape: "R",
                                    badgeText: view._proto._createOriginDescriptionDom(desc).innerHTML
                                }); 
                            }else{
                                offset -= 1;
                            }

                            if (column === "taskDueDate"){
                                view._instance.searchBarInput.value = bpmext.localization.formatMsg("controlTaskList", "taskDueDate");
                            }
                        }
                    }
                    view._instance.valueDropDownMenu.appendItem("ascending", bpmext.localization.formatMsg("controlTaskList", "asc"));
                    view._instance.valueDropDownMenu.appendItem("descending", bpmext.localization.formatMsg("controlTaskList", "desc"));
                    view._instance.valueDropDownMenu.setSelectedItem("ascending");
                    view._instance.initialized = true;
                    if (!noDisplay) {
                        view._proto._showDropdown(view);
                    }
                } else {
                    view._proto._showDropdown(view);
                }

                bpmext.log.info("SearchSortFilter._loadDropdown EXIT >>", view);
            },
            _updateDropdown: function (view, columns) {
                bpmext.log.info("SearchSortFilter._updateDropdown ENTER >>");
                view._instance.dropDownMenu.removeAllMenuItems();
                view._instance.menuItems = [];
                var offset = 0
                for (var x = 0; x < columns.length; x++) {
                    var column = columns[x];
                    if(column && column.name !== "taskStatus") {
                        view._instance.menuItems.push({
                            command: {index:x+offset+"", display: column.name},
                            itemType: "L",
                            itemText: column.value,
                            badgeShape: "R",
                            badgeText: view._proto._createOriginDescriptionDom(column.desc).innerHTML
                        });
                    }else{
                        offset -= 1;
                    }
                }

                bpmext.log.info("SearchSortFilter._updateDropdown EXIT >>", view);
            },
            _showDropdown: function (view) {
                bpmext.log.info("SearchSortFilter._showDropdown ENTER >>");
                view._instance.dropDownMenu.setMenuItems(view._instance.menuItems);
                view._instance.dropDownMenu.setMenuVisible(true);
                domClass.add(view._instance.searchLayout.context.element, "expandedSearch");
                view._proto._setWidth(view);
                setTimeout(function() { view._instance.searchBar._instance.text.focus(); }, 50);
                bpmext.log.info("SearchSortFilter._showDropdown EXIT >>", view);
            },
            _createOriginDescriptionDom: function (description){
                var infoDom = document.createElement("div");
                var infoDomWrapper = document.createElement("span");
                domClass.add(infoDomWrapper, "menuitem-tooltip-icon");

                var tooltipWrapper = document.createElement("div");
                domClass.add(tooltipWrapper, "menuitem-tooltip");
                var tooltipCaret = document.createElement("div");
                domClass.add(tooltipCaret, "menuitem-tooltip-caret");
                var tooltipContent = document.createElement("div");

                var id = "menuitem-tooltip-content-" + bpmext.ui.makeUniqueId("");
                tooltipContent.id = id;
                var ciIcon = utilities.getCarbonIcon("ci-information");
                ciIcon.tabIndex = 0;
                domAttr.set(ciIcon, "aria-describedby", tooltipContent.id);
                ciIcon.ariaLabel = bpmext.localization.formatMsg("savedSearchBuilder", "information");
                infoDomWrapper.appendChild(ciIcon);

                domClass.add(tooltipContent, "menuitem-tooltip-content");
                var tooltipText = document.createTextNode(description);
                tooltipContent.appendChild(tooltipText);
                tooltipWrapper.appendChild(tooltipCaret);
                tooltipWrapper.appendChild(tooltipContent);
                infoDomWrapper.appendChild(tooltipWrapper);

                infoDom.appendChild(infoDomWrapper);

                return infoDom
            },
            _setWidth: function (view, keepVisible) {
                bpmext.log.info("SearchSortFilter._setWidth ENTER >>");
                var parentDiv, windowBottom, menuBottom, menuRect, top, menuDom, inputDomRect;

                var searchBarDom = view._instance.searchLayout.context.element.querySelector(".ContentBox");
                var dropDownDom = view._instance.dropDownMenu._getMenuDom();
                if (searchBarDom.offsetWidth > dropDownDom.offsetWidth) {
                    domStyle.set(dropDownDom, "width", searchBarDom.offsetWidth + "px");
                } else {
                    domStyle.set(searchBarDom, "width", dropDownDom.offsetWidth + "px");
                }
                if (!keepVisible) {
                    view._instance.dropDownMenu.setMenuVisible(false);
                    view._instance.dropDownMenu.setTargetElement(view._instance.searchLayout.context.element);
                    view._instance.dropDownMenu.setMenuVisible(true);
                }
                //close the menu if the parent is scrolled
                parentDiv = view.ui.getAncestor("Stack", true);
                if (parentDiv) {
                    parentDiv = parentDiv.context.element;
                    parentDiv.onscroll = function() {
                        view._instance.dropDownMenu.setMenuVisible(false);
                    };
                }

                //set the height and scroll bar of the menu if it is outside of the viewport
                windowBottom = window.scrollY + window.innerHeight;
                menuDom = view._instance.dropDownMenu._getMenuDom();
                inputDomRect = view._instance.searchBarInput.getBoundingClientRect();
                menuRect = menuDom.getBoundingClientRect();
                top = inputDomRect.top + inputDomRect.height;
                menuBottom = top + menuRect.height;
                if (menuBottom > windowBottom) {
                    menuDom.parentElement.style.height = (windowBottom - top - 10) + "px";
                    menuDom.parentElement.style.overflowY = "scroll";
                } else {
                    menuDom.parentElement.style.height = "";
                    menuDom.parentElement.style.overflowY = "";
                }

                bpmext.log.info("SearchSortFilter._setWidth EXIT >>", view);
            },
            _filterItems: function (view) {
                bpmext.log.info("SearchSortFilter._filterItems ENTER >>");
                var filteredResults=[];
                var hasBusinessData, businessDataIndex, hasSystemData, systemDataIndex = 0;
                view._instance.dropDownMenu.setMenuVisible(true);
                
                if (view._instance.filterCondition) {
                    view._instance.menuItems.forEach(function(item) {
                        if (item.itemType === "H") {
                            filteredResults.push(item);
                            if (filteredResults.length !== 1) {
                                //businessdata header
                                businessDataIndex = filteredResults.length -1;
                            }
                        } else if (item.itemText.toLowerCase().indexOf(view._instance.filterCondition.toLowerCase()) !== -1) {
                            filteredResults.push(item);
                            if (!businessDataIndex) {
                                hasSystemData = true;
                            } else {
                                hasBusinessData = true;
                            }
                        }
                    });
                    if (!hasBusinessData) {
                        filteredResults.splice(businessDataIndex, 1);
                    }
                    if (!hasSystemData) {
                        filteredResults.splice(systemDataIndex, 1);
                    }
                }
                else {
                    filteredResults = view._instance.menuItems;
                }

                if (filteredResults.length === 0) {
                    filteredResults.push({
                        itemType: "H",
                        itemText: "<div><span>" +  bpmext.localization.formatMsg("workplace", "noMatch") + "</span></div>"
                    });
                }

                view._instance.dropDownMenu.setMenuItems(filteredResults);
                view._proto._setWidth(view, true);
                bpmext.log.info("SearchSortFilter._filterItems EXIT >>", view);
            },

            _focusDropdown: function (view) {
                if (view._instance.dropDownMenu.isMenuVisible()) {
                    var dropDownElements = taskUtils.getFocusElementList(view._instance.dropDownMenu._instance.menuTbl, true);
                    view._instance.focusIndex = 0;
                    dropDownElements[view._instance.focusIndex].focus();
                }
            }
        };

        /*
        Public control methods *************************************************************
        */
        /**
         * @instance
         * @memberof SearchSortFilter
         * @method openDropdown
         * @desc Opens the dropdown section
         */
        this.constructor.prototype.openDropdown = function openDropdown() {
            var view = this;
            bpmext.log.info("SearchSortFilter.openDropdown ENTER >>", this);
            this._proto._loadDropdown(this);
            if (!this._instance.dropDownMenu.isVisible()) {
                this._instance.dropDownMenu.setMenuVisible(true);
            }

            this._instance.searchBarInput = this._instance.searchBar.context.element.querySelector("input");
            this._instance.dropDownBlur = function(event) {
                if (!view._instance.searchBarInput.contains(event.relatedTarget)
                    && !view._instance.dropDownMenu._instance.menuTbl.contains(event.relatedTarget) ) {
                    view.hideDropdown();
                }
            };

            this._instance.dropDownMenu._instance.wrapper.addEventListener("blur", this._instance.dropDownBlur, true);
            
            bpmext.log.info("SearchSortFilter.openDropdown EXIT >>", this);
        };
        /**
         * @instance
         * @memberof SearchSortFilter
         * @method hideDropdown
         * @desc Closes the dropdown section
         */
         this.constructor.prototype.hideDropdown = function hideDropdown() {
            bpmext.log.info("SearchSortFilter.hideDropdown ENTER >>", this);
            if (this._instance.initialized) {
                this._instance.dropDownMenu.setMenuVisible(false);
                this._instance.dropDownMenu._instance.wrapper.removeEventListener("blur", this._instance.dropDownBlur, true);
            }
            bpmext.log.info("SearchSortFilter.hideDropdown EXIT >>", this);
        };
        /**
         * @instance
         * @memberof SearchSortFilter
         * @method filterDropdown
         * @desc Filter the dropdown section
         */
         this.constructor.prototype.filterDropdown = function filterDropdown() {
            bpmext.log.info("SearchSortFilter.filterDropdown ENTER >>", this);
            this.openDropdown();
            this._instance.filterCondition = this._instance.searchBar.context.element.querySelector("input").value;
            this._proto._filterItems(this);
            bpmext.log.info("SearchSortFilter.filterDropdown EXIT >>", this);
        };
        /**
         * @instance
         * @memberof SearchSortFilter
         * @method compareFilterConditions
         * @desc Compare filters
         */
         this.constructor.prototype.compareFilterConditions = function compareFilterConditions(filter1, filter2) {
            if(filter1.field === filter2.field){
                if(filter1.order === filter2.order){
                    return false;
                }else{
                    return true;
                }
            }else{
                return true;
            }
    };
        /**
         * @instance
         * @memberof SearchSortFilter
         * @method getCurrentSort
         * @desc Return current sort
         */
         this.constructor.prototype.getCurrentSort = function getCurrentSort() {
            bpmext.log.info("SearchSortFilter.getCurrentSort ENTER >>", this);
            var sort = { 
                field: this._instance.searchBarInput.value,
                order: this._instance.valueDropDownMenu.getSelectedItem()};
            bpmext.log.info("SearchSortFilter.getCurrentSort EXIT >>", this);
            return sort;
        };
        /**
         * @instance
         * @memberof SearchSortFilter
         * @method setSort
         * @desc Set sort
         */
         this.constructor.prototype.setSort = function setSort(field, order) {
            bpmext.log.info("SearchSortFilter.setSort ENTER >>", this);
            this._instance.searchBarInput.value = this.context.options.instanceMode.get("value") ? taskUtils.getLabelFromInstanceProperty(field) : taskUtils.getLabelFromTaskProperty(field);
            if (order === "DESC"){
                order = "descending";
            }else{
                order = "ascending";
            }
            this._instance.valueDropDownMenu.setSelectedItem(order);
            bpmext.log.info("SearchSortFilter.setSort EXIT >>", this);
        };
        /**
         * @instance
         * @memberof SearchSortFilter
         * @method launchItem
         * @param {String} action The item command
         * @desc Launches the item selected
         */
         this.constructor.prototype.launchItem = function launchItem(action) {
            bpmext.log.info("SearchSortFilter.launchItem ENTER >>", this);
            if (action != null){
                this._instance.searchBarInput.value = this._instance.menuItems[action.index].itemText;
                this._instance.currentItem = action;
            }else{
                for (var i = 0; i < this._instance.menuItems.length; i++){
                    if(this._instance.menuItems[i].itemText === this._instance.searchBarInput.value){
                        action = this._instance.menuItems[i].command;
                        break;
                    }
                }
            }
            if(action){
                if (action.display !== "taskDueDate" || this._instance.valueDropDownMenu.getSelectedItem() !== "ascending"){
                    taskUtils.EVENTS.SET_TASK_BADGE.publish({text:bpmext.localization.formatMsg("SearchBar", "filterApplied"),clearSS:false});
                }
                this._instance.searchBarInput.focus();
                this.hideDropdown();
                taskUtils.EVENTS.SORT_TASKLIST.publish({field: action.display, order: this._instance.valueDropDownMenu.getSelectedItem()});
            }
            bpmext.log.info("SearchSortFilter.launchItem EXIT >>", this);
        };
        /**
         * @instance
         * @memberof SearchSortFilter
         * @method clearSort
         * @desc Return to default state of the search
         */
         this.constructor.prototype.clearSort = function clearSort() {
            bpmext.log.info("SearchSortFilter.clearSort ENTER >>", this);
            this._instance.searchBarInput.value = bpmext.localization.formatMsg("controlTaskList", "taskDueDate");
            this._instance.valueDropDownMenu.setSelectedItem("ascending");
            bpmext.log.info("SearchSortFilter.clearSort EXIT >>", this);
        };
        /*
        Coach NG Lifecycle methods *************************************************************
        */
        this.constructor.prototype.load = function ()
        {
            bpmext.log.info("SearchSortFilter.load ENTER >>", this);
            var view = this, opts = this.context.options;

            if (!opts.instanceFilter) {
                bpmext.ui.substituteConfigOption(this, "instanceFilter", false);
            }

            if (!opts.taskFilters) {
                bpmext.ui.substituteConfigOption(this, "taskFilters", null);
            }

            if (!opts.instanceFilters) {
                bpmext.ui.substituteConfigOption(this, "instanceFilters", null);
            }

            if (!opts.scopeFilter) {
                bpmext.ui.substituteConfigOption(this, "scopeFilter", false);
            }
            if(!opts.instanceMode) {
                bpmext.ui.substituteConfigOption(this, "instanceMode", false);
            }
            this._instance.scopeFilter = opts.scopeFilter.get("value");

            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONCHANGE);
            this._instance.instanceFilter = opts.instanceFilter.get("value");
            this._instance.filterView = bpmext.ui.getContainer("SortFilter", this);
            this._instance.filterView.context.binding = bpmext.ui.substituteObject(this._instance.filterView);
            this._instance.searchLayout = bpmext.ui.getContainer("searchLayout", this);
            this._instance.dropDownMenu = bpmext.ui.getContainer("dropDownMenu", this);
            this._instance.dropDownMenu.context.options.customFocus.set("value", true);
            this._instance.searchBar = bpmext.ui.getView("searchBar", this);
            this._instance.columnSelectorToggle = bpmext.ui.getView("ColumnSelectorToggle", this);
            this._instance.valueDropDownMenu = bpmext.ui.getView("sortDropdown", this);

            this._instance.searchBar.setPlaceholder(bpmext.localization.formatMsg("searchFilter", "selectValue"));
            this._instance.searchBarInput = this._instance.searchBar.context.element.querySelector("input");
            domAttr.set(this._instance.searchBarInput, "aira-haspopup", "true");
            domAttr.set(this._instance.searchBarInput, "autocomplete", "off");
            this._instance.searchBarInput.onkeydown = function(event) {
                if (event.key === "ArrowDown") {
                    view.openDropdown();
                    setTimeout(function () {
                        view._proto._focusDropdown(view);
                    }, 150);
                } else if (event.key === "Escape" || event.key === "Esc") {
                    event.preventDefault();
                    event.stopPropagation();
                    view.hideDropdown();
                } else if (event.key === "Enter") {
                    view.openDropdown();
                }
            };

            this._instance.searchBarInput.onclick = function() {
                setTimeout(function() { view.openDropdown(); }, 50);
            };

            this._instance.searchBarInput.onblur = function(event) {
                if (!view._instance.dropDownMenu._instance.menuTbl.contains(event.relatedTarget)) {
                    view.hideDropdown();
                }
            };

            this._instance.focusIndex = 0;
            this._instance.dropDownMenu._instance.wrapper.onkeydown = function(event) {
                var dropDownElements = taskUtils.getFocusElementList(view._instance.dropDownMenu._instance.menuTbl, true);
                if(event.key === "ArrowUp" || event.key === "Up"){
                    if (dropDownElements[view._instance.focusIndex] === dropDownElements[0]) {
                        view._instance.focusIndex = dropDownElements.length - 1;
                        dropDownElements[view._instance.focusIndex].focus();
                    } else {
                        view._instance.focusIndex = view._instance.focusIndex - 1;
                        dropDownElements[view._instance.focusIndex].focus();
                    }
                } else if (event.key === "ArrowDown" || event.key === "Down") {
                    if (dropDownElements[view._instance.focusIndex] === dropDownElements[dropDownElements.length - 1]) {
                        view._instance.focusIndex = 0;
                        dropDownElements[view._instance.focusIndex].focus();
                    } else {
                        view._instance.focusIndex = view._instance.focusIndex + 1;
                        dropDownElements[view._instance.focusIndex].focus();
                    }
                } else if (event.key === "Escape" || event.key === "Esc" || event.key === "Tab") {
                    event.preventDefault();
                    event.stopPropagation();
                    view._instance.searchBarInput.focus();
                }
            }

            taskUtils.EVENTS.UPDATE_COLUMNS.subscribe(function(eventName, eventData){
                view._proto._updateDropdown(view, eventData.columns);
            }, this);
            taskUtils.EVENTS.SAVED_SEARCH_CLEARED.subscribe(function () {
                view.clearSort();
            }, this);
            taskUtils.EVENTS.SAVED_SEARCH_LAUNCHED.subscribe(function (eventName, eventData) {
                if (!eventData || !eventData.search) {
                    view.clearSort();
                }
            }, this);
            taskUtils.EVENTS.UPDATE_SORT_FILTER.subscribe(function(eventName, eventData){
                view.launchItem();
            }, this);

            this._proto._loadDropdown(this, true);
            this.loadView(this);

            bpmext.log.info("SearchSortFilter.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try
            {
                utilities.handleVisibility(this.context);
            }
            catch (e)
            {
                //{#feature: US-1330 Added RT localization}
                //bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if(e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    //bpmext.log.error("  Call stack: " + e.stack);
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                }
            }
        };

        this.constructor.prototype.change = function ()
        {
        };

        this.constructor.prototype.unload = function ()
        {
            bpmext.ui.unloadView(this);
        };
    }
};
