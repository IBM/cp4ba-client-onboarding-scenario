/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define("com.ibm.bpm.workplace.resources/UsersResource", ["./resourceBase"], function(resource) {
    "use strict";
    var ROUTE = resource._buildUrl("${urlPrefix}/v1/users", { urlPrefix: resource.contextRoot.rest }),
        PARTS = {
            ALL: "all",
            MEMBERSHIPS: "memberships",
            NONE: "none"
        };

    /**
     * Get a list of users
     *
     * @param {Object} [options] - optional params to pass to the API
     * @param {String[]} [options.parts] - list of parts to return see UserResource#PARTS
     * @param {String} [options.filter] - a filter string used to limit the returned users to only those with a username or full name
     *                                    matching this string. For partial matches, * should be used in place of a sequence of character.
     * @param {Boolean} [options.sort] - true to sort the results, default is true
     * @param {Number} [options.maxresult] - limit to the number of users returned. No guarantee of which users will be pruned from the
     *                                       returned list of users if specified.
     * @param {Number} [options.assignTaskidFilter] - task id that limits the returned user list to only those users able to be reassigned the
     *                                                corresponding task. The task's currently assigned user will never be included in the returned list.
     * @param {String} [options.systemID] - Id of the system where this task exists
     * @param {Boolean} [options.includeInternalMemberships] - when true will include in the returned list of memberships the internal group membership names that
     *                                                         the user belongs to. Default is false.If set to true, "memberships" must be included in the parts param
     * @returns {Promise} promise that resolves to the list of users
     */
    function get(options) {
        var query = {};

        // add user defined query params
        if (options) {
            query.filter = options.filter || undefined;
            query.parts = !!options.parts && options.parts.length > 0 && options.parts.join() || PARTS.NONE;
            query.sort = typeof options.sort === "boolean" && options.sort || true;
            query.includeInternalMemberships = typeof options.includeInternalMemberships === "boolean" && options.includeInternalMemberships || false;
            query.assignTaskidFilter = options.assignTaskidFilter || undefined;
            query.maxresult = typeof options.maxresult === "number" && options.maxresult || undefined;
        }
        if (query.filter) {
            query.filter = encodeURIComponent(query.filter);
            query.encodedParams = "filter";
        }

        return resource
            .get(ROUTE, {
                query: query,
                systemID: options && options.systemID
            })
            .then(
                function success(res) {
                    return res.data.users;
                }
            );
    }

    // module.exports
    return {
        PARTS: PARTS,
        get: get
    };
});
