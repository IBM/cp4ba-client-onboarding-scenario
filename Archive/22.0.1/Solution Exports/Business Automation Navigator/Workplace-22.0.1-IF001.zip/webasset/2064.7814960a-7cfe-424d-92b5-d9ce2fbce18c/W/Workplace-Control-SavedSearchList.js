/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof SavedSearchList
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof SavedSearchList
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof SavedSearchList
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof SavedSearchList
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof SavedSearchList
 * @method setData
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On Search Launched:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when a saved search query is launched</td>
 *               </tr>
 *           </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">item {object}</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">saved search data</td>
 *               </tr>
 *       </table>
 *     </td>
 *   </tr>
 * </table>
 */
workplace_control_InitSavedSearchList = function (utilities, array, domStyle, dom, resourceUtils, taskUtils, wpResources)
{
    "use strict";
    this._instance =
    {

    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            EVT_ONLOAD : "eventON_LOAD",
            EVT_ONSEARCH_LAUNCHED: "eventON_SEARCH_LAUNCHED",

            _setSelectedItem: function(item, view) {
            	var detailDiv = dom.byId("savedSearch_" + item.ID);
            	if(view._instance.selectedItem) {
            		if(view._instance.selectedItem === item) {
            			view._instance.selectedItem = null;
                		domStyle.set(detailDiv, "display", "none");
            		} else {
            			domStyle.set(dom.byId("savedSearch_" + view._instance.selectedItem.ID), "display", "none");
            			view._instance.selectedItem = item;
                		domStyle.set(detailDiv, "display", "");
            		}
            	} else {
            		view._instance.selectedItem = item;
            		domStyle.set(detailDiv, "display", "");
            	}
            },

            _launchSearch: function(item, view) {
				bpmext.log.info("SavedSearchList._launchSearch LOG >> (saved search): " + item, view);
				var eventObj = item? {search: item}:undefined;
            	taskUtils.EVENTS.SAVED_SEARCH_LAUNCHED.publish(eventObj);
				taskUtils.EVENTS.SET_NEXT_TASK_MODE.publish({isNextTaskMode: false});
            },

            _loadSavedSearches: function(view, selectedItem) {
                view._instance.searchResource.get().then(function(savedSearches) {
					view._instance.searches = resourceUtils.buildSavedSearches(savedSearches);
					if(view._instance.searches.length<1){
                        view._instance.savedSearchTitle.setLabel(bpmext.localization.formatMsg("savedSearchBuilder","emptyState"));
                    }else{
                        view._instance.savedSearchTitle.setLabel(bpmext.localization.formatMsg("savedSearchList","savedSearch"));
                    }
					view._instance.savedSearchVL.setViewData(view._instance.searches, true);
					if(selectedItem){
						var savedSearchID = selectedItem.ID || selectedItem.id;
						if(savedSearchID != view._instance.selectedItem) {
							view.setSelectedItem(selectedItem.ID || selectedItem.id);
							view.launchSavedSearchByID(selectedItem);
						}
					}
                });
            }
        };


        /*
        Public control methods *************************************************************
         */

		 /**
         * @instance
         * @memberof SavedSearchList
         * @method setSavedSearchPanel
         * @desc Set title, description, and icon of the workflow
         */
		this.constructor.prototype.setSavedSearchPanel = function setSavedSearchPanel(target) {
			bpmext.log.info("LaunchList.setWorkflowData ENTER >>", this);
			var view = this;
			if (this._instance.searches && this._instance.searches.length > 0){
				var data = this._instance.searches[target.ui.getIndex()];
				if(data){
					target.ui.getChild("Title").setText(data.display);
					target.context.element.setAttribute("value", data.ID);
					target.context.element.setAttribute("tabindex", "0");
					target.context.element.setAttribute("role", "tab");
					target.context.element.setAttribute("aria-label", data.display);


					if(this._instance.selectedItem == data.ID){
						target.context.element.classList.add("selected");
                        target.context.element.setAttribute("aria-selected", "true");
					}

					// Add mouse hover tooltip
					var timeout,titleElt = null,title = target.context.element.querySelector("p[id*='Title']");
					title.onmouseenter = function(){
						if(title.scrollHeight > title.clientHeight || title.scrollWidth > title.clientWidth){
							timeout = setTimeout(function() {
								var text = target.ui.getChild("Title").getText();
								titleElt = bpmext.ui.util.showTooltip(title, text, {
									horizontalPos: "LEFT",
									smartPositioning: true,
									alwaysShow: true,
									plainText: true
								});
							},1000);
						}
					};
					title.onmouseleave = function() {
						if(title.scrollHeight > title.clientHeight || title.scrollWidth > title.clientWidth){
							// Clear any timers set to timeout
							clearTimeout(timeout);
							if(titleElt != null){
								bpmext.ui.util.closeTooltip(titleElt, title);
								titleElt = null;
							}
						}
					};

					function selectSearch() {
						view.clearSelectedItems();
						target.context.element.classList.add("selected");
                        target.context.element.setAttribute("aria-selected", "true");
						view.launchSavedSearchByID(data);
					}
	
					target.context.element.onclick = function(){
						selectSearch();
					};

					target.context.element.onkeydown = function(event){
						if (event.key === "Enter" || event.key === " " || event.key === "Spacebar") {
							selectSearch();
						}
					};
				}
			}
		};

        /**
		 * @instance
		 * @memberof SavedSearchList
		 * @method launchSavedSearch
         * @param {Map} data The saved search data
		 * @desc Runs the saved search
		 */
		this.constructor.prototype.launchSavedSearch = function(data) {
			bpmext.log.info("SavedSearchList.launchSavedSearch ENTER: >>");
			this._proto._launchSearch(data, this);
			bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONSEARCH_LAUNCHED, {item:data});
		};

		/**
		 * @instance
		 * @memberof SavedSearchList
		 * @method launchSavedSearchByID
         * @param {String} data The saved search ID
		 * @desc Runs the saved search by ID
		 */
		this.constructor.prototype.launchSavedSearchByID = function(data) {
			bpmext.log.info("SavedSearchList.launchSavedSearchByID ENTER: >>");
			this._instance.selectedItem = data.ID || data.id;
			if(this._instance.selectedItem == null){
				data = "";
			}
			taskUtils.EVENTS.SAVED_SEARCH_LAUNCHED.publish({search: (data || "")});
			taskUtils.EVENTS.SET_NEXT_TASK_MODE.publish({isNextTaskMode: false});
			bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONSEARCH_LAUNCHED, {item: data.ID || data.id});

		};

        /**
		 * @instance
		 * @memberof SavedSearchList
		 * @method refresh
		 * @desc Reloads the saved search list
		 */
        this.constructor.prototype.refresh = function(selectedItem) {
			bpmext.log.info("SavedSearchList.refresh ENTER>>", this);
			this._proto._loadSavedSearches(this, selectedItem);
        };

		/**
		 * @instance
		 * @memberof SavedSearchList
		 * @method getCurrentSavedSearch
		 * @desc Return current selected SavedSearch id
		 */
        this.constructor.prototype.getCurrentSavedSearch = function() {
			bpmext.log.info("SavedSearchList.getCurrentSavedSearch ENTER >>", this);
			return this._instance.selectedItem;
		};

		/**
		 * @instance
		 * @memberof SavedSearchList
		 * @method setSelectedItemAt
		 * @param {int} index Index to set to
		 * @desc Set selected item at index
		 */
        this.constructor.prototype.setSelectedItemAt = function(index) {
			bpmext.log.info("SavedSearchList.setSelectedItemAt ENTER >>", this);
			this.clearSelectedItems();
			var items = this.context.element.querySelectorAll(".sidebar-item");
			items[index].classList.add("selected");
			items[index].setAttribute("aria-selected", "true");
		};

		/**
		 * @instance
		 * @memberof SavedSearchList
		 * @method getSelectedIndex
		 * @desc Return current selected SavedSearch index
		 */
        this.constructor.prototype.getSelectedIndex = function() {
			bpmext.log.info("SavedSearchList.getSelectedIndex ENTER >>", this);
			var items = this.context.element.querySelectorAll(".sidebar-item");
			for (var index = 0; index < items.length; index++){
				if(items[index].getAttribute("aria-selected") == true){
					return index;
				}
			}
		};

		/**
		 * @instance
		 * @memberof SavedSearchList
		 * @method setSelectedItem
	     * @param {String} searchID Search id to set to
		 * @desc Set the selected Item
		 */
        this.constructor.prototype.setSelectedItem = function(searchID) {
			bpmext.log.info("SavedSearchList.setSelectedItem ENTER >>", this);
			this.clearSelectedItems();
			var items = this.context.element.querySelectorAll(".sidebar-item");
			for (var index = 0; index < items.length; index++){
				if(items[index].getAttribute("value") == searchID){
					items[index].classList.add("selected");
					items[index].setAttribute("aria-selected", "true");
				}
			}
		};

		/**
		 * @instance
		 * @memberof SavedSearchList
		 * @method getListSize
		 * @desc Returns the amount of saved searches are in the list default is 1 (None selected)
		 */
        this.constructor.prototype.getListSize = function() {
			bpmext.log.info("SavedSearchList.getListSize ENTER >>", this);
			return this._instance.searches.length;
		};

		/**
		 * @instance
		 * @memberof SavedSearchList
		 * @method clearSelectedItems
		 * @desc Clear the selected item
		 */
        this.constructor.prototype.clearSelectedItems = function() {
			bpmext.log.info("SavedSearchList.clearSelectedItems ENTER >>", this);
			var items = this.context.element.querySelectorAll(".sidebar-item");
			for (var index = 0; index < items.length; index++){
				items[index].classList.remove("selected");
				items[index].setAttribute("aria-selected", "false");
			}
		};

        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function ()
        {
        	bpmext.log.info("SavedSearchList.load ENTER >>", this);

            if (!this.context.binding) {
                this.context.binding = bpmext.ui.substituteObject(this, "binding", "searches", null);
			}
			
			this._instance.savedSearchTitle = bpmext.ui.getView("Sidebar_Title", this);
			this._instance.savedSearchVL = bpmext.ui.getContainer("SavedSearchVL", this);
			this._instance.savedSearchVL.context.element.setAttribute("role", "tablist");
			this._instance.savedSearchVL.context.element.setAttribute("aria-label", bpmext.localization.formatMsg("savedSearchList", "none"));

			this._instance.savedSearchTitle.setLabel(bpmext.localization.formatMsg("savedSearchList","savedSearch"));

            this._instance.searchResource = wpResources.searches;
            this._instance.userResource = wpResources.user;
            this._proto._loadSavedSearches(this, null);
			this._instance.initList = true;

            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONSEARCH_LAUNCHED);

			taskUtils.EVENTS.SAVED_SEARCH_PILL_SET.subscribe(function (eventName, eventData){
				if(eventData && eventData.id){
					this._instance.selectedItem = eventData.id;
					this.setSelectedItem(eventData.id);
				}
			}, this);

			taskUtils.EVENTS.SAVED_SEARCH_DELETED.subscribe(function(){
				this._instance.selectedItem = null;
				this.refresh();
                this.setVisible(true);
			}, this);

			taskUtils.EVENTS.REFRESH_SAVED_SEARCH.subscribe(function(eventName, eventData){
				this.refresh(eventData.search);
			}, this);

			taskUtils.EVENTS.EDIT_SAVED_SEARCH.subscribe(function(eventName, eventData){
                if(this._instance.selectedItem){
					this.refresh({id: eventData.search});
                }
            }, this);

			taskUtils.EVENTS.SAVED_SEARCH_LAUNCHED.subscribe(function(eventName, eventData){
				var id = eventData.search.ID || eventData.search.id;
				if(!id){
					this._instance.selectedItem = null;
					this.clearSelectedItems();
				}else{
					this._instance.selectedItem = id;
				}
            }, this);
			taskUtils.EVENTS.SAVED_SEARCH_CLEARED.subscribe(function () {
				this._instance.selectedItem = null;
				this.clearSelectedItems();
			}, this);
			taskUtils.EVENTS.CREATE_SAVED_SEARCH.subscribe(function (eventName) {
				this.refresh();				
			}, this);

            bpmext.ui.loadView(this);

            bpmext.log.info("SavedSearchList.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try
            {
                utilities.handleVisibility(this.context);
            }
            catch (e)
            {
                //{#feature: US-1330 Added RT localization}
                //bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if(e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    //bpmext.log.error("  Call stack: " + e.stack);
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                }
            }
        };

        this.constructor.prototype.change = function (event)
        {
			bpmext.log.info("SavedSearchList.change ENTER >> (event): " + event, this);
        	if (event.type === "config") {
                switch (event.property) {
                    case "_metadata.visibility": {
                        this.view();
                        break;
                    }
                }
            }
            bpmext.log.info("SavedSearchList.change EXIT >>", this);
        };

        this.constructor.prototype.unload = function ()
        {
            bpmext.ui.unloadView(this);
        };
    }
};