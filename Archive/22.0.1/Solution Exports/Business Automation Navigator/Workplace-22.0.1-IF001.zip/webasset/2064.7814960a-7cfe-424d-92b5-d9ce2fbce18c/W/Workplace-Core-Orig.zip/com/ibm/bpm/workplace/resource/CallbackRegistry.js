/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define("com.ibm.bpm.workplace.resources/CallbackRegistry", ["dojo/_base/lang"], function(lang) {
    "use strict";
    var registry = {},
        _id = 0;

    /**
     * Add callbacks to a specific namespace
     *
     * @param {String} namespace - name of namespace
     * @param {Object} [callbackOptions] - Object containing success and failure callbacks with a context in which they should be called
     * @param {Function} [callbackOptions.success] - success callback
     * @param {Function} [callbackOptions.failure] - failure callback
     * @param {Object} [callbackOptions.context] - context in which to execute success and failure callbacks
     */
    function addCallback(namespace, callbackOptions) {
        var handler = undefined;
        if (namespace) {
            var ns = (registry[namespace] = registry[namespace] || { success: {}, failure: {} });
            // compute an id value to be used
            var cbId = _id++;
            // register success callback
            ns.success[cbId] = lang.hitch(callbackOptions.context, callbackOptions.success);
            // register failure callback
            ns.failure[cbId] = lang.hitch(callbackOptions.context, callbackOptions.failure);

            // create callback registration handler
            handler = {
                id: cbId,
                namespace: namespace,
                remove: function remove() {
                    var ns = registry[namespace];
                    if (ns) {
                        delete ns.success[this.id];
                        delete ns.failure[this.id];
                    }
                }
            };
        }
        return handler;
    }

    /**
     * Invoke all of the callbacks under a given namespace.
     * This is a variadic function, anything after the options argument will be passed down to the callback
     *
     * @param {Object} options - object containing the namespace name as well as additional flag
     * @param {String} options.namespace - name of the namespace to invoke callbacks of
     * @param {Boolean} [options.failure] - true to invoke failure callback if it is present under namespace, false (default) to invoke success callback
     */
    function notifyNamespace(options) {
        var ns,
            state,
            args = Array.prototype.slice.call(arguments, 1);
        if (options) {
            ns = registry[options.namespace] || {};
            state = options.failure ? ns.failure : ns.success;
            Object.keys(state || {}).forEach(function(cbId) {
                state[cbId].apply(null, args);
            });
        }
    }

    // module.exports
    return {
        addCallback: addCallback,
        notifyNamespace: notifyNamespace
    };
});
