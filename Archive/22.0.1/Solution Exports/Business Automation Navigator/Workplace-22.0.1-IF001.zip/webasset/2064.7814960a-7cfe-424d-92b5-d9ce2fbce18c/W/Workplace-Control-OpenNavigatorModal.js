/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof OpenNavigatorModal
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof OpenNavigatorModal
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof OpenNavigatorModal
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof OpenNavigatorModal
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof OpenNavigatorModal
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof OpenNavigatorModal
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof OpenNavigatorModal
 * @method triggerFormulaUpdates
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 * </table>
 */
workplace_control_InitOpenNavigatorModal = function (utilities, taskUtils, domAttr)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
        };


        /*
        Public control methods *************************************************************
         */

        /**
		 * @instance
		 * @memberof OpenNavigatorModal
		 * @method closeModal
		 * @desc Closes the modal dialog
         */
        this.constructor.prototype.closeModal = function() {
			bpmext.log.info("OpenNavigatorModal.closeModal ENTER >> ",this);
            this.setVisible(false, true);
			bpmext.log.info("OpenNavigatorModal.closeModal EXIT << ");
        };

        /**
		 * @instance
		 * @memberof OpenNavigatorModal
		 * @method openNavigator
		 * @desc open navigator in new window and closes the modal
         */
        this.constructor.prototype.openNavigator = function() {
            bpmext.log.info("OpenNavigatorModal.claimAction ENTER >> ", this);
            if(this._instance.doNotShowCheckbox.isChecked()){
                // Do not show again is checked we need to set the user setting
                this.setOption("skipNavDialog", true);
                this._instance.skipNavDialog = true;
            }
            window.open(this._instance.navigatorUrl, this._instance.windowName);
            this.closeModal();
			bpmext.log.info("OpenNavigatorModal.claimAction EXIT << ");
        };

        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function (){
            bpmext.log.info("OpenNavigatorModal.load ENTER >>", this);

            var view = this, opts = this.context.options;

            if (!opts.skipNavDialog) {
                bpmext.ui.substituteConfigOption(this, "skipNavDialog", false);
            }
            this._instance.skipNavDialog = opts.skipNavDialog.get("value");
            this._instance.modalSection = bpmext.ui.getContainer("ModalSection", this);
            this._instance.modalSection.setPrimaryButtonText(bpmext.localization.formatMsg("workplace", "ok"));
            this._instance.modalSection.setSecondaryButtonText(bpmext.localization.formatMsg("workplace", "cancel"));
            //CV in ModalSection
            this._instance.panel = bpmext.ui.getContainer("Panel", this);
            //CV in Panel
            this._instance.OpenNavigatorNote = bpmext.ui.getView("OpenNavigatorNote", this);
            this._instance.panel.setTitle(bpmext.localization.formatMsg("workplace", "openNavigator"));
            this._instance.OpenNavigatorNote.setLabel(bpmext.localization.formatMsg("workplace", "openNavigatorNote"));

            this._instance.doNotShowCheckbox = bpmext.ui.getView("DoNotShowCheckbox", this);
            this._instance.doNotShowCheckbox.setLabel(bpmext.localization.formatMsg("claimTaskModal", "doNotShowMessage"));

            var panelHeaderIcon = this._instance.panel.context.element.querySelector("div.panel-heading-controls > div.panel-heading-icon > i");
            !!panelHeaderIcon && domAttr.remove(panelHeaderIcon, "tabindex");

            taskUtils.EVENTS.NOTIFICATION_OPEN_NAVIGATOR.subscribe(function (eventName, eventData) {
            	view._instance.navigatorUrl = eventData.url;
            	view._instance.windowName = eventData.name;
            	if (view._instance.skipNavDialog) {
            		window.open(view._instance.navigatorUrl, view._instance.windowName);
            	} else {
            		view.setVisible(true, true);
            	}
            }, this);

            this.loadContainer(this);

            bpmext.log.info("OpenNavigatorModal.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try {
                utilities.handleVisibility(this.context);
            }
            catch (e){
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e, this);
                if(e.stack) {
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack), this);
                }
            }
        };

        this.constructor.prototype.change = function (event){
            bpmext.log.info("OpenNavigatorModal.change ENTER >> (event): " + event, this);
            bpmext.log.info("OpenNavigatorModal.change ENTER >>", this);
        };

        this.constructor.prototype.unload = function (){
            bpmext.log.info("OpenNavigatorModal.unload ENTER >> ", this);
            bpmext.ui.unloadContainer(this);
            bpmext.log.info("OpenNavigatorModal.unload ENTER >>", this);
        };
    }
};