/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof SavedSearchBuilder
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof SavedSearchBuilder
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof SavedSearchBuilder
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof SavedSearchBuilder
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof SavedSearchBuilder
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof SavedSearchBuilder
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof SavedSearchBuilder
 * @method triggerFormulaUpdates
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 * </table>
 */
workplace_control_InitSavedSearchBuilder = function (utilities, taskUtils, wpResources, domAttr, array)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            _getTeams: function _getTeams(view, permissions, sizeLimit) {
                bpmext.log.info("SavedSearchBuilder._getTeams LOG >>", view);
                try {
                    wpResources.teams.get({filter:0,size:sizeLimit})
                        .then(dojo.hitch(view, function(teams) {
                            if (teams && teams.length>0) {
                                var teamsList=[];
                                for(var i = 0; i < teams.length; i++){
                                    teamsList.push(teams[i].teamName);
                                }
                                this._instance.teams = teams;
                                this._instance.teamTypeAhead.context.options.itemList.set("value", teamsList);
                            }else{
                                this._instance.shareCB.setVisible(false, true);
                                this._instance.teamTypeAhead.setVisible(false, true);
                            }
                            if(view._instance.searchId){
                                view._proto._launchSavedSearch(view, permissions);
                            }
                        }));
                } catch (error) {
                    bpmext.log.error(error.message);
                }
            },
            _getPermissions: function _getPermissions(view){
                bpmext.log.info("SavedSearchBuilder._getPermissions LOG >>", view);
                var self = view;
                view._proto._checkUserRightsChanged(view).then(function(whatChanged){
                    if(!view.context.options.instanceMode.get("value")){
                        self._proto._enableCreateSearch(self, whatChanged);// Base case: None and Create Right are the same behaviour
                    }
                });
            },
            _enableCreateSearch: function _enableCreateSearch(view, permissions){
                var self = view;
                self._instance.saveNewCB.setVisible(true,true);
                self._instance.clearButton.setVisible(true,true);
                wpResources.searches.get().then(dojo.hitch(self, function(searches){
                    wpResources.user.get().then(dojo.hitch(self, function(currentUser){
                        self._instance.userOwnedSaveSearches = searches.reduce(function(ownedSaveSearches, search) {
                            var currentUsername = wpResources.isFederated ? permissions.currentUserSecurityName : currentUser.userName;
                            if (currentUsername === search.owner) {
                                ownedSaveSearches.push(search);
                            }
                            return ownedSaveSearches;
                        }, []);
                        if (currentUser.showNextTaskDashboard) {
                            self._instance.isNextTaskMode = true;
                            self._instance.autoClaimNextTask = currentUser.autoClaimNextTask;
                            self._instance.defaultNextTaskSavedSearch = currentUser.defaultNextTaskSavedSearch;
                        }
                        self._instance.clearButton.setVisible(true,true);
                        self._instance.saveAsNewLayout.setVisible(false, true);
                        self._instance.teamTypeAhead.setVisible(false, true);
                        if(permissions.currentAdminRight){
                            self._instance.saveNewCB.setVisible(true,true);
                            self._instance.saveAsNewLayout.setVisible(self._instance.saveNewCB.isChecked(), true);
                            self._instance.deleteButton.setVisible(view._instance.searchId !== "" && view._instance.searchId !== null, true);
                            self._instance.shareCB.setVisible(true, true);
                            self._instance.shareCB.setEnabled(true);
                            self._instance.teamTypeAhead.setEnabled(true);
                            self._instance.teamTypeAhead.setVisible(self._instance.shareCB.isChecked(), true);
                            taskUtils.EVENTS.SLIDEOUT_SET_PRIMARY_BTN.publish({visible: true});
                        }else if(permissions.currentCreateShareRight || permissions.currentCreateRight){
                            if(self._proto._isUserOwnedSavedSearch(self, self._instance.searchId) || self._instance.searchId==="" || self._instance.searchId===null){
                                self._instance.saveNewCB.setVisible(true,true);
                                self._instance.saveAsNewLayout.setVisible(self._instance.saveNewCB.isChecked(), true);
                                self._instance.deleteButton.setVisible(view._instance.searchId !== "" && view._instance.searchId !== null, true);
                                self._instance.shareCB.setVisible(permissions.currentCreateShareRight, true);
                                self._instance.shareCB.setEnabled(permissions.currentCreateShareRight);
                                self._instance.teamTypeAhead.setEnabled(permissions.currentCreateShareRight);
                                self._instance.teamTypeAhead.setVisible(self._instance.shareCB.isChecked(), true);
                                taskUtils.EVENTS.SLIDEOUT_SET_PRIMARY_BTN.publish({visible: true});
                            }else{
                                self._instance.saveNewCB.setVisible(true,true);
                                self._instance.deleteButton.setVisible(false, false);
                                self._instance.shareCB.setVisible(true, true);
                                self._instance.shareCB.setEnabled(false);
                                self._instance.teamTypeAhead.setEnabled(false);
                                self._instance.teamTypeAhead.setVisible(true, true);
                                taskUtils.EVENTS.SLIDEOUT_SET_PRIMARY_BTN.publish({visible: false});
                            }
                        }else{
                            self._instance.saveNewCB.setVisible(false,true);
                            self._instance.deleteButton.setVisible(false, true);
                            self._instance.shareCB.setVisible(false, true);
                            self._instance.shareCB.setEnabled(false);
                            self._instance.teamTypeAhead.setEnabled(false);
                            taskUtils.EVENTS.SLIDEOUT_SET_PRIMARY_BTN.publish({visible: false});
                        }
                        self._proto._getTeams(self, permissions, 250);
                        // Accessibility
                        if(self.isVisible()){
                            taskUtils.setTabCycle(self);
                        }
                    }));
                }));
            },
            _save: function _save(view){
                bpmext.log.info("SavedSearchBuilder._save LOG >>", view);
                try {
                    view._proto._checkUserRightsChanged(view).then(function(whatChanged) {
                        if(whatChanged.currentAdminRight || whatChanged.currentCreateShareRight || whatChanged.currentCreateRight || !whatChanged.currentRunOnlyRight) {
                            wpResources.searches.save(view._instance.currentSavedSearch).then(dojo.hitch(view,function(search){
                                view._instance.searchId = search.id;
                                view._instance.searchName = search.name;
                                taskUtils.EVENTS.TASKLIST_SHOW_LOADER.publish();
                                taskUtils.EVENTS.REFRESH_SAVED_SEARCH.publish({searchID:search.id, search: search});
                                view._proto._getPermissions(view);
                            }));
                        }
                    });
                } catch (error) {
                    bpmext.log.error(error.message);
                }
            },
            _update: function _update(view){
                bpmext.log.info("SavedSearchBuilder._update LOG >>", view);
                try {
                    view._proto._checkUserRightsChanged(view).then(function(whatChanged) {
                        var isUserSavedSearch = view._proto._isUserOwnedSavedSearch(view, view._instance.searchId);
                        if(whatChanged.currentAdminRight || (whatChanged.currentCreateShareRight && isUserSavedSearch) || (whatChanged.currentCreateRight && isUserSavedSearch) || (!whatChanged.currentRunOnlyRight && isUserSavedSearch)) {
                            wpResources.searches.update(view._instance.currentSavedSearch).then(dojo.hitch(view,function(search){
                                view._instance.searchId = search.id;
                                view._instance.searchName = search.name;
                                taskUtils.EVENTS.REFRESH_SAVED_SEARCH.publish({searchID:search.id, search: search});
                                taskUtils.EVENTS.SET_SS_UNSAVED.publish(false);
                                view._proto._getPermissions(view);
                            }));
                        }
                    });
                } catch (error) {
                    bpmext.log.error(error.message);
                }
            },
            _getInteractionFromFilter: function _getInteractionIndexFromFilter(filter){
                bpmext.log.info("SavedSearchBuilder._getInteractionFromFilter LOG >>");
                for(var x=0;x<filter.length;x++){
                    if(filter[x].field==="interaction"){
                        return x;
                    }
                }
            },
            _isUserOwnedSavedSearch: function _isUserOwnedSavedSearch(view){
                var self = view, userOwnedList = view._instance.userOwnedSaveSearches;
                for ( var i=0; i< userOwnedList.length; i++){
                    if(userOwnedList[i].id+"" === self._instance.searchId+""){
                        return true;
                    }
                }
                return false;
            },
            _validateSaveSearch: function _validateSaveSearch(view, requireSave) {
                bpmext.log.info("SavedSearchBuilder._validateSaveSearch LOG >>", view);
                var validationResults = view._proto._validateInputs(view);
                taskUtils.EVENTS.SLIDEOUT_SET_PRIMARY_BTN.publish({enable: validationResults});

                if (validationResults && requireSave) {
                    view._proto._saveAction(view);
                }
            },
            _validateInputs: function _validateInputs(view) {
                bpmext.log.info("SavedSearchBuilder._validateInputs LOG >>", view);

                // avoid short circuiting
                var validName = view._proto._validateName(view);
                var validTeam = view._proto._validateTeam(view);

                return  validName && validTeam;
            },
            _validateName: function _validateName(view) {
                bpmext.log.info("SavedSearchBuilder._validateName LOG >>", view);

                // define used items
                var searchNameInput = view._instance.nameText;
                var userOwnedSaveSearches = view._instance.userOwnedSaveSearches;

                if(!view._instance.saveNewCB.isChecked()){
                    if(view._instance.searchId == null || view._instance.searchId == ""){
                        return false;
                    }
                    else{
                        return true;
                    }
                }

                // validate the save search name field
                var nameStream = searchNameInput._instance.input.firstElementChild.value;
                var isNameExisted = !!userOwnedSaveSearches && userOwnedSaveSearches.reduce(function(enable, search) {
                    return enable || (search.name === nameStream);
                }, false);

                //none empty spaces & none numerical & at most 64 chars & no repeated
                if (!nameStream.trim()) {
                    searchNameInput.setValid(false, bpmext.localization.formatMsg("general", "EMPTY_INPUT_WARNING"));
                } else if (!isNaN(nameStream)) {
                    searchNameInput.setValid(false, bpmext.localization.formatMsg("general", "NONE_NUMERICAL_WARNING"));
                } else if (nameStream.length > 64) {
                    searchNameInput.setValid(false, bpmext.localization.formatMsg("general", "INPUT_TOO_LONG_64_WARNING"));
                } else if (isNameExisted) {
                    searchNameInput.setValid(false, bpmext.localization.formatMsg("general", "ALREADY_EXISTED_WARNING"));
                } else {
                    searchNameInput.setValid(true);
                    return true;
                }

                return false;
            },
            _validateTeam: function _validateTeam(view) {
                bpmext.log.info("SavedSearchBuilder._validateTeam LOG >>", view);

                // define used items
                var shareCB = view._instance.shareCB;
                var shareWithTeam = view._instance.teamTypeAhead;
                var teams = view._instance.teams;

                if (shareCB.isChecked()) {
                    var inputTeam = view._instance.currentTeam; //Get latest value instead of checking ui value
                    var isTeamFound = !!teams && teams.reduce(function(enable, team) {
                        return enable || (team.teamName === inputTeam);
                    }, false);

                    if (!inputTeam || (inputTeam && !inputTeam.trim())){
                        shareWithTeam.setValid(false, bpmext.localization.formatMsg("general", "EMPTY_INPUT_WARNING"));
                    } else if (!isTeamFound) {
                        shareWithTeam.setValid(false, bpmext.localization.formatMsg("general", "NO_RESULTS_FOUND_WARNING"));
                    } else {
                        shareWithTeam.setValid(true);
                        return true;
                    }
                    return false;
                }

                return true;
            },
            _saveAction: function _saveAction(view) {
            	//function  body is from previous saveSaveSearch function
                bpmext.log.info("SavedSearchBuilder.saveAction ENTER >> ",view);
                var selectedTeam = [],filterConditions = [],interactionValue;
                //Check if this is save as new
                if(view._instance.saveNewCB.isChecked()){
                    view._instance.searchId = null;
                }
                //this._instance.taskList = bpmext.ui.getContainer("/Task_List1");
                var inputTeam = view._instance.teamTypeAhead.getText();
                if(view._instance.teamTypeAhead.getText()){
                    view._instance.teams.forEach(function(team){
                        if(team.teamName === inputTeam){
                            selectedTeam.push(team);
                        }
                    });
                }
                filterConditions = view._instance.searchFilter.getCurrentFilter();
                if(view._instance.scopeCheckbox.isChecked()){
                    view._instance.scopeFilter.getCurrentFilter() && view._instance.scopeFilter.getCurrentFilter().forEach(function(data){
                        data.value && filterConditions.push(data);
                    });
                }
                interactionValue = filterConditions.splice(view._proto._getInteractionFromFilter(filterConditions),1)[0];
                view._instance.currentSavedSearch = {
                    interaction : interactionValue? interactionValue.value:undefined,
                    conditions : filterConditions,
                    fields : view._instance.columnSelector.getCurrentSelectedColumns(),
                    name : view._instance.saveNewCB.isChecked()?view._instance.nameText.getText():view._instance.searchName,
                    organization : view._instance.organizeBySelector.getSelectedItem(),
                    shared : view._instance.shareCB.isChecked(),
                    teams : selectedTeam,
                    sort : view._instance.currentSort
                };
                taskUtils.EVENTS.TASKLIST_SHOW_LOADER.publish();
                if(view._instance.searchId && view._instance.searchId!==""){
                    view._instance.currentSavedSearch.id = view._instance.searchId;
                    view._proto._update(view);
                }else{
                    view._proto._save(view);
                }

                view.closeSavedSearch();
                
                bpmext.log.info("SavedSearchBuilder.saveAction EXIT << ");
            },
            _launchSavedSearch: function _launchSavedSearch(view, permissions){
                bpmext.log.info("SavedSearchBuilder._launchSavedSearch LOG >>", view);
                try {
                    wpResources.searches.get({id:view._instance.searchId}).then(dojo.hitch(view,
                        function(search){
                            this._proto._displaySearch(this, search, permissions);
                        }
                    ));
                } catch (error) {
                    bpmext.log.error(error.message);
                }
            },
            _displaySearch: function _displaySearch(view, search, permissions){
                if(search){
                    view._instance.searchFilter.hide();
                    view._instance.columnSorter.hide();
                    view._instance.columnSelector.hide();
                    //Advanced Options
                    view._instance.currentSearch = search;
                    // view._instance.nameText.setText(search.name);
                    // Organize by, PFS not supported yet
                    // view._instance.organizeBySelector.setSelectedItem(search.organization);

                    view._instance.saveNewCB.setChecked(false);

                    if(search.shared && search.teams && search.teams.length>0){
                        if(!permissions.currentCreateShareRight && !permissions.currentAdminRight){
                            view._instance.shareCB.setVisible(true);
                            view._instance.shareCB.setEnabled(false);
                            view._instance.teamTypeAhead.setEnabled(false);
                        }
                        view._instance.shareCB.setChecked(true);
                        view._instance.currentTeam = search.teams[0].teamName;
                        view._instance.teamTypeAhead.setText(search.teams[0].teamName);
                        view._instance.teamTypeAhead.setVisible(true);
                    } else {
                        view._instance.shareCB.setChecked(false);
                    }


                    //Search Filter
                    view._instance.conditions = [];
                    view._instance.scopeConditions = [];
                    view._instance.savedSort = [];
                    var isPXServer = view.context.isWorkflowPXServer && view.context.isWorkflowPXServer() === true;
                    var interaction = {name:"interaction", operator:"Equals", value:search.interaction}, x, defaultScopeFilters = isPXServer ? taskUtils.DEFAULT_PX_SCOPE_FILTERS : taskUtils.DEFAULT_SCOPE_FILTERS;
                    view._instance.conditions.push(interaction);
                    if(search.conditions){
                        for(x = 0; x < search.conditions.length; x++){
                            var val = search.conditions[x];
                            if(defaultScopeFilters.indexOf(val.field)>-1){
                                view._instance.scopeConditions.push({name:val.field,operator:val.operator,value:val.value});
                            }else{
                                view._instance.conditions.push({name:val.field,operator:val.operator,value:val.value});
                            }
                        }
                    }
                
                    if(view._instance.scopeConditions.length>0){
                        view._instance.scopeCheckbox.setChecked(true);
                        taskUtils.EVENTS.SET_SAVED_SEARCH_SCOPE.publish({filterCondition:view._instance.scopeConditions, selectedCols: search.fields})
                        setTimeout(function(){
                            view._instance.scopeFilter.setCurrentFilter(view._instance.scopeConditions);
                            view._instance.searchFilter.setCurrentFilter(view._instance.conditions);
                        },100)
                    }else{
                        view._instance.searchFilter.setCurrentFilter(view._instance.conditions);
                        view._instance.scopeCheckbox.setChecked(false);

                         //Column Selector
                        if(search.fields){
                            view._instance.selectedCols = [];
                            var businessDataList = {};
                            // double check if business data still exists in current business data list
                            for(x = 0; x < search.fields.length; x++){
                                val = search.fields[x];
                                var origins ="";
                                if(val.indexOf("@")!==-1){ // check for business data
                                    //TODO need to check the current fields against the fields in the saved search - APAR 57482
                                    // taskUtils.publishError(bpmext.localization.formatMsg("Errors", "savedSearchOldBusinessData", businessDataField));
                                    var businessDataField = val.split("@")[0];
                                    var businessDataAlias = "";
                                    for(var y =0; y < search.aliases.length; y++){
                                        if(search.aliases[y].field === businessDataField){
                                            businessDataAlias = search.aliases[y].alias;
                                            break;
                                        }// get business data alias
                                    }
                                    for(y = 0; y < view._instance.businessData.length; y++){
                                        if(search.fields[x] == view._instance.businessData[y].name+"@"+view._instance.businessData[y].type){
                                            origins = view._instance.businessData[y].origins;
                                            break;
                                        }
                                    }
                                    if(businessDataField && businessDataAlias){
                                        view._instance.selectedCols.push({name: businessDataField, value: businessDataAlias, origins:origins, isBusinessData: true});
                                    }
                                }else{
                                    view._instance.selectedCols.push({name: val, value: taskUtils.getLabelFromTaskProperty(val)});
                                }
                            }
                            view._instance.columnSelector.context.binding.set("value", view._instance.selectedCols);
                            view._instance.columnSelector.setCurrentDefault(view._instance.selectedCols);
                            view._instance.columnSelector.changeSelectedColumns(false, true);
                        }
                    }

                    // Column Sort
                    if(search.sort){
                        var value =  taskUtils.getLabelFromTaskProperty(search.sort[0].field);
                        var order, cols = [], desc;
                        if (search.sort[0].order === "DESC"){
                            order = "descending";
                        }else{
                            order = "ascending";
                        }
                        view._instance.savedSort = {field: value, order: order};
                        for (var x = 0; x < search.fields.length; x++){
                            var value = view.context.options.instanceMode.get("value") ? taskUtils.getLabelFromInstanceProperty(search.fields[x]) : taskUtils.getLabelFromTaskProperty(search.fields[x]);
                            if(view.context.options.instanceMode.get("value")){
                                if(taskUtils.getInstanceSystemDataDescription(search.fields[x])){
                                    desc = taskUtils.getInstanceSystemDataDescription(search.fields[x]);
                                }else{
                                    desc = value;
                                }
                            }else{
                                if(taskUtils.getTaskSystemDataDescription(search.fields[x])){
                                    desc = taskUtils.getTaskSystemDataDescription(search.fields[x]);
                                }else{
                                    desc = value;
                                }
                            }
                            cols.push({name: search.fields[x], value: value, desc: desc});
                        }
                        view._instance.columnSorter._proto._updateDropdown(view._instance.columnSorter, cols);
                        view._instance.columnSorter.setSort(search.sort[0].field, search.sort[0].order);
                    }
                    
                    //Number of Entries Selector
                    if(search.size){
                        view.updateTaskListNumberOfTask(search.size);
                    }
                    view._instance.searchFilter.show();
                    view._instance.columnSorter.show();
                    view._instance.columnSelector.show();
                    view.updateSaveButton();
                    taskUtils.EVENTS.FORCED_REFRESH.publish();
                }else{
                    bpmext.log.error("Invalid search ID >> " + view._instance.searchId);
                }
            },
            _resetFields: function _resetFields(view, runDefaultSearch) {
                view._instance.currentSavedSearch = null;
                view._instance.searchId = null;
                view._instance.shareCB.setChecked(false);
                view._instance.saveNewCB.setChecked(false);
                view._instance.deleteButton.setVisible(false, true);
                view.clearAllFields(runDefaultSearch);
                view.updateSaveButton();
                taskUtils.EVENTS.SAVED_SEARCH_CLEARED.publish();
            },

            _checkUserRightsChanged: function(view) {
        		var oldAdminRight = view._instance.sharedSavedSearchAdminRight,
        		oldRunOnlyRight = view._instance.sharedSavedSearchRunOnlyRight,
        		oldCreateRight = view._instance.sharedSavedSearchCreateRight,
				oldShareRight = view._instance.sharedSavedSearchCreateShareRight;

        		var self = this;

        		return wpResources.searches.getActions().then(function(savedSearchActions) {
        			view._instance.sharedSavedSearchAdminRight = self._isSharedSavedSearchAdminRightPresent(savedSearchActions.actions);
        			view._instance.sharedSavedSearchCreateRight = self._isSharedSavedSearchCreateRightPresent(savedSearchActions.actions);
					view._instance.sharedSavedSearchRunOnlyRight = self._isSharedSavedSearchRunOnlyRightPresent(savedSearchActions.actions);
					view._instance.sharedSavedSearchCreateShareRight = self._isSharedSavedSearchCreateShareRightPresent(savedSearchActions.actions);
					view._instance.currentUserSecurityName = savedSearchActions.userSecurityName;
					var whatChanged = {
        				"adminRightChanged" : view._instance.sharedSavedSearchAdminRight !== oldAdminRight,
        				"createRightChanged" : view._instance.sharedSavedSearchCreateRight !== oldCreateRight,
						"runOnlyRightChanged" : view._instance.sharedSavedSearchRunOnlyRight !== oldRunOnlyRight,
						"shareRightChanged" : view._instance.sharedSavedSearchShareRight !== oldShareRight,
        				"currentAdminRight" : view._instance.sharedSavedSearchAdminRight,
        				"currentCreateRight" : view._instance.sharedSavedSearchCreateRight,
						"currentRunOnlyRight" : view._instance.sharedSavedSearchRunOnlyRight,
						"currentCreateShareRight" : view._instance.sharedSavedSearchCreateShareRight,
						"currentUserSecurityName" : view._instance.currentUserSecurityName
        			};
                   return whatChanged;
        		});
        	},

            _isSharedSavedSearchAdminRightPresent: function(savedSearchActions) {
            	return array.some(savedSearchActions, function(action) {
            		return action === wpResources.searches.ACTION.ADMINISTER_SHARED_SAVED_SEARCHES;
            	});
            },

            _isSharedSavedSearchCreateRightPresent: function(savedSearchActions) {
            	return array.some(savedSearchActions, function(action) {
            		return action === wpResources.searches.ACTION.MANAGE_SAVED_SEARCH;
            	});
            },

            _isSharedSavedSearchRunOnlyRightPresent: function(savedSearchActions) {
            	return array.some(savedSearchActions, function(action) {
            		return action === wpResources.searches.ACTION.RUN_SAVED_SEARCH;
            	});
			},

			_isSharedSavedSearchCreateShareRightPresent: function(savedSearchActions) {
            	return array.some(savedSearchActions, function(action) {
            		return action === wpResources.searches.ACTION.CREATE_SHARED_SAVED_SEARCH;
            	});
			}
        };


        /*
        Public control methods *************************************************************
         */

         /**
         * @instance
         * @memberof SavedSearchBuilder
         * @method saveSavedSearch
         * @desc Saves the current saved search
         */
        this.constructor.prototype.saveSavedSearch = function saveSavedSearch() {
            bpmext.log.info("SavedSearchBuilder.saveSavedSearch ENTER >> ",this);
            this.validateSaveSearch(true);
        };

        /**
         * @instance
         * @memberof SavedSearchBuilder
         * @method validateSaveSearch
         * @desc Saves the current saved search
         */
        this.constructor.prototype.validateSaveSearch = function validateSaveSearch(requireSave) {
            bpmext.log.info("SavedSearchBuilder.validateSaveSearch ENTER >> ",this);
            this._proto._validateSaveSearch(this, requireSave);
        };

         /**
         * @instance
         * @memberof SavedSearchBuilder
         * @method checkShareCB
         * @desc Depending on the state of the 'Share with teams' checkbox, shows or hides the team selection
         */
        this.constructor.prototype.checkShareCB = function checkShareCB() {
            bpmext.log.info("SavedSearchBuilder.checkShareCB ENTER >> ",this);
            if(this._instance.shareCB.isChecked()){
                this._instance.teamTypeAhead.setVisible(true,true);
                this._instance.teamTypeAhead.context.element.scrollIntoView();
                this._instance.teamTypeAhead.focus();
            }else{
                this._instance.teamTypeAhead.setText("");
                this._instance.teamTypeAhead.setVisible(false,true);
            }

            // Fix defect 332243
            this.updateSaveButton();
            if(this._instance.shareCB.isChecked()) {
                this._instance.teamTypeAhead.setValid(true);
            }

            bpmext.log.info("SavedSearchBuilder.checkShareCB EXIT << ");
        };

         /**
         * @instance
         * @memberof SavedSearchBuilder
         * @method getPermissions
         * @desc Enables the Save button based on the current user's permissions
         */
        this.constructor.prototype.getPermissions = function getPermissions() {
            bpmext.log.info("SavedSearchBuilder.getPermissions ENTER >> ",this);
            this._proto._getPermissions(this);
            bpmext.log.info("SavedSearchBuilder.getPermissions EXIT << ");
        };

        /**
         * @instance
         * @memberof SavedSearchBuilder
         * @method updateSaveButton
         * @desc Sets save button to be enabled based on the current state
         */
        this.constructor.prototype.updateSaveButton = function updateSaveButton() {
            bpmext.log.info("SavedSearchBuilder.updateSaveButton ENTER: >>");
            this._proto._validateSaveSearch(this, false);
        };

        /**
         * @instance
         * @memberof SavedSearchBuilder
         * @method closeSavedSearch
         * @desc Closes the dialog
         */
        this.constructor.prototype.closeSavedSearch = function closeSavedSearch() {
            bpmext.log.info("SavedSearchBuilder.closeSavedSearch ENTER: >>");
            if(!this.isVisible()){
                return;
            }
            var sfModified, columnModified, sortModified, ssfModified = false;
            this.hide(true);
            this._instance.searchFilter.cleanUp();
            if(this._instance.scopeCheckbox.isChecked()){
                this.context.options.searchFilters.set("value",this._instance.searchFilter.getCurrentFilter().concat(this._instance.scopeFilter.getCurrentFilter()));
                ssfModified = true;
            }else{
                this.context.options.searchFilters.set("value",this._instance.searchFilter.getCurrentFilter());
            }
            if(this._instance.searchId && this._instance.conditions && this._instance.searchFilter.getCurrentFilter()){
                sfModified = this._instance.searchFilter.compareFilterConditions(this._instance.conditions, this._instance.searchFilter.getCurrentFilter(true));
                sortModified = this._instance.columnSorter.compareFilterConditions(this._instance.savedSort, this._instance.columnSorter.getCurrentSort());
                columnModified = this._instance.columnSelector.checkIfModified();
                if(this._instance.scopeCheckbox.isChecked()){
                    ssfModified = this._instance.scopeFilter.compareFilterConditions(this._instance.scopeConditions, this._instance.scopeFilter.getCurrentFilter(true));
                }
                
                if(sfModified || columnModified || sortModified || ssfModified){
                    taskUtils.EVENTS.SET_SS_UNSAVED.publish(true);
                }else{
                    taskUtils.EVENTS.SET_SS_UNSAVED.publish(false);
                }
            }else{
                sfModified = this._instance.searchFilter.compareFilterConditions(taskUtils.DEFAULT_FILTER_CONDITION, this._instance.searchFilter.getCurrentFilter(true));
                sortModified = this._instance.columnSorter.compareFilterConditions({field: bpmext.localization.formatMsg("controlTaskList", "taskDueDate"), order: "ascending"}, this._instance.columnSorter.getCurrentSort());
                columnModified = this._instance.columnSelector.checkIfModified();
                
                if(!sfModified && !columnModified && !sortModified && !ssfModified){
                    if(this.context.options.instanceMode.get("value")){
                        taskUtils.EVENTS.SET_INSTANCE_BADGE.publish({text:"",clearSS:false})
                    }else if (this._instance.isNextTaskMode) {
                    	// load default filter in next task mode, need show a search badge to clear it to back to next task mode
                    	taskUtils.EVENTS.SET_NEXT_TASK_MODE.publish({isNextTaskMode: false});
                    	taskUtils.EVENTS.SET_TASK_BADGE.publish({text:bpmext.localization.formatMsg("SearchBar", "defaultApplied"),clearSS:false})
                    } else {
                        var sortByValue = this.context.options.taskSortBy.get("value");
                        if (sortByValue && sortByValue.value !== "ascending") {
                            taskUtils.EVENTS.SET_TASK_BADGE.publish({text:"",clearSS:false})
                        }
                    }
                }
            }
        };

        /**
         * @instance
         * @memberof SavedSearchBuilder
         * @method initializeColumnSelector
         * @desc Calls the services to retrieve the current system and business data and populates the columns selector with the result
         */
        this.constructor.prototype.initializeColumnSelector = function initializeColumnSelector(resetColumns) {
            bpmext.log.info("SavedSearchBuilder.initializeColumnSelector ENTER: >>");
            var view = this;
            this._instance.mandatoryColumns = this.context.options.instanceMode.get("value") ? taskUtils.DEFAULT_MANDATORY_INSTANCE_COLUMNS : taskUtils.DEFAULT_MANDATORY_COLUMNS;
            var columns;
            var isPXServer = view.context.isWorkflowPXServer && view.context.isWorkflowPXServer() === true, 
            	isCaseSupported = view.context.isCaseSupported && view.context.isCaseSupported() === true;
            this._instance.selectedCols = [];
            this._instance.defaultCols = [];
            columns = this.context.options.instanceMode.get("value") ? taskUtils.DEFAULT_FEDERATED_INSTANCE_COLUMNS : taskUtils.DEFAULT_SELECTED_COLUMNS;
            var i;
            for(i = 0; i < columns.length; i++){
                var column = columns[i];
                if(column) {
                    if(this.context.options.instanceMode.get("value")){
                        var obj = {name: column, value: taskUtils.getLabelFromInstanceProperty(column)};
                        if(taskUtils.getInstanceSystemDataDescription(column)){
                            obj.description = taskUtils.getInstanceSystemDataDescription(column);
                        }else{
                            obj.description = obj.value;
                        }
                        this._instance.defaultCols.push({name: column, value: taskUtils.getLabelFromInstanceProperty(column)});
                        resetColumns === true && this._instance.selectedCols.push({name: column, value: taskUtils.getLabelFromInstanceProperty(column)});

                    }else{
                        var obj = {name: column, value: taskUtils.getLabelFromTaskProperty(column)};
                        if(taskUtils.getTaskSystemDataDescription(column)){
                            obj.description = taskUtils.getTaskSystemDataDescription(column);
                        }else{
                            obj.description = obj.value;
                        }
                        this._instance.defaultCols.push(obj);
                        resetColumns === true && this._instance.selectedCols.push(obj);
                    }
                }
            }

            if(!resetColumns === true) {
                columns = this.getOption("columns");
                if(columns.length() > 0) {
                    this._instance.selectedCols = columns.toJSObject().items;
                }
            }
            if(this.context.options.instanceMode.get("value")){
                wpResources.searches.getInstanceMetaFields().then(function(systemData) {
                    wpResources.searches.getInstanceMetaBusinessDataFields().then(function(businessData) {
                        view._instance.systemData = taskUtils.processColumns(systemData, taskUtils.getFieldsToHide(isPXServer || !isCaseSupported, true), true);
                        view._instance.businessData = taskUtils.processBusinessDataColumns(businessData);
                        view._instance.columnSelector.setColumns(view._instance.systemData, view._instance.businessData, view._instance.mandatoryColumns , view._instance.selectedCols, view._instance.defaultCols, true);
                        view._instance.columnSelector.context.binding.set("value", view._instance.selectedCols);
                        view._instance.columnSelector.changeSelectedColumns(false, false);
                    });
                });      
                
            }else{
                wpResources.searches.getMetaFields()
                .then(function(systemData) {
                    wpResources.searches.getMetaBusinessDataFields()
                        .then(function(businessData) {
                            view._instance.systemData = taskUtils.processColumns(systemData, taskUtils.getFieldsToHide(isPXServer || !isCaseSupported, false));
                            view._instance.businessData = taskUtils.processBusinessDataColumns(businessData);
                            view._instance.columnSelector.setColumns(view._instance.systemData, view._instance.businessData, view._instance.mandatoryColumns, view._instance.selectedCols, view._instance.defaultCols, true);
                            view._instance.columnSelector.context.binding.set("value", view._instance.selectedCols);
                            view._instance.columnSelector.changeSelectedColumns(false, false);
                        });
                    }
                );
            }
        };
        /**
         * @instance
         * @memberof SavedSearchBuilder
         * @method clearAllFields
         * @desc Clears all fields in the dialog
         */
        this.constructor.prototype.clearAllFields = function clearAllFields(runDefaultSearch) {
            bpmext.log.info("SavedSearchBuilder.clearAllFields ENTER: >>");
            //Clear scope
            this._instance.scopeCheckbox.setChecked(false);
            this._instance.shareCB.setChecked(false);
            //Clear search filter
            this._instance.searchFilter.resetFilter(this._instance.searchFilter);
            //Set column selector to initialized fields but needed to be called earlier for instance SS
            this.initializeColumnSelector(runDefaultSearch);
            if(this.context.options.instanceMode.get("value")){
                this._instance.nameText.setText("");
                this._instance.organizeBySelector.setSelectedItem("byTask");
                this._instance.shareCB.setChecked(false);
                this._instance.shareCB.setVisible(false,true);
                this._instance.shareCB.setEnabled(false);
                this._instance.teamTypeAhead.setText("");
                this._instance.teamTypeAhead.setVisible(false,true);
                this._instance.teamTypeAhead.setEnabled(false);
                this._instance.columnSorter.clearSort();
                this._instance.saveNewCB.setChecked(false);
                this._instance.saveAsNewLayout.setVisible(false, true);
                this._instance.deleteButton.setVisible(false, true);
            } else if(runDefaultSearch){ // instance search filter doesn't support saved search right now
                if(this._instance.isNextTaskMode) {
                    taskUtils.EVENTS.SET_NEXT_TASK_MODE.publish({isNextTaskMode: true, autoClaimNextTask: this._instance.autoClaimNextTask});
                    if (this._instance.defaultNextTaskSavedSearch) {
                        taskUtils.EVENTS.LOAD_DEFAULT_SAVED_SEARCH.publish({search: this._instance.defaultNextTaskSavedSearch});
                    } else {
                        this._proto._getPermissions(this);
                    }
                } else {
                    //Reset the view based on permissions
                    this._proto._getPermissions(this);
                }
            }
        };

         /**
         * @instance
         * @memberof SavedSearchBuilder
         * @method updateTaskListNumberOfTask
         * @desc broadcast event to tasklist to update its number of task to be displayed
         */
        this.constructor.prototype.updateTaskListNumberOfTask = function updateTaskListNumberOfTask(numberOfTask) {
            bpmext.log.info("SavedSearchBuilder.updateTaskListNumberOfTask ENTER: >>");

            taskUtils.EVENTS.NUMBER_OF_TASK_CHANGED.publish(numberOfTask);
        };

         /**
         * @instance
         * @memberof SavedSearchBuilder
         * @method showSaveAsNewLayout
         * @desc Toggles the visibility of save as new layout
         */
        this.constructor.prototype.showSaveAsNewLayout = function showSaveAsNewLayout() {
            bpmext.log.info("SavedSearchBuilder.showSaveAsNewLayout ENTER: >>");
            var view = this;
            this._instance.saveAsNewLayout.setVisible(this._instance.saveNewCB.isChecked(), true);
            if(!this._instance.saveNewCB.isChecked()){
                this._instance.nameText.setText("");
            } else {
                this._instance.saveAsNewLayout.context.element.scrollIntoView();
                this._instance.nameText.focus();
            }
            this._proto._checkUserRightsChanged(this).then(function(whatChanged) {
                var isUserSavedSearch = view._proto._isUserOwnedSavedSearch(view, view._instance.searchId);
                if(!whatChanged.currentAdminRight){
                    if(view._instance.searchId && !isUserSavedSearch && (whatChanged.currentCreateShareRight || whatChanged.currentCreateRight || !whatChanged.currentRunOnlyRight)){
                        taskUtils.EVENTS.SLIDEOUT_SET_PRIMARY_BTN.publish({visible: view._instance.saveNewCB.isChecked()});
                    }
                }
            });

            this.updateSaveButton();
            if(this._instance.saveNewCB.isChecked()){
                this._instance.nameText.setValid(true);
            }
        };

        /**
         * @instance
         * @memberof SavedSearchBuilder
         * @method deleteCurrentSavedSearch
         * @desc Deletes the current saved search in the builder
         */
        this.constructor.prototype.deleteCurrentSavedSearch = function deleteCurrentSavedSearch() {
            bpmext.log.info("SavedSearchBuilder.deleteCurrentSavedSearch ENTER: >>");
            var view = this;
            this._proto._checkUserRightsChanged(this).then(function(whatChanged) {
                var isUserSavedSearch = view._proto._isUserOwnedSavedSearch(view, view._instance.searchId);
                if((whatChanged.currentAdminRight)|| (whatChanged.currentCreateShareRight && isUserSavedSearch) || (whatChanged.currentCreateRight && isUserSavedSearch) || (!whatChanged.currentRunOnlyRight && isUserSavedSearch)) {
                    taskUtils.EVENTS.DELETE_SAVED_SEARCH.publish({search:view._instance.searchId, display:view._instance.currentSearch.name});
                }
            });
        };

        this.constructor.prototype.onSearchLaunch = function onSearchLaunch(view) {
            if(view.getSelectedIndex() < 1){
                this._proto._resetFields(this);
            }
        };

        /**
         * @instance
         * @memberof SavedSearchBuilder
         * @method clearButtonHandler
         * @desc Handler for clear button
         */
        this.constructor.prototype.clearButtonHandler = function clearButtonHandler() {
            bpmext.log.info("SavedSearchBuilder.clearButtonHandler ENTER: >>");

            this._proto._resetFields(this, true);

            return false;
        };

        /**
         * @instance
         * @memberof SavedSearchBuilder
         * @method typeaheadHandler
         * @desc handler for typeahead
         */
        this.constructor.prototype.typeaheadHandler = function typeaheadHandler() {
            bpmext.log.info("SavedSearchBuilder.typeaheadHandler ENTER: >>");
            this._instance.currentTeam = this._instance.teamTypeAhead.getText();
            this.updateSaveButton();
        };

        this.constructor.prototype.setPanelOptions = function setPanelOptions() {
            if(this.context.options.instanceMode.get("value")){
                this._instance.MODAL_OPTIONS = {
                    title: "INSTANCE FILTER!",
                    subtitle: "INSTANCE!!!",
                    secondaryBtnText: bpmext.localization.formatMsg("savedSearchBuilder", "hide"),
                    secondaryBtnEvent: {method: dojo.hitch(this, this.closeSavedSearch), args: true, closeOnEvtComplete: true},
                    onPanelClose: {},//"Not used"
                    progressBarOptions:{progressBarSteps:[], currentStep:1},
                    width: window.innerWidth > 700 ? ((700 / window.innerWidth) * 100 + "%") : "100%",
                };
            }else{
                this._instance.MODAL_OPTIONS = {
        			title: bpmext.localization.formatMsg("savedSearchBuilder", "savedSearchTitle"),
                	subtitle: bpmext.localization.formatMsg("savedSearchBuilder", "savedSearchSubtitle"),
                	primaryBtnText: bpmext.localization.formatMsg("savedSearchBuilder", "save"),
                	secondaryBtnText: bpmext.localization.formatMsg("savedSearchBuilder", "hide"),
                	primaryBtnEvent: {method: dojo.hitch(this, this.saveSavedSearch), args: null, closeOnEvtComplete: true},
                	secondaryBtnEvent: {method: dojo.hitch(this, this.closeSavedSearch), args: true, closeOnEvtComplete: true},
                	onPanelShow: {method: dojo.hitch(this, this.validateSaveSearch), args: false, closeOnEvtComplete: false},
                	onPanelClose: {},//"Not used"
                	width: window.innerWidth > 700 ? ((700 / window.innerWidth) * 100 + "%") : "100%",
                	viewFrom: "Saved search"
            	};
            } 
        };
        /**
         * @instance
         * @memberof SavedSearchBuilder
         * @method scopeCheckboxhandler
         * @desc handler for scope checkbox
         */
        this.constructor.prototype.scopeCheckboxhandler = function scopeCheckboxhandler() {
            if(this._instance.scopeCheckbox.isChecked()){
                this._instance.scopeFilter.showScopeFilter();
            }else{
                this._instance.scopeFilter.resetFilter(this._instance.scopeFilter);
                this._instance.scopeFilter.setVisible(false, true);
                taskUtils.EVENTS.SET_SAVED_SEARCH_SCOPE.publish({filterCondition:[]});
            }
        };
        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function ()
        {
            bpmext.log.info("SavedSearchBuilder.load ENTER >>", this);

            var view = this, opts = this.context.options, messages = bpmext.localization;

            if (!this.context.binding) {
                this.context.binding = bpmext.ui.substituteObject(this, "binding", "search", {});
            }

            if (!opts.columns) {
                bpmext.ui.substituteConfigOption(this, "columns", []);
            }

            if (!opts.listOfNumberOfOptions) {
                var defaultList = [1,2,3,4,40].map(function(factor){
                    return wpResources.tasks.get.default_size*factor;
                });
                bpmext.ui.substituteConfigOption(this, "listOfNumberOfOptions", defaultList);
            }

            if(!opts.instanceMode) {
                bpmext.ui.substituteConfigOption(this, "instanceMode", false);
            }

            if(!opts.searchFilters) {
                bpmext.ui.substituteConfigOption(this, "searchFilters", null);
            }

            if(!opts.taskSortBy) {
                bpmext.ui.substituteConfigOption(this, "taskSortBy", null);
            }

            //Get Sibling TaskList
            this._instance.taskList = bpmext.ui.getContainer("/Task_List1");

            //Filter
            this._instance.searchFilter = bpmext.ui.getView("SearchFilter", this);
            this._instance.searchFilterPanel = bpmext.ui.getContainer("SearchFilterPanel", this);
            this._instance.searchFilterPanel.context.element.firstElementChild.setAttribute("role", "form")
            this._instance.searchFilterPanel.context.element.firstElementChild.setAttribute("aria-label", messages.formatMsg("savedSearchBuilder", "searchFilterTitle"))

            // Sort Columns
            this._instance.sortPanel = bpmext.ui.getContainer("SortPanel",this);
            this._instance.columnSorter = bpmext.ui.getView("SearchSortFilter", this);

            //Columns
            this._instance.columnSelectorPanel = bpmext.ui.getContainer("ColumnSelectorPanel",this);
            this._instance.columnSelector = bpmext.ui.getView("ColumnSelector", this);
            this._instance.columnSelector.setAlwaysShow(true);
            this._instance.columnSelectorPanel.context.element.firstElementChild.setAttribute("role", "form")
            this._instance.columnSelectorPanel.context.element.firstElementChild.setAttribute("aria-label", messages.formatMsg("savedSearchBuilder", "columnSelectorTitle"));

            //Advanced Options
            this._instance.nameText = bpmext.ui.getView("NameText", this);
            //turn off the autocomplete
            var input = this._instance.nameText.context.element.querySelector("input");
            if (input) {
                domAttr.set(input, "autocomplete", "off");
            }

            if(opts.taskSortBy.get("value") && opts.taskSortBy.get("value").name !== ""){
                var taskSort = opts.taskSortBy.get("value").toJSObject();
                this._instance.currentSort = [{field: taskSort.name, order: taskSort.value === "descending" ? "DESC" : "ASC"}];
            } else {
                if(opts.instanceMode.get("value")){
                    this._instance.currentSort = [{field: "instanceDueDate", order: "ASC"}];
                }else{
                    this._instance.currentSort = [{field: "taskDueDate", order: "ASC"}];
                }
            }

            this._instance.organizeBySelector = bpmext.ui.getView("OrganizeBySelector", this);
            this._instance.shareCB = bpmext.ui.getView("ShareCB", this);
            this._instance.teamTypeAhead = bpmext.ui.getView("TeamTypeAhead", this);

            this._instance.saveNewCB = bpmext.ui.getView("saveNewCB", this);
            this._instance.saveAsNewLayout = bpmext.ui.getContainer("saveAsNewLayout", this);
            this._instance.deleteButton = bpmext.ui.getView("deleteButton", this);
            this._instance.clearButton = bpmext.ui.getView("clearButton", this);

            this._instance.saveSearchListTitle = bpmext.ui.getContainer("Panel1", this);

            this._instance.scopeView = bpmext.ui.getContainer("scopePanel", this);
            this._instance.scopeFilter =  bpmext.ui.getView("scopeFilter", this);
            this._instance.scopeCheckbox = bpmext.ui.getView("scopeCheckbox", this);
            this._instance.scopeCheckbox.setLabel(messages.formatMsg("savedSearchBuilder","scopeFilterCheckbox"))
            
            this._instance.scopeFilter.resetFilter(this._instance.scopeFilter);
            this._instance.scopeFilter.setVisible(false, true);

            if(opts.instanceMode.get("value")){
                this._instance.scopeView.setVisible(false, true);
            }

            //Populate Messages
            this._instance.nameText.setLabel(messages.formatMsg("savedSearchBuilder", "name"));
            this._instance.organizeBySelector.setLabel(messages.formatMsg("savedSearchBuilder", "organizeBy"));
            this._instance.shareCB.setLabel(messages.formatMsg("savedSearchBuilder", "shareWithTeam"));
            this._instance.teamTypeAhead.setPlaceholder(messages.formatMsg("savedSearchBuilder", "teamTypeAheadPlaceholder"));
            this._instance.teamTypeAhead._instance.typeahead.menuNode.setAttribute("aria-label", messages.formatMsg("savedSearchBuilder", "teamTypeAheadMenuLabel"));

            //Populate Organize By Selector
            this._instance.organizeBySelector.appendItem( "byTask", "Task");
            this._instance.organizeBySelector.appendItem( "byInstance", "Process");
            this._instance.organizeBySelector.setSelectedItem("byTask");
            //Hide this "Organize By" selector, since PFS does not support "By Process" yet
            this._instance.organizeBySelector.setVisible(false, true);

            this._instance.saveNewCB.setLabel(messages.formatMsg("savedSearchBuilder","saveNewSearchTitle"));
            this._instance.clearButton.setText(bpmext.localization.formatMsg("savedSearchBuilder", "clear"));
            
            var initColumns = false, refreshHandler;

            if(opts.instanceMode.get("value")){
                this._instance.shareCB.setVisible(false, true);
                this._instance.saveNewCB.setVisible(false, true);
                this._instance.deleteButton.setVisible(false, true);
                this._instance.columnSelector.setInstanceMode(true);
                this._instance.columnSorter.setInstanceMode(true);
                this._instance.searchFilter.context.options.instanceFilter.set("value", true);
            }else{
                this._instance.columnSorter.setInstanceMode(false);
            }
            if(this.getOption("columns").length() === 0) {
                initColumns = true;
            }
            this.initializeColumnSelector(initColumns);

            refreshHandler = function refreshHandler() { this.hide(true); };

            taskUtils.EVENTS.TASK_SHOWING_IN_VIEWER.subscribe(refreshHandler, this);
            taskUtils.EVENTS.SERVICE_SHOWING_IN_VIEWER.subscribe(refreshHandler, this);
            taskUtils.EVENTS.VIEW_INSTANCE.subscribe(refreshHandler, this);

            this.setPanelOptions();

            if(!this.getOption("instanceMode") && this.getOption("searchFilters")){
                var isPXServer = view.context.isWorkflowPXServer && view.context.isWorkflowPXServer() === true;
                var filter = dojo.clone(this.getOption("searchFilters")), defaultScopeFilters = isPXServer ? taskUtils.DEFAULT_PX_SCOPE_FILTERS : taskUtils.DEFAULT_SCOPE_FILTERS;
                if(filter){
                    for(var x=0; x<filter.length(); x++){
                        if(defaultScopeFilters.indexOf(filter.items[x].field)>-1){
                            this._instance.scopeCheckbox.setChecked(true);
                            taskUtils.EVENTS.SET_SAVED_SEARCH_SCOPE.publish({filterCondition:[filter.items[x]]})
                            setTimeout(function(){
                                view._instance.scopeFilter.setCurrentFilter([filter.items[x]]);
                            },100)
                            break;
                        }
                    }
                }
            }

            this.loadContainer(this);
            taskUtils.EVENTS.SAVED_SEARCH_LAUNCHED.subscribe(function(eventName, eventData){
                if(!view.context.options.instanceMode.get("value")){
                    var id = eventData.search.ID || eventData.search.id;
                    view.clearAllFields(!id);
                    view._instance.searchId = id;
                    view._instance.searchName = eventData.search.name? eventData.search.name: eventData.search.display;
                    if(eventData.search){
                        view.getPermissions();
                    }
                }
            }, this);
            taskUtils.EVENTS.CREATE_SAVED_SEARCH.subscribe(function(){
                view._instance.searchId = "";
                if(view._instance.userOwnedSaveSearches == null || (view._instance.userOwnedSaveSearches && view._instance.userOwnedSaveSearches.length == 0)){
                    taskUtils.EVENTS.LOAD_MODAL.publish({modal:"Saved search", showModal:true});
                    // Accessibility
                    var checkLoaded = setInterval(function () { 
                        if (view.ui.getParent()._instance.spinner && !view.ui.getParent()._instance.spinner.isVisible()) {
                            taskUtils.setTabCycle(view);
                            clearInterval(checkLoaded);
                        }
                    }, 100);
                }
                view.getPermissions();
                view.setPanelOptions();
                taskUtils.EVENTS.LOAD_STACK_PANE.publish({targetView:view.context.viewid});
                view._instance.columnSorter.show();
                view.setVisible(true, true);
            }, this);
            taskUtils.EVENTS.EDIT_SAVED_SEARCH.subscribe(function(eventName, eventData){
                if(view._instance.userOwnedSaveSearches == null || (view._instance.userOwnedSaveSearches && view._instance.userOwnedSaveSearches.length == 0)){
                    taskUtils.EVENTS.LOAD_MODAL.publish({modal:"Saved search", showModal:true});
                    return;
                }
                if(eventData.search){
                    view.setPanelOptions();
                    taskUtils.EVENTS.LOAD_STACK_PANE.publish({targetView:view.context.viewid});
                    view.setVisible(true, true)
                }
            }, this);
            taskUtils.EVENTS.SAVED_SEARCH_DELETED.subscribe(function(){
                view._instance.searchId = "";
                this._proto._resetFields(this, true);
            }, this);
            taskUtils.EVENTS.SLIDEOUT_PANEL_CLOSE.subscribe(function(){
                view.closeSavedSearch();
            }, this);

            taskUtils.EVENTS.CLEAR_TASK_FIELDS.subscribe(function(){
				view.clearAllFields(true);
			}, this);
            taskUtils.EVENTS.SORT_TASKLIST.subscribe(function(eventName, eventData){
                var order = eventData.order === "descending" ? "DESC" : "ASC";
                view._instance.currentSort = [{field: eventData.field, order: order}];
            }, this);
            taskUtils.EVENTS.CHANGE_SORT_FILTER.subscribe(function(eventName, eventData){
                if(!view.context.options.instanceMode.get("value")){
                    var order = eventData.order === "DESC" ? "DESC" : "ASC";
                    view._instance.currentSort = [{field: eventData.field, order: order}];
                }
            }, this);
            taskUtils.EVENTS.SET_SAVED_SEARCH_SCOPE.subscribe(function(eventName, eventData){
                wpResources.searches.getMetaFields().then(function(systemData) {
                    wpResources.searches.getMetaBusinessDataFields().then(function(businessData) {
                            var selCols = [];
                            var columns = eventData.selectedCols || view._instance.selectedCols;
                            var i;
                            for(i = 0; i < columns.length; i++){
                                var column = columns[i];
                                if(column) {
                                    if (column.indexOf("@") !== -1){
                                        column = column.slice(0, column.indexOf("@"));
                                    }
                                    var obj = {name: column, value: taskUtils.getLabelFromTaskProperty(column)};
                                    if(taskUtils.getTaskSystemDataDescription(column)){
                                        obj.description = taskUtils.getTaskSystemDataDescription(column);
                                    }else{
                                        obj.description = obj.value;
                                    }
                                    selCols.push(obj);
                                }
                            }
                            var isPXServer = view.context.isWorkflowPXServer && view.context.isWorkflowPXServer() === true,
                            	isCaseSupported = view.context.isCaseSupported && view.context.isCaseSupported() === true;
                            var sysCols = taskUtils.processColumns(systemData, taskUtils.getFieldsToHide(isPXServer || !isCaseSupported, false));
                            var busCols = taskUtils.processBusinessDataColumns(businessData);
                            var mandCols = taskUtils.DEFAULT_MANDATORY_COLUMNS;
                            var scopedBusCols = [];
                            var selectedScope = eventData.filterCondition;
                            for(var y =0; y < busCols.length; y++){
                                var found = false;
                                if(selectedScope.length>0){
                                    for(var z=0; z < busCols[y].origins.length; z++){
                                        switch(selectedScope[0].field){
                                            case "bpdName":{
                                                if(busCols[y].origins[z].processName.trim().toLowerCase().includes(selectedScope[0].value.trim().toLowerCase())){
                                                    scopedBusCols.push(busCols[y]);
                                                    found = true;
                                                }
                                            }
                                            case "instanceProcessApp":{
                                                if(busCols[y].origins[z].projectShortName.trim().toLowerCase().includes(selectedScope[0].value.trim().toLowerCase())){
                                                    scopedBusCols.push(busCols[y]);
                                                    found = true;
                                                }
                                            }
                                        }
                                        if(found){
                                            break;
                                        }
                                    }
                                }
                            }
                            if(selectedScope.length>0 && (selectedScope[0].field == "bpdName" || selectedScope[0].field == "instanceProcessApp") && !!selectedScope[0].value && busCols.length>0){
                                view._instance.searchFilter.setBusinessData(scopedBusCols);
                                view._instance.columnSelector.setColumns(sysCols, scopedBusCols, mandCols, selCols, selCols, true);
                            }else{
                                view._instance.searchFilter.setBusinessData(busCols);
                                view._instance.columnSelector.setColumns(sysCols, busCols, mandCols, selCols, selCols, true);
                            }
                        });
                    }
                );
                
            }, this);

            bpmext.log.info("SavedSearchBuilder.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try
            {
                utilities.handleVisibility(this.context);
            }
            catch (e)
            {
                //{#feature: US-1330 Added RT localization}
                //bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e, this);
                if(e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    //bpmext.log.error("  Call stack: " + e.stack);
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack), this);
                }
            }
        };

        this.constructor.prototype.change = function (event)
        {
            bpmext.log.info("SavedSearchBuilder.change ENTER >> (event): " + event, this);
            bpmext.log.info("SavedSearchBuilder.change ENTER >>", this);
        };

        this.constructor.prototype.unload = function ()
        {
            bpmext.ui.unloadContainer(this);
        };
    }
};