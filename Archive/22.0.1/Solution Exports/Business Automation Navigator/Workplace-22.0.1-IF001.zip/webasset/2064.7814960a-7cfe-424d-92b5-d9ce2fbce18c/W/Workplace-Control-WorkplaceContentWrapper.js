/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof WorkplaceContentWrapper
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof WorkplaceContentWrapper
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof WorkplaceContentWrapper
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof WorkplaceContentWrapper
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof WorkplaceContentWrapper
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof WorkplaceContentWrapper
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof WorkplaceContentWrapper
 * @method triggerFormulaUpdates
 */

workplace_control_WorkplaceContentWrapper = function (utilities, taskUtils, wpResources) {
    "use strict";
    this._instance = {
        defaultTimeout: 6000
    };

    if (!this.constructor.prototype._proto) {
        this.constructor.prototype._proto = {};

        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function () {
            bpmext.log.info("WorkplaceContentWrapper.load ENTER >>", this);

            /******* handler for notifications *****/
            var _this = this;
            var notificationsHandler = function notificationsHandler(eventName, eventData) {
                var notificationsView,
                    notificationTitle,
                    notificationText,
                    groupName,
                    taskName,
                    timeout = _this._instance.defaultTimeout,
                    formatMsg = bpmext.localization.formatMsg;

                if (eventData.task) {
                    taskName = eventData.task.displayName || eventData.task.name;
                }

                notificationsView = _this.ui.get("Notifications");
                if (taskName) {
                    if (eventData.kind === "TASK_RESOURCE_ASSIGNED") {
                        wpResources.user.get().then(function (currentUser) {
                            notificationTitle = formatMsg("notifications", "notificationTitle") + ":";
                            if (eventData.task.resource.type === "ROLE") {
                                groupName = eventData.task.resource.displayName;
                                if (groupName && (currentUser.memberships || []).indexOf(groupName) !== -1) {
                                    notificationText = formatMsg("notifications", "groupReceivedNewTask", groupName, taskName);
                                    notificationsView.appendAlert(notificationTitle, notificationText, "I", timeout);
                                } else {
                                    try {
                                        throw new Error("Group Name does not exit.");
                                    } catch (e) {
                                        bpmext.log.error("WorkplaceContentWrapper notificationsHandler Error >>", e.stack);
                                    }
                                }
                            } else if (
                                eventData.task.resource.type === "USER" &&
                                eventData.task.resource.id === currentUser.userName
                            ) {
                                notificationText = formatMsg("notifications", "userReceivedNewTask", taskName);
                                notificationsView.appendAlert(notificationTitle, notificationText, "I", timeout);
                            }
                        });
                    }
                } else if (eventData.msg) {
                    notificationsView.appendAlert("", eventData.msg, "I", timeout);
                } else {
                    try {
                        throw new Error("Task Name does not exit.");
                    } catch (e) {
                        bpmext.log.error("WorkplaceContentWrapper notificationsHandler Error >>", e.stack);
                    }
                }
            };

            /**
             * @param {string} eventName
             * @param {string} [data.title = bpmext.localization.formatMsg("notifications", "notificationTitle")]
             * @param {string} [data.text = ""]
             * @param {"S"|"I"|"P"|"W"|"D"} [data.style = "P"]
             * @param {number} [data.timeout = _this._instance.defaultTimeout]
             */
            var createToast = function createToast(eventName, data) {
                if (!data) {
                    data = {};
                }
                var notificationsView = _this.ui.get("Notifications");
                notificationsView.appendAlert(
                    data.title || bpmext.localization.formatMsg("notifications", "notificationTitle"),
                    data.text || "",
                    data.style || "P",
                    data.timeout || _this._instance.defaultTimeout
                );
            };

            taskUtils.EVENTS.NOTIFICATION_TASK_RESOURCE_ASSIGNED.subscribe(notificationsHandler, this);
            taskUtils.EVENTS.NOTIFICATION_PROCESS_STARTED.subscribe(notificationsHandler, this);
            taskUtils.EVENTS.CREATE_TOAST.subscribe(createToast, this);
           
            this.loadContainer(this);

            bpmext.log.info("WorkplaceContentWrapper.load EXIT >>", this);
        };

        this.constructor.prototype.view = function () {
            try {
                utilities.handleVisibility(this.context);
            } catch (e) {
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e, this);
                if (e.stack) {
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack), this);
                }
            }
        };

        this.constructor.prototype.change = function (event) {
            bpmext.log.info("WorkplaceContentWrapper.change ENTER >> (event): " + event, this);
            bpmext.log.info("WorkplaceContentWrapper.change ENTER >>", this);
        };

        this.constructor.prototype.unload = function () {
            bpmext.log.info("WorkplaceContentWrapper.unload ENTER >> ", this);
            bpmext.ui.unloadContainer(this);
            bpmext.log.info("WorkplaceContentWrapper.unload ENTER >>", this);
        };
    }
};
