/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof TaskStatistics
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof TaskStatistics
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof TaskStatistics
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof TaskStatistics
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof TaskStatistics
 * @method setData
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   
 *   <tr class=Prop>
 *       <td>On filter button clicked:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when a filter button is clicked.</td>
 *               </tr>
 *           </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">Description</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">filter {object}</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">{filter {[text]}, text: {text}}</td>
 *               </tr>
 *       </table>
 *     </td>
 *   </tr>
 * </table>
 */
workplace_control_InitTaskStatistics = function (utilities, domClass, domConstruct, taskUtils, wpResources)
{
    "use strict";
    this._instance =
    {
    };
    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            EVT_FILTERBTN_ONCLICK: "eventON_FILTERBTN_CLICKED",
            TERMS: {
                OVERDUE: {status: "overdue", class: "overdueTask", text: bpmext.localization.formatMsg("controlTaskList", "taskOverdue")},
                ATRISK: {status: "atRisk", class: "atRiskTask", text: bpmext.localization.formatMsg("controlTaskList", "taskAtRisk")},
                ONTRACK: {status: "onTrack", class: "onTrackTask", text: bpmext.localization.formatMsg("controlTaskList", "taskOnTrack")},
                // COMPLETED: {status: "completed", class: "completedTask", text: bpmext.localization.formatMsg("controlTaskList", "taskCompleted")},
                TOTAL: {status: "total", class: "totalTask", text: bpmext.localization.formatMsg("controlTaskList", "taskTotal")},
                TOTALINSTANCE: {status: "total", class: "totalInstance", text: bpmext.localization.formatMsg("controlTaskList", "instanceTotal")},
                // ACTIVE: {status: "active", class: "activeInstance", text: bpmext.localization.formatMsg("instanceList", "active")},
                FAILED: {status: "failed", class: "failedInstance", text: bpmext.localization.formatMsg("instanceList", "failed")},
                TERMINATED: {status: "terminated", class: "terminatedInstance", text: bpmext.localization.formatMsg("searchFilter", "terminated")},
                SUSPENDED: {status: "suspended", class: "suspendedInstance", text: bpmext.localization.formatMsg("searchFilter", "suspended")},
                ASSIGNED: {status: "assigned", class: "onTrackTask", text: bpmext.localization.formatMsg("controlTaskList", "taskAssigned")},
                COMPLETETODAY: {status: "completeToday", class: "completedTask", text: bpmext.localization.formatMsg("controlTaskList", "taskCompletedToday")}
            },
            // TERMS_ORDER: ["ONTRACK", "ATRISK", "OVERDUE", "COMPLETED", "ASSIGNED", "ACTIVE", "FAILED", "SUSPENDED", "TERMINATED", "COMPLETETODAY", "TOTAL"],
            TERMS_ORDER: ["ONTRACK", "ATRISK", "OVERDUE", "ASSIGNED", "FAILED", "SUSPENDED", "TERMINATED", "COMPLETETODAY", "TOTAL"],

            MIN_REFRESH_INTERVAL: 5000, //5 seconds

            /********** CONSTRUCT FILTER NODE ACCORDINGLY START **********/
            _buildNodes: function _buildNodes(view) {
                var displayingTerms = view._proto._getDisplayingTerms(view);
                view._instance.currentTerms = (displayingTerms || []).map(function(term) {
                    var node = view._proto._constructNode(view, term);
                    domConstruct.place(node, view._instance.container);

                    return {
                        status: term.status,
                        node: node
                    };
                });
            },

            _getDisplayingTerms: function _getDisplayingTerms(view) {
                var terms = [];

                if (view.context.binding) {
					var currentStats =  view.context.binding.get("value").stats;
                    var showIfZero = view.getConfigShowAll();
                    var showTotalOnly = view.getShowTotalOnly();

                    if (!showTotalOnly) {
                        view._proto.TERMS_ORDER.forEach(function(termName) {
                            Object.keys(currentStats).forEach(function(term) {
                                if(termName === term.toUpperCase()) {
                                    if (currentStats[term] === null || (!showIfZero && currentStats[term] === 0)) {
                                        return;
                                    }
                                    terms.push(view._proto.TERMS[termName]);
                                    return;
                                }
                            });
                        });
                    } else {
                        terms.push(view._proto.TERMS.TOTAL);
                    }
                }

                return terms;
            },

            _constructNode: function _constructNode(view, term) {
                var node = domConstruct.create("div", {
                    "class": "taskStatistics taskStats" + " " + term.class,
                    "role": "button",
                    "tabindex": "0"
                });

                var statsTitle = domConstruct.toDom("<div class='taskStatistics taskStatsText'></div>");
                var statsNumber = domConstruct.toDom("<div class='taskStatistics taskStatsNumber'></div>");
                var taskStatsIconWrapper = domConstruct.toDom("<div class='taskStatsIconWrapper'></div>");
                domConstruct.place(statsTitle, node);
                domConstruct.place(statsNumber, node);
                domConstruct.place(taskStatsIconWrapper, node);

                if (term.status !== "total") {
                    var status = term.status;
                    if (status === view._proto.TERMS.COMPLETETODAY.status) {
                        status = view._proto.TERMS.COMPLETED.status;
                    } else if (status === view._proto.TERMS.ASSIGNED.status) {
                        status = view._proto.TERMS.ONTRACK.status;
                    }

                    var taskStatsIcon = domConstruct.toDom("<img src='" + com_ibm_bpm_coach.getManagedAssetUrl("status_" + status +".png", com_ibm_bpm_coach.assetType_WEB,"SYSWPT") +"' alt=''></img>");
                    domConstruct.place(taskStatsIcon, taskStatsIconWrapper);
                }

                statsTitle.innerText = term.text;

                var eventsHandler = function (event) {
                    view._proto._nodeEventsHandler(view, term, event);
                };

                node.addEventListener("click", eventsHandler, true);
                node.addEventListener("keyup", eventsHandler, true);

                return node;
            },

            _nodeEventsHandler: function _nodeEventsHandler(view, term, event) {
                switch (event.type) {
                    case "keyup": {
                        if (event.key !== "Enter" && (event.key !== " " || event.key !== "Spacebar")) {
                            break;
                        }
                    }
                    // falls through
                    case "click": {
                        if (view.isEventTriggeredFilterAction()) {
                            bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_FILTERBTN_ONCLICK, {filter: term.status, text: term.text});
                        } else {
                            view._instance.filterSelected = true;

                            var now = new Date().toISOString();
                            var filter=[], length = 1;
                            var termText = "";
                            // var filter = [wpResources.tasks.OPERATOR.EQUALS("interaction", wpResources.tasks.INTERACTION.CLAIMED_AND_AVAILABLE)];
                            // var length = 1;
                            if (term.status === "overdue") {
                                termText = view._proto.TERMS.OVERDUE.text;
                                if(!view._instance.instanceMode){
                                    filter.push(wpResources.tasks.OPERATOR.LESS_THAN("taskDueDate", now));
                                }else{
                                    filter.push(wpResources.tasks.OPERATOR.EQUALS("INSTANCE_RISK_STATE", "Overdue"));
                                }
                                length++;
                            } else if (term.status === "atRisk") {
                                termText = view._proto.TERMS.ATRISK.text;
                                if(!view._instance.instanceMode){
                                    filter.push(wpResources.tasks.OPERATOR.GREATER_THAN("taskDueDate", now));
                                    filter.push(wpResources.tasks.OPERATOR.LESS_THAN("taskAtRiskTime", now));
                                }else{
                                    filter.push(wpResources.tasks.OPERATOR.EQUALS("INSTANCE_RISK_STATE", "AtRisk"));
                                }
                                length++;
                            } else if (term.status === "onTrack") {
                                termText = view._proto.TERMS.ONTRACK.text;
                                if(!view._instance.instanceMode){
                                    filter.push(wpResources.tasks.OPERATOR.GREATER_THAN("taskDueDate", now));
                                    filter.push(wpResources.tasks.OPERATOR.GREATER_THAN("taskAtRiskTime", now));
                                }else{
                                    filter.push(wpResources.tasks.OPERATOR.NOT_EQUALS("INSTANCE_RISK_STATE", "Overdue"));
                                    filter.push(wpResources.tasks.OPERATOR.NOT_EQUALS("INSTANCE_RISK_STATE", "AtRisk"));
                                }
                                length++;
                            }
                            view._instance.instanceMode ? taskUtils.EVENTS.SET_INSTANCE_QUICK_FILTER.publish({text:termText}) : taskUtils.EVENTS.SET_QUICK_FILTER.publish({text:termText});
                            if(term.status !== "total"){
                                if(!view._instance.instanceMode){
                                    view._instance.taskActiveFilter = term.status;
                                    taskUtils.EVENTS.MODIFY_TASK_QUICK_FILTER.publish({filterCondition: filter, length: length});
                                }else{
                                    view._instance.instanceActiveFilter = term.status;
                                    taskUtils.EVENTS.MODIFY_INSTANCE_QUICK_FILTER.publish({filterCondition: filter, length: length});
                                }
                            }else{
                                if(!view._instance.instanceMode){
                                    view._instance.taskActiveFilter = null;
                                }else{
                                    view._instance.instanceActiveFilter = null;
                                }
                            }
                        }
                        view._proto._setActiveFilterBtn(view, term.status);
                    }
                }
            },

            _setActiveFilterBtn: function _setActiveFilterBtn(view, activeFilter) {
                if (!view._instance.currentTerms) {
                    return;
                }
                view._instance.currentTerms.forEach(function (term) {
                    if (term.status === activeFilter) {
                        domClass.add(term.node, "active");
                    } else {
                        domClass.remove(term.node, "active");
                    }
                });
            },

            _deactivateAllFilterBtns: function _deactivateAllFilterBtns(view) {
                if (!view._instance.currentTerms) {
                    return;
                }

                view._instance.currentTerms.forEach(function (term) {
                    domClass.remove(term.node, "active");
                });

                if (view.isEventTriggeredFilterAction()) {
                    bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_FILTERBTN_ONCLICK, {filter: ""});
                }
            },

            _changeTotalNodesTitle: function _changeTotalNodesTitle(view) {
                var node = view._instance.currentTerms[view._instance.currentTerms.length-1].node;
                if(view._instance.instanceMode){
                    domClass.replace(node, "taskStatistics taskStats " + view._proto.TERMS.TOTALINSTANCE.status, "taskStatistics taskStats " + view._proto.TERMS.TOTAL.status);
                    node.firstChild.innerHTML = view._proto.TERMS.TOTALINSTANCE.text;
                }else{
                    domClass.replace(node, "taskStatistics taskStats " + view._proto.TERMS.TOTAL.status, "taskStatistics taskStats " + view._proto.TERMS.TOTALINSTANCE.status);
                    node.firstChild.innerHTML = view._proto.TERMS.TOTAL.text;
                }
                
            },
            /********** CONSTRUCT FILTER NODE ACCORDINGLY END **********/



            /********** UPDATE FILTER NODE ACCORDINGLY START **********/
            _updateMainStats: function _updateMainStats(view) {
                if (view.context.binding) {
                    var node, mainStatsNumberEle;
                    var mainStats =  view.context.binding.get("value").stats;

                    if (!view._instance.currentTerms) {
                        view._proto._buildNodes(view);
                    } else if (view._proto._isTermsChanged(view)) {
                        view._proto._resetStatsContainer(view);
                        view._proto._buildNodes(view);
                    }

                    view._instance.currentTerms.forEach(function (term) {
                        node = term.node;
                        mainStatsNumberEle = node.querySelector("div.taskStatsNumber");

                        if (mainStatsNumberEle) {
                            mainStatsNumberEle.innerText = mainStats[term.status] || 0;
                        }
                    });
                    domClass.remove(view.context.element, "skeleton");
                }
            },

            _isTermsChanged: function _isTermsChanged(view) {
                var displayingTerms = view._proto._getDisplayingTerms(view).map(function (term) {
                    return term.status;
                });

                var currentTerms = (view._instance.currentTerms || []).map(function (term) {
                    return term.status;
                });

                if (displayingTerms.length !== currentTerms.length) {
                    return true;
                }

                var i;
                for (i = 0; i < currentTerms.length; i++) {
                    if (displayingTerms.indexOf(currentTerms[i]) < 0) {
                        return true;
                    }
                }

                return false;
            },
            /********** UPDATE FILTER NODE ACCORDINGLY END **********/



            /********** OTHERS START **********/
            _initStatsContainer: function _initStatsContainer(view) {
                view._instance.container = domConstruct.create("div", {className: "wrappedStatsContainer skeleton"}, view.context.element);
            },

            _resetStatsContainer: function _resetStatsContainer(view) {
                if (!view._instance.container) {
                    view._proto._initStatsContainer(view);
                } else {
                    domConstruct.empty(view._instance.container);
                }
                view._instance.currentTerms = [];
            },

            _fetchTaskTotals: function _fetchTaskTotals(view, callback) {

                //limit requests to at most once every MIN_REFRESH_INTERVAL milliseconds
                if (!view._instance.lastTaskRefresh) {
                    //initialize date to the past
                    view._instance.lastTaskRefresh = new Date();
                    view._instance.lastTaskRefresh.setFullYear(2000);
                }
                var now = new Date();
                if((now.getTime() - view._instance.lastTaskRefresh.getTime()) > view._proto.MIN_REFRESH_INTERVAL) {
                    view._instance.lastTaskRefresh = new Date();
                    wpResources.tasks.get({calcStats: true, fields: [], interaction: wpResources.tasks.INTERACTION.CLAIMED_AND_AVAILABLE, size: 500, skipPublish: true}).then(callback);
                }else{
                    view.setStats(view._instance.taskStats);
                }
            },

            _fetchInstanceTotals: function _fetchInstanceTotals(view, callback) {

                //limit requests to at most once every MIN_REFRESH_INTERVAL milliseconds
                if (!view._instance.lastInstanceRefresh) {
                    //initialize date to the past
                    view._instance.lastInstanceRefresh = new Date();
                    view._instance.lastInstanceRefresh.setFullYear(2000);
                }
                var now = new Date();
                if((now.getTime() - view._instance.lastInstanceRefresh.getTime()) > view._proto.MIN_REFRESH_INTERVAL) {
                    view._instance.lastInstanceRefresh = new Date();
                    wpResources.processes.get({calcStats: true, fields: [], interaction: wpResources.processes.INTERACTION.ACTIVE, size: 500}).then(callback);
                }else{
                    view.setStats(view._instance.instanceStats);
                }
            }
            /********** OTHERS START **********/
        };


        /*
        Public control methods *************************************************************
         */

        /**
         * @instance
         * @memberof TaskStatistics
         * @method setStats
         * @param {Object} data.stats - The object that contains statistics values
		 * @param {Number} data.stats.overdue - The amount of overdue task
		 * @param {Number} data.stats.atRisk - The amount of at risk task
		 * @param {Number} data.stats.onTrack - The amount of onTrack task
         * @param {Number} data.stats.completed - The amount of completed task
         * @param {Number} data.stats.total - The amount of total task
         * @desc Sets the statistics values by specific values
		 */
		this.constructor.prototype.setStats = function(data)
        {
            if (!this.context.binding) {
                this.context.binding = bpmext.ui.substituteObject(this, "binding", "value", {});
            }

			this.context.binding.set("value", data);
            domClass.remove(this.context.element.querySelector(".wrappedStatsContainer"), "skeleton");
        };
        /**
         * @instance
         * @memberof TaskStatistics
         * @method setMainStatsByItems
         * @param {Object} data - The list of task items
         * @desc Sets the statistics values by a given list of task items
		 */
        this.constructor.prototype.setMainStatsByItems = function(data, type)
        {
            var stats = {};
            if (type === "instance") {
                stats = {
                    "total": data && data.Total || 0,
                    "active": data && data.Active || 0,
                    "failed": data && data.Failed || 0,
                    "terminated": data && data.Terminated|| 0,
                    "suspended": data && data.Suspended || 0,
                    "completed": data && data.Completed || 0
                };
            } else {
                var allStatus = data.reduce(function(prev, status) {
                    var statusName = taskUtils.getStatusClassName(status);
                    prev[statusName] = (prev[statusName] || 0) + 1;
                    return prev;
                }, {});

                stats = {
                    "total": data.length,
                    "onTrack": (allStatus["onTrackTask"] || 0),
                    "atRisk": (allStatus["atRiskTask"] || 0),
                    "overdue": (allStatus["overdueTask"] || 0),
                    "completed": (allStatus["completedTask"] || 0)
                };
            }

            this.setStats({stats: stats});
        };
		/**
		 * @instance
         * @memberof TaskStatistics
         * @method setConfigShowAll
		 * @param {Boolean} value - When this is true, all statistics will be shown even the ones with zero values
		 * @desc Sets the configuration to show all statistics
		 */
		this.constructor.prototype.setConfigShowAll = function(value)
        {
            if (!this.context.options.showAll) {
                bpmext.ui.substituteConfigOption(this, "showAll", false);
            }
            this.context.options.showAll.set("value", value);
        };
		/**
		 * @instance
         * @memberof TaskStatistics
         * @method getConfigShowAll
		 * @returns {Boolean} the boolean value of showAll
		 * @desc Gets the value of the configuration property showAll
		 */
		this.constructor.prototype.getConfigShowAll = function()
        {
            if (!this.context.options.showAll) {
                bpmext.ui.substituteConfigOption(this, "showAll", false);
            }
            return this.context.options.showAll.get("value");
        };
        /**
		 * @instance
         * @memberof TaskStatistics
         * @method showTotalOnly
		 * @param {Boolean} show - When this is true, only total statistic will be shown all others will be hidden
		 * @desc Sets all other statistics except total to be hidden
		 */
		this.constructor.prototype.showTotalOnly = function(show)
        {
            if (!this.context.options.showTotalOnly) {
                bpmext.ui.substituteConfigOption(this, "showTotalOnly", false);
            }
            this.context.options.showTotalOnly.set("value", show);
        };
        /**
		 * @instance
         * @memberof TaskStatistics
         * @method getShowTotalOnly
		 * @returns {Boolean} the boolean value of showTotalOnly
		 * @desc Gets the value of the configuration property showTotalOnly
		 */
		this.constructor.prototype.getShowTotalOnly = function()
        {
            if (!this.context.options.getShowTotalOnly) {
                bpmext.ui.substituteConfigOption(this, "showTotalOnly", false);
            }
            return this.context.options.showTotalOnly.get("value");
        };
        /**
		 * @instance
         * @memberof TaskStatistics
         * @method eventTriggeredFilterAction
		 * @desc Set if event Triggered Filter Action be enabled
		 */
		this.constructor.prototype.eventTriggeredFilterAction = function(enable)
        {
            if (!this.context.options.eventTriggeredFilterAction) {
                bpmext.ui.substituteConfigOption(this, "eventTriggeredFilterAction", false);
            }

            return this.context.options.eventTriggeredFilterAction.set("value", enable);
        };
        /**
		 * @instance
         * @memberof TaskStatistics
         * @method isEventTriggeredFilterAction
		 * @returns {Boolean} the boolean value of eventTriggeredFilterAction
		 * @desc Gets the value of the eventTriggeredFilterAction
		 */
		this.constructor.prototype.isEventTriggeredFilterAction = function()
        {
            return this.context.options.eventTriggeredFilterAction.get("value");
        };
        /**
		 * @instance
         * @memberof TaskStatistics
         * @method removeFilters
		 * @desc Removes filters
		 */
		this.constructor.prototype.removeFilters = function()
        {
            if(this._instance.instanceMode){
                this._instance.instanceActiveFilter = null;
            }else{
                this._instance.taskActiveFilter = null;
            }
            this._proto._deactivateAllFilterBtns(this);
        };
        /**
		 * @instance
         * @memberof TaskStatistics
         * @method setActiveFilterFocus
		 * @desc Set filter focus depending on current tab
		 */
		this.constructor.prototype.setActiveFilterFocus = function()
        {   
            var activeFilter = null;
            if (this._instance.instanceMode && this._instance.instanceActiveFilter != null){
                activeFilter = this._instance.instanceActiveFilter;
            }else if(!this._instance.instanceMode && this._instance.taskActiveFilter != null){
                activeFilter = this._instance.taskActiveFilter;
            }
            this._proto._setActiveFilterBtn(this, activeFilter);
        };

        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function ()
        {
            var view = this, opts = this.context.options;

            if (!this.context.binding) {
                this.context.binding = bpmext.ui.substituteObject(this, "binding", "tasks", {});
            }

            if (!opts.showAll) {
                bpmext.ui.substituteConfigOption(this, "showAll", false);
            }

            if (!opts.showTotalOnly) {
                bpmext.ui.substituteConfigOption(this, "showTotalOnly", false);
            }

            if (!opts.eventTriggeredFilterAction) {
                bpmext.ui.substituteConfigOption(this, "eventTriggeredFilterAction", false);
            }

            this._instance.instanceMode = false;
            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_FILTERBTN_ONCLICK, "filterOpt");

            this._proto._initStatsContainer(this);

            var skeltonStats = {
                "total": 0,
                "onTrack": 0,
                "atRisk": 0,
                "overdue": 0
            };
            this.setStats({stats: skeltonStats});

            // default action is to update on every tasks fetching
            if (!this.isEventTriggeredFilterAction()) {
                this._instance.tasksResource = wpResources.tasks;
                this._instance.tasksResource.get.register(this, function (){
                    //some other view requested an update to the task list, so the statistics should be updated just in case there was a change
                    if (view.isVisible() && !this._instance.instanceMode) {
                        view._proto._fetchTaskTotals(view, function (totalTasks) {
                            view._instance.taskStats = totalTasks;
                            taskUtils.EVENTS.SET_STATS.publish();
                        });
                    }
                });
            }
            taskUtils.EVENTS.SET_DEFAULT_STATS.subscribe(function () {
                if (this.isVisible()) {
                    view.removeFilters();
                }
            }, this);
            taskUtils.EVENTS.SET_DEFAULT_INSTANCE_STATS.subscribe(function () {
                if (this.isVisible()) {
                    view.removeFilters();
                }
            }, this);
            // Update stats displayed when switching tabs
            taskUtils.EVENTS.SET_STATS.subscribe(function() {
                if (this.isVisible()) {
                    if(this._instance.instanceMode){
                        view._proto._fetchInstanceTotals(view, function (totalInstances) {
                            if(totalInstances != null){
                                view._instance.instanceStats = totalInstances;
                                view.setStats(totalInstances); 
                            }
                        });
                    }else if(this._instance.taskStats != null){
                        this.setStats(this._instance.taskStats);
                    }
                    view._proto._changeTotalNodesTitle(view);
                }
            }, this);

            bpmext.ui.loadView(this);
        };

        this.constructor.prototype.view = function ()
        {
            try
            {
                utilities.handleVisibility(this.context);
            }
            catch (e)
            {
                bpmext.log.error("ERROR_ONVIEW_EVENT" + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if(e.stack) {
                    bpmext.log.error("  " + "CALL_STACK" + e.stack);
                }
            }
        };

        this.constructor.prototype.change = function (event)
        {
            if (event && event.type === "binding") {
                this._proto._updateMainStats(this);
            }

            if (event && event.type === "config") {
                switch (event.property) {
                    case "_metadata.visibility": {
                        this.view();
                        break;
                    }
                    case "showAll":
                    case "showTotalOnly":
                    case "eventTriggeredFilterAction": {
                        this._proto._resetStatsContainer(this);
                        this._proto._updateMainStats(this);
                        break;
                    }
                }
            }
        };

        this.constructor.prototype.unload = function ()
        {
            bpmext.ui.unloadView(this);
        };
    }
};
