/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define([], function() {
    "use strict";
    var EVENT_NAMES, EVENTS;

    EVENT_NAMES = [
        "TASK_SHOWING_IN_VIEWER",
        "CLOSE_TASK_VIEWER",
        "SERVICE_SHOWING_IN_VIEWER",
        "VIEWER_CLOSED",
        "TASK_BEFORE_LAUNCH",
        "TASK_CONFIRM_CLAIM",
        "TASK_LAUNCHED",
        "MODIFY_TASK_SEARCH_TERM",
        "MODIFY_TASK_FILTER",
        "MODIFY_TASK_QUICK_FILTER",
        "MODIFY_TASK_COLUMNS",
        "MODIFY_INSTANCE_COLUMNS",
        "SERVICE_LAUNCHED",
        "MODIFY_TASK",
        "BEFORE_VIEW_INSTANCE",
        "INSTANCE_FETCHED",
        "INSTANCE_ADHOC_ACTIVITIES_FETCHED",
        "INSTANCE_HISTORY_STREAM_FETCHED",
        "VIEW_INSTANCE",
        "CLOSE_INSTANCE",
        "CONFIG_INSTANCE_CONTROL",
        "AFTER_CLOSE_INSTANCE",
        "RELOAD_INSTANCE",
        "MODIFY_INSTANCE",
        "FOLLOW_INSTANCE",
        "UNFOLLOW_INSTANCE",
        "UPDATE_FOLLOWING",
        "UPDATE_MENTIONS",
        "UPDATE_FOLLOW_ACTION",
        "MODIFY_INSTANCE_OPEN",
        "MODIFY_INSTANCE_CLOSE",
        "CLOSE_SIDEBAR",
        "SHOW_ERROR_DETAIL",
        "DASHBOARDS_READY",
        "NO_FEDERATED_SYSTEM",

        "PERFORM_WORKSTREAM_ACTION",
        "ACTION_PERFORMED",
        "TERMINATE_INSTANCE_EVENT",
        "RETRY_INSTANCE_EVENT",
        "SUSPEND_INSTANCE_EVENT",
        "RESUME_INSTANCE_EVENT",

        "INSTANCE_TASK_BEFORE_LAUNCH",
        "VIEW_PROCESS_AUDIT",
        "VIEW_PROCESS_DIAGRAM",
        "NUMBER_OF_TASK_CHANGED",
        "QUICK_LAUNCH_ITEMS",
        "TASKLIST_SHOW_LOADER",

        "SAVED_SEARCH_LAUNCHED",
        "EDIT_SAVED_SEARCH",
        "DUPLICATE_SAVED_SEARCH",
        "DELETE_SAVED_SEARCH",
        "SAVED_SEARCH_DELETED",
        "USER_RIGHT_CHANGED",
        "REFRESH_SAVED_SEARCH",
        "CREATE_SAVED_SEARCH",
        "SAVED_SEARCH_CLEARED",
        "SAVED_SEARCH_PILL_SET",
        "UPDATE_COLUMNS",
        "SORT_TASKLIST",
        "SORT_WORKFLOWLIST",
        "UPDATE_SORT_FILTER",
        "CHANGE_SORT_FILTER",
        "CHANGE_WORKFLOW_SORT_FILTER",
        "SORT_FROM_SS",
        
        "BEFORE_OPEN_INSTANCE_LIST",
        "OPEN_INSTANCE_LIST",
        "INSTANCE_ERROR",
        "OPEN_SEARCH_FILTER",
        "MODIFY_INSTANCE_FILTER",
        "MODIFY_INSTANCE_SEARCH_TERM",

        // social features
        "VIEW_STREAM",

        "SUMMARY_MODAL_LAUNCH",

        //Delay Reload events
        "DELAY_RELOAD",
        "PROCESSES_UPDATING",
        "PROCESSES_UPDATED",
        "TEAM_UPDATED",

        "NOTIFICATION_PROCESS_STARTED",

        "COMETD_DISCONNECTED",
        "COMETD_FAILED_TO_CONNECT",

        //COMETD NOTIFICATION EVENT KINDS
        "TASK_RESOURCE_ASSIGNED",
        "TASK_COLLABORATION_INVITE",
        "PROCESS_COMMENT_TAGGED",
        "TASK_FIELD_CHANGED",

        //COMETD NOTIFICATION CHANNEL EVENT NAMES
        "NOTIFICATION_TASK_RESOURCE_ASSIGNED",
        "NOTIFICATION_TASK_COLLABORATION_INVITE",
        "NOTIFICATION_PROCESS_COMMENT_TAGGED",

        //COMETD TASKLIST CHANNEL EVENT NAMES
        "TASKLIST_TASK_RESOURCE_ASSIGNED",

        "SLIDEOUT_PANEL_EXPAND",
        "SLIDEOUT_PANEL_CLOSE",
        "SLIDEOUT_SET_PRIMARY_BTN",
        "SLIDEOUT_SET_SECONDARY_BTN",
        "LOAD_STACK_PANE",

        "OPEN_RECENT",
        "OPEN_ACTIVITIES",
        "OPEN_FAVORITES",
        "OPEN_CONFIG",
        "ADJUST_CONFIG_PANEL",
        "WORKSTREAM_LAUNCHED",
        "LAUNCH_RESOURCE",
        "OPEN_NAME_WORKSTREAM",
        "NAME_WORKSTREAM_LOADED",

        "FORCED_REFRESH",
        "LAUNCH_HELP",
        
        //CASE
        "CASETYPE_READY",
        "NOTIFICATION_OPEN_NAVIGATOR",
        "VIEW_CASE_INSTANCE",

        //TEAM DASHBOARD
        "BEFORE_VIEW_TEAM_DASHBOARD",
        "CLOSE_TEAM_DASHBOARD",
        "RELOAD_TEAM_DASHBOARD",
        "FOCUS_ON_TEAM",
        "HIGHLIGHT_ON_TEAM",

        //TEAM PERFORMANCE
        "BEFORE_VIEW_TEAM_PERFORMANCE",
        "CLOSE_TEAM_PERFORMANCE",
        "RELOAD_TEAM_PERFORMANCE",

        //TEAM MEMBER DETAIL
        "BEFORE_VIEW_TEAM_MEMBER_DETAIL",
        "TEAM_MEMBER_TASK_BEFORE_LAUNCH",

        //BATCH MODIFY TASKS
        "BATCH_MODIFY_TASKS",
        "TEAM_TASK_BEFORE_LAUNCH",

        //WORKPLACE LAYOUT
        "BEFORE_VIEW_WORKPLACE",
        "SHOW_REFRESH_BUTTON",
        "SET_EMAIL_NOTIFICATION",

        //CONTENT SWITCHED
        "ROOT_CONTENT_SWITCHED",

        //PROPERTIES MODAL
        "LOAD_MODAL",
        
        "CLOSE_SEARCH_BAR",
        "SET_DEFAULT_STATS",
        "SET_SS_UNSAVED",
        "MODIFY_TASK_STATS",
        "SET_DEFAULT_INSTANCE_STATS",
        "SET_TASK_BADGE",
        "SET_INSTANCE_BADGE",
        "RESET_INSTANCE_FILTER",
        "CLEAR_TASK_FIELDS",
        "CLEAR_INSTANCE_FIELDS",
        "CLEAR_TASK_FILTERS",

        "SET_STATS",
        "MODIFY_INSTANCE_QUICK_FILTER",
        "SET_QUICK_FILTER",
        "SET_INSTANCE_QUICK_FILTER",
        "CREATE_TOAST",
        "GET_LINK",
        "COPY_LINK",
        "OPEN_PAGE",
        "SET_SAVED_SEARCH_SCOPE",
        "SET_NEXT_TASK_MODE",
        "LOAD_DEFAULT_SAVED_SEARCH", 
        "POTENTIAL_REASSIGN_BACK_TO_TEAM",
        "REASSIGN_BACK",
        "DISABLE_NAV_LINK", 
        
        "LAUNCH_FROM_PREVIEW"
    ];

    function createEvent(eventName) {
        return {
            name: eventName,
            subscribe: function subscribe(callback, view) {
                bpmext.ui.addEventSubscription(this.name, callback, view, true);
            },
            subscribeNonPersistent: function subscribeNonPersistent(callback, view) {
                bpmext.ui.addEventSubscription(this.name, callback, view);
            },
            publish: function publish(data) {
                bpmext.ui.publishEvent(this.name, data, false, true);
            },
            publishSync: function publishSync(data) {
                bpmext.ui.publishEvent(this.name, data, false);
            },
            equals: function (objectOrName) {
                return objectOrName === this || objectOrName === this.name;
            }
        };
    }

    EVENTS = EVENT_NAMES.reduce(function(acc, eventName) {
        acc[eventName] = createEvent(eventName);
        return acc;
    }, {});

    return {
        EVENTS: EVENTS
    };
});
