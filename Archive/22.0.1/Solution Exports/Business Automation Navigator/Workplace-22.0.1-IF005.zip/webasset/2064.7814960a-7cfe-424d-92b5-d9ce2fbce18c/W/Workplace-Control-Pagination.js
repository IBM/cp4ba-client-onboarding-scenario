/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof Pagination
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof Pagination
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof Pagination
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof Pagination
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof Pagination
 * @method setData
 */

/**
 * <table>
 * 
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 * 
 *   <tr class=Prop>
 *       <td>On page changed:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when the page number changes.</td>
 *               </tr>
 *           </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">Description</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">pageNumber {integer}</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">new page number</td>
 *               </tr>
 *       </table>
 *     </td>
 *   </tr>
 * 
 *   <tr class=Prop>
 *       <td>On items per page changed:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when the number of items per page changes.</td>
 *               </tr>
 *           </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">Description</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">itemPerPage {integer}</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">number items per page</td>
 *               </tr>
 *           </table>
 *       </td>
 *   </tr>
 * 
 * </table>
 */
workplace_control_InitPagination = function (utilities) {
    "use strict";
    this._instance = {};

    if (!this.constructor.prototype._proto) {
        this.constructor.prototype._proto = {
            //Event constants
            EVT_ONPAGE_SWITCHED : "eventON_PAGE_SWITCHED",
            EVT_ONPAGESIZE_CHANGED : "eventON_PAGESIZE_CHANGED",

            /******************** Config - start ********************/
            _setPages: function _setPages(view) {
                var pages = view._proto._getPages(view);
                var ofPageText = bpmext.localization.formatMsg("Pagination", (pages > 1) ? "ofPages" : "ofPage", pages);

                view._instance.ofPages.setLabelVisible(false);
                view._instance.ofPages.setText(ofPageText);

                // set page options
                view._instance.pager.clearItems();
                for (var i = 0; i < pages; i++) {
                    view._instance.pager.appendItem(i+1, i+1);
                }
            },

            _getPages: function _getPages(view) {
                var numberItems = view.getItemLength() || 0;
                var perPage = view.getPerPage() || 10;

                // get number of pages by current perPage setting
                return Math.ceil(numberItems / perPage) || 1;
            },

            _setPageSizer: function _setPageSizer(view) {
                var pageSize = view.getPerPage() || 10;

                // sync page size with the control
                if (view._instance.pageSizer.getValue() !== pageSize) {
                    view._instance.pageSizer.setValue(pageSize);
                }
            },

            _setCurPageNumber: function _setCurPageNumber(view) {
                var pages = view._proto._getPages(view);
                var pageNumb = view.getCurPageNumber();

                if (pages > 0 && pageNumb > 0) {
                    // sync page selector
                    if (view._instance.pager.getSelectedIndex() + 1 !== pageNumb) {
                        view._instance.pager.setSelectedItemAt(pageNumb - 1);
                    }

                    bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONPAGE_SWITCHED, pageNumb);
                }
            },

            _updateControls: function _updateControls(view) {
                var pages = view._proto._getPages(view);
                var pageNumb = view.getCurPageNumber();

                if (pages > 0 && pageNumb > 0) {
                    view._instance.prevBtn.setVisible(true, true);
                    view._instance.nextBtn.setVisible(true, true);

                    view._instance.prevBtn.setEnabled(pageNumb !== 1);
                    view._instance.nextBtn.setEnabled(pages !== pageNumb);

                    view._proto._updateStats(view);
                }
            },

            _updateStats: function _updateStats(view) {
                var numberItems = view.getItemLength() || 0;
                var perPage = view.getPerPage() || 10;

                var statsText = bpmext.localization.formatMsg("Pagination", "noItemsStats");
                if (numberItems) {
                    var curPageNumb = view.getCurPageNumber();
                    var prePageNumb = curPageNumb - 1;

                    statsText = bpmext.localization.formatMsg(
                        "Pagination",
                        "stats",
                        Math.max(prePageNumb * perPage, 0) + 1,
                        Math.min(curPageNumb * perPage, numberItems),
                        numberItems
                    );
                }

                view._instance.stats.setLabelVisible(false);
                view._instance.stats.setText(statsText);
            },
            /******************** Config - end ********************/



            /******************** Others - start ********************/
            _resetPages: function  _resetPages(view) {
                // if not at the first page, then go to the first page
                view.setCurPageNumber(1);

                // update buttons and text
                view._proto._updateControls(view);
            },

            _updateComponentsVisibility: function _updateComponentsVisibility(view) {
                view._instance.pageSizerWrapper.setVisible(view.getShowPageSizer(), true);
                view._instance.statsWrapper.setVisible(view.getShowStats(), true);
            },

            _localization: function _localization(view) {
                view._instance.pageSizer.setLabel(bpmext.localization.formatMsg("Pagination", "itemPerPage"));
                view._instance.prevBtn.setLabel(bpmext.localization.formatMsg("workplace", "previous"));
                view._instance.nextBtn.setLabel(bpmext.localization.formatMsg("workplace", "next"));
            }
            /******************** Others - end ********************/
        };

        /*
        Public control methods *************************************************************
        */

        /**
		 * @instance
		 * @memberof Pagination
		 * @method setCurPageNumber
		 * @desc Sets current page number
		 */
        this.constructor.prototype.setCurPageNumber = function setCurPageNumber(num) {
            bpmext.log.info("Pagination.setCurPageNumber");
            this.context.options.curPageNumber && this.context.options.curPageNumber.set("value", parseInt(num || 1));
        };

        /**
		 * @instance
		 * @memberof Pagination
		 * @method getCurPageNumber
		 * @desc Gets current page number
		 */
        this.constructor.prototype.getCurPageNumber = function getCurPageNumber() {
            bpmext.log.info("Pagination.getCurPageNumber");
            return this.context.options.curPageNumber.get("value");
        };

        /**
		 * @instance
		 * @memberof Pagination
		 * @method setItemLength
		 * @desc Sets number of items
		 */
        this.constructor.prototype.setItemLength = function setItemLength(num) {
            bpmext.log.info("Pagination.setItemLength");
            this.context.options.itemLength && this.context.options.itemLength.set("value", num);
        };

        /**
		 * @instance
		 * @memberof Pagination
		 * @method getItemLength
		 * @desc Gets number of items
		 */
        this.constructor.prototype.getItemLength = function getItemLength() {
            bpmext.log.info("Pagination.getItemLength");
            return this.context.options.itemLength.get("value");
        };

        /**
		 * @instance
		 * @memberof Pagination
		 * @method setPerPage
		 * @desc Sets number of items per page
		 */
        this.constructor.prototype.setPerPage = function setPerPage(num) {
            bpmext.log.info("Pagination.setPerPage");
            this.context.options.perPage && this.context.options.perPage.set("value", num);
            bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONPAGESIZE_CHANGED, num);
        };

        /**
		 * @instance
		 * @memberof Pagination
		 * @method getPerPage
		 * @desc Gets number of items per page
		 */
        this.constructor.prototype.getPerPage = function getPerPage() {
            bpmext.log.info("Pagination.getPerPage");
            return this.context.options.perPage.get("value");
        };

        /**
		 * @instance
		 * @memberof Pagination
		 * @method setShowPageSizer
		 * @desc Sets whether show page sizer
		 */
        this.constructor.prototype.setShowPageSizer = function setShowPageSizer(show) {
            bpmext.log.info("Pagination.setShowPageSizer");
            this.context.options.showPageSizer && this.context.options.showPageSizer.set("value", show);
        };

        /**
		 * @instance
		 * @memberof Pagination
		 * @method getShowPageSizer
		 * @desc Gets whether pager sizer is showing or not
		 */
        this.constructor.prototype.getShowPageSizer = function getShowPageSizer() {
            bpmext.log.info("Pagination.getShowPageSizer");
            return this.context.options.showPageSizer.get("value");
        };

        /**
		 * @instance
		 * @memberof Pagination
		 * @method setShowStats
		 * @desc Sets whether show page stats
		 */
        this.constructor.prototype.setShowStats = function setShowStats(show) {
            bpmext.log.info("Pagination.setShowStats");
            this.context.options.showStats && this.context.options.showStats.set("value", show);
        };

        /**
		 * @instance
		 * @memberof Pagination
		 * @method getShowStats
		 * @desc Gets whether pager stats is showing or not
		 */
        this.constructor.prototype.getShowStats = function getShowStats() {
            bpmext.log.info("Pagination.getShowStats");
            return this.context.options.showStats.get("value");
        };

        /**
		 * @instance
		 * @memberof Pagination
		 * @method toPrev
		 * @desc Goes to previous available page
		 */
        this.constructor.prototype.toPrev = function toPrev() {
            bpmext.log.info("Pagination.toPrev");
            this.setCurPageNumber(this.getCurPageNumber() - 1);
        };

        /**
		 * @instance
		 * @memberof Pagination
		 * @method toNext
		 * @desc Goes to next available page
		 */
        this.constructor.prototype.toNext = function toNext() {
            bpmext.log.info("Pagination.toNext");
            this.setCurPageNumber(this.getCurPageNumber() + 1);
        };

        /**
		 * @instance
		 * @memberof Pagination
		 * @method pagerOnChange
		 * @desc Pager on change
		 */
        this.constructor.prototype.pagerOnChange = function pagerOnChange(target, newVal, oldVal) {
            bpmext.log.info("Pagination.pagerOnChange");
            if (newVal !== oldVal) {
                this.setCurPageNumber(newVal);
            }
        };

        /**
		 * @instance
		 * @memberof Pagination
		 * @method perPageOnChange
		 * @desc Pager on change
		 */
        this.constructor.prototype.perPageOnChange = function perPageOnChange(target, newVal) {
            bpmext.log.info("Pagination.perPageOnChange");

            // prevent negative input
            if (!newVal || newVal < 1) {
                return  this._instance.pageSizer.setValue(this.getPerPage());
            }

            this.setPerPage(newVal);
        };

        /*
        Coach NG Lifecycle methods *************************************************************
        */

        this.constructor.prototype.load = function () {
            bpmext.log.info("Pagination.load ENTER >>", this);

            var opts = this.context.options;

            if (!opts.curPageNumber) {
                bpmext.ui.substituteConfigOption(this, "curPageNumber", 0);
            }

            if (!opts.itemLength) {
                bpmext.ui.substituteConfigOption(this, "itemLength", 0);
            }

            if (!opts.perPage) {
                bpmext.ui.substituteConfigOption(this, "perPage", 6);
            }

            if (!opts.showPageSizer) {
                bpmext.ui.substituteConfigOption(this, "showPageSizer", false);
            }

            if (!opts.showStats) {
                bpmext.ui.substituteConfigOption(this, "showStats", false);
            }

            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONPAGE_SWITCHED, "newPageNumber");
            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONPAGESIZE_CHANGED, "newPageSize");

            // pager sizer
            this._instance.pageSizerWrapper = bpmext.ui.getContainer("PageSizerWrapper", this);
            this._instance.pageSizer = bpmext.ui.getView("PageSizer", this);

            // stats
            this._instance.statsWrapper = bpmext.ui.getContainer("StatsWrapper", this);
            this._instance.stats = bpmext.ui.getView("Stats", this);

            // pager
            this._instance.pager = bpmext.ui.getView("Pager", this);
            this._instance.ofPages = bpmext.ui.getView("OfPages", this);
            this._instance.prevBtn = bpmext.ui.getView("PrevBtn", this);
            this._instance.nextBtn = bpmext.ui.getView("NextBtn", this);

            this._proto._localization(this);
            this._proto._updateComponentsVisibility(this);

            this._proto._setPageSizer(this);
            this._proto._setPages(this);
            this._proto._resetPages(this);

            this.loadView(this);
        };

        this.constructor.prototype.view = function () {
            try {
                utilities.handleVisibility(this.context);
            } catch (e) {
                //{#feature: US-1330 Added RT localization}
                //bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if(e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    //bpmext.log.error("  Call stack: " + e.stack);
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                }
            }
        };

        this.constructor.prototype.change = function (event) {
            bpmext.log.info("Pagination.change ENTER >>");
            if (event.type === "config") {
                switch (event.property) {
                    case "_metadata.visibility": {
                        this.view();
                        break;
                    }
                    case "showStats":
                    case "showPageSizer":
                        this._proto._updateComponentsVisibility(this);
                        break;
                    case "curPageNumber":
                        this._proto._setCurPageNumber(this);
                        this._proto._updateControls(this);
                        break;
                    case "perPage":
                        this._proto._setPageSizer(this);
                        // falls through
                    case "itemLength":
                        this._proto._setPages(this);
                        this._proto._resetPages(this);
                        break;
                }
            }
            bpmext.log.info("Pagination.change EXIT >>");
        };

        this.constructor.prototype.unload = function () {
            bpmext.ui.unloadView(this);
        };
    }
};