/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define([],function(){var l="ar bg cs da de el es fi fr he hu it iw ja ko nb nl no pl pt pt_BR ro ru sk sv tr zh zh_TW".split(" "),h=function(a,b){return a.replace(/{(\d+)}/g,function(a,e){return(b[e]||a)+""})},k=function(a,b,c,e){a.localization?(Object.keys(b).forEach(function(f){a.localization.messages[f]=b[f]}),Object.keys(c).forEach(function(f){a.localization.defaultMessages[f]=c[f]})):a.localization={messages:b,defaultMessages:c,formatString:function(a){return h(a,Array.prototype.slice.call(arguments,
1))},formatMsg:function(a,d){var g;b[a]&&b[a][d]?g=b[a][d]:c[a]&&c[a][d]&&(g=c[a][d]);return null!=g?h(g,Array.prototype.slice.call(arguments,2)):"MESSAGE["+e+"-\x3e"+d+"]"}}};return{initMessages:function(a,b,c){null===a&&(a=document.documentElement.lang.toLowerCase().replace(/[-_]/,"-"),"pt-br"===a?a="pt_BR":"zh-tw"===a?a="zh_TW":"zh-cn"===a?a="zh":"ca"===a?a="es":"en-ca"===a||"en-gb"===a?a="":"fr-ca"===a&&(a="fr"));var e="com.ibm.bpm.workplace.localization/messages"+(-1!==l.indexOf(a)?"_"+a:"");
b?require([e,"com.ibm.bpm.workplace.localization/messages"],function(b,d){k(bpmext,b,d,a);c()}):require(["com.ibm.bpm.coach/bpmEventHelper",e,"com.ibm.bpm.workplace.localization/messages"],function(b,d,c){k(b,d,c,a)})}}});