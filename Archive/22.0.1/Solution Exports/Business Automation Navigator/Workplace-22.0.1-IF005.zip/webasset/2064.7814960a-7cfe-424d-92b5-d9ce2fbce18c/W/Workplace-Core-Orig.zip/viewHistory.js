/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define(["dojo/_base/declare"], function(declare) {
    "use strict";
    //TODO look into how to use dojo.hash and dojo Router to replace this class and standardize interactions
    var ViewHistoryDef = declare("ViewHistory", null, {
        _maxHistory: 5,
        _viewHistory: [],
        _viewRootIdent: "",
        _logStack: function _logStack(separator) {
            var stack = this._viewHistory.map(function(callback) {
                return callback.displayName || callback.identifier;
            });
            bpmext.log.info("HISTORY: " + stack.join(separator));
        },
        /**
         * Add current launching view's callback methods to an array of view history
         *
         * @param {Object} callbacks An object containing two methods onViewClose and onViewRestore and a identifier of the view
         * callbacks definition:
         * - callbacks.identifer {String} Name of current launching view, using for debugging
         * - callbacks.onViewRestore {Function} Restore the current view with same information on call
         * - callbacks.onViewClose {Function} Method that close current view
         * @param {boolean} replaceCurrentView remove current view in history before adding the new view
         */
        addToViewHistory: function addToViewHistory(callbacks, replaceCurrentView, clearBreadcrumb) {
            // close the last view when new view been launching
            if (this._viewHistory.length > 0) {
                var curViewCallbacks = this._viewHistory[this._viewHistory.length - 1];
                if (curViewCallbacks) {
                    curViewCallbacks.onViewClose();
                }
            }

            //check if we need to replace the current view in the history, clear the breadcrumb, or add to it
            if (this._viewHistory.length > 0) {
                if ((clearBreadcrumb+"") === "true") {
                    while (this._viewHistory.length > 1) {
                        this._viewHistory.pop();
                    }
                } else if ((replaceCurrentView+"") === "true") {
                    this._viewHistory.pop();
                }
            }

            // always skipping the second last view history when stacking history exceed the maximum tracking records
            if (this._viewHistory.length === this._maxHistory) {
                var rootViewCallbacks = this._viewHistory[0];
                var tailViewHistory = this._viewHistory.splice(2);
                this._viewHistory = [rootViewCallbacks].concat(tailViewHistory);
            }

            // adding launching view's callbacks to history
            this._viewHistory.push(callbacks);

            this._logStack(" < ");
        },

        /**
         * Closing current launching view and going to the previous view
         */
        loadViewFromHistory: function loadViewFromHistory() {
            if (this._viewHistory.length >= 2) {
                // close and remove current view callbacks for history
                var pauseRestore = false;
                this._curViewCallbacks = this._viewHistory.pop();
                if (this._curViewCallbacks) {
                    pauseRestore = this._curViewCallbacks.onViewClose();
                }

				//If the view has requested that the view restore is paused until it has had a
				//chance to clean up, then do not load the previous view yet
                if(pauseRestore !== true) {
                    this.resumeRestore();
                }

                return true;
            }
        },

        /**
         * If the breadcrumb navigation was previously paused (to allow for view cleanup), calling this
         * method will continue the breadcrumb navigation
        */
        resumeRestore: function resumeRestore() {
            // restore and remove previous view callbacks for history (will be added back in restore callback)
            var prevViewCallbacks = this._viewHistory.pop();
            if (prevViewCallbacks) {
                var forceRefresh = false;
                if(this._curViewCallbacks && this._curViewCallbacks.displayName === "Manage workstream teams" && prevViewCallbacks.displayName === "Workplace") {
                    forceRefresh = true;
                }
                prevViewCallbacks.onViewRestore(forceRefresh);
            }
            this._curViewCallbacks = null;
        },

        /**
         * Closing current launching view and going to the root view
         */
        toRootView: function toRootView() {
            this.loadHistoryItem(0);
        },

        /**
         * Closes the current view and opens the view indicated by index
         * @param index The index of the view to navigate to
         */
        loadHistoryItem: function loadHistoryItem(index) {
            if (this._viewHistory.length > index+1) {
                var curViewCallbacks = this._viewHistory.pop();
                this._viewHistory = this._viewHistory.slice(0,index+1).concat([curViewCallbacks]);

                this._logStack(" <-JUMP- ");
                return this.loadViewFromHistory();
            }
        },

        /**
         * Return the index of a view history that indicated by data identity
         * @param data an object that could use as as identity for a view
         */
        fetchHistoryIndexByIdentData: function fetchHistoryIndexByIdentData(data) {
            if (!data) {
                return -1;
            }

            var i, history, historyData;
            var ident = JSON.stringify(data);
            for (i = 0; i < this._viewHistory.length; i++) {
                history = this._viewHistory[i];

                if (!!history.data) {
                    historyData = dojo.clone(history.data);
                    //the type field is not needed for the compare
                    delete historyData.type;
                    // if an view has been opened before, go back to that view
                    if (ident === JSON.stringify(historyData)) {
                        return i;
                    }
                }

            }

            return -1;
        },

        /**
         * Returns the current view history
         */
        getViewHistory: function getViewHistory() {
            return this._viewHistory;
        },

        resetViewHistory: function resetViewHistory() {
            // close the last view when new view been launching
            if (this._viewHistory.length > 0) {
                var curViewCallbacks = this._viewHistory[this._viewHistory.length - 1];
                if (curViewCallbacks) {
                    curViewCallbacks.onViewClose();
                }
            }

            this._viewHistory = [];
            this._logStack(" < ");
        },

        /**
         * Returns the root view identifier
         */
        getViewRootIdent: function getViewRootIdent() {
            return this._viewRootIdent;
        },

        /**
         * Returns the root view identifier
         */
        setViewRootIdent: function getViewRootIdent(rootIdent) {
            this._viewRootIdent = rootIdent;
        }

    });

    return new ViewHistoryDef();
});
