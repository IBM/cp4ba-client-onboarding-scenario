/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof WorkplaceNavigationBar
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof WorkplaceNavigationBar
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof WorkplaceNavigationBar
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof WorkplaceNavigationBar
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof WorkplaceNavigationBar
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof WorkplaceNavigationBar
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof WorkplaceNavigationBar
 * @method triggerFormulaUpdates
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On navigation item clicked:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when a navigation item from the navigation bar is clicked</td>
 *               </tr>
 *           </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *               </tr>
 *       </table>
 *     </td>
 *   </tr>
 * </table>
 */
workplace_control_InitWorkplaceNavigationBar = function (utilities, taskUtils)
{
    "use strict";

    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
			EVT_ONNAV_ITEM_CLICKED : "eventON_NAV_ITEM_CLICKED"
        };

		/*
        Public control methods *************************************************************
         */

		/**
		 * @instance
		 * @memberof WorkplaceNavigationBar
		 * @method resetView
		 * @desc Resets the current view
		 */
		this.constructor.prototype.resetView = function(){
            this._instance.histories = taskUtils.viewHistory.getViewHistory();
            this._instance.navLayout.setViewData(this._instance.histories, true);
        };
        
        /**
		 * @instance
		 * @memberof WorkplaceNavigationBar
		 * @method loadHistoryLink
		 * @desc Loads an individual link
		 */
		this.constructor.prototype.loadHistoryLink = function(target) {
            target.setVisible(false, true);

            if (!this._instance.histories) {
                this._instance.histories = [];
            }

            var targetIndex = target.ui.getIndex();
            var historyRecord = this._instance.histories[targetIndex];
            var isLastHistoryRecord = (this._instance.histories.length - 1) === targetIndex;

            if (!!historyRecord) {
                target.setText(historyRecord.displayName || historyRecord.identifier);
            }

            if (isLastHistoryRecord) {
                var lastLink = target.context.element.querySelector("a");
                if (!!lastLink) {
                    lastLink.setAttribute("tabindex", "-1");
                    lastLink.setAttribute("aria-disabled", "true");
                } 
            }
            
            if (this._instance.disableNavLink && !isLastHistoryRecord) {
            	target.setVisible(false, true);
            } else {
            	target.setVisible(!!historyRecord, true);
            }
        };

		/**
		 * @instance
		 * @memberof WorkplaceNavigationBar
		 * @method navigationItemClicked
		 * @desc Navigates to the navigation item that was clicked
		 */
		this.constructor.prototype.navigationLinkClicked = function(view, clickedItem) {
            //call event
            var result = bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONNAV_ITEM_CLICKED, clickedItem);

            //navigate
            if (result !== false) {
                taskUtils.viewHistory.loadHistoryItem(clickedItem.ui.getIndex());
            }
        };

        /**
		 * @instance
		 * @memberof WorkplaceNavigationBar
		 * @method copyLink
		 * @desc Copy the link
    	 */
         this.constructor.prototype.copyLink = function() {
            if (this.isVisible() && this.context.getInheritedVisibility() !== "NONE") {
                taskUtils.EVENTS.COPY_LINK.publish();
            }
       };

		/*
        Coach NG Load Lifecycle method *************************************************************
         */
        this.constructor.prototype.load = function ()
        {
        	var view = this;
            bpmext.ui.substituteConfigOption(this, "navitems", []);

            this._instance.navLayout = bpmext.ui.getContainer("NavigationLayout", this);
            this._instance.copyLinkIcon = bpmext.ui.getView("CopyLinkIcon", this);

            taskUtils.addTooltip(this._instance.copyLinkIcon, bpmext.localization.formatMsg("workplace", "copyLink"), 500);
            this._instance.navLayout.setViewData(taskUtils.viewHistory.getViewHistory(), true);

            this.loadView(this);

            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONNAV_ITEM_CLICKED, "item");
            
            taskUtils.EVENTS.DISABLE_NAV_LINK.subscribe(function () {
            	view._instance.disableNavLink = true;
            });

		};

        /*
        Coach NG VIew Lifecycle method *************************************************************
         */
        this.constructor.prototype.view = function ()
        {
            try
            {
                utilities.handleVisibility(this.context);
            }
            catch (e)
            {
                //{#feature: US-1330 Added RT localization}
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if(e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                }
            }
        };

        /*
        Coach NG Change Lifecycle method *************************************************************
         */
        this.constructor.prototype.change = function (event)
        {
            if (event.type === "config") {
                if((event.property === "_metadata.visibility") && ["NONE", "HIDDEN"].indexOf(event.newVal) === -1) {
                    this.resetView();
                }
            }
            this.view();
        };

        /*
        Coach NG Unload Lifecycle method *************************************************************
         */
        this.constructor.prototype.unload = function ()
        {
            bpmext.ui.unloadView(this);
        };
    }
};