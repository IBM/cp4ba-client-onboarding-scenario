/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof LaunchList
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof LaunchList
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof LaunchList
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof LaunchList
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof LaunchList
 * @method setData
 */

/**
 * </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">item {object}</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">service data</td>
 *               </tr>
 *           </table>
 *       </td>
 *   </tr>
 * </table>
 */
workplace_control_InitLaunchList = function (utilities, taskUtils, domAttr, resourceUtils, wpResources, lang) {
	"use strict";
	this._instance = {};

	if (!this.constructor.prototype._proto) {
		this.constructor.prototype._proto = {

			_setViewData: function _setViewData(view, data, createPseudoBinding){
                var ctx = view.context;
                if(ctx){
                    if(ctx.binding){
                        ctx.binding.set("value", data);
                    } else if (createPseudoBinding) {
                        ctx.binding = bpmext.ui.substituteObject(view);
                        ctx.binding.set("value", data);
                    }
                }
	         },

	        _setPrimaryButton: function _setPrimaryButton(view) {
	        	var selectedItem = view._instance.selectedWorkstream, eventData = {}, buttonTxt = bpmext.localization.formatMsg("workplace", "next");
	        	if(selectedItem && typeof selectedItem !== "string") {
	        		buttonTxt =  bpmext.localization.formatMsg("taskCard", "launch");
	        	}
	        	eventData = {
	        		enable: !!selectedItem,
	        		text: buttonTxt
	        	};
				taskUtils.EVENTS.SLIDEOUT_SET_PRIMARY_BTN.publish(eventData);
			},

	         _groupWorkStreams: function _groupWorkStreams(data) {
				var items = [], groupArray = [];
				if(data) {
					items = dojo.clone(data);
					for(var i = 0; i < items.length; i += 3) {
						var obj = {};
						if(i < items.length){
							for(var j = 0; j < 3; j += 1) {
								obj[j] = items[i + j];
							}
							groupArray.push(obj);
						}
					}
				}
	        	 return groupArray;
	         },

			_runProcess: function(item, view) {
            	bpmext.log.info("RecentWorkstream._runProcess LOG >> (process): " + item.display, view);
            	if (item && item.launch instanceof Function) {
            		item.launch().then(function(coachData) {
    					item.loading = false;
    					bpmext.log.info("RecentWorkstream._runProcess LOG >>: " + coachData, view);
    					wpResources.user.get().then(function(currentUser) {
	    					var i, launchNotifyMsg, processName = coachData.name, task;

	    					for (i = 0; i < coachData.tasks.length && task===undefined; i += 1) {
	    						if (coachData.tasks[i].owner === currentUser.userName) {
	    							task = lang.clone(coachData.tasks[i]);
	    						}
	    					}

	    					if (!!task && (taskUtils.isUserTask(task) || view._instance.portalConfig.enableSystemTaskLaunchByPortal)) {
	    						wpResources.task.get({tkiid: task.tkiid, includeURL: true, systemID: item.systemID}).then(function(task) {
                                    task.systemID = task.systemID || item.systemID;
	    							taskUtils.EVENTS.TASK_LAUNCHED.publish({task: task});
	    					    });
	    						return;
	    					} else {
	    						if (processName === null || processName.replace(/^\s\s*/, "").replace(/\s\s*$/, "") === "") {
	    							launchNotifyMsg = bpmext.localization.formatMsg("workplace", "defaultProcess", coachData.data.piid);
	    						} else {
	    							launchNotifyMsg = bpmext.localization.formatMsg("workplace", "processStarted", processName);
	    						}
	    						taskUtils.EVENTS.NOTIFICATION_PROCESS_STARTED.publish({msg:launchNotifyMsg});
	    					}
    					});
    				}, function(rejection){
    					bpmext.log.info("RecentWorkstream._runProcess LOG >>: Launch process failed!", view);
    					var msg = bpmext.localization.formatMsg("workplace", "launchProcessFailed");
    					if(rejection && rejection.timedOut && rejection.config.timeout) {
    						msg = bpmext.localization.formatMsg("workplace", "launchProcessTimeout", rejection.config.timeout / 1000);
    					}
    					taskUtils.publishError(msg);
    				});

    				item.loading = true;
            	}
            },

            _runService: function(item, view) {
            	bpmext.log.info("RecentWorkstream._runService LOG >> (service): " + item.display, view);
            	taskUtils.EVENTS.SERVICE_LAUNCHED.publish({service: item});
            },

			_launchResource: function(data, view) {
				if(data && (data.type === taskUtils.TYPES.SERVICE)) {
					this._runService(data, view);
					bpmext.ui.executeEventHandlingFunction(view, this.EVT_ONSERVICE_LAUNCHED, {item:data});
				} else if(data && data.type === taskUtils.TYPES.PROCESS) {
					this._runProcess(data, view);
					bpmext.ui.executeEventHandlingFunction(view, this.EVT_ONPROCESS_LAUNCHED, data);
					taskUtils.EVENTS.FORCED_REFRESH.publish();
				} else if (data && data.type === taskUtils.TYPES.CASETYPE) {
					var systemInfo, tosName, restUrlPrefix, openInNewWindow = (data.startCaseUsingCSHSPage === "false");
					if(data.systemID) {
						systemInfo = resourceUtils.getFederatedSystemInfo(data.systemID);
	            		restUrlPrefix = systemInfo.restUrlPrefix;
	            		tosName = systemInfo.targetObjectStoreName;
	            		//to do: need remove once Feature 359539 is delivered
	            		if(restUrlPrefix.indexOf("CASEREST") !== -1) {
	            			restUrlPrefix = restUrlPrefix.substr(0, restUrlPrefix.indexOf("CASEREST"));
	            		}
	            		//CaseManager/addcase?TargetObjectStore=tos&CaseType=GNS_MyNewCaseType1
	    				data.runURL = restUrlPrefix + data.addCaseServletPath + "?TargetObjectStore=" + tosName + "&CaseType=" + data.casetypeSymbolicName;
	    				if(openInNewWindow) {
	    					taskUtils.EVENTS.NOTIFICATION_OPEN_NAVIGATOR.publish({url:data.runURL, name:data.casetypeSymbolicName});
	    					//window.open(data.runURL, data.casetypeSymbolicName);
	                    } else {
	                    	this._runService(data, view);
	                    }
					}
				}
			},

			_openActivityList: function(view) {
				var data = view._instance.allExposedItem;
				view._instance.selectedWorkstream = null;
				view._proto._setPrimaryButton(view);
				taskUtils.EVENTS.LOAD_STACK_PANE.publish({targetView:view.context.viewid});
				view._instance.allExposedResource = data;
				view._instance.workflowPanel.setVisible(false,true);
			},

			_openLaunchList: function(view) {
				var data = view._instance.allExposedItem, subtitle;
				view._instance.selectedWorkstream = null;
				view._proto._setPrimaryButton(view);
				taskUtils.EVENTS.LOAD_STACK_PANE.publish({targetView:view.context.viewid});
				view._instance.allExposedResource = data;
				view._instance.allWorkstreams = data? data.processes.concat(data.services,data.caseTypes): data.services;
				view._instance.activityPanel.setVisible(data.configurableWorkstream.itemID === taskUtils.CONFIGURABLE_WORKSTREAM_PROCESS_ID, true);
				view._instance.workflowPanel.setVisible(true,true);
				if(data.configurableWorkstream.itemID === taskUtils.CONFIGURABLE_WORKSTREAM_PROCESS_ID) {
					subtitle = bpmext.localization.formatMsg("ConfigPanel", "subtitle");
				} else {
					subtitle = bpmext.localization.formatMsg("ConfigPanel", "noWorkstreamSubtitle");
				}
				view.setPanelOptions(subtitle);
			},

			_loadAndOpenLaunchList: function(view) {
				var options = {
					subtypes: [wpResources.exposed.SERVICE_SUBTYPE.STARTABLE_SERVICE, wpResources.exposed.SERVICE_SUBTYPE.DASHBOARD],
					includeDescription: true,
					refresh: view._instance.needRefresh
					};

				wpResources.config.get().then(function(config) {
					view._instance.portalConfig = config;
					if (config.excludeReferencedFromToolkit) {
						options.excludeReferencedFromToolkit = config.excludeReferencedFromToolkit;
					}
					wpResources.exposed.get(options).then(function(exposedData) {
						var data = resourceUtils.buildResources(exposedData, options), tempArray = [];

						if(!view._instance.hideProcesses) {
							tempArray = tempArray.concat(data.processes);
						}
						if(!view._instance.hideServices) {
							tempArray = tempArray.concat(data.services);
						}
						if(!view._instance.hideCases) {
							tempArray = tempArray.concat(data.caseTypes);
						}

						//publish the list of dashboards for other views to consume
						taskUtils.EVENTS.DASHBOARDS_READY.publish(data.dashboards);
						taskUtils.EVENTS.CASETYPE_READY.publish(data.caseTypes);

						view._instance.configurableWorkstream = data.configurableWorkstream;
						view._instance.allWorkstreams = tempArray;
						view._instance.allExposedItem = data;
						view._instance.needRefresh = false;

						view._proto._openLaunchList(view);
					});
				});
			},

			_getOrderId: function(dashboard) {
				var orderId = "",
					itemId, systemId, idx, index;
				if(dashboard && dashboard.systemID && dashboard.casetypeSymbolicName) {
					orderId = dashboard.systemID + "-" + dashboard.casetypeSymbolicName;
				}else if(dashboard && dashboard.ID && dashboard.itemID) {
					orderId = dashboard.ID;
					itemId = dashboard.itemID;
					systemId = dashboard.systemID;
					idx = itemId.lastIndexOf("-");
					if(idx !== -1) {
						orderId += itemId.slice(idx);
					}
					if(systemId) {
						index = systemId.lastIndexOf("-");
						if(index !== -1) {
							orderId += systemId.slice(index);
						}
					}
					orderId += "/";
				}
				return orderId.toLowerCase();
			},

			_getFavorite: function(view, targetView) {
				var path = targetView.context.controlidpath;
				var regex = /\[(-?\d+)\]/;
				var i = path.match(regex)[1];
				var j = path.charAt(path.length-1);
				return view._instance.allWorkStreamVL.context.binding.get("value").items[i][j];
			},

			_getRecentInstances: function _getRecentInstances(items) {
            	var temp = this._sortByDate(items, wpResources.isFederated ? "PI_CREATED" : "creationDate"), startedBpdNames = {}, configurableWorkstreamInstances = [], recentInstances = [], existed = false;
            	for(var i in temp) {
            		var processName = temp[i]["bpdName"] || temp[i]["processName"] || temp[i]["PT_NAME"];
            		if(!startedBpdNames[processName] && processName !== taskUtils.CONFIGURABLE_WORKSTREAM) {
            			startedBpdNames[processName] = temp[i];
            		}
            		if(processName === taskUtils.CONFIGURABLE_WORKSTREAM) {
						var name = temp[i].name || temp[i].PI_NAME;
            			// if there is already a same name instance, only keep the latest one
            			existed = configurableWorkstreamInstances.some(function(item) {
            				return item.name === name;
            			});
            			if(!existed) {
            				configurableWorkstreamInstances.push(temp[i]);
            			}
            		}
                }
            	for(var j in startedBpdNames) {
            		recentInstances.push(startedBpdNames[j]);
            	}
            	recentInstances = this._sortByDate(recentInstances.concat(configurableWorkstreamInstances),  wpResources.isFederated ? "PI_CREATED" : "creationDate");
            	return recentInstances;
            },

            _sortByDate: function(items, sortName) {
            	var tempArray = dojo.clone(items);
            	tempArray.sort(function(a, b) {
                    var dateA = a[sortName], dateB = b[sortName];
                    if (dateB > dateA) {
                        return 1;
                    } else if (dateB < dateA) {
                        return -1;
                    } else {
                        return 0;
                    }
                });
                return tempArray;
            }
		};

		/*
		Public control methods *************************************************************
		 */

		 /**
		 * @instance
		 * @memberof LaunchList
		 * @method refresh
		 * @desc Reloads the launch list
		 */
        this.constructor.prototype.refresh = function() {
			bpmext.log.info("LaunchList.refresh ENTER>>", this);

			this._instance.needRefresh = true;
		};

		/**
		 * @instance
		 * @memberof LaunchList
		 * @method goNext
		 * @desc Go to step2
		 */
		this.constructor.prototype.goNext = function goNext() {
			bpmext.log.info("LaunchList.goNext ENTER>>", this);
			var selectedItem = this._instance.selectedWorkstream;
			if(typeof selectedItem === "string") {
				taskUtils.EVENTS.LOAD_STACK_PANE.publish({targetView:"Name_Workstream1"});
				if(this._instance.fromActivities){
					taskUtils.EVENTS.OPEN_NAME_WORKSTREAM.publish({
						selectedWorkstream: selectedItem,
						allExposedResource: this._instance.allExposedResource,
						caller: "ACTIVITIES"
					});
				}else{
					taskUtils.EVENTS.OPEN_NAME_WORKSTREAM.publish({
						selectedWorkstream: selectedItem,
						allExposedResource: this._instance.allExposedResource,
						caller: "STEP_1"
					});
				}
			} else {
				taskUtils.EVENTS.SLIDEOUT_PANEL_CLOSE.publish();
				taskUtils.EVENTS.LAUNCH_RESOURCE.publish(selectedItem);
			}
		};

		/**
         * @instance
         * @memberof LaunchList
         * @method showPanel
         * @desc list the available workstreams
         */
		this.constructor.prototype.showPanel = function showPanel() {
			bpmext.log.info("LaunchList.showPanel ENTER >>", this);
			this.context.options.workStreams.set("value", this._instance.allWorkstreams);
			this._instance.halfWorkstreams = this._proto._groupWorkStreams(this._instance.allWorkstreams);
			this._proto._setViewData(this._instance.allWorkStreamVL, this._instance.halfWorkstreams, true);
			this._instance.selectedWorkstream = null;
		};

		/**
         * @instance
         * @memberof LaunchList
         * @method selectTemplate
         * @desc select one template
         */
		this.constructor.prototype.selectTemplate = function selectTemplate(target) {
			bpmext.log.info("LaunchList.selectTemplate ENTER >>", this);
			if(target.context.viewid.indexOf("ChecklistTemplate") !== -1) {
				this._instance.selectedWorkstream = "CHECKLIST";
			} else if(target.context.viewid === "ApprovalTemplate"){
				this._instance.selectedWorkstream = "APPROVAL";
			}
			this._proto._setPrimaryButton(this);
		};

		/**
         * @instance
         * @memberof LaunchList
         * @method selectSnapshot
         * @desc select a snapshot
         */
		this.constructor.prototype.selectSnapshot = function selectSnapshot(item) {
			bpmext.log.info("LaunchList.selectSnapshot ENTER >>", this);
			this._instance.selectedWorkstream = item;
			this._proto._setPrimaryButton(this);
		};

		/**
         * @instance
         * @memberof LaunchList
         * @method setActivityData
         * @desc Set title, description, and icon of the activity
         */
		this.constructor.prototype.setActivityData = function setActivityData(target, type) {
			bpmext.log.info("LaunchList.setActivityData ENTER >>", this);
			target.setVisible(true);
			if (type === "approval"){
				target.setTitle(bpmext.localization.formatMsg("ConfigPanel", "approvalActivity"));
				target.setDescription(bpmext.localization.formatMsg("ConfigPanel", "approvalDes"));
				target.setTopIcon("ci-network-3");

				target._instance.card.context.element.firstElementChild.setAttribute("role", "form")
				target._instance.card.context.element.firstElementChild.setAttribute("aria-label",
					bpmext.localization.formatMsg("ConfigPanel", "approvalActivity")
					+ " " + bpmext.localization.formatMsg("workplace", "card"));
			}else if (type === "checklist"){
				target.setTitle(bpmext.localization.formatMsg("ConfigPanel", "checklistActivity"));
				target.setDescription(bpmext.localization.formatMsg("ConfigPanel", "checklistDes"));
				target.setTopIcon("ci-list-checked");

				target._instance.card.context.element.firstElementChild.setAttribute("role", "form")
				target._instance.card.context.element.firstElementChild.setAttribute("aria-label",
					bpmext.localization.formatMsg("ConfigPanel", "checklistActivity")
					+ " " + bpmext.localization.formatMsg("workplace", "card"));
			}else{
				target.setVisible(false, true);
			}
		};

		/**
         * @instance
         * @memberof LaunchList
         * @method setWorkflowData
         * @desc Set title, description, and icon of the workflow
         */
		this.constructor.prototype.setWorkflowData = function setWorkflowData(target, index) {
			bpmext.log.info("LaunchList.setWorkflowData ENTER >>", this);
			var data = this._instance.halfWorkstreams[target.ui.getIndex()];
			var lastStream = this._instance.halfWorkstreams[this._instance.halfWorkstreams.length - 1]
			if(data && data[index]){
				target.setVisible(true);
				if(data[index].type === "casetype"){
					target.setTitle(data[index].display + " (" + data[index].solutionName + ")");
					target.setDescription(data[index].casetypeDescription);

					target._instance.card.context.element.firstElementChild.setAttribute("role", "form")
					target._instance.card.context.element.firstElementChild.setAttribute("aria-label",
						data[index].display + " (" + data[index].solutionName + ")"
						+ " " + bpmext.localization.formatMsg("workplace", "card"));
				}else{
					target.setTitle(data[index].display);
					target.setDescription(data[index].itemDescription);
					if(data[index].snapshots && data[index].snapshots.length > 0) {
						target.setSnapshotData(data[index], target);
					}

					target._instance.card.context.element.firstElementChild.setAttribute("role", "form")
					target._instance.card.context.element.firstElementChild.setAttribute("aria-label",
						data[index].display
						+ " " + bpmext.localization.formatMsg("workplace", "card"));
				}
				target.setTopIcon("ci-flow-data");
			}else{
				target.setVisible(false, true);
			}

			// Accessibility
			if (lastStream === data && index === Object.keys(lastStream).length - 1 && this._instance.firstWorkflowLoad) {
				taskUtils.setTabCycle(this); 
			}
		};

		/**
         * @instance
         * @memberof LaunchList
         * @method selectWorkflow
         * @desc select a workflow
         */
		this.constructor.prototype.selectWorkflow = function selectWorkflow(target, index) {
			bpmext.log.info("LaunchList.selectWorkflow ENTER >>", this);
			var data = this._instance.halfWorkstreams[target.ui.getIndex()];
			if(data && data[index] && data[index].snapshots && data[index].snapshots.length > 0) {
				target.openSnapshotLinks(data[index]);
			}
			// select the default snapshot, after resourceUtil processing, the default one will be at the top; if no default snapshot, the first one will be selected by default
			this._instance.selectedWorkstream = data[index];
			this._proto._setPrimaryButton(this);
		};

		/**
         * @instance
         * @memberof LaunchList
         * @method closeSlideout
         * @desc Closes the dialog
         */
        this.constructor.prototype.closeSlideout = function closeSlideout() {
            this.hide(true);
		};

		/**
         * @instance
         * @memberof LaunchList
         * @method setAccessibility
         * @desc Set Accessibility for dynamic elements
         */
        this.constructor.prototype.setAccessibility = function setAccessibility(targetView) {
			if(targetView){
				domAttr.set(targetView.context.element.querySelector(".SPARKWell"), "tabindex", "-1");
				var ariaLabel = targetView.context.element.querySelector(".SPARKWell .Link .input").innerText + " " + targetView.context.element.querySelector(".SPARKWell .Output_Text .input").innerText;
				domAttr.set(targetView.context.element.querySelector(".SPARKWell .input p a"), "aria-label", ariaLabel.trim());
			}
		};

		/**
         * @instance
         * @memberof LaunchList
         * @method loadFavorites
         * @desc Set the favorite workstream icons to filled
         */
        this.constructor.prototype.loadFavorites = function loadFavorites(favoriteView, targetView) {
			var item = this._proto._getFavorite(this, targetView);
			var view = this;

			this.context.options.favorites.get("value").items.forEach(function(favorite) {
				if (view._proto._getOrderId(item) === favorite) {
					favoriteView.setLabel(bpmext.localization.formatMsg("workplace", "favoriteFilled"));
					favoriteView.setIcon("ci-favorite-filled");
				}
			});
		};

		/**
         * @instance
         * @memberof LaunchList
         * @method manageFavorites
         * @desc Add workstream to favorites list when selected and remove when deselected
         */
        this.constructor.prototype.manageFavorites = function manageFavorites(label, targetView, event) {
			event.stopImmediatePropagation();
			var item = this._proto._getFavorite(this, targetView);
			var view = this;

			var favoritesList = this.context.options.favorites.get("value").items;
			if (label === bpmext.localization.formatMsg("workplace", "favorite")) {
				var newList = favoritesList.filter(function(favorite) {
					return view._proto._getOrderId(item) !== favorite;
				});
				this.context.options.favorites.set("value", newList);
			} else {
				favoritesList.push(view._proto._getOrderId(item));
				this.context.options.favorites.set("value", favoritesList);
			}
		};

		this.constructor.prototype.setPanelOptions = function setPanelOptions(subtitle) {
			this._instance.MODAL_OPTIONS = {
				title: bpmext.localization.formatMsg("ConfigPanel", "title"),
				subtitle: subtitle,
				primaryBtnText: bpmext.localization.formatMsg("workplace", "next"),
				primaryBtnEvent: {method: dojo.hitch(this, this.goNext), args: null, closeOnEvtComplete: false},
				onPanelShow: {method: dojo.hitch(this, this.showPanel), args: [""], closeOnEvtComplete: false},
				width: window.innerWidth>700? ((700/window.innerWidth) *100 + "%") : "100%"
			};
		};

		this.constructor.prototype.generateRecent = function generateRecent(exposeList, view) {
			var exposedList = dojo.clone(exposeList), newArray = [], configurableWorkstreamsArray = [], self = this;
			var fields = ["instanceName", "bpdName", "instanceCreationDate", "instanceId"];
			var opt = {limit: taskUtils.DEFAULT_RETRIEVE_INSTANCES_NUM, includeBusinessData: true, fields: null, statusFilter: "Active,Completed,Suspended,Terminated,Failed"};
			if (wpResources.isFederated){
				opt = {limit: taskUtils.DEFAULT_RETRIEVE_INSTANCES_NUM, includeBusinessData: true, fields: fields, interaction: "all"};
			}
			wpResources.processes.get(opt).then(function(data) {
				var processes = !!data ? (data.processes || data.items): null;
				if(!!processes && processes.length > 0) {
					bpmext.log.info("RecentWorkstream._generateRecent LOG >> Instances: " + processes.length);
					var bpdNames = self._proto._getRecentInstances(processes);
					 for(var i = 0; i< bpdNames.length; i++) {
						 var obj = bpdNames[i];
						 var processName = obj.bpdName || obj.processName || obj.PT_NAME;
						 if(processName === taskUtils.CONFIGURABLE_WORKSTREAM) {
							obj.name = obj.name || obj.PI_NAME;
							obj.itemDescription = obj.Workstream_Description || "";
							obj.type = "APPROVAL";
							 newArray.push(obj);
							 configurableWorkstreamsArray.push(obj);
						 } else {
							 exposedList.forEach(function(item) {
								 if(processName === item.display) {
									 newArray.push(item);
								 }
							 });
						 }
					 }
				}
				view._instance.recentList = newArray;
				view._instance.recentInstances = configurableWorkstreamsArray;
				view._proto._updateData(view, newArray);
			});
		};

		/*
		Coach NG Lifecycle methods *************************************************************
		 */
		this.constructor.prototype.load = function () {
			bpmext.log.info("LaunchList.load ENTER >>", this);
			var self = this, opts = this.context.options;
			if (!opts.workStreams) {
                bpmext.ui.substituteConfigOption(this, "workStreams", []);
			}
			if (!opts.favorites) {
                bpmext.ui.substituteConfigOption(this, "favorites", []);
            }
			this._instance.allWorkStreamVL = bpmext.ui.getContainer("AllWorkStreamVL", this);
			this._instance.multiSnapshotVL = bpmext.ui.getContainer("multiSnapshotVL", this);
			this._instance.activityPanel = bpmext.ui.getContainer("ActivityPanel", this);
			this._instance.activityPanel._instance.title.parentElement.setAttribute("aria-level", "3");
			this._instance.workflowPanel = bpmext.ui.getContainer("WorkflowPanel", this);
			this._instance.workflowPanel._instance.title.parentElement.setAttribute("aria-level", "3");
			this._instance.needRefresh = true;

			// refresh launch list
			taskUtils.EVENTS.PROCESSES_UPDATING.subscribe(self.refresh, this);
			taskUtils.EVENTS.PROCESSES_UPDATED.subscribe(self.refresh, this);
			taskUtils.EVENTS.FORCED_REFRESH.subscribe(self.refresh, this);

			taskUtils.EVENTS.OPEN_CONFIG.subscribe(function(){
				self._instance.fromActivities = false;
				self._instance.firstWorkflowLoad = true;
				self._proto._loadAndOpenLaunchList(self);
			}, this);

			taskUtils.EVENTS.OPEN_ACTIVITIES.subscribe(function(){
				self._instance.fromActivities = true;
				self._instance.firstWorkflowLoad = true;
				self._proto._openActivityList(self);
            }, this);

			taskUtils.EVENTS.LAUNCH_RESOURCE.subscribe(function(eventName, resource) {
				self._proto._launchResource(resource, self);
			});

			taskUtils.EVENTS.NAME_WORKSTREAM_LOADED.subscribe(function() {
				var selectedItem = self._instance.selectedWorkstream;
				if(typeof selectedItem === "string") {
					if(self._instance.fromActivities){
						taskUtils.EVENTS.OPEN_NAME_WORKSTREAM.publish({
							selectedWorkstream: selectedItem,
							allExposedResource: self._instance.allExposedResource,
							caller: "ACTIVITIES"
						});
					}else{
						taskUtils.EVENTS.OPEN_NAME_WORKSTREAM.publish({
							selectedWorkstream: selectedItem,
							allExposedResource: self._instance.allExposedResource,
							caller: "STEP_1"
						});
					}
				}
			});

			window.addEventListener("message", dojo.hitch(this, function(event) {
				if (event && event.data){
                    var data = dojo.fromJson(event.data);
                    if ((data.name === "onCompleted") && data.processInstance && data.processInstance.piid !== undefined) {
						taskUtils.EVENTS.FORCED_REFRESH.publish();
					}
				}
			}), false);

			this.loadContainer(this);

			bpmext.log.info("LaunchList.load EXIT >>", this);
		};

		this.constructor.prototype.view = function () {
			try {
				utilities.handleVisibility(this.context);
			} catch (e) {
				//{#feature: US-1330 Added RT localization}
				//bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
				bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
				if (e.stack) {
					//{#feature: US-1330 Added RT localization}
					//bpmext.log.error("  Call stack: " + e.stack);
					bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
				}
			}
		};

		this.constructor.prototype.change = function (event) {
			bpmext.log.info("LaunchList.change ENTER >> (event): " + event, this);
			if (event.type === "config") {
				switch (event.property) {
					case "_metadata.visibility": {
						this.view();
						break;
					}
				}
			}
			bpmext.log.info("LaunchList.change EXIT >>", this);
		};

		this.constructor.prototype.unload = function () {
			bpmext.ui.unloadView(this);
		};
	}
};