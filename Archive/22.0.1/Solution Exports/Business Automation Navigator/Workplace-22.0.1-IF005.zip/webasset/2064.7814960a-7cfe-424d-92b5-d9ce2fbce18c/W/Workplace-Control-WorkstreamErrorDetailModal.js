/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof WorkstreamErrorDetailModal
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof WorkstreamErrorDetailModal
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof WorkstreamErrorDetailModal
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof WorkstreamErrorDetailModal
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof WorkstreamErrorDetailModal
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof WorkstreamErrorDetailModal
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof WorkstreamErrorDetailModal
 * @method triggerFormulaUpdates
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 * </table>
 */
workplace_control_InitWorkstreamErrorDetailModal = function (utilities, taskUtils, domConstruct, domAttr, wpResources)
{
    "use strict";
    this._instance =
    {
        FORMAT_OPTIONS: ["xlsx", "csv", "txt"]
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            _setViewData: function _setViewData(view, data, createPseudoBinding){
                var ctx = view.context;

                if(ctx){
                    if(ctx.binding){
                        ctx.binding.set("value", data);
                    } else if (createPseudoBinding === true) {
                        ctx.binding = bpmext.ui.substituteObject(view);
                        ctx.binding.set("value", data);
                    }
                }
            },

            _fetchWorkstreamErrorDetail: function _fetchWorkstreamErrorDetail (view, piid, systemID, workstream) {
                if (piid) {
                    if (workstream) {
                        wpResources.process.getError({piid: piid, systemID: systemID}).then(function(errorDetail){
                            !!errorDetail && view._proto._setData(view, workstream, errorDetail, systemID);
                        });
                    } else {
                        view._proto._getWorkstream(view, piid, systemID);
                    }
                }
            },

            _getWorkstream: function (view, piid, systemID) {
                if (piid) {
                    wpResources.process.get({piid: piid, systemID: systemID}).then(function (workstream) {
                       !!workstream && view._proto._fetchWorkstreamErrorDetail(view, piid, systemID, workstream);
                    });
                }
            },

            _setData: function _setData(view, workstream, errorDetail, systemID) {
                view._instance.detail = {workstream: workstream, errorDetail: errorDetail, systemID: systemID};

                view._proto._resetViews(view);

                var errorInfo = view._proto._gatheringErrorDetails(view);
                view._proto._loadErrorDetail(view, errorInfo);
                view._proto._setExportingData(view, errorInfo);
            },

            _resetViews: function _resetViews (view) {
                var formatOptions = view._instance.FORMAT_OPTIONS;
                var stackTracePanelBtnControl = view._instance.stackTracePanel.context.element.querySelector("div.accordion-toggle[aria-expanded=true]");
                var exportSettingsPanelBtnControl = view._instance.exportSettingsPanel.context.element.querySelector("div.accordion-toggle[aria-expanded=true]");

                // Make sure the body of the collapse panels have correct aria labels and classes
                !!stackTracePanelBtnControl && stackTracePanelBtnControl.click();
                !!exportSettingsPanelBtnControl && exportSettingsPanelBtnControl.click();

                // Change format back to default format
                if (formatOptions) {
                    view._instance.formatOptions.setSelectedItem(formatOptions[0]);
                }
            },

            _gatheringErrorDetails: function _gatheringErrorDetails (view) {
                var detail = view._instance.detail;

                var workstream = detail.workstream;
                var errorDetail = detail.errorDetail;
                var systemID = detail.systemID;

                var runtimeError = errorDetail && errorDetail.runtimeErrors && errorDetail.runtimeErrors[0];

                return {
                    workstreamName: workstream.name || "",
                    workstreamID: workstream.piid || "",
                    snapshotID: workstream.snapshotID || "",
                    workstreamError: workstream.instanceError || "",
                    taskID: runtimeError && runtimeError.taskId || "",
                    errorTimestamp: runtimeError && runtimeError.timestamp || "" ,
                    javaStackTrace: runtimeError && runtimeError.javaTrace || "",
                    jsStackTrace: runtimeError && runtimeError.jsTrace || "" ,
                    systemID: systemID || "",
                    fullWorkstreamDetail:  JSON.stringify(workstream),
                    fullErrorDetail:  JSON.stringify(errorDetail)
                };
            },

            _loadErrorDetail: function _loadErrorDetail(view, errorInfo) {
                view._instance.workstreamName.setData(errorInfo.workstreamName);
                view._instance.workstreamID.setData(errorInfo.workstreamID);
                view._instance.snapshotID.setData(errorInfo.snapshotID);
                view._instance.workstreamError.setData(errorInfo.workstreamError);
                view._instance.taskID.setData(errorInfo.taskID.replace("Task.", ""));

                var dateStr = "";
                var timestamp = Date.parse(errorInfo.errorTimestamp);

                if (!isNaN(timestamp)) {
                    timestamp = new Date(errorInfo.errorTimestamp);
                    var options = {
                        year: "numeric", month: "short", day: "numeric",
                        hour: "2-digit", minute: "2-digit"
                    };
                    dateStr = timestamp.toLocaleTimeString("en-us", options);
                }

                view._instance.errorTimestamp.setData(dateStr);

                var javaTrace = view._proto._transferErrorTraceToHTML(errorInfo.javaStackTrace);
                var jsTrace = view._proto._transferErrorTraceToHTML(errorInfo.jsStackTrace);
                var errorTrace = javaTrace + jsTrace || bpmext.localization.formatMsg("workstreamErrorDetailModal", "noTraceFound");
                view._instance.stackTrace.setData(errorTrace);
            },

            _transferErrorTraceToHTML: function _transferErrorTraceToHTML(errorTrace) {
                return (!errorTrace) ? "" : "<p class=\"errorTrace\">"
                    + errorTrace
                        .replace(/(\r\n|\n|\r)/gm, "<br />")
                        .replace(/\t/gm, "<span class=\"tab\"></span>")
                    + "</p>";
            },

            _setExportingData: function _setExportingData(view, errorInfo) {
                var columnsHeader = Object.keys(errorInfo).reduce(function (columns, field) {
                    columns.push(bpmext.localization.formatMsg("workstreamErrorDetailModal", field));
                    return columns;
                }, []);

                view._instance.fileName = view._proto._generateFileName(errorInfo);
                view._instance.exportErrorDetail.setColumnHeaders(columnsHeader);
                view._proto._setViewData(view._instance.exportErrorDetail, [errorInfo], true);
            },

            _generateFileName: function _generateFileName(errorInfo) {
                var defaultName = "Error Detail";
                if (errorInfo && errorInfo.workstreamName) {
                    var fileNameFormat = "<PREFIX> - <WORKSTREAM NAME>";
                    return fileNameFormat
                        .replace("<PREFIX>", bpmext.localization.formatMsg("workstreamErrorDetailModal", "filePrefix"))
                        .replace("<WORKSTREAM NAME>", errorInfo.workstreamName);
                }
                return defaultName;
            },

            _initFormatOptions: function _initFormatOptions (view) {
                var formatOptions = view._instance.FORMAT_OPTIONS;

                view._instance.exportSettingsPanel.setVisible(!!formatOptions, true);

                if (formatOptions) {
                    formatOptions.map(function (format) {
                        view._instance.formatOptions.appendItem(format, format.toUpperCase());
                    });
                }
            },

            _localizingLabels: function _localizingLabels (view) {
                // Modal title
                view._instance.errorDetailPanel.setTitle(bpmext.localization.formatMsg("workstreamErrorDetailModal", "workstreamErrorDetailTitle"));

                // Displayed info labels
                view._instance.workstreamName.setLabel(bpmext.localization.formatMsg("workstreamErrorDetailModal", "workstreamName") + ": ");
                view._instance.workstreamError.setLabel(bpmext.localization.formatMsg("workstreamErrorDetailModal", "workstreamError") + ": ");
                view._instance.workstreamID.setLabel(bpmext.localization.formatMsg("workstreamErrorDetailModal", "workstreamID") + ": ");
                view._instance.snapshotID.setLabel(bpmext.localization.formatMsg("workstreamErrorDetailModal", "snapshotID") + ": ");
                view._instance.errorTimestamp.setLabel(bpmext.localization.formatMsg("workstreamErrorDetailModal", "errorTimestamp") + ": ");
                view._instance.taskID.setLabel(bpmext.localization.formatMsg("workstreamErrorDetailModal", "taskID") + ": ");

                // Stack trace title
                view._instance.stackTracePanel.setTitle(bpmext.localization.formatMsg("workstreamErrorDetailModal", "stackTraceTitle"));
                view._instance.stackTrace.setLabelVisible(false);

                // Format options collapsible panel
                view._instance.exportSettingsPanel.setTitle(bpmext.localization.formatMsg("workstreamErrorDetailModal", "exportSettingsTitle"));
                view._instance.formatOptions.setLabel(bpmext.localization.formatMsg("workstreamErrorDetailModal", "exportFormatOptions"));

                // Button text
                view._instance.modalSection.setPrimaryButtonText(bpmext.localization.formatMsg("workstreamErrorDetailModal", "extractError"));
                view._instance.modalSection.setSecondaryButtonText(bpmext.localization.formatMsg("workstreamErrorDetailModal", "close"));
            },

            _download: function _download(saveObj) {
                if ((/iPad|iPhone/.test(navigator.userAgent) || (navigator.platform === "MacIntel"
                && navigator.maxTouchPoints > 1)) && !window.MSStream) {
                   //  ios does not support blob saving, use alternate method
                    var reader = new FileReader();

                    reader.onload = function() {
                        domConstruct.create("a", {
                            href: reader.result,
                            download: saveObj.fileName,
                            target: "_blank"
                        }).click();
                    };

                    reader.readAsDataURL(saveObj.theBlob);
                } else {
                    //not ios, use FileSaver
                    saveAs(saveObj.theBlob, saveObj.fileName);
                }
            },

            _createBlob: function _createBlob(view, obj, fileName) {
                var str = JSON.stringify(obj);
                var data = view._proto._encode(str);

                return {
                    fileName: fileName,
                    theBlob: new Blob([data], {type: "application/octet-stream"})
                };
            },

            _encode: function _encode(str) {
                var out = [];
                for ( var i = 0; i < str.length; i++ ) {
                    out[i] = str.charCodeAt(i);
                }
                return new Uint8Array(out);
            }
        };


        /*
        Public control methods *************************************************************
        */

        /**
		 * @instance
		 * @memberof WorkstreamErrorDetailModal
		 * @method setViewData
         * @param {Object} eventData New workstream object binding
         * @param {String} eventData.piid Process id for the workstream
         * @param {String} eventData.systemID Federated systemID for the workstream
         * @param {Workstream} eventData.workstream Optional, workstream object binding
         * @desc Sets the data
         */
        this.constructor.prototype.setViewData = function(eventData) {
            bpmext.log.info("WorkstreamErrorDetailModal.setViewData ENTER >>", this, eventData);

            var workstream = eventData.workstream;
            var systemID = eventData.systemID;
            var piid = eventData.piid;

            // To avoid loading same data
            if (this._instance.piid !== piid) {
                this._instance.piid = piid;
                this._proto._fetchWorkstreamErrorDetail(this, piid, systemID, workstream);
            }

            bpmext.log.info("WorkstreamErrorDetailModal.setViewData Exit >>", this);
        };

        /**
		 * @instance
		 * @memberof WorkstreamErrorDetailModal
		 * @method closeModal
		 * @desc Closes the modal dialog
         */
        this.constructor.prototype.closeModal = function() {
            bpmext.log.info("WorkstreamErrorDetailModal.closeModal ENTER >> ",this);

            this._instance.modalSection.hide();
            this.hide();

			bpmext.log.info("WorkstreamErrorDetailModal.closeModal EXIT << ");
        };

        /**
		 * @instance
		 * @memberof WorkstreamErrorDetailModal
		 * @method openModal
		 * @desc Opens the modal dialog
         */
        this.constructor.prototype.openModal = function() {
            bpmext.log.info("WorkstreamErrorDetailModal.openModal ENTER >> ",this);

            this._instance.modalSection.show();
            this.show();
            taskUtils.setTabCycle(this);
			bpmext.log.info("WorkstreamErrorDetailModal.openModal EXIT << ");
        };

        /**
		 * @instance
		 * @memberof WorkstreamErrorDetailModal
		 * @method exportError
		 * @desc Exports error detail to selected format
         */
        this.constructor.prototype.exportError = function() {
            bpmext.log.info("WorkstreamErrorDetailModal.exportError ENTER >> ",this);

            var fileName = this._instance.fileName;
            var format = this._instance.formatOptions.getSelectedItem() || "xlsx";

            if (format === "xlsx" || format === "csv") {
                this._instance.exportErrorDetail.setFileName(fileName);
                this._instance.exportErrorDetail.exportFile(this._instance.exportErrorDetail, format);
            } else {
                var detail = this._instance.detail;
                fileName += "." + format;

                var saveObj = this._proto._createBlob(this, detail, fileName);
                this._proto._download(saveObj);
            }

			bpmext.log.info("WorkstreamErrorDetailModal.exportError EXIT << ");
        };


        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function (){
            bpmext.log.info("WorkstreamErrorDetailModal.load ENTER >>", this);

            var view = this;

            // Modal section
            this._instance.modalSection = bpmext.ui.getContainer("ModalSection", this);
            this._instance.errorDetailPanel = bpmext.ui.getContainer("ErrorDetailPanel", this);

            // Displayed info fields
            this._instance.workstreamName = bpmext.ui.getView("Workstream_Name", this);
            this._instance.workstreamError = bpmext.ui.getView("Workstream_Error", this);
            this._instance.workstreamID = bpmext.ui.getView("Workstream_ID", this);
            this._instance.snapshotID = bpmext.ui.getView("Snapshot_ID", this);
            this._instance.errorTimestamp = bpmext.ui.getView("Error_Time_Stamp", this);
            this._instance.taskID = bpmext.ui.getView("Task_ID", this);

            // Stack trace collapsible panel
            this._instance.stackTracePanel = bpmext.ui.getContainer("Stack_Trace_Panel", this);
            this._instance.stackTrace = bpmext.ui.getView("Stack_Trace", this);

            // Format options collapsible panel
            this._instance.exportSettingsPanel =  bpmext.ui.getContainer("ExportSettingsPanel", this);
            this._instance.formatOptions = bpmext.ui.getView("ExportFormatRadioButton", this);

            // Export data
            this._instance.exportErrorDetail = bpmext.ui.getView("ExportErrorDetail", this);
            this._instance.exportErrorDetail.setVisible(false, true);

            this._proto._localizingLabels(this);
            this._proto._initFormatOptions(this);

            var errorDetailPanelHeaderIcon = this._instance.errorDetailPanel.context.element.querySelector("div.panel-heading-controls > div.panel-heading-icon");
            if (errorDetailPanelHeaderIcon) {
                domAttr.set(errorDetailPanelHeaderIcon, "tabindex", 0);
                domAttr.set(errorDetailPanelHeaderIcon, "role", "button");
                domAttr.set(errorDetailPanelHeaderIcon, "aria-label", bpmext.localization.formatMsg("workstreamErrorDetailModal", "close"));

                errorDetailPanelHeaderIcon.addEventListener("keydown", function (event) {
                    event.stopPropagation();

                    // if input key is space or enter key
                    if (event.key === "Enter" || event.key === " " || event.key === "Spacebar") {
                        view.closeModal();
                    }
                }, true);
            }

            this.loadContainer(this);

            taskUtils.EVENTS.SHOW_ERROR_DETAIL.subscribe(function (eventName, eventData) {
                this.setViewData(eventData);
                this.openModal();
            }, this);

            bpmext.log.info("WorkstreamErrorDetailModal.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try {
                utilities.handleVisibility(this.context);
            }
            catch (e){
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e, this);
                if(e.stack) {
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack), this);
                }
            }
        };

        this.constructor.prototype.change = function (event){
            bpmext.log.info("WorkstreamErrorDetailModal.change ENTER >> (event): " + event, this);
            bpmext.log.info("WorkstreamErrorDetailModal.change ENTER >>", this);
        };

        this.constructor.prototype.unload = function (){
            bpmext.log.info("WorkstreamErrorDetailModal.unload ENTER >> ", this);
            bpmext.ui.unloadContainer(this);
            bpmext.log.info("WorkstreamErrorDetailModal.unload ENTER >>", this);
        };
    }
};