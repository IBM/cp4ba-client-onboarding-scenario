/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof Categories
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof Categories
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof Categories
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof Categories
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof Categories
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof Categories
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof Categories
 * @method triggerFormulaUpdates
 */

/**
 * <p>Events</p>
<ul>
    <li>
        On all clicked
        <ul>
            <li>
                <b>Description:</b> This event is fired when the "all" section is
                clicked
            </li>
        </ul>
    </li>
    <li>
        On recent clicked
        <ul>
            <li>
                <b>Description:</b> This event is fired when the "recent" section is
                clicked
            </li>
        </ul>
    </li>
    <li>
        On favorite clicked
        <ul>
            <li>
                <b>Description:</b> This event is fired when the "favorite" section is
                clicked
            </li>
        </ul>
    </li>
</ul>
 */

workplace_control_InitCategories = function (utilities, taskUtils, wpResources, resourceUtils) {
    "use strict";
    this._instance = {
        selected: "all"
    };

    if (!this.constructor.prototype._proto) {
        this.constructor.prototype._proto = {
            EVT_ONALL_CLICK: "eventON_ALL_CLICK",
            EVT_ONACTIVITIES_CLICK: "eventON_ACTIVITIES_CLICK",
            EVT_ONRECENT_CLICK: "eventON_RECENT_CLICK",
            EVT_ONFAVORITES_CLICK: "eventON_FAVORITES_CLICK",

            _translate: function _translate() {
                var args = [].slice.call(arguments);
                args.unshift("PropertiesModal");
                return bpmext.localization.formatMsg.apply(null, args);
            },

            _loadResources: function(view) {
                if(resourceUtils.exposedResources && resourceUtils.exposedResources.configurableWorkstream) {
                    var itemID = resourceUtils.exposedResources.configurableWorkstream.itemID;
                    view._instance.activitiesHL.setVisible(itemID === taskUtils.CONFIGURABLE_WORKSTREAM_PROCESS_ID, true);
                } else {
                    var fetchError = function (error) {
                        !!error && !!error.errorMessage && taskUtils.publishError(error.errorMessage);
                        bpmext.log.error("ERROR >> There was an error fetching exposedResources: " + error);
                    };
                    // this call is not needed here
                    wpResources.config.get().then(function() {
                        var options = {
                            subtypes: ["url"]
                        };

                        wpResources.exposed.get(options).then(
                            function (exposedData) {
                                var data = resourceUtils.buildResources(exposedData, options);

                                // Hide activities when workstreams are disabled
                                view._instance.activitiesHL.setVisible(data.configurableWorkstream.itemID === taskUtils.CONFIGURABLE_WORKSTREAM_PROCESS_ID, true);
                            },
                            fetchError
                        );
                    }, fetchError);
                }
			}
        };


        /*
        Public control methods *************************************************************
        */

        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function () {
            try {
                var view = this;

                // HL = horizontal layout
                this._instance.allHL = bpmext.ui.getContainer("All_HL", this);
                this._instance.activitiesHL = bpmext.ui.getContainer("Activities_HL", this);
                this._instance.recentHL = bpmext.ui.getContainer("Recent_HL", this);
                this._instance.favoritesHL = bpmext.ui.getContainer("Favorite_HL", this);

                this._instance.sidebarTitle = bpmext.ui.getView("Sidebar_Title", this);
                this._instance.allText = bpmext.ui.getView("All_Text", this);
                this._instance.activitesText = bpmext.ui.getView("Activities_Text", this);
                this._instance.RecentText = bpmext.ui.getView("Recent_Text", this);
                this._instance.favoritesText = bpmext.ui.getView("Favorites_Text", this);

                this._instance.layouts = [
                    this._instance.allHL.context.element.id,
                    this._instance.activitiesHL.context.element.id,
                    this._instance.recentHL.context.element.id,
                    this._instance.favoritesHL.context.element.id
                ];

                view._proto._loadResources(view);

                this._instance.sidebarTitle.setLabel(bpmext.localization.formatMsg("workplace", "workflowsTitle"));
                this._instance.allText.setLabel(bpmext.localization.formatMsg("PropertiesModal", "all"));
                this._instance.activitesText.setLabel(bpmext.localization.formatMsg("PropertiesModal", "activities"));
                this._instance.RecentText.setLabel(bpmext.localization.formatMsg("PropertiesModal", "recent"));
                this._instance.favoritesText.setLabel(bpmext.localization.formatMsg("PropertiesModal", "favorites"));

                this._instance.allHL.context.element.setAttribute("aria-labelledby", this._instance.allText._instance.label.id);
                this._instance.activitiesHL.context.element.setAttribute("aria-labelledby", this._instance.activitesText._instance.label.id);
                this._instance.recentHL.context.element.setAttribute("aria-labelledby", this._instance.RecentText._instance.label.id);
                this._instance.favoritesHL.context.element.setAttribute("aria-labelledby", this._instance.favoritesText._instance.label.id);

                this.context.element.setAttribute("role", "tablist");
                this._instance.allHL.context.element.setAttribute("role", "tab");
                this._instance.activitiesHL.context.element.setAttribute("role", "tab");
                this._instance.recentHL.context.element.setAttribute("role", "tab");
                this._instance.favoritesHL.context.element.setAttribute("role", "tab");

                this._instance.allHL.context.element.setAttribute("type", "button");
                this._instance.activitiesHL.context.element.setAttribute("type", "button");
                this._instance.recentHL.context.element.setAttribute("type", "button");
                this._instance.favoritesHL.context.element.setAttribute("type", "button");

                this._instance.allHL.context.element.setAttribute("aria-selected", "false");
                this._instance.activitiesHL.context.element.setAttribute("aria-selected", "false");
                this._instance.recentHL.context.element.setAttribute("aria-selected", "false");
                this._instance.favoritesHL.context.element.setAttribute("aria-selected", "false");

                var eventLayoutMap = new Map();
                eventLayoutMap.set("OPEN_ACTIVITIES", "activities");
                eventLayoutMap.set("OPEN_RECENT", "recent");
                eventLayoutMap.set("OPEN_FAVORITES", "favorites");
                eventLayoutMap.set("OPEN_CONFIG", "all");
                eventLayoutMap.forEach(function (selectionLayoutName, eventName) {
                    taskUtils.EVENTS[eventName].subscribe(function () {
                        // remove all selected
                        view._instance[view._instance.selected + "HL"].context.element.classList.remove("selected");
                        view._instance[view._instance.selected + "HL"].context.element.setAttribute("aria-selected", "false");
                        // set the selected
                        view._instance[selectionLayoutName + "HL"].context.element.classList.add("selected");
                        view._instance[selectionLayoutName + "HL"].context.element.setAttribute("aria-selected", "true");
                        view._instance.selected = selectionLayoutName;
                    }, view);
                });

                view._instance[view._instance.selected + "HL"].context.element.classList.add("selected");
                view._instance[view._instance.selected + "HL"].context.element.setAttribute("aria-selected", "true");

                var onClickHandler = function (itemName) {
                    return function sidebarClickHandler () {
                        // remove all selected
                        view._instance[view._instance.selected + "HL"].context.element.classList.remove("selected");
                        view._instance[view._instance.selected + "HL"].context.element.setAttribute("aria-selected", "false");
                        // set the selected
                        view._instance[itemName + "HL"].context.element.classList.add("selected");
                        view._instance[itemName + "HL"].context.element.setAttribute("aria-selected", "true");
                        bpmext.ui.executeEventHandlingFunction(view, view._proto["EVT_ON" + itemName.toUpperCase() + "_CLICK"]);
                        view._instance.selected = itemName;
                    };
                };

                var keyboardNavigation = function (event) {
                    var key = event.key;
                    if (key === " " || key === "Spacebar" || key === "Enter") {
                        this.click();
                        return;
                    }
                    var index = view._instance.layouts.indexOf(this.id);
                    if (key === "ArrowUp" || key === "Up") {
                        index -= 1;
                    }
                    if (key === "ArrowDown" || key === "Down") {
                        index += 1;
                    }

                    var length = view._instance.layouts.length;
                    // add length to ensure the index is positive
                    var id = view._instance.layouts[((index + length) % length)];
                    document.getElementById(id).focus();
                };
                this._instance.allHL.context.element.addEventListener("click", onClickHandler("all"));
                this._instance.allHL.context.element.addEventListener("keydown", keyboardNavigation);
                this._instance.allHL.context.element.setAttribute("tabindex", 0);
                this._instance.activitiesHL.context.element.addEventListener("click", onClickHandler("activities"));
                this._instance.activitiesHL.context.element.addEventListener("keydown", keyboardNavigation);
                this._instance.activitiesHL.context.element.setAttribute("tabindex", 0);
                this._instance.recentHL.context.element.addEventListener("click", onClickHandler("recent"));
                this._instance.recentHL.context.element.addEventListener("keydown", keyboardNavigation);
                this._instance.recentHL.context.element.setAttribute("tabindex", 0);
                this._instance.favoritesHL.context.element.addEventListener("click", onClickHandler("favorites"));
                this._instance.favoritesHL.context.element.addEventListener("keydown", keyboardNavigation);
                this._instance.favoritesHL.context.element.setAttribute("tabindex", 0);
            } catch (error) {
                bpmext.log.error(error);
            }
        };

        this.constructor.prototype.view = function () {
            try {
                utilities.handleVisibility(this.context);
            } catch (e) {
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if (e.stack) {
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                }
            }
        };

        this.constructor.prototype.change = function () { };

        this.constructor.prototype.unload = function () {
            bpmext.ui.unloadView(this);
        };
    }
};