/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define("com.ibm.bpm.workplace.resources/SearchesResource", ["dojo/_base/lang", "./resourceBase"], function(lang, resource) {
    "use strict";
    var ROUTE =
            resource._buildUrl("${urlPrefix}/v1/searches", {
                urlPrefix: resource.contextRoot.federatedURL || resource.contextRoot.rest
            }) + "${pathParam}",
        METADATA = {
            FIELDS: "fields",
            CONSTRAINT_FIELDS: "constraintFields",
            BUSINESS_DATA_FIELDS: "businessDataFields",
            INSTANCE_STATUS: "instanceStatus",
            TASK_STATUS: "taskStatus",
            PRIORITY: "priority"
        },
        SEARCH_TYPE = {
    		TASK_SEARCH: "TASK_SEARCH",
    		INSTANCE_SEARCH: "INSTANCE_SEARCH"
    	},
        ACTION = {
            RUN_SAVED_SEARCH: "ACTION_RUN_SAVED_SEARCH",
            MANAGE_SAVED_SEARCH: "ACTION_MANAGE_SAVED_SEARCH",
            CREATE_SHARED_SAVED_SEARCH: "ACTION_CREATE_SHARED_SAVED_SEARCH",
            ADMINISTER_SHARED_SAVED_SEARCHES: "ACTION_ADMINISTER_SHARED_SAVED_SEARCHES"
        },
        DEFAULT_OPTS = {
            size: resource.DEFAULT_TASK_LIST_SIZE,
            id: 0,
            name: "",
            fields: [],
            organization: "byTask", //tasks.ORGANIZATION.BY_TASK,
            shared: false,
            teams: [],
            interaction: "claimed_and_available", //tasks.INTERACTION.CLAIMED_AND_AVAILABLE,
            conditions: [],
            sort: [],
            aliases: []
        },
        _businessFieldsPromise, // promise to cache the results of the meta business fields
        _metaFieldsPromise, // promise to cache the results of the meta fields (non-business fields)
        _instanceMetaFieldsPromise,
        _instanceBusinessFieldsPromise;

    /**
     * Get all the saved searches definitions. If options.id or options.name is defined, then only that saved search is returned.
     *
     * @param {Object} [options] - optional params to pass to the underlying API
     * @param {Number} [options.id] - Numeric identifier of the saved search definition. This is optional if name is provided
     * @param {String} [options.name] - Alphanumeric name of the saved search definition. This is optional if id is provided
     */
    function get(options) {
        var defId = (options && (options.id || options.name)) || "",
            url = resource._buildUrl(ROUTE, { pathParam: "/tasks" }),
            query = { federationMode: resource.isFederated };
        if (defId) {
            url += "/" + defId;
        }
        if (resource.isFederated) {
            query.includeSameName = true;
        }
        return resource.get(url, { query: query }).then(
            function success(res) {
                var retData;
                if (resource.isFederated && defId) {
                    retData = res;
                } else if (!resource.isFederated && defId) {
                    retData = res.data;
                } else if (resource.isFederated && !defId) {
                    retData = res.definitions || res.results;
                } else if (!resource.isFederated && !defId) {
                    // mentioning this case to be verbose
                    retData = res.data.definitions;
                }
                return retData;
            }, function error(err) {
                if (err && err.response && err.response.data) {
                    if (err.response.data.status === 500 && err.response.data.errorNumber === "CWMFS4021E") {
                        resource.showError(bpmext.localization.formatMsg("Errors", "noFederatedSystem"), err);
                    } else {
                        var data = err.response.data.Data || err.response.data;
                        resource.showError(data.errorMessage || data.message, err);
                    }
                }
                throw err;
            }
        );
    }

    /**
     * Delete a saved search definition
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {Number} options.id - Numeric identifier of the saved search definition. This is optional if name is provided
     * @param {String} [options.name] - Alphanumeric name of the saved search definition. This is optional if id is provided
     */
    function deleteSearch(options) {
        var defId = (options && (options.id || options.name)) || "",
            url = resource._buildUrl(ROUTE, { pathParam: "/tasks/" + defId });
        if (defId) {
            return resource
                .del(url, {
                    query: {
                        federationMode: resource.isFederated
                    }
                }).then (function success (res) {
                    return res;
                }, function error (err) {
                    if (err && err.response && err.response.data) {
                        var data = err.response.data.Data || err.response.data;
                        resource.showError(data.errorMessage || data.message, err);
                    }
                    throw err;
                });
        }
    }

    /**
     * Update a saved search definition.
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {Number} options.size - number of items to return
     * @param {Number} options.id - id of the saved search. Must be numeric
     * @param {String} options.name - alphanumeric name of the saved search
     * @param {String[]} options.fields - list of fields to include in the result of the search
     * @param {String} options.organization - Grouping of the results. Default is #ORGANIZATION.BY_TASK See #ORGANIZATION
     * @param {Boolean} options.shared - true if the search is to be shared, default is false
     * @param {Object[]} options.teams - list of teams to share the saved search with
     * @param {String} options.interaction - type of interaction of this query. Default is #INTERACTION.CLAIMED_AND_AVAILABLE, See #INTERACTION
     * @param {Object[]} options.conditions - list of conditions to define the search query. You can use the Operators from #OPERATORS
     * @param {Object[]} options.sort - list of columns to sort by. You can use the operators from the #SORT_BY
     * @param {Object[]} options.aliases - list of fields and their aliases. you can use #ALIAS to generate the alias objects
     */
    function update(options) {
        var defId = (options && (options.id || options.name)) || "",
            url = resource._buildUrl(ROUTE, { pathParam: "/tasks/" + defId }),
            data = DEFAULT_OPTS;
        if (defId) {
            if (options.id) {
                options.id = parseInt(options.id, 10);
            }

            // copy from options to override defaults
            data = lang.mixin(data, options);

            // check if shared is a bool or not
            data.shared = data.shared === true;

            return resource
                .put(url, {
                    data: JSON.stringify(data) // data needs to be a string to bypass dojo's objectToQuery
                })
                .then(function success(res) {
                    var retData = resource.isFederated ? res : res.data;
                    return retData;
                });
        }
    }

    /**
     * Save a saved search definition.
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {Number} options.size - number of items in the saved search
     * @param {String} options.name - alphanumeric name of the saved search
     * @param {String[]} options.fields - list of fields to include in the result of the search
     * @param {String} options.organization - Grouping of the results. Default is #ORGANIZATION.BY_TASK See #ORGANIZATION
     * @param {Boolean} options.shared - true if the search is to be shared, default is false
     * @param {Object[]} options.teams - list of teams to share the saved search with
     * @param {String} options.interaction - type of interaction of this query. Default is #INTERACTION.CLAIMED_AND_AVAILABLE, See #INTERACTION
     * @param {Object[]} options.conditions - list of conditions to define the search query. You can use the Operators from #OPERATORS
     * @param {Object[]} options.sort - list of columns to sort by. You can use the operators from the #SORT_BY
     * @param {Object[]} options.aliases - list of fields and their aliases. you can use #ALIAS to generate the alias objects
     */
    function save(options) {
        var url = resource._buildUrl(ROUTE, { pathParam: "/tasks" }),
            data = lang.mixin(DEFAULT_OPTS, { id: undefined });
        if (options && options.name) {
            // copy from options to override defaults
            data = lang.mixin(data, options);

            // check if shared is a bool or not
            data.shared = data.shared === true;

            return resource
                .post(url, {
                    data: JSON.stringify(data) // data needs to be a string to bypass dojo's objectToQuery
                })
                .then(
                    function success(res) {
                        var retData = resource.isFederated ? res : res.data;
                        return retData;
                    }, function error (err) {
                        if (err && err.response && err.response.data) {
                            resource.showError(bpmext.localization.formatMsg("Errors", "errorSavingSavedSearch"), err);
                            var data = err.response.data.Data || err.response.data;
                            if (data.exceptionType === "com.ibm.bpm.wle.api.InvalidParameterException" && (data.errorMessageParameters || [])[0] === "name") {
                                resource.showError(bpmext.localization.formatMsg("Errors", "savedSearchNameError"), err);
                            } else {
                                resource.showError(data.errorMessage || data.message, err);
                            }
                        }
                        throw err;
                    }
                );
        }
    }

    /**
     * Get the action policies set for the current user. Possible action Policies are
     * ACTION_ADMINISTER_SHARED_SAVED_SEARCHES, ACTION_CREATE_SHARED_SAVED_SEARCH, ACTION_MANAGE_SAVED_SEARCH, ACTION_RUN_SAVED_SEARCH
     */
    function getActions() {
        var url = resource._buildUrl(ROUTE, { pathParam: "/actions" });
        return resource
            .get(url, {
                query: {
                    federationMode: resource.isFederated
                }
            })
            .then(function success(res) {
                return resource.isFederated ? res : res.data;
            });
    }

    /**
     * Get metadata fields for saved searches.
     *
     * @param {String} type - Metadata type, see #META
     */
    function getMeta(type, options) {
        var url = resource.isFederated? resource._buildUrl(ROUTE, { pathParam: "/meta" }): resource._buildUrl(ROUTE, { pathParam: "/tasks/meta" }), query;
        if (type) {
            url += "/" + type;
            query = lang.mixin({federationMode: resource.isFederated}, options);
            if(options && options.instanceType) {
        		query = lang.mixin(query, { "instanceType": options.instanceType});
        	}
            return resource
                .get(url, {
                    query: query
                })
                .then(
                    function success(res) {
                        return resource.isFederated ? res.result : res.data.result;
                    },
                    function error(err) {
                        if (err && err.response && err.response.data && err.response.data.status === 500 && err.response.data.errorNumber === "CWMFS4021E") {
                            resource.showError(bpmext.localization.formatMsg("Errors", "noFederatedSystem"), err);
                        }
                        throw err;
                    }
                );
        }
    }

    /**
     * Get the list of default fields that can be used in a search.
     * @param {Boolean} [refresh] - true to bust the cache and retrieve new information from server
     * @returns {Promise} a promise that resolves to the meta fields
     */
    function getMetaFields(refresh) {
        if (!_metaFieldsPromise || refresh) {
            _metaFieldsPromise = getMeta(METADATA.FIELDS);
        }
        return _metaFieldsPromise;
    }
    
    /**
     * Get the list of default fields that can be used in an instance saved search.
     * @param {Boolean} [refresh] - true to bust the cache and retrieve new information from server
     * @returns {Promise} a promise that resolves to the instance meta fields
     */
    function getInstanceMetaFields(refresh) {
        if (!_instanceMetaFieldsPromise || refresh) {
        	_instanceMetaFieldsPromise = getMeta(METADATA.FIELDS, { "searchType": SEARCH_TYPE.INSTANCE_SEARCH });
        }
        return _instanceMetaFieldsPromise;
    }

    /**
     * Get the list of all possible constraint (searchable) fields that are valid within a conditional expression for a search.
     */
    function getMetaConstraintFields() {
        return getMeta(METADATA.CONSTRAINT_FIELDS);
    }

    /**
     * Get the list of all exposed business data fields.
     * @param {Boolean} [refresh] - true to bust the cache and retrieve new information from server
     * @returns {Promise} a promise that resolves to the meta business fields
     */
    function getMetaBusinessDataFields(refresh) {
        if (!_businessFieldsPromise || refresh) {
            _businessFieldsPromise = getMeta(METADATA.BUSINESS_DATA_FIELDS, {"includeOrigin": true});
        }
        return _businessFieldsPromise;
    }

    /**
     * Get the list of all exposed business data fields for instances.
     * @param {Boolean} [refresh] - true to bust the cache and retrieve new information from server
     * @returns {Promise} a promise that resolves to the meta business fields
     */
    function getInstanceMetaBusinessDataFields(refresh) {
        if (!_instanceBusinessFieldsPromise || refresh) {
        	_instanceBusinessFieldsPromise = getMeta(METADATA.BUSINESS_DATA_FIELDS, {"searchType": SEARCH_TYPE.INSTANCE_SEARCH, "includeOrigin": true});
        }
        return _instanceBusinessFieldsPromise;
    }
    
    /**
     * Get the list of all possible task status values.
     */
    function getMetaTaskStatus() {
        return getMeta(METADATA.TASK_STATUS);
    }

    /**
     * Get the list of all possible instance status values.
     */
    function getMetaInstanceStatus() {
        return getMeta(METADATA.INSTANCE_STATUS);
    }

    /**
     * Get the list of all possible priority values.
     */
    function getMetaPriority() {
        return getMeta(METADATA.PRIORITY);
    }

    // module.exports
    return {
        ACTION: ACTION,
        METADATA: METADATA,
        get: get,
        deleteSearch: deleteSearch,
        update: update,
        save: save,
        getActions: getActions,
        getMetaFields: getMetaFields,
        getMetaConstraintFields: getMetaConstraintFields,
        getMetaBusinessDataFields: getMetaBusinessDataFields,
        getMetaTaskStatus: getMetaTaskStatus,
        getMetaInstanceStatus: getMetaInstanceStatus,
        getMetaPriority: getMetaPriority,
        getInstanceMetaFields: getInstanceMetaFields,
        getInstanceMetaBusinessDataFields: getInstanceMetaBusinessDataFields
    };
});
