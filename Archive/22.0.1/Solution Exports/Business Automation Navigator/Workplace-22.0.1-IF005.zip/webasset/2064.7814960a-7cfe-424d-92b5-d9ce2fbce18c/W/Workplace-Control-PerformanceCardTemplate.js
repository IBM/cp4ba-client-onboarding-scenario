/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof PerformanceCardTemplate
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof PerformanceCardTemplate
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof PerformanceCardTemplate
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof PerformanceCardTemplate
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof PerformanceCardTemplate
 * @method setData
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 * </table>
 */
workplace_control_InitPerformanceCardTemplate = function (utilities, taskUtils, domConstruct, domClass){
    "use strict";
    this._instance = {};

    if (!this.constructor.prototype._proto) {
        this.constructor.prototype._proto = {
            LIST_MODE: {
                TEAM: "team",
                ROSTER: "roster"
            },

            /******************** Load data - start ********************/
            _setListMode: function _setListMode(view, mode) {
                mode = mode || view._instance.listMode || "";
                if (mode !== view._instance.listMode) {
                    view._instance.listMode = mode || view._proto.LIST_MODE.TEAM;

                    if (view._instance.listMode === view._proto.LIST_MODE.TEAM) {
                        view._instance.noDataFoundText.setText(bpmext.localization.formatMsg("TeamDashboard", "noTeamsFound"));
                    } else if (view._instance.listMode === view._proto.LIST_MODE.ROSTER) {
                        view._instance.noDataFoundText.setText(bpmext.localization.formatMsg("TeamPerformance", "noRostersFound"));
                    }
                }
            },

            _loadCards: function _loadCards (view, teams) {
                view._instance.templateCards.setVisible((teams && teams.length > 0), true);
                view._instance.noDataFoundWrapper.setVisible(teams.length === 0, true);

                view._proto._setViewData(view._instance.templateCards, teams, true);
            },

            _formTaskStatsLabel: function (state, count) {
                var taskState, taskStateText;
                if (state === "overdue") {
                    taskState = "overdue";
                    taskStateText = "taskOverdue";
                } else if (state === "atRisk") {
                    taskState = "atRisk";
                    taskStateText = "taskAtRisk";
                } else if (state === "onTrack") {
                    taskState = "onTrack";
                    taskStateText = "taskOnTrack";
                } else if (state === "completedToday") {
                    taskState = "completed";
                    taskStateText = "taskCompletedToday";
                } else {
                    taskState = "onTrack";
                    taskStateText = "taskAssigned";
                }

                var span = domConstruct.create("div", {
                    className: "teamTaskStats"
                });

                var stats = domConstruct.create("span", null, span);
                stats.innerText = "${text} ${count}"
                    .replace("${count}", count)
                    .replace("${text}", bpmext.localization.formatMsg("controlTaskList", taskStateText));

                var teamTaskIcon = domConstruct.create("div", {
                    className: "teamTaskIcon"
                }, span, "first");

                var imgSrc = com_ibm_bpm_coach.getManagedAssetUrl(
                    "status_" + taskState +".png",
                    com_ibm_bpm_coach.assetType_WEB,
                    "SYSWPT"
                );

                var taskStatsIcon = domConstruct.toDom("<img src='" + imgSrc +"' alt=''></img>");
                domConstruct.place(taskStatsIcon, teamTaskIcon);

                return span.outerHTML;
            },

            _createDonutChart: function _createDonutChart(view, dataSeries) {
                var radius = 40,
                    circleLength = Math.PI * (radius * 2),
                    spaceUsed = 0;

                var svg = domConstruct.toDom('<svg role="img" aria-label="' + bpmext.localization.formatMsg("TeamPerformance", "donutChart") + '" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 100 100"></svg>');

                var totalValue = dataSeries.reduce(function (total, data) {
                    return total + (data.value || 0);
                }, 0);

                var circleSettings = {cx: 50, cy:50, radius: radius};

                if (totalValue > 0) {
                    dataSeries.forEach(function (data) {
                        var percentage = data.value / totalValue;
                        data.value = Math.ceil(percentage * 100);

                        var circle = view._proto._plotCircle(view, circleSettings, data);

                        // Set dash on circle
                        var len = percentage * circleLength;
                        circle.style.strokeDashoffset = 0 - spaceUsed;

                        if (data.value === totalValue) {
                            circle.style.strokeDasharray = len + " " + circleLength;
                        } else {
                            circle.style.strokeDasharray = (len === 0 ? 0 : len - 1) + " " + circleLength;
                        }

                        // Append circle to svg.
                        svg.appendChild(circle);

                        // Subtract current value from spaceLeft
                        spaceUsed += len;
                    });
                } else {
                    var circle = view._proto._plotCircle(view, circleSettings, {
                        name: "taskTotal",
                        value: totalValue
                    });

                    // Set dash on circle
                    circle.style.strokeDasharray = circleLength + " " + circleLength;

                    // Append circle to svg.
                    svg.appendChild(circle);
                }

                return svg;
            },

            _plotCircle: function _plotCircle(view, circleSettings, data) {
                var circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");

                // Set attributes
                circle.setAttribute("cx", circleSettings.cx);
                circle.setAttribute("cy", circleSettings.cy);
                circle.setAttribute("r", circleSettings.radius);
                circle.setAttribute("class", data.name);

                circle.addEventListener("mouseover", function(event) {
                    if (view._instance.chartTooltipDiv) {
                        var rect = view._proto._getCardsWrapRect(view);
                        domClass.add(view._instance.chartTooltipDiv, "showTooltip " + data.name);
                        view._instance.chartTooltipDiv.style.left = event.pageX - rect.left + 16 + "px";
                        view._instance.chartTooltipDiv.style.top = event.pageY - rect.top - 8 +  "px";
                    }

                    if (view._instance.chartTooltipText) {
                        view._instance.chartTooltipText.innerText = "${text}: ${count}%"
                            .replace("${count}", data.value)
                            .replace("${text}", bpmext.localization.formatMsg("controlTaskList", data.name));
                    }
                });

                circle.addEventListener("mouseout", function() {
                    if (view._instance.chartTooltipDiv) {
                        domClass.remove(view._instance.chartTooltipDiv, "showTooltip taskOnTrack taskAtRisk taskOverdue taskCompletedToday taskAssigned");
                        view._instance.chartTooltipDiv.style.left = null;
                        view._instance.chartTooltipDiv.style.top = null;
                    }

                    if (view._instance.chartTooltipText) {
                        view._instance.chartTooltipText.innerText = "";
                    }
                });

                circle.addEventListener("mousemove", function(event) {
                    if (view._instance.chartTooltipDiv) {
                        var rect = view._proto._getCardsWrapRect(view);
                        view._instance.chartTooltipDiv.style.left = event.pageX - rect.left + 16 + "px";
                        view._instance.chartTooltipDiv.style.top = event.pageY - rect.top - 8 +  "px";
                    }
                });

                return circle;
            },
            /******************** Load data - start ********************/



            /******************** Others - start ********************/
            _setViewData: function _setViewData(view, data, createPseudoBinding){
                var ctx = view.context;

                if (!data || data.length < 1) {
                    view.setVisible(false, true);
                } else {
                    view.setVisible(true, true);
                }

                if(ctx){
                    if(ctx.binding){
                        ctx.binding.set("value", data);
                    } else if (createPseudoBinding === true) {
                        ctx.binding = bpmext.ui.substituteObject(view);
                        ctx.binding.set("value", data);
                    }
                }
            },

            _getBindingData: function _getBindingData (view, target) {
                var listData = view.getListData();

                // Get binding data on a target
                if (listData && target) {
                    var curIndex = target.ui.getIndex();

                    return listData[curIndex];
                }

                return {};
            },

            _bindingEvents: function _bindingEvents (view) {
                if (view._instance.resizeFunc) {
                    view._proto._removeBoundEvents(view);
                }

                view._instance.resizeFunc = function () {
                    view.isVisible() && view._proto._getCardsWrapRect(view, true);
                };

                window.addEventListener("resize", view._instance.resizeFunc, true);
            },

            _removeBoundEvents: function _removeBoundEvents (view) {
                if (view._instance.resizeFunc) {
                    window.removeEventListener("resize", view._instance.resizeFunc, true);
                    delete view._instance.resizeFunc;
                }
            },

            _getCardsWrapRect: function _getCardsWrapRect(view, forceUpdate) {
                // using for reduce numbers of query
                if (forceUpdate || !view._instance.cardsWrapRect) {
                    var rect = view._instance.templateCards.context.element.getBoundingClientRect();

                    view._instance.cardsWrapRect = {
                        left: rect.left || 0,
                        top: rect.top || 0
                    };
                }

                return view._instance.cardsWrapRect;
            }
            /******************** Others - end ********************/
        };

        /*
        Public control methods *************************************************************
        */

        /**
         * @instance
         * @memberof PerformanceCardTemplate
         * @method setListData
         * @desc Set data for data list
         */
        this.constructor.prototype.setListData = function(listData, mode) {
            bpmext.log.info("PerformanceCardTemplate.setListData >> listData: ", listData);
            this._proto._setListMode(this, mode);
            this.context.options.listData && this.context.options.listData.set("value", listData);
        };

        /**
         * @instance
         * @memberof PerformanceCardTemplate
         * @method getListData
         * @desc Get configured data
         */
        this.constructor.prototype.getListData = function() {
            bpmext.log.info("PerformanceCardTemplate.getListData");
            return this.context.options.listData ? this.context.options.listData.get("value").items : [];
        };

        /**
         * @instance
         * @memberof PerformanceCardTemplate
         * @method loadCardBody
         * @desc Loads a card body
         */
        this.constructor.prototype.loadCardBody = function(target) {
            bpmext.log.info("PerformanceCardTemplate.loadCardBody >> event: ", event);

            var data = this._proto._getBindingData(this, target);

            if (!data || JSON.stringify(data) === "{}") {
                target.setVisible(false, true);
                return;
            }

            target.setVisible(true, true);
        };

        /**
         * @instance
         * @memberof PerformanceCardTemplate
         * @method loadDonutChart
         * @desc Loads a team card donut chart
         */
        this.constructor.prototype.loadDonutChart = function(target) {
            bpmext.log.info("PerformanceCardTemplate.loadDonutChart >> event: ", event);

            var data = this._proto._getBindingData(this, target);

            if (!data || JSON.stringify(data) === "{}") {
                return;
            }

            var matchingVal = {};
            if (this._instance.listMode === this._proto.LIST_MODE.TEAM) {
                matchingVal = {
                    donutInnerCounts: data.totalOpenTasks,
                    dataSeries: [
                        {name: "taskOverdue", value: data.countOverdue},
                        {name: "taskAtRisk", value: data.countAtRisk},
                        {name: "taskOnTrack", value: data.countOnTrack},
                    ]
                };
            } else if (this._instance.listMode === this._proto.LIST_MODE.ROSTER) {
                matchingVal = {
                    donutInnerCounts: data.totalTask,
                    dataSeries: [
                        {name: "taskOverdue", value: data.overdueTask},
                        {name: "taskAtRisk", value: data.atRiskTask},
                        {name: "taskOnTrack", value: data.onTrackTask},
                    ]
                };
            }

            //Some languages have different translations for (zero, 1, many) tasks
            var tasksStr = "";
            if (matchingVal.donutInnerCounts === 1) {
                tasksStr = bpmext.localization.formatMsg("TeamPerformance", "tasksSingular");
            } else if (matchingVal.donutInnerCounts > 0) {
                tasksStr = bpmext.localization.formatMsg("TeamPerformance", "tasksPlural");
            } else if (matchingVal.donutInnerCounts === 0) {
                tasksStr = bpmext.localization.formatMsg("TeamPerformance", "tasksZero");
            }

            // Set team stats donut chart
            var tasks = target.context.element.querySelector(".DonutInnerText > .Tasks");
            tasks.innerText = tasksStr;

            var totalCounts = target.context.element.querySelector(".DonutChartWrapper > .DonutInnerText > .AllTasksCounts");
            totalCounts.innerText = matchingVal.donutInnerCounts || 0;

            var donutChart = target.context.element.querySelector(".DonutChartWrapper > .DonutChart");
            var svg = this._proto._createDonutChart(this, matchingVal.dataSeries || []);
            domConstruct.place(svg, donutChart);
        };

        /**
         * @instance
         * @memberof PerformanceCardTemplate
         * @method loadCardDetail
         * @desc Loads card detail section
         */
        this.constructor.prototype.loadCardDetail = function(target) {
            bpmext.log.info("PerformanceCardTemplate.loadCardDetail");
            var data = this._proto._getBindingData(this, target);

            if (!data || JSON.stringify(data) === "{}") {
                return;
            }

            var matchingVal = {};
            if (this._instance.listMode === this._proto.LIST_MODE.TEAM) {
                matchingVal = {
                    name: data.name,
                    main: data.description || bpmext.localization.formatMsg("TeamDashboard", "noTeamDescription")
                };
            } else if (this._instance.listMode === this._proto.LIST_MODE.ROSTER) {
                matchingVal = {
                    name: data.name,
                    main: data.jobTitle || bpmext.localization.formatMsg("TeamPerformance", "noJobTitleFound")
                };
            }

            // Set team name
            var name = target.context.getSubview("Name", target)[0];
            name && name.setText(matchingVal.name || "");
            name && name.setLabelVisible(false, true);

            // Set team description
            var main = target.context.getSubview("Main_Content", target)[0];
            main && main.setText(matchingVal.main || "");
            main && main.setLabelVisible(false, true);
        };

        /**
         * @instance
         * @memberof PerformanceCardTemplate
         * @method loadCardStats
         * @desc Loads a team stats
         */
        this.constructor.prototype.loadCardStats = function(target) {
            bpmext.log.info("PerformanceCardTemplate.loadCardStats");
            var data = this._proto._getBindingData(this, target);

            if (!data || JSON.stringify(data) === "{}") {
                return;
            }

            var matchingVal = {};
            if (this._instance.listMode === this._proto.LIST_MODE.TEAM) {
                matchingVal.statsVals = [
                    this._proto._formTaskStatsLabel("onTrack", data.countOnTrack),
                    this._proto._formTaskStatsLabel("atRisk", data.countAtRisk),
                    this._proto._formTaskStatsLabel("overdue", data.countOverdue)
                ];
            } else if (this._instance.listMode === this._proto.LIST_MODE.ROSTER) {
                matchingVal.statsVals = [
                    this._proto._formTaskStatsLabel("onTrack", data.onTrackTask),
                    this._proto._formTaskStatsLabel("atRisk", data.atRiskTask),
                    this._proto._formTaskStatsLabel("overdue", data.overdueTask)
                ];
            }

            var statsCtl;
            (matchingVal.statsVals || []).forEach(function(statsVal, index) {
                statsCtl = target.context.getSubview("Card_Stats" + (index + 1), target)[0];

                if (statsCtl) {
                    statsCtl.setText(statsVal);
                    statsCtl.setVisible(!!statsVal, true);
                    statsCtl.setLabelVisible(false, true);
                }
            });
        };

        /**
         * @instance
         * @memberof PerformanceCardTemplate
         * @method cardOnClick
         * @desc On card body clicked
         */
        this.constructor.prototype.cardOnClick = function (target) {
            if (this._instance.listMode === this._proto.LIST_MODE.TEAM) {
                this.openTeamDashboard(target);
            } else if (this._instance.listMode === this._proto.LIST_MODE.ROSTER) {
                this.openTeamMemberDetail(target);
            }
        };

        /**
         * @instance
         * @memberof PerformanceCardTemplate
         * @method openTeamDashboard
         * @desc Open team dashboard for select team
         */
        this.constructor.prototype.openTeamDashboard = function (target) {
            bpmext.log.info("PerformanceCardTemplate.openTeamDashboard");

            var view = this,
                data = view._proto._getBindingData(view, target),
                teamPerformanceDS = bpmext.ui.getContainer("/Workplace_Content_Wrapper1/Team_Performance_DS");

			// iteratively check if the deferred view gets loaded,
			// trigger the event after the view gets loaded
			var checkedLoaded = function (data) {
				if (!teamPerformanceDS.isLoaded()) {
					view._instance.defferTimeout = setTimeout(function () {
						checkedLoaded(data);
					}, 200);
				} else {
                    taskUtils.EVENTS.BEFORE_VIEW_TEAM_PERFORMANCE.publish(data);
					delete view._instance.defferTimeout;
				}
			};

			// block repeated clicks
			if (!!teamPerformanceDS && !view._instance.defferTimeout) {
				// load view if it's not loaded
				!teamPerformanceDS.isLoaded() && teamPerformanceDS.lazyLoad(0);

				checkedLoaded(data);
			}
        };

        /**
         * @instance
         * @memberof PerformanceCardTemplate
         * @method openTeamMemberDetail
         * @desc Open team member detail for select member
         */
        this.constructor.prototype.openTeamMemberDetail = function (target) {
            bpmext.log.info("PerformanceCardTemplate.openTeamMemberDetail");

            var view = this,
                data = view._proto._getBindingData(view, target),
                teamMemberDetailDS = bpmext.ui.getContainer("/Workplace_Content_Wrapper1/Team_Member_Detail_DS");

			// iteratively check if the deferred view gets loaded,
			// trigger the event after the view gets loaded
			var checkedLoaded = function (data) {
				if (!teamMemberDetailDS.isLoaded()) {
					view._instance.defferTimeout = setTimeout(function () {
						checkedLoaded(data);
					}, 200);
				} else {
                    taskUtils.EVENTS.BEFORE_VIEW_TEAM_MEMBER_DETAIL.publish(data);
					delete view._instance.defferTimeout;
				}
			};

			// block repeated clicks
			if (!!teamMemberDetailDS && !view._instance.defferTimeout) {
				// load view if it's not loaded
				!teamMemberDetailDS.isLoaded() && teamMemberDetailDS.lazyLoad(0);

				checkedLoaded(data);
			}
        };

        /*
        Coach NG Lifecycle methods *************************************************************
        */

        this.constructor.prototype.load = function () {
            bpmext.log.info("PerformanceCardTemplate.load ENTER >>", this);

            var opts = this.context.options;

            if (!opts.listData) {
                bpmext.ui.substituteConfigOption(this, "listData", []);
            }

            // Cards wrapper
            this._instance.templateCards = bpmext.ui.getContainer("TemplateCards", this);

            // No data found wrapper
            this._instance.noDataFoundWrapper = bpmext.ui.getContainer("No_Data_Found_Wrapper", this);
            this._instance.noDataFoundText = bpmext.ui.getView("No_Data_Found", this);

            // Chart tooltip
            this._instance.chartTooltipDiv = this.context.element.querySelector(".chartTooltip");
            this._instance.chartTooltipText = this.context.element.querySelector(".chartTooltip > span");

            this.loadView(this);

            this._proto._bindingEvents(this);
        };

        this.constructor.prototype.view = function () {
            try {
                utilities.handleVisibility(this.context);
            } catch (e) {
                //{#feature: US-1330 Added RT localization}
                //bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if(e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    //bpmext.log.error("  Call stack: " + e.stack);
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                }
            }
        };

        this.constructor.prototype.change = function (event) {
            bpmext.log.info("PerformanceCardTemplate.change ENTER >>");
            if (event.type === "config") {
                switch (event.property) {
                    case "_metadata.visibility": {
                        this.view();
                        break;
                    }
                    case "listData": {
                        this._proto._loadCards(this, event.newVal.items || []);
                        break;
                    }
                }
            }
            bpmext.log.info("PerformanceCardTemplate.change EXIT >>");
        };

        this.constructor.prototype.unload = function () {
            this._proto._removeBoundEvents(this);
            bpmext.ui.unloadView(this);
        };
    }
};