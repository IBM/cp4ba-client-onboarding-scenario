/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define("com.ibm.bpm.workplace.resources/ServiceResource", ["./resourceBase"], function (resource) {
    "use strict";
    /**
     * Call a service
     *
     * @param {string} options.name - name of the service to invoke. Must be `<PA_SHORT_NAME>@<SERVICE_NAME>`
     * @param {any} options.data - data to be passed to the service. Will be stringified
     * @param {string} [options.systemID] - systemID of the service
     * @returns {Promise} promise that resolved to the response object
     */
    function start(options) {
        // options.systemID (which BAW server it should talk to)  SystemsResource
        var url = resource._buildUrl("${urlPrefix}/v1/service/${name}", {
            urlPrefix: resource.contextRoot.rest,
            name: options.name
        });
        return resource.post(url, {
            data: JSON.stringify(options.data),
            systemID: options.systemID,
            query: { action: "start" }
        });
    }

    return {
        start: start
    };
});
