/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
 /**
 * @ignore
 * @instance
 * @memberof EmailNotificationModal
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof EmailNotificationModal
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof EmailNotificationModal
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof EmailNotificationModal
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof EmailNotificationModal
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof EmailNotificationModal
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof EmailNotificationModal
 * @method triggerFormulaUpdates
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 * </table>
 */
workplace_control_InitEmailNotificationModal = function (utilities, taskUtils, wpResources, domAttr)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            _hideModel: function _hideModel(view){
                bpmext.log.info("EmailNotificationModal._hideModel LOG >>", view);
                view._instance.emailAddressInput.setVisible(false, true);
                view._instance.notificationCheckbox.setVisible(false, true);
                view._instance.modalSection.setVisible(false, true);
                view.setVisible(false, true);
            },
            _getUserPreference: function _getUserPreference(view) {
                bpmext.log.info("EmailNotificationModal._getUserPreference LOG >>", view);
                try {
                    wpResources.user.get()
                        .then(dojo.hitch(view, function(user) {
                            if (user.userPreferences) {
                                var taskEmailAddress = wpResources.user.PREFERENCE.taskEmailAddress;
                                var taskNotification = wpResources.user.PREFERENCE.taskNotification;
                                var emailAddress = user.userPreferences[taskEmailAddress] ? user.userPreferences[taskEmailAddress] : "";
                                var emailNotification = user.userPreferences[taskNotification] ? user.userPreferences[taskNotification] : false;
                                view._instance.emailAddressInput.setText(emailAddress);

                                if (emailNotification === "true" && emailAddress !== ""){
                                    view._instance.notificationCheckbox.setChecked(true);
                                } else {
                                    view._instance.notificationCheckbox.setChecked(false);
                                }

                                // Disable the fields if not editable
                                if (user.editableUserPreferences) {
                                    var emailAddressEditable = user.editableUserPreferences.indexOf(taskEmailAddress) !== -1;
                                    var notificationEditable = user.editableUserPreferences.indexOf(taskNotification) !== -1;
                                    view._instance.notificationEditable = notificationEditable;
                                    view._instance.emailAddressInput.setEnabled(emailAddressEditable);
                                    view._instance.notificationCheckbox.setEnabled(notificationEditable && emailAddress !== "");
                                    view._instance.modalSection.setPrimaryButtonEnabled(emailAddressEditable || notificationEditable);
                                }
                            } else {
                                bpmext.log.error("Email Notification Modal", "Unable to get user info");
                            }
                        }));
                } catch (error) {
                    bpmext.log.error(error.message);
                }
            },
            _updateUserPreference: function _updateUserPreference(view) {
                bpmext.log.info("EmailNotificationModal._updateUserPreference LOG >>", view);
                try {
                    var prefs = { };
                    prefs[wpResources.user.PREFERENCE.taskEmailAddress] = view._instance.emailAddressInput.getData();
                    prefs[wpResources.user.PREFERENCE.taskNotification] = view._instance.notificationCheckbox.isChecked() ? "true" : "false";
                    wpResources.user.setPreferences({preferences: prefs});
                } catch (error) {
                    bpmext.log.error(error.message);
                }
            }
        };


        /*
        Public control methods *************************************************************
         */

         /**
         * @instance
         * @memberof EmailNotificationModal
         * @method closeModal
         * @desc Closes the modal dialog
         */
        this.constructor.prototype.closeModal = function() {
            bpmext.log.info("EmailNotificationModal.closeModal ENTER >> ",this);
            this._proto._hideModel(this);
            bpmext.log.info("EmailNotificationModal.closeModal EXIT << ");
        };

         /**
         * @instance
         * @memberof EmailNotificationModal
         * @method saveModal
         * @desc Saves the data on the dialog
         */
        this.constructor.prototype.saveModal = function() {
            bpmext.log.info("EmailNotificationModal.saveModal ENTER >> ", this);
            if (this.validateEmailAddress()) {
                this._proto._updateUserPreference(this);
                this.closeModal();
            }
            bpmext.log.info("EmailNotificationModal.saveModal EXIT << ");
        };

        /**
         * @instance
         * @memberof EmailNotificationModal
         * @method showModal
         * @desc Display the modal
         */
        this.constructor.prototype.showModal = function() {
            bpmext.log.info("EmailNotificationModal.showModal ENTER >> ", this);

            this._proto._getUserPreference(this);
            this._instance.emailAddressInput.setVisible(true);
            this._instance.notificationCheckbox.setVisible(true);
            this._instance.modalSection.setVisible(true);
            this.show();
            taskUtils.setTabCycle(this);
            bpmext.log.info("EmailNotificationModal.showModal EXIT >> ", this);
        };

         /**
         * @instance
         * @memberof EmailNotificationModal
         * @method validateEmailAddress
         * @returns {Boolean} the boolean value for the validity of the email address
         * @desc Controls the visibility of plain input and enables or disables the save button
         */
        this.constructor.prototype.validateEmailAddress = function() {
            bpmext.log.info("EmailNotificationModal.validateEmailAddress ENTER >> ", this);
            var validEmail = false;
            //Only enable save button if there is a valid email
            var validationRE = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            var emailAddressInput = this._instance.emailAddressInput;
            var emailAddressData = emailAddressInput.getData() ? emailAddressInput.getData().toLowerCase() : "";
            validEmail = emailAddressData === "" || validationRE.test(emailAddressData);
            this._instance.modalSection.setPrimaryButtonEnabled(!!validEmail);
            if (validEmail) {
                emailAddressInput.setValid(true);
            } else {
                emailAddressInput.setValid(false, bpmext.localization.formatMsg("EmailNotificationModal", "invalidEmail"));
            }
            if (this._instance.notificationEditable === true) {
                this._instance.notificationCheckbox.setEnabled(true);
                if (emailAddressData === "") {
                    this._instance.notificationCheckbox.setChecked(false);
                    this._instance.notificationCheckbox.setEnabled(false);
                }
            }

            bpmext.log.info("EmailNotificationModal.validateEmailAddress EXIT << ");
            return validEmail;
        };

        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function (){
            bpmext.log.info("EmailNotificationModal.load ENTER >>", this);

            this._instance.modalSection = bpmext.ui.getContainer("ModalSection", this);
            this._instance.modalSection.setPrimaryButtonText(bpmext.localization.formatMsg("EmailNotificationModal", "save"));
            this._instance.modalSection.setSecondaryButtonText(bpmext.localization.formatMsg("EmailNotificationModal", "cancel"));
            //CV in ModalSection
            this._instance.panel = bpmext.ui.getContainer("Panel", this);
            //CV in Panel
            this._instance.emailAddressInput = bpmext.ui.getView("EmailAddressInput", this);
            this._instance.notificationCheckbox = bpmext.ui.getView("EmailNotificationCheckbox", this);
            //Assign labels and texts to controls
            this._instance.modalSection._instance.modalDialog.ariaLabel = bpmext.localization.formatMsg("EmailNotificationModal", "emailNotification");
            this._instance.panel.setTitle(bpmext.localization.formatMsg("EmailNotificationModal", "emailNotification"));
            this._instance.emailAddressInput.setLabel(bpmext.localization.formatMsg("EmailNotificationModal", "emailAddress"));
            this._instance.notificationCheckbox.setLabel(bpmext.localization.formatMsg("EmailNotificationModal", "notificationCheckbox"));

            var panelHeaderIcon = this._instance.panel.context.element.querySelector("div.panel-heading-controls > div.panel-heading-icon > i");
            !!panelHeaderIcon && domAttr.remove(panelHeaderIcon, "tabindex");

            taskUtils.EVENTS.SET_EMAIL_NOTIFICATION.subscribe(function(eventName, eventView) {
                if (eventView === this.ui.getParent()) {
                    this.showModal();
                }
            }, this);

            // Move focus to close icon when Save is disabled
            var primaryBtn = this._instance.modalSection._instance.primaryBtn;
            var secondaryBtn = this._instance.modalSection._instance.secondaryBtn;
            var closeIcon = this._instance.panel.context.element.querySelector("div.panel-heading-controls > div.panel-heading-icon");
            secondaryBtn.onkeydown = function(event) {
                if (primaryBtn.disabled && event.key === "Tab") {
                    if (event.shiftKey) {
                        return;
                    }
                    event.preventDefault();
                    closeIcon.focus();
                }
            };

            this.loadContainer(this);

            bpmext.log.info("EmailNotificationModal.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try {
                utilities.handleVisibility(this.context);
            }
            catch (e){
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e, this);
                if(e.stack) {
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack), this);
                }
            }
        };

        this.constructor.prototype.change = function (event){
            bpmext.log.info("EmailNotificationModal.change ENTER >> (event): " + event, this);
            bpmext.log.info("EmailNotificationModal.change ENTER >>", this);
        };

        this.constructor.prototype.unload = function (){
            bpmext.log.info("EmailNotificationModal.unload ENTER >> ", this);
            bpmext.ui.unloadContainer(this);
            bpmext.log.info("EmailNotificationModal.unload ENTER >>", this);
        };
    }
};