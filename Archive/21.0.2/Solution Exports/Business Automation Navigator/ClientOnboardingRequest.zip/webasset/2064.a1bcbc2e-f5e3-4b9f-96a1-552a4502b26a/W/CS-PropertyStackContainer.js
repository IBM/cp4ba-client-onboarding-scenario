/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019 - 2020. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

cs_InitPropertyStackContainer = function(bpmext, domClass, domAttr, domStyle, messages, string, config){
	
	_includeTimePicker: true;
	_loading: false;
	_binding: null;
		
	if (!this.constructor.prototype._proto)
	{
		this.constructor.prototype._proto =
		{
			stackPanes: {
				STRING: 0,
				LONG_STRING: 1,
				DROPDOWN: 2,
				DATE: 3,
				MULTI_VALUE: 4,
			},
						
			_updateStack: function(view){
				view._loading = true;
				var stack = view.ui.getChild("PropertyStack");
				var parent = view.ui.getParent(true);
								
				if (view.context.binding){
					view._binding = view.context.binding
				}
				else if (parent.context.binding){
					var parentBinding = parent.context.binding.get("value");
						
					// view.ui.getIndex() does not reset to 0 when the parent layout is rebound to a new list.
					// Calculate the actual index to the binding value here.
					var uiIndex = view.ui.getIndex();
					if (parent._displayNew){
						parent._displayNew = false;
						parent._indexOffset = uiIndex;
					}
					var index = uiIndex - parent._indexOffset;
					view._binding = parentBinding.get(index);
				}
				if (view._binding){
					var displayOnly = parent._readOnly;
					var currentView;
					var pane = -1;
					if (view._binding.cardinality == "SINGLE"){
						value = view._binding.singleCardinalityValue;
						
						// Convert to UTC if it is a dateOnly date.
						if (view._binding.dateOnly && view._binding.singleCardinalityValue) {
							value = new Date(view._binding.singleCardinalityValue.getTime());							
						}
						
						var currentView;
						if (view._binding.choices && !displayOnly){
							pane = this.stackPanes.DROPDOWN;
							currentView = stack.getViewInPane(pane);
							if (!view._binding.required){
								currentView.appendItem("", "");
							}
							var choiceValues = view._binding.choices.choiceValues.items ? view._binding.choices.choiceValues.items : view._binding.choices.choiceValues;
							choiceValues.forEach(function(choiceItem){
								var choiceValue = choiceItem.choiceStringValue ? choiceItem.choiceStringValue : choiceItem.choiceIntegerValue;
								currentView.appendItem(choiceValue, choiceItem.displayName);
							});
							currentView.setSelectedItem(value);
						}
						else if (displayOnly ||
							view._binding.type == "STRING" ||
							view._binding.type == "GUID" ||
							view._binding.type == "LONG" ||
							view._binding.type == "DOUBLE"){
									
							if (view._binding.type == "DATE"){
								pane = this.stackPanes.DATE;
							}
							else if (view._binding.maxLength > 255){
								pane = this.stackPanes.LONG_STRING;
							}
							else{
								pane = this.stackPanes.STRING;
							}
							currentView = stack.getViewInPane(pane);
							if (value != null){
								if (view._binding.type == "DATE"){
									var includeTimePicker = !view._binding.dateOnly && view._includeTimePicker;
									currentView.context.options.includeTimePicker.set("value", includeTimePicker);																		
									currentView.setDate(value);
								}
								else if (view._binding.choices){
									var choiceValues = view._binding.choices.choiceValues.items ? view._binding.choices.choiceValues.items : view._binding.choices.choiceValues;
									var displayName;
									for (var i = 0; i < choiceValues.length; i++){
										var choice = choiceValues[i];
										if ((view._binding.type == "STRING" && choice.choiceStringValue == value) ||
											(view._binding.type == "LONG" && choice.choiceIntegerValue == value)){
											
											displayName = choice.displayName;
											break;
										}
									}
									if (displayName){
										currentView.setText(displayName);
									}
								}
								else {
									currentView.setText(value.toString());
								}								
							}
						}
						else if (view._binding.type == "BOOLEAN"){
							pane = this.stackPanes.DROPDOWN;
							currentView = stack.getViewInPane(pane);
							if (!view._binding.required){
								currentView.appendItem("", "");
							}
							currentView.appendItem("true", "True");
							currentView.appendItem("false", "False");
							if (value != null){
								currentView.setSelectedItem(value.toString());
							}
						}
						else if (view._binding.type == "DATE"){
							pane = this.stackPanes.DATE;
							currentView = stack.getViewInPane(pane);
								
							var includeTimePicker = !view._binding.dateOnly && view._includeTimePicker
							currentView.context.options.includeTimePicker.set("value", includeTimePicker);
									
							if (view._binding.minValue){
								var minDate = new Date(view._binding.minValue);
								currentView.setStart(minDate);
							}
							if (view._binding.maxValue){
								var maxDate = new Date(view._binding.maxValue);
								currentView.setEnd(maxDate);
							}
							currentView.setDate(value);
						}

						if (view._binding.readOnly || displayOnly){
							stack.context.options._metadata.visibility.set("value", "READONLY");
						}
						else if (view._binding.required){
							stack.context.options._metadata.visibility.set("value", "REQUIRED");
						}
						
						if (!view._binding.readOnly && !displayOnly && parent._setFocus){
							setTimeout(function(){
								currentView.focus();
							}, 300);
							parent._setFocus = false;
						}
						
						var label = view._binding.label;
						currentView.setLabel(label);
					} else if (view._binding.cardinality == "LIST") {
						pane = this.stackPanes.MULTI_VALUE;
						currentView = stack.getViewInPane(pane);
						
						// Set binding if not already set.
						if (!currentView.context.binding){
							var listCardinalityValues = view._binding.listCardinalityValues.items ? view._binding.listCardinalityValues.items : view._binding.listCardinalityValues;
							currentView.setViewData(listCardinalityValues, true);
						}
						
						var label = document.createElement("span");
						domClass.add(label, "control-label CS_MultiValuePropertyLabel");
						var labelText = document.createTextNode(view._binding.label);
						label.appendChild(labelText);
						currentView.context.element.insertBefore(label, currentView.context.element.firstChild);
						
						if (view._binding.required){
							var requiredMark = document.createElement("span");
							var requiredText = document.createTextNode("* ");
							requiredMark.appendChild(requiredText);
							domClass.add(requiredMark, "CS_RequiredMark");
							currentView.context.element.insertBefore(requiredMark, label);
						}
						
						if (!view._binding.disabled && !displayOnly){						
							this._createAddButton(view, currentView, view._binding);	
						}
						
						var choices = null;
						if (view._binding.choices){
							choices = view._binding.choices.choiceValues.items ? view._binding.choices.choiceValues.items : view._binding.choices.choiceValues;
						}
						var multiValueData = {
							dataType: view._binding.type,
							disabled: view._binding.disabled,
							choices: choices,
							maxLength: view._binding.maxLength,
							minValue: view._binding.minValue,
							maxValue: view._binding.maxValue,
							uniqueValues: view._binding.requiresUniqueElements,
							includeTimePicker: view._includeTimePicker,
							displayOnly: displayOnly,
							deleteOffset: 0, 
							propertyName: view._binding.label,
							dateOnly: view._binding.dateOnly
						}
						currentView._multiValueData = multiValueData;
					}
					if (view._binding.disabled){
						domClass.add(view.context.element, "CS_PropertyDisabled");
					}
					domAttr.set(currentView.context.element, "propertyId", view._binding.id);
				}
				stack.setCurrentPane(pane);
				var paneCount = stack.getPaneCount();
				for (var i = paneCount - 1; i >= 0; i--){
					if (i != pane){
						var viewInPane = stack.getViewInPane(i);
						var viewDiv = viewInPane.context.element;
						stack.context.deleteView(viewDiv);
						viewDiv.parentNode.removeChild(viewDiv);
					}
				}
				view._loading = false;
			},
			
			_createAddButton: function(view, layoutView){
				// Add the button after the label.
				var addButton = document.createElement("div");	
				domClass.add(addButton, "CS_PropertyListIconButton");
				domAttr.set(addButton, "tabindex", "0");
				layoutView.context.element.insertBefore(addButton, layoutView.context.element.firstChild.nextSibling)
				
				var icon = document.createElement("i");
				domClass.add(icon, "fa fa-plus CS_MVCPIconButton");
				domAttr.set(icon, "alt", "Add");
				addButton.href = "javascript:void(0)";
				addButton.appendChild(icon);				
				domAttr.set(addButton, "title", string.substitute(messages.properties_add_mvcp, [view._binding.label]));

				var _this = this;
				addButton.onclick = function() {
					_this._addItem(view, layoutView);
				}
				addButton.addEventListener('keypress', function(evt) {
					var keyID = (evt.charCode) ? evt.charCode : ((evt.which) ? evt.which : evt.keyCode);
					if(keyID == 13 || keyID == 32){
						if(!domClass.contains(this, "disabled"))
						{
							_this._addItem(view, layoutView);
						}
						evt.preventDefault();
					}
					return true;
				});
			},
			
			_addItem: function(view, layoutView){
				var choices = null;
				if (view._binding.choices){
					choices = view._binding.choices.choiceValues.items ? view._binding.choices.choiceValues.items : view._binding.choices.choiceValues;
				}	
					
				var newValue;
				if (choices){
					newValue = choices[0].choiceStringValue ? choices[0].choiceStringValue : choices[0].choiceIntegerValue;
				}
				else {						
					switch (view._binding.type){
						case "STRING":
						case "GUID":
						case "LONG":
						case "DOUBLE":
							newValue = "";
							break;
						case "BOOLEAN":
							newValue = false;
							break;
						case "DATE":
							newValue = new Date();
							if (view._binding.dateOnly){
								newValue.setHours(12);
								var timezoneOffset = newValue.getTimezoneOffset();
								newValue.setMinutes(-timezoneOffset, 0, 0);
							}
							else if (!view._includeTimePicker){
								newValue.setHours(0, 0, 0, 0);
							}
							break;		
					}
				}
		
				var layoutBinding = layoutView.context.binding.get("value");
				layoutBinding.add(newValue);
			},
			
			_getPropertyValue: function(view, forJson){
				if (!view._binding.disabled || forJson){
					var stack = view.ui.getChild("PropertyStack");
					if (stack){	
						var currentPane = stack.getCurrentPane();
						if (currentPane != null && currentPane > -1){
							var currentView = stack.getViewInPane(0);
							var propertyId = domAttr.get(currentView.context.element, "propertyId");
							var dataType = view._binding.type;
							var cardinality = view._binding.cardinality;
							var hierChoices = view._binding.hierChoices;
							
							// Property value format is different for service that it is for just plain json
							var propertyString;
							if (forJson) {
								propertyString = "{\"" + propertyId + "\": ";
							} else {
								propertyString = "{" + propertyId + ": ";
							}

							if (cardinality == "SINGLE"){
								if (currentView.getText){
									var value = currentView.getText();
									if ((dataType == "GUID" || dataType == "LONG" || dataType == "DOUBLE" || (dataType == "STRING" && hierChoices)) && value.length < 1){
										propertyString += null;
									}
									else if (dataType == "STRING" || dataType == "GUID"){
										var sanitizedValue = value.replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/\t/g,'\\t').replace(/"/g,'\\"').replace(/\r/g,'\\r');
										propertyString += "\"" + sanitizedValue + "\"";
									}
									else {
										propertyString += value;
									}
								}
								else if (currentView.getSelectedItem){
									var value = currentView.getSelectedItem();
									if (dataType == "STRING" && value && value.length > 0){
										propertyString += "\"" + value + "\"";
									}
									else {
										if (dataType == "BOOLEAN" && value == ""){
											value = null;
										} else if ((dataType == "LONG" || dataType == "DOUBLE") && value == ""){
											value = null;
										}
										propertyString += value;
									}				
								}
								else if (currentView.getDate){
									var value = currentView.getDate();
									if (value.length == 0){
										propertyString += null;
									}
									else{
										var dateValue = new Date(value);
										
										if (view._binding.dateOnly) {
											var newValue = dateValue;
											newValue.setHours(12);
											var timezoneOffset = newValue.getTimezoneOffset();
											newValue.setMinutes(-timezoneOffset, 0, 0);
											
											if (view._binding.singleCardinalityValue) {
												var oldValue = new Date(view._binding.singleCardinalityValue.getTime());
												
												// Only save date only values if the user made a change.
												if (newValue.getYear() != oldValue.getYear() ||
													newValue.getMonth() != oldValue.getMonth() ||
													newValue.getDate() != oldValue.getDate()) {
														
													dateValue = newValue;
												}
												else {
													dateValue = oldValue;
												}
											}
											else {
												dateValue = newValue;
											}
										}
										propertyString += "\"" + dateValue.toISOString() + "\"";
									}
								}
							}					
							else if (cardinality == "LIST"){
								// Get the list from the vertical layout binding.
								var list = currentView.context.binding.get("value");
								propertyString +="[";
								var firstValue = true;
								for (var multiValueStackIndex = 0; ; multiValueStackIndex ++){
									var stackContainer = currentView.ui.getChild("CSMultiValuePropertyStackContainer", multiValueStackIndex);
									if (!stackContainer){
										break;
									}
									var value = stackContainer.getPropertyValue();
									if (value == null || (value && value.length && value.length < 1)){
										continue;
									}
									
									if (!firstValue){
										propertyString += ",";
									}
									firstValue = false;
									propertyString += value;
								}
								propertyString +="]";
							}	
							return propertyString + "}";
						}
					}
				}
			},
			
			_validate: function(view){
				var isValid = true;
				var errorMessage = "";
				
				var stack = view.ui.getChild("PropertyStack");
				var currentPane = stack.getCurrentPane();		
				if (currentPane != null && currentPane > -1){
					var currentView = stack.getViewInPane(0);
					if (currentPane != this.stackPanes.MULTI_VALUE){
						if (currentView.isValid){
							isValid = currentView.isValid();
						}
						if (!isValid){
							currentView.context.element.scrollIntoView(true);
						}
					}
					// Multi value
					else {
						binding = currentView.context.binding.get("value");
						var uniqueValues = {};
						for (var i = 0; i < binding.items.length; i++){
							multiStackContainer = currentView.ui.getChild("CSMultiValuePropertyStackContainer", i);
							isValid = multiStackContainer.isValid();
							if (!isValid){
								break;							
							}

							if (isValid && view._binding.requiresUniqueElements){
								var errorDiv = multiStackContainer.context.element.querySelector(".CS_ValidationMessage");
								var value = multiStackContainer.getPropertyValue();
								var multiValueStack = multiStackContainer.ui.getChild("MultiValuePropertyStack");
								var multiStackPane = multiValueStack.getCurrentPane();
								var multiStackView = multiValueStack.getViewInPane(0);
								if (uniqueValues[value]){
									var errorMessage = messages.properties_unique_value_required;
								}
								var childNode = errorDiv.childNodes ? errorDiv.childNodes[0] : null;
								if (childNode){
									childNode.nodeValue = "";
								}
								else {
									childNode = document.createTextNode("");
									errorDiv.appendChild(childNode);	
								}
								if (errorMessage.length > 0){
									if (multiStackView.setValid){
										multiStackView.setValid(false, errorMessage);
									}
									childNode.nodeValue = errorMessage;
									domStyle.set(errorDiv, "display", "block");
									isValid = false;
									multiStackView.context.element.scrollIntoView(true);
								}
								else {
									uniqueValues[value] = true;
									if (multiStackView.setValid){
										multiStackView.setValid(true);
									}
									domStyle.set(errorDiv, "display", "none");
								}
							}
						}
					}
					
					if (isValid && view._binding.required){						
						// Check for required.
						var value;
						if (currentView.getText){
							value = currentView.getText();
						}
						else if (currentView.getSelectedItem){
							value = currentView.getSelectedItem();
						}
						else if (currentView.getDate){
							value = currentView.getDate();
						}
						else if (view._binding.cardinality == "LIST"){
							binding = currentView.context.binding.get("value"); 
							for (var i = 0; i < binding.items.length; i++){
								multiStackContainer = currentView.ui.getChild("CSMultiValuePropertyStackContainer", i);
								if (multiStackContainer){
									var value = stackContainer.getPropertyValue();
									if (value != null || (value && value.length && value.length > 0)){
										break;
									}
								}
							}
						}
						
						var errorDiv = view.context.element.querySelector(".CS_SingleValueValidationMessage");
						var childNode = errorDiv.childNodes ? errorDiv.childNodes[0] : null;
						if (childNode){
							childNode.nodeValue = "";
						}
						else {
							childNode = document.createTextNode("");
							errorDiv.appendChild(childNode);	
						}
						if (value == null || value.toString().length < 1){
							errorMessage = messages.properties_value_required;
						}
						
						childNode.nodeValue = errorMessage;
						if (errorMessage.length > 0){
							if (currentView.setValid){
								currentView.setValid(false, errorMessage);
							}
							domStyle.set(errorDiv, "display", "block");
							currentView.context.element.scrollIntoView(true);
							isValid = false;							
						}
						else {
							domStyle.set(errorDiv, "display", "none");
						}						
					}
				}
								
				return isValid;
			},

			_validateValue(view, validationData){

				var validationMessage = "";
				
				if (!validationData.minValue && validationData.dataType == "LONG"){
					validationData.minValue = -9223372036854775808;
				}
				if (!validationData.maxValue && validationData.dataType == "LONG"){
					validationData.maxValue = 9223372036854775807;
				}
				
				if (validationData.value.toString().length > 0){
					switch(validationData.dataType){
						case "LONG":
						case "DOUBLE":
						var match = validationData.dataType == "LONG" ? 
							validationData.value.match('^[+-]?[0-9]+$') : 
							validationData.value.match('^[+-]?([0-9]*[' + this._getDecimalPoint(view) + '])?[0-9]+$');

						if (match === null){
							validationMessage = validationData.dataType == "LONG" ? messages.properties_invalid_long_value : messages.properties_invalid_float_value;
						}
						else {
							var numericValue = validationData.dataType == "LONG" ? parseInt(validationData.value, 10) : parseFloat(validationData.value);
							if (validationData.minValue && numericValue < validationData.minValue){
								validationMessage = string.substitute(messages.properties_min_value, [validationData.minValue]);									
							}
							else if (validationData.maxValue && numericValue > validationData.maxValue){
								validationMessage = string.substitute(messages.properties_max_value, [validationData.maxValue]);
							}
						}
						break;
						case "STRING":
							if (validationData.maxLength > 0 && validationData.value.length > validationData.maxLength){
								validationMessage = string.substitute(messages.properties_max_length, [validationData.maxLength]);
							}							
							else if (validationData.id == "FolderName" && /[\\\/:*?"<>|]/.test(validationData.value)){
								validationMessage = string.substitute(messages.properties_invalid_folder_name);
							}
							break;
						case "GUID":
							var match = validationData.value.match('^\{[a-fA-F0-9]{8}\-[a-fA-F0-9]{4}\-[a-fA-F0-9]{4}\-[a-fA-F0-9]{4}\-[a-fA-F0-9]{12}\}$');
							if (match === null){
								validationMessage = messages.properties_invalid_guid;
							}
							break;
					}
				}
				else {
					if (validationData.required){
						validationMessage = messages.properties_value_required;
					}
				}
				
				var childNode = validationData.errorDiv.childNodes ? validationData.errorDiv.childNodes[0] : null;
				if (childNode){
					childNode.nodeValue = "";
				}
				else {
					childNode = document.createTextNode("");
					validationData.errorDiv.appendChild(childNode);	
				}
				if (validationMessage.length > 0){
					if (validationData.view.setValid){
						setTimeout(function(){
							validationData.view.setValid(false, validationMessage);
						}, 100);
					}
					childNode.nodeValue = validationMessage;
					domStyle.set(validationData.errorDiv, "display", "block");
				}
				else {
					if (validationData.view.setValid){
						validationData.view.setValid(true);
					}
					domStyle.set(validationData.errorDiv, "display", "none");
				}
			},
			
			_getDecimalPoint: function(view) {
				return this._numberBundle["decimal"] || ".";
			}
		},
		
		this.constructor.prototype.onPropertyValueChange = function (newValue){
			if (!this._loading){
				var stack = this.ui.getChild("PropertyStack");
				var currentPane = stack.getCurrentPane();
				var errorDiv = this.context.element.querySelector(".CS_SingleValueValidationMessage");
				if (currentPane != null && currentPane > -1){
					currentView = stack.getViewInPane(0);
					var validationData = {
						id: this._binding.id,
						value: newValue,
						minValue: this._binding.minValue,
						maxValue: this._binding.maxValue,
						maxLength: this._binding.maxLength,
						dataType: this._binding.type,
						required: this._binding.required,
						view: currentView,
						errorDiv: errorDiv
					}
					this._proto._validateValue(this, validationData);
					var stackLayout = this.ui.getAncestor("StackLayout", true);
					var propertyList = stackLayout.ui.getParent();
					propertyList._propertyChanged();
				}
			}
		}
		
		this.constructor.prototype.change = function (event){
			try	{
				var view = this;
				if (event.type == "config")	{
//					this._proto._updateStack(this);
				} else if (event.type == "binding") {
					this._proto._updateStack(this);
				}
			} catch (e) {
				bpmext.log.error("Error on change event [" + this.ui.getAbsoluteName() + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		}

		this.constructor.prototype.load = function (){
			try	{
				this._proto._numberBundle = dojo.i18n.getLocalization("dojo.cldr", "number", config.locale);
				var stackLayout = this.ui.getAncestor("StackLayout", true);
				if (stackLayout){
					var propertyList = stackLayout.ui.getParent();
					this._includeTimePicker = propertyList.context.options.hideTimePicker ? !propertyList.context.options.hideTimePicker.get("value") : true;
				}
				this._proto._updateStack(this);
			} catch (e) {
				bpmext.log.error("Error on load event [" + this.context.viewid + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		}
		
		this.constructor.prototype.setSVCPInputValue = function(newValue, disabled){
			var stack = this.ui.getChild("PropertyStack");
			if (stack){
				var currentPane = stack.getCurrentPane();
				if (currentPane != null && currentPane > -1){
					var currentView = stack.getViewInPane(0);
					if (currentView.setText){
						currentView.setText(newValue);
					} else if (currentView.setSelectedItem){
						currentView.setSelectedItem(newValue.toString())						
					}
					else if (currentView.setDate){
						currentView.setDate(value);
					}
					disabled ? stack.context.options._metadata.visibility.set("value", "READONLY") : stack.context.options._metadata.visibility.set("value", "DEFAULT");
				}
			}
		}
		
		this.constructor.prototype.getSVCPInputValue = function(){
			var value;
			var stack = this.ui.getChild("PropertyStack");
			if (stack){
				var currentPane = stack.getCurrentPane();
				if (currentPane != null && currentPane > -1){
					var currentView = stack.getViewInPane(0);
					if (currentView.getText){
						value = currentView.getText();
					} else if (currentView.getSelectedItem){
						value = currentView.getSelectedItem()						
					}
					else if (currentView.getDate){
						value = currentView.getDate();
					}
				}
			}
			return value;
		}
		
		this.constructor.prototype.getPropertyId = function(){
			propertyId = null;
			var stack = this.ui.getChild("PropertyStack");
			if (stack){
				var currentPane = stack.getCurrentPane();
				if (currentPane != null && currentPane > -1){
					var currentView = stack.getViewInPane(0);
					var propertyId = domAttr.get(currentView.context.element, "propertyId");
				}
			}
			return propertyId;
		}
		
		this.constructor.prototype.isValid = function(){
			return this._proto._validate(this);
		}
		
		this.constructor.prototype.getPropertyValue = function(forJson){
			return this._proto._getPropertyValue(this, forJson);
		}

		this.constructor.prototype.view = function (){
		}
	}			
}