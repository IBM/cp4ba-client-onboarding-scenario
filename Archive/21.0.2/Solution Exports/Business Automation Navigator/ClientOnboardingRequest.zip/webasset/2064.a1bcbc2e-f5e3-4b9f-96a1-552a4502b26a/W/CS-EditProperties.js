/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

cs_InitEditProperties = function (utilities, bpmext, domClass, domStyle, domAttr, messages, string)
{
	this._instance = {
		serverConfigurationName: "GRAPHQL_APP_RESOURCE",
		objectStoreName: null,
		hideTimePicker: null,
		actionName: null,
		contentItem: null,
		callback: null,
		errback: null
	};

	if (!this.constructor.prototype._proto)	{
		
		this.constructor.prototype._proto =	{
			EVT_ONSAVEPROPERTIES: "eventON_SAVEPROPERTIES",
			EVT_ONCANCEL: "eventON_CANCEL",
			EVT_ONERROR: "eventON_ERROR",

			typeDocument: "Document",
			typeFolder: "Folder",
			typeAbstract: "Abstract",
			
			privilegeToBitmask: {
				"privEditProperties": 0x2,
				"privAddToFolder": 0x10,
				"privViewDoc": 0x80,
				"privDelete": 0x10000,
				"privMajorVersion": 0x4,
				"privMinorVersion": 0x40,
				"privAddItem": 0x100,
			},	

			actions: {
				documentProperties: "DocumentProperties",			
				folderProperties: "FolderProperties",
				abstractProperties: "AbstractProperties",
			},

			_handleVisibility: function (view) {
				var vis = utilities.handleVisibility(view.context);
			},
			
			_setVisibilityOfControl: function (control, vis) {
				control.context.options["_metadata"].visibility.set("value", vis);
				control.context.setDisplay(vis != "NONE");
				control.context.setVisibility(vis != "HIDDEN");
			},
			
			_setAlertMessage: function(view, message, isError, delay) {
				var title = messages.contlist_progress_success;
				var style = "S";
				if (isError) {
					title = messages.contlist_progress_alert;
					style = "D";
				}
				// Call out to the CS_Alert utility class to handle displaying the alert message
				setAlertMessage(title, message, style, delay, domClass, domStyle, domAttr, messages);
			},
			
			_setModalAlertMessage: function(view, modalAlert, modalAlertId, message, isError, delay) {
				var title = messages.contlist_progress_success;
				var style = "S";
				if (isError) {
					title = messages.contlist_progress_alert;
					style = "D";
				}
				// Call out to the CS_Alert utility class to handle displaying the alert message
				var alertDiv = setAlertMessage(title, message, style, delay, domClass, domStyle, domAttr, messages);
				
				setTimeout(function(){
					alertDiv.scrollIntoView(true);
				}, 300);	
			},
	
			_getType: function(contentItem) {
				var type;
				if (contentItem.baseType) {
					type = contentItem.baseType;
				} else if (contentItem.isFolder) {
					type = this.typeFolder;
				} else {
					type = this.typeDocument;
				}
				return type;
			},
	
			/**
			 * Helper function to retrieve the Object Store Name as defined in ACCE admin tool. This is the 
			 * string that will be passed to all the graphql action services since it's working against CE
			 * and not ICN).
			 */
			_getObjectStoreName: function(view) {
				var objectStoreName = view.context.options.objectStoreName.get("value");
				if (view._instance.objectStoreName) {
					objectStoreName = view._instance.objectStoreName;
				}
				return objectStoreName;
			},

			_showHidePropertiesModal: function (view, isVisible, contentItem, callback, errback) {
				console.log("CS-EditProperties:_showHidePropertiesModal() : Show properties modal, isVisible: " + isVisible);
				
				view._instance.propertiesModal = view.ui.get("PropertiesModal");
				view._instance.propertiesPanel = view.ui.get("PropertiesPanel");
				view._instance.propertiesTable = view.ui.get("PropertiesTable");
				view._instance.savePropertiesBtn = view.ui.get("SaveButton");
				
				view._instance.propertiesModal.setVisible(isVisible);
				view._instance.propertiesTable.setVisible(isVisible);	
				
				if (isVisible == true) {
					view._instance.callback = callback; 
					view._instance.errback = errback; 

					if (view._instance.hideTimePicker !== null) {
						view._instance.propertiesTable.setIncludeTimePicker(!view._instance.hideTimePicker);
					} else {
						view._instance.propertiesTable.setIncludeTimePicker(!view.context.options.hideTimePicker.get("value"));
					}

					view._instance.propertiesTable.setServerConfigurationName(view._instance.serverConfigurationName);
					view._instance.propertiesTable.setObjectStoreName(this._getObjectStoreName(view));
					
					view._instance.savePropertiesBtn.setVisible(true);
					view._instance.savePropertiesBtn.setEnabled(true);
					
					view._instance.contentItem = contentItem;
					
					var label = '';
					var baseType = contentItem.baseType;
					if (baseType == this.typeDocument) {
						label = messages.contlist_document_properties;
					} else if (baseType == this.typeFolder) {
						label = messages.contlist_folder_properties;
					} else {
						if (contentItem.className == "DbaClassificationBatch") {
							label = messages.contlist_batch_properties;
						} else {
							label = messages.contlist_abstract_properties;
						}
					}
					view._instance.propertiesPanel.context.options._metadata.label.set('value', label);

					var self = this;
					var canEditProperties = view._canEditProperties(contentItem);
					view._instance.propertiesTable.setReadOnly(!canEditProperties);
					
					this._setPropertyListMaxHeight(view, view._instance.propertiesModal, view._instance.propertiesTable);
					
					view._instance.propertiesTable.displayProperties(contentItem.id, contentItem.className, baseType, null, function(error) {
						var errorText = error ? error : "";
						var errMessage = string.substitute(messages.contlist_display_properties_failed, [errorText]);
						self._setModalAlertMessage(view, view._instance.propertiesAlert, "PropertiesAlert", errMessage, true);
					});
				}
				else {
					view._instance.propertiesTable.clear();
				}	
			},

			_onCancelBtnClicked: function(view) {
				view._instance.propertiesModal = view.ui.get("PropertiesModal");
				view._instance.propertiesTable = view.ui.get("PropertiesTable");
				
				view._instance.propertiesModal.setVisible(false);
				view._instance.propertiesTable.setVisible(false);

				bpmext.ui.executeEventHandlingFunction(view, this.EVT_ONCANCEL);
			},
			
			_setPropertyListMaxHeight: function(view, modalSection, propertyList) {
				var modalContent = modalSection.context.element.querySelector(".modal-dialog");
				var modalHeight = modalContent.offsetHeight;
				var modalStyle = window.getComputedStyle(modalContent);
				modalHeight += (parseInt(modalStyle.getPropertyValue('margin-top')) + parseInt(modalStyle.getPropertyValue('margin-bottom')));
				
				var parentHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
				var parentStyle = window.getComputedStyle(view.context.element);
				parentHeight += (parseInt(parentStyle.getPropertyValue('margin-top')) + parseInt(parentStyle.getPropertyValue('margin-bottom')));
				
				var availableHeight = window.innerHeight < parentHeight ? window.innerHeight : parentHeight;
				availableHeight -= (modalHeight - propertyList.context.element.clientHeight);
				domStyle.set(propertyList.context.element, "max-height", availableHeight + "px");
			}, 

			_onSavePropertiesBtnClicked: function(view) {
				console.log("CS-EditProperties:_onSavePropertiesBtnClicked()");

				var self = this;
				view._instance.propertiesTable = view.ui.get("PropertiesTable");

				var contentItem = view._instance.contentItem;
				var properties = contentItem.properties.items ? contentItem.properties.items : contentItem.properties;
				var returnProperties = [];
				var objectProperties = [];
				
				properties.forEach(function(property) {
					returnProperties.push(property.id);
					if (property.objectValue) {
						var ovpProperties = property.objectValue.properties.items ? property.objectValue.properties.items : property.objectValue.properties;
						ovpProperties.forEach(function(objectProperty) {
							objectProperties.push(objectProperty.id);
						});
					}
				});			
				
				var isValid = view._instance.propertiesTable.save(returnProperties, objectProperties, true, function(properties) {
					self._showHidePropertiesModal(view, false, '');
					self._setAlertMessage(view, messages.contlist_save_props_success, false);

					var updatedContentItem = self._updateContentItem(contentItem, properties);
					var callback = view._instance.callback;
					if (callback) {
						callback(updatedContentItem);
					}
					bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONSAVEPROPERTIES, updatedContentItem);

				}, function(errorText) {
					// Show error in an alert box at top of properties dialog
					self._setModalAlertMessage(view, view._instance.propertiesAlert, "PropertiesAlert", messages.contlist_save_props_failed, true);
					view._instance.savePropertiesBtn.setEnabled(true);
				});

				if (isValid) {
					view._instance.savePropertiesBtn.setEnabled(false);
				} else {
					// There was a validation problem and save call never made
					// Todo: should we display a message or are the controls themselves enough?
				}
			},
			
			_updateContentItem: function(contentItem, properties) {
				var newContentItem = {
					baseType: contentItem.baseType,
					isFolder: contentItem.isFolder,
					properties: properties
				};
				if (contentItem.className) {
					newContentItem.className = contentItem.className;
				}
				if (contentItem.accessAllowed) {
					newContentItem.accessAllowed = contentItem.accessAllowed;
				}
				if (contentItem.contentElements != null) {
					newContentItem.contentElements = contentItem.contentElements;
				}
				if (contentItem.cmThumbnails != null) {
					newContentItem.cmThumbnails = contentItem.cmThumbnails;
				}

				// Dig some properties out of the property bag and make first class properties
				for (var i = 0; i < properties.length; i++) {
					var property = properties[i];
					if (property.id == "Id") {
						newContentItem.id = property.value;
					} else if (property.id == "Name") {
						newContentItem.name = property.value;
					} else if (property.id == "MimeType") {
						newContentItem.mimeType = property.value;
					} else if (property.id == "IsReserved") {
						newContentItem.isReserved = property.value;
					}
				} 
				return newContentItem;
			}
			
		};

		/*
		 * Private methods and event handlers *************************************************************
		 */
		 
		this.constructor.prototype._canEditProperties = function(contentItem) {
			if (contentItem && contentItem.accessAllowed) {
				var canEditProperties = (contentItem.accessAllowed & this._proto.privilegeToBitmask["privEditProperties"]) > 0;
				return canEditProperties;
			} else {
				return false;
			}
		};

		/*
		 * Public control methods *************************************************************
		 */

		/**
		 * @instance
		 * @memberof CSEditProperties
		 * @method setHideTimePicker
		 * @desc Controls the display of the time picker when editing date properties.
		 * @param {boolean} hideTimePicker Flag that determines whether the time picker is displayed when editing dates.
		 */
		this.constructor.prototype.setHideTimePicker = function(hideTimePicker) {
			this._instance.hideTimePicker = hideTimePicker;
		};

		/**
		 * @instance
		 * @memberof CSEditProperties
		 * @method editProperties
		 * @param contentItem object for which you would like to dplay properties
		 * @desc Updates the properties of an object in the repository
		 * @returns 
		 */
		this.constructor.prototype.editProperties = function(contentItem, callback, errback) {
			if (contentItem) {
				this._proto._showHidePropertiesModal(this, true, contentItem, callback, errback);
			} else {
				console.log("CS-EditProperties:editProperties() : Error contentItem parameter is null.");
				if (errback) {
					errback("Error contentItem parameter is null.");
				}
			}
		};

		/*
		 * Coach NG Lifecycle methods *************************************************************
		 */
		 
		this.constructor.prototype.load = function() {
			console.log("CS-EditProperties:load() : called from: " + this.context.viewid);
			try	{
				var opts = this.context.options;
				var mdt = opts._metadata;

				if (!opts.objectStoreName) {
                    opts.objectStoreName = bpmext.ui.substituteConfigOption(this, "objectStoreName", null);
				}

				if (!opts.hideTimePicker) {
					opts.hideTimePicker = bpmext.ui.substituteConfigOption(this, "hideTimePicker", false);
				}
			
				domClass.add(this.context.element, "CS_EditPropertiesModal");
				
  				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONSAVEPROPERTIES, "contentItem");
				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONCANCEL);
				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONERROR, "message");

				bpmext.ui.loadView(this);			
				
			} catch (e) {
				bpmext.log.error("Error on load event [" + this.context.viewid + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};

		this.constructor.prototype.view = function () {
			console.log("CS-EditProperties:view() : called from: " + this.context.viewid);
            try {
//				this._proto._handleVisibility(this);
 			} catch (e) {
                bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                if (e.stack) {
                    bpmext.log.error("  Call stack: " + e.stack);
				}
            }
        };

		this.constructor.prototype.change = function(event)	{
			console.log("CS-EditProperties:change() : called from: " + this.context.viewid);
			try	{
				var view = this;
				if (event.type == "config")	{
					// NA
				} else {
					if (this.context.binding && event.newVal && event.newVal.id) {
						var boundObject = this.context.binding.boundObject;
						if (boundObject != null) {
														
						}
					}
				}
			} catch (e) {
				bpmext.log.error("Error on change event [" + this.ui.getAbsoluteName() + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};
	}
}	
