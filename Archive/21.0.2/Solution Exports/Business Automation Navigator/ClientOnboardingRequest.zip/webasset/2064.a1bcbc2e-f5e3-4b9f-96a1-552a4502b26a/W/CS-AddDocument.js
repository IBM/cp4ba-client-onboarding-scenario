/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

cs_InitAddDocument = function (utilities, bpmext, domClass, domStyle, domAttr, messages, string)
{
	this._instance = {
		serverConfigurationName: "GRAPHQL_APP_RESOURCE",
		inUpdateDocument: false,
		objectStoreName: null,
		documentClasses: null,
		hideTimePicker: null,
		acceptFileTypes: null,
		displayProgressIndicator: false,
		pollingEnabled: false,
		parentFolderId: null,
		batchId: null
	};

	if (!this.constructor.prototype._proto)	{
		
		this.constructor.prototype._proto =	{
			EVT_ONADD: "eventON_ADD",
			EVT_ONCANCEL: "eventON_CANCEL",
			EVT_ONERROR: "eventON_ERROR",

			_handleVisibility: function (view) {
				var vis = utilities.handleVisibility(view.context);
			},
			
			_setVisibilityOfControl: function (control, vis) {
				control.context.options["_metadata"].visibility.set("value", vis);
				control.context.setDisplay(vis != "NONE");
				control.context.setVisibility(vis != "HIDDEN");
			},
			
			_setAlertMessage: function(view, message, isError, delay) {
				var title = messages.contlist_progress_success;
				var style = "S";
				if (isError) {
					title = messages.contlist_progress_alert;
					style = "D";
				}
				// Call out to the CS_Alert utility class to handle displaying the alert message
				setAlertMessage(title, message, style, delay, domClass, domStyle, domAttr, messages);
			},
			
			_setModalAlertMessage: function(view, modalAlert, modalAlertId, message, isError, delay) {
				var title = messages.contlist_progress_success;
				var style = "S";
				if (isError) {
					title = messages.contlist_progress_alert;
					style = "D";
				}
				// Call out to the CS_Alert utility class to handle displaying the alert message
				var alertDiv = setAlertMessage(title, message, style, delay, domClass, domStyle, domAttr, messages);
				
				setTimeout(function(){
					alertDiv.scrollIntoView(true);
				}, 300);	
			},
			
			/**
			 * Helper function to retrieve the Object Store Name as defined in ACCE admin tool. This is the 
			 * string that will be passed to all the graphql action services since it's working against CE
			 * and not ICN).
			 */
			_getObjectStoreName: function(view) {
				var objectStoreName = view.context.options.objectStoreName.get("value");
				if (view._instance.objectStoreName) {
					objectStoreName = view._instance.objectStoreName;
				}
				return objectStoreName;
			},
			
			_showHideAddDocumentModal: function (view, isVisible, parentFolderId, files, parentName, callback, errback) {
				console.log("CS-AddDocument:_showHideAddDocumentModal() : Show add document modal");
				
				view._instance.addDocumentModal = view.ui.get("AddDocumentModal");
				view._instance.addDocumentPanel = view.ui.get("AddDocumentPanel");
				view._instance.addDocumentProps = view.ui.get("ContentProperties");
				view._instance.addDocumentBtn = view.ui.get("AddButton");
				
				view._instance.addDocumentModal.setVisible(isVisible);
				view._instance.addDocumentProps.setVisible(isVisible);
				if (isVisible == true) {
					view._instance.callback = callback; 
					view._instance.errback = errback; 

					if (view._instance.documentClasses) {
						view._instance.addDocumentProps.setDocumentClasses(view._instance.documentClasses);
					} else {
						view._instance.addDocumentProps.setDocumentClasses(view.context.options.documentClasses.get("value"));
					}
					
					if (view._instance.acceptFileTypes) {
						view._instance.addDocumentProps.setFileTypes(view._instance.acceptFileTypes);
					} else {
						acceptFileTypes = view.context.options.acceptFileTypes.get("value");
						if (acceptFileTypes && acceptFileTypes.items) {
							view._instance.addDocumentProps.setFileTypes(acceptFileTypes.items);
						}
					}
					
					if (view._instance.hideTimePicker !== null) {
						view._instance.addDocumentProps.setIncludeTimePicker(!view._instance.hideTimePicker);
					} else {
						view._instance.addDocumentProps.setIncludeTimePicker(!view.context.options.hideTimePicker.get("value"));
					}
					
					view._instance.addDocumentProps.setServerConfigurationName(view._instance.serverConfigurationName);
					view._instance.addDocumentProps.setObjectStoreName(this._getObjectStoreName(view));
					
					view._instance.addDocumentBtn.setVisible(true);
					view._instance.addDocumentBtn.setEnabled(true);
					
					var	label = messages.contlist_menu_action_add_doc;						
					view._instance.addDocumentPanel.context.options._metadata.label.set('value', label);					
					this._setPropertyListMaxHeight(view, view._instance.addDocumentModal, view._instance.addDocumentProps);
					
					var batchId = view._instance.batchId;
					
					var _self = this;
					view._instance.addDocumentProps.newDocument(parentFolderId, function(error) {
						// Show error in an alert box at top of add dialog
						var errorText = error ? error : "";
						_self._setModalAlertMessage(view, view._instance.addDocumentAlert, "AddDocumentAlert", string.substitute(messages.contlist_add_document_failed, [errorText]), true);
					},  files, parentName, batchId);
				} else {
					view._instance.addDocumentProps.clear();
				}
			},
	
			_setPropertyListMaxHeight: function(view, modalSection, propertyList) {
				var modalContent = modalSection.context.element.querySelector(".modal-dialog");
				var modalHeight = modalContent.offsetHeight;
				var modalStyle = window.getComputedStyle(modalContent);
				modalHeight += (parseInt(modalStyle.getPropertyValue('margin-top')) + parseInt(modalStyle.getPropertyValue('margin-bottom')));
				
				var parentHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
				var parentStyle = window.getComputedStyle(view.context.element);
				parentHeight += (parseInt(parentStyle.getPropertyValue('margin-top')) + parseInt(parentStyle.getPropertyValue('margin-bottom')));
				
				var availableHeight = window.innerHeight < parentHeight ? window.innerHeight : parentHeight;
				availableHeight -= (modalHeight - propertyList.context.element.clientHeight);
				domStyle.set(propertyList.context.element, "max-height", availableHeight + "px");
			}, 
	
			_onAddBtnClicked: function(view) {
				var self = this;
				var displayProgressIndicator = view._instance.displayProgressIndicator;
				if (displayProgressIndicator || !view._instance.inUpdateDocument) {
					view._instance.inUpdateDocument = true;
					domStyle.set(view._instance.addDocumentModal.context.element, "cursor", "wait"); // Since no busy indicator in dialog
					console.log("CS-AddDocument:_onAddBtnClicked() : Enter add document");
		
					view._instance.addDocumentProps = view.ui.get("ContentProperties");
					var isValid = view._instance.addDocumentProps.update(function(properties, contentElements, cmThumbnails, className, accessAllowed) {
						if (view._instance.pollingEnabled) {
							self._showHideAddDocumentModal(view, false, '');
						} else {
							view._instance.inUpdateDocument = false; // Done adding document
							if (!displayProgressIndicator) {
								self._showHideAddDocumentModal(view, false, '');
								// Display message at top of the window
								var message;
								if (properties[0].Cardinality) {
									message = messages.contlist_add_doc_success;
								} else {
									message = messages.contlist_add_docs_success;
								}
								self._setAlertMessage(view, message, false);
							}
						}
						domStyle.set(view._instance.addDocumentModal.context.element, "cursor", "auto");
						console.log("CS-AddDocument:_onAddDocumentBtnClicked() : Finished adding document");
						// Send out and add event for the newly add documents. The response is either a properties array of real 
						// properties (single document) or a properties array of results objects (multi-document)
						var property = properties[0];
						if (property.results && property.results.properties) {
							// Multi-document add case
							properties.forEach(function(property) {
								var contentItem = self._createDocumentContentItem(property.results.properties, property.results.contentElements, property.results.cmThumbnails);
								var callback = view._instance.callback;
								if (callback) {
									callback(contentItem);
								}
								bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONADD, contentItem);
							});
						} else {
							// Single document add case
							var contentItem = self._createDocumentContentItem(properties, contentElements, cmThumbnails, className, accessAllowed);
							var callback = view._instance.callback;
							if (callback) {
								callback(contentItem);
							}
							bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONADD, contentItem);
						}
						
					}, function(error, response) {
						var errorMessage = "";
						var errorText = "";						
						if (Array.isArray(response)) {							
							var errorString = messages.contlist_docs_not_added;
							var fileNames = "";
							for (var i = 0; i < response.length; i++){
								var documentAddError = response[i];
								if (fileNames.length > 0){
									fileNames += ", ";
								}
								fileNames += documentAddError.fileName;
							}	
							errorMessage = string.substitute(errorString, [fileNames]);		
						} else {
							errorText = error ? error : "";
							errorMessage = string.substitute(messages.contlist_add_document_failed, [errorText]);
						}
						
						if (displayProgressIndicator) {
							self._showHideAddDocumentModal(view, true, '');
						} else {
							// Show error in an alert box at top of add dialog
							self._setModalAlertMessage(view, view._instance.addDocumentAlert, "AddDocumentAlert", errorMessage, true, 40000);
						}
												
						view._instance.inUpdateDocument = false; // Was error, allow for adding document again
						domStyle.set(view._instance.addDocumentModal.context.element, "cursor", "auto");
					});
					
					if (!isValid) {
						// There was a validation problem and add call never made
						view._instance.inUpdateDocument = false; // Was validation problem, allow for adding document again
						domStyle.set(view._instance.addDocumentModal.context.element, "cursor", "auto");
					} else if (displayProgressIndicator) {
						self._showHideAddDocumentModal(view, false, '');
					}
				}
			},
	
			_onCancelBtnClicked: function(view) {
				var self = this;
				view._instance.addDocumentModal = view.ui.get("AddDocumentModal");
				view._instance.addDocumentProps = view.ui.get("ContentProperties");
				
				view._instance.addDocumentModal.setVisible(false);
				view._instance.addDocumentProps.setVisible(false);
				
				bpmext.ui.executeEventHandlingFunction(view, this.EVT_ONCANCEL);
			},
	
			_checkFileSize: function(view, files) {
				var filesThatAreTooBig = [];
				var maxDocumentSize = view.context.options.maxDocumentSize.get("value");
				if (maxDocumentSize > 0) {
					for (var i = 0; i < files.length; i++) {
						var file = files[i];
						// Divide the real file size by 1024 to get the the size in KB 
						if ((file.size/1024) > maxDocumentSize) {
							filesThatAreTooBig.push(file.name);
						}
					}
				}
				return filesThatAreTooBig;
			},
	
			_createDocumentContentItem: function(properties, contentElements, cmThumbnails, className, accessAllowed) {
				var contentItem = {
					isFolder: false,
					baseType: "Document",
					properties: properties
				};
				if (className) {
					contentItem.className = className;
				}
				if (accessAllowed) {
					contentItem.accessAllowed = accessAllowed;
				}
				if (contentElements != null) {
					contentItem.contentElements = contentElements;
				}
				if (cmThumbnails != null) {
					contentItem.cmThumbnails = cmThumbnails;
				}
				// Dig some properties out of the property bag and make first class properties
				for (var i = 0; i < properties.length; i++) {
					var property = properties[i];
					if (property.id == "Id") {
						contentItem.id = property.value;
					} else if (property.id == "Name") {
						contentItem.name = property.value;
					} else if (property.id == "MimeType") {
						contentItem.mimeType = property.value;
					} else if (property.id == "IsReserved") {
						contentItem.isReserved = property.value;
					}
				} 
				return contentItem;
			}

		};
		
		/*
		 * Private methods and event handlers *************************************************************
		 */

		/*
		 * Public control methods *************************************************************
		 */

		/**
		 * @instance
		 * @memberof CSAddDocument
		 * @method getType
		 * @desc Returns the descriptive string that represents the control type.
		 * @returns {string}
		 */
		this.constructor.prototype.getType = function() {
			return "csAddDocument.1";
		};

		this.constructor.prototype.setObjectStoreName = function(objectStoreName) {
			this._instance.objectStoreName = objectStoreName;
		};

		/**
		 * @instance
		 * @memberof CSAddDocument
		 * @method setDocumentClasses
		 * @desc Set the list of document classes to be displayed in the add document dialog. 
		 * @param {object[]} The list should be of name value pair objects ie: [{name: "Email", value: "Email"}, {...}]. The
		 *        name should be the display name an the value should be the symbolic name of the class.
		 */
		this.constructor.prototype.setDocumentClasses = function(documentClasses) {
			this._instance.documentClasses = documentClasses;
		};

		/**
		 * @instance
		 * @memberof CSAddDocument
		 * @method setHideTimePicker
		 * @desc Controls the display of the time picker when editing date properties.
		 * @param {boolean} hideTimePicker Flag that determines whether the time picker is displayed when editing dates.
		 */
		this.constructor.prototype.setHideTimePicker = function(hideTimePicker) {
			this._instance.hideTimePicker = hideTimePicker;
		};

		/**
		 * @instance
		 * @memberof CSAddDocument
		 * @method setAcceptFileTypes
		 * @desc Set the list of accepted file types. 
		 * @param {string[]} acceptFileTypes The items in the list must be preceeded with '.' character ie: ".pdf", ".docx".
		 */
		this.constructor.prototype.setAcceptFileTypes = function(acceptFileTypes) {
			this._instance.acceptFileTypes = acceptFileTypes;
		};

		/**
		 * @instance
		 * @memberof CSAddDocument
		 * @method setMaxDocumentSize
		 * @desc Set maximum document size that can be added. 
		 * @param {integer} maxDocumentSize The maximum size of document that can be added in KB.
		 */
		this.constructor.prototype.setMaxDocumentSize = function(maxDocumentSize) {
			// TODO: currently this is not hooked up in the add with UI case. Will add it later
			this._instance.maxDocumentSize = maxDocumentSize;
			
			console.log("CS-AddDocument:setMaxDocumentSize() : Error: Setting maximum document size is not supported yet.");
		};
		
		/**
		 * @instance
		 * @memberof CSAddDocument
		 * @method addDocument
		 * @desc Adds a new document to the repository
		 * @returns 
		 */
		this.constructor.prototype.addDocument = function(parentFolderId, files, parentName, pollingEnabled, displayProgressIndicator, batchId, callback, errback) {

			if (pollingEnabled != null) {
				this._instance.pollingEnabled = pollingEnabled;
			} 
			if (displayProgressIndicator != null) {
				this._instance.displayProgressIndicator = displayProgressIndicator;
			}
			this._instance.batchId = batchId;
			
			this._proto._showHideAddDocumentModal(this, true, parentFolderId, files, parentName, callback, errback);
		};

		/*
		 * Coach NG Lifecycle methods *************************************************************
		 */
		 
		this.constructor.prototype.load = function() {
			console.log("CS-AddDocument:load() : called from: " + this.context.viewid);
			try	{
				var opts = this.context.options;
				var mdt = opts._metadata;

				if (!opts.objectStoreName) {
                    opts.objectStoreName = bpmext.ui.substituteConfigOption(this, "objectStoreName", null);
				}

				if (!opts.documentClasses) {
					opts.documentClasses = bpmext.ui.substituteConfigOption(this, "documentClasses", null);
				}

				if (!opts.hideTimePicker) {
					opts.hideTimePicker = bpmext.ui.substituteConfigOption(this, "hideTimePicker", false);
				}

				if (!opts.acceptFileTypes) {
					opts.acceptFileTypes = bpmext.ui.substituteConfigOption(this, "acceptFileTypes", null);
				}
				
				domClass.add(this.context.element, "CS_AddDocument");
				
  				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONADD, "contentItem");
				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONCANCEL);
				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONERROR, "message");

				bpmext.ui.loadView(this);			
				
			} catch (e) {
				bpmext.log.error("Error on load event [" + this.context.viewid + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};

		this.constructor.prototype.view = function () {
			console.log("CS-AddDocument:view() : called from: " + this.context.viewid);
            try {
//				this._proto._handleVisibility(this);
 			} catch (e) {
                bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                if (e.stack) {
                    bpmext.log.error("  Call stack: " + e.stack);
				}
            }
        };

		this.constructor.prototype.change = function(event)	{
			console.log("CS-AddDocument:change() : called from: " + this.context.viewid);
			try	{
				var view = this;
				if (event.type == "config")	{
					// NA
				} else {
					if (this.context.binding && event.newVal && event.newVal.id) {
						var boundObject = this.context.binding.boundObject;
						if (boundObject != null) {
														
						}
					}
				}
			} catch (e) {
				bpmext.log.error("Error on change event [" + this.ui.getAbsoluteName() + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};
	}
}	
