/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "Trieda",

		// Property list
		properties_file_name: "Názov súboru",
		properties_file_save_in: "Uložiť do",
		properties_add_file: "Pridať súbor",
		properties_add_mvcp: "Pridať ${0}",
		properties_remove_mvcp: "Odstrániť z ${0}",
		properties_use_file_name: "Pre túto vlastnosť bude použitý názov súboru",

		properties_optional_label: "${0} (nepovinné)",

		properties_document_or_folder_not_found: "Dokument alebo priečinok sa nepodarilo nájsť.",
		properties_class_not_found: "Triedu obsahu sa nepodarilo nájsť.",
		properties_folder_duplicate_item_invalid_prop: "V priečinku sa už nachádza položka s rovnakým názvom, prípadne ste zadali neplatnú hodnotu vlastnosti.",
		properties_item_invalid_prop: "Zadali ste neplatnú hodnotu pre niektoré vlastnosti.",

		properties_invalid_long_value: "Táto hodnota nie je platná. Hodnota musí byť celé číslo, napríklad 5 alebo 1349.",
		properties_invalid_float_value: "Hodnota je neplatná. Hodnota musí byť číslo s pohyblivou desatinnou čiarkou, napríklad 1,2 alebo 365.",
		properties_min_value: "Minimálna hodnota: ${0}",
		properties_max_value: "Maximálna hodnota: ${0}",
		properties_max_length: "Maximálna dĺžka: ${0}",
		properties_invalid_guid: "Hodnota je neplatná. Hodnota musí predstavovať globálne jedinečný identifikátor (GUID), napríklad: {F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}.",
		properties_value_required: "Táto hodnota je povinná.",
		properties_unique_value_required: "Táto hodnota musí byť jedinečná.",
		properties_file_required: "Vyžaduje sa súbor.",
		properties_invalid_folder_name: "Názov priečinka nemôže obsahovať nasledujúce znaky: \\ / : * ? \" < > |",

		properties_move_edit_confirm_msg: "Meníte vlastnosti nasledujúceho dokumentu<br>${0}<br><br>Chcete uložiť vykonané zmeny?",
		properties_move_edit_confirm_no: "Nie",
		properties_move_edit_confirm_yes: "Áno",
		properties_move_edit_confirm_title: "Potvrdenie",
		properties_edit_save_success: "Vlastnosti boli uložené",
		properties_edit_save_failure: "Vlastnosti sa neuložili",
		properties_no_item_selected: "Nie je vybratá žiadna položka.",

		// Content list
		contlist_column_spec_title: "Nadpis",
		contlist_column_spec_name: "Názov",
		contlist_column_spec_version_label: "Verzia",
		contlist_column_spec_modified_by: "Upravil",
		contlist_column_spec_mod_date: "Posledná úprava",
		contlist_column_spec_created_by: "Vytvoril",
		contlist_column_spec_creation_date: "Vytvorené",
		contlist_column_spec_mime_type: "Typ dokumentu",
		contlist_column_spec_size: "Veľkosť",
		contlist_column_spec_thumbnail: "Miniatúra",

		contlist_paging_no_more_items: "Nenašli sa žiadne ďalšie položky",
		contlist_paging_of_at_least_items: "Položky ${0} z aspoň ${1}",
		contlist_paging_of_items: "Položky ${0} z ${1}",
		contlist_paging_items: "Položky ${0}",
		contlist_paging_items_per_page: "Položky na stránku: ${0}",

		contlist_checked_out: "Odhlásené",
		contlist_checked_out_by: "Odhlásil ${0}",

		contlist_size_units_B: "B",
		contlist_size_units_KB: "kB",
		contlist_size_units_MB: "MB",
		contlist_size_units_GB: "GB",
		contlist_size_units_TB: "TB",

		contlist_missing_server_error: "Neurčili ste server.",
		contlist_invalid_server_error: "Server '{0}' neexistuje.",
		contlist_error_retrieving_doc_props: "Vyskytla sa chyba pri načítaní vlastností dokumentu.",
		contlist_error_retrieving_folder_props: "Chyba pri načítavaní vlastností priečinka.",
		contlist_checkout_failed: "Dokument sa nepodarilo odhlásiť",
		contlist_cancel_checkout_failed: "Zrušenie odhlásenia nebolo úspešné",
		contlist_rename_folder_failed: "Priečinok sa nepodarilo premenovať.",
		contlist_folder_name_not_unique: "Názov priečinka musí byť jedinečný.",
		contlist_delete_object_failed: "Objekt sa nepodarilo odstrániť.",
		contlist_display_properties_failed: "Vlastnosti sa nepodarilo zobraziť. ${0}",
		contlist_save_props_failed: "Vlastnosti sa nepodarilo uložiť",
		contlist_upload_failed: "Verziu sa nepodarilo nahrať",
		contlist_add_folder_failed: "Priečinok sa nepodarilo pridať. ${0}",
		contlist_add_document_failed: "Dokument sa nepodarilo pridať. ${0}",
		contlist_search_failed: "Nepodarilo sa načítať výsledky vyhľadávania",
		contlist_folder_containees_failed: "Nepodarilo sa načítať obsah priečinka",
		contlist_delete_folder_referenced: "Priečinok nemožno odstrániť, pretože obsahuje podpriečinky.",
		contlist_docs_not_added: "Nasledujúce dokumenty sa nepodarilo pridať: ${0}",

		contlist_checkout_success: "Dokument bol odhlásený",
		contlist_delete_success: "Objekt bol odstránený",
		contlist_rename_folder_success: "Priečinok bol premenovaný",
		contlist_save_props_success: "Vlastnosti boli uložené",
		contlist_cancel_checkout_success: "Zrušenie odhlásenia bolo úspešné",
		contlist_upload_version_success: "Verzia bola nahraná",
		contlist_add_folder_success: "Priečinok bol pridaný",
		contlist_add_doc_success: "Dokument bol pridaný",
		contlist_add_docs_success: "Dokumenty boli pridané",

		contlist_menu_action_open: "Otvoriť",
		contlist_menu_action_rename: "Premenovať",
		contlist_menu_action_properties: "Vlastnosti",
		contlist_menu_action_view: "Zobraziť",
		contlist_menu_action_download: "Stiahnuť",
		contlist_menu_action_checkout: "Odhlásiť",
		contlist_menu_action_edit_document: "Upraviť dokument",
		contlist_menu_action_cancel_checkout: "Zrušiť odhlásenie",
		contlist_menu_action_delete_doc: "Odstrániť dokument",
		contlist_menu_action_rename_folder: "Premenovať priečinok",
		contlist_menu_action_add_folder: "Pridať priečinok",
		contlist_menu_action_delete_folder: "Odstrániť priečinok",
		contlist_menu_action_add_doc: "Pridať dokument",
		contlist_menu_action_upload: "Nahrať novú verziu",

		contlist_document_properties: "Vlastnosti dokumentu",
		contlist_folder_properties: "Vlastnosti priečinka",
		contlist_folder_name: "Názov priečinka",

		contlist_cancel_btn_label: "Zrušiť",
		contlist_add_btn_label: "Pridať",
		contlist_ok_btn_label: "OK",
		contlist_edit_btn_label: "Upraviť",
		contlist_save_btn_label: "Uložiť",
		contlist_upload_btn_label: "Nahrávanie",
		contlist_refresh_btn_label: "Obnoviť",
		contlist_next_btn_label: "Ďalej",
		contlist_previous_btn_label: "Späť",

		contlist_delete_folder_confirm: "Chystáte sa odstrániť priečinok ${0}. Chcete pokračovať?",
		contlist_delete_doc_confirm: "Chystáte sa odstrániť dokument ${0}. Chcete pokračovať?",

		contlist_no_mimetype: "Táto položka nemá žiadny obsah.",
		contlist_folder_mimetype: "Priečinok",

		contlist_filter_search_hint: "Hľadať dokumenty",
		contlist_filter_folder_hint: "Filtrovať zoznam",

		contlist_root_folder: "Koreňový priečinok",
		contlist_drop_folder_error: "Priečinky nemôžete pridať. Vyberte iba súbory.",
		contlist_add_in_process: "Pred pridaním nového dokumentu počkajte, kým sa pridá predchádzajúci.",
		contlist_add_doc_max_exceeded: "Naraz môžete maximálne pridať ${0} položiek. Pokúšate sa pridať ${1} položiek.",
		contlist_progress_success: "Úspech",
		contlist_progress_alert: "Výstraha",
		contlist_progress_error: "Chyba",
		contlist_progress_uploading: "Nahráva sa",
		contlist_progress_processing: "Spracováva sa 1 súbor",
		contlist_progress_uploading_text: "Nahráva sa 1 súbor",
		contlist_progress_upload_failed: "Vyskytol sa problém",
		contlist_progress_close: "Zatvoriť",
		progress_ind_uploaded_status: "Nahraté",
		progress_ind_uploaded: "Bol nahratý 1 súbor",
		progress_ind_uploaded_error: "Spracovanie sa nespustilo",		
		progress_ind_processing_status: "Spracovanie",
		progress_ind_processing_err: "Vyskytol sa problém",
		progress_ind_processed: "Bol spracovaný 1 súbor",	
		progress_ind_failed: "Neúspešné",
		progress_ind_review_doc: "Vyžaduje sa kontrola",	
		progress_ind_updating: "Aktualizuje sa 1 súbor",
		progress_ind_updating_status: "Aktualizuje sa",
		progress_ind_update_err: "Vyskytol sa problém",
		progress_ind_timeout: "Uplynul vyhradený čas pre monitorovanie",
		progress_ind_refresh: "Obnoviť",

		getcontent_ret_versions_error: "Nepodarilo sa načítať sériu verzií",
		getcontent_ret_properties_error: "Nepodarilo sa načítať vlastnosti dokumentu",

		contentviewer_test_mode: "Prezerač nezobrazí dokumenty v režime ukážky. Musí sa spustiť v rámci aplikácie IBM Navigator pre počítače. ",

		thumbnail_retreival_error: "Nepodarilo sa načítať obrázok náhľadu. ",

		status_10: "Nahraté",
		status_20: "Spracováva sa",
		status_25: "Znova sa spracováva",
		status_30: "Vyžaduje sa kontrola",
		status_40: "Aktualizuje sa",
		status_900: "Chyba pri spracovaní",
		status_910: "Chyba pri aktualizácii",

		/*do not remove this line*/nop: null
});
