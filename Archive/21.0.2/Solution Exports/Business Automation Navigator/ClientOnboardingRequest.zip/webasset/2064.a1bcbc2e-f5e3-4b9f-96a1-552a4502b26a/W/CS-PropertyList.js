/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019 - 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

cs_InitPropertyList = function(utilities, bpmext, domClass, domAttr, domStyle, messages, string, cookie){
	
	const Actions = {
		EDIT_PROPERTIES: 'editProperties',
		ADD_DOCUMENT: 'addDocument',
		ADD_FOLDER: 'addFolder',
		CHECKIN_DOCUMENT: 'checkinDocument',
		ADD_BATCH: 'addBatch'
	};
	
	const ObjectTypes = {
		FOLDER: "Folder",
		DOCUMENT: "Document",
		ABSTRACT: "Abstract"
	};
	
	const BATCH_DISPLAY_PROPERTIES = ["DbaDisplayName", "DbaType", "DbaBatchDescription", "DbaBatchPriority", "DbaBatchGroup", "DbaBatchLocation"];
	
	const BATCH_CLASS_NAME = "DbaClassificationBatch";
	
	this._serverConfigurationName = "GRAPHQL_APP_RESOURCE";
	this._action = "";
	this._metadataCache = {};
	this._contentItem = null;
	this._objectId = "";
	this._classId = "";
	this._parentFolderId = "";
	this._propertyObjects = [];
	this._objectType = "";
	this._readOnly = false;
	this._valueOnly = false;
	this._refreshAfterUpdate = null;
	this._callback = null;
	this._errbacks = null;
	this._classSelector = null;
	this._fileSelector = null;
	this._fileUploadButton = null;
	this._currentDocumentTitle = null;
	this._stackLayout = null;
	this._toolbarLayout = null;
	this._noItemSelectedDiv = null;
	this._saveButton = null;
	this._editButton = null;
	this._cancelButton = null;
	this._serviceLayout = null;
	this._propertyUpdated = false;
	this._confirmEditMoveDlg = null;
	this._moveEditObjectId = null;
	this._moveEditObjectClass = null;
	this._moveEditObjectType = null;
	this._confirmEditNoBtn = null;
	this._confirmEditYesBtn = null;
	this._uploadContent = null;
	this._controllerDocumentProperty = null;
	this._controllerClass = null;
	this._controlledDocumentClass = null;
	this._classificationBatchId = null;
	this._intializedFilename = false;
	this._privEditProperties = 0x2;
	this._files = [];
	this.EVT_ONSVCERROR = "onServiceError";
	this._alertDiv = null;
	this._fileTypes = null;
	
	if (!this.constructor.prototype._proto)
	{
		this.constructor.prototype._proto =
		{					
			/**
			 * Helper function to retrieve the Object Store Name as defined in ACCE admin tool.
			 */
			_getObjectStoreName: function(view) {
				var objectStoreName = view.context.options.objectStoreName.get("value");
				return objectStoreName;
			},

			_handleVisibility: function (view) {
				var vis = utilities.handleVisibility(view.context);
			},

			_callService: function(service, params) {
				// Create ecm token as a large random number
				var csrfToken = Math.floor(Math.random() * 10000000);
				console.log("CS-PropertyList:_callService() : Ecm token: " + csrfToken);

				// Add the required token value to the service params
				params.csrfToken = csrfToken;
				service.execute(params);
			},
			
			_mergeMetadata: function(view, classDescription, propertyObjects, newObject, valueOnly){
				var ovpUpdatedProperties = [];
				var propertyValues = {};
				var batchErrorStatusCode = 0;
				var batchErrorString = "";
				propertyObjects.forEach(function(propertyObject){
					propertyValues[propertyObject.id] = propertyObject.objectValue != null ? propertyObject.objectValue: propertyObject.value != null ? propertyObject.value : propertyObject.singleCardinalityValue != null ? propertyObject.singleCardinalityValue : propertyObject.listCardinalityValues != null ? propertyObject.listCardinalityValues : null;
				});
				var updatedPropertyObjects = [];
				var propertyDescriptions = classDescription.propertyDescriptions.items ? classDescription.propertyDescriptions.items : classDescription.propertyDescriptions;
				for (var i = 0; i < propertyDescriptions.length; i++){
					var propertyDescription = propertyDescriptions[i];
					if ((propertyDescription.isSystemOwned && propertyDescription.symbolicName != "FolderName") || propertyDescription.symbolicName == "MimeType"){
						continue;
					}
					
					if ((propertyDescription.symbolicName == "DbaCaptureError" || propertyDescription.symbolicName == "DbaBatchError") && 
						propertyValues[propertyDescription.symbolicName] && propertyValues[propertyDescription.symbolicName].length > 0){
							
						batchErrorString = propertyValues[propertyDescription.symbolicName];						
					}
					
					if ((propertyDescription.symbolicName == "DbaBatchStatus" && propertyValues[propertyDescription.symbolicName] >= 1900 && propertyValues[propertyDescription.symbolicName] < 2000) ||
						(propertyDescription.symbolicName == "DbaCaptureStatus" && propertyValues[propertyDescription.symbolicName] >= 900 && propertyValues[propertyDescription.symbolicName] < 1000)){
					
						batchErrorStatusCode = propertyValues[propertyDescription.symbolicName];		
					}
					
					if (propertyDescription.dataType == "BINARY" || propertyDescription.isHidden){
						continue;
					}
					
					if (propertyDescription.dataType == "OBJECT"){
						if ((view._action == Actions.EDIT_PROPERTIES && propertyDescription.symbolicName == view._controllerDocumentProperty || propertyDescription.id == view._controllerDocumentProperty)){
							var propertyValue = propertyValues[propertyDescription.symbolicName];
							if (propertyValue) {
								var ovpPropertyObjects = propertyValue.properties.items ? propertyValue.properties.items : propertyValue.properties;
								ovpUpdatedProperties = this._mergeMetadata(view, view._metadataCache[view._controllerClass], ovpPropertyObjects, false, valueOnly);
							}
						}
						continue;
					}
					
					var updatedPropertyObject = {
						id: propertyDescription.symbolicName,
						type: propertyDescription.dataType,
						cardinality: propertyDescription.cardinality,
						label: propertyDescription.displayName,
						readOnly: propertyDescription.isReadOnly,
						required: propertyDescription.isValueRequired,
						choices: propertyDescription.choiceList,
						hierChoices: false,
						isSystemOwned: propertyDescription.isSystemOwned,
						requiresUniqueElements: propertyDescription.requiresUniqueElements,
						maxLength: propertyDescription.maximumLengthString ? propertyDescription.maximumLengthString : null,
						minValue: propertyDescription.propertyMinimumInteger32 || propertyDescription.propertyMinimumFloat64 || propertyDescription.propertyMinimumDateTime,
						maxValue: propertyDescription.propertyMaximumInteger32 || propertyDescription.propertyMaximumFloat64 || propertyDescription.propertyMaximumDateTime,
						singleCardinalityValue: propertyValues[propertyDescription.symbolicName] != null && propertyDescription.cardinality == "SINGLE" ? propertyValues[propertyDescription.symbolicName] : null,
						listCardinalityValues: propertyValues[propertyDescription.symbolicName] != null && propertyDescription.cardinality == "LIST" ? propertyValues[propertyDescription.symbolicName] : [],
						dateOnly: propertyDescription.isDateOnly ? propertyDescription.isDateOnly : null
					}
					
					var listCardinalityValues = updatedPropertyObject.listCardinalityValues.items ? updatedPropertyObject.listCardinalityValues.items : updatedPropertyObject.listCardinalityValues;
					if (valueOnly && (updatedPropertyObject.singleCardinalityValue == null || updatedPropertyObject.singleCardinalityValue == "" || updatedPropertyObject.	singleCardinalityValue == false) && (listCardinalityValues.length == 0)){
						continue;
					}
					
					// Exclude hierarchical choice lists for now.
					if (updatedPropertyObject.choices && updatedPropertyObject.choices.choiceValues){
						var choiceValues = updatedPropertyObject.choices.choiceValues.items ? updatedPropertyObject.choices.choiceValues.items : updatedPropertyObject.choices.choiceValues;
						for (var j = 0; j < choiceValues.length; j++){
							var choice = choiceValues[j];
							if (choice.choiceValues){
								var subChoices = choice.choiceValues.items ? choice.choiceValues.items : choice.choiceValues;
								if (subChoices && subChoices.length > 0){
									updatedPropertyObject.choices = null;
									updatedPropertyObject.hierChoices = true;
									break;
								}
							}
						}
					}
					
					// Check settability
					if (propertyDescription.settability == "READ_ONLY" ||
						((propertyDescription.settability == "SETTABLE_ONLY_ON_CREATE" || propertyDescription.settability == "SETTABLE_ONLY_BEFORE_CHECKIN")&& !newObject) ||
						(propertyDescription.symbolicName == "DbaBatchDocumentCount" || 
						propertyDescription.symbolicName == "DbaBatchStatus" ||
						propertyDescription.symbolicName == "DbaProjectId" ||
						propertyDescription.symbolicName == "DbaLeaseTime")){
							updatedPropertyObject.readOnly = true;							
					}
					
					if (newObject){
						if (propertyDescription.cardinality == "SINGLE" && !updatedPropertyObject.singleCardinalityValue){
							updatedPropertyObject.singleCardinalityValue = propertyDescription.propertyDefaultId ||
								propertyDescription.propertyDefaultString || propertyDescription.propertyDefaultBoolean || propertyDescription.propertyDefaultInteger32 || propertyDescription.propertyDefaultDateTime || propertyDescription.propertyDefaultFloat64 || null;
						}
					}
					
					// Work around a date binding issue for MVCPs
					if (updatedPropertyObject.cardinality == "LIST" && updatedPropertyObject.type == "DATE"){
						dateListValues = updatedPropertyObject.listCardinalityValues.items ? updatedPropertyObject.listCardinalityValues.items : updatedPropertyObject.listCardinalityValues;
						updatedPropertyObject.listCardinalityValues = dateListValues.map(function(dateStringValue){
							return new Date(dateStringValue);
						})
					}
					
					updatedPropertyObjects.push(updatedPropertyObject);
				}
				
				if (batchErrorStatusCode > 0){
					// If we have a string from the batch error property, use it. Otherwise us a generic string.
					if (batchErrorString.length > 0){
						this._handleBatchErrorString(view, batchErrorString);				
					}
					else {
						var messageKey = batchErrorStatusCode < 1900 ? "status_error_msg_" + batchErrorStatusCode : "batch_error_msg_" + batchErrorStatusCode;
						if (messages[messageKey]){
							this._displayBatchError(view, messages[messageKey]);
						}
					}
				}
				
				return updatedPropertyObjects.concat(ovpUpdatedProperties);
			},
			
			_handleBatchErrorString(view, errorJson){
				var errorText = "";
				var errors = JSON.parse(errorJson);				
				if (errors.ErrorList){
					for (var i = 0; i < errors.ErrorList.length; i++){
						var pageErrors = errors.ErrorList[i];						
						for (var j = 0; j < pageErrors.errors.length; j++){
							var error = pageErrors.errors[j];
							if (errorText.length > 0){
								errorText += "\n";
							}
							errorText += error.Message;
						}
					}
				}
				else if (errors.errors){
					for (var i = 0; i < errors.errors.length; i++){
						var error = errors.errors[i];
						if (errorText.length > 0){
							errorText += "\n";
						}
						errorText += error.Message;
					}
				}
				else if (errors.Message){
					errorText = errors.Message;
				}
				
				if (errorText.length > 0){
					this._displayBatchError(view, errorText);
					return true;
				}
				else {
					return false;
				}
			},
			
			_displayBatchError(view, errorText){	
				if (view._alertDiv){
					view._alertDiv.remove();
				}
				view._alertDiv = setAlertMessage(messages.contlist_progress_alert, errorText, "D", 0, domClass, domStyle, domAttr, messages);
				var closeButton = view._alertDiv.querySelector(".CS_AlertClose");
				closeButton.addEventListener("click", function(evt){
					view._alertDiv.remove();
					view._alertDiv = null;
				}, true);
				var batchErrorDiv = view.context.element.querySelector(".CS_BatchError");
				batchErrorDiv.appendChild(view._alertDiv);				
			},
			
			_disableDocumentTitle: function(view){
				for (var i = 0; i < view._propertyObjects.length; i++){
					var propertyObject = view._propertyObjects[i];
					if (propertyObject.id == "DocumentTitle"){
						propertyObject.readOnly = true;
						break;
					}
				}
			},
			
			_displayNoItemSelected: function(view, show){
				if (view._alertDiv){
					view._alertDiv.remove();
					view._alertDiv = null;
				}
				
				var displayMessage = "";
				var displayToolbar = "";
				if (show){
					displayToolbar = "none";
				}
				else {
					displayMessage = "none";
				}
				domStyle.set(view._noItemSelectedDiv, "display", displayMessage);
				domStyle.set(view._toolbarLayout.context.element, "display", displayToolbar);
			}
		};
		
		/**
		*	Sets a value indicating properties in the view should be read-only, not available for editing.
		**/
		this.constructor.prototype.setReadOnly = function(readOnly){
			this._readOnly = readOnly;
			readOnly ? domClass.add(this.context.element, "CS_DisplayProperties") : domClass.remove(this.context.element, "CS_DisplayProperties");
		};
		
		this.constructor.prototype.getReadOnly = function(){
			return this._readOnly;
		};
		
		/**
		*	Sets a value indicating only properties with values should be displayed. Null or empty properties are not displayed
		* 	when this value is true.
		**/
		this.constructor.prototype.setValueOnly = function(valueOnly){
			this._valueOnly = valueOnly;
		};
		
		this.constructor.prototype.getValueOnly = function(){
			return this._valueOnly;
		};
		
		this.constructor.prototype._setProperties = function(){
			this._stackLayout._readOnly = this._readOnly;
			this._stackLayout._displayNew = true;
			this._stackLayout._indexOffset = 0;
			this._stackLayout.setViewData(this._propertyObjects, true);
		};
		
		/**
		 * 	Clears the contents of the list.
		 **/
		this.constructor.prototype.clear = function(){
			this.classSelector.clearItems();
			this._propertyObjects = [];
			this._setProperties();
		};
		
		/**
		 *	Displays the properties of a document or folder.
		 *	@param objectId: The id of the document or folder.
		 *	@param classId: The symbolicName of the class of the document or folder.
		 *	@param objectType: "Document" or "Folder".
		 *	@param callback: Function called after properties are retrieved from server.
		 *	@param errback: Function called when an error occurs.
		 **/
		this.constructor.prototype.displayProperties = function (objectId, classId, objectType, callback, errback){
			this._storeCallbackErrback(callback, errback);
			this._objectId = objectId;
			this._classId = classId;
			this._objectType = objectType;
			domStyle.set(this._fileSelector, "display", "none");
			this.classSelector.setVisible(true);
			domStyle.set(this.classSelector.context.element, "display", "");
			this.classSelector.clearItems();
			this._action = Actions.EDIT_PROPERTIES;
			var contentClass = this._metadataCache[classId];
			this._propertyUpdated = false;
			this.classSelector.setEnabled(false);
			this._stackLayout._setFocus = true;
			if (this._alertDiv){
				this._alertDiv.remove();
				this._alertDiv = null;
			}
					
			var displayUI = this.context.options.displayEditInterface.get("value");
			if (displayUI){
				domStyle.set(this._serviceLayout.context.element, "display", "");
				domAttr.set(this.context.element, "region", "Properties");
				domAttr.set(this.context.element, "aria-label", "Properties");
				domAttr.set(this.context.element, "tabindex", "0");
				if (!this._editingProperties()){
					var binding = this.context.binding.get("value");
					if (binding && binding.accessAllowed & this._privEditProperties){
						domStyle.set(this._editButton.context.element, "display", "");
					} else {
						domStyle.set(this._editButton.context.element, "display", "none");
					}
				}
			} else {
				domAttr.remove(this.context.element, "region");
				domAttr.remove(this.context.element, "aria-label");
				domAttr.remove(this.context.element, "tabindex");
			}
			
			var fileInput = this.context.element.querySelector(".CS_PropertyListClass");
			domClass.remove(fileInput, "CS_PropertyListClassUpload");
			
			if (contentClass){
				this.classSelector.appendItem(contentClass.symbolicName, contentClass.displayName);
				this.classSelector.setSelectedItem(contentClass.symbolicName);
				this.callGetPropertiesService(objectId, classId);
			} else {
				var params = {
					classId: classId,
					repository: this._proto._getObjectStoreName(this),
					serverAppResource: this._serverConfigurationName,
				};
				this.classDetailsService = this.ui.get("GetClassDetails");
				this._proto._callService(this.classDetailsService, params);
			}
		};
		
		/**
		 * 	Displays the add component for adding a new captaure batch.
		 **/
		this.constructor.prototype.newBatch = function(errback){
			this._storeCallbackErrback(null, errback);
			this._proto._displayNoItemSelected(this, false);
			domStyle.set(this._toolbarLayout.context.element, "display", "none");
			this._stackLayout._setFocus = true;
			this._action = Actions.ADD_BATCH;
			var classDescription = this._metadataCache[BATCH_CLASS_NAME];
			if (!classDescription){
				this._propertyObjects = [];
				this._setProperties();
				var params = {
					repository: this._proto._getObjectStoreName(this),
					serverAppResource: this._serverConfigurationName,
					classId: BATCH_CLASS_NAME
				};
				this.classDetailsService = this.ui.get("GetClassDetails");
				this._proto._callService(this.classDetailsService, params);
			} else {
				this._propertyObjects = this._proto._mergeMetadata(this, classDescription, [], true);
				this._setProperties();
			}
		};
		
		/**
		 * 	Creates a new folder
		 *	@param parentFolderId: Parent folder ID for the new folder.
		 *	@param errback: Function called when an error occurs.
		 */
		this.constructor.prototype.newFolder = function (parentFolderId, errback){
			this._storeCallbackErrback(null, errback);
			this._parentFolderId = parentFolderId;
			this._action = Actions.ADD_FOLDER;
			this._objectType = "Folder";
			domStyle.set(this._fileSelector, "display", "none");
			domStyle.set(this.classSelector.context.element, "display", "");
			this.classSelector.setVisible(true);
			this._propertyUpdated = false;
			this._proto._displayNoItemSelected(this, false);
			domStyle.set(this._toolbarLayout.context.element, "display", "none");
			
			var fileInput = this.context.element.querySelector(".CS_PropertyListClass");
			domClass.remove(fileInput, "CS_PropertyListClassUpload");
			
			var _this = this;
			this.classSelector.displayContentClasses(this._objectType, function(){
				if (_this.classSelector.getClassCount() > 1){
					_this.classSelector.setEnabled(true);
					_this._stackLayout._setFocus = false;
					setTimeout(function(){
						_this.classSelector.focus();
					}, 300);
				}
				else {
					_this.classSelector.displayAsStaticText();
					_this._stackLayout._setFocus = true;
				}
			}, function(error){
				_this._handleErrback(error);
			});
		};
		
		/**
		 * 	Creates a new document
		 *	@param parentFolderId: Parent folder ID for the new document.
		 *	@param errback: Function called when an error occurs.
		 *	@param files: Filelist of files to be added as content for new documents
		 *	@param parentName: Name of parent folder to be displayed in the UI.
		 *	@param classificationBatchId: Object Id of classification batch object. Used when adding documents to existing classification batches.
		 */
		this.constructor.prototype.newDocument = function (parentFolderId, errback, files, parentName, classificationBatchId){
			this._storeCallbackErrback(null, errback);
			this._parentFolderId = parentFolderId;
			this._action = Actions.ADD_DOCUMENT;
			this._objectType = "Document";
			this._files = files;
			this._classificationBatchId = classificationBatchId;
			
			var fileUpload = this.context.element.querySelector(".CS_File");
			domClass.remove(fileUpload, "CS_FileCheckin");
			var fileInput = this.context.element.querySelector(".CS_FileInput");
			fileInput.value = null;			
			domStyle.set(this._fileSelector, "display", "block");
			this._propertyUpdated = false;
			
			var fileUploadSection = this.context.element.querySelector(".CS_PropertyListClass");
			domClass.remove(fileUploadSection, "CS_PropertyListClassUpload");
			domClass.remove(this._fileSelector, "CS_FileUploadCheckin");
			this._proto._displayNoItemSelected(this, false);
			
			domStyle.set(this.classSelector.context.element, "display", "");
			var fileNameElement = this.context.element.querySelector(".CS_FileName");
			var parentNameLabel = this._fileSelector.querySelector(".CS_ParentNameLabel");
			var parentNameValue = this._fileSelector.querySelector(".CS_ParentNameValue");
			var fileSelectorLabel = this._fileSelector.querySelector(".CS_FileSelectorLabel");
			var selectedFile =  this._fileSelector.querySelector(".CS_SelectedFile");
			var fileContainer = this.context.element.querySelector(".CS_FileContainer");
			domStyle.set(fileContainer, "display", "none");
			domStyle.set(parentNameLabel, "display", "none");
			domStyle.set(parentNameValue, "display", "none");
			domStyle.set(fileSelectorLabel, "display", "none");
			if (files && files.length > 0){
				domClass.add(fileNameElement, "CS_FileNameDnD");
				domClass.add(selectedFile, "CS_SelectedFileDnD");
				domStyle.set(fileSelectorLabel, "display", "");
				domStyle.set(this._fileUploadButton, "display", "none");
				domClass.add(fileContainer, "CS_FileContainerDnD");
				if (parentName && parentName.length > 0){
					domStyle.set(parentNameLabel, "display", "");
					domStyle.set(parentNameValue, "display", "");
					var textNode;
					for(i = 0; i < parentNameValue.childNodes.length; i++){
						var child = parentNameValue.childNodes[i];
						if (child.nodeType == Node.TEXT_NODE){
							textNode = child;
							break;
						}
					}
					if (!textNode){
						textNode = document.createTextNode("");
						parentNameValue.appendChild(textNode);
					}
					textNode.nodeValue = parentName;
				}
			}else {
				domStyle.set(this._fileUploadButton, "display", "");
				domClass.remove(fileNameElement, "CS_FileNameDnD");
				domClass.remove(selectedFile, "CS_SelectedFileDnD");
				domClass.remove(fileContainer, "CS_FileContainerDnD");
				setTimeout(function(){
					fileInput.focus();
				}, 300);
			}

			domStyle.set(this._toolbarLayout.context.element, "display", "none");
			var _this = this;
			this.classSelector.displayContentClasses(this._objectType, function(){
				_this.classSelector.setVisible(true);
				if (_this.classSelector.getClassCount() > 1){
					_this.classSelector.setEnabled(true);
				}
				else {
					_this.classSelector.displayAsStaticText();
				}
			}, function(error){
				_this._handleErrback(error);
			});
		};
		
		/**
	 	 *	Sets the view up for checking in a new version of a document.
	 	 */		
		this.constructor.prototype.displayForCheckin = function (documentId){
			this._action = Actions.CHECKIN_DOCUMENT;
			this._objectType = "Document";
			this._objectId = documentId;
			this._propertyUpdated = false;
			
			var parentNameLabel = this._fileSelector.querySelector(".CS_ParentNameLabel");
			domStyle.set(parentNameLabel, "display", "none");
			var parentNameValue = this._fileSelector.querySelector(".CS_ParentNameValue");
			domStyle.set(parentNameValue, "display", "none");
			var fileSelectorLabel = this._fileSelector.querySelector(".CS_FileSelectorLabel");
			domStyle.set(fileSelectorLabel, "display", "none");
			domClass.add(this._fileSelector, "CS_FileUploadCheckin");
			
			domStyle.set(this.classSelector.context.element, "display", "none");
			this._propertyObjects = [];
			this._setProperties();
			this._proto._displayNoItemSelected(this, false);
			
			var fileUploadSection = this.context.element.querySelector(".CS_PropertyListClass");
			domClass.add(fileUploadSection, "CS_PropertyListClassUpload");
			
			domStyle.set(this._toolbarLayout.context.element, "display", "none");
			
			var fileUpload = this.context.element.querySelector(".CS_File");
			domClass.add(fileUpload, "CS_FileCheckin");
			var fileInput = this.context.element.querySelector(".CS_FileInput");
			fileInput.value = null;
			this._displaySelectedFileName();
			domStyle.set(this._fileSelector, "display", "block");
			setTimeout(function(){
				fileInput.focus();
			}, 300);
		};
		
		/**
		 * 	Calls the server to update or create a document or folder.
		 *	@param callback: A function that is called when the update completes successfully.
		 *	@param errback: A function that is called when the update fails due to an error.
		 *	@param refresh: Boolean indicating the property list should be updated with new 
		 *		values returned from the update.
		 */
		this.constructor.prototype.update = function (callback, errback, refresh){
			if (this.isValid()){
				this._storeCallbackErrback(callback, errback, refresh);
				var getPropertiesAsJson = this._action == Actions.ADD_DOCUMENT;
				var objectProperties = this._action == Actions.CHECKIN_DOCUMENT ? [] : this.getPropertyValues(getPropertiesAsJson);
				var serverResource = this._serverConfigurationName;
				var repositoryName = this._proto._getObjectStoreName(this);
				var connectionStr = "/content-services-graphql/graphql";
				
				if (this._action == Actions.EDIT_PROPERTIES){
					var params = {
						serverAppResource: serverResource,
						repository: repositoryName,
						objectType: this._objectType,
						objectId: this._objectId,
						properties: objectProperties
					};
					var updateService = this.ui.get("UpdateService");
					this._proto._callService(updateService, params);
				}
				else if (this._action == Actions.ADD_FOLDER){
					var params = {
						repository: repositoryName,
						classId: this.classSelector.getSelectedItem(),
						fileInFolderId: this._parentFolderId,
						serverAppResource: serverResource,
						properties: objectProperties
					};
					var addService = this.ui.get("AddFolderService");
					this._proto._callService(addService, params);
				}
				else if (this._action == Actions.ADD_DOCUMENT){
					var classId = this.classSelector.getSelectedItem();
					var fileInput = this.context.element.querySelector(".CS_FileInput");
					var _this = this;
					var jsonProperties = JSON.parse(objectProperties);
					if (this._classificationBatchId){
						this._uploadContent.appendDocumentsToClassificationBatch(this._classificationBatchId, _this._files, classId, jsonProperties, function(results){
							_this._onAddObjectResult(_this, results);
						}, function(error){
							_this._onUpdateError(_this, error);
						});
					}
					else {
						this._uploadContent.uploadFile(this._parentFolderId, _this._files, classId, jsonProperties, function(results){
							_this._onAddObjectResult(_this, results);
						}, function(error){
							_this._onUpdateError(_this, error);
						});
					}
				}
				else {
					var fileInput = this.context.element.querySelector(".CS_FileInput");
					var _this = this;
					this._uploadContent.uploadNewVersionFromFile(this._objectId, fileInput.files[0], function(results){
						_this._onUpdateResult(_this, results);
					}, function(error){
						_this._onUpdateError(_this, error);
					});
				}
				return true;
			}
			else {
				return false; // need to return something so caller will know save was never executed
			}
		};

		/**
		 * 	Calls the server to save properties or create a document or folder. This is a newer function that will eventually replace the updated function.
		 *  @param returnProperties: Extra properties to be returned
		 *  @param objectProperties: object value properties to be returned
		 *	@param refresh: Boolean indicating the property list should be updated with new 
		 *	@param callback: A function that is called when the save completes successfully.
		 *	@param errback: A function that is called when the save fails due to an error.
		 *	@return	values returned from the update.
		 */
		this.constructor.prototype.save = function (returnProperties, objectProperties, refresh, callback, errback) {
			if (this.isValid()) {
				this._storeCallbackErrback(callback, errback, refresh);
				var getPropertiesAsJson = this._action == Actions.ADD_DOCUMENT;
				var properties = this._action == Actions.CHECKIN_DOCUMENT ? [] : this.getPropertyValues(getPropertiesAsJson);
				var serverResource = this._serverConfigurationName;
				var repositoryName = this._proto._getObjectStoreName(this);
				var connectionStr = "/content-services-graphql/graphql";
				
				if (returnProperties == null) {
					returnProperties = [];
				}
				// Get the class properties and add them (if not already) to the returned properties list
				this._propertyObjects.forEach(function(property) {
					if (returnProperties.indexOf(property.id) == -1) {
						returnProperties.push(property.id);
					}
				});

				if (this._action == Actions.EDIT_PROPERTIES) {
					var params = {
						serverAppResource: serverResource,
						repository: repositoryName,
						objectType: this._objectType,
						objectId: this._objectId,
						classId: this._classId,
						properties: properties,
						returnProperties: returnProperties,
						objectProperties: objectProperties
					};
					var updateService = this.ui.get("UpdateService");
					this._proto._callService(updateService, params);
				} else if (this._action == Actions.ADD_FOLDER) {
					var params = {
						repository: repositoryName,
						classId: this.classSelector.getSelectedItem(),
						fileInFolderId: this._parentFolderId,
						serverAppResource: serverResource,
						properties: properties
					};
					var addService = this.ui.get("AddFolderService");
					this._proto._callService(addService, params);
				} else if (this._action == Actions.ADD_DOCUMENT) {
					var classId = this.classSelector.getSelectedItem();
					var fileInput = this.context.element.querySelector(".CS_FileInput");
					var _this = this;
					var jsonProperties = JSON.parse(properties);
					this._uploadContent.uploadFile(this._parentFolderId, _this._files, classId, jsonProperties, function(results){
						_this._onAddObjectResult(_this, results);
					}, function(error){
						_this._onUpdateError(_this, error);
					});
				} else {
					var fileInput = this.context.element.querySelector(".CS_FileInput");
					var _this = this;
					this._uploadContent.uploadNewVersionFromFile(this._objectId, fileInput.files[0], function(results){
						_this._onUpdateResult(_this, results);
					}, function(error){
						_this._onUpdateError(_this, error);
					});
				}
				return true;
			} else {
				return false; // need to return something so caller will know save was never executed
			}
		};
		
		/**
		* 	Sets valid file types when adding new documents
		*	@param: fileTypes: An array of media (mime) type strings that will be used to validate files selected by the user.
		*/
		this.constructor.prototype.setFileTypes = function(fileTypes){
			this._fileTypes = fileTypes;
			var fileInput = this.context.element.querySelector(".CS_FileInput");
				
			if (fileTypes && fileTypes.length > 0){
				var acceptString = "";
				for (var i = 0; i < fileTypes.length; i++){
					if (i > 0){
						acceptString += ", ";
					}
					acceptString += fileTypes[i];
				}
				domAttr.set(fileInput, "accept", acceptString);
			}
			else {
				domAttr.remove(fileInput, "accept");
			}
		};
		
		this.constructor.prototype._storeCallbackErrback = function(callback, errback, refresh){
			this._deleteCallbackErrback();
			this._callback = callback;
			this._errback = errback;
			this._refreshAfterUpdate = refresh;
		};
		
		this.constructor.prototype._handleCallback = function(properties, contentElements, cmThumbnails, className, accessAllowed){
			if (this._refreshAfterUpdate){
				this._refreshAfterUpdateProperties(properties);
				
				// Check for a bound object and update it's properties
				if (this.context.binding) {
					var boundProperty = this.context.binding.property;
					if (boundProperty != null) {
						var contentItem = this.context.binding.boundObject[boundProperty];
						contentItem.properties = properties;
						contentItem.propertyUpdate = true;
						contentItem.viewerUpdate = false;
						if (contentElements){
							contentItem.contentElements = contentElements;
						}
						if (cmThumbnails) {
							contentItem.cmThumbnails = cmThumbnails;
						}
						this.context.binding.set("value", contentItem);
					}
				}
			}
			if (this._callback){
				this._callback(properties, contentElements, cmThumbnails, className, accessAllowed);
			}
			if (this._action == Actions.ADD_DOCUMENT && !this._uploadContent.isUploadingNewDocuments){
				this._deleteCallbackErrback();
			}
		};
		
		this.constructor.prototype._handleErrback = function(error, response){
			if (this._errback){
				this._errback(error, response);
			}
		};
		
		this.constructor.prototype._deleteCallbackErrback = function(){
			this._callback = null;
			this._errback = null;
			this._refreshAfterUpdate = null;
		};
		
		this.constructor.prototype._handleError = function(error, errorMessage){
			var logMessage;
			var errorMessage;
			if (Array.isArray(error)){
				logMessage = "Documents failed to add: " + JSON.stringify(error);
			}
			else {
				logMessage = errorMessage ? errorMessage : error.errorText;	
			}			
			console.log("CS-PropertyList:_handleError() : " + logMessage);			
			bpmext.ui.executeEventHandlingFunction(this, this.EVT_ONSVCERROR, logMessage);
			this._handleErrback(logMessage, error);
			
			if (this._action == Actions.EDIT_PROPERTIES && error.errorCode == "FNRJG1001" ) {
				// Could not find the document properties for permissions reasons, don't leave red progress indicator up
				var propertiesService = this.ui.get("GetPropertiesService");
				propertiesService._proto._setExecutionStatus(propertiesService, "cleared");
				propertiesService._proto._setExecutionStatus(propertiesService, "completed");
			}
		};
		
		this.constructor.prototype.isValid = function(){
			var valid = true;
			if (this._action == Actions.ADD_DOCUMENT || this._action == Actions.CHECKIN_DOCUMENT){
				var fileInput = this.context.element.querySelector(".CS_FileInput");
				if (!this._files || this._files.length == 0){
					valid = false;
					if (this._fileSelector.style.display != "none"){
						domClass.add(this._fileUploadButton, "CS_SelectFileError");
						var fileUploadErrorDiv = this.context.element.querySelector(".CS_FileUploadValidationMessage");
						domStyle.set(fileUploadErrorDiv, "display", "");
						this._fileUploadButton.scrollIntoView(true);
					}
				}
			}
			var numStackContainers = this.ui.getCount("PropertyStackContainer");
			for (var i = 0; i < numStackContainers; i++){
				stackContainer = this._stackLayout.ui.getChild("PropertyStackContainer", i);
				if (stackContainer){
					if (!stackContainer.isValid()){
						valid = false;
					}
				}
			}
			if (valid && this._action == Actions.ADD_DOCUMENT && !this._intializedFilename){
				valid = false;
			}
			return valid;
		};
		
		this.constructor.prototype.getPropertyValues = function(forJson){
			var propertyValues = "[";
			
			var numStackContainers = this.ui.getCount("PropertyStackContainer");
			for (var i = 0; i < numStackContainers; i++){
				stackContainer = this._stackLayout.ui.getChild("PropertyStackContainer", i);
				if (stackContainer){
					propertyValue = stackContainer.getPropertyValue(forJson);
					if (propertyValue != null){
						if (propertyValues.length > 1){
							propertyValues += ", ";
						}
						propertyValues += propertyValue;
					}
				}
			}
			
			return propertyValues + "]";
		};
		
		this.constructor.prototype._onClassSelectChange = function (view, selectedClassId){
			if ((this._action == Actions.ADD_FOLDER || this._action == Actions.ADD_DOCUMENT) && selectedClassId != null){
				if (this._action == Actions.ADD_DOCUMENT) {
					var numStackContainers = this.ui.getCount("PropertyStackContainer");
					for (var i = 0; i < numStackContainers; i++){
						stackContainer = this.ui.get("PropertyStackContainer", i);
						if (stackContainer){
							if (stackContainer.getPropertyId() == "DocumentTitle"){
								this._currentDocumentTitle = stackContainer.getSVCPInputValue();
								break;
							}
						}
					}
				}
			
				// See if the class is already in the metadataCache.
				var classDescription = this._metadataCache[selectedClassId];
				if (!classDescription){
					this._propertyObjects = [];
					this._setProperties();
					var params = {
						repository: this._proto._getObjectStoreName(view),
						serverAppResource: this._serverConfigurationName,
						classId: selectedClassId
					};
					this.classDetailsService = this.ui.get("GetClassDetails");
					this._proto._callService(this.classDetailsService, params);
				} else {
					var propertyValues = this._action == Actions.ADD_DOCUMENT ? this._setDocumentTitle() : [];
					this._propertyObjects = this._proto._mergeMetadata(this, classDescription, propertyValues, true);
					this._setProperties();
					this._uploadContent.setClassProperties(classDescription);
					if (this._action == Actions.ADD_DOCUMENT){
						var _this = this;
						setTimeout(function(){
							_this._displaySelectedFileName();
						}, 300);
					}
				}
			}
		};
		
		this.constructor.prototype._setDocumentTitle = function(){
			var propertyValues = [];
			if (this._action == Actions.ADD_DOCUMENT && this._currentDocumentTitle){
				propertyValues.push({
					id: "DocumentTitle",
					value: this._currentDocumentTitle,
				});
			}
			this._currentDocumentTitle = null;
			return propertyValues;
		};
		
		this.constructor.prototype.callGetPropertiesService = function (objectId, classId) {
			var contentClass = this._metadataCache[classId];
			var propertyDescriptions = contentClass.propertyDescriptions.items ? contentClass.propertyDescriptions.items : contentClass.propertyDescriptions;
			var propertyNames = [];
			var getControllerClass = false;
			for (var i = 0; i < propertyDescriptions.length; i++){
				var propertyDescription = propertyDescriptions[i];
				if ((propertyDescription.isSystemOwned && propertyDescription.symbolicName != "FolderName") ||
					propertyDescription.symbolicName == "MimeType"){
					continue;
				}
				if (propertyDescription.dataType == "BINARY" || 
					(propertyDescription.isHidden && propertyDescription.symbolicName != "DbaBatchError" && propertyDescription.symbolicName != "DbaCaptureError")) {
					continue;
				}
				
				if (propertyDescription.dataType == "OBJECT") {
					if (this._action == Actions.EDIT_PROPERTIES) {
						if (propertyDescription.symbolicName == this._controllerDocumentProperty || propertyDescription.id == this._controllerDocumentProperty) {
							if (!this._controllerClass) {
								// If there is no controller class yet, need to call the servies to get that first
								this._controlledDocumentClass = contentClass.symbolicName;
								this._controllerClass = propertyDescription.requiredClass.symbolicName;
								getControllerClass = true;
								break;
							} else {
								// Just in case there are different controller document subclasses, make sure name is correct
								this._controlledDocumentClass = contentClass.symbolicName;
							}
						} else {
							continue;
						}						
					} else {
						continue;
					}
				}
				propertyNames.push(propertyDescription.symbolicName);
			}	
			
			if (getControllerClass) {
				var params = {
					classId: this._controllerClass,
					repository: this._proto._getObjectStoreName(this),
					serverAppResource: this._serverConfigurationName
				};
				this.classDetailsService = this.ui.get("GetClassDetails");
				this._proto._callService(this.classDetailsService, params);
			} else {				
				var ovpPropertyNames = [];
				if (classId == this._controlledDocumentClass) {
					var controllerClass = this._metadataCache[this._controllerClass];
					var controllerPropertyDescriptions = controllerClass.propertyDescriptions.items ? controllerClass.propertyDescriptions.items : controllerClass.propertyDescriptions;
					for (var j = 0; j < controllerPropertyDescriptions.length; j++) {
						var controllerPropertyDescription = controllerPropertyDescriptions[j];
						controllerPropertyDescription.isReadOnly = true;
						if (controllerPropertyDescription.isSystemOwned || 
							(controllerPropertyDescription.isHidden && controllerPropertyDescription.symbolicName != "DbaCaptureError" && controllerPropertyDescription.symbolicName != "DbaBatchError") || controllerPropertyDescription.dataType == "BINARY" || 
							controllerPropertyDescription.dataType == "OBJECT"){
								
							continue;
						}
						ovpPropertyNames.push(controllerPropertyDescription.symbolicName);
					}
				}
				var params = {
					repository: this._proto._getObjectStoreName(this),
					serverAppResource: this._serverConfigurationName,
					objectType: this._objectType,
					objectId: objectId,
					classId: classId,
					properties: propertyNames,
					ovpProperties: ovpPropertyNames
				};
				var propertiesService = this.ui.get("GetPropertiesService");
				this._proto._callService(propertiesService, params);
			}
		};
				
		this.constructor.prototype._onGetPropertiesResult = function (view, response){
			// Get properties results now return a contentItem like object.
			var propertyObjects = response.results.properties.items ? response.results.properties.items : response.results.properties;
			var classDescription = this._metadataCache[response.results.className];
			if (!classDescription){
				// The document may have changed class due to batch processing. Get the new class and stash the property objects in the request so we can get them later.
				this._classId = response.results.className;
				var params = {
					classId: this._classId,
					repository: this._proto._getObjectStoreName(this),
					serverAppResource: this._serverConfigurationName,
					propertyObjects: propertyObjects
				}
				this.classDetailsService = this.ui.get("GetClassDetails");
				this._proto._callService(this.classDetailsService, params);
			} else {
				this._propertyObjects = this._proto._mergeMetadata(this, classDescription, propertyObjects, false, this._valueOnly);
				this._setProperties();
				if (this._action == Actions.EDIT_PROPERTIES){
					this._handleCallback(propertyObjects);
				}
			}
		};

		this.constructor.prototype._onGetPropertiesError = function (view, response){
			var errorMessage;
			switch(response.errorCode){
				case"FNRJG1006":
					errorMessage = messages.properties_document_or_folder_not_found;
					break;
			}
			this._handleError(response, errorMessage);
		};
		
		this.constructor.prototype._onClassDetailsResult = function (view, response){
			var jsonClass = response.results;
			var classId = jsonClass["symbolicName"];
			this._metadataCache[classId] = jsonClass;

			if (this._action == Actions.EDIT_PROPERTIES){
				if (this._classId == classId){
					this.classSelector.appendItem(classId, jsonClass.displayName);
					this.classSelector.setSelectedItem(classId);
					domStyle.set(this.classSelector.context.element, "display", "");
					this.classSelector.setVisible(true);
					var parameters = this.classDetailsService.getInputData();
					if (parameters && parameters.propertyObjects){
						// We already have the properties for the object in question, no need to call the get properties service.
						this._propertyObjects = this._proto._mergeMetadata(this, jsonClass, parameters.propertyObjects, false, this._valueOnly);
						this._setProperties();
						if (this._action == Actions.EDIT_PROPERTIES){
							this._handleCallback(this._propertyObjects);
						}
					} else {
						this.callGetPropertiesService(this._objectId, classId);
					}
				} else if (this._controllerClass == classId){
					this.callGetPropertiesService(this._objectId, this._controlledDocumentClass);
				}
			} else if (this._action == Actions.ADD_BATCH){
				var displayProperties = {};
				BATCH_DISPLAY_PROPERTIES.forEach(function(symbolicName){
					displayProperties[symbolicName] = symbolicName;
				});
					
				var filteredPropertyDescs = [];
				var propertyDescs = jsonClass.propertyDescriptions.items ? jsonClass.propertyDescriptions.items : jsonClass.propertyDescriptions;
				propertyDescs.forEach(function(propertyDesc){
					if (!displayProperties[propertyDesc.symbolicName]){
						propertyDesc.isHidden = true;
					}
					filteredPropertyDescs.push(propertyDesc);
				});
					
				jsonClass.propertyDescriptions = filteredPropertyDescs;
				this._metadataCache[classId] = jsonClass;
				this._propertyObjects = this._proto._mergeMetadata(this, jsonClass, [], true);
				this._setProperties();
			} else {
				var propertyValues = this._action == Actions.ADD_DOCUMENT ? this._setDocumentTitle() : [];
				this._propertyObjects = this._proto._mergeMetadata(this, jsonClass, propertyValues, true, this._valueOnly);
				this._uploadContent.setClassProperties(jsonClass);
				this._setProperties();
				if (this._action == Actions.ADD_DOCUMENT){
					var _this = this;
					setTimeout(function(){
						_this._displaySelectedFileName();
						_this._intializedFilename = true;
					}, 300);
				}
			}
		};
		
		this.constructor.prototype._onClassDetailsError = function (view, response){
			this._handleError(response, messages.properties_class_not_found);
		};
		
		this.constructor.prototype._onClassSelectError = function (view, response){
			this._handleError(response, messages.properties_class_not_found);
		}
				
		this.constructor.prototype._onUpdateResult = function (view, response){
			var results = response.results ? response.results : response;
			var properties = results.properties.items ? results.properties.items : results.properties;
			var contentElements = results.contentElements ? 
				results.contentElements.items ? results.contentElements.items : results.contentElements : null;
			var cmThumbnails = results.cmThumbnails ? 
				results.cmThumbnails.items ? results.cmThumbnails.items : results.cmThumbnails : null;
			this._handleCallback(properties, contentElements, cmThumbnails, results.className, results.accessAllowed);
		};
		
		this.constructor.prototype._onUpdateError = function (view, response){
			var errorMessage = response.errorText;
			switch(response.errorCode){
				case"FNRJG1017":
					if (this._action == Actions.ADD_FOLDER){
						errorMessage = messages.properties_folder_duplicate_item_invalid_prop;
					}
					else {
						errorMessage = messages.properties_item_invalid_prop;
					}
					break;
			}
			this._handleError(response, errorMessage);
		};
		
		this.constructor.prototype._refreshAfterUpdateProperties = function(properties){
			var propertiesLookup = {};
			properties.forEach(function(property){
				propertiesLookup[property.id] = property.value;
			});
							
			// Update property objects with values returned in results.
			this._propertyObjects.forEach(function(propertyObject){
				if (propertyObject.cardinality == "SINGLE"){
					propertyObject.singleCardinalityValue = propertiesLookup[propertyObject.id];
					propertyObject.listCardinalityValues = [];
				}
				else if (propertyObject.cardinality == "LIST"){
					propertyObject.singleCardinalityValue = null;
					propertyObject.listCardinalityValues = propertiesLookup[propertyObject.id];
					
					// Work around a date binding issue for MVCPs
					if (propertyObject.type == "DATE"){
						dateListValues = propertyObject.listCardinalityValues.items ? propertyObject.listCardinalityValues.items : propertyObject.listCardinalityValues;
						propertyObject.listCardinalityValues = dateListValues.map(function(dateStringValue){
							return new Date(dateStringValue);
						})
					}
				}
			});
			this._setProperties();
		};
		
		this.constructor.prototype._onAddObjectResult = function (view, response){
			var results = response.results ? response.results : response;
			var properties = results.properties ? results.properties.items ? results.properties.items : results.properties: results;
			var contentElements = results.contentElements ? 
				results.contentElements.items ? results.contentElements.items : results.contentElements : null;
			var cmThumbnails = results.cmThumbnails ? 
				results.cmThumbnails.items ? results.cmThumbnails.items : results.cmThumbnails : null;
			this._objectId = results.id ? results.id : null;
			
			if (this.isVisible()){
				this._action = Actions.EDIT_PROPERTIES;
				var classId = this.classSelector.getSelectedItem();
				var contentClass = this._metadataCache[classId];
					
				this.classSelector.clearItems();
				this.classSelector.appendItem(classId, contentClass.displayName);
				this.classSelector.setSelectedItem(classId);
				this.classSelector.setEnabled(false);
				
				domStyle.set(this._fileSelector, "display", "none");
			}
			
			this._handleCallback(properties, contentElements, cmThumbnails, results.className, results.accessAllowed);
		};
		
		this.constructor.prototype._displaySelectedFileName = function(){
			var fileNameDisplay = "";
			var fileNames = "";
			if (this._files && this._files.length > 0){
				if (this._files.length > 1){
					fileNameDisplay = this._files.length + " files";
				}
				else {
					fileNameDisplay = this._files[0].name;
				}
				for (var i = 0; i < this._files.length; i++){
					var file = this._files[i];
					if (fileNames.length > 0){
						fileNames += "\x0A";
					}
					fileNames += file.name;
				}
			}
			
			var fileNameElement = this.context.element.querySelector(".CS_FileName");
			domAttr.set(fileNameElement, "title", fileNames);
			var textNode;
			for(i = 0; i < fileNameElement.childNodes.length; i++){
				var child = fileNameElement.childNodes[i];
				if (child.nodeType == Node.TEXT_NODE){
					textNode = child;
					break;
				}
			}
			if (!textNode){
				textNode = document.createTextNode("");
				fileNameElement.appendChild(textNode);
			}
			textNode.nodeValue = fileNameDisplay;
			var fileContainer = this.context.element.querySelector(".CS_FileContainer");
			if (fileNameDisplay && fileNameDisplay.length > 0){
				domStyle.set(fileContainer, "display", "");
			}
			else {
				domStyle.set(fileContainer, "display", "none");
			}
			
			// Clear validation error.
			domClass.remove(this._fileUploadButton, "CS_SelectFileError");
			var fileUploadErrorDiv = this.context.element.querySelector(".CS_FileUploadValidationMessage");
			domStyle.set(fileUploadErrorDiv, "display", "none");
			
			if (this._action == Actions.ADD_DOCUMENT){
				var numStackContainers = this.ui.getCount("PropertyStackContainer");
				for (var i = 0; i < numStackContainers; i++){
					stackContainer = this.ui.get("PropertyStackContainer", i);
					if (stackContainer){
						if (stackContainer.getPropertyId() == "DocumentTitle"){
							var currentValue = stackContainer.getSVCPInputValue();							
							if (!currentValue || currentValue.length == 0 || (this._previousFileName && this._previousFileName == currentValue)){
								if (this._files && this._files.length > 1){
									stackContainer.setSVCPInputValue(messages.properties_use_file_name, true);
								}
								else {
									stackContainer.setSVCPInputValue(fileNameDisplay);
								}
							}
							break;
						}
					}
				}
				this._previousFileName = fileNameDisplay;
			}
		};
		
		this.constructor.prototype.change = function (event){
			try	{
				if (event.type != "config" && this.context.binding) {
					var contentItem = event.newVal;
					
					// Store contentItem so we can retrieve the properties from it later
					this._contentItem = contentItem;
					
					if (contentItem != null){
						if (!contentItem.id){
							if (this._editingProperties()){
								this._cancelEdit(false);
							}
							this.clear();
							domStyle.set(this._serviceLayout.context.element, "display", "none");
							this._proto._displayNoItemSelected(this, true);
						}
						else if (contentItem.id != null && !contentItem.propertyUpdate){
							console.log("CS-PropertyList:change() : Change update for bound object: " + contentItem.name);
							var objectType = contentItem.baseType;
							
							domStyle.set(this._serviceLayout.context.element, "display", "");
							this._proto._displayNoItemSelected(this, false);
							if (this._editingProperties()){
								if (this._propertyUpdated) {
									this._moveEditObjectId = contentItem.id;
									this._moveEditObjectClass = contentItem.className;
									this._moveEditObjectType = objectType;
								
									var objectName;
									for (var i = 0; i < this._propertyObjects.length; i++){
										var propertyObject = this._propertyObjects[i];
										if (propertyObject.id == "DocumentTitle" || propertyObject.id == "FolderName"){
											objectName = propertyObject.singleCardinalityValue;
											break;
										}
									}
								
									var confirmMoveText = this.ui.get("ConfirmEditMoveOutputText");
									confirmMoveText.setText(string.substitute(messages.properties_move_edit_confirm_msg, [objectName]));				
									this._confirmEditMoveDlg.setVisible(true);
									var _this = this;
									setTimeout(function(){
										_this._confirmEditYesBtn.focus();
									}, 300);
								} else {
									this.clear();
									this.displayProperties(contentItem.id, contentItem.className, objectType);
								}
							} else {
								this.setValueOnly(true);
								this.setReadOnly(true);
								this.clear();
								this.displayProperties(contentItem.id, contentItem.className, objectType);
							}
						}
					}
				}
			} catch (e) {
				bpmext.log.error("Error on change event [" + this.ui.getAbsoluteName() + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};
		
		this.constructor.prototype._confirmEditMoveNoBtnClicked = function(){
			this._confirmEditMoveDlg.setVisible(false);	
			this.displayProperties(this._moveEditObjectId, this._moveEditObjectClass, this._moveEditObjectType);
			this._moveEditObjectId = this._moveEditObjectClass = this._moveEditObjectType = null;	
		};
		
		this.constructor.prototype._confirmEditMoveYesBtnClicked = function(){
			this._confirmEditMoveDlg.setVisible(false);	
			var _this = this;
			this._saveEdit(function(){
				_this._confirmEditMoveNoBtnClicked();
			}, false);
		};
		
		this.constructor.prototype.isUploadingDocuments = function(){
			return this._uploadContent.isUploadingNewDocuments();
		}
	
		this.constructor.prototype.view = function () {
            try {
				this._proto._handleVisibility(this);
				
				// Check for a bound object use it to re-render the properties UX with
				if (this.context.binding) {
					var boundProperty = this.context.binding.property;
					if (boundProperty != null) {
						var contentItem = this.context.binding.boundObject[boundProperty];
						if (contentItem.id != null && contentItem.id != "") {
							console.log("CS-PropertyList:view() : View update for: " + contentItem.name);
							var objectType = contentItem.isFolder ? "Folder" : "Document";
							this.setValueOnly(true);
							this.setReadOnly(true);
							this.clear();
							this.displayProperties(contentItem.id, contentItem.className, objectType);
						} else {
							this._proto._displayNoItemSelected(this, true);
							console.log("CS-PropertyList:view() : No bound object to view.");
						}
					}
				}
 			} catch (e) {
                bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                if (e.stack) {
                    bpmext.log.error("  Call stack: " + e.stack);
				}
            }
        };
	
		this.constructor.prototype.load = function() {
			try	{
				this.classSelector = this.ui.getChild("ClassSelect");
				domStyle.set(this.classSelector.context.element, "display", "none");
				
				this._fileSelector = this.context.element.querySelector(".CS_FileUpload");
				var fileSelectorId = new Date().getTime();
				var fileInput = this.context.element.querySelector(".CS_FileInput");
				
				var parentNameLabel = this.context.element.querySelector(".CS_ParentNameLabel");
				var parentNameText = document.createTextNode(messages.properties_file_save_in);
				parentNameLabel.appendChild(parentNameText);
				
				this._fileUploadButton = this.context.element.querySelector(".CS_FileButton");
				domAttr.set(this._fileUploadButton, "aria-label", messages.properties_file_name);
				var uploadText = document.createTextNode(messages.properties_file_name);
				this._fileUploadButton.appendChild(uploadText);
				domAttr.set(fileInput, "id", fileSelectorId);
				domAttr.set(this._fileUploadButton, "for", fileSelectorId);
				
				var fileContainer = this.context.element.querySelector(".CS_FileContainer");
				domStyle.set(fileContainer, "display", "none");

				var _this = this;
				fileInput.onfocus = function(){
					domClass.add(_this._fileUploadButton, "CS_FileButtonFocus");
				}
				fileInput.onblur = function(){
					domClass.remove(_this._fileUploadButton, "CS_FileButtonFocus");
				}

				fileInput.onchange = function(){
					var isValid = true;
					var maxAddsAvaliable = _this._uploadContent.getMaxAddsAvailable();
					if (this.files.length > maxAddsAvaliable){
						isValid = false;
						setAlertMessage(messages.contlist_progress_alert, string.substitute(messages.contlist_add_doc_max_exceeded, [maxAddsAvaliable, this.files.length]), 
						"D", 4000, domClass, domStyle, domAttr, messages);
					}
					else {
						if (_this._fileTypes && _this._fileTypes.length > 0){
							for (var i = 0; i < this.files.length; i++){
								var file = this.files[i];
								var index = file.name.lastIndexOf(".");
								var fileExtension = "";
								if (index != -1) {
									fileExtension = file.name.substring(index, file.name.length);
								}
								if (fileExtension.length > 0 && !_this._fileTypes.includes(fileExtension)){
									console.log("CS-PropertyList:load() : Found invalid file type: " + file.name + " " + fileExtension);
									var fileTypes = _this._fileTypes.join();								
									setAlertMessage(messages.contlist_progress_alert, string.substitute(messages.contlist_drop_invalid_file_types, [fileTypes]), "D", 
										6000, domClass, domStyle, domAttr, messages);
									isValid = false;
									break;
								}
							}
						}
					}
					if (isValid){
						_this._files = this.files;
						_this._displaySelectedFileName();
					}
				}
				
				bpmext.ui.registerEventHandlingFunction(this, this.EVT_ONSVCERROR, "errors");				

				var fileSelectorLabel = this._fileSelector.querySelector(".CS_FileSelectorLabel");
				var fileSelectorLabelText = document.createTextNode(messages.properties_file_name);
				fileSelectorLabel.appendChild(fileSelectorLabelText);
				var fileSelectorValidationMsg = this._fileSelector.querySelector(".CS_FileUploadValidationMessage");
				var fileSelectorErrorText = document.createTextNode(messages.properties_file_required);
				fileSelectorValidationMsg.appendChild(fileSelectorErrorText);
				domStyle.set(this._fileSelector, "display", "none");
				
				this._stackLayout = this.ui.getChild("StackLayout");
				
				this._confirmEditMoveDlg = this.ui.getChild("ConfirmEditMoveModal");
				var confirmEditPanel = this._confirmEditMoveDlg.ui.getChild("ConfirmMovePanel");
				confirmEditPanel.setTitle(messages.properties_move_edit_confirm_title);
				var confirmButtonLayout = confirmEditPanel.ui.getChild("ConfirmButtonLayout");
				this._confirmEditNoBtn = confirmButtonLayout.ui.getChild("ConfirmEditNoButton");
				this._confirmEditNoBtn.setText(messages.properties_move_edit_confirm_no);
				this._confirmEditYesBtn = confirmButtonLayout.ui.getChild("ConfirmEditYesButton");
				this._confirmEditYesBtn.setText(messages.properties_move_edit_confirm_yes);
				
				this._noItemSelectedDiv = this.context.element.querySelector(".CS_NoItemDisplayed");
				var noItemSelectedText = document.createTextNode(messages.properties_no_item_selected);
				this._noItemSelectedDiv.appendChild(noItemSelectedText);
				domStyle.set(this._noItemSelectedDiv, "display", "none");
				
				this._toolbarLayout = this.ui.getChild("ToolbarLayout");
				domStyle.set(this._toolbarLayout.context.element, "display", "none");
				this._saveButton = this._toolbarLayout.ui.getChild("SaveButton");
				domStyle.set(this._saveButton.context.element, "display", "none");
				domAttr.set(this._saveButton.context.element, "title", messages.contlist_save_btn_label);
				this._saveButton.context.element.addEventListener('click', function(evt){
					evt.preventDefault();
					_this._saveEdit(null, true);
				});
				this._saveButton.context.element.addEventListener('keyup', function(evt){
					if (evt.keyCode == 13){
						evt.preventDefault();
						_this._saveEdit(null, true);
					}
				});
				var saveImage = this._saveButton.context.element.querySelector("img");
				domAttr.set(saveImage, "title", messages.contlist_save_btn_label);
				domAttr.set(saveImage, "tabindex", "-1");
				
				this._cancelButton = this._toolbarLayout.ui.getChild("CancelButton");
				domStyle.set(this._cancelButton.context.element, "display", "none");				
				domAttr.set(this._cancelButton.context.element, "title", messages.contlist_cancel_btn_label);
				this._cancelButton.context.element.addEventListener('click', function(evt){
					evt.preventDefault();
					_this._cancelEdit(true);
				});
				this._cancelButton.context.element.addEventListener('keyup', function(evt){
					if (evt.keyCode == 13){
						evt.preventDefault();
						_this._cancelEdit(true);
					}
				});
				var cancelImage = this._cancelButton.context.element.querySelector("img");
				domAttr.set(cancelImage, "title", messages.contlist_cancel_btn_label);
				domAttr.set(cancelImage, "tabindex", "-1");
				
				this._editButton = this._toolbarLayout.ui.getChild("EditButton");
				domStyle.set(this._editButton.context.element, "display", "none");			
				domAttr.set(this._editButton.context.element, "title", messages.contlist_edit_btn_label);
				this._editButton.context.element.addEventListener('click', function(evt){
					evt.preventDefault();
					_this._editProperties();
				});
				this._editButton.context.element.addEventListener('keyup', function(evt){
					if (evt.keyCode == 13){
						evt.preventDefault();
						_this._editProperties();
					}
				});
				var editImage = this._editButton.context.element.querySelector("img");
				domAttr.set(editImage, "title", messages.contlist_edit_btn_label);
				domAttr.set(editImage, "tabindex", "-1");
				
				this._serviceLayout = this.ui.getChild("ServiceLayout");
				domStyle.set(this._serviceLayout.context.element, "display", "none");
				
				this._uploadContent = this.ui.get("UploadContent");
				
				var options = this.context.options;
				if (!options.documentClasses) {
					options.documentClasses = bpmext.ui.substituteConfigOption(this, "documentClasses", null);
				}
				this.classSelector.setDocumentClasses(options.documentClasses.get("value"));
				
				if (!options.folderClasses) {
					options.folderClasses = bpmext.ui.substituteConfigOption(this, "folderClasses", null);
				}
				this.classSelector.setFolderClasses(options.folderClasses.get("value"));
				
				this.classSelector.setServerConfigurationName(this._serverConfigurationName);
			
				if (!options.objectStoreName) {
                    options.objectStoreName = bpmext.ui.substituteConfigOption(this, "objectStoreName", null);
				}
				this.classSelector.setObjectStoreName(this._proto._getObjectStoreName(this));
				this._uploadContent.setObjectStoreName(this._proto._getObjectStoreName(this));

				if (options.hideTimePicker == null){
					options.hideTimePicker = bpmext.ui.substituteConfigOption(this, "hideTimePicker", false);
				}
				
				if (options.displayEditInterface == null){
					options.displayEditInterface = bpmext.ui.substituteConfigOption(this, "displayEditInterface", false);
				}
				
				if (options.controllerDocumentProperty == null){
					options.controllerDocumentProperty = bpmext.ui.substituteConfigOption(this, "controllerDocumentProperty", "");
				}
				this._controllerDocumentProperty = options.controllerDocumentProperty.get("value");
				
				domClass.add(this.context.element, "CS_Properties");
				
				this.context.element.addEventListener('dragover', function(evt){
					evt.preventDefault();
					evt.dataTransfer.dropEffect = "none";
				}, false);
				this.context.element.addEventListener('drop', function(evt){
					evt.preventDefault();
					return false;
				}, false);
			} catch (e) {
				bpmext.log.error("Error on load event [" + this.context.viewid + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};
		
		this.constructor.prototype._editProperties = function(){
			this.setValueOnly(false);
			this.setReadOnly(false);
			domStyle.set(this._editButton.context.element, "display", "none");
			domStyle.set(this._cancelButton.context.element, "display", "");
			domStyle.set(this._saveButton.context.element, "display", "");
			var classDescription = this._metadataCache[this._classId];
			this._propertyObjects =  this._proto._mergeMetadata(this, classDescription, this._propertyObjects);
			this._stackLayout._setFocus = true;
			this._setProperties();
		};
		
		this.constructor.prototype._cancelEdit = function(resetProperties){
			this.setValueOnly(true);
			this.setReadOnly(true);
			domStyle.set(this._editButton.context.element, "display", "");
			domStyle.set(this._cancelButton.context.element, "display", "none");
			domStyle.set(this._saveButton.context.element, "display", "none");
			if (resetProperties){
				var classDescription = this._metadataCache[this._classId];
				this._propertyObjects =  this._proto._mergeMetadata(this, classDescription, this._propertyObjects, false, true, true);
				this._setProperties();
			}
		};
		
		this.constructor.prototype._saveEdit = function(callback, refresh){
			var properties = this._contentItem.properties.items ? this._contentItem.properties.items : this._contentItem.properties;
			var returnProperties = [];
			var objectProperties = [];
			properties.forEach(function(property) {
				returnProperties.push(property.id);
				if (property.objectValue) {
					var ovpProperties = property.objectValue.properties.items ? property.objectValue.properties.items : property.objectValue.properties;
					ovpProperties.forEach(function(objectProperty) {
						objectProperties.push(objectProperty.id);
					});
				}
			});
			
			this.save(returnProperties, objectProperties, refresh, function() {
				this._propertyUpdated = false;
				// Call out to the CS_Alert utility class to handle displaying the alert message
				setAlertMessage(messages.contlist_progress_success, messages.properties_edit_save_success, "S", 4000, domClass, domStyle, domAttr, messages);
				if (callback){
					callback();
				}
			}, function(error){
				// Call out to the CS_Alert utility class to handle displaying the alert message
				setAlertMessage("Alert", messages.properties_edit_save_failure, "D", 4000, domClass, domStyle, domAttr, messages);
			});
		};
		
		this.constructor.prototype.addAdditionalPropertyOnAdd = function(additionalPropertyId, additionalPropertyValue){
			var uploadComponent = this.ui.get("UploadContent");
			uploadComponent.addAdditionalPropertyOnAdd(additionalPropertyId, additionalPropertyValue);
		};
		
		this.constructor.prototype.addConfigValueOnAdd = function(configProperty, configId, configValue){
			var uploadComponent = this.ui.get("UploadContent");
			uploadComponent.addConfigValueOnAdd(configProperty, configId, configValue);
		}
		
		this.constructor.prototype._propertyChanged = function(){
			this._propertyUpdated = true;
		};
		
		this.constructor.prototype._editingProperties = function(){
			return (domStyle.get(this._cancelButton.context.element, "display") != "none") && (domStyle.get(this._toolbarLayout.context.element, "display") != "none");
		};
		
		this.constructor.prototype._onProcessIndicatorRemovePendingFile = function(batchId, fileName){
			this._uploadContent.removeFileFromQueue(batchId, fileName);
		};
		
		this.constructor.prototype.setObjectStoreName = function(objectStoreName){
			this.classSelector.setObjectStoreName(objectStoreName);
			this._uploadContent.setObjectStoreName(objectStoreName);
			this.context.options.objectStoreName.set("value", objectStoreName);
		};
		
		this.constructor.prototype.getObjectStoreName = function(){
			return this.context.options.objectStoreName.get("value");
		};
		
		this.constructor.prototype.setServerConfigurationName = function(serverConfigurationName){
			this.classSelector.setServerConfigurationName(serverConfigurationName);
			this._serverConfigurationName = serverConfigurationName;
		};
		
		this.constructor.prototype.getServerConfigurationName = function(){
			return this._serverConfigurationName;
		};
		
		this.constructor.prototype.setDocumentClasses = function(documentClasses){
			this.classSelector.setDocumentClasses(documentClasses);
		};
		
		this.constructor.prototype.getDocumentClasses = function(){
			this.classSelector.getDocumentClasses();
		};
		
		this.constructor.prototype.setFolderClasses = function(folderClasses){
			this.classSelector.setFolderClasses(folderClasses);
		};
		
		this.constructor.prototype.getFolderClasses = function(){
			this.classSelector.getFolderClasses();
		};
		
		this.constructor.prototype.getFiles = function(){
			return this._files;
		}
		
		this.constructor.prototype.getParentFolderId = function(){
			return this._parentFolderId;
		}
		
		this.constructor.prototype.setIncludeTimePicker = function(includeTimePicker){
			this.context.options.hideTimePicker.set("value", !includeTimePicker);
		};
		
		this.constructor.prototype.setProgressIndicator = function(progressIndicator){
			this._uploadContent.setProgressIndicator(progressIndicator);
		};
		
		this.constructor.prototype.setPropertyPoller = function(propertyPoller){
			this._uploadContent.setPropertyPoller(propertyPoller);
		};
		
		this.constructor.prototype.setControllerDocumentProperty = function(controllerDocumentProperty){
			this._controllerDocumentProperty = controllerDocumentProperty;
			this._uploadContent.setControllerDocumentProperty(controllerDocumentProperty);
		};
	}	
}
	