/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019 - 2020. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

var mixObject = {
	createPreview: function(containingDiv, labelText, callback){
		var bpmextUri = this.context.getManagedAssetUrl("BPMExt-Core-Designer.js", this.context.assetType_WEB, "SYSBPMUI");
		require([ "dojo/dom-construct", "dojo/dom-class", "dojo/dom-attr", bpmextUri], this.lang.hitch(this, function(domConstruct, domClass, domAttr, bpmext) {
			bpmext.uidesign.css.ensureSparkUIClass(containingDiv);
			bpmext.uidesign.css.ensureGlyphsLoaded(this);
			
			this.context.coachViewData.containingDiv = containingDiv;
			
			var tempID;
			while(true) {
				tempID = dojox.uuid.generateRandomUuid();
				if (this.context.coachViewData.containingDiv.querySelector("div[data-temp-id='" + tempID + "']") == null) {
					break;
				}
			}
			
			this.context.coachViewData.containingDiv.setAttribute("data-temp-id", encodeURIComponent(tempID));
			domClass.add(this.context.coachViewData.containingDiv, "WYSIWYGContentList");
			
			this.context.coachViewData.label = this.context.coachViewData.containingDiv.querySelector("div[data-temp-id='" + tempID + "']  .contentlist-title");
			this.context.coachViewData.labelTextDom = document.createTextNode(labelText);
			this.context.coachViewData.label.appendChild(this.context.coachViewData.labelTextDom);
			
			this.context.coachViewData.icon = this.context.coachViewData.containingDiv.querySelector("div[data-temp-id='" + tempID + "']  .contentlist-heading-icon .fa");
			this.context.coachViewData.iconClass = "fa";
			
			//Added for WYSIWYG for default width & height
			this.context.coachViewData.defaultWidth = "100%";
			
			this.context.coachViewData.bodyDiv = this.context.coachViewData.containingDiv.querySelector("div[data-temp-id='" + tempID + "'] .SPARKPanel.panel .contentlist-body");

			this.context.coachViewData.searchIconDiv = this.context.coachViewData.containingDiv.querySelector("div[data-temp-id='" + tempID + "'] .SPARKPanel.panel .contentlist-toolbar-icon-search");
			this.context.coachViewData.searchLabelDiv = this.context.coachViewData.containingDiv.querySelector("div[data-temp-id='" + tempID + "'] .SPARKPanel.panel .contentlist-toolbar-search");
			this.context.coachViewData.filterBtnDiv = this.context.coachViewData.containingDiv.querySelector("div[data-temp-id='" + tempID + "'] .SPARKPanel.panel .contentlist-toolbar-icon-filter");

			this.context.coachViewData.dateDivs = this.context.coachViewData.containingDiv.querySelectorAll("div[data-temp-id='" + tempID + "'] .SPARKPanel.panel .contentlist-date");
			this.context.coachViewData.dateTimeDivs = this.context.coachViewData.containingDiv.querySelectorAll("div[data-temp-id='" + tempID + "'] .SPARKPanel.panel .contentlist-datetime");

			this.context.coachViewData.pageItemsDiv = this.context.coachViewData.containingDiv.querySelector("div[data-temp-id='" + tempID + "'] .SPARKPanel.panel .contentlist-items");
			
			this.context.coachViewData.labelHandler = bpmext.uidesign.createLabelHandler(this.context.coachViewData.labelTextDom, undefined/*we handle label vis*/, this.context.coachViewData.containingDiv, false, true);
			
			callback();
		}));
	},
	
	getLabelDomElement: function() {
		return this.context.coachViewData.label;
	},
	
	propertyChanged: function(propertyName, propertyValue){
		var configHelperUri = this.context.getManagedAssetUrl("BPMExt-Core-ConfigHelper.js",this.context.assetType_WEB, "SYSBPMUI");
		require(["dojo/dom-style", "dojo/dom-class",  "dojo/dom-construct", configHelperUri], this.lang.hitch(this, function(domStyle, domClass, domConstruct, configHelper){
			this.context.coachViewData.labelHandler.propertyChanged(propertyName, propertyValue);

			if (propertyName == "@style") {
				var width = configHelper.getResponsiveConfigOptionValue(this, "width");
				var minWidth = configHelper.getResponsiveConfigOptionValue(this, "@minWidth");
				var finalWidth = width || minWidth || this.context.coachViewData.width;
				if (!!finalWidth) {
					this.context.coachViewData.containingDiv.style.width =  isNaN(finalWidth) ? finalWidth : (finalWidth + "px");
				} else {
					this.context.coachViewData.containingDiv.style.width = "";
				}
			} else if (propertyName == "initialPageSize") {
				console.log("CS-ContentList-Preview:propertyChanged() : Property Name: " + propertyName + ", value: " + propertyValue);
				if (propertyValue === null || propertyValue === undefined || propertyValue == "") {
					this.context.coachViewData.pageItemsDiv.innerHTML = encodeURIComponent("20");
				} else {
					this.context.coachViewData.pageItemsDiv.innerHTML = encodeURIComponent(propertyValue);
				}
			} else if (propertyName == "width") {		
				this.context.coachViewData.width = propertyValue;
				if (propertyValue === null || propertyValue === undefined || propertyValue == "") {
					this.context.coachViewData.containingDiv.style.width = this.context.coachViewData.defaultWidth;
				} else {
					this.context.coachViewData.containingDiv.style.width = isNaN(propertyValue) ? propertyValue : propertyValue + "px";
				}
			} else if (propertyName == "height") {
				this.context.coachViewData.height = propertyValue;
				if (!propertyValue) {
					this.context.coachViewData.bodyDiv.style.height = "";
					this.context.coachViewData.bodyDiv.style.overflowY = "";
				} else {
					this.context.coachViewData.bodyDiv.style.height = isNaN(propertyValue) ? propertyValue : propertyValue + "px";
					this.context.coachViewData.bodyDiv.style.overflowY = "scroll";
				}
			} else if (propertyName == "enableSearchFilter") {
				console.log("CS-ContentList-Preview:propertyChanged() : Property Name: " + propertyName + ", value: " + propertyValue);
				if (propertyValue === null || propertyValue === undefined || propertyValue == false) {
					this.context.coachViewData.filterBtnDiv.style.display = "none";
					this.context.coachViewData.searchIconDiv.style.display = "inline-block";
					this.context.coachViewData.searchLabelDiv.style.display = "inline-block";
				} else {
					this.context.coachViewData.filterBtnDiv.style.display = "inline-block";
					this.context.coachViewData.searchIconDiv.style.display = "none";
					this.context.coachViewData.searchLabelDiv.style.display = "none";
				}
			} else if (propertyName == "includeTimeInDates") {
				console.log("CS-ContentList-Preview:propertyChanged() : Property Name: " + propertyName + ", value: " + propertyValue);
				var dateNodes = this.context.coachViewData.dateDivs;
				var dateTimeNodes = this.context.coachViewData.dateTimeDivs;
				for (var i = 0; i < dateNodes.length; i++) {
					var dateNode = dateNodes[i];
					var dateTimeNode = dateTimeNodes[i];
					if (propertyValue === null || propertyValue === undefined || propertyValue == false) {
						dateNode.style.display = "";
						dateTimeNode.style.display = "none";
					} else {
						dateNode.style.display = "none";
						dateTimeNode.style.display = "";
					}
				}
			}
		}));
    },
	
	modelChanged: function(propertyName, propertyValue) {
		this.context.coachViewData.labelHandler.modelChanged(propertyName, propertyValue);
	}
};
