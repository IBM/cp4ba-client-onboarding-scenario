// NLS_MESSAGEFORMAT_NONE
// NLS_ENCODING=UNICODE
/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "Clasă",

		// Property list
		properties_file_name: "Nume fişier",
		properties_add_file: "Adăugare fişier",
		properties_add_mvcp: "Adăugați ${0}",
		properties_remove_mvcp: "Scoateți din ${0}",

		properties_optional_label: "${0} (opţional)",

		properties_document_or_folder_not_found: "Documentul sau folderul nu poate fi găsit. ",
		properties_class_not_found: "Clasa de conţinut nu poate fi găsită. ",
		properties_folder_duplicate_item_invalid_prop: "Un articol cu acelaşi nume există deja în folder sau aţi introdus o valoare de proprietate invalidă. ",
		properties_item_invalid_prop: "Aţi introdus o valoare invalidă pentru unsa sau mai multe proprietăţi.",

		properties_invalid_long_value: "Această valoare nu este validă. Valoarea trebuie să fie un întreg, de exemplu 5 sau 1349.",
		properties_invalid_float_value: "Valoarea nu este validă. Valoarea trebuie să fie un număr virgulă mobilă, de  exemplu 1.2 sau 365.",
		properties_min_value: "Valoarea minimă: ${0}",
		properties_max_value: "Valoarea maximă: ${0}",
		properties_max_length: "Lungime maximă: ${0}",
		properties_invalid_guid: "Valoarea nu este validă. Valoarea trebuie să fie un Identificator unic global (GUID), de exemplu, {F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}.",
		properties_value_required: "Această valoare este necesară.",
		properties_unique_value_required: "Această valoare trebuie să fie unică. ",
		properties_file_required: "Este necesar un fişier.",
		properties_invalid_folder_name: "Un nume de folder nu poate conţine niciunul din următoarele caractere: \\ / : * ? \" < > |",

		properties_move_edit_confirm_msg: "Modificaţi proprietăţile următorului document<br>${0}<br><br>Vreţi să vă salvaţi modificările?",
		properties_move_edit_confirm_no: "Nu",
		properties_move_edit_confirm_yes: "Da",
		properties_move_edit_confirm_title: "Confirmare",
		properties_edit_save_success: "Proprietăţile au fost salvate",
		properties_edit_save_failure: "Proprietăţile nu au fost salvate",

		// Content list
		contlist_column_spec_title: "Titlu",
		contlist_column_spec_name: "Nume",
		contlist_column_spec_version_label: "Versiune",
		contlist_column_spec_modified_by: "Modificat de",
		contlist_column_spec_mod_date: "Ultima modificare",
		contlist_column_spec_created_by: "Creat de",
		contlist_column_spec_creation_date: "Creat",
		contlist_column_spec_mime_type: "Tip de document",
		contlist_column_spec_size: "Dimensiune",
		contlist_column_spec_thumbnail: "Miniatură",

		contlist_paging_no_more_items: "nu mai există articole. ",
		contlist_paging_of_at_least_items: "${0} din cel puţin ${1} articole",
		contlist_paging_of_items: "${0} din ${1} articole",
		contlist_paging_items: "Articole ${0}",
		contlist_paging_items_per_page: "Articole pe pagină: ${0}",

		contlist_checked_out: "Înregistrat la ieşire",
		contlist_checked_out_by: "Înregistrat la ieşire de ${0}",

		contlist_size_units_B: "B",
		contlist_size_units_KB: "KB",
		contlist_size_units_MB: "MB",
		contlist_size_units_GB: "GB",
		contlist_size_units_TB: "TB",

		contlist_missing_server_error: "Nu a fost specificat un server. ",
		contlist_invalid_server_error: "Serverul '{0}' nu există.",
		contlist_error_retrieving_doc_props: "Eroare la extragerea proprietăţilor documentului.",
		contlist_checkout_failed: "Documentul nu poate fi înregistrat la ieşire",
		contlist_cancel_checkout_failed: "Anularea înregistrării la ieşire a eşuat",
		contlist_rename_folder_failed: "Nu s-a putut redenumi folderul. ",
		contlist_folder_name_not_unique: "Numele folderului trebuie să fie unic. ",
		contlist_delete_object_failed: "Obiectul nu a putut fi şters. ",
		contlist_display_properties_failed: "Proprietăţile nu au putut fi afişate.${0}",
		contlist_save_props_failed: "Proprietăţile nu au putut fi salvate.",
		contlist_upload_failed: "Versiunea nu a putut fi încărcată",
		contlist_add_folder_failed: "Folderul nu a putut fi adăugat.${0}",
		contlist_add_document_failed: "Documentul nu a putut fi adăugat.${0}",
		contlist_search_failed: "Rezultate de căutare nu au putut fi extrase.",
		contlist_folder_containees_failed: "conţinutul folderului nu a putut fi extras. ",
		contlist_delete_folder_referenced: "Folderul nu a putut fi şters deoarece conţine subfoldere.",

		contlist_checkout_success: "Documentul a fost înregistrat la ieşire",
		contlist_delete_success: "Obiectul a fost şters. ",
		contlist_rename_folder_success: "Folderul a fost redenumit",
		contlist_save_props_success: "Proprietăţile au fost salvate",
		contlist_cancel_checkout_success: "Anularea înregistrării la ieşire a reuşit",
		contlist_upload_version_success: "Versiunea a fost încărcată",
		contlist_add_folder_success: "Folderul a fost adăugat",
		contlist_add_doc_success: "Documentul a fost adăugat",

		contlist_menu_action_open: "Deschidere",
		contlist_menu_action_rename: "Redenumire",
		contlist_menu_action_properties: "Proprietăţi",
		contlist_menu_action_view: "Vizualizare",
		contlist_menu_action_download: "Descărcare",
		contlist_menu_action_checkout: "Înregistrare la ieşire",
		contlist_menu_action_edit_document: "Editare document",
		contlist_menu_action_cancel_checkout: "Anulare înregistrare la ieşire",
		contlist_menu_action_delete_doc: "Ştergere document",
		contlist_menu_action_rename_folder: "Redenumire folder",
		contlist_menu_action_add_folder: "Adăugare folder",
		contlist_menu_action_delete_folder: "Ştergere folder",
		contlist_menu_action_add_doc: "Adăugare document",
		contlist_menu_action_upload: "Încărcare versiune nouă",

		contlist_document_properties: "Proprietăţi document",
		contlist_folder_properties: "Proprietăţi folder",
		contlist_folder_name: "Nume folder",

		contlist_cancel_btn_label: "Anulare",
		contlist_add_btn_label: "Adăugare",
		contlist_ok_btn_label: "Ok",
		contlist_edit_btn_label: "Editare",
		contlist_save_btn_label: "Salvare",
		contlist_upload_btn_label: "Încărcare",
		contlist_refresh_btn_label: "Reîmprospătare",
		contlist_next_btn_label: "Următor",
		contlist_previous_btn_label: "Anterior",

		contlist_delete_folder_confirm: "Sunteţi pe cale să ştergeţi folderul ${0}. Doriţi să continuaţi?",
		contlist_delete_doc_confirm: "Sunteţi pe cale să ştergeţi documentul ${0}. Doriţi să continuaţi?",

		contlist_no_mimetype: "Acest articol nu are conţinut.",
		contlist_folder_mimetype: "Folder",

		contlist_filter_search_hint: "Căutare documente",
		contlist_filter_folder_hint: "Filtrare listă de rezultate afişate",

		contlist_root_folder: "Folder rădăcină",

		contentviewer_test_mode: "Vizualizatorul nu va afişa documente în modul de testare. Trebuie să rulaţi într-o aplicaţie desktop IBM Navigator.",

		/*do not remove this line*/nop: null
});
