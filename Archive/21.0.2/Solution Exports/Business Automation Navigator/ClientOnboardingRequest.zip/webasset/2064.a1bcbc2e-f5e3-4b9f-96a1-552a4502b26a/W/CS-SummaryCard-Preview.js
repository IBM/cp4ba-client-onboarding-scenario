/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2020. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

var mixObject = {
	createPreview: function(containingDiv, labelText, callback){
		var bpmextUri = this.context.getManagedAssetUrl("BPMExt-Core-Designer.js", this.context.assetType_WEB, "SYSBPMUI");
		require([ "dojo/dom-construct", "dojo/dom-class", "dojo/dom-attr", bpmextUri], this.lang.hitch(this, function(domConstruct, domClass, domAttr, bpmext) {
			bpmext.uidesign.css.ensureSparkUIClass(containingDiv);
			bpmext.uidesign.css.ensureGlyphsLoaded(this);
			
			this.context.coachViewData.containingDiv = containingDiv;
			
			var tempID;
			while(true) {
				tempID = dojox.uuid.generateRandomUuid();
				if (this.context.coachViewData.containingDiv.querySelector("div[data-temp-id='" + tempID + "']") == null) {
					break;
				}
			}
			
			this.context.coachViewData.containingDiv.setAttribute("data-temp-id", encodeURIComponent(tempID));
			domClass.add(this.context.coachViewData.containingDiv, "WYSIWYGSummaryCard");
			
			this.context.coachViewData.label = this.context.coachViewData.containingDiv.querySelector("div[data-temp-id='" + tempID + "']  .summarycard-title");
			this.context.coachViewData.labelTextDom = document.createTextNode(labelText);
			this.context.coachViewData.label.appendChild(this.context.coachViewData.labelTextDom);
			
			this.context.coachViewData.icon = this.context.coachViewData.containingDiv.querySelector("div[data-temp-id='" + tempID + "']  .summarycard-heading-icon .fa");
			this.context.coachViewData.iconClass = "fa";
			
			//Added for WYSIWYG for default width & height
			this.context.coachViewData.defaultWidth = "350px";
			
			this.context.coachViewData.summaryCard = this.context.coachViewData.containingDiv.querySelector("div[data-temp-id='" + tempID + "'] .SPARKPanel.panel .summarycard");
			this.context.coachViewData.summaryCardHeading = this.context.coachViewData.containingDiv.querySelector("div[data-temp-id='" + tempID + "'] .SPARKPanel.panel .summarycard-heading");
			this.context.coachViewData.summaryTitle = this.context.coachViewData.containingDiv.querySelector("div[data-temp-id='" + tempID + "'] .SPARKPanel.panel .summarycard_title");
			this.context.coachViewData.summaryDetails = this.context.coachViewData.containingDiv.querySelector("div[data-temp-id='" + tempID + "'] .SPARKPanel.panel .summarycard_details");
			this.context.coachViewData.displayHelpIcon = this.context.coachViewData.containingDiv.querySelector("div[data-temp-id='" + tempID + "'] .SPARKPanel.panel .CS_SummaryCardHelpIcon");
			
			this.context.coachViewData.labelHandler = bpmext.uidesign.createLabelHandler(this.context.coachViewData.labelTextDom, undefined/*we handle label vis*/, this.context.coachViewData.containingDiv, false, true);
			
			callback();
		}));
	},
	
	getLabelDomElement: function() {
		return this.context.coachViewData.label;
	},
	
	propertyChanged: function(propertyName, propertyValue){
		var configHelperUri = this.context.getManagedAssetUrl("BPMExt-Core-ConfigHelper.js",this.context.assetType_WEB, "SYSBPMUI");
		require(["dojo/dom-style", "dojo/dom-class",  "dojo/dom-construct", configHelperUri], this.lang.hitch(this, function(domStyle, domClass, domConstruct, configHelper){
			this.context.coachViewData.labelHandler.propertyChanged(propertyName, propertyValue);
			
			console.log("CS-SummaryCard-Preview:propertyChanged() : Property Name: " + propertyName + ", value: " + propertyValue);

			if (propertyName == "@style") {
				console.log("CS-SummaryCard-Preview:propertyChanged() : style: " + JSON.stringify(propertyValue));
				if (propertyValue.height != null){
					// Add some space to allow for the heading.
					var height = parseInt(propertyValue.height) || 0;
					height = height > 85 ? height : 85;
					var newContainigDivHeight = height + 40 + "px";
					var newHeight = height + 36 + "px";
					console.log("CS-SummaryCard-Preview:propertyChanged() : newHeight: " + newHeight);
					this.context.coachViewData.containingDiv.style.height = newContainigDivHeight;
					this.context.coachViewData.summaryCard.style.height = newHeight;
				}
			}
			else if (propertyName == "@labelVisibility"){
				console.log("CS-SummaryCard-Preview:propertyChanged() : labelVisbility: " + JSON.stringify(propertyValue));
				if (propertyValue == "HIDE"){
					this.context.coachViewData.summaryCardHeading.style.display = "none";
				}
				else {
					this.context.coachViewData.summaryCardHeading.style.display = "";;
				}
			}
			else if (propertyName == "summaryTitle") {
				this.context.coachViewData.summaryTitle.innerText = propertyValue;
			}
			else if (propertyName == "summaryDetails"){
				this.context.coachViewData.summaryDetails.innerText = propertyValue;
			}
			else if (propertyName == "displayHelpIcon"){
				var style = propertyValue ? "inline-block" : "none";
				this.context.coachViewData.displayHelpIcon.style.display = style;
			}
		}));
    },
	
	modelChanged: function(propertyName, propertyValue) {
		this.context.coachViewData.labelHandler.modelChanged(propertyName, propertyValue);
	}
};
