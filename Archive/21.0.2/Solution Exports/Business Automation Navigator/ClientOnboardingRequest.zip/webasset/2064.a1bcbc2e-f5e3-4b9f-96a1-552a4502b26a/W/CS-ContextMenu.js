/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

class cs_ContextMenu {
	
	static removeContextMenu(view, domClass) {
		if (view._instance.menu != null) {
			// Get the context menu open button div and change the style 
			var ctxMenuButtonDiv = view._instance.ctxMenuButtonDiv;
			if (ctxMenuButtonDiv != null) {
				domClass.remove(ctxMenuButtonDiv, "bx--overflow-menu-hold");
			}

			var wrapper = view._instance.menu.wrapper;
			var chartMenu = view._instance.menu.chartMenu;
			var chartMenuInner = view._instance.menu.chartMenuInner;
			var menuTable = view._instance.menu.menuTable;

			if (chartMenuInner.contains(menuTable)) {
				chartMenuInner.removeChild(menuTable);
			}
			menuTable = null;
			if (chartMenu && chartMenuInner) {
				chartMenu.removeChild(chartMenuInner);
			}
			chartMenuInner = null;
			if (wrapper.contains(chartMenu)) {
				wrapper.removeChild(chartMenu);
			}
			chartMenu = null;
			if (wrapper) {
				if (view.context.element.contains(wrapper)) {
					view.context.element.removeChild(wrapper);
				}
				wrapper = null;
			}
			view._instance.menu = null;
		}
	}
	
	static createWrapper(view, domClass, domAttr) {
		var wrapper = view._instance.menu.wrapper = document.createElement("div");
		domClass.add(wrapper, "menu contextmenu");
		domAttr.set(wrapper, "data-overflow-menu", "");
		domAttr.set(wrapper, "role", "region");
		return wrapper;
	}
	
	static createChartMenu(view, domClass) {
		var chartMenu = view._instance.menu.chartMenu = document.createElement("div");
		domClass.add(chartMenu, "menu-inner bottom");
		return chartMenu;
	}
	
	static createChartMenuInner(view, chartMenu, domClass, domAttr) {
		var chartMenuInner = view._instance.menu.chartMenuInner = document.createElement("div");
		domAttr.set(chartMenuInner, "tabindex", -1);
		domClass.add(chartMenuInner, "chart-menu dropdown-menu DropDownMenu"); 
		chartMenu.appendChild(chartMenuInner);
		return chartMenuInner
	}
	
	static createMenuTable(view, domClass, domAttr) {
		var menuTable = view._instance.menu.menuTable = document.createElement("table");
		domClass.add(menuTable, "inner ContextMenu"); 
		domAttr.set(menuTable, "role", "menu");
		return menuTable;
	}
		
	static determineContextMenuPopupVisibility(view, cell, domClass) {
		if (view._instance.menu && view._instance.menu && view._instance.menu.chartMenu) {
			var isVisible = domClass.contains(view._instance.menu.chartMenu, "open");
			return isVisible;
		}
		return false;
	}

	static showHideContextMenuButton(target, display, domClass) {
		var parNode = target;
		if (parNode.nodeName == "IMG") {
			parNode = target.parentNode
		}
		
		if (display) {
			domClass.add(parNode, "bx--overflow-menu-hold");
		} else {
			domClass.remove(parNode, "bx--overflow-menu-hold");
		}
	}
			
	static positionContextMenu(view, event, chartMenu, chartDiv) {
		var target = event.target || event.srcElement;
		var rect = target.getBoundingClientRect();

		// Create the "fudge" factors for the context menu open button (depends on event target object)
		var rightFudge = 0;
		var topFudge = -2;
		if (target.nodeName == "IMG") {
			rightFudge = 6;
			topFudge = 6;
		}
		
		var xOffset = window.pageXOffset;
		var yOffset = window.pageYOffset;

		// This is initial guess of top/left of drop down menu location
		var left = rect.left;
		var top = rect.bottom + topFudge;
//				var right = left + chartMenu.scrollWidth;
		var right = rect.right + rightFudge;
		var bottom = top + chartMenu.scrollHeight;

		if (right > chartDiv.offsetWidth) {
			if (view._instance.isFirefox) {
				xOffset -= right - chartDiv.offsetWidth + 1;
			} else {
				xOffset -= right - chartDiv.offsetWidth - 1;
			}
		}

		if (bottom > chartDiv.offsetHeight) {
			yOffset -= bottom - chartDiv.offsetHeight;
			// negative offset is up and will cover ellipses button, move left a little bit
			if (view._instance.isChrome) {
				xOffset -= 18;  // Not sure why Chrome is soo far off in this regard
			} else {
				xOffset -= 32;
			}
		}
//				console.log("_positionContextMenu(): bottom: " + bottom + " chartDiv.offsetHeight: " + chartDiv.offsetHeight + " yOffset: " + yOffset);

		var menuTop = Math.max(0, top + yOffset);
		var menuLeft = Math.max(0, right + xOffset - chartMenu.scrollWidth); // below and aligned with right side

		chartMenu.style.top = menuTop + "px";
		chartMenu.style.left = menuLeft + "px";
		chartMenu.style.position = "absolute";
	}
	
	static addMenuAction(view, actions, actionId, icon, text, badgeText, onclickFn, isEnabled) {
		var action = {	
			actionId: actionId,
			icon: icon,
			text: text,
			badgeText: badgeText,
			isEnabled: isEnabled
		};
		
		if (isEnabled) {
			action.onclick = CSContextMenu.createClickFunction(onclickFn);
		}
		actions.push(action);
	}

	static createClickFunction(callback) {
		return function(evt) {
			if (evt.type == "keydown") {
				var keyID = (evt.charCode) ? evt.charCode : ((evt.which) ? evt.which : evt.keyCode);
				if (keyID == 13 || keyID == 32) {
					evt.preventDefault();
					callback();
				}
			} else {
				callback();
			}
		};
	}

	static populateMenuCategory(view, actions, table, domClass, domAttr) {
		var firstTr;
		// Add the actions to a html table for rendering the context menu
		for (var i = 0; i < actions.length; i++) {
			var action = actions[i];
			
			if (action.actionId == "__separator") {
				var tr = document.createElement("tr");
				tr.tabIndex = -1;
				domClass.add(tr, "mnTrSeparator");
				table.appendChild(tr);

				var td = document.createElement("td");
				domClass.add(td, "mnSeparator");
				tr.appendChild(td);
			} else {
				var tr = document.createElement("tr");
				tr.tabIndex = 0;
				domAttr.set(tr, "role", "menuitem");
				domAttr.set(tr, "aria-label", action.text);
				table.appendChild(tr);
				
				var td = document.createElement("td");
				domAttr.set(td, "role", "presentation");
				tr.appendChild(td);

				if (action.isEnabled) {
					domClass.add(tr, "mnTextItem ContextMenuRow");
				} else {
					domClass.add(tr, "mnTextItem RowDisabled");
					domAttr.set(tr, "aria-disabled", "true");
				}
				// Add "marker" css class to indicate that this is the last action item in the menu
				if (i == actions.length - 1) {
					domClass.add(tr, "LastMenuItem");
				} else if (i == 0) {
					domClass.add(tr, "FirstMenuItem");
				}
				
				domClass.add(td, "mnLabel");

				var a = document.createElement("a");
				a.tabIndex = -1;
				domClass.add(a, "mnItem");

				a.href = "javascript:void(0)";
				if (action.actionId !== null && action.actionId.length > 0) {
					domAttr.set(a, "data-action-id", action.actionId);
				}
				
				if (action.icon != null && action.icon.length > 0) {
					var icon = document.createElement("i");
					var ic = bpmext.text.startsWith(action.icon, "fa-") ? action.icon : "fa-" + action.icon;

					domClass.add(icon, "dropdown-icon fa " + ic);
					a.appendChild(icon);
				}

				var txt = document.createTextNode(action.text);
				a.appendChild(txt);
				td.appendChild(a);

				if (action.isEnabled) {
					if (action.onclick) {
						tr.onclick = action.onclick;
						tr.onkeydown = action.onclick;
					} else {
						CSContextMenu.setMenuClickAction(view, tr, action);
					}
				}
			}
			
			table.appendChild(tr);
			
			if (i == 0) {
				firstTr = tr;
			}
		}
		return firstTr;
	}
	
	static setMenuClickAction(view, element, actionItem) {
		element.onclick = function (evt) {
			if (actionItem.onclick) {
				actionItem.onclick.call(view, actionItem);
			}
		}
	}

	static isCurrentUserCheckout(view, contentItem) {
		var isCurrentUser = false;
		// Need to check to see if current logged in user is the one who has the document checked out
		if (contentItem.reservation && contentItem.reservation.creator) {
			var reservationUser = contentItem.reservation.creator;
			// NOTE: The following call only works if running in ICN in platform mode
			var currentUser = CSContextMenu.getUserId(view);
			if (currentUser != null && reservationUser == currentUser) {
				isCurrentUser = true;
			}
		}
		return isCurrentUser;
	}

	static getUserId(view) {
		var userId = view._instance.userId;
		if (userId == null) {
			// Todo: Currently, no way of getting logged in user information from UMS, temporary work around
			var navUrl = window.location.href;
			var params = navUrl.split("&");
			for (var i = 0; i < params.length; i++) {
				var param = params[i].split("=");
				if (param[0] == "userId") {
					userId = decodeURIComponent(param[1]);
					view._instance.userId = userId;
					break;
				}
			}
		}
		return userId;
	}


}

window.CSContextMenu = cs_ContextMenu;