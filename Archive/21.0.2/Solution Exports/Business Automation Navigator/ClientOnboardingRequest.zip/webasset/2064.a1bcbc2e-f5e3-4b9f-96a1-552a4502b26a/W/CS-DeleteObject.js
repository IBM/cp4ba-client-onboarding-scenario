/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

cs_InitDeleteObject = function (utilities, bpmext, domClass, domStyle, domAttr, messages, string)
{
	this._instance = {
		serverConfigurationName: "GRAPHQL_APP_RESOURCE",
		objectStoreName: null,
		actionName: null,
		contentItem: null,
		callback: null,
		errback: null
	};

	if (!this.constructor.prototype._proto)	{
		
		this.constructor.prototype._proto =	{
			EVT_ONDELETEOBJECT: "eventON_DELETEOBJECT",
			EVT_ONCANCEL: "eventON_CANCEL",
			EVT_ONERROR: "eventON_ERROR",

			typeDocument: "Document",
			typeFolder: "Folder",
			typeAbstract: "Abstract",
			
			privilegeToBitmask: {
				"privEditProperties": 0x2,
				"privAddToFolder": 0x10,
				"privViewDoc": 0x80,
				"privDelete": 0x10000,
				"privMajorVersion": 0x4,
				"privMinorVersion": 0x40,
				"privAddItem": 0x100,
			},	

			actions: {
				deleteDocument: "DeleteDocument",
				deleteFolder: "DeleteFolder",
				deleteAbstract: "DeleteAbstract"
			},

			_handleVisibility: function (view) {
				var vis = utilities.handleVisibility(view.context);
			},
			
			_setVisibilityOfControl: function (control, vis) {
				control.context.options["_metadata"].visibility.set("value", vis);
				control.context.setDisplay(vis != "NONE");
				control.context.setVisibility(vis != "HIDDEN");
			},
			
			_setAlertMessage: function(view, message, isError, delay) {
				var title = messages.contlist_progress_success;
				var style = "S";
				if (isError) {
					title = messages.contlist_progress_alert;
					style = "D";
				}
				// Call out to the CS_Alert utility class to handle displaying the alert message
				setAlertMessage(title, message, style, delay, domClass, domStyle, domAttr, messages);
			},
			
			_setModalAlertMessage: function(view, modalAlert, modalAlertId, message, isError, delay) {
				var title = messages.contlist_progress_success;
				var style = "S";
				if (isError) {
					title = messages.contlist_progress_alert;
					style = "D";
				}
				// Call out to the CS_Alert utility class to handle displaying the alert message
				var alertDiv = setAlertMessage(title, message, style, delay, domClass, domStyle, domAttr, messages);
				
				setTimeout(function(){
					alertDiv.scrollIntoView(true);
				}, 300);	
			},
	
			_getType: function(contentItem) {
				var type;
				if (contentItem.baseType) {
					type = contentItem.baseType;
				} else if (contentItem.isFolder) {
					type = this.typeFolder;
				} else {
					type = this.typeDocument;
				}
				return type;
			},
	
			/**
			 * Helper function to retrieve the Object Store Name as defined in ACCE admin tool. This is the 
			 * string that will be passed to all the graphql action services since it's working against CE
			 * and not ICN).
			 */
			_getObjectStoreName: function(view) {
				var objectStoreName = view.context.options.objectStoreName.get("value");
				if (view._instance.objectStoreName) {
					objectStoreName = view._instance.objectStoreName;
				}
				return objectStoreName;
			},

			_callService: function(service, params, setInputData) {
				// Create Csrf token as a large random number
				var csrfToken = Math.floor(Math.random() * 10000000);
				console.log("CS-DeleteObject:_callService() : " + service.context.viewid + ", Csrf token: " + csrfToken);

				// Add the required token value to the service params
				params.csrfToken = csrfToken;
				if (setInputData) {
					service.setInputData(params);
					service.execute();
				} else {
					service.execute(params);
				}
			},

			_onDeleteObject: function(view, contentItem, batchItem, callback, errback) {
				view._instance.deleteObjectOutputText = view.ui.get("DeleteObjectOutputText");
				view._instance.callback = callback; 
				view._instance.errback = errback; 
				view._instance.contentItem = contentItem;
				view._instance.batchItem = batchItem;
				
				if (this._getType(contentItem) == this.typeFolder) {
					view._instance.deleteObjectOutputText.setText(string.substitute(messages.contlist_delete_folder_confirm, [contentItem.name]));
					this._showHideDeleteObjectModal(view, true, this.actions.deleteFolder);
				} else if (this._getType(contentItem) == this.typeAbstract) {
					var displayName = contentItem.name;
					if (contentItem.className  == "DbaClassificationBatch") {
						var properties = contentItem.properties.items ? contentItem.properties.items : contentItem.properties;
						for (var i = 0; i < properties.length; i ++) {
							if (properties[i].id == "DbaDisplayName") {
								displayName = properties[i].value;
								break;
							}
						}
					}
					view._instance.deleteObjectOutputText.setText(string.substitute(messages.contlist_delete_confirm, [displayName]));
					this._showHideDeleteObjectModal(view, true, this.actions.deleteAbstract);
				} else {
					view._instance.deleteObjectOutputText.setText(string.substitute(messages.contlist_delete_doc_confirm, [contentItem.name]));
					this._showHideDeleteObjectModal(view, true, this.actions.deleteDocument);
				}								
			},
			
			_showHideDeleteObjectModal: function(view, isVisible, actionName) {
				console.log("CS-DeleteObject:_showHideDeleteObjectModal() : Show delete object modal, isVisible: " + isVisible);

				view._instance.deleteObjectModal = view.ui.get("DeleteObjectModal");
				view._instance.deleteObjectPanel = view.ui.get("DeleteObjectPanel");
				view._instance.deleteObjectBtn = view.ui.get("DeleteObjectOkButton");
				view._instance.actionName = actionName;
				
				if (isVisible == true) {
					view._instance.deleteObjectBtn.setVisible(true);
					view._instance.deleteObjectBtn.setEnabled(true);
					
					var label = '';
					if (actionName == this.actions.deleteDocument) {
						label = messages.contlist_menu_action_delete_doc;
					} else if (actionName == this.actions.deleteFolder) {
						label = messages.contlist_menu_action_delete_folder;
					} else {
						label = messages.contlist_menu_action_delete;
					}
					view._instance.deleteObjectPanel.context.options._metadata.label.set('value', label);
				}

				view._instance.deleteObjectModal.setVisible(isVisible);
			},
			
			_onDeleteObjectBtnClicked: function(view) {
				view._instance.deleteObjectBtn.setEnabled(false);
				if (view._instance.actionName == this.actions.deleteDocument || view._instance.actionName == this.actions.deleteFolder  || view._instance.actionName == this.actions.deleteAbstract) {
					console.log("CS-DeleteObject:_onDeleteObjectBtnClicked() : Perform delete object.");
					
					var contentItem = view._instance.contentItem;
					
					if (view._instance.batchItem) {
						var currentBatch = view._instance.batchItem;
						var params = {
							documentId: contentItem.id,
							versionSeriesId: contentItem.versionSeriesId,
							batchId: currentBatch.id,
							repository: this._getObjectStoreName(view),
							serverAppResource: view._instance.serverConfigurationName
						};
					
						view._instance.deleteBatchDocumentSvc = view.ui.get("DeleteBatchDocumentSvc");
						this._callService(view._instance.deleteBatchDocumentSvc, params);
						
					} else {
						var objectType = this.typeDocument;
						if (view._instance.actionName == this.actions.deleteFolder) {
							objectType = this.typeFolder;
						} else if (view._instance.actionName == this.actions.deleteAbstract) {
							objectType = this.typeAbstract;
						}
					
						var objectId = contentItem.id;
						if (this._getType(contentItem) == this.typeDocument) {
							objectId = contentItem.versionSeriesId;;
						} 

						var params = {
							objectId: objectId,
							objectType: objectType,
							classId: contentItem.className,
							repository: this._getObjectStoreName(view),
							serverAppResource: view._instance.serverConfigurationName
						};
					
						view._instance.deleteObjectSvc = view.ui.get("DeleteObjectSvc");
						this._callService(view._instance.deleteObjectSvc, params);
					}
				} else {
					console.log("CS-DeleteObject:_onDeleteObjectBtnClicked() : Unknown action on Delete Object Popup ");
				}
			},

			_onCancelBtnClicked: function(view) {
				console.log("CS-DeleteObject:_onCancelBtnClicked()");
				view._instance.deleteObjectModal = view.ui.get("DeleteObjectModal");
				view._instance.deleteObjectModal.setVisible(false);

				bpmext.ui.executeEventHandlingFunction(view, this.EVT_ONCANCEL);
			},
			
			_onDeleteObjectResult: function(view) {
				try	{
					this._setAlertMessage(view, messages.contlist_delete_success, false);
					this._showHideDeleteObjectModal(view, false, '');

					var contentItem = view._instance.contentItem;
					var callback = view._instance.callback;
					if (callback) {
						callback(contentItem);
					}
					bpmext.ui.executeEventHandlingFunction(view, this.EVT_ONDELETEOBJECT, contentItem);

				} catch(e) {
					bpmext.log.error("Error on AJAX service invocation [" + view.context.viewid + "]: " + e);
					if (e.stack) {
						bpmext.log.error("  Call stack: " + e.stack);
					}
				}
			}		
			
		};

		/*
		 * Private methods and event handlers *************************************************************
		 */
		 
		this.constructor.prototype._canEditProperties = function(contentItem) {
			if (contentItem && contentItem.accessAllowed) {
				var canEditProperties = (contentItem.accessAllowed & this._proto.privilegeToBitmask["privEditProperties"]) > 0;
				return canEditProperties;
			} else {
				return false;
			}
		};

		this.constructor.prototype._onDeleteObjectResult = function() {
			try {
				this._proto._onDeleteObjectResult(this);
			} catch (e) {
				bpmext.log.error("Error on AJAX service invocation [" + this.context.viewid + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};

		this.constructor.prototype._onDeleteObjectError = function() {
			var view = this;
			var error = view._instance.deleteObjectSvc && view._instance.deleteObjectSvc.getLastError();
			if (error) {
				error.actionName = this._instance.actionName;
				var message;
				if (error.errorCode == "FNRJG1005" && error.actionName == this._proto.actions.deleteFolder) {
					message = messages.contlist_delete_folder_referenced;
				} else {
					message = messages.contlist_delete_object_failed;
				}				

				this._proto._showHideDeleteObjectModal(view, false, '');					
				this._proto._setAlertMessage(view, message, true);

				view._instance.error = error;

				setTimeout(function() {
					bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, view._instance.error);
				});
			}
		};
		
		this.constructor.prototype._onDeleteBatchDocumentError = function() {
			var view = this;
			var error = view._instance.deleteBatchDocumentSvc && view._instance.deleteBatchDocumentSvc.getLastError();
			if (error) {
				error.actionName = this._instance.actionName;
				var message = messages.contlist_delete_document_failed;
				if (this._instance.actionName == this._proto.actions.deleteFolder) {
					message = messages.contlist_delete_folder_failed;
				} else if (this._instance.actionName == this._proto.actions.deleteAbstract) {
					message = messages.contlist_delete_object_failed;
				}
				this._proto._showHideDeleteObjectModal(view, false, '');					
				this._proto._setAlertMessage(view, message, true);

				view._instance.error = error;

				setTimeout(function() {
					bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, view._instance.error);
				});
			}
		};

		/*
		 * Public control methods *************************************************************
		 */

		/**
		 * @instance
		 * @memberof CSDeleteObject
		 * @method deleteObject
		 * @param contentItem CSContentItem object holding the document information for the item you would like to delete
		 * @param batchItem CSContentItem object hoding the batch information you would like to delete the document from (optional)
		 * @desc Delete the specified object from the repository
		 * @returns 
		 */
		this.constructor.prototype.deleteObject = function(contentItem, batchItem, callback, errback) {

			this._proto._onDeleteObject(this, contentItem, batchItem, callback, errback);
			
		};

		/*
		 * Coach NG Lifecycle methods *************************************************************
		 */
		 
		this.constructor.prototype.load = function() {
			console.log("CS-DeleteObject:load() : called from: " + this.context.viewid);
			try	{
				var opts = this.context.options;
				var mdt = opts._metadata;

				if (!opts.objectStoreName) {
                    opts.objectStoreName = bpmext.ui.substituteConfigOption(this, "objectStoreName", null);
				}

				domClass.add(this.context.element, "CS_DeleteObject");
				
  				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONDELETEOBJECT, "contentItem");
				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONCANCEL);
				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONERROR, "message");

				bpmext.ui.loadView(this);			
				
			} catch (e) {
				bpmext.log.error("Error on load event [" + this.context.viewid + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};

		this.constructor.prototype.view = function () {
			console.log("CS-DeleteObject:view() : called from: " + this.context.viewid);
            try {
//				this._proto._handleVisibility(this);
 			} catch (e) {
                bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                if (e.stack) {
                    bpmext.log.error("  Call stack: " + e.stack);
				}
            }
        };

		this.constructor.prototype.change = function(event)	{
			console.log("CS-DeleteObject:change() : called from: " + this.context.viewid);
			try	{
				var view = this;
				if (event.type == "config")	{
					// NA
				} else {
					if (this.context.binding && event.newVal && event.newVal.id) {
						var boundObject = this.context.binding.boundObject;
						if (boundObject != null) {
														
						}
					}
				}
			} catch (e) {
				bpmext.log.error("Error on change event [" + this.ui.getAbsoluteName() + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};
	}
}	
