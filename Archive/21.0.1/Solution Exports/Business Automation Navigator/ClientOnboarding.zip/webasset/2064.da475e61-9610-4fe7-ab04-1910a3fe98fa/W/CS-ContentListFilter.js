/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2020. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */
 
cs_InitContentListFilter = function(utilities, bpmext, domClass, domAttr, domStyle, messages, string, cookie) {
	
	this._instance = {
		serverConfigurationName: "GRAPHQL_APP_RESOURCE",
		blockRefreshOnChange: false,
		inUpdateDocument: false
	};

	const Actions = {
		DISPLAY_FILTER: 'displayFilter'
	};
	
	this._serverConfigurationName = "GRAPHQL_APP_RESOURCE";
	this._action = "";
	this._metadataCache = {};
	this._classId = "";
	this._propertyObjects = [];
	this._objectType = "";
	this._readOnly = false;
	this._valueOnly = false;
	this._refreshAfterUpdate = null;
	this._callback = null;
	this._errbacks = null;
	this._stackLayout = null;
	this._noItemSelectedDiv = null;
	this._serviceLayout = null;
	this._propertyUpdated = false;
	this._privEditProperties = 0x2;
	
	if (!this.constructor.prototype._proto)
	{
		this.constructor.prototype._proto =
		{					
			EVT_ONERROR: "eventON_ERROR",
			EVT_ONFILTER: "eventON_FILTER",
			EVT_ONCANCELFILTER: "eventON_CANCELFILTER",

			/**
			 * Helper function to retrieve the Object Store Name as defined in ACCE admin tool.
			 */
			_getObjectStoreName: function(view) {
				var objectStoreName = view.context.options.objectStoreName.get("value");
				return objectStoreName;
			},

			_handleVisibility: function (view) {
				var vis = utilities.handleVisibility(view.context);
			},

			_callService: function(service, params) {
				// Create ecm token as a large random number
				var ecmToken = Math.floor(Math.random() * 10000000);
				console.log("CS-ContentListFilter:_callService() : Ecm token: " + ecmToken);

				// Add the required token value to the service params
				params.ecmToken = ecmToken;
				service.execute(params);
			},
		
			_mergeSearchProperties: function(classDescription, propertyObjects, newObject, valueOnly) {
				var propertyValues = {};
				
				var updatedPropertyObjects = [];
				var propertyDescriptions = classDescription.propertyDescriptions.items ? classDescription.propertyDescriptions.items : classDescription.propertyDescriptions;
	
				// Create a map of property descriptions so we can reference them easily later
				propertyDescriptions.forEach(function(propertyDescription){
					propertyValues[propertyDescription.symbolicName] = propertyDescription;
				});
	
				for (var i = 0; i < propertyObjects.length; i++){
					var propertyObject = propertyObjects[i];
					
					if (propertyObject.dataType == "BINARY" || propertyObject.dataType == "OBJECT" || propertyObject.isHidden) {
						continue;
					}
					
					// Do not display any property filters that are marked hidden
					if (propertyObject.hide) {
						continue;
					}
					
					// Todo: should we filter out MVP properties initially? No requirement for them 
					
					var propertyDescription = propertyValues[propertyObject.name];
					
					var value = propertyObject.defaultValue;
					if (propertyDescription.dataType == "DATE") {
						// 2020-07-28T07:00:00.000Z
						if (value != null && value != "") {
							var dateValue = new Date(value);
							value = dateValue.toISOString();
						}
					}
					
					var updatedPropertyObject = {
						id: propertyDescription.symbolicName,
						type: propertyDescription.dataType,
						cardinality: propertyDescription.cardinality,
						label: propertyObject.displayName,
						readOnly: false,
						required: false,
						choices: propertyDescription.choiceList,
						hierChoices: false,
						isSystemOwned: propertyDescription.isSystemOwned,
						requiresUniqueElements: propertyDescription.requiresUniqueElements,
						maxLength: propertyDescription.maximumLengthString ? propertyDescription.maximumLengthString : null,
						minValue: propertyDescription.propertyMinimumInteger32 || propertyDescription.propertyMinimumFloat64 || propertyDescription.propertyMinimumDateTime,
						maxValue: propertyDescription.propertyMaximumInteger32 || propertyDescription.propertyMaximumFloat64 || propertyDescription.propertyMaximumDateTime,
						singleCardinalityValue: propertyDescription.cardinality == "SINGLE" ? value : null,
						listCardinalityValues: propertyDescription.cardinality == "LIST" ? propertyObject.defaultValue : []
					}
					
					var listCardinalityValues = updatedPropertyObject.listCardinalityValues.items ? updatedPropertyObject.listCardinalityValues.items : updatedPropertyObject.listCardinalityValues;
					
					// Exclude hierarchical choice lists for now.
					if (updatedPropertyObject.choices && updatedPropertyObject.choices.choiceValues) {
						var choiceValues = updatedPropertyObject.choices.choiceValues.items ? updatedPropertyObject.choices.choiceValues.items : updatedPropertyObject.choices.choiceValues;
						for (var j = 0; j < choiceValues.length; j++) {
							var choice = choiceValues[j];
							if (choice.choiceValues){
								var subChoices = choice.choiceValues.items ? choice.choiceValues.items : choice.choiceValues;
								if (subChoices && subChoices.length > 0) {
									updatedPropertyObject.choices = null;
									updatedPropertyObject.hierChoices = true;
									break;
								}
							}
						}
					}
					
					if (newObject) {
						if (propertyDescription.cardinality == "SINGLE" && !updatedPropertyObject.singleCardinalityValue) {
							updatedPropertyObject.singleCardinalityValue = propertyDescription.propertyDefaultId ||
								propertyDescription.propertyDefaultString || propertyDescription.propertyDefaultBoolean || propertyDescription.propertyDefaultInteger32 || propertyDescription.propertyDefaultDateTime || propertyDescription.propertyDefaultFloat64 || null;
						}
					}
					
					// Work around a date binding issue for MVCPs
					if (updatedPropertyObject.cardinality == "LIST" && updatedPropertyObject.type == "DATE") {
						dateListValues = updatedPropertyObject.listCardinalityValues.items ? updatedPropertyObject.listCardinalityValues.items : updatedPropertyObject.listCardinalityValues;
						updatedPropertyObject.listCardinalityValues = dateListValues.map(function(dateStringValue) {
							return new Date(dateStringValue);
						})
					}
					
					updatedPropertyObjects.push(updatedPropertyObject);
				}
				return updatedPropertyObjects
			},
		
			_clearServiceError: function(view, serviceName) {
				var service = view.ui.get(serviceName);
				var busyIndicator = service.context.options.busyIndicator.get("value");
				service.context.options.busyIndicator.set("value", "");
				service.context.options.busyIndicator.set("value", busyIndicator);
			},
			
			_displayNoItemSelected: function(view, show) {
				var displayMessage = "";
				var displayToolbar = "";
				if (show) {
					displayToolbar = "none";
				} else {
					displayMessage = "none";
				}
				domStyle.set(view._noItemSelectedDiv, "display", displayMessage);
			},
			
			_getPropertyValue: function(property, addComma) {
				// No property does not have a stack container, is hidden
				var propertyValue = "";
				if (property.hide) {
					var defaultValue = property.defaultValue;
					if (defaultValue) {
						if (addComma) {
							propertyValue += ", ";
						}
						propertyValue += "{\"" + property.name + "\": ";
						if (property.dataType == "string" || property.dataType == "guid"){
							if (defaultValue == null || defaultValue == "") {
								propertyValue += null;
							} else {
								var sanitizedValue = defaultValue.replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/\t/g,'\\t').replace(/"/g,'\\"').replace(/\r/g,'\\r');
								propertyValue += "\"" + sanitizedValue + "\"";
							}
						} else if (property.dataType == "date") {
							if (defaultValue == null || defaultValue == "") {
								propertyValue += null;
							} else {
								var dateValue = new Date(defaultValue);
								propertyValue += "\"" + dateValue.toISOString() + "\"";
							}
						} else if (property.dataType == "boolean") {
							if (defaultValue == null || defaultValue == "") {
								propertyValue += null;
							} else {
								propertyValue += defaultValue;
							}
						} else if (property.dataType == "integer" || property.dataType == "decimal") {
							if (defaultValue == null || defaultValue == "") {
								propertyValue += null;
							} else {
								// Turn them into strings, they would be anyway later on
								propertyValue += "\"" + defaultValue + "\"";
							}
						}
						propertyValue += "}";
					}
				}
				return propertyValue;
			}

		};
		
		/**
		 *	Sets a value indicating properties in the view should be read-only, not available for editing.
		 */
		this.constructor.prototype.setReadOnly = function(readOnly) {
			this._readOnly = readOnly;
			readOnly ? domClass.add(this.context.element, "CS_DisplayProperties") : domClass.remove(this.context.element, "CS_DisplayProperties");
		};
		
		this.constructor.prototype.getReadOnly = function() {
			return this._readOnly;
		};
		
		this.constructor.prototype._setProperties = function() {
			this._stackLayout._readOnly = this._readOnly;
			this._stackLayout._displayNew = true;
			this._stackLayout._indexOffset = 0;
			this._stackLayout.setViewData(this._propertyObjects, true);
		};
		
		/**
		 * 	Clears the contents of the list.
		 */
		this.constructor.prototype.clear = function() {
			this._propertyObjects = [];
			this._setProperties();
		};
		
		/**
		 *	Displays the query properties specified by config options.
		 *	@param classId: The symbolicName of the class of the document or folder.
		 *	@param objectType: "Document" or "Folder".
		 *	@param callback: Function called after properties are retrieved from server.
		 *	@param errback: Function called when an error occurs.
		 */
		this.constructor.prototype.displayProperties = function(classId, objectType, callback, errback) {
			console.log("CS-ContentListFilter:displayProperties() : called with class: " + classId);
			this._storeCallbackErrback(callback, errback);
			this._classId = classId;
			this._objectType = objectType;

			this._action = Actions.DISPLAY_FILTER;
			var contentClass = this._metadataCache[classId];
			this._propertyUpdated = false;
			this._stackLayout._setFocus = false;
					
			var displayUI = true;
			if (displayUI) {
				domAttr.set(this.context.element, "region", "Properties");
				domAttr.set(this.context.element, "aria-label", "Properties");
				domAttr.set(this.context.element, "tabindex", "0");
			} else {
				domAttr.remove(this.context.element, "region");
				domAttr.remove(this.context.element, "aria-label");
				domAttr.remove(this.context.element, "tabindex");
			}
			
			if (contentClass) {
				// properties come from the content list config settings (originally select from class properties)
				var results = {
				};
				var searchProperties = this.context.options.searchProperties;
				if (searchProperties) {
					var properties = searchProperties.get("value");
					if (properties != null) {
						properties = properties.items ? properties.items : properties;
						// Check to see if there are any existing property values and use those as default values
						if (this._instance.propertyValues) {
							var defaultValues = this._instance.propertyValues;
							if (defaultValues && defaultValues != "") {
								defaultValues = JSON.parse(defaultValues);
								var modifiedProperties = [];
								for (var i = 0; i < properties.length; i++) {
									var property = properties[i];
									modifiedProperties.push({
										name: property.name,
										displayName: property.displayName,
										operator: property.operator,
										dataType: property.dataType,
										cardinality: property.cardinality,
										defaultValue: defaultValues[i][property.name],
										hide: property.hide
									});
								}
								results.properties = modifiedProperties;
							}
						} else {
							results.properties = properties;
						}
					}
				}				
				this._onGetPropertiesResult(this, results);
			} else {
				// Need to get the classes property descriptions mainly for the choice lists and extended meta-data
				var params = {
					classId: classId,
					isSearchable: true,
					repository: this._proto._getObjectStoreName(this),
					serverAppResource: this._serverConfigurationName
				};
				
				this.classDetailsService = this.ui.get("GetClassDetails");
				this._proto._callService(this.classDetailsService, params);
			}
		};
			
		this.constructor.prototype._storeCallbackErrback = function(callback, errback, refresh) {
			this._deleteCallbackErrback();
			this._callback = callback;
			this._errback = errback;
			this._refreshAfterUpdate = refresh;
		};
		
		this.constructor.prototype._handleCallback = function(properties, contentElements) {
			if (this._refreshAfterUpdate){
				this._refreshAfterUpdateProperties(properties);
				
				// Check for a bound object and update it's properties
				if (this.context.binding) {
					var boundProperty = this.context.binding.property;
					if (boundProperty != null) {
					}
				}
			}
			if (this._callback){
				this._callback(properties, contentElements);
			}
		};
		
		this.constructor.prototype._handleErrback = function(error, response) {
			if (this._errback) {
				this._errback(error, response);
			}
		};
		
		this.constructor.prototype._deleteCallbackErrback = function() {
			this._callback = null;
			this._errback = null;
			this._refreshAfterUpdate = null;
		};
		
		this.constructor.prototype._handleError = function(error, errorMessage) {
			var errorMessage;
			var logMessage = errorMessage ? errorMessage : error.errorText;	
			bpmext.log.error(logMessage);			
			bpmext.ui.executeEventHandlingFunction(this, this.EVT_ONERROR, logMessage);
			this._handleErrback(errorMessage, error);
		};
		
		this.constructor.prototype.isValid = function() {
			var valid = true;
			var numStackContainers = this.ui.getCount("PropertyStackContainer");
			for (var i = 0; i < numStackContainers; i++) {
				stackContainer = this._stackLayout.ui.getChild("PropertyStackContainer", i);
				if (stackContainer){
					if (!stackContainer.isValid()) {
						valid = false;
					}
				}
			}
			return valid;
		};

		this.constructor.prototype._runFilterQuery = function(runButton) {
			console.log("CS-ContentListFilter:_runFilterQuery() : called.");
			var propertyValues = this.getPropertyValues(true);
			if (propertyValues) {
				this._instance.propertyValues = propertyValues;
				// Fire an event that content content list can handle to invoke the query
//				[
//				   {DateCreated: "2020-07-20T07:00:00.000Z"},
//				   {DateCreated: "2020-07-31T07:00:00.000Z"}
//				]
				
				bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONFILTER, propertyValues);
			}
		};

		this.constructor.prototype._resetFilterQuery = function(resetButton) {
			console.log("CS-ContentListFilter:_resetFilterQuery() : called.");
			this._instance.propertyValues = null;
			
			// Fire an event that content content list can handle to reset the query
			bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONCANCELFILTER);
		};
		
		this.constructor.prototype.saveProperties = function() {
			var propertyValues = this.getPropertyValues(true);
			if (propertyValues) {
				this._instance.propertyValues = propertyValues;
			}
		};
		
		this.constructor.prototype.getPropertyValues = function(forJson) {
			var propertyValues = "[";
			
			var searchProperties = this.context.options.searchProperties;
			if (searchProperties) {
				var properties = searchProperties.get("value");
				if (properties != null) {
					var stackIndex = 0;
					// See if there are any hidden property filters, if so, get their default values
					properties = properties.items ? properties.items : properties;
					for (var i = 0; i < properties.length; i++) {
						var property = properties[i];
						var stackContainer = this._stackLayout.ui.getChild("PropertyStackContainer", stackIndex);
						if (stackContainer != null) {
							var propertyId = stackContainer.getPropertyId();
							if (property.name == propertyId) {
								// Yes property has a stack container, it is being displayed
								propertyValue = stackContainer.getPropertyValue(forJson);
								if (propertyValue != null) {
									if (propertyValues.length > 1) {
										propertyValues += ", ";
									}
									propertyValues += propertyValue;
								}
								stackIndex++;
							} else {
								// No property does not have a stack container, is hidden
								propertyValues += this._proto._getPropertyValue(property, propertyValues.length > 1);
							}
						} else {
							// No stack  container for this property, probably at end , last property
							propertyValues += this._proto._getPropertyValue(property, propertyValues.length > 1);
						}
					}
				}
			}

			return propertyValues + "]";
		};
	
		this.constructor.prototype._onGetPropertiesResult = function(view, results) {
			// Get properties results and merge them in with the class descriptions property definitions
			var propertyObjects = results.properties.items ? results.properties.items : results.properties;
			var classDescription = this._metadataCache[this._classId];
			
			this._propertyObjects = this._proto._mergeSearchProperties(classDescription, propertyObjects, false, this._valueOnly);
			
			this._setProperties();
			if (this._action == Actions.DISPLAY_FILTER) {
				this._handleCallback(propertyObjects);
			}
		};

		this.constructor.prototype._onGetPropertiesError = function(view, response) {
			var errorMessage;
			switch(response.errorCode) {
				case "FNRJG1006":
					errorMessage = messages.properties_document_or_folder_not_found;
					break;
			}
			this._proto._clearServiceError(this, "GetPropertiesService");
			this._handleError(response, errorMessage);
		};
		
		this.constructor.prototype._onClassDetailsResult = function(view, results) {
			var jsonClass = results;
			var classId = jsonClass["symbolicName"];
			this._metadataCache[classId] = jsonClass;

			if (this._action == Actions.DISPLAY_FILTER) {
				if (this._classId == classId){
					// Put the filter properties in the "results" format similar to typicaly get properties response
					var results = {
					};
					var searchProperties = this.context.options.searchProperties;
					if (searchProperties) {
						var properties = searchProperties.get("value");
						if (properties != null) {
							results.properties = properties.items ? properties.items : properties;
						}
					}				
					this._onGetPropertiesResult(view, results);
				}
			}
		};
		
		this.constructor.prototype._onClassDetailsError = function(view, response) {
			this._proto._clearServiceError(this, "GetClassDetails");
			this._handleError(response, messages.properties_class_not_found);
		};
				
		this.constructor.prototype._refreshAfterUpdateProperties = function(properties) {
			var propertiesLookup = {};
			properties.forEach(function(property) {
				propertiesLookup[property.id] = property.value;
			});
							
			// Update property objects with values returned in results.
			this._propertyObjects.forEach(function(propertyObject) {
				if (propertyObject.cardinality == "SINGLE") {
					propertyObject.singleCardinalityValue = propertiesLookup[propertyObject.id];
					propertyObject.listCardinalityValues = [];
				} else if (propertyObject.cardinality == "LIST") {
					propertyObject.singleCardinalityValue = null;
					propertyObject.listCardinalityValues = propertiesLookup[propertyObject.id];
					
					// Work around a date binding issue for MVCPs
					if (propertyObject.type == "DATE") {
						dateListValues = propertyObject.listCardinalityValues.items ? propertyObject.listCardinalityValues.items : propertyObject.listCardinalityValues;
						propertyObject.listCardinalityValues = dateListValues.map(function(dateStringValue) {
							return new Date(dateStringValue);
						});
					}
				}
			});
			this._setProperties();
		};
		
		this.constructor.prototype.change = function(event) {
			try	{
				if (event.type != "config" && this.context.binding) {
					console.log("CS-ContentListFilter:change() : Change update for bound object");
					var contentItem = event.newVal;
					if (contentItem != null) {
					}
				}
			} catch (e) {
				bpmext.log.error("Error on change event [" + this.ui.getAbsoluteName() + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};
		
		this.constructor.prototype.view = function() {
            try {
				this._proto._handleVisibility(this);
				
				// Check for a bound object use it to re-render the properties UX with
				if (this.context.binding) {
					var boundProperty = this.context.binding.property;
					if (boundProperty != null) {
						var contentItem = this.context.binding.boundObject[boundProperty];
					}
				}
 			} catch (e) {
                bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                if (e.stack) {
                    bpmext.log.error("  Call stack: " + e.stack);
				}
            }
        };
	
		this.constructor.prototype.load = function() {
			try	{
				bpmext.ui.registerEventHandlingFunction(this, this.EVT_ONERROR, "errors");				
				bpmext.ui.registerEventHandlingFunction(this, this.EVT_ONFILTER, "values");				
				bpmext.ui.registerEventHandlingFunction(this, this.EVT_ONCANCELFILTER);				
				
				this._stackLayout = this.ui.getChild("StackLayout");	
				this._stackContainer = this.ui.get("PropertyStackContainer");	

				var options = this.context.options;

				if (!options.objectStoreName) {
                    options.objectStoreName = bpmext.ui.substituteConfigOption(this, "objectStoreName", null);
				}

				if (options.includeTimePicker == null){
					options.includeTimePicker = bpmext.ui.substituteConfigOption(this, "includeTimePicker", false);
				}
				var includeTime = options.includeTimePicker.get("value");
				if (this._stackContainer) {
					this._stackContainer.setIncludeTimePicker(includeTime);
					this._stackContainer.setUIParent(this);
				}
				
				if (!options.className) {
                    options.className = bpmext.ui.substituteConfigOption(this, "className", null);
				}
				
				domClass.add(this.context.element, "CS_Properties");

			} catch (e) {
				bpmext.log.error("Error on load event [" + this.context.viewid + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};
		
		this.constructor.prototype._propertyChanged = function(){
			this._propertyUpdated = true;
		};
		
		this.constructor.prototype._editingProperties = function(){
			return true;
		};
		
		this.constructor.prototype.setObjectStoreName = function(objectStoreName){
			this.context.options.objectStoreName.set("value", objectStoreName);
		};
		
		this.constructor.prototype.getObjectStoreName = function(){
			return this.context.options.objectStoreName.get("value");
		};
		
		this.constructor.prototype.setServerConfigurationName = function(serverConfigurationName){
			this._serverConfigurationName = serverConfigurationName;
		};
		
		this.constructor.prototype.getServerConfigurationName = function(){
			return this._serverConfigurationName;
		};
		
		this.constructor.prototype.setIncludeTimePicker = function(includeTimePicker){
			this.context.options.includeTimePicker.set("value", includeTimePicker);
		};
		
	}	
}
	