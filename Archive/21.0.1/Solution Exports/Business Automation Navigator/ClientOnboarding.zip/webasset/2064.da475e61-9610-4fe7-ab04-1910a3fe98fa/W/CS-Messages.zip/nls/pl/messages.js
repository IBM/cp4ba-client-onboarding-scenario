/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "Klasa",

		// Property list
		properties_file_name: "Nazwa pliku",
		properties_file_save_in: "Zapisz w",
		properties_add_file: "Dodaj plik",
		properties_add_mvcp: "Dodaj ${0}",
		properties_remove_mvcp: "Usuń z ${0}",
		properties_use_file_name: "Dla tej właściwości zostanie użyta nazwa pliku",

		properties_optional_label: "${0} (opcjonalnie)",

		properties_document_or_folder_not_found: "Nie znaleziono dokumentu lub folderu.",
		properties_class_not_found: "Nie znaleziono klasy treści.",
		properties_folder_duplicate_item_invalid_prop: "W folderze istnieje już element o takiej samej nazwie lub wprowadzono niepoprawną wartość właściwości.",
		properties_item_invalid_prop: "Wprowadzono niepoprawną wartość co najmniej jednej właściwości.",

		properties_invalid_long_value: "Ta wartość jest niepoprawna. Wartość musi być liczbą całkowitą, na przykład 5 lub 1349.",
		properties_invalid_float_value: "Ta wartość jest niepoprawna. Wartość musi być liczbą zmiennopozycyjną, na przykład 1.2 lub 365.",
		properties_min_value: "Minimalna wartość: ${0}",
		properties_max_value: "Maksymalna wartość: ${0}",
		properties_max_length: "Maksymalna długość: ${0}",
		properties_invalid_guid: "Ta wartość jest niepoprawna. Ta wartość musi być identyfikatorem GUID, na przykład {F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}.",
		properties_value_required: "Ta wartość jest wymagana.",
		properties_unique_value_required: "Wartość musi być unikalna.",
		properties_file_required: "Plik jest wymagany.",
		properties_invalid_folder_name: "Nazwa folderu nie może zawierać żadnego z następujących znaków: \\ / : * ? \" < > |",

		properties_move_edit_confirm_msg: "Zmieniasz właściwości następującego dokumentu<br>${0}<br><br>Czy chcesz zapisać zmiany?",
		properties_move_edit_confirm_no: "Nie",
		properties_move_edit_confirm_yes: "Tak",
		properties_move_edit_confirm_title: "Potwierdzenie",
		properties_edit_save_success: "Właściwości zostały zapisane",
		properties_edit_save_failure: "Właściwości nie zostały zapisane",
		properties_no_item_selected: "Nie wybrano żądanego elementu.",

		// Content list
		contlist_column_spec_title: "Tytuł",
		contlist_column_spec_name: "Nazwa",
		contlist_column_spec_version_label: "Wersja",
		contlist_column_spec_modified_by: "Zmodyfikowane przez",
		contlist_column_spec_mod_date: "Ostatnia modyfikacja",
		contlist_column_spec_created_by: "Utworzone przez",
		contlist_column_spec_creation_date: "Utworzenie",
		contlist_column_spec_mime_type: "Typ dokumentu",
		contlist_column_spec_size: "Wielkość",
		contlist_column_spec_thumbnail: "Miniatura",

		contlist_paging_no_more_items: "Nie ma więcej elementów",
		contlist_paging_of_at_least_items: "${0} z co najmniej ${1} elementów",
		contlist_paging_of_items: "${0} z ${1} elementów",
		contlist_paging_items: "Elementy ${0}",
		contlist_paging_items_per_page: "Elementów na stronę: ${0}",

		contlist_checked_out: "Wypisany",
		contlist_checked_out_by: "Wypisane przez ${0}",

		contlist_size_units_B: "B",
		contlist_size_units_KB: "kB",
		contlist_size_units_MB: "MB",
		contlist_size_units_GB: "GB",
		contlist_size_units_TB: "TB",

		contlist_missing_server_error: "Nie określono serwera.",
		contlist_invalid_server_error: "Serwer '{0}' nie istnieje.",
		contlist_error_retrieving_doc_props: "Błąd podczas pobierania właściwości dokumentu.",
		contlist_error_retrieving_folder_props: "Błąd podczas pobierania właściwości folderu.",
		contlist_checkout_failed: "Wypisanie dokumentu nie było możliwe",
		contlist_cancel_checkout_failed: "Anulowanie wypisania nie powiodło się",
		contlist_rename_folder_failed: "Zmiana nazwy folderu nie była możliwa.",
		contlist_folder_name_not_unique: "Nazwa folderu musi być unikalna.",
		contlist_delete_object_failed: "Usunięcie obiektu nie było możliwe.",
		contlist_display_properties_failed: "Wyświetlenie właściwości nie było możliwe. ${0}",
		contlist_save_props_failed: "Zapisanie właściwości nie było możliwe",
		contlist_upload_failed: "Przesłanie wersji nie było możliwe",
		contlist_add_folder_failed: "Dodanie folderu nie było możliwe. ${0}",
		contlist_add_document_failed: "Dodanie dokumentu nie było możliwe. ${0}",
		contlist_search_failed: "Wydobycie wyników wyszukiwania nie było możliwe",
		contlist_folder_containees_failed: "Wydobycie zawartości folderu nie było możliwe",
		contlist_delete_folder_referenced: "Nie można usunąć folderu, ponieważ zawiera on podfoldery.",
		contlist_docs_not_added: "Dodanie następujących dokumentów nie było możliwe: ${0}",

		contlist_checkout_success: "Dokument został wypisany",
		contlist_delete_success: "Obiekt został usunięty",
		contlist_rename_folder_success: "Nazwa folderu została zmieniona",
		contlist_save_props_success: "Właściwości zostały zapisane",
		contlist_cancel_checkout_success: "Anulowanie wypisania powiodło się",
		contlist_upload_version_success: "Wersja została przesłana",
		contlist_add_folder_success: "Folder został dodany",
		contlist_add_doc_success: "Dokument został dodany",
		contlist_add_docs_success: "Dokumenty zostały dodane",

		contlist_menu_action_open: "Otwórz",
		contlist_menu_action_rename: "Zmień nazwę",
		contlist_menu_action_properties: "Właściwości",
		contlist_menu_action_view: "Wyświetl",
		contlist_menu_action_download: "Pobierz",
		contlist_menu_action_checkout: "Wypisz",
		contlist_menu_action_edit_document: "Edytowanie dokumentu",
		contlist_menu_action_cancel_checkout: "Anuluj wypisanie",
		contlist_menu_action_delete_doc: "Usuwanie dokumentu",
		contlist_menu_action_rename_folder: "Zmień nazwę folderu",
		contlist_menu_action_add_folder: "Dodaj folder",
		contlist_menu_action_delete_folder: "Usuwanie folderu",
		contlist_menu_action_add_doc: "Dodaj dokument",
		contlist_menu_action_upload: "Prześlij nową wersję",

		contlist_document_properties: "Właściwości dokumentu",
		contlist_folder_properties: "Właściwości folderu",
		contlist_folder_name: "Nazwa folderu",

		contlist_cancel_btn_label: "Anuluj",
		contlist_add_btn_label: "Dodaj",
		contlist_ok_btn_label: "Ok",
		contlist_edit_btn_label: "Edytuj",
		contlist_save_btn_label: "Zapisz",
		contlist_upload_btn_label: "Przesyłanie",
		contlist_refresh_btn_label: "Odśwież",
		contlist_next_btn_label: "Dalej",
		contlist_previous_btn_label: "Wstecz",

		contlist_delete_folder_confirm: "Nastąpi usunięcie folderu ${0}. Czy chcesz kontynuować?",
		contlist_delete_doc_confirm: "Nastąpi usunięcie dokumentu ${0}. Czy chcesz kontynuować?",

		contlist_no_mimetype: "Ten element nie zawiera treści.",
		contlist_folder_mimetype: "Folder",

		contlist_filter_search_hint: "Szukaj dokumentów",
		contlist_filter_folder_hint: "Filtruj listę",

		contlist_root_folder: "Folder główny",
		contlist_drop_folder_error: "Nie można dodawać folderów. Wybierz tylko pliki.",
		contlist_add_in_process: "Przed dodaniem następnego dokumentu poczekaj, aż zakończy się dodawanie poprzedniego.",
		contlist_add_doc_max_exceeded: "Jednorazowo można dodać maksymalnie ${0} elementów. Podejmujesz próbę dodania ${1} elementów.",
		contlist_progress_success: "Powodzenie",
		contlist_progress_alert: "Alert",
		contlist_progress_error: "Błąd",
		contlist_progress_uploading: "Przesyłanie",
		contlist_progress_processing: "Przetwarzanie 1 pliku",
		contlist_progress_uploading_text: "Przesyłanie 1 pliku",
		contlist_progress_upload_failed: "Wystąpił problem",
		contlist_progress_close: "Zamknij",
		progress_ind_uploaded_status: "Przesłano",
		progress_ind_uploaded: "Przesłano 1 plik",
		progress_ind_uploaded_error: "Przetwarzanie nie rozpoczęło się",		
		progress_ind_processing_status: "Przetwarzanie",
		progress_ind_processing_err: "Wystąpił problem",
		progress_ind_processed: "Przetworzono 1 plik",	
		progress_ind_failed: "Nie powiodło się",
		progress_ind_review_doc: "Wymagana recenzja",	
		progress_ind_updating: "Aktualizowanie 1 pliku",
		progress_ind_updating_status: "Aktualizowanie",
		progress_ind_update_err: "Wystąpił problem",
		progress_ind_timeout: "Przekroczono limit czasu monitorowania",
		progress_ind_refresh: "Odśwież",

		getcontent_ret_versions_error: "Pobieranie serii wersji nie powiodło się",
		getcontent_ret_properties_error: "Pobieranie właściwości dokumentu nie powiodło się",

		contentviewer_test_mode: "Przeglądarka nie będzie wyświetlać dokumentów w trybie podglądu. Wymagana jest praca w aplikacji lokalnej IBM Navigator.",

		thumbnail_retreival_error: "Pobranie miniatury nie powiodło się.",

		status_10: "Przesłano",
		status_20: "Przetwarzanie",
		status_25: "Ponowne przetwarzanie",
		status_30: "Wymagana recenzja",
		status_40: "Aktualizowanie",
		status_900: "Błąd przetwarzania",
		status_910: "Błąd aktualizacji",

		/*do not remove this line*/nop: null
});
