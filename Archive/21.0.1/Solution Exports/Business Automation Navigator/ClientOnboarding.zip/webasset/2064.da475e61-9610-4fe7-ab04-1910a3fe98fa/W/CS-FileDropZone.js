/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2020. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

cs_InitFileDropZone = function(bpmext, domClass, domStyle, domAttr, messages, string) {
	
	_uploadContent: null;
	_objectStoreName: null;
	_parentFolder: null;
	
	if (!this.constructor.prototype._proto)
	{
		this.constructor.prototype._proto =
		{
			EVT_ONADD: "eventON_ADD",
			EVT_ONERROR: "eventON_ERROR",
	
			_setAlertMessage: function(view, message, isError, delay) {
				var title = messages.contlist_progress_success;
				var style = "S";
				if (isError) {
					title = messages.contlist_progress_alert;
					style = "D";
				}
				// Call out to the CS_Alert utility class to handle displaying the alert message
				setAlertMessage(title, message, style, delay, domClass, domStyle, domAttr, messages);
			},

			_setHeight: function(view) {
				var size = view.context.options.height.get("value");
				if (size ) {
					try	{
						if (size != null && size != "")	{
							if (!isNaN(size)) {
								size += "px";
							}
							view.context.element.style.height = size;
						}
					} catch (e)	{
						bpmext.log.error("CS-FileDropZone._setHeight() error: " + e);
						if (e.stack) {
							bpmext.log.error("  Call stack: " + e.stack);
						}
					}
				}
			},
			
			_setWidth: function(view) {
				var size = view.context.options.width.get("value");
				if (size) {
					try {
						if (size != null && size != "") {
							if (!isNaN(size)) {
								size += "px";
							}
							view.context.element.style.width = size;
						}
					} catch (e)	{
						bpmext.log.error("CS-FileDropZone._setWidth() error: " + e);
						if (e.stack) {
							bpmext.log.error("  Call stack: " + e.stack);
						}
					}
				}
			},
			
			_onExternalDragOver: function(event, view) {
				event.preventDefault();
				var fileDropZone = view.context.element;
				domClass.add(fileDropZone, "CS_FileDropZoneDragOver");
			},

			_onExternalDrop: function(event, view) {
				this._onExternalDragLeave(event, view);
				event.preventDefault();
				this._uploadFiles(event.dataTransfer.files, event.dataTransfer.items, view);
			},
		
			_onExternalDragLeave: function(event, view) {
				event.preventDefault();
				var fileDropZone = view.context.element;
				domClass.remove(fileDropZone, "CS_FileDropZoneDragOver");
			},
		
			_uploadFiles: function(files, items, view, index) {
				document.body.style.cursor = 'wait';
				this._uploadFile(files, items, view, 0, function() {
					document.body.style.cursor = 'default';
					console.log("CS-FileDropZone:_uploadFiles() : Uploaded successfully.");
				}, function(error) {
					document.body.style.cursor = 'default';
					console.log("CS-FileDropZone:_uploadFiles() : Error occured.");
				});
			},
			
			_uploadFile: function(files, items, view, index, callback, errback) {
				var self = this;
				// Check for folders, can only drop files
				var foundFolder = false;
				var entry;
				if (items) {
					for (var i = 0; i < items.length; i++) {
						var item = items[i];
						if ((item.webkitGetAsEntry != null) && (entry = item.webkitGetAsEntry())) {
							if (!entry.isFile){
								foundFolder = true;
								break;
							}
						} else if (item.getAsFile == null || item.kind !== "file") {
							foundFolder = true;
							break;
						}
					}
				}
				
				if (foundFolder) {
					var message = messages.contlist_drop_folder_error;
					view._proto._setAlertMessage(view, message, true);
					bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONERROR, message);
					errback(message);
				} else if (files.length > view.context.options.maxAddDocuments.get("value")) {
					document.body.style.cursor = 'default';
					var message = string.substitute(messages.contlist_add_doc_max_exceeded, [view.context.options.maxAddDocuments.get("value"), files.length]);
					view._proto._setAlertMessage(view, message, true, 6000);
					bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONERROR, message);
					errback(message);
				} else {
					if (index >= files.length) {
						if (files.length == 1) {
							console.log("CS-FileDropZone:_uploadFile() : Successfully added the file.");
							view._proto._setAlertMessage(view, messages.contlist_add_doc_success, false);	
						} else {
							console.log("CS-FileDropZone:_uploadFile() : Successfully added the files.");
							view._proto._setAlertMessage(view, messages.contlist_add_docs_success, false);	
						}
						callback();
					} else {
						var file = files[index];
						// See if a document type has been specified in the config settings, if not use base Document type
						var documentType = view.context.options.defaultDocumentType.get("value");
						if (documentType == null || documentType == "") {
							documentType = "Document";
						}
						console.log("CS-FileDropZone:_uploadFile() : Adding document with type: " + documentType + " and name: " + file.name);
						
						view._uploadContent.uploadFileSimpleWithClass(view._parentFolder, file, documentType, function(result) {
							var contentItem = self._createDocumentContentItem(result.properties, result.contentElements);
							bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONADD, contentItem);

							// If there were multiple files selected or dropped, get the file at the next index and add it.
							view._proto._uploadFile(files, null, view, ++index, callback, errback);
						}, function(error){
							var message = string.substitute(messages.contlist_add_document_failed, [file.name]);
							view._proto._setAlertMessage(view, message, true, 6000);
							bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONERROR, message);
							errback(error);
						});		
					}
				}
			},
			
			_createDocumentContentItem: function(properties, contentElements) {
				var contentItem = {
					isFolder: false,
					properties: properties
				};
				if (contentElements != null) {
					contentItem.contentElements = contentElements;
				}
				// Dig some properties out of the property bag and make first class properties
				for (var i = 0; i < properties.length; i++) {
					var property = properties[i];
					if (property.id == "Id") {
						contentItem.id = property.value;
					} else if (property.id == "Name") {
						contentItem.name = property.value;
					} else if (property.id == "MimeType") {
						contentItem.mimeType = property.value;
					} else if (property.id == "IsReserved") {
						contentItem.isReserved = property.value;
					}
				} 
				return contentItem;
			}
		}		
	}
	
	this.constructor.prototype.load = function() {
		var options = this.context.options;
		
		if (!options.objectStoreName) {
			options.objectStoreName = bpmext.ui.substituteConfigOption(this, "objectStoreName", "");
		} else {
			this._objectStoreName = options.objectStoreName.get("value");
		}
		
		if (!options.folderId) {
			options.folderId = bpmext.ui.substituteConfigOption(this, "folderId", "");
		} else {
			this._parentFolder = options.folderId.get("value");
		}
	
		if (!options.maxAddDocuments) {
			options.maxAddDocuments = bpmext.ui.substituteConfigOption(this, "maxAddDocuments", 50);
		}				
		if (options.maxAddDocuments.get("value") > 50){
			options.maxAddDocuments.set("value", 50);
		}
		
		if (!options.defaultDocumentType) {
			options.defaultDocumentType = bpmext.ui.substituteConfigOption(this, "defaultDocumentType", "");
		}

		if (!options.height) {
			options.height = bpmext.ui.substituteConfigOption(this, "height", null);
		}
		if (!options.width) {
			options.width = bpmext.ui.substituteConfigOption(this, "width", null);
		}

		domClass.add(this.context.element, "CS_FileDropZone");
	
	  	bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONADD, "contentItem");
		bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONERROR, "message");

		this._proto._setWidth(this);
		this._proto._setHeight(this);

		bpmext.ui.loadView(this);

		this._uploadContent = this.ui.get("UploadContent");
		
		var self = this;
		this.context.element.addEventListener('dragover', function(evt) {
			evt.preventDefault();
			evt.stopPropagation();
			self._proto._onExternalDragOver(evt, self);
		}, false);
		
		this.context.element.addEventListener('drop', function(evt) {
			evt.preventDefault();
			evt.stopPropagation();
			event.stopPropagation();
			self._proto._onExternalDrop(evt, self);
		}, false);
		
		this.context.element.addEventListener('dragleave', function(evt) {
			evt.preventDefault();
			evt.stopPropagation();
			self._proto._onExternalDragLeave(evt, self);
		}, false);

		var fileInput = this.context.element.querySelector(".CS_FileInput");
		fileInput.onchange = function() {
			if (this.files.length > 0) {
				self._proto._uploadFiles(this.files, null, self);
			}
		}		
	};
	
	this.constructor.prototype.change = function(event) {

	};
}