/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2020. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

cs_InitUploadContent = function(bpmext, domClass, domStyle, domAttr, messages, cookie) {
	
	this._instance = {
		objectStoreName: null,
		maxConcurentAdds: 5,
		addsInProgress: 0,
		maxAddsAvailable: 50,
		additionalPropertiesOnAdd: [],
		classes: {},
		batchData: [],
		classDetailsService: null,
		getDocumentsService: null,
		checkoutDocumentService: null,
		dependentPropertyInfo: null,
		configurationProperty: null,
		configurationValues: {},
		progressIndicator: null,
		propertyPoller: null,
		documentUploadedCallback: null,
		batchUpdatedCallback: null,
		uploadEcmTokenValue: 0
	}

	if (!this.constructor.prototype._proto)
	{
		this.constructor.prototype._proto =
		{
			_appResource: "GRAPHQL_APP_RESOURCE",
			_connectionStr: "/content-services-graphql/graphql",
			_documentTitle: "{DocumentTitle: \"",
			_pageSize: 2000,
			EVT_ONERROR: "eventON_ERROR",
			EVT_ONCONTENTADDED: "eventON_CONTENTADDED",
			EVT_ONDOCUMENTADDED: "eventON_DOCUMENTADDED",
			
			batchStatusPropertyValues: {
				CREATED: 210,
				UPLOADING: 220,
				UPLOADED: 230,
				PROCESSING_REQUESTED: 240,
				PROCESSING: 250,
				PROCESSING_ERROR: 1920,
				CLASSIFICATION_REVIEW_REQUIRED: 260,
				CLASSIFICATION_REVIEW_COMPLETE: 270,
				REPROCESSING: 280,
				UPLOAD_ERROR: 1900,
				UPLOAD_CANCELLED: 1910,
			},
			BATCH_STATUS_PROPERTY_VALUE_ERROR_LOWER_BOUNDARY: 1900,
			BATCH_STATUS_PROPERTY_VALUE_ERROR_UPPER_BOUNDARY: 1999,
			
			documentStatusPropertyValues: {
				PENDING: 3,
				UPLOADING: 5,
				UPLOADED: 10,
				PROCESSING_ERROR: 900,
				UPDATING_ERROR: 910,
				UPLOAD_ERROR: 920
			},
			DOCUMENT_STATUS_PROPERTY_VALUE_ERROR_LOWER_BOUNDARY: 900,
			DOCUMENT_STATUS_PROPERTY_VALUE_ERROR_UPPER_BOUNDARY: 999,
			
			classificationBatchAction: {
				CREATE_BATCH: "createBatch",
				ADD_DOCUMENT: "addDocument",
				REPLACE_DOCUMENT: "replaceDocument",
				INSERT_ABOVE: "insertAbove",
				INSERT_BELOW: "insertBelow"
			},
			
			// Table of well known file extension to mime types. Derived from a simiar table in com.ibm.ecm.util.MimeTypeUtil.
			_mimeTypeLookup: {
				"gsheet": "application/vnd.google-apps.spreadsheet",
				"gdoc": "application/vnd.google-apps.document",
				"boxnote": "application/x-box-note",
				"afp": "application/afp",
				"dcm": "application/dicom",
				"ftf": "application/dca-rft",
				"dwg": "application/dwg",
				"lin": "application/line",
				"mdb": "application/msaccess",
				"accdb": "application/msaccess",
				"dot": "application/msword",
				"doc": "application/msword",
				"class": "application/octet-stream",
				"exe": "application/octet-stream",
				"lzh": "application/octet-stream",
				"lha": "application/octet-stream",
				"dms": "application/octet-stream",
				"bin": "application/octet-stream",
				"pdf": "application/pdf",
				"rss": "application/rss+xml",
				"frm": "application/vnd.framemaker",
				"fm": "application/vnd.framemaker",
				"mda": "application/vnd.ibm.modcap",
				"wks": "application/vnd.lotus-1-2-3",
				"wk1": "application/vnd.lotus-1-2-3",
				"wk3": "application/vnd.lotus-1-2-3",
				"wk4": "application/vnd.lotus-1-2-3",
				"123": "application/vnd.lotus-1-2-3",
				"pre": "application/vnd.lotus-freelance",
				"prz": "application/vnd.lotus-freelance",
				"smm": "application/vnd.lotus-wordpro",
				"mwp": "application/vnd.lotus-wordpro",
				"sam": "application/vnd.lotus-wordpro",
				"lwp": "application/vnd.lotus-wordpro",
				"xll": "application/vnd.ms-excel",
				"xlw": "application/vnd.ms-excel",
				"xlc": "application/vnd.ms-excel",
				"xla": "application/vnd.ms-excel",
				"xld": "application/vnd.ms-excel",
				"xlm": "application/vnd.ms-excel",
				"xlt": "application/vnd.ms-excel",
				"xls": "application/vnd.ms-excel",
				"xlam": "application/vnd.ms-excel.addin.macroEnabled.12",
				"xlsb": "application/vnd.ms-excel.sheet.binary.macroEnabled.12",
				"xlsm": "application/vnd.ms-excel.sheet.macroEnabled.12",
				"xltm": "application/vnd.ms-excel.template.macroEnabled.12",
				"msg": "application/vnd.ms-outlook",
				"pwz": "application/vnd.ms-powerpoint",
				"ppz": "application/vnd.ms-powerpoint",
				"pps": "application/vnd.ms-powerpoint",
				"ppa": "application/vnd.ms-powerpoint",
				"pot": "application/vnd.ms-powerpoint",
				"ppt": "application/vnd.ms-powerpoint",
				"ppam": "application/vnd.ms-powerpoint.addin.macroEnabled.12",
				"pptm": "application/vnd.ms-powerpoint.presentation.macroEnabled.12",
				"ppsm": "application/vnd.ms-powerpoint.slideshow.macroEnabled.12",
				"potm": "application/vnd.ms-powerpoint.template.macroEnabled.12",
				"docm": "application/vnd.ms-word.document.macroEnabled.12",
				"dotm": "application/vnd.ms-word.template.macroEnabled.12",
				"odp": "application/vnd.oasis.opendocument.presentation",
				"otp": "application/vnd.oasis.opendocument.presentation-template",
				"ods": "application/vnd.oasis.opendocument.spreadsheet",
				"ots": "application/vnd.oasis.opendocument.spreadsheet-template",
				"odt": "application/vnd.oasis.opendocument.text",
				"ott": "application/vnd.oasis.opendocument.text-template",
				"pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
				"ppsx": "application/vnd.openxmlformats-officedocument.presentationml.slideshow",
				"potx": "application/vnd.openxmlformats-officedocument.presentationml.template",
				"xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
				"xltx": "application/vnd.openxmlformats-officedocument.spreadsheetml.template",
				"docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
				"dotx": "application/vnd.openxmlformats-officedocument.wordprocessingml.template",
				"xsn": "application/vnd.ms-infopath",
				"vsd": "application/vnd.visio",
				"vss": "application/x-visio",
				"vst": "application/x-visio",
				"mpp": "application/vnd.ms-project",
				"mpv": "application/x-project",
				"mpx": "application/x-project",
				"mpt": "application/x-project",
				"w51": "application/wordperfect5.1",
				"wpd": "application/wordperfect5.1",
				"wp": "application/wordperfect5.1",
				"pub": "application/x-mspublisher",
				"ulw": "audio/basic",
				"snd": "audio/basic",
				"au": "audio/basic",
				"mpga": "audio/mpeg",
				"mpa": "audio/mpeg",
				"mpm": "audio/mpeg",
				"mp2": "audio/mpeg",
				"m1a": "audio/mpeg",
				"m1s": "audio/mpeg",
				"mp3": "audio/mpeg",
				"qcp": "audio/vnd.qcelp",
				"aifc": "audio/x-aiff",
				"aiff": "audio/x-aiff",
				"aif": "audio/x-aiff",
				"kar": "audio/x-midi",
				"smf": "audio/x-midi",
				"mid": "audio/x-midi",
				"midi": "audio/x-midi",
				"wma": "audio/x-ms-wma",
				"wav": "audio/x-wav",
				"dss": "audio/x-dss",
				"dib": "image/bmp",
				"bmp": "image/bmp",
				"cals": "image/cals",
				"dcx": "image/x-dcx",
				"g3f": "image/g3fax",
				"gif": "image/gif",
				"jpg2": "image/jp2",
				"j2k": "image/jp2",
				"jp2": "image/jp2",
				"jpc": "image/jpc",
				"svg": "image/svg+xml",
				"pjp": "image/jpg",
				"pjpeg": "image/jpg",
				"jfif": "image/jpg",
				"jpe": "image/jpg",
				"jpeg": "image/jpg",
				"jpg": "image/jpg",
				"jpgm": "image/jpm",
				"jpm": "image/jpm",
				"jpx": "image/jpx",
				"jpf": "image/jpx",
				"pcx": "image/x-pcx",
				"png": "image/png",
				"tif": "image/tiff",
				"tiff": "image/tiff",
				"plg": "text/html",
				"shtml": "text/html",
				"html": "text/html",
				"htm": "text/html",
				"log": "text/plain",
				"text": "text/plain",
				"txt": "text/plain",
				"rtf": "application/rtf",
				"dtd": "text/xml",
				"xml": "text/xml",
				"csv": "application/csv",
				"m15": "video/mpeg",
				"m75": "video/mpeg",
				"m1v": "video/mpeg",
				"mpe": "video/mpeg",
				"mpeg": "video/mpeg",
				"mpg": "video/mpeg",
				"vfw": "video/x-msvideo",
				"avi": "video/x-msvideo",
				"qt": "video/quicktime",
				"mov": "video/quicktime",
				"asx": "video/x-ms-asf",
				"asf": "video/x-ms-asf",
				"wmv": "video/x-ms-wmv",
				"flv": "video/x-flv",
				"swf": "application/x-shockwave-flash",
				"cptx": "application/cptx",
				"pep": "application/x-filenet-workflowdefinition",
				"xpdl": "application/x-filenet-xpdlworkflowdefinition",
				"itx": "application/x-filenet-itxformtemplate",
				"xfdd": "application/vnd.xfdl.design",
				"tar": "application/tar",
				"cgm": "image/cgm",
				"eml": "message/rfc822",
				"dxf": "application/dxf",
				"ics": "text/calendar",
				"mp4": "video/mp4",
				"m4v": "video/x-m4v",
				"webm": "video/webm",
				"zip": "application/zip",
				"z": "application/x-compress",
				"gzip": "application/x-gzip",
				"gz": "application/x-gzip",
				"rar": "application/x-rar-compressed",
				"xps": "application/vnd.ms-xpsdocument",
				"rmp": "application/NikuWorkbench",
				"ps": "application/postscript",
				"tnf": "application/vnd.ms-tnef",
				"dxl": "application/x-lotus-dxl",
				"roff": "application/x-troff",
				"url": "text/url",
				"java": "text/x-java-source",
				"js": "application/javascript",
				"json": "application/json "
			},
			
			/**
			* @private
			*/
			_setupAdditionalProperties: function(view, batchData){
				console.log("CS-UploadContent: _setupAdditionalProperties called");
				if (view._instance.configurationValues && Object.keys(view._instance.configurationValues).length > 0){
					var configProperties = Object.keys(view._instance.configurationValues);
					for (var i = 0; i < configProperties.length; i++){
						var configProperty = configProperties[i];
						var jsonValue = view._instance.configurationValues[configProperty];
						var value = JSON.stringify(jsonValue);
						view.addAdditionalPropertyOnAdd(configProperty, value);
					}
					view._instance.configurationValues = {};
				}
				
				var requiredClassId;
				if (batchData.classId == view._instance.classificationDocumentClass){
					if (view._instance.additionalPropertiesOnAdd != null && view._instance.additionalPropertiesOnAdd.length > 0 && 
						view._instance.classificationControllerClass && !view._instance.classes[view._instance.classificationControllerClass]){
				
						// Just need to get the controller class description if we are adding additional properties.
						requiredClassId = view._instance.classificationControllerClass;
					}
				}
				else if (!view._instance.classes[batchData.classId]){
					requiredClassId = batchData.classId;
				}
					
				if (requiredClassId){
					var params = {
						classId: requiredClassId,
						repository: view._instance.objectStoreName,
						serverAppResource: this._appResource,
						batchId: batchData.id
					}
					this._callService(view._instance.classDetailsService, params, true);
				}
				else{
					if (view._instance.additionalPropertiesOnAdd != null && view._instance.additionalPropertiesOnAdd.length > 0){	
						this._addAdditionalProperties(view, batchData.id);
					}
					else {
						this._handleBatchType(view, batchData);
					}
				}
			},
			
			/**
			* @private
			*/
			_addAdditionalProperties: function(view, batchId){
				console.log("CS-UploadContent: _addAdditionalProperties called");
				var batchData = view._instance.batchData.find(batch => batch.id == batchId);
				
				// Strip off "]" character of the property string.
				var classPropertyString = batchData.properties.substring(0, batchData.properties.length - 1);
				var controllerPropertyString;
				
				var contentClass = view._instance.classes[batchData.classId];
				var controllerClass = view._instance.classes[view._instance.classificationControllerClass];
				for (var i = 0; i < view._instance.additionalPropertiesOnAdd.length; i++){
					var additionalProperty = view._instance.additionalPropertiesOnAdd[i];
					if (!additionalProperty.propertyValue){
						continue;
					}
					
					var controllerClassProperty;
					if (controllerClass){
						controllerClassProperty = controllerClass.classPropertiesLookupById[additionalProperty.propertyId] ? controllerClass.classPropertiesLookupById[additionalProperty.propertyId] : 
							controllerClass.classPropertiesLookupByName[additionalProperty.propertyId];
					}
					
					var classProperty;
					if (!controllerClassProperty){
						classProperty = contentClass.classPropertiesLookupById[additionalProperty.propertyId] ? contentClass.classPropertiesLookupById[additionalProperty.propertyId] : 
							contentClass.classPropertiesLookupByName[additionalProperty.propertyId];
					}
					if ((!classProperty && !controllerClassProperty) || (controllerClassProperty && controllerClassProperty.cardinality != "SINGLE") ||  (classProperty && classProperty.cardinality != "SINGLE")){
						console.log("CS_UploadContent._addAdditionalProperties: Property " + additionalProperty.propertyId + " in class " + batchData.classId + " is not present or does not have single cardinality and the value " + additionalProperty.propertyValue + " was not added.");
					}
					else {
						var property;
						var propertyString;
						if (controllerClassProperty){
							property = controllerClassProperty
							propertyString = controllerPropertyString;
						}
						else {
							property = classProperty
							propertyString = classPropertyString;
						}
						var propertyValue = additionalProperty.propertyValue;
						var formattedValue = null;
						if (propertyString && propertyString.length > 1){
							propertyString += ", {" + additionalProperty.propertyId + ": ";
						}
						else {
							propertyString = ", {" + additionalProperty.propertyId + ": ";
						}
						switch(property.dataType){
							case "STRING":
							case "GUID":
								var sanitizedValue = propertyValue.replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/\t/g,'\\t').replace(/"/g,'\\"');
								formattedValue = "\"" + sanitizedValue + "\"";
								break;
							case "BOOLEAN":
								formattedValue = propertyValue == "" ? null : propertyValue;
								break;
							case "DATE":
								var value = propertyValue == "" ? null : propertyValue;
								if (value){
									var dateValue = new Date(value);
									formattedValue =  "\"" + dateValue.toISOString() + "\"";
								}
								else{
									formattedValue = null;
								}
								break;
							default:
								formattedValue = propertyValue;
								break;
						}
						propertyString += formattedValue + "}";
						if (controllerClassProperty){
							controllerPropertyString = propertyString;
						}
						else {
							classPropertyString = propertyString;
						}
					}
				}
				classPropertyString += "]";
				batchData.properties = classPropertyString;
				batchData.controllerProperties = controllerPropertyString;
				this._handleBatchType(view, batchData);
			},
			
			/**
			* @private
			*/
			_handleBatchType: function(view, batchData){
				console.log("CS-UploadContent: _handleBatchType called");
				if (batchData.classificationBatchAction){
					switch(batchData.classificationBatchAction){
						case view._proto.classificationBatchAction.CREATE_BATCH:
							this._addClassificationBatch(view, batchData);
							break;
						case view._proto.classificationBatchAction.ADD_DOCUMENT:
							this._appendDocumentsToClassificationBatch(view, batchData);
							break;
						case view._proto.classificationBatchAction.REPLACE_DOCUMENT:
							this._replaceDocumentInClassificationBatch(view, batchData);
							break;
						case view._proto.classificationBatchAction.INSERT_ABOVE:
						case view._proto.classificationBatchAction.INSERT_BELOW:
							this._insertDocumentsIntoClassificationBatch(view, batchData);
							break;
						default:
							console.error("Invalid value for batchData.classificationBatchAction: " + batchData.classificationBatchAction);
							break;
					}
				}
				else {
					this._addDocuments(view, batchData);
				}
			},
		
			/**
			* @private
			*/
			_getMimeType: function(filename){
				console.log("CS-UploadContent: _getMimeType called");
				// Try to get the mime type based on the file extension.
				var index = filename.lastIndexOf(".");
				if (index != -1) {
					extension = filename.substring(index + 1, filename.length).toLowerCase();
					if (extension != null && extension.length > 0) {
						return this._mimeTypeLookup[extension];
					}
				}
			},
			
			/**
			* @private
			*/
			_addDocumentFromFile: function(view){	
				console.log("CS-UploadContent: _addDocumentFromFile called");
				var fileData = this._getNextBatchFile(view);
				if (fileData && fileData.file){
					view._instance.addsInProgress++;
					var batchData = view._instance.batchData.find(batch => batch.id == fileData.id);
					batchData.addsInProgress++;
					var file = fileData.file;
					console.log("CS-UploadContent: _addDocumentFromFile : Starting add for " + file.name);
					if (view._instance.progressIndicator){
						view._instance.progressIndicator.updateDocumentStatus(file.name, view._proto.documentStatusPropertyValues.UPLOADING, true, false, null, batchData.id);
					}
					var mimeType = file.type && file.type != "" ? file.type : this._getMimeType(file.name);
					var properties = fileData.properties;
					if (fileData.useFilenameForTitle){
						properties = this._useFilenameForTitle(properties, file.name);
					}
					var query;
					if (batchData.classId == view._instance.classificationDocumentClass){
						var documentId = this._getId();
						var controllerId = this._getId();
						var query = "mutation createDocument($nFile: String) {\n";						
						query += this._getAddControlledAddDocumentMutation(view, fileData, documentId, controllerId, properties);
						query += this._getCheckinDocumentMutation(view, documentId, mimeType);
					}
					else {
						query = this._getAddDocumentMutation(view, fileData, file, mimeType, properties);
					}
										
					var _this = this;
					this._uploadContent(view, query, file, function(results){
						console.log("CS-UploadContent: _addDocumentFromFile : Successful add for " + file.name);
						_this._handleAddDocumentCallbacks(view, results, batchData, file.name, false);
					}, function(error){
						console.log("CS-UploadContent: _addDocumentFromFile : Error occurred for " + file.name);
						_this._handleAddDocumentCallbacks(view, error, batchData, file.name, true);
					});					
				}
			},
			
			/**
			* @ private
			*/
			_checkinClassificationBatchFromFile: function(view){
				console.log("CS-UploadContent: _checkinClassificationBatchFromFile called");
				var fileData = this._getNextBatchFile(view);
				if (fileData && fileData.file){
					var file = fileData.file.file;
					view._instance.addsInProgress++;
					var batchData = view._instance.batchData.find(batch => batch.id == fileData.id);
					batchData.addsInProgress++;
					var mimeType = file.type && file.type != "" ? file.type : this._getMimeType(file.name);
					var query = "mutation checkinDocument($nFile: String) {\n";
					query += this._getCheckinDocumentMutation(view, fileData.file.documentId, mimeType);
					
					// Don't need to update the first set of controllers because the status was set to uploading when they were created.
					if (fileData.file.controllerStatus && fileData.file.controllerStatus != view._proto.documentStatusPropertyValues.UPLOADING){
						var controllerProperties = [{"DbaCaptureStatus": view._proto.documentStatusPropertyValues.UPLOADING}];
						this._updateClassificationController(view, fileData, controllerProperties);
					}
					
					console.log("CS-UploadContent: _checkinClassificationBatchFromFile : Begin uploading " + file.name);
					var _this = this;
					this._uploadContent(view, query, file, function(results){
						console.log("CS-UploadContent: _checkinClassificationBatchFromFile : Successful add for " + file.name);						
						_this._handleAddDocumentCallbacks(view, results, batchData, file.name, false);
					}, function(error){
						var isError = true;
						// Handle a missing file or controller as a valid case -- the user may have deleted the document before it was uploaded.
						if (error.extensions && error.extensions.statusCode && error.extensions.statusCode == "404"){
							isError = false;
						}
						if (isError){
							console.log("CS-UploadContent: _checkinClassificationBatchFromFile : Error occurred for " + file.name);
							var batchProperties = [{"DbaBatchStatus": view._proto.batchStatusPropertyValues.UPLOAD_ERROR}];
							_this._updateClassificationBatch(view, batchData, batchProperties);
						
							var controllerProperties = [{"DbaCaptureStatus": view._proto.documentStatusPropertyValues.UPLOAD_ERROR}];
							_this._updateClassificationController(view, fileData, controllerProperties);
						}
						_this._handleAddDocumentCallbacks(view, error, batchData, file.name, true);
					});				
				}
			},

			/**
			* @private
			*/
			_getId: function(){
				var id = ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, c => (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16));
				console.log("CS-UploadContent: _getId : Id = " + id);
				return "{" + id.toUpperCase() + "}";
			},
			
			/**
			* @private
			*/
			_useFilenameForTitle: function(properties, fileName){
				var newProperties;
				var docTitleIndex = properties.indexOf(this._documentTitle);
				if (docTitleIndex >= 0){
					newProperties = properties.substring(0, docTitleIndex + this._documentTitle.length);
					newProperties += fileName;
					var endIndex = properties.indexOf("\"", docTitleIndex + this._documentTitle.length);
					newProperties += properties.substring(endIndex);
				}
				else {
					var newProperties = properties.substring(0, properties.length - 1);
					if (newProperties && newProperties.length > 1){
						newProperties += ", ";
					}
					newProperties += this._documentTitle + fileName + "\"}]";
				}
				return newProperties;
			},
			
			/**
			* @private
			*/
			_handleAddDocumentCallbacks: function(view, results, batchData, fileName, error){
				console.log("CS-UploadContent: _handleAddDocumentCallbacks : Processing results for " + fileName);
				view._instance.addsInProgress--;
				if (view._instance.addsInProgress <= 0){
					view._instance.uploadEcmTokenValue = 0;
				}
				batchData.addsInProgress--;
				if (batchData){
					if (error){
						batchData.errors.push({
							fileName: fileName,
							error: results
						});
					}
					else {
						batchData.results.push({
							fileName: fileName,
							results: results
						});
					}
				}
				
				var documentId;
				if (!error){
					documentId = results.id;
					if (!documentId){
						var idProperty = results.properties.find(property => property.id == "Id");
						documentId = idProperty.value;
					}
					bpmext.ui.executeEventHandlingFunction(view, this.EVT_ONDOCUMENTADDED, documentId);
					var polling = view._instance.propertyPoller;
					if (polling && batchData.classificationBatchAction != view._proto.classificationBatchAction.CREATE_BATCH){
						view._instance.propertyPoller.addDocumentId(documentId);
					}
					if (view._instance.progressIndicator){
						var processingStatus = polling ? 10 : "";
						view._instance.progressIndicator.updateDocumentStatus(fileName, processingStatus, polling, !polling, documentId, batchData.id);
					}
				}
				else {
					if (view._instance.progressIndicator){
						var processingStatus = error ? "error" : "";
						view._instance.progressIndicator.updateDocumentStatus(fileName, processingStatus, view._instance.propertyPoller, true, null, batchData.id);
					}
				}
				
				if (view._instance.documentUploadedCallback){
					var batchStatus = batchData.cancelled ? view._proto.batchStatusPropertyValues.UPLOAD_CANCELLED : batchData.errors.length > 0 ? view._proto.batchStatusPropertyValues.UPLOAD_ERROR : view._proto.batchStatusPropertyValues.UPLOADING;
					var batchProperties = null;
					if (batchData.classificationBatchId){
						batchProperties = [{
							id: "DbaBatchStatus",
							value: batchStatus
						}];
					}
					var documentId
					view._instance.documentUploadedCallback(fileName, documentId, batchData.classificationBatchId, batchProperties);
				}
				
				if (batchData.addsInProgress <= 0){
					this._handleBatchCallbacks(view, batchData);
				}
				
				batchData.classificationBatchCheckins ? this._checkinClassificationBatchFromFile(view) :this._addDocumentFromFile(view);
			},
			
			/**
			* @private
			*/
			_getClassificationBatchPercentDone(batchData){
				var numDone = batchData.errors.length + batchData.results.length;
				var percentDone = ((numDone / batchData.numFiles) * 100).toFixed(0);
				return(percentDone);
			},
			
			/**
			* @private
			*/
			_getNextBatchFile: function(view){
				console.log("CS-UploadContent: _getNextBatchFile : Getting next file");
				var results;
				for (var i = 0; i < view._instance.batchData.length; i++){
					var batchData = view._instance.batchData[i];
					if ((batchData.files && batchData.files.length > 0) || batchData.classificationBatchCheckins && batchData.classificationBatchCheckins.length > 0){
						var results = Object.assign({}, batchData);
						results.file = batchData.files.length > 0 ? batchData.files.shift() : batchData.classificationBatchCheckins.shift();
						break;
					}
				}
				return results;
			},
			
			/**
			* @private
			*/
			_cancelClassificationBatchUpload: function(view, classificationBatchId){
				var batchData = view._instance.batchData.find(batch => batch.classificationBatchId == classificationBatchId);
				if (batchData){
					batchData.files = [];
					batchData.cancelled = true;
					var batchProperties = [{"DbaBatchStatus": view._proto.batchStatusPropertyValues.UPLOAD_CANCELLED}];
					this._updateClassificationBatch(view, batchData, batchProperties);
					if (view._instance.documentUploadedCallback){
						var batchProperties = [{
							id: "DbaBatchStatus",
							value: view._proto.batchStatusPropertyValues.UPLOAD_CANCELLED
						}];
					}
					view._instance.documentUploadedCallback(null, null, batchData.classificationBatchId, batchProperties);
				}
			},
			
			/**
			* @private
			*/
			_removePendingFile: function(view, batchId, fileName){
				console.log("CS-UploadContent: _removePendingFile : Removing pending file: " + fileName);
				var removedItem = false;
				for (var i = 0; i < view._instance.batchData.length; i++){
					var batchData = view._instance.batchData[i];
					if (batchData.id == batchId){
						for (var j = 0; j < batchData.files.length; j++){
							var file = batchData.files[j];
							if (file.name == fileName){
								batchData.files.splice(j, 1);
								removedItem = true;
								break;
							}
						}
						if (removedItem){
							break;
						}
					}
				}
			},
			
			/**
			* @private
			*/
			_handleBatchCallbacks: function(view, batchData){
				console.log("CS-UploadContent: _handleBatchCallbacks : Handling callbacks for batch " + batchData.id);
				if (batchData.classificationBatchId && batchData.errors.length == 0 && !batchData.cancelled){
					this._updateClassficationBatchCompleted(view, batchData);
				}
				
				if (batchData.errors.length > 0 && batchData.errback){
					batchData.numFiles == 1 ? batchData.errback(batchData.errors[0].error) : batchData.errback(batchData.errors);
				}
				else if (batchData.callback){
					batchData.numFiles == 1 ? batchData.callback(batchData.results[0].results) : batchData.callback(batchData.results);								
				}
				
				var index = -1
				for (var i = 0; i < view._instance.batchData.length; i++){
					if (view._instance.batchData[i].id == batchData.id){
						index = i;
						break;
					}
				}
				if (index >= 0){
					view._instance.batchData.splice(index, 1);
				}
			},
			
			/**
			* @private
			*/
			_updateClassficationBatchCompleted: function(view, batchData){			
				console.log("CS-UploadContent: _updateClassficationBatchCompleted called for " + batchData.id);
				if ((!batchData.errors || batchData.errors.length == 0) && !batchData.cancelled){					
					var _this = this;
					var updateBatchStatus = function(view, batchData, batchStatus){
						var batchProperties = [{"DbaBatchStatus": batchStatus}];
						if (batchStatus == _this.batchStatusPropertyValues.UPLOADED){
							batchProperties.push({"DbaBatchError": ""});
						}
						_this._updateClassificationBatch(view, batchData, batchProperties);
					};
					
					// If this is for a new batch, we don't need to check the status of the individual controllers.
					if (batchData.classificationBatchAction == view._proto.classificationBatchAction.CREATE_BATCH){
						updateBatchStatus(view, batchData, this.batchStatusPropertyValues.UPLOADED);
						if (view._instance.documentUploadedCallback){
							batchProperties = [{
								id: "DbaBatchStatus",
								value: this.batchStatusPropertyValues.UPLOADED
							}];
							view._instance.documentUploadedCallback(null, null, batchData.classificationBatchId, batchProperties);
						}
					}
					else {
						// After updating an existing batch, we need to check each of the controllers and set the status of the batch accordingly.
						var query = "query {\n";
						query += 		"repositoryRows(\n";
						query +=		"repositoryIdentifier:\"" + view._instance.objectStoreName + "\"\n";
						query +=		"sql: \"SELECT dcc.DbaCaptureStatus FROM DbaCaptureBase dcb INNER JOIN DbaClassificationController dcc ON dcb.Id = dcc.DbaDocId WHERE dcc.DbaBatchController = " + batchData.classificationBatchId + "\"\n";
						query +=		"pageSize: 2000\n";
						query +=	")\n";
						query +=	"{\n";
						query +=		"repositoryRows {\n";
						query +=			"properties {\n";
						query +=				"label\n";
						query +=				"value\n";
						query +=			"}\n";
						query +=		"}\n";
						query +=	"}\n";  
						query +="}\n";
						
						var operation = {
							query: query,
							variables: null
						};
								
						var formData = new FormData();;
						formData.append('operations', JSON.stringify(operation));
						
						var _this = this;
						this._sendRequest(view, formData, function(results){
							var batchStatus = _this.batchStatusPropertyValues.UPLOADED;
							var rows = results.repositoryRows;
							for (var i = 0; i < rows.length; i++){
								var property = rows[i].properties[0];
								if (property.value >= _this.DOCUMENT_STATUS_PROPERTY_VALUE_ERROR_LOWER_BOUNDARY &&
									property.value <= _this.DOCUMENT_STATUS_PROPERTY_VALUE_ERROR_UPPER_BOUNDARY){

									if (batchData.originalBatchStatus){
										batchStatus = batchData.originalBatchStatus;
									}
									break;
								}
							}
							updateBatchStatus(view, batchData, batchStatus);
						});
					}
				}
			},
			
			/**
			* @private
			*/
			_uploadNewVersionFromFile: function(view, documentId, file, callback, errback){			
				var mimeType = file.type && file.type != "" ? file.type : this._getMimeType(file.name);

				var query = "mutation checkinDocument($nFile: String) {\n";
				query += this._getCheckinDocumentMutation(view, documentId, mimeType);

				this._uploadContent(view, query, file, callback, errback);
			},
			
			/**
			* @private
			*/
			_getAddDocumentMutation: function(view, fileData, file, mimeType, properties){
				console.log("CS-UploadContent: _getAddDocumentMutation called for " + fileData.id);
				
				var query = "mutation createDocument($nFile: String) {\n"
				query += 		"createDocument(\n";
				query += 			"repositoryIdentifier:\"" + view._instance.objectStoreName + "\"\n";
				query += 			"classIdentifier:\"" + fileData.classId + "\"\n";
				query += 			"checkinAction: {}\n";
				
				if (file != null && fileData.parentFolderId && fileData.parentFolderId != "") {
					query += "fileInFolderIdentifier: \"" + fileData.parentFolderId + "\"\n";
				}
				
				query += 	    	"documentProperties: {\n";
				query += 		   	"properties: " + properties + "\n";
				query += 		    "contentElements:{ \n";
				query += 			   	"replace: [ {\n";
				query += 			    	"type: CONTENT_TRANSFER contentType: \"" + mimeType + "\" subContentTransfer: {\n";
				query += 				    	"content: $nFile\n";
				query += 			    	"}\n";
				query += 			   	"}]\n";
				query +=            "}\n";
				query +=		"}\n";
				query += 	")\n";
				query += 	"{\n";
				query += 		"id\n";
				query += 		"contentElements {\n";
				query +=			"elementSequenceNumber\n";
				query +=			"... on ContentTransfer {\n";
				query += 					"retrievalName\n";
				query += 					"downloadUrl\n";
				query +=				"}\n";
				query +=		"}\n";
				query +=		"properties {\n";
				query += 			"id\n";
				query +=			"cardinality\n";
				query +=			"value\n";
				query +=		"}\n";
				query += 	"}\n";
				query += "}\n";

				return query;
			},
			
			/**
			* @private
			*/
			_getAddControlledAddDocumentMutation: function(view, fileData, documentId, controllerId, properties, orderNo, controllerStatus){
				console.log("CS-UploadContent: _getAddControlledAddDocumentMutation called. DocumentId: " + documentId + " ControllerId: " + controllerId);
				var addDocumentName = "createDocument" +  documentId.replace(/[{}]/g, "").replace(/-/g, "_");
				var addControllerName = "createController" + controllerId.replace(/[{}]/g, "").replace(/-/g, "_");
				
				query = 		addControllerName + ":createCmAbstractPersistable(\n";
				query += 			"repositoryIdentifier:\"" + view._instance.objectStoreName + "\"\n";
				query += 			"classIdentifier:\"" + view._instance.classificationControllerClass + "\"\n";
				query += 			"id:\"" + controllerId + "\"\n";
				query += 			"cmAbstractPersistableProperties: {\n";
				query += 				"properties: [{DbaDocId: \"" + documentId + "\"}";
				
				if (controllerStatus){
					query +=			", {DbaCaptureStatus: " + controllerStatus + "}";
				}

				if (fileData.controllerProperties){
					query += fileData.controllerProperties;
				}
				if (orderNo){
					query += ", {DbaBatchOrder: \"" + orderNo + "\"}";
				}
				query += 			"]\n";
				
				if (fileData.classificationBatchId){
					query += 			"objectProperties:[{\n";
					query +=				"identifier: \"DbaBatchController\"\n";
					query +=				"objectReferenceValue: {\n";
					query += 					"identifier: \"" + fileData.classificationBatchId + "\"\n";
					query +=				"}\n";
					query +=			"}]\n";;
				}
				query +=			"}\n";
				query +=	 	")\n";
				query += 		"{\n";
				query +=			"id\n";
				query += 		"}\n";
				
				query += 		addDocumentName + ":createDocument(\n";
				query += 			"repositoryIdentifier:\"" + view._instance.objectStoreName + "\"\n";
				query += 			"classIdentifier:\"" + fileData.classId + "\"\n";
				query += 			"id:\"" + documentId + "\"\n";
			
				if (fileData.parentFolderId && fileData.parentFolderId != "") {
					query += "fileInFolderIdentifier: \"" + fileData.parentFolderId + "\"\n";
				}
				
				query += 	    	"documentProperties: {\n";
				query += 		   		"properties: " + properties + "\n";
				query +=				"objectProperties:[{\n";
				query += 					"identifier: \"" + view._instance.controllerDocumentProperty +"\"\n";
				query +=					"objectReferenceValue: {identifier:\"" + controllerId + "\"}\n";
				query += 				"}]\n";
				query +=			"}\n";
				query += 		")\n";
				query += 		"{\n";
				query += 			"id\n";
				query += 		"}\n";

				return query;
			},
			
			/*
			* @private
			*/
			_getCheckinDocumentMutation(view, documentId, mimeType){
				console.log("CS-UploadContent: _getCheckinDocumentMutation called. DocumentId: " + documentId);				
				query =		 "checkinDocument (\n";
				query += 			"repositoryIdentifier:\"" + view._instance.objectStoreName + "\"\n";
				query +=			"identifier: \"" + documentId + "\"\n";
				query +=			"documentProperties: {\n";
				query += 		    	"contentElements:{ \n";
				query += 			   		"replace: [{\n";
				query += 			    		"type: CONTENT_TRANSFER contentType: \"" + mimeType + "\" subContentTransfer: {\n";
				query += 				    		"content: $nFile\n";
				query += 			    		"}\n";
				query += 			   		"}]\n";
				query +=            	"}\n";
				query += 			"}\n";
				query +=			"checkinAction: {}\n";
				query += 		")\n";
				query += 		"{\n";
				query += 			"id\n";
				query += 			"contentElements {\n";
				query +=				"elementSequenceNumber\n";
				query +=				"... on ContentTransfer {\n";
				query += 						"retrievalName\n";
				query += 						"downloadUrl\n";
				query +=					"}\n";
				query +=			"}\n";
				query +=			"properties {\n";
				query += 				"id\n";
				query +=				"cardinality\n";
				query +=				"value\n";
				query +=			"}\n";
				query +=		"}\n";
				query += "}\n";
				
				return query;
			},
			
			/**
			* @private
			*/
			_uploadAnnotationFromFile: function(view, documentId, documentClassId, file, annotationClassId, callback, errback){
				console.log("CS-UploadContent: _uploadAnnotationFromFile called. DocumentId: " + documentId);	
				var mimeType = file.type && file.type != "" ? file.type : this._getMimeType(file.name);
				
				var query = "mutation($nFile: String) {\n";
				query +=		"createAnnotation( \n";
				query += 			"repositoryIdentifier:\"" + view._instance.objectStoreName + "\"\n";
				query +=			"classIdentifier: \"" + annotationClassId + "\"\n";
				query +=			"annotationProperties: { \n";
				query += 				"mimeType:\"" + mimeType +  "\"\n";
				query += 				"annotatedObject: {\n";
				query += 					"identifier:\"" + documentId +"\"\n";
				query +=					"classIdentifier: \"" + documentClassId +  "\"\n";
				query += 					"repositoryIdentifier:\"" + view._instance.objectStoreName + "\"\n";
				query +=				"}\n";
				query += 				"content: $nFile\n";
				query +=			"}\n";
				query +=		")\n";
				query +=		"{\n";
				query +=			"id\n";
				query +=			"contentElements {\n";
				query +=				"elementSequenceNumber\n";
				query +=				"... on ContentTransfer {\n";
				query +=					"retrievalName\n";
				query +=					"downloadUrl\n";
				query +=				"}\n";
				query +=			"}\n";
				query +=			"properties {\n";
				query +=				"id\n";
				query +=				"cardinality\n";
				query +=				"value\n";
				query +=			"}\n";
				query +=		"}\n";
				query += 	"}\n";
				
				this._uploadContent(view, query, file, callback, errback);
			},
			
			/**
			* @private
			*/
			_createFileFromData: function(content, fileName, mimeType){
				var blob = new Blob([content], {type: mimeType});
				return new File([blob], fileName, {type: mimeType});
			},
			
			/**
			* @private
			*/
			_isCurrentUserCheckout: function(view, reservation) {
				var isCurrentUser = false;
				// Need to check to see if current logged in user is the one who has the document checked out
				if (reservation.creator) {
					var reservationUser = reservation.creator;
					// NOTE: The following call only works if running in ICN in platform mode
					var currentUser = this._getUserId(view);
					if (currentUser != null && reservationUser == currentUser) {
						isCurrentUser = true;
					}
				}
				return isCurrentUser;
			},
			
			/**
			* @private
			*/
			_getUserId: function(view) {
				var userId = view._instance.userId;
				if (userId == null) {
					// Todo: Currently, no way of getting logged in user information from UMS, temporary work around
					var navUrl = window.location.href;
					var params = navUrl.split("&");
					for (var i = 0; i < params.length; i++) {
						var param = params[i].split("=");
						if (param[0] == "userId") {
							userId = decodeURIComponent(param[1]);
							view._instance.userId = userId;
							break;
						}
					}
				}
				return userId;
			},
			
			/**
			* @private
			*/
			_uploadContent: function(view, query, file, callback, errback){				
				console.log("CS-UploadContent: _uploadContent called");	

				var operation = {
					query: query,
					variables: {
						nFile: null
					}
				};
				
				var map = {
					nFile: ["variables.file"]
				};
						
				var formData = new FormData();;
				formData.append('operations', JSON.stringify(operation));
				formData.append('map', JSON.stringify(map));
				formData.append("nFile", file);
				
				this._sendRequest(view, formData, function(results){
					view._proto.raiseSuccess(view, results);	
					if (callback){
						callback(results);
					}
				}, function(error){
					if (errback){
						errback(error);
					}
				});
			},
			
			/**
			* @private
			*/
			_addClassificationBatch: function(view, batchData){
				console.log("CS-UploadContent: _addClassificationBatch called");	
				batchData.classificationBatchId = this._getId();
				var controllerProperties;
				if (batchData.controllerProperties && batchData.controllerProperties.length > 0){
					controllerProperties = batchData.controllerProperties;
				}
				batchData.controllerProperties = controllerProperties;
				
				var query = "mutation {\n";
				query +=		"createBatch:createCmAbstractPersistable (\n";
				query += 			"repositoryIdentifier:\"" + view._instance.objectStoreName + "\"\n";
				query += 			"classIdentifier: \"DbaClassificationBatch\"\n";
				query +=			"id: \"" + batchData.classificationBatchId + "\"\n";
				query += 			"cmAbstractPersistableProperties:{\n";
				query +=				"properties: " + batchData.batchProperties + "\n";
				query +=			"}\n";
				query +=		")\n";
				query +=		"{\n";
				query +=			"id\n";
				query +=		"}\n";
				
				// Add documents and controllers to the graphql request.
				query += this._getClassificationBatchAddDocumentsMutation(view, batchData, "0");
				query +=	"}\n";
												
				var operation = {
					query: query,
					variables: null
				};
						
				var formData = new FormData();;
				formData.append('operations', JSON.stringify(operation));
				
				var _this = this;
				this._sendRequest(view, formData, function(results){
					if (view._instance.batchUpdatedCallback){
						view._instance.batchUpdatedCallback(results.id);
					}
					
					var properties = [{"DbaBatchStatus": view._proto.batchStatusPropertyValues.UPLOADING}];
					_this._updateClassificationBatch(view, batchData, properties);
					
					if (view._instance.documentUploadedCallback){
						var batchProperties = [{
							id: "DbaBatchStatus",
							value: view._proto.batchStatusPropertyValues.UPLOADING
						}];
						view._instance.documentUploadedCallback(null, null, batchData.classificationBatchId, batchProperties);
					}
					
					_this._addDocuments(view, batchData);
				}, function(error) {
					if (batchData.errback){
						batchData.errback(error);
					}
				});
			},
			
			/**
			* @private
			*/
			_getClassificationBatchAddDocumentsMutation: function(view, batchData, initialOrderNo, successorOrderNo){
				query = "";
				batchData.classificationBatchCheckins = [];
				var orderNo = initialOrderNo;
				while (batchData.files && batchData.files.length > 0){
					var file = batchData.files.shift();
					var documentId = this._getId();
					var controllerId = this._getId();
					var controllerStatus = batchData.numFiles - batchData.files.length > view._instance.maxConcurentAdds ? view._proto.documentStatusPropertyValues.PENDING : view._proto.documentStatusPropertyValues.UPLOADING;
					batchData.classificationBatchCheckins.push({
						file: file,
						documentId: documentId,
						controllerId: controllerId,
						controllerStatus: controllerStatus
					});
					var properties = batchData.properties;
					properties = this._useFilenameForTitle(properties, file.name);
					var orderNo = successorOrderNo ? this._getInsertOrderNumber(orderNo, successorOrderNo) : this._getAppendOrderNumber(orderNo);
					var controllerStatus = batchData.numFiles - batchData.files.length > view._instance.maxConcurentAdds ? view._proto.documentStatusPropertyValues.PENDING : view._proto.documentStatusPropertyValues.UPLOADING;
					query += this._getAddControlledAddDocumentMutation(view, batchData, documentId, controllerId, properties, orderNo, controllerStatus);
				}
				return query;
			},
			
			/**
			* @private
			*/
			_getAppendOrderNumber(orderNumberStr){
				var MAX_ORDERNO_DIGITS = 3;
				var newOrderNoStr = "";
				
				var orderNumberInt = parseInt(orderNumberStr);
				if (!isNaN(orderNumberInt)){
					orderNumberInt++;
				}
				var decimalIndex = orderNumberStr.indexOf(".");
				if (isNaN(orderNumberInt) || decimalIndex >= 0 || orderNumberInt.toString().length > MAX_ORDERNO_DIGITS){
					newOrderNoStr = orderNumberStr + ".1";
				}
				else {
					var numOrderNumDigits = orderNumberInt.toString().length;
					for (var i = 0; i < MAX_ORDERNO_DIGITS - numOrderNumDigits; i++){
						newOrderNoStr += "0";
					}
					newOrderNoStr += orderNumberInt.toString();
				}
				
				return newOrderNoStr;
			},
			
			/**
			* @private
			*/
			_getInsertOrderNumber(predecessor, successor){
				var newOrder = predecessor + ".1";
				if (newOrder < successor) {
					// should be good, save it
				} else {
					// Have a conflict, try adding zeros
					var newOrder;
					var count = 0;
					while (true) {
						// Add an extra "0" and try again
						count++;
						var increment = ".";
						for (var j = 0; j < count; j++) {
							increment += "0";
						}
						increment += "1";
						
						newOrder = predecessor + increment;
						if (newOrder < successor) {
							// should be good, save it
							break;
						}
						
						if (count == 99) {
							// Bad mojo, throw and error
							break;
						}
					}
				}
				return newOrder;
			},
			
			/**
			* @private
			*/
			_updateClassificationBatch: function(view, batchData, properties){
				console.log("CS-UploadContent: _updateClassificationBatch called. Classification batch id: " + batchData.classificationBatchId);	
				query = "mutation {\n";
				query += this._getUpdateAbstractPersistableMutation(view, batchData.classificationBatchId, "DbaClassificationBatch", properties);
				query +="}\n";
				
				var operation = {
					query: query,
					variables: null
				};
						
				var formData = new FormData();;
				formData.append('operations', JSON.stringify(operation));
				
				this._sendRequest(view, formData, function(results){

				}, function(){
				});
			},
			
			/**
			* @private
			*/
			_updateClassificationController: function(view, batchData, properties){
				console.log("CS-UploadContent: _updateClassificationController called. Controller id: " + batchData.file.controllerId);
				query = "mutation {\n";
				query += this._getUpdateAbstractPersistableMutation(view, batchData.file.controllerId, "DbaClassificationController", properties);
				query +="}\n";
				
				var operation = {
					query: query,
					variables: null
				};
						
				var formData = new FormData();;
				formData.append('operations', JSON.stringify(operation));
				
				this._sendRequest(view, formData, function(results){

				}, function(){
				});
			},
			
			/**
			* @private
			*/
			_getUpdateAbstractPersistableMutation: function(view, objectId, classId, properties){
				var graphQlProperties = this._convertJSONPropsToGraphql(properties);
				
				query =		"updateCmAbstractPersistable (\n";
				query += 		"repositoryIdentifier:\"" + view._instance.objectStoreName + "\"\n";
				query += 		"classIdentifier: \"" + classId + "\"\n";
				query +=		"identifier: \"" + objectId + "\"\n";
				query +=		"cmAbstractPersistableProperties: {\n";
				query +=			"properties: " + graphQlProperties + "\n";
				query +=		"}\n";
				query +=	")\n";
				query +=	"{\n";
				query +=		"id\n";
				query +=	"}\n";
				
				return query;
			},
			
			/**
			* @private
			*/
			_appendDocumentsToClassificationBatch(view, batchData){
				
				// Get the document count and status on the classification batch object.
				var documentCount = 0;
				var _this = this;
				this._getBatchStatus(view, batchData.classificationBatchId, function(batchProperties){
					documentCount = batchProperties.documentCount;
					batchData.originalBatchStatus = batchProperties.batchStatus;
					
					// Next, get the value of batch order proprerty on the last controller object.
					query = "query{\n";
					query += 	"repositoryRows(\n";
					query += 		"repositoryIdentifier:\"" + view._instance.objectStoreName + "\"\n";
					query +=		"sql: \"SELECT DbaBatchOrder FROM DbaClassificationController WHERE DbaBatchController = " + batchData.classificationBatchId + " ORDER BY DbaBatchOrder DESC\"\n";
					query +=		"pageSize: 1\n";
					query +=	")\n";
					query +=	"{\n";
					query +=		"repositoryRows {\n";
					query += 			"properties {\n";
					query += 				"value\n";
					query +=			"}\n";
					query +=		"}\n";
					query +=	"}\n";
					query +="}\n";
					
					var operation = {
						query: query,
						variables: null
					};						
					var formData = new FormData();;
					formData.append('operations', JSON.stringify(operation));
					_this._sendRequest(view, formData, function(results){
						var lastOrderNo = results.repositoryRows.length > 0 ? results.repositoryRows[0].properties[0].value : (0).toString();
						
						// Construct a graphql batch that will update the count in the classification batch object and add the documents and controllers for the new document(s).
						var batchProperties = [{"DbaBatchDocumentCount": documentCount + batchData.files.length}];
						query = "mutation {\n";
						query += _this._getUpdateAbstractPersistableMutation(view, batchData.classificationBatchId, "DbaClassificationBatch", batchProperties);
						query += _this._getClassificationBatchAddDocumentsMutation(view, batchData, lastOrderNo);
						query +="}\n";
						
						var operation = {
							query: query,
							variables: null
						};					
						var formData = new FormData();;
						formData.append('operations', JSON.stringify(operation));
						_this._sendRequest(view, formData, function(results){
							if (view._instance.batchUpdatedCallback){
								view._instance.batchUpdatedCallback(results.id);
							}
					
							var properties = [{"DbaBatchStatus": view._proto.batchStatusPropertyValues.UPLOADING}]
							_this._updateClassificationBatch(view, batchData, properties);
					
							if (view._instance.documentUploadedCallback){
								var batchProperties = [{
									id: "DbaBatchStatus",
									value: view._proto.batchStatusPropertyValues.UPLOADING
								}];
								view._instance.documentUploadedCallback(null, null, batchData.classificationBatchId, batchProperties);
							}					
							_this._addDocuments(view, batchData);
						}, function(error){
							if (batchData.errback){
								batchData.errback(error);
							}
						});
						
					}, function(error){
						if (batchData.errback){
							batchData.errback(error);
						}
					});
				}, function(error){
					if (batchData.errback){
						batchData.errback(error);
					}
				});
			},
			
			/**
			* @private
			*/
			_replaceDocumentInClassificationBatch: function(view, batchData){
				var file = batchData.files.shift();
				var documentId = this._getId();
				var controllerId = this._getId();
				batchData.classificationBatchCheckins = [{
					file: file,
					documentId: documentId,
					controllerId: controllerId,
					controllerStatus: this.documentStatusPropertyValues.UPLOADING
				}];
				var properties = batchData.properties;
				properties = this._useFilenameForTitle(properties, file.name);

				query = "mutation {\n";
				query += 	"deleteDocument(\n";
				query +=		"repositoryIdentifier: \"" + view._instance.objectStoreName + "\"\n";
				query +=		"identifier: \"" + batchData.documentId + "\"\n";
				query +=	")\n";
				query += 	"{\n";
				query +=		"id\n";
				query +=	"}\n";
				
				query += this._getAddControlledAddDocumentMutation(view, batchData, documentId, controllerId, properties, batchData.orderNumber, this.documentStatusPropertyValues.UPLOADING);
				
				query +="}\n";
						
				var operation = {
					query: query,
					variables: null
				};					
				var formData = new FormData();;
				formData.append('operations', JSON.stringify(operation));
				var _this = this;
				this._sendRequest(view, formData, function(results){
					if (view._instance.batchUpdatedCallback){
						view._instance.batchUpdatedCallback(results.id);
					}
					
					var properties = [{"DbaBatchStatus": view._proto.batchStatusPropertyValues.UPLOADING}]
					_this._updateClassificationBatch(view, batchData, properties);
				
					if (view._instance.documentUploadedCallback){
						var batchProperties = [{
							id: "DbaBatchStatus",
							value: view._proto.batchStatusPropertyValues.UPLOADING
						}];
						view._instance.documentUploadedCallback(null, null, batchData.classificationBatchId, batchProperties);
					}					
					_this._addDocuments(view, batchData);
				}, function(error){
					if (batchData.errback){
						batchData.errback(error);
					}
				});
			},
			
			/**
			* @private
			*/
			_insertDocumentsIntoClassificationBatch: function(view, batchData){
				
				// Get the document count and status on the classification batch object.
				var documentCount = 0;
				var _this = this;
				this._getBatchStatus(view, batchData.classificationBatchId, function(batchProperties){
					documentCount = batchProperties.documentCount;
					batchData.originalBatchStatus = batchProperties.batchStatus;
					
					var controllerOperator = ">=";
					var controllerOrder = "ASC";
					if (batchData.classificationBatchAction == _this.classificationBatchAction.INSERT_ABOVE){
						controllerOperator = "<=";
						controllerOrder = "DESC";
					}
					query = "query{\n";
					query += 	"repositoryRows(\n";
					query += 		"repositoryIdentifier:\"" + view._instance.objectStoreName + "\"\n";
					query +=		"sql: \"SELECT DbaBatchOrder FROM DbaClassificationController WHERE DbaBatchController = " + batchData.classificationBatchId + " AND DbaBatchOrder " +  controllerOperator + " '" + batchData.orderNumber + "' ORDER BY DbaBatchOrder " + controllerOrder + "\"\n";
					query +=		"pageSize: 2\n";
					query +=	")\n";
					query +=	"{\n";
					query +=		"repositoryRows {\n";
					query += 			"properties {\n";
					query += 				"value\n";
					query +=			"}\n";
					query +=		"}\n";
					query +=	"}\n";
					query +="}\n";
					
					var operation = {
						query: query,
						variables: null
					};						
					var formData = new FormData();;
					formData.append('operations', JSON.stringify(operation));
					_this._sendRequest(view, formData, function(results){
						var properties = results.repositoryRows.properties;
						var predecessor = results.repositoryRows[0].properties[0].value;
						var successor  = results.repositoryRows[1] ? results.repositoryRows[1].properties[0].value : null;
						if (batchData.classificationBatchAction == _this.classificationBatchAction.INSERT_ABOVE){
							predecessor = results.repositoryRows[1] ? results.repositoryRows[1].properties[0].value : "000";
							successor = results.repositoryRows[0].properties[0].value;
						}
							
						// Construct a graphql batch that will update the count in the classification batch object and add the documents and controllers for the new document(s).
						var batchProperties = [{"DbaBatchDocumentCount": documentCount + batchData.files.length}];
						query = "mutation {\n";
						query += _this._getUpdateAbstractPersistableMutation(view, batchData.classificationBatchId, "DbaClassificationBatch", batchProperties);
						query += _this._getClassificationBatchAddDocumentsMutation(view, batchData, predecessor, successor);
						query +="}\n";
						
						var operation = {
							query: query,
							variables: null
						};					
						var formData = new FormData();;
						formData.append('operations', JSON.stringify(operation));
						_this._sendRequest(view, formData, function(results){
							if (view._instance.batchUpdatedCallback){
								view._instance.batchUpdatedCallback(results.id);
							}
					
							var properties = [{"DbaBatchStatus": view._proto.batchStatusPropertyValues.UPLOADING}]
							_this._updateClassificationBatch(view, batchData, properties);
					
							if (view._instance.documentUploadedCallback){
								var batchProperties = [{
									id: "DbaBatchStatus",
									value: view._proto.batchStatusPropertyValues.UPLOADING
								}];
								view._instance.documentUploadedCallback(null, null, batchData.classificationBatchId, batchProperties);
							}					
							_this._addDocuments(view, batchData);
						}, function(error){
							if (batchData.errback){
								batchData.errback(error);
							}
						});
					}, function(error){
						if (batchData.errback){
							batchData.errback(error);
						}
					});
				});
			},
			
			/**
			* @private
			*/
			_getBatchStatus: function(view, classificationBatchId, callback, errback){
				var query = "query{\n";
				query +=		"cmAbstractPersistable(\n";
				query += 			"repositoryIdentifier:\"" + view._instance.objectStoreName + "\"\n";
				query += 			"classIdentifier: \"DbaClassificationBatch\"\n";
				query +=			"identifier: \"" + classificationBatchId + "\"\n";
				query +=		")\n";
				query +=		"{\n";
				query +=			"properties(includes:[\"DbaBatchDocumentCount\", \"DbaBatchStatus\"]) {\n";
				query +=				"id\n";
				query +=				"value\n";
				query +=			"}\n";
				query +=		"}\n";
				query +=	"}\n";
				
				var operation = {
					query: query,
					variables: null
				};						
				var formData = new FormData();;
				formData.append('operations', JSON.stringify(operation));				
				var _this = this;
				this._sendRequest(view, formData, function(results){
					var returnObject = {};						;
					for (var i = 0; i < results.properties.length; i++){
						var property = results.properties[i];
						if (property.id == "DbaBatchDocumentCount"){
							returnObject.documentCount = property.value;
						}
						else if (property.id == "DbaBatchStatus"){
							returnObject.batchStatus = property.value;
						}
					}
					if (callback){
						callback(returnObject);
					}
				}, function(error){
					if (errback){
						errback(error);
					}
				});
			},
	
			_callService: function(service, params, setInputData) {
				// Add the required token value to the service params
				params.ecmToken = this._getEcmToken(false);
				if (setInputData) {
					service.setInputData(params);
					service.execute();
				} else {
					service.execute(params);
				}
			},

			_getEcmTokenName: function() {
				return "ECM-CS-XSRF-Token";
			}, 
			
			_getEcmToken: function(setCookie) {
				// Create ecm token as a large random number
				var ecmToken = Math.floor(Math.random() * 10000000);
				if (setCookie) {
					cookie(this._getEcmTokenName(), ecmToken);
				}
				console.log("CS-UploadContent:_getEcmToken() : Ecm token: " + ecmToken);
				return ecmToken;
			},
	
			/**
			* @private
			*/
			_sendRequest: function(view, formData, callback, errback){
				var appResourceUrl = view.context.rewriteURI(this._connectionStr, this._appResource);
				var CSRFTokenHeaderName = view.context.getCSRFTokenHeaderName();
				var CSRFToken = view.context.getCSRFToken();
				
				var xhr = new XMLHttpRequest();
				xhr.open("POST", appResourceUrl, true);
				xhr.setRequestHeader("Accept", "application/json");
				
				// send CSRF Token
				xhr.setRequestHeader(CSRFTokenHeaderName, CSRFToken);
				
				var ecmToken;
				if (view._instance.uploadEcmTokenValue > 0){
					ecmToken = view._instance.uploadEcmTokenValue;
					cookie(this._getEcmTokenName(), ecmToken);
				}
				else {
					ecmToken = this._getEcmToken(true);
				}	
				xhr.setRequestHeader(this._getEcmTokenName(), ecmToken);

				xhr.onreadystatechange = function () {
					if (xhr.status == 200){
						if (xhr.readyState === 4){
							// A 200 response may contain errors from graphql api.
							var responseJson = JSON.parse(xhr.response);
							if (responseJson.errors){
								var errorResponse = responseJson.errors[0];
								console.error("CS-UploadContent: _sendRequest : Error returned from Graphql request: " + JSON.stringify(errorResponse));
								var error = {};
								error.errorText = errorResponse.extensions ? errorResponse.extensions.userResponse : errorResponse.message;
								error.errorCode = errorResponse.extensions ? errorResponse.extensions.errorCode : errorResponse.errorType;
								error.extensions = errorResponse.extensions ? errorResponse.extensions : null;
								view._proto.raiseError(view, error);
								if (errback){
									errback(error);	
								}
							}
							else {
								var results = {};
								results["id"] = responseJson.data.createDocument ? responseJson.data.createDocument.id : responseJson.data.checkinDocument ? 
									responseJson.data.checkinDocument.id : responseJson.data.createAnnotation ? responseJson.data.createAnnotation.id : responseJson.data.createCmAbstractPersistable ?
									responseJson.data.createCmAbstractPersistable.id : responseJson.data.updateCmAbstractPersistable ? 
									responseJson.data.updateCmAbstractPersistable.id : responseJson.data.createBatch ? responseJson.data.createBatch.id : null;
								results["properties"] = responseJson.data.createDocument ? responseJson.data.createDocument.properties : responseJson.data.checkinDocument ? 
									responseJson.data.checkinDocument.properties : responseJson.data.createAnnotation ? responseJson.data.createAnnotation.properties : 
									responseJson.data.cmAbstractPersistable ? responseJson.data.cmAbstractPersistable.properties : null;
								results["contentElements"] = responseJson.data.createDocument ? responseJson.data.createDocument.contentElements : responseJson.data.checkinDocument ?
									responseJson.data.checkinDocument.contentElements : responseJson.data.createAnnotation ? responseJson.data.createAnnotation.contentElements : null;
								results["repositoryRows"] = responseJson.data.repositoryRows ? responseJson.data.repositoryRows.repositoryRows : null;
								if (callback){
									callback(results);
								}
							}
						}
					}
					else {
						var error = {};
						error.errorText = xhr.statusText;
						error.errorCode = xhr.status;
						view._proto.raiseError(view, error);
						if (errback){
							errback(error);	
						}
					}
				};
					
				xhr.send(formData);
			},
			
			/**
			* @private
			*/
			raiseError: function(view, error){
				var message = error && error.errorText ? error.errorText : "The document could not be added";
				bpmext.ui.executeEventHandlingFunction(view, this.EVT_ONERROR, message);
			},
			
			/**
			* @private
			*/
			raiseSuccess: function(view, results){
				bpmext.ui.executeEventHandlingFunction(view, this.EVT_ONCONTENTADDED, results);
			},
			
			/**
			* @private
			*/
			_addDocuments: function(view, batchData){
				// If no uploads are in progress, generate a new CSRF token.
				if (view._instance.addsInProgress == 0){
					view._instance.uploadEcmTokenValue = this._getEcmToken(false);
				}
				
				var numFiles = batchData.classificationBatchCheckins ? batchData.classificationBatchCheckins.length : batchData.files.length;
				var limit = view._instance.maxConcurentAdds - view._instance.addsInProgress;
				limit = limit < 0 ? 0 : limit;
				limit = limit > numFiles ? numFiles : limit;
				for (var i = 0; i < limit; i++){
					batchData.classificationBatchCheckins ? view._proto._checkinClassificationBatchFromFile(view) : view._proto._addDocumentFromFile(view);					
				}				
			},
			
			/**
			* @private
			*/
			_convertJSONPropsToGraphql: function(jsonProperties){
				// Convert the JSON array of property name/value pairs into a string for graphql consumption.
				var graphqlProperties = "[";
				for (var i = 0; i < jsonProperties.length; i++){
					if (graphqlProperties.length > 1){
						graphqlProperties = graphqlProperties.concat(", ");
					}
					var jsonProperty = jsonProperties[i];
					var propertyName = Object.keys(jsonProperty)[0];
					var propertyValue = jsonProperty[propertyName];
					var graphqlPropertyValue;
					if (typeof propertyValue === 'string' || propertyValue instanceof String){
						graphqlPropertyValue = "\"" + propertyValue.replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/\t/g,'\\t').replace(/"/g,'\\"') + "\"";
					}
					else if (Array.isArray(propertyValue)){
						graphqlPropertyValue = "[";
						for (var j = 0; j < propertyValue.length; j++){
							if (graphqlPropertyValue.length > 1){
								graphqlPropertyValue = graphqlPropertyValue.concat(",");
							}
							var multiPropertyValue = propertyValue[j];
							var multiGraphqlPropertyValue;
							if (typeof multiPropertyValue === 'string' || multiPropertyValue instanceof String){
								multiGraphqlPropertyValue = "\"" + multiPropertyValue.replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/\t/g,'\\t').replace(/"/g,'\\"') + "\"";
							}
							else {
								multiGraphqlPropertyValue = multiPropertyValue;
							}
							graphqlPropertyValue  = graphqlPropertyValue.concat(multiGraphqlPropertyValue);
						}
						graphqlPropertyValue = graphqlPropertyValue.concat("]");
					}
					else {
						graphqlPropertyValue = propertyValue;
					}
					graphqlProperties = graphqlProperties.concat("{", propertyName, ": ", graphqlPropertyValue, "}");
				}
				graphqlProperties = graphqlProperties.concat("]");
				return graphqlProperties;
			},
			
			/**
			* @private
			*/
			_addClassProperties: function(view, classDescription){
				console.log("CS-UploadContent: _addClassProperties : ClassId: " + classDescription.symbolicName);
				var contentClass = {
					classPropertiesLookupById: {},
					classPropertiesLookupByName: {}
				}
				var propertyDescriptions = classDescription.propertyDescriptions.items ? classDescription.propertyDescriptions.items : classDescription.propertyDescriptions;
				for (var i = 0; i < propertyDescriptions.length; i++){
					var propertyDescription = propertyDescriptions[i];
					contentClass.classPropertiesLookupById[propertyDescription.id] = propertyDescription;
					contentClass.classPropertiesLookupByName[propertyDescription.symbolicName] = propertyDescription;
					if (propertyDescription.symbolicName == view._instance.controllerDocumentProperty || propertyDescription.id == view._instance.controllerDocumentProperty){
						view._instance.classificationDocumentClass = classDescription.symbolicName;
						view._instance.classificationControllerClass = propertyDescription.requiredClass.symbolicName;
					}
				}
				view._instance.classes[classDescription.symbolicName] = contentClass;		
			}
		}
	};
	
	/*
	* Public methods
	*/
	
	/**
	* Adds a document from a file.
	*
	* @param parentFolderId: ID of the parent folder for the new document	
	* @param files: Either a single file or filelist, normally obtained from a file input HTML control.
	* @param classId: The ID of the class.
	* @param properties: A JSON array of property name/value pairs.
	* @param callback: Function called when document is added successfully.
	* @param errback: Function called when an error occurs.
	*/
	this.constructor.prototype.uploadFile = function(parentFolderId, files, classId, properties, callback, errback){
		console.log("CS-UploadContent: uploadFile called");

		var graphQLProperties = this._proto._convertJSONPropsToGraphql(properties);
		var batchId = Date.now();
		var arrFiles = files.length ? Array.from(files) : [files];
		if (this._instance.progressIndicator){
			var clear = !(this._instance.addsInProgress > 0 || (this._instance.propertyPoller && this._instance.propertyPoller.isPolling()));
			this._instance.progressIndicator.displayFileUploadStatus(batchId, arrFiles, clear);
		}
		
		var batchData = {
			id: batchId,
			files:  arrFiles,
			parentFolderId: parentFolderId,
			classId: classId,
			properties: graphQLProperties,
			useFilenameForTitle: arrFiles.length > 1,
			errors: [],
			results: [],
			callback: callback,
			errback: errback,
			addsInProgress: 0,
			numFiles: arrFiles.length
		};
		this._instance.batchData.push(batchData);		
		this._proto._setupAdditionalProperties(this, batchData);
	};
	
	/**
	* Creates a new document using the root Document class. The document title of the new document is set to the file name.
	*
	* @param parentFolderId: ID of the parent folder for the new document
	* @param files: Either a single file or filelist, normally obtained from a file input HTML control.
	* @param callback: Function called when document is added successfully.
	* @param errback: Function called when an error occurs.
	*/
	this.constructor.prototype.uploadFileSimple = function(parentFolderId, files, callback,  errback){
		console.log("CS-UploadContent: uploadFileSimple called");
		this.uploadFileSimpleWithClass(parentFolderId, "Document", files, callback,  errback);
	};
	
	/**
	* 	Creates a new document from a file. The caller specifies the document class, but no class properties are set. The document title of the new document is set to the file name.
	*
	* @param parentFolderId: ID of the parent folder for the new document
	* @param files: Either a single file or filelist, normally obtained from a file input HTML control.
	* @param classId: The ID of the class.
	* @param callback: Function called when document is added successfully.
	* @param errback: Function called when an error occurs.
	*/
	this.constructor.prototype.uploadFileSimpleWithClass = function(parentFolderId, files, classId, callback,  errback){
		console.log("CS-UploadContent: uploadFileSimpleWithClass called");
		var properties;
		if (!files.length){
			// Single file.
			properties = [{DocumentTitle: files.name}];
		}
		else{
			// Filelist with single file.
			properties = [{DocumentTitle: files[0].name}];
		}
		this.uploadFile(parentFolderId, files, classId, properties, callback, errback);
	};
	
	/**
	* Checks in a new version of a previously checked out document using a file content source.
	*
	* @param documentId: The ID of the reservation.
	* @param file: The file object, normally obtained from a file input HTML control.
	* @param callback: Function called when version is checked in successfully.
	* @param errback: Function called when an error occurs.
	*/
	this.constructor.prototype.uploadNewVersionFromFile = function(documentId, file, callback, errback){	
		console.log("CS-UploadContent: uploadNewVersionFromFile called");
		this._proto._uploadNewVersionFromFile(this, documentId, file, callback, errback);
	};	
	
	/**
	* Adds a document from a non-file content source
	*
	* @param parentFolderId: ID of the parent folder for the new document
	* @param content: Content for the new document. May be either a ArrayBuffer, ArrayBufferView, Blob, or String.
	* @param fileName: The name of the content element that will be added to the version.
	* @param mimeType: Mime type of the new document
	* @param classId: The ID of the class.
	* @param properties:  A JSON array of property name/value pairs.
	* @param callback: Function called when document is added successfully.
	* @param errback: Function called when an error occurs.
	*/
	this.constructor.prototype.uploadFileFromData = function(parentFolderId, content, fileName, mimeType, classId, properties, callback, errback){
		console.log("CS-UploadContent: uploadFileFromData called");
		var file = this._proto._createFileFromData(content, fileName, mimeType);
		this.uploadFile(parentFolderId, file, classId, properties, callback, errback);
	};
	
	/**
	* Checks in a new version of a previously checked out document using a non-file content source.
	*
	* @param documentId: The ID of the reservation.
	* @param content: Content for the new version. May be either a ArrayBuffer, ArrayBufferView, Blob, or String.
	* @param fileName: The name of the content element that will be added to the new version.
	* @param mimeType: Mime type of the new version.
	* @param callback: Function called when version is checked in successfully.
	* @param errback: Function called when an error occurs.
	*/
	this.constructor.prototype.uploadNewVersionFromData = function(documentId, content, fileName, mimeType, callback, errback){
		console.log("CS-UploadContent: uploadNewVersionFromData called");
		var file = this._proto._createFileFromData(content, fileName, mimeType);
		this.uploadNewVersionFromFile(documentId, file, callback, errback);
	};
	
	/**
	* Checks in a new version of a document using a file content source. The document is not required to be in a checked out (reserved) state.
	* If the document is not reserved it will be checked out before adding the new version.
	*
	* @param documentId: The ID of the document or reservation.
	* @param file: The file object, normally obtained from a file input HTML control.
	* @param callback: Function called when version is checked in successfully.
	* @param errback: Function called when an error occurs.
	*/
	this.constructor.prototype.uploadNewVersionWithCheckoutFromFile = function(documentId, file, callback, errback){
		console.log("CS-UploadContent: uploadNewVersionWithCheckoutFromFile called");
		if (!this._instance.dependentPropertyInfo){
			this._instance.dependentPropertyInfo = {};
		}
		
		this._instance.dependentPropertyInfo[documentId] = {
			file: file,
			callback: callback,
			errback: errback
		}
		
		var contentItems = [];
		contentItems.push ({
			id: documentId
		});
		var params = {
			checkOutIn: true,
			pageSize: this._proto._pageSize,
			contentItems: contentItems,
			properties: [],
			ovpProperties: [],
			repository: this._instance.objectStoreName,
			serverAppResource: this._proto._appResource
		};
		this._proto._callService(this._instance.getDocumentsService, params, true);
	};
	
	/**
	* Checks in a new version of a document using a non-file content source. The document is not required to be in a checked out (reserved) state.
	* If the document is not reserved it will be checked out before adding the new version.
	*
	* @param documentId: The ID of the document or reservation.
	* @param content: Content for the new version. May be either a ArrayBuffer, ArrayBufferView, Blob, or String.
	* @param fileName: The name of the content element that will be added to the new version.
	* @param mimeType: Mime type of the new version.
	* @param callback: Function called when version is checked in successfully.
	* @param errback: Function called when an error occurs.
	*/
	this.constructor.prototype.uploadNewVersionWithCheckoutFromData = function(documentId, content, fileName, mimeType, callback, errback){
		console.log("CS-UploadContent: uploadNewVersionWithCheckoutFromData called");
		var file = this._proto._createFileFromData(content, fileName, mimeType);
		this.uploadNewVersionWithCheckoutFromFile(documentId, file, callback, errback);
	};

	/**
	* Checks in a new version of a file that is referenced by an object value property in another document from a file content source.
	*
	* @param documentId: The ID of the reservation.
	* @param dependentDocumentProperty: The symbolic name of the object value property that refers to the document that will be versioned.
	* @param file: The file object, normally obtained from a file input HTML control.
	* @param callback: Function called when document is checked in successfully.
	* @param errback: Function called when an error occurs.
	*/
	this.constructor.prototype.uploadNewDependentDocumentVersionFromFile = function(documentId, dependentDocumentProperty, file, callback, errback){
		console.log("CS-UploadContent: uploadNewDependentDocumentVersionFromFile called");
		if (!this._instance.dependentPropertyInfo){
			this._instance.dependentPropertyInfo = {};
		}
		
		this._instance.dependentPropertyInfo[documentId] = {
			dependentDocumentProperty: dependentDocumentProperty,
			file: file,
			callback: callback,
			errback: errback
		}
		
		var contentItems = [];
		contentItems.push ({
			id: documentId
		});
		var params = {
			pageSize: this._proto._pageSize,
			contentItems: contentItems,
			properties: [dependentDocumentProperty],
			ovpProperties: [],
			repository: this._instance.objectStoreName,
			serverAppResource: this._proto._appResource
		};
		this._proto._callService(this._instance.getDocumentsService, params, true);
	};
	
	/**
	* Checks in a new version of a file that is referenced by an object value property in another document from non-file content.
	*
	* @param documentId: The ID of the reservation.
	* @param dependentDocumentProperty: The symbolic name of the object value property that refers to the document that will be versioned.
	* @param content: Content for the new version. May be either a ArrayBuffer, ArrayBufferView, Blob, or String.
	* @param fileName: The name of the content element that will be added to the new version.
	* @param mimeType: Mime type of the new version.
	* @param callback: Function called when document is checked in successfully.
	* @param errback: Function called when an error occurs.
	*/
	this.constructor.prototype.uploadNewDependentDocumentVersionFromData = function(documentId, dependentDocumentProperty, content, fileName, mimeType, callback, errback){
		console.log("CS-UploadContent: uploadNewDependentDocumentVersionFromData called");
		var file = this._proto._createFileFromData(content, fileName, mimeType);
		this.uploadNewDependentDocumentVersionFromFile(documentId, dependentDocumentProperty, file, callback, errback);
	};
	
	/**
	* Adds an annotation to a document using a file as the content of the new annotation.
	*
	* @param documentId: The ID of the document to which the annotation will be added.
	* @param documentClassId: The symbolic name of the class of the document.
	* @param file: The file object, normally obtained from a file input HTML control.
	* @param annotationClassId: The annotation class symbolic name for the new annotation.
	* @param callback: Function called when document is checked in successfully.
	* @param errback: Function called when an error occurs.
	*/
	this.constructor.prototype.uploadAnnotationFromFile = function(documentId, documentClassId, file, annotationClassId, callback, errback){
		console.log("CS-UploadContent: uploadAnnotationFromFile called");
		this._proto._uploadAnnotationFromFile(this, documentId, documentClassId, file, annotationClassId, callback, errback);
	};
	
	/**
	* Adds an annotation to a document from a non-file content source.
	*
	* @param documentId: The ID of the document to which the annotation will be added.
	* @param documentClassId: The symbolic name of the class of the document.
	* @param content: Content for the new annotation. May be either a ArrayBuffer, ArrayBufferView, Blob, or String.
	* @param fileName: The name of the content element of the new annotation.
	* @param mimeType: Mime type of the new annotation.
	* @param annotationClassId: The annotation class symbolic name for the new annotation.
	* @param callback: Function called when document is checked in successfully.
	* @param errback: Function called when an error occurs.
	*/
	this.constructor.prototype.uploadAnnotationFromData = function(documentId, documentClassId, content, fileName, mimeType, annotationClassId, callback, errback){
		console.log("CS-UploadContent: uploadAnnotationFromData called");
		var file = this._proto._createFileFromData(content, fileName, mimeType);
		this.uploadAnnotationFromFile(documentId, documentClassId, file, annotationClassId, callback, errback);
	};
	
	/**
	* Adds a classification batch object with corresponding controllers and documents
	*
	* @param batchProperties: Property values that will be set on the classification batch object.
	* @param files: File objects, normally obtained from a file input HTML control.
	* @param documentClassId: The symbolic name of the document class that will be used to create document instances.
	* @param callback: Function called when document is checked in successfully.
	* @param errback: Function called when an error occurs.
	*/
	this.constructor.prototype.addClassificationBatch = function(batchProperties, files, documentClassId, callback, errback){
		console.log("CS-UploadContent: addClassificationBatch called");

		var batchId = Date.now();
		var arrFiles = files.length ? Array.from(files) : [files];
			
		var graphQLBatchProperties = this._proto._convertJSONPropsToGraphql(batchProperties);
		var graphQLBatchPropertiesString = graphQLBatchProperties.substring(0, graphQLBatchProperties.length - 1);
		graphQLBatchPropertiesString += (", {DbaBatchStatus: 210}, {DbaBatchDocumentCount: " + arrFiles.length + "}]");
	
		// Add the project id if present.
		var projectIdProperty = this._instance.additionalPropertiesOnAdd.find(property => property.propertyId == "DbaProjectId");	
		if (projectIdProperty){
			var batchPropertyString = graphQLBatchPropertiesString.substring(0, graphQLBatchPropertiesString.length - 1);
			graphQLBatchPropertiesString = batchPropertyString + ", {DbaProjectId: \"" + projectIdProperty.propertyValue + "\"}]";
		}
		
		var batchData = {
			id: batchId,
			files:  arrFiles,
			orderNo: 0,
			classId: documentClassId,
			batchProperties: graphQLBatchPropertiesString,
			properties: "[]",
			useFilenameForTitle: true,
			errors: [],
			results: [],
			callback: callback,
			errback: errback,
			addsInProgress: 0,
			numFiles: arrFiles.length,
			classificationBatchAction: this._proto.classificationBatchAction.CREATE_BATCH
		};
		this._instance.batchData.push(batchData);
		this._proto._setupAdditionalProperties(this, batchData);
	};
	
	/**
	* Appends documents to a classification batch.
	*
	* @param classificationBatchId: The id of the batch to which to append documents.
	* @param files: File objects, normally obtained from a file input HTML control.
	* @param documentClassId: The document class for the new documents.
	* @param callback: Function called when document is checked in successfully.
	* @param errback: Function called when an error occurs.
	*/
	this.constructor.prototype.appendDocumentsToClassificationBatch = function(classificationBatchId, files, documentClassId, callback, errback){
		console.log("CS-UploadContent: appendDocumentsToClassificationBatch called");

		var batchId = Date.now();
		var arrFiles = files.length ? Array.from(files) : [files];
		
		var batchData = {
			id: batchId,
			files:  arrFiles,
			classificationBatchId: classificationBatchId,
			classId: documentClassId,
			properties: "[]",
			useFilenameForTitle: true,
			errors: [],
			results: [],
			callback: callback,
			errback: errback,
			addsInProgress: 0,
			numFiles: arrFiles.length,
			classificationBatchAction: this._proto.classificationBatchAction.ADD_DOCUMENT
		};
		this._instance.batchData.push(batchData);
		this._proto._setupAdditionalProperties(this, batchData);
	};
	
	/**
	* Replaces a document in a classification batch.
	*
	* @param classificationBatchId: The id of the batch to which to append documents.
	* @param action: "replace", "insertAbove", or "insertBelow".
	* @param files: File object, normally obtained from a file input HTML control.
	* @param documentClassId: The document class for the new documents.
	* @param documentId: The id of the document in the batch to replace.
	* @param orderNumber: The order number on the document controller that will be replaced.
	* @param callback: Function called when document is checked in successfully.
	* @param errback: Function called when an error occurs.
	*/
	this.constructor.prototype.insertClassificationBatchDocument = function(classificationBatchId, action, files, documentClassId, documentId, orderNumber, callback, errback){
		console.log("CS-UploadContent: insertClassificationBatchDocument called");

		var batchId = Date.now();
		var arrFiles = files.length ? Array.from(files) : [files];
		
		var batchData = {
			id: batchId,
			files:  arrFiles,
			classificationBatchId: classificationBatchId,
			classId: documentClassId,
			properties: "[]",
			useFilenameForTitle: true,
			errors: [],
			results: [],
			callback: callback,
			errback: errback,
			addsInProgress: 0,
			numFiles: arrFiles.length,
			documentId: documentId,
			orderNumber, orderNumber,
			classificationBatchAction: action
		};
		this._instance.batchData.push(batchData);
		this._proto._setupAdditionalProperties(this, batchData);
	};
	
	/**
	* Sets a callback method that will be invoked when each document completes uploading.
	*/
	this.constructor.prototype.setDocumentUploadedCallback = function(callback){
		this._instance.documentUploadedCallback = callback;
	};
	
	/**
	* Sets a callback method that will be called after a batch object is added or modified.
	*/
	this.constructor.prototype.setBatchUpdatedCallback = function(callback){
		this._instance.batchUpdatedCallback = callback;
	};
	
	/**
	* Sets the name of the object store that will be used when making calls to the server.
	*/
	this.constructor.prototype.setObjectStoreName = function(objectStoreName){
		this._instance.objectStoreName = objectStoreName;
	};
	
	/**
	* Cancels a classification batch upload
	*/
	this.constructor.prototype.cancelClassificationBatchUpload = function(classificationBatchId){
		this._proto._cancelClassificationBatchUpload(this, classificationBatchId);
	}
	
	/**
	* Adds an additional property value that will be included when adding documents.
	*/
	this.constructor.prototype.addAdditionalPropertyOnAdd = function(additionalPropertyId, additionalPropertyValue){
		this._instance.additionalPropertiesOnAdd.push({
			propertyId: additionalPropertyId,
			propertyValue: additionalPropertyValue
		});
	};
	
	/**
	* Adds values to a JSON string that will be set in the specified property.
	*/
	this.constructor.prototype.addConfigValueOnAdd = function(configProperty, configId, configValue){
		this._instance.configurationProperty = configProperty;
		if (!this._instance.configurationValues){
			this._instance.configurationValues = {};
		}
		if (!this._instance.configurationValues[configProperty]){
			this._instance.configurationValues[configProperty] = {};
		}
		this._instance.configurationValues[configProperty][configId] = configValue;
	};
	
	/**
	* Sets the class properties that will be used when verifying the additional added properties set in addAdditionalPropertyOnAdd(). Class properties will be retrieved from the server
	* if this is not set.
	*/
	this.constructor.prototype.setClassProperties = function(classDescription){
		this._proto._addClassProperties(this, classDescription);
	};
	
	/**
	* Returns the maximum number of documents that may be added.
	*/
	this.constructor.prototype.getMaxAddsAvailable = function(){
		var pendingAdds = 0;
		for (var i = 0; i < this._instance.batchData.length; i++){
			pendingAdds += this._instance.batchData[i].files.length;
		}
		return this._instance.maxAddsAvailable - (pendingAdds + this._instance.addsInProgress);
	}
	
	/*
	* Private event handlers and methods
	*/
	this.constructor.prototype.setProgressIndicator = function(progressIndicator){
		this._instance.progressIndicator = progressIndicator;
	};
	
	this.constructor.prototype.setPropertyPoller = function(poller){
		this._instance.propertyPoller = poller;
	};
	
	this.constructor.prototype.setControllerDocumentProperty = function(controllerDocumentProperty){
		this._instance.controllerDocumentProperty = controllerDocumentProperty;
	};
	
	this.constructor.prototype.removeFileFromQueue = function(batchId, fileName){
		this._proto._removePendingFile(this, batchId, fileName);
	};
	
	this.constructor.prototype.isUploadingNewDocuments = function(){
		return this._instance.addsInProgress > 0;
	};
	
	this.constructor.prototype.getClassificationBatchPercentDone = function(batchId){
		var batchData = this._instance.batchData.find(batch => batch.classificationBatchId == batchId);
		if (!batchData){
			var batchData = this._instance.batchData.find(batch => batch.id == batchId);		
		}
		var percentDone = batchData ? this._proto._getClassificationBatchPercentDone(batchData) : 0;
		return(percentDone);
	};
	
	this.constructor.prototype.updateBatchStatus = function(classificationBatchId){
		var _this = this;
		this._proto._getBatchStatus(this, classificationBatchId, function(batchProperties){
			if (batchProperties.batchStatus == _this._proto.batchStatusPropertyValues.UPLOADING ||
				(batchProperties.batchStatus >= _this._proto.BATCH_STATUS_PROPERTY_VALUE_ERROR_LOWER_BOUNDARY &&
				batchProperties.batchStatus <= _this._proto.BATCH_STATUS_PROPERTY_VALUE_ERROR_UPPER_BOUNDARY)){

				var batchData = {
					classificationBatchId: classificationBatchId,
					originalBatchStatus: batchProperties.batchStatus
				};
				_this._proto._updateClassficationBatchCompleted(_this, batchData);
			}
		});
	};
	
	this.constructor.prototype._onGetDocumentsResults = function (view, results){
		if (results && results.results && results.results.items && results.results.items.length > 0){
			var item = results.results.items[0];
			var documentId = item.id;
			var dependentPropertyInfo = this._instance.dependentPropertyInfo[documentId];
			var properties = item.properties.items ? item.properties.items : item.properties;
			var parameters = this._instance.getDocumentsService.getInputData();
			var getVersionSeries = false;
			var versionSeriesId;
			if (parameters.checkOutIn){
				if (item.reservation){
					if (this._proto._isCurrentUserCheckout(view, item.reservation)) {
						this.uploadNewVersionFromFile(item.reservation.id, dependentPropertyInfo.file, dependentPropertyInfo.callback, dependentPropertyInfo.errback);
						delete this._instance.dependentPropertyInfo[documentId];
					}
					else {
						console.log("CS_UploadContent._onGetVersionSeriesResults:  Unable to upload new version. The document is checked out by another user.");
						this._proto.raiseError(this, messages.contlist_upload_failed);
					}
				}
				else {
					getVersionSeries = true;
					versionSeriesId = item.versionSeriesId;
				}
			}
			else{
				getVersionSeries = true;
				versionSeriesProperty = properties.find(property => property.id == dependentPropertyInfo.dependentDocumentProperty);
				versionSeriesId = versionSeriesProperty.value.identifier;		
			}
			
			if (getVersionSeries){
				var params = {
					documentId: documentId,
					versionSeriesId: versionSeriesId,
					repository: this._instance.objectStoreName,
					serverAppResource: this._proto._appResource
				};
				this._proto._callService(this._instance.getVersionSeriesService, params, true);
			}
		}
		else {
			console.log("CS_UploadContent._onGetDocumentsResults: Error getting document properties: " + JSON.stringify(results));
			this._proto.raiseError(this, messages.contlist_error_retrieving_doc_props);
		}
	};
	
	this.constructor.prototype._onGetDocumentsError = function (view, error){
		console.log("CS_UploadContent._onGetDocumentsError: Error getting document properties: " + JSON.stringify(error));
		this._proto.raiseError(this, messages.contlist_error_retrieving_doc_props);
	};
	
	this.constructor.prototype._onGetVersionSeriesResults = function(view, results){
		if (results && results.results && results.results.items && results.results.items.length > 0){
			var parameters = this._instance.getVersionSeriesService.getInputData();
			var versionSeries = results.results.items[0];
			if (versionSeries.reservation){
				if (this._proto._isCurrentUserCheckout(view, versionSeries.reservation)) {
					var dependentPropertyInfo = this._instance.dependentPropertyInfo[parameters.documentId];
					this.uploadNewVersionFromFile(versionSeries.reservation.id, dependentPropertyInfo.file, dependentPropertyInfo.callback, dependentPropertyInfo.errback);
					delete this._instance.dependentPropertyInfo[parameters.documentId];
				}
				else {
					console.log("CS_UploadContent._onGetVersionSeriesResults:  Unable to upload new version. The document is checked out by another user.");
					this._proto.raiseError(this, messages.contlist_upload_failed);
				}
			}
			else {
				var params = {
					originalDocId: parameters.documentId,
					documentId: versionSeries.currentVersion.id,
					repository: this._instance.objectStoreName,
					serverAppResource: this._proto._appResource
				};
				this._proto._callService(this._instance.checkoutDocumentService, params, true);
			}
		}
		else {
			console.log("CS_UploadContent._onGetVersionSeriesResults: Error getting version series: " + JSON.stringify(error));
			this._proto.raiseError(this, messages.contlist_error_retrieving_doc_props);
		}
	};
	
	this.constructor.prototype._onGetVersionSeriesError = function (view, error){
		console.log("CS_UploadContent._onGetVersionSeriesError: Error getting version series: " + JSON.stringify(error));
		this._proto.raiseError(this, messages.contlist_error_retrieving_doc_props);
	};
	
	this.constructor.prototype._onCheckoutDocumentResults = function (view, results){
		if (results && results.results && results.results.items && results.results.items.length > 0){
			var parameters = this._instance.checkoutDocumentService.getInputData();
			var reservation = results.results.items[0];
			var dependentPropertyInfo = this._instance.dependentPropertyInfo[parameters.originalDocId];
			this.uploadNewVersionFromFile(reservation.id, dependentPropertyInfo.file, dependentPropertyInfo.callback, dependentPropertyInfo.errback);
			delete this._instance.dependentPropertyInfo[parameters.originalDocId];
		}
		else {
			console.log("CS_UploadContent._onCheckoutDocumentResults: Error getting checking out document: " + JSON.stringify(results));
			this._proto.raiseError(this, messages.contlist_checkout_failed);
		}
	};
	
	this.constructor.prototype._onCheckoutDocumentError = function (view, error){
		console.log("CS_UploadContent._onCheckoutDocumentError: Error getting checking out document: " + JSON.stringify(error));
		this._proto.raiseError(this, messages.contlist_checkout_failed);
	};
	
	this.constructor.prototype._onClassDetailsResult = function (view, results){
		console.log("CS_UploadContent : _onClassDetailsResult: ClassId = " + results.symbolicName);
		var parameters = this._instance.classDetailsService.getInputData();
		this._proto._addClassProperties(this, results);
		if (this._instance.additionalPropertiesOnAdd != null && this._instance.additionalPropertiesOnAdd.length > 0){
			if (results.symbolicName == this._instance.classificationDocumentClass && 
				this._instance.classificationControllerClass && 
				!this._instance.classes[this._instance.classificationControllerClass]){
				
				// Get the controller class definition if we are adding additional properties.
				var params = {
					classId: this._instance.classificationControllerClass,
					repository: this._instance.objectStoreName,
					serverAppResource: this._proto._appResource,
					batchId: parameters.batchId
				}
				this._proto._callService(this._instance.classDetailsService, params, true);
			}
			else {
				this._proto._addAdditionalProperties(this, parameters.batchId);		
			}
		}
		else {
			var batchData = this._instance.batchData.find(batch => batch.id == parameters.batchId);
			this._proto._handleBatchType(this, batchData);
		}
	};
	
	this.constructor.prototype._onClassDetailsError = function (view, error){
		var logMessage = error && error.errorText ? error.errorText : messages.properties_class_not_found;
		console.log("CS-UploadContent : _onClassDetailsError : Error getting class details: " + logMessage);
		this._proto.raiseError(this, messages.properties_class_not_found);
	};
	
	this.constructor.prototype.load = function(){
		var opts = this.context.options;
		if (!opts.objectStoreName) {
            opts.objectStoreName = bpmext.ui.substituteConfigOption(this, "objectStoreName", null);
		}
		if (!this._instance.objectStoreName){
			this._instance.objectStoreName = opts.objectStoreName.get("value");
		}
		
		bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONERROR, "message");
		bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONCONTENTADDED, "results");
		bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONDOCUMENTADDED, "documentId");
		
		this._instance.classDetailsService = this.ui.get("GetClassDetails");
		this._instance.getDocumentsService = this.ui.get("GetDocuments");
		this._instance.getVersionSeriesService = this.ui.get("GetVersionSeries");
		this._instance.checkoutDocumentService = this.ui.get("CheckoutDocument");
		domStyle.set(this.context.element, "margin", 0);
		domStyle.set(this.context.element, "padding", 0);
	};
	
	this.constructor.prototype.change = function(event){
	};
}