/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019 - 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

cs_InitContentList = function (utilities, bpmext, domClass, domStyle, domAttr, domConstruct, dateLocale, dateStamp, Deferred, messages, string, connect, cookie)
{
	this._instance =
	{
		serverConfigurationName: "GRAPHQL_APP_RESOURCE",
		countLimit: "2000",
		totalCount: 0,
		loadMoreClicked: false,
		blockRefreshOnChange: false,
		breadcrumbLevel: 0,
		breadCrumbTrail: [],
		pageTokensLevel: [],
		rootFolder: null,
		_openDocumentWindows: {},
		inUpdateDocument: false,
		filterPropertyValues: []
	};

	if (!this.constructor.prototype._proto)
	{
		this.constructor.prototype._proto =
		{
			EVT_ONADD: "eventON_ADD",
			EVT_ONRESULT: "eventON_RESULT",
			EVT_ONFILECLICKED: "eventON_FILECLICKED",
			EVT_ONFOLDERCLICKED: "eventON_FOLDERCLICKED",
			EVT_ONROWSEL: "eventON_ROWSEL",
			EVT_ONERROR: "eventON_ERROR",
			EVT_ONCONTEXTMENUOPEN: "eventON_CONTEXTMENUOPEN",
			EVT_ONACTIONMENUOPEN: "eventON_ACTIONMENUOPEN",
			EVT_ONPOLLRESULTS: "eventON_POLLRESULTS",

			loadFolder: "Folder",
			loadSearch: "Search",
			loadDocuments: "Document",
			loadBatch: "Batch",
			MAP_DP2TYPE: {
				"DocumentTitle": "Text",
				"name": "Text",
				"MajorVersionNumber": "Integer",
				"LastModifier": "Text",
				"DateLastModified": "Date",
				"Creator": "Text",
				"DateCreated": "Date",
				"DateCheckedIn": "Date",
				"mimeType": "Text",
				"ContentSize": "Text",
				"IsReserved": "Text",
				"ClassName": "Text",
				"_thumbnail": "Image"
			},
			MAP_DP2LABEL: {
				"DocumentTitle": messages.contlist_column_spec_title,
				"name": messages.contlist_column_spec_name,
				"MajorVersionNumber": messages.contlist_column_spec_version_label,
				"LastModifier": messages.contlist_column_spec_modified_by,
				"DateLastModified": messages.contlist_column_spec_mod_date,
				"Creator": messages.contlist_column_spec_created_by,
				"DateCreated": messages.contlist_column_spec_creation_date,
				"mimeType": messages.contlist_column_spec_mime_type,
				"ContentSize": messages.contlist_column_spec_size,
				"IsReserved": "",
				"ClassName": messages.class_selector_class,
				"_thumbnail": messages.contlist_column_spec_thumbnail			
			},
			MAP_DP2CSS: {
				"DocumentTitle": "CS_tableRow",
				"name": "CS_tableRow",
				"Name": "CS_tableRow",
				"MajorVersionNumber": "CS_tableRow",
				"LastModifier": "CS_tableRow",
				"DateLastModified": "CS_tableRow",
				"Creator": "CS_tableRow",
				"DateCreated": "CS_tableRow",
				"mimeType": "CS_tableRow",
				"ContentSize": "CS_tableRow",
				"IsReserved": "CS_tableRow",
				"ClassName": "CS_tableRow",
				"_thumbnail": "CS_tableRow"
			},		
			MAP_DP2RENDERAS: {
				"DocumentTitle": "C",
				"name": "C",
				"Name": "C",
				"MajorVersionNumber": "H",
				"LastModifier": "H",
				"DateLastModified": "C",
				"Creator": "H",
				"DateCreated": "C",
				"mimeType": "H",
				"ContentSize": "C",
				"IsReserved": "H",
				"ClassName": "C"
			},
			hiddenDocumentProperties: [
				'Id',
				'DocId',
				'ContentElements',
				'reservation'
			],
			privilegeToBitmask: {
				"privEditProperties": 0x2,
				"privAddToFolder": 0x10,
				"privViewDoc": 0x80,
				"privDelete": 0x10000,
				"privMajorVersion": 0x4,
				"privMinorVersion": 0x40,
				"privAddItem": 0x100,
			},	
			mimeTypeToCssClass: {
				"": "ftNoContent",
				"item": "ftNoContent",
				"application/afp": "ftAfp",
				"application/vnd.ibm.afplinedata": "ftAfp",
				"application/pdf": "ftPdf",
				"text/plain": "ftPlain",
				"application/rtf": "ftPlain",
				"application/x-rtf": "ftPlain",
				"text/richtext": "ftPlain",
				"application/dca-rft": "ftPlain",
				"text/html": "ftWeb",
				"text/htm": "ftWeb",
				"application/x-compress": "ftCompressed",
				"application/x-compressed": "ftCompressed",
				"application/x-zip-compressed": "ftCompressed",
				"application/x-zip": "ftCompressed",
				"application/zip": "ftCompressed",
				"multipart/x-zip": "ftCompressed",
				"application/x-rar-compressed": "ftCompressed",
				"application/x-gzip": "ftCompressed",
				"text/xml": "ftCode",
				"application/xml": "ftCode",
				"application/x-vnd.oasis.opendocument.presentation": "ftPresentation",
				"application/vnd.ms-powerpoint": "ftPresentation",
				"application/vnd.lotus-freelance": "ftPresentation",
				"application/vnd.oasis.opendocument.presentation": "ftPresentation",
				"application/vnd.oasis.opendocument.presentation-template": "ftPresentation",
				"application/vnd.openxmlformats-officedocument.presentationml.presentation": "ftPresentation",
				"application/vnd.openxmlformats-officedocument.presentationml.slideshow": "ftPresentation",
				"application/vnd.openxmlformats-officedocument.presentationml.template": "ftPresentation",
				"application/vnd.ms-powerpoint.addin.macroEnabled.12": "ftPresentation",
				"application/vnd.ms-powerpoint.presentation.macroEnabled.12": "ftPresentation",
				"application/vnd.ms-powerpoint.slideshow.macroEnabled.12": "ftPresentation",
				"application/vnd.ms-powerpoint.template.macroEnabled.12": "ftPresentation",
				"application/x-mspowerpoint": "ftPresentation",
				"application/vnd.ms-infopath": "ftInfoPath",
				"application/line": "ftData",
				"application/x-vnd.oasis.opendocument.spreadsheet": "ftData",
				"application/vnd.ms-excel": "ftData",
				"application/vnd.ms-excel.addin.macroEnabled.12": "ftData",
				"application/vnd.ms-excel.sheet.binary.macroEnabled.12": "ftData",
				"application/vnd.ms-excel.sheet.macroEnabled.12": "ftData",
				"application/vnd.ms-excel.template.macroEnabled.12": "ftData",
				"application/vnd.lotus-1-2-3": "ftData",
				"application/vnd.openxmlformats-officedocument.spreadsheetml.template": "ftData",
				"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "ftData",
				"application/vnd.oasis.opendocument.spreadsheet": "ftData",
				"application/vnd.oasis.opendocument.spreadsheet-template": "ftData",
				"application/x-msexcel": "ftData",
				"text/csv": "ftData",
				"application/csv": "ftData",
				"application/x-vnd.oasis.opendocument.text": "ftWordProcessing",
				"application/msword": "ftWordProcessing",
				"application/vnd.lotus-wordpro": "ftWordProcessing",
				"application/wordperfect5.1": "ftWordProcessing",
				"application/vnd.oasis.opendocument.text": "ftWordProcessing",
				"application/vnd.oasis.opendocument.text-template": "ftWordProcessing",
				"application/vnd.openxmlformats-officedocument.wordprocessingml.document": "ftWordProcessing",
				"application/vnd.openxmlformats-officedocument.wordprocessingml.template": "ftWordProcessing",
				"application/vnd.ms-word.template.macroEnabled.12": "ftWordProcessing",
				"application/vnd.ms-word.document.macroEnabled.12": "ftWordProcessing",
				"application/x-msword": "ftWordProcessing",
				"application/x-filenet-searchtemplate": "ftSearchTemplate",
				"application/x-searchtemplate": "ftSearchTemplate",
				"application/x-searchtemplate.automatic": "ftSearchStored",
				"application/x-filenet-search": "ftSearchStored",
				"application/x-unifiedsearchtemplate": "ftUnifiedSearch",
				"application/x-icn-documententrytemplate": "ftIcnDocumentEntryTemplate",
				"application/x-icn-folderentrytemplate": "ftIcnFolderEntryTemplate",
				"application/x-filenet-external": "ftExternalFile",
				"application/x-box-web-link": "ftExternalFile",
				"application/csbundled": "ftMail",
				"message/rfc822": "ftMail",
				"application/iccxit": "ftMail",
				"application/x-filenet-filetype-msg": "ftMail",
				"application/icccsn": "ftNotesMail",
				"application/vnd.ms-outlook": "ftOutlookMail",
				"application/x-box-note": "ftBoxNote",
				"application/vnd.google-apps.document": "ftGdoc",
				"application/vnd.google-apps.spreadsheet": "ftGsheet",
				"application/vnd.visio": "ftWordProcessing",
				"application/visio": "ftWordProcessing",
				"application/x-visio": "ftWordProcessing",
				"application/vnd.ms-project": "ftWordProcessing",
				"application/msproject": "ftWordProcessing",
				"application/x-project": "ftWordProcessing"
			},
			actions: {
				checkoutDocument: "CheckoutDocument",
				uploadVersion: "UploadVersion",
				editDocument: "EditDocument",
				cancelCheckout: "CancelCheckout",
				renameFolder: "RenameFolder",
				createFolder: "CreateFolder",
				deleteDocument: "DeleteDocument",
				deleteFolder: "DeleteFolder",
				deleteAbstract: "DeleteAbstract",
				addDocument: "AddDocument",
				addFolder: "AddFolder",
				documentProperties: "DocumentProperties",			
				folderProperties: "FolderProperties",
				abstractProperties: "AbstractProperties",
			},
			SIZE_UNITS: [
				messages.contlist_size_units_B, 
				messages.contlist_size_units_KB, 
				messages.contlist_size_units_MB, 
				messages.contlist_size_units_GB, 
				messages.contlist_size_units_TB
			],
			defaultDatePattern: "MM/dd/yyyy",  // Default date format when displayed as column properties 
			defaultDateTimePattern: "MM/dd/yyyy, hh:mm a", // Default date time format when displayed as column properties 
			typeDocument: "Document",
			typeFolder: "Folder",
			typeAbstract: "Abstract",
			
			DbaBatchStatusUploading: 220,
			
			_handleVisibility: function (view) {
				var vis = utilities.handleVisibility(view.context);
			},
			
			_setVisibilityOfControl: function (control, vis) {
				control.context.options["_metadata"].visibility.set("value", vis);
				control.context.setDisplay(vis != "NONE");
				control.context.setVisibility(vis != "HIDDEN");
			},
			
			_setAlertMessage: function(view, message, isError, delay) {
				var title = messages.contlist_progress_success;
				var style = "S";
				if (isError) {
					title = messages.contlist_progress_alert;
					style = "D";
				}
				// Call out to the CS_Alert utility class to handle displaying the alert message
				setAlertMessage(title, message, style, delay, domClass, domStyle, domAttr, messages);
			},
			
			_setModalAlertMessage: function(view, modalAlert, modalAlertId, message, isError, delay) {
				var title = messages.contlist_progress_success;
				var style = "S";
				if (isError) {
					title = messages.contlist_progress_alert;
					style = "D";
				}
				// Call out to the CS_Alert utility class to handle displaying the alert message
				var alertDiv = setAlertMessage(title, message, style, delay, domClass, domStyle, domAttr, messages);
				
				setTimeout(function(){
					alertDiv.scrollIntoView(true);
				}, 300);	
			},
			
			_getType: function(contentItem) {
				var type;
				if (contentItem.baseType) {
					type = contentItem.baseType;
				} else if (contentItem.isFolder) {
					type = this.typeFolder;
				} else {
					type = this.typeDocument;
				}
				return type;
			},
			
			_getUserId: function(view) {
				var userId = view._instance.userId;
				if (userId == null) {
					// Todo: Currently, no way of getting logged in user information from UMS, temporary work around
					var navUrl = window.location.href;
					var params = navUrl.split("&");
					for (var i = 0; i < params.length; i++) {
						var param = params[i].split("=");
						if (param[0] == "userId") {
							userId = decodeURIComponent(param[1]);
							view._instance.userId = userId;
							break;
						}
					}
				}
				return userId;
			},
			
			_getMimeCssClass: function(contentItem) {
				var cssClass;
				var mimeType = contentItem.mimeType;
				if (this._getType(contentItem) == this.typeFolder) {
					cssClass = "ftFolderClosed";
				} else if (this._getType(contentItem) == this.typeAbstract) {
					cssClass = "ftBatch";
				} else {
					cssClass = this.mimeTypeToCssClass[mimeType];
					if (!cssClass) {
						if (mimeType == null || mimeType == "" || mimeType == "item") {
							cssClass = "ftNoContent";
						} else if (mimeType.substr(0, "audio/".length) == "audio/") {
							cssClass = this.mimeTypeToCssClass["audio/*"] || "ftAudio";
						} else if (mimeType.substr(0, "image/".length) == "image/") {
							cssClass = this.mimeTypeToCssClass["image/*"] || "ftGraphic";
						} else if (mimeType.substr(0, "video/".length) == "video/") {
							cssClass = this.mimeTypeToCssClass["video/*"] || "ftVideo";
						} else if (mimeType == "teamspace" || mimeType == "Teamspace") {
							cssClass = "ecmTeamspaceIcon";
						} else if (mimeType == "application/x-unifiedsearchtemplate") {
							cssClass = "ftUnifiedSearch";
						} else if (mimeType == "application/x-icn-documententrytemplate") {
							cssClass = "ftIcnDocumentEntryTemplate";
						} else if (mimeType == "application/x-icn-folderentrytemplate") {
							cssClass = "ftIcnFolderEntryTemplate";
						} else {
							cssClass = "ftDefault";
						}
					}
				}
				return cssClass;
			},

			_setHeight: function(view, height) {
				try {
					if (height == null || height == "") {
						height = "auto";
					}
					if (!isNaN(height)) {
						height += "px";
					}
					view.context.element.style.height = height;
				} catch (e) {
					bpmext.log.error("CSContentList._setHeight() error: " + e);
					if (e.stack) {
						bpmext.log.error("  Call stack: " + e.stack);
					}
				}
			},
			
			_setWidth: function(view, width) {
				try {
					if (width == null || width == "") {
						width = "auto";
					}
					if (!isNaN(width)) {
						width += "px";
					}
					view.context.element.style.width = width;
				} catch (e) {
					bpmext.log.error("CSContentList._setWidth() error: " + e);
					if (e.stack) {
						bpmext.log.error("  Call stack: " + e.stack);
					}
				}
			},
			
			_formatSize: function(bytes, precision) {
				if (bytes == 0) {
					return "0 " + this.SIZE_UNITS[0];
				}

				if (typeof precision == "undefined")	{
					precision = 0;
				}

				var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
				var res = bytes / Math.pow(1024, i);
				if (i < 2) {
					precision = 0; // For B and KB, no decimal precision
				}
				return Number(res).toFixed(precision) + " " + this.SIZE_UNITS[i];
			},
			
			_findProperty: function(contentItem, propertyId) {
				var properties;
				if (contentItem.properties.items) {
					properties = contentItem.properties.items;
				} else { 
					properties = contentItem.properties;
				}
				var value = null;
				for (var i = 0; i < properties.length; i++) {
					var property = properties[i];
					if (property.id == propertyId) {
						value = property.value;
						break;
					}
				}
				return value;			
			},
			
			/**
			 * Helper function to retrieve the Object Store Name as defined in ACCE admin tool. This is the 
			 * string that will be passed to all the graphql action services since it's working against CE
			 * and not ICN).
			 */
			_getObjectStoreName: function(view) {
				var objectStoreName = view.context.options.objectStoreName.get("value");
				return objectStoreName;
			},
	
			/**
			 * Helper function to retrieve the column Sort Property as defined in configuration settings. This is the 
			 * string that will be passed to all the graphql action services that retrieve result set information.
			 */
			_getColumnSortProperty: function(view) {
				var sortProperty = view._instance.sortProperty;
				if (sortProperty == null || sortProperty == "") {
					sortProperty = view.context.options.sortProperty.get("value");
				}
				return sortProperty;
			},

			/**
			 * Helper function to retrieve the column Sort Order (ASC | DESC) as defined in configuration settings. This is the 
			 * string that will be passed to all the graphql action services that retrieve result set information.
			 */
			_getColumnSortOrder: function(view) {
				var sortOrder = view._instance.sortOrder;
				if (sortOrder == null || sortOrder == "") {
					sortOrder = view.context.options.sortOrder.get("value");
				}
				return sortOrder;
			},

			_getPageSize: function(view) {
				var pageSize = view.context.options.initialPageSize.get("value");
				if (pageSize == null || pageSize == "") {
					pageSize = 20;
				}
				return pageSize;
			},
			
			_getObjectPropertyId: function(propertyId, objectPropertyId) {
				// Create a two part column property id to handle object value properties as column properties
				var id = propertyId + "." + objectPropertyId;
				return id;
			},
			
			_getColumnProperties: function(view) {
				// These properties are required for the list view to render state and mime columns (also know when an object is a folder)
				var requiredProperties = ["Name", "MimeType", "IsReserved", "PathName"];
				
				// See if a custom state property has been set in the configuration options
				var stateProperty = view.context.options.stateProperty.get("value");
				if (stateProperty != null) {
					requiredProperties.push(stateProperty);
				}

				// See if there are any "extra" properties specified in the config settings and add them if there are
				var extraProperties = view.context.options.extraProperties.get("value");
				if (extraProperties != null) {
					var properties = extraProperties.items ? extraProperties.items : extraProperties;
					for (var i = 0; i < properties.length; i++) {
						var property = properties[i];
						requiredProperties.push(property.primary);
					}
				}				
				
				var columnProperties = [];
				
				// Get the list of properties defined for the list view columns
				var columnSpecs = view._instance._columnSpecs;
				columnSpecs.forEach(function(columnSpec) {
					// Create an array of property ids to be used in api call to return proper set of data
					if (columnSpec.dataElementName != "_contextMenuButton" && columnSpec.dataElementName != "ClassName") {
						if (columnSpec.type != "Object") {
							if (columnProperties.indexOf(columnSpec.dataElementName) == -1) {
								columnProperties.push(columnSpec.dataElementName);
							}
						} else {
							var index = columnSpec.dataElementName.indexOf(".");
							var propertyName = columnSpec.dataElementName.slice(0, index);
							if (columnProperties.indexOf(propertyName) == -1) {
								columnProperties.push(propertyName);
							}
						}
					}
				});
		
				// Add the required properties to the list (if they are not already there)
				requiredProperties.forEach(function(property) {
					if (columnProperties.indexOf(property) == -1) {
						columnProperties.push(property);
					}
				});
				return columnProperties;
			},

			_getColumnObjectProperties: function(view) {
				var columnObjectProperties = [];
				// Get the list of properties defined for the list view columns
				var columnSpecs = view._instance._columnSpecs;
				columnSpecs.forEach(function(columnSpec) {
					// Create an array of property ids to be used in api call to return proper set of data
					if (columnSpec.dataElementName != "_contextMenuButton" && columnSpec.dataElementName != "ClassName") {
						if (columnSpec.options.ovpProperty) {
							columnObjectProperties.push(columnSpec.options.ovpProperty);
						}
					}
				});
				
				// State property is an object value property... need to make sure and retrieve it
				var stateSecondaryProperty = view.context.options.stateSecondaryProperty.get("value");
				if (stateSecondaryProperty != null) {
					if (columnObjectProperties.indexOf(stateSecondaryProperty) == -1) {
						columnObjectProperties.push(stateSecondaryProperty);
					}
				}
						
				// See if there are any "extra" properties that are secondary specified in the config settings and add them if there are
				var extraProperties = view.context.options.extraProperties.get("value");
				if (extraProperties != null) {
					var properties = extraProperties.items ? extraProperties.items : extraProperties;
					for (var i = 0; i < properties.length; i++) {
						var property = properties[i];
						if (property.secondary) {
							if (columnObjectProperties.indexOf(property.secondary) == -1) {
								columnObjectProperties.push(property.secondary);
							}
						}
					}
				}				
				return columnObjectProperties;
			},
	
			_getColumnType: function(propertyDef) {
				var columnType = "Text";
				if (propertyDef) {
					columnType = this.MAP_DP2TYPE[propertyDef.id];
					if (!columnType) {
						if (propertyDef.cardinality === "multi") {
							columnType = "Text";
						} else {
							switch (propertyDef.type) {
								case "STRING":
									columnType = "Text";
									break;
								case "DATE_TIME":
									columnType = "Date";
									break;
								case "FLOAT":
									columnType = "Decimal";
									break;
								case "INTEGER":
									columnType = "Integer";
									break;
								default:
									columnType = "Text";
									break;
							}
						}
					}
				}
				return columnType;
			},
			
			_getColumnRenderAs: function(propertyDef) {
				return propertyDef && this.MAP_DP2RENDERAS[propertyDef.id] ? this.MAP_DP2RENDERAS[propertyDef.id] : "C";
			},
			
			_getColumnLabel: function(propertyDef, id) {
				return propertyDef && this.MAP_DP2LABEL[propertyDef.id] ? this.MAP_DP2LABEL[propertyDef.id] : (propertyDef && propertyDef.label) || id;
			},
			
			_getColumnVisibility: function(propertyDef) {
				return propertyDef && this.hiddenDocumentProperties.indexOf(propertyDef.id) == -1;
			},

			_loadColumns: function(view, columns) {
				// Get the columns whether specified in config or defaults
				view._instance._columnSpecs = this._getColumnSpecs(view, columns);
				
				// Create column spec hash for faster access later on when rendering column items in each row
				view._instance._columnSpecsHash = {};
				view._instance._columnSpecs.forEach(function(columnSpec) {
					view._instance._columnSpecsHash[columnSpec.dataElementName] = columnSpec;
				});

				// Need to add the last column for context menu button
				view._instance._columnSpecs.push({
					visibility: true,
					sortable: false,
					dataElementName: "_contextMenuButton",
					label: "",
					css: "CS_tableRow CS_ctxMenu",
					renderAs: "C"
				});

				// Set the column specification on to the Control-Table
				view._instance.contentTable.setColumns(view._instance._columnSpecs);
			},
	
			_getColumnSpecs: function(view, columns) {
				var columnSpecs = [];
				var searchResult = null;
				var includeTime = view.context.options.includeTimeInDates.get("value");
				var nlResources = view.context.options.nlResources.get("value");
							
				// If pulling column properties out of search results
				if (searchResult) {
					var columnItems = searchResult.items[0].properties.items;  // Grabbing property collection from first item
					for (var i = 0; i < columnItems.length; i++) {
						var propertyDef = columnItems[i];
						
						var label = null;
						if (nlResources) {
							label = nlResources[propertyDef.id];
						}
						if (label == null) {
							label = this._getColumnLabel(propertyDef);
						}
						
						var colSpec = {
							visibility: this._getColumnVisibility(propertyDef),
							sortable: true,
							dataElementName: propertyDef.id,
							label: label,
							type: this._getColumnType(propertyDef),
							renderAs: this._getColumnRenderAs(propertyDef)
						};
						
						if (i == 0) {
							colSpec.width = "250px";  // Make main column usually name column wider
						}
						
						if (colSpec.type === "Date") {
							colSpec.options = {
								datePattern: includeTime ? this.defaultDateTimePattern : this.defaultDatePattern
							};
						}

						columnSpecs.push(colSpec);
					}
				}

				// If defined columns at author time, use options to define columns
				if (columnSpecs.length == 0) {
					var cspecs;
					if (columns != null) {
						cspecs = columns; // Columns passed in from the 
					} else {
						cspecs = view.context.options.columns;
						if (cspecs != null) {
							cspecs = cspecs.get("value");
						}
					}
					
					if (cspecs != null) {
						cspecs = cspecs.items;

						for (var i = 0; i < cspecs.length; i++) {
							var cspec = cspecs[i];
							var id = cspec.id;

							var renderAs = "C"; 
							// First column (main column) is Custom rendered for state and mime type
							if (i > 0) {
								renderAs = this._getColumnRenderAs(cspec);
							}

							var css = cspec.css;
							if (css == null || css == "") {
								css = this.MAP_DP2CSS[id];
								if (css == null || css == "") {
									css = "CS_tableRow";  // Default if no css class
								}
							}
							
							// First column and if no width specified, set main name column min width to 250
							if (i == 0) {
								if (cspec.width == null || cspec.width == "") {
									css += " CS_tableMainName";
								}
							}
							
							var type = this._getColumnType(cspec);
							
							// Look to see if the column property has a object value property defined, if so change the column id to include to ovp id
							var propId = id;
							var options = null;
							if (cspec.options) {
								// Note: options value will be entered as "ovpProperty": "SymbolicName"
								options = "{" + cspec.options + "}";
								options = JSON.parse(options);
								if (options.ovpProperty) {
									propId = this._getObjectPropertyId(id, options.ovpProperty);
									type = "Object";
								}
							}

							var label = null;
							if (nlResources) {
								if (options && options.ovpProperty) {
									label = nlResources[id + "_" + options.ovpProperty];
								} else {
									label = nlResources[id];
								}
							}
							if (label == null) {
								label = (cspec.label == null || cspec.label == "") ? this._getColumnLabel(cspec, propId) : cspec.label;
							}
													
							var colSpec = {
								width: cspec.width,
								visibility: this._getColumnVisibility(cspec),
								sortable: cspec.sortable,
								css: css,
								dataElementName: propId,
								type: type,
								label: label,
								renderAs: renderAs,
								options: (cspec.options != null && cspec.options != "") ? cspec.options : null
							}
							// Note: for options entered in UI at design time, need to make sure the key has quotes around it as well as value
							// Eg: "datePattern": "MM/dd/yyyy" or "MM/dd/yyyy hh:mm a"

							columnSpecs.push(colSpec);
						}
					}
				}

				// If no columns found yet (from above attempts), use default set
				if (columnSpecs.length == 0) {
					var searchFor = view.context.options.searchFor.get("value");
					if (searchFor == null || searchFor == this.typeDocument || searchFor == this.typeFolder) {
						this._addDefaultColumnSpec(true, true, "name", null, columnSpecs);
						this._addDefaultColumnSpec(true, true, "ContentSize", null, columnSpecs);
						this._addDefaultColumnSpec(true, true, "LastModifier", null, columnSpecs);
						this._addDefaultColumnSpec(true, true, "DateLastModified", {datePattern: includeTime ? this.defaultDateTimePattern : this.defaultDatePattern}, columnSpecs);
						this._addDefaultColumnSpec(true, true, "MajorVersionNumber", null, columnSpecs);
					} else { // Abstract Objects
						this._addDefaultColumnSpec(true, true, "name", null, columnSpecs);
						this._addDefaultColumnSpec(true, true, "LastModifier", null, columnSpecs);
						this._addDefaultColumnSpec(true, true, "DateLastModified", {datePattern: includeTime ? this.defaultDateTimePattern : this.defaultDatePattern}, columnSpecs);
					}
				}
				
				return columnSpecs;
			},

			_addDefaultColumnSpec: function(visibility, sortable, name, options, columnSpecs) {
				var columnSpec = {
					visibility: visibility,
					sortable: sortable,
					dataElementName: name,
					label: this.MAP_DP2LABEL[name],
					css: columnSpecs.length == 0 ? this.MAP_DP2CSS[name] + " CS_tableMainName" : this.MAP_DP2CSS[name],
					type: this.MAP_DP2TYPE[name],
					renderAs: this.MAP_DP2RENDERAS[name]
				};
				if (options) {
					columnSpec.options = options;
				}
				columnSpecs.push(columnSpec);
			},
			
			_refresh: function(view, sortProperty, sortOrder) {
				console.log("CS-ContentList:_refresh() : called.");
				view._instance.addBreadcrumbItem = false;
				
				var refreshIconBtn = view.ui.get("RefreshImage");
				refreshIconBtn.setEnabled(false);

				if (view._instance.refreshing) {
					console.log("CS-ContentList:_refresh() : Currently refreshing, refresh items blocked");
					return;
				}
				view._instance.refreshing = true; // blocks clicking same button multiple times

				// clear old results in case we have an error so we don't leave stale data.
				if (view._instance.contentTable && view._instance.contentTable._instance.list != null) {
					view._instance.contentTable.clear();
//					view._instance.contentTable.refresh(true);
				}

				if (view._instance.folderId != null || view._instance.contentItems != null) {
					// If in browse mode, clear the filter on a refresh?
					if (view._instance.explorerFilterText && view._instance.explorerFilterText.getText() != '') {
						view._instance.contentTable.clearSearch();
						view._instance.explorerFilterText.setText("");
					}
				}

        		if (!view._instance.serverConfigurationName || view._instance.serverConfigurationName == null) {
           		    bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR,  messages.contlist_missing_server_error);
             		return;
       			}

				// Check to see if any content items are specified, followed by folder Id, then finally search
				if (view._instance.contentItems != null) {
					var contentItems;
					if (view._instance.contentItems.items) {
						contentItems = view._instance.contentItems.items;
					} else { 
						contentItems = view._instance.contentItems;
					}
					this._getDocuments(view, contentItems, sortProperty, sortOrder);
				} else if (view._instance.folderId != null) {
					var folderId = view._instance.folderId;
					var currentFolder = view._instance.currentParentFolder;
					if (currentFolder != null) {
						folderId = currentFolder.id;
					}
					this._getFolderContainees(view, folderId, sortProperty, sortOrder);
				} else {
					// If we are in search mode, but navigating folders, use get folder containees (unless it's the fake root)
					var currentFolder = view._instance.currentParentFolder;
					if (currentFolder != null && currentFolder.id != "__id_Results") {
						this._getFolderContainees(view, currentFolder.id, sortProperty, sortOrder);
					} else if (view._instance.loadType == this.loadBatch && view._instance.currentBatch) {
						this._getBatchDocuments(view, view._instance.currentBatch);
					} else {
						var searchValue = view._instance.searchValue;
						this._getSearchResults(view, searchValue, sortProperty, sortOrder, view._instance.searchValues);
					}
				}
			},
		
			_callService: function(service, params, setInputData) {
				// Create ecm token as a large random number
				var ecmToken = Math.floor(Math.random() * 10000000);
				console.log("CS-ContentList:_callService() : " + service.context.viewid + ", Ecm token: " + ecmToken);

				// Add the required token value to the service params
				params.ecmToken = ecmToken;
				if (setInputData) {
					service.setInputData(params);
					service.execute();
				} else {
					service.execute(params);
				}
			},

			_getDocuments: function(view, contentItems, sortProperty, sortOrder) {
				if (contentItems && contentItems.length > 0) {
					// See if there has been a order by property specified in the config settings
					if (sortProperty == null || sortProperty == "") {
						sortProperty = this._getColumnSortProperty(view);
					}
					var documentSortProperty = sortProperty;
					if (sortProperty == "Name" || sortProperty == "name") {
						documentSortProperty = "DocumentTitle";
					}
					if (sortOrder == null || sortOrder == "") {
						sortOrder = this._getColumnSortOrder(view);
					}

					var params = {
						pageSize: this._getPageSize(view),
						countLimit: view._instance.countLimit,
						contentItems: contentItems,
						orderByProperty: documentSortProperty,
						order: sortOrder,
						properties: this._getColumnProperties(view),
						repository: this._getObjectStoreName(view),
						serverAppResource: view._instance.serverConfigurationName
					};
					console.log("CS-ContentList:_getDocuments() : Retrieving documents in list.");
					view._instance.documentsSvc = view.ui.get("DocumentsSvc");
					this._callService(view._instance.documentsSvc, params);
				} else {
					// List is cleared of previous items in the refresh function
					console.log("CS-ContentList:_getDocuments() : No items in the document list to retrieve.");
					view._setPagingInstanceData(null, 0, true);
					view._setPagingTextData(0, 0, 0);
				}
			},
			
			_getMoreDocuments: function(view, newPageNumber, token) {
				var params = {
					newPageNumber: newPageNumber,
					token: token,
					properties: this._getColumnProperties(view),
					serverAppResource: view._instance.serverConfigurationName
				};
				view._instance.moreDocumentsSvc = view.ui.get("MoreDocumentSvc");
				this._callService(view._instance.moreDocumentsSvc, params);
			},
			
			_updateDocument: function(view, contentItem, update) {
				// Need to get the properties first, then refresh the table row
				var properties = this._getColumnProperties(view);
				var ovpProperties = this._getColumnObjectProperties(view);
				
				var params = {
					objectId: contentItem.id,
					objectType: view._proto.typeDocument,
					classId: contentItem.className,
					properties: properties,
					ovpProperties: ovpProperties,
					update: update,
					repository: view._proto._getObjectStoreName(view),
					serverAppResource: view._instance.serverConfigurationName
				};
				
				console.log("CS-ContentList:_updateDocument() : Retrieving document properties.");
				view._instance.getPropertiesSvc = view.ui.get("GetPropertiesSvc");
				this._callService(view._instance.getPropertiesSvc, params, true);
			},
			
			_getBatchDocuments: function(view, contentItem) {
				var properties = this._getColumnProperties(view);
				properties = properties.filter(property => property != "PathName"); // remove PathName if it exists
				properties.push("Id");  // Not normally a column property
				properties.push("ContentElements");  // Not normally a column property
				properties.push("Reservation");
				properties.push("VersionSeries");
				
				var batchOrderBy = "DbaBatchOrder"; // Special property for the query results order
				var controllerProperties = [];
				controllerProperties.push(batchOrderBy);

				var propIssues = properties.find(property => property == "DbaIssues");
				if (propIssues) {
					properties = properties.filter(property => property != "DbaIssues"); // Pseudo property, can not be queried on
					controllerProperties.push("DbaVerificationWarningCount");
					controllerProperties.push("DbaVerificationErrorCount");
					controllerProperties.push("DbaCaptureError");
				}

				var ovpProperties = this._getColumnObjectProperties(view);
				ovpProperties.push("Creator");
				
				var searchParams = [];
				searchParams.push({
					name: "DbaBatchController",
					operator: "=",
					value: contentItem.id
				});

				var params = {
					pageSize: this._getPageSize(view),
					countLimit: view._instance.countLimit,
					documentBaseType: "DbaCaptureBase",
					controllerType: "DbaClassificationController",
					batchType: "DbaBatchController",
					batchOrderBy: batchOrderBy,
					order: "ASC",
					searchParams: searchParams,
					properties: properties,
					controllerProperties: controllerProperties,
					ovpProperties: ovpProperties,
					repository: this._getObjectStoreName(view),
					serverAppResource: view._instance.serverConfigurationName
				};
				console.log("CS-ContentList:_getBatchDocuments() : Retrieving batch objects in list.");
				view._instance.batchDocumentsSvc = view.ui.get("BatchDocumentsSvc");
				this._callService(view._instance.batchDocumentsSvc, params);
			},
	
			_getMoreBatchDocuments: function(view, newPageNumber, token) {
				var ovpProperties = this._getColumnObjectProperties(view);
				var batchId = null;
				if (view._instance.currentBatch) {
					batchId = view._instance.currentBatch.id;
				}
				var params = {
					newPageNumber: newPageNumber,
					token: token,
					documentBaseType: "DbaCaptureBase",
					ovpProperties: ovpProperties,
					batchId: batchId,
					repository: this._getObjectStoreName(view),
					serverAppResource: view._instance.serverConfigurationName
				};
				view._instance.moreBatchDocumentsSvc = view.ui.get("MoreBatchDocumentsSvc");
				this._callService(view._instance.moreBatchDocumentsSvc, params);
			},
			
			_updateBatch: function(view, contentItem) {
				// Need to get the batch properties first, then refresh the table row
				var properties = [
					"DbaDisplayName", 
					"DbaBatchDocumentCount", 
					"DbaBatchPriority", 
					"DbaBatchStatus", 
					"DateCreated", 
					"Creator", 
					"DbaBatchGroup", 
					"DbaBatchLocation", 
					"Name", 
					"MimeType", 
					"IsReserved", 
					"PathName", 
					"DbaLeaseTime", 
					"LastModifier", 
					"DbaBatchError"
				];
				
				var params = {
					objectId: contentItem.id,
					objectType: view._proto.typeAbstract,
					classId: "DbaClassificationBatch",
					properties: properties,
					update: "batch",
					repository: view._proto._getObjectStoreName(view),
					serverAppResource: view._instance.serverConfigurationName
				};
				
				view._instance.getPropertiesSvc = view.ui.get("GetPropertiesSvc");
				this._callService(view._instance.getPropertiesSvc, params);
			},

			_updateBatchDocument: function(view, contentItem) {
				// Need to get the batch document properties first, then refresh the table row
				var properties = this._getColumnProperties(view);
				properties = properties.filter(property => property != "PathName"); // remove PathName if it exists
				properties.push("Id");  // Not normally a column property
				properties.push("ContentElements");  // Not normally a column property
				properties.push("Reservation");
				
				var batchOrderBy = "DbaBatchOrder"; // Special property for the query results order
				var controllerProperties = [];
				controllerProperties.push(batchOrderBy);

				var propIssues = properties.find(property => property == "DbaIssues");
				if (propIssues) {
					properties = properties.filter(property => property != "DbaIssues"); // Pseudo property, can not be queried on
					controllerProperties.push("DbaVerificationWarningCount");
					controllerProperties.push("DbaVerificationErrorCount");
					controllerProperties.push("DbaCaptureError");
				}

				var ovpProperties = this._getColumnObjectProperties(view);
				ovpProperties.push("Creator");
				
				var props = contentItem.properties.items ? contentItem.properties.items : contentItem.properties;
				var propBatchOrder = props.find(property => property.id == "DbaBatchOrder");
				
				var searchParams = [];
				var contParam = {
					name: "DbaBatchController",
					operator: "=",
					value: contentItem.batchId
				};			
				if (propBatchOrder && propBatchOrder.value) {
					contParam.logical = "AND";
					var orderParam = {
						name: "DbaBatchOrder",
						operator: "=",
						value: "'" + propBatchOrder.value + "'"
					};
					searchParams.push(contParam);
					searchParams.push(orderParam);
				} else {
					searchParams.push(contParam);
				}
	
				var params = {
					pageSize: this._getPageSize(view),
					countLimit: view._instance.countLimit,
					documentBaseType: "DbaCaptureBase",
					controllerType: "DbaClassificationController",
					batchType: "DbaBatchController",
					batchOrderBy: batchOrderBy,
					order: "ASC",
					searchParams: searchParams,
					properties: properties,
					controllerProperties: controllerProperties,
					ovpProperties: ovpProperties,
					update: "batchDocuments",
					repository: this._getObjectStoreName(view),
					serverAppResource: view._instance.serverConfigurationName
				};
				console.log("CS-ContentList:_updateBatchDocument() : Retrieving batch object properties.");
				view._instance.batchDocumentsSvc = view.ui.get("BatchDocumentsSvc");
				this._callService(view._instance.batchDocumentsSvc, params);
			},

			_getFolderContainees: function(view, folderId, sortProperty, sortOrder) {
				// See if there has been a order by property specified in the config settings
				if (sortProperty == null || sortProperty == "") {
					sortProperty = this._getColumnSortProperty(view);
				}
				var documentSortProperty = sortProperty;
				if (sortProperty == "Name" || sortProperty == "name") {
					documentSortProperty = "DocumentTitle";
				}
				var folderSortProperty = sortProperty;
				if ((sortProperty == "Name" || sortProperty == "name") || (sortProperty != "LastModifier" && sortProperty != "LastModifier" && sortProperty != "Creator" && sortProperty != "DateCreated")) {
					// Folders can not be sorted by some document related properties (causes graphql error)
					folderSortProperty = "FolderName";
				}
				
				if (sortOrder == null || sortOrder == "") {
					sortOrder = this._getColumnSortOrder(view);
				}

				var params = {
					pageSize: this._getPageSize(view),
					countLimit: view._instance.countLimit,
					documentOrderBy: documentSortProperty,
					order: sortOrder,
					folderOrderBy: folderSortProperty,
					folderId: folderId,
					properties: this._getColumnProperties(view),
					ovpProperties: this._getColumnObjectProperties(view),
					repository: this._getObjectStoreName(view),
					serverAppResource: view._instance.serverConfigurationName
				};
				console.log("CS-ContentList:_getFolderContainees() : Folder contents for: " + folderId);
				view._instance.folderContSvc = view.ui.get("FolderContSvc");
				this._callService(view._instance.folderContSvc, params);
			},
			
			_getMoreFolderContainees: function(view, newPageNumber, token) {
				var params = {
					newPageNumber: newPageNumber,
					token: token,
					properties: this._getColumnProperties(view),
					ovpProperties: this._getColumnObjectProperties(view),
					serverAppResource: view._instance.serverConfigurationName
				};
				view._instance.moreFolderContSvc = view.ui.get("MoreFolderContSvc");
				this._callService(view._instance.moreFolderContSvc, params);
			},

			_getSearchResults: function(view, searchValue, sortProperty, sortOrder, searchValues) {
				view._instance.searchValue = searchValue;
				var valueRequired = true;

				// Get the search folder settings (if any, they are optional)
				var searchFolderId = view.context.options.searchFolderId.get("value");
				var searchOnlyFolder = view.context.options.searchOnlyFolder.get("value");
				var searchFor = view.context.options.searchFor.get("value");
				var searchType = view.context.options.searchType.get("value");
				var textOption = view.context.options.searchTextOption.get("value");

				if (searchFor && searchFor == this.typeFolder) {
					// Clear bread crumb in case we are in folder query mode
					this._clearBreadCrumb(view, true);
					view._instance.currentParentFolder = view._instance.breadCrumbTrail[0];
					textOption = null; // Can't do text base queries against folders
				}
				// If the search type has been specified, use it instead of default Document or Folder type
				if (searchType == null) {
					if (searchFor == undefined || searchFor == this.typeDocument) {
						searchType = this.typeDocument;
					} else {
						searchType = this.typeFolder;
					}
				}
			
				// Get the specified operator first and check if its one that does not require a value to be entered
				var operator = view.context.options.searchOperator.get("value");
				var operatorLowerCase;
				if (operator != null) {
					operatorLowerCase = operator.toLowerCase();
					if (operatorLowerCase == "is null") {
						valueRequired = false;
					} else if (operatorLowerCase == "is not null") {
						valueRequired = false;
					}
				} else {
					console.log("CS-ContentList:_getSearchResults() : Property search no operator configured.");
				}
					
				// Retrieve the option to check to see if the search filter is configured
				var enableSearchFilter = view.context.options.enableSearchFilter.get("value");
					
				// If no search value specified, clear the list and don't run a query against root for nothing
				if (!enableSearchFilter && valueRequired && (searchValue == null || searchValue == "")) {
					if (view._instance.contentTable._instance.list != null) {
						view._instance.contentTable.clear();
//						view._instance.contentTable.refresh(true);
					}
					view._setPagingTextData(0, 0, 0);
				} else {
					if (textOption != null && textOption != "none") {
						var property = view.context.options.searchProperty.get("value");
						var operator = view.context.options.searchOperator.get("value");
						var searchPhrase;
						var propertyPhrase;
						var words = searchValue.split(" ");
						if (words.length > 1) {
							searchPhrase = words[0];
							
							var searchValue = searchPhrase;
							searchValue = this._addSearchValueWildCardChars(searchValue, true, true);
//							propertyPhrase = "(d." + property + " LIKE '" + searchValue + "'";
							// Note: Converting property values and query string to lower case for case-insensitive queries by default
							propertyPhrase = "(LOWER(d." + property + ") LIKE LOWER('" + searchValue + "')";

							for (var i = 1; i < words.length; i++) {
								var word = words[i];
								if (word != null && word != "") {
									searchPhrase += " " + textOption + " "; /* search text will be capitalized by default */
									searchPhrase += word;
									
									var searchValue = word;
									searchValue = this._addSearchValueWildCardChars(searchValue, true, true);
//									propertyPhrase += " " + textOption + " d." + property + " LIKE '" + searchValue + "'";
									propertyPhrase += " " + textOption + " LOWER(d." + property + ") LIKE LOWER('" + searchValue + "')";
								}
							}
						} else {
							searchPhrase = searchValue;
							searchValue = this._addSearchValueWildCardChars(searchValue, true, true);
//							propertyPhrase = "(d." + property + " LIKE '" + searchValue + "'";
							propertyPhrase = "(LOWER(d." + property + ") LIKE LOWER('" + searchValue + "')";
						}
						
						// See if there has been a order by property specified in the config settings
						if (sortProperty == null || sortProperty == "") {
							sortProperty = this._getColumnSortProperty(view);
						}
						if (sortProperty == "Name" || sortProperty == "name") {
							sortProperty = "DocumentTitle";
						}
						
						if (sortOrder == null || sortOrder == "") {
							sortOrder = this._getColumnSortOrder(view);
						}
						
						var params = {
							pageSize: this._getPageSize(view),
							countLimit: view._instance.countLimit,
							searchFolderId: searchFolderId,
							searchOnlyFolder: searchOnlyFolder,
							searchFor: this.typeDocument,
							searchType: searchType,
							searchPhrase: searchPhrase,
							textOption: textOption,
							propertyPhrase: propertyPhrase,
							orderByProperty: sortProperty,
							order: sortOrder,
							properties: this._getColumnProperties(view),
							ovpProperties: this._getColumnObjectProperties(view),
							repository: this._getObjectStoreName(view),
							serverAppResource: view._instance.serverConfigurationName
						};
						
						if (searchFolderId != null) {
							if (searchOnlyFolder) {
								console.log("CS-ContentList:_getSearchResults() : Text search for: " + searchPhrase + " InFolder " + searchFolderId);
							} else {
								console.log("CS-ContentList:_getSearchResults() : Text search for: " + searchPhrase + " InSubFolder " + searchFolderId);
							}
						} else {
							console.log("CS-ContentList:_getSearchResults() : Text search for: " + searchPhrase);
						}
						view._instance.textSearchSvc = view.ui.get("TextSearchSvc");
						this._callService(view._instance.textSearchSvc, params);
					} else {
						// Standard search options, no CBR turned on
						var modifiedProperties = [];
						if (enableSearchFilter) {
							var searchConfigOptions = view.context.options.searchProperties.get("value");
							searchConfigOptions = searchConfigOptions.items ? searchConfigOptions.items : searchConfigOptions;
							// If there are search values passed in, use those values with the config options
							if (searchValues) {
								modifiedProperties = this._cloneConfigOptions(view, searchConfigOptions, searchValues);
							} else {
								modifiedProperties = this._cloneConfigOptions(view, searchConfigOptions, null);
							}
							// If there have been any extra filter property values specified from the api, process those
							var filterProperties = view._instance.filterPropertyValues;
							if (filterProperties.length > 0) {
								console.log("CS-ContentList:_refresh() : processing filter properties.");
								filterProperties.forEach(function(filterProperty) {
									// Look for a filter property with a matching name and set the value
									for (var i = 0; i < modifiedProperties.length; i++) {
										var modifiedProperty = modifiedProperties[i];
										if (modifiedProperty.name == filterProperty.name) {
											modifiedProperty.defaultValue = filterProperty.value;
											break;
										}
									}
								});
							}
						}
						
						if (modifiedProperties == null || modifiedProperties.length == 0) {
							// Add single value search property otion into array structure like multi-options
							var property = view.context.options.searchProperty.get("value");
							var operator = view.context.options.searchOperator.get("value");
							modifiedProperties.push({
								name: property,
								operator: operator,
								defaultValue: searchValue,
								dataType: view._instance.searchPropertyType,
								cardinality: view._instance.searchPropertyCardinality
							});
						}

						var searchProperties = [];		
						
						for (var i = 0; i < modifiedProperties.length; i++) {
							var searchProperty = modifiedProperties[i];

							var searchValue = searchProperty.defaultValue;
							if (searchValue == null || searchValue == "") {
								continue; // Skip properties that have not values
							} else if ((searchProperty.dataType == "integer" || searchProperty.dataType == "decimal") && searchValue == "null") {
								continue; 
							}
							
							var property = searchProperty.name;
							var operator = searchProperty.operator;
							var searchPropertyType = searchProperty.dataType;
							var searchPropertyCardinality = searchProperty.searchPropertyCardinality;

							// Get the specified operator first and check if its one that does not require a value to be entered
							var valueRequired = true;
							var operatorLowerCase;
							if (operator != null) {
								operatorLowerCase = operator.toLowerCase();
								if (operatorLowerCase == "is null") {
									valueRequired = false;
								} else if (operatorLowerCase == "is not null") {
									valueRequired = false;
								}
							} else {
								console.log("CS-ContentList:_getSearchResults() : Property search no operator configured.");
							}

							if (property != null) {
								// When property data type is string, need to convert to lower case (later on)
								var propertyLowerCase = property;
								var orderByProperty;
								var checkDataType = true;
								var operatorLowerCase;
								var addNotOperator = false;
								
								if (operator != null) {
									// Check to see if a multi-value operator has been specified (assume mvcp property too)
									operatorLowerCase = operator.toLowerCase();
									if (operatorLowerCase == "intersects") {
										// Todo: not in operator choice list
										searchValue = this._modifyIncludeAnyValueSearchValue(view, searchValue, searchPropertyType);
										orderByProperty = "DocumentTitle"; // Can't orderBy on mvcp properties
										checkDataType = false;
									} else if (operatorLowerCase == "in") {
										// Todo: not in operator choice list
										searchValue = this._modifyIncludeAnyValueSearchValue(view, searchValue, searchPropertyType);
										orderByProperty = "DocumentTitle"; 
										checkDataType = false;
									} else if (operatorLowerCase == "include any") {
										searchValue = this._modifyIncludeValueSearchValue(view, searchValue, property, searchPropertyType, "Or");
										propertyLowerCase = "";
										operatorLowerCase = "";
										orderByProperty = "DocumentTitle"; 
										checkDataType = false;
									} else if (operatorLowerCase == "include all") {
										searchValue = this._modifyIncludeValueSearchValue(view, searchValue, property, searchPropertyType, "And");
										propertyLowerCase = "";
										operatorLowerCase = "";
										orderByProperty = "DocumentTitle"; 
										checkDataType = false;
									} else if (operatorLowerCase == "is null") {
										searchValue = "";
										orderByProperty = "DocumentTitle"; // Can't orderBy on mvcp properties
										checkDataType = false;
									} else if (operatorLowerCase == "is not null") {
										searchValue = "";
										orderByProperty = "DocumentTitle"; // Can't orderBy on mvcp properties
										checkDataType = false;
									} else if (operatorLowerCase == "like") {
										// If 'like' operator specified (or default set in action), add '%' if not already specified
										searchValue = this._addSearchValueWildCardChars(searchValue, true, true);
									} else if (operatorLowerCase == "starts with") {
										// If 'starts with' operator specified, change it into like and add '%' at the end
										operatorLowerCase = "like";
										searchValue = this._addSearchValueWildCardChars(searchValue, false, true);
									} else if (operatorLowerCase == "ends with") {
										// If 'ends with' operator specified, change it into like and add '%' at beginning
										operatorLowerCase = "like";
										searchValue = this._addSearchValueWildCardChars(searchValue, true, false);
									} else if (operatorLowerCase == "not like") {
										// 'not like' needs to be burst apart into a 'not' prefix and a 'like' operator
										operatorLowerCase = 'like';
										searchValue = this._addSearchValueWildCardChars(searchValue, true, false);
										addNotOperator = true;
									} else if (operatorLowerCase == "exclude all") {
										if (searchPropertyCardinality == "SINGLE") {
											// 'exclude all' needs to be burst apart into a 'not' prefix and a 'in' operator
											operatorLowerCase = 'in';
											searchValue = this._modifyIncludeAnyValueSearchValue(view, searchValue, searchPropertyType);
											checkDataType = false; // Will not add "LOWER" macro
											addNotOperator = true;
										} else {
											// Using 'Or' operator here to match what ICN does... seems like it should really be an 'And'
											searchValue = this._modifyIncludeValueSearchValue(view, searchValue, property, searchPropertyType, "Or");
											propertyLowerCase = "";
											operatorLowerCase = "";
											orderByProperty = "DocumentTitle"; 
											checkDataType = false;
											addNotOperator = true;
										}
									}
								} else {
									// If operator is null, will default to 'like'
									searchValue = this._addSearchValueWildCardChars(searchValue, true, true)							
								}
								
								if (searchPropertyCardinality == "LIST") {
									orderByProperty = "DocumentTitle"; // Can't orderBy on mvcp properties
								}
									
								var searchValues = null;
								if (checkDataType) {
									if (searchPropertyType == "string") {
										searchValue = this._modifyStringSearchValue(searchValue);
										if (operatorLowerCase != "is null" && operatorLowerCase != "is not null") {
											propertyLowerCase = "LOWER(" + property + ")";
										}
									} else if (searchPropertyType == "date") {
										searchValue = this._modifyDateTimeSearchValue(searchValue, true);
									} else if (searchPropertyType == "guid") {
										searchValue = this._modifyGUIDSearchValue(searchValue);
									} else if (searchPropertyType == "integer") {
										var n = searchValue.indexOf(";");
										if (n >= 0) {
											searchValues = searchValue.split(";");
										}
									}
								}
								
								if (addNotOperator) {
									// Need to add the not opeartor at front of where clause
									propertyLowerCase = "Not ( " + propertyLowerCase;
									searchValue = searchValue + " )";
								}
								
								if (searchValues && searchValues.length > 0) {
									searchValues.forEach(function(searchValue, index) {
										var searchProperty = {
											property: propertyLowerCase,
											operator: operatorLowerCase,
											value: searchValue.trim(),
											dataType: searchPropertyType
										};
										if (index == 0) {
											searchProperty.lparen = true;
										} else if (index == searchValues.length - 1) {
											searchProperty.rparen = true;
										}
										if (index < searchValues.length - 1) {
											searchProperty.logical = "OR";
										}
										searchProperties.push(searchProperty);
									});
								} else {
									var searchProperty = {
										property: propertyLowerCase,
										operator: operatorLowerCase,
										value: searchValue,
										dataType: searchPropertyType,
									};
									searchProperties.push(searchProperty);
								}
								console.log("CS-ContentList:_getSearchResults() : Property search on: " + propertyLowerCase + " " + operatorLowerCase + " " + searchValue);
							}
						}

						if (enableSearchFilter) {
							console.log("CS-ContentList:_getSearchResults() : Using property search filter configuration for query.");
						} else if (searchFolderId != null) {
							if (searchOnlyFolder) {
								console.log("CS-ContentList:_getSearchResults() : Property search for: " + searchFor + " In Folder " + searchFolderId);
							} else {
								console.log("CS-ContentList:_getSearchResults() : Property search for: " + searchFor + " In SubFolders " + searchFolderId);
							}
						} else {
							console.log("CS-ContentList:_getSearchResults() : Property search for: " + searchFor);
						}
						
						// See if there has been a order by property specified in the config settings
						if (sortProperty == null || sortProperty == "") {
							sortProperty = this._getColumnSortProperty(view);
							if (sortProperty != null && sortProperty != "") {
								orderByProperty = sortProperty;
							}
						} else {
							orderByProperty = sortProperty;
						}
						if (orderByProperty == "Name" || orderByProperty == "name") {
							orderByProperty = "DocumentTitle";
						}
						
						if (sortOrder == null || sortOrder == "") {
							sortOrder = this._getColumnSortOrder(view);
						}

						var params = {
							pageSize: this._getPageSize(view),
							countLimit: view._instance.countLimit,
							searchFolderId: searchFolderId,
							searchOnlyFolder: searchOnlyFolder,
							searchFor: searchFor,
							searchType: searchType,
							searchProperty: propertyLowerCase,
							searchOperator: operatorLowerCase,
							searchValue: searchValue,
							searchPropertyType: view._instance.searchPropertyType,
							searchProperties: searchProperties,
							orderByProperty: orderByProperty,
							order: sortOrder,
							properties: this._getColumnProperties(view),
							ovpProperties: this._getColumnObjectProperties(view),
							repository: this._getObjectStoreName(view),
							serverAppResource: view._instance.serverConfigurationName
						};
												
						view._instance.searchSvc = view.ui.get("SearchSvc");
						this._callService(view._instance.searchSvc, params);

						if (view._instance.pollingEnabled) {
							view._instance.propertyPoller.setSearchCriteria({
								searchFor: searchFor,
								searchType: searchType,
								searchProperties: searchProperties,
								properties: this._getColumnProperties(view),
								ovpProperties: this._getColumnObjectProperties(view),
							});
						}
					}
				}
			},
			
			_cloneConfigOptions: function(view, searchConfigOptions, searchValues) {
				var modifiedProperties = [];
				var values;
				if (searchValues) {
					values = JSON.parse(searchValues);
					if (values.length != searchConfigOptions.length) {
						console.log("CS-ContentList:_cloneConfigOptions() : Config options length does not match values length, check for hidden filter property that does not have a default value.");
					}
				}

				for (var i = 0; i < searchConfigOptions.length; i++) {
					var configOption = searchConfigOptions[i];
					var modifiedProperty = {
						name: configOption.name,
						displayName: configOption.displayName,
						operator: configOption.operator,
						dataType: configOption.dataType,
						cardinality: configOption.cardinality
					};
					
					if (values) {
						if (values[i]) {
							var value = values[i][configOption.name];
							if (configOption.dataType == "integer" || configOption.dataType == "decimal") {
								modifiedProperty.defaultValue = "" + value; // Convert to string
							} else {
								modifiedProperty.defaultValue = value;
							}
						} else {
							modifiedProperty.defaultValue = null;
						}
					} else {
						modifiedProperty.defaultValue = configOption.defaultValue;
					}
					modifiedProperties.push(modifiedProperty);
				}
				return modifiedProperties;
			},
			
			_modifyIncludeAnyValueSearchValue: function(view, searchValue, searchPropertyType) {
				// Need to make sure string values have ' around each value
				var searchValueEnhanced = "(";
				var words = searchValue.split(",");
				if (words.length > 0) {
					for (var i = 0; i < words.length; i++) {
						var word = words[i];
						if (word != null && word != "") {
							var wordTrimmed = word.trim();
							if (searchPropertyType == "string") {
								// Check first to see if words have surrounding tic's (if not add them)
								if (!wordTrimmed.startsWith("'")) {
									wordTrimmed = "'" + wordTrimmed;
								}
								if (!wordTrimmed.endsWith("'")) {
									wordTrimmed = wordTrimmed + "'";
								}
								searchValueEnhanced = this._addIncludeAnySearchValue(i, searchValueEnhanced, wordTrimmed);
							} else if (searchPropertyType == "date") {
								var searchDateStr = this._modifyDateTimeSearchValue(wordTrimmed, false);
								searchValueEnhanced = this._addIncludeAnySearchValue(i, searchValueEnhanced, searchDateStr);
							} else if (searchPropertyType == "guid") {
								var searchGuid = this._modifyGUIDSearchValue(wordTrimmed);
								searchValueEnhanced = this._addIncludeAnySearchValue(i, searchValueEnhanced, searchGuid);								
							} else if (searchPropertyType == "integer" || searchPropertyType == "decimal") {
								if (!isNaN(wordTrimmed)) {
									searchValueEnhanced = this._addIncludeAnySearchValue(i, searchValueEnhanced, wordTrimmed);
								}
							} else {
								// Boolean
								searchValueEnhanced = this._addIncludeAnySearchValue(i, searchValueEnhanced, wordTrimmed);
							}
						}
					}
				}
				searchValueEnhanced += ")";
				return searchValueEnhanced;
			},

			_addIncludeAnySearchValue: function(i, searchValueEnhanced, searchValue) {
				if (searchValue != null) {
					if (i != 0) {
						searchValueEnhanced += ", ";
					}
					searchValueEnhanced += searchValue;
				}
				return searchValueEnhanced;
			},

			_modifyIncludeValueSearchValue: function(view, searchValue, property, searchPropertyType, anyall) {
				// Need to make sure string values have ' around each value
				var searchValueEnhanced = "";
				var words = searchValue.split(",");
				if (words.length > 0) {
					for (var i = 0; i < words.length; i++) {
						var word = words[i];
						if (word != null && word != "") {
							var wordTrimmed = word.trim();
							if (searchPropertyType == "string") {
								// Check first to see if words have surrounding tic's (if not add them)
								if (!wordTrimmed.startsWith("'")) {
									wordTrimmed = "'" + wordTrimmed;
								}
								if (!wordTrimmed.endsWith("'")) {
									wordTrimmed = wordTrimmed + "'";
								}
								searchValueEnhanced = this._addIncludeSearchValue(searchValueEnhanced, wordTrimmed, property, anyall);
							} else if (searchPropertyType == "date") {
								var searchDateStr = this._modifyDateTimeSearchValue(wordTrimmed, false);
								searchValueEnhanced = this._addIncludeSearchValue(searchValueEnhanced, searchDateStr, property, anyall);
							} else if (searchPropertyType == "guid") {
								var searchGuid = this._modifyGUIDSearchValue(wordTrimmed);
								searchValueEnhanced = this._addIncludeSearchValue(searchValueEnhanced, searchGuid, property, anyall);
							} else if (searchPropertyType == "integer" || searchPropertyType == "decimal") {
								if (!isNaN(wordTrimmed)) {
									searchValueEnhanced = this._addIncludeSearchValue(searchValueEnhanced, wordTrimmed, property, anyall);
								}
							} else {
								// Boolean
								searchValueEnhanced = this._addIncludeSearchValue(searchValueEnhanced, wordTrimmed, property, anyall);
							}
						}
					}
				}
				return searchValueEnhanced;
			},
			
			_addIncludeSearchValue: function(searchValueEnhanced, searchValue, property, anyall) {
				if (searchValue != null) {
					if (searchValueEnhanced != "") {
						searchValueEnhanced += " " + anyall + " ";
					}
					searchValueEnhanced += searchValue + " In " + property + " ";
				}
				return searchValueEnhanced;
			},
			
			_isValidDate: function(d) {
				return d instanceof Date && !isNaN(d);
			},
		
			_modifyStringSearchValue: function(searchValue) {
				// Add ' around search value (for graphql), for string type properties
				// Note: Converting property values and query string to lower case for case-insensitive queries by default
				if (searchValue != null && searchValue != "") {
					searchValue = "LOWER('" + searchValue + "')";
				}
				return searchValue;
			},
			
			_modifyDateTimeSearchValue: function(searchValue, obfuscate) {
				// Date properties need to be converted to ISO format for graphql
				var searchDate = new Date(searchValue);
				if (this._isValidDate(searchDate)) {
					var searchDateStr = dateStamp.toISOString(searchDate, {
						milliseconds: true
					});	
					if (obfuscate) {
						// Todo: adding characters so the Studio's "execute" function will not change the date format (is a string but still gets modified)
						// The extra characters will get sliced off in the service action code before sending request to graphql
						searchValue = "&&" + searchDateStr;
					} else {
						searchValue = searchDateStr;
					}
				} else {
					searchValue = null;
				}
				return searchValue;
			},
		
			_modifyGUIDSearchValue: function(searchValue) {
				searchValue = searchValue.trim(); // remove white space at both ends
				if (!searchValue.startsWith("{")) {
					searchValue = "{" + searchValue;
				}
				if (!searchValue.endsWith("}")) {
					searchValue = searchValue + "}";
				}
				return searchValue;
			},
			
			_addSearchValueWildCardChars: function(searchValue, atBeginning, atEnd) {
				var value = searchValue;
				if (atBeginning) {
					if (!value.startsWith("%")) {
						value = "%" + value;
					}
				}
				if (atEnd) {
					if (!value.endsWith("%")) {
						value = value + "%";
					}
				}
				return value;
			},
			
			_getMoreSearchResults: function(view, newPageNumber, token) {
				var searchFor = view.context.options.searchFor.get("value");
				var params = {
					newPageNumber: newPageNumber,
					token: token,
					searchFor: searchFor,
					properties: this._getColumnProperties(view),
					ovpProperties: this._getColumnObjectProperties(view),
					serverAppResource: view._instance.serverConfigurationName
				};
					
				var textSearch = view.context.options.searchTextOption.get("value");
				if (textSearch != null && textSearch != "none") {
					view._instance.moreTextSearchSvc = view.ui.get("MoreTextSearchSvc");
					this._callService(view._instance.moreTextSearchSvc, params);
				} else {
					view._instance.moreSearchSvc = view.ui.get("MoreSearchSvc");
					this._callService(view._instance.moreSearchSvc, params);
				}
			},
			
			_getPreviousItems: function(view) {
				// New page number should reflect the new page the user is trying to navigate to
				var newPageNumber = view._instance.pageNumber - 1;
				if (newPageNumber == -1) {
					return;  // Shouldn't get here, grayed out previous button when at beginning
				}

				if (view._instance.refreshing) {
					console.log("CS-ContentList:_getPreviousItems() : Previous items blocked");
					return;
				}
				view._instance.refreshing = true; // blocks clicking same button multiple times
				console.log("CS-ContentList:_getPreviousItems() : Previous items for page: " + newPageNumber);

				if (view._instance.folderId != null) {
					if (view._instance.explorerFilterText && view._instance.explorerFilterText.getText() != '') {
						view._instance.contentTable.clearSearch();
						view._instance.explorerFilterText.setText("");
					}
				}
				
				if (newPageNumber == 0) {
					// At first page
					view._instance.pageNumber = 0;
					
					// Clear the pageTokens array if we go back to first page 
					if (view._instance.breadcrumbLevel == 0) {
						view._instance.pageTokensLevel = [];					
					} else {
						tokensPage = [];
						view._instance.pageTokensLevel[view._instance.breadcrumbLevel] = tokensPage;
					}

					// Check to see if a folderId has been specified, if so use it (it has priority over searchValue)
					var folderId = view._instance.folderId
					if (folderId != null) {
						var currentFolder = view._instance.currentParentFolder;
						if (currentFolder != null) {
							folderId = currentFolder.id;
						}
						this._getFolderContainees(view, folderId, null, null);
					} else {
						// Get the search string the user has potentially modified from the ui
						if (view._instance.loadType == this.loadSearch) {
							var searchValue = view._instance.contentListFilterText.getText();
							this._getSearchResults(view, searchValue, null, null, view._instance.searchValues);
						} else if (view._instance.loadType == this.loadBatch && view._instance.currentBatch) {
							this._getBatchDocuments(view, view._instance.currentBatch);
						}
					}
				} else { 
					// Normal paging backwards, setup paging token array
					var tokensPage = view._instance.pageTokensLevel[view._instance.breadcrumbLevel];
					var token = tokensPage[newPageNumber - 1];  // get previous page of items (-1)
					tokensPage = tokensPage.splice(0, newPageNumber);
					view._instance.pageTokensLevel[view._instance.breadcrumbLevel] = tokensPage;
				
					// Check to see if a folderId has been specified, if so use it (it has priority over searchValue)
					var folderId = view._instance.folderId;
					if (folderId != null) {
						this._getMoreFolderContainees(view, newPageNumber, token);
					} else {
						if (view._instance.loadType == this.loadSearch) {
							// Retrieve the option to check to see if the search filter is configured
							var enableSearchFilter = view.context.options.enableSearchFilter.get("value");
							if (enableSearchFilter) {
								this._getMoreSearchResults(view, newPageNumber, token);
							} else {
								var searchValue = view.context.options.searchValue.get("value");
								if (searchValue != null) {
									this._getMoreSearchResults(view, newPageNumber, token);
								}
							}
						} else if (view._instance.loadType == this.loadBatch) {
							this._getMoreBatchDocuments(view, newPageNumber, token);
						}
					}
				}
			},
			
			_getNextItems: function(view) {
				// New page number should reflect the new page the user is trying to navigate to
				var newPageNumber = view._instance.pageNumber + 1;
				
				// Setup paging token array
				var tokensPage = view._instance.pageTokensLevel[view._instance.breadcrumbLevel];
				var token = tokensPage[view._instance.pageNumber];
	
				if (token == null) {
					return;  // Shouldn't get here, grayed out next button when at end (or no more pages)
				}
	
				if (view._instance.refreshing) {
					console.log("CS-ContentList:_getNextItems() : Next items blocked");
					return;
				}
				view._instance.refreshing = true; // blocks clicking same button multiple times
				console.log("CS-ContentList:_getNextItems() : Next items for page: " + newPageNumber);
	
				if (view._instance.folderId != null) {
					if (view._instance.explorerFilterText && view._instance.explorerFilterText.getText() != '') {
						view._instance.contentTable.clearSearch();
						view._instance.explorerFilterText.setText("");
					}
				}

				// Check to see if a folderId has been specified, if so use it (it has priority over searchValue)
				var folderId = view._instance.folderId;
				if (folderId != null) {
					this._getMoreFolderContainees(view, newPageNumber, token);
				} else {
					if (view._instance.loadType == this.loadSearch) {
						// Retrieve the option to check to see if the search filter is configured
						var enableSearchFilter = view.context.options.enableSearchFilter.get("value");
						if (enableSearchFilter) {
							this._getMoreSearchResults(view, newPageNumber, token);
						} else {
							var searchValue = view.context.options.searchValue.get("value");
							if (searchValue != null) {
								this._getMoreSearchResults(view, newPageNumber, token);
							}
						}
					} else if (view._instance.loadType == this.loadBatch) {
						// No folderId or search specified, nothing specified to load (getDocuments does not support paging)
						this._getMoreBatchDocuments(view, newPageNumber, token);
					}
				}
			},

			_buildDocumentURLString: function(view, serverConfigurationName, rowData) {
				var item = rowData.contentItem;
				var contentElements = item.contentElements ? item.contentElements.items ? item.contentElements.items : item.contentElements : [];
				if (contentElements.length > 0) {
					var downloadUrl = contentElements[0].downloadUrl;
					// Todo: Temp URL modification for graphql
					var res = downloadUrl.replace("content", "content-services-graphql/content");
				}
				return res;
			},
			
			_onFileClick: function(view, row) {
				var rowData = row.data;
				var id = rowData.contentItem.id;   // id is a first class property on the item and not in the property bag
				var name = rowData.contentItem.name;
				console.log("CS-ContentList:_onFileClick() : File clicked: " + name + " row: " + row.index);

				// When a file name/mime icon is selected, also select the row selector (not in None mode)
				this._setRecordSelected(view, row.index, true);
				
				// If the list view selection mechanism has been bound to something
				this._setBindingObject(view, row, rowData.contentItem, false, true);
				bpmext.ui.executeEventHandlingFunction(view, this.EVT_ONFILECLICKED, rowData.contentItem);
			},

			_setRecordSelected: function(view, record, selected) {
				// Record parameter is an index, not the real record
				view._instance.contentTable.setRecordSelected(record, selected);
		
				// If in None selection mode, selection selection color on the item that was clicked on
				var selectionMode = view.context.options.selectionMode.get("value");
				if (selectionMode && selectionMode == "N") {
					var recordObj = view._instance.contentTable.getRecord(record, null);	
					var currentTrObj = view._instance.currentTrObj;
					if (currentTrObj && currentTrObj.tr) {
						domClass.remove(currentTrObj.tr, "sel");
					}
					var trObj = view._instance.contentTable._instance.list.getItemContext(recordObj);
					domClass.add(trObj.tr, "sel");
					view._instance.currentTrObj = trObj;
				}
			},

			_removeLastFolder: function(view, parentFolderId) {
				return view._instance.breadCrumbTrail.filter(function(folder) {
					return (folder.id != parentFolderId); 
				});
			},

			_onFolderClick : function(view, row) {
				var rowData = row.data;
				if (!domClass.contains(view.context.element, "nonRoot")) {
					domClass.add(view.context.element, "nonRoot");
				}
				
				view._instance.loadedItems = view._instance.maxItems;
				view._instance.lastPageIndex = 0;

				if (view._instance.refreshing) {
					console.log("CS-ContentList:_onFolderClick() : Folder click blocked");
					return;
				}
				view._instance.refreshing = true; // blocks clicking same folder multiple times
				console.log("CS-ContentList:_onFolderClick() : Folder clicked: " + rowData.contentItem.id + " row: " + row.index);
				
				var lastFolder = view._instance.breadCrumbTrail[view._instance.breadCrumbTrail.length - 1];

				view._instance.currentParentFolder = {
					id: rowData.contentItem.id,
					accessAllowed: rowData.contentItem.accessAllowed,
					server: rowData.server,
					name: rowData.contentItem.name,
					className: rowData.contentItem.className,
					path: "/",
					isFolder: true,
					baseType: this.typeFolder
				};

				var rootFolder;
				if (rowData.name === "..") {
					// Todo: breadcrumb wraps... so never see ".."
					lastFolder = view._instance.breadCrumbTrail[view._instance.breadCrumbTrail.length - 1];
					view._instance.breadCrumbTrail = this._removeLastFolder(view, lastFolder.id);
				} else if (view._instance.breadCrumbTrail.length == 0) {
					// If not items in breadcrumb yet, add a root item
					var folderId = view._instance.folderId;
					if (folderId != null) {
						var folderParent = rowData.contentItem.parent;
						rootFolder = {
							id: folderParent.id,
							accessAllowed: folderParent.accessAllowed,
							server: rowData.server,
							name: folderParent.name,
							className: folderParent.className,
							path: "/",
							isFolder: true,
							baseType: this.typeFolder
						};
					} else {
						// In search mode, add a pseudo root folder for the bread crumb to work correctly
						var rootSearchName = view.context.options.rootSearchName.get("value");
						if (rootSearchName == null || rootSearchName == "") {
							rootSearchName = messages.contlist_root_search;
						}
						rootFolder = {
							id: "__id_Results",
							server: rowData.server,
							name: rootSearchName,
							path: "/",
							isFolder: true,
							baseType: this.typeFolder
						};
					}
					
					if (rootFolder) {
						this._addBreadcrumbItem(view, rootFolder);
						view._instance.rootFolder = rootFolder;
					}
				}
				
				// If going down into sub-folder
				if (rootFolder) {
					var seperator = "/";
					if (view._instance.breadCrumbTrail[view._instance.breadCrumbTrail.length - 1].path == "/") {
						seperator = "";
					}
					view._instance.currentParentFolder.path = view._instance.breadCrumbTrail[view._instance.breadCrumbTrail.length - 1].path + seperator + " " + view._instance.currentParentFolder.name;
				}

				// Set the flag to update the breadcrumb on the async response callback
				view._instance.addBreadcrumbItem = true;
				
				// Setup paging token array
				var tokensPage = [];
				view._instance.pageTokensLevel.push(tokensPage);
				view._instance.breadcrumbLevel++;
				
				// Call the get folder containees service to get the new items to render in list view
				var currentFolder =	view._instance.currentParentFolder;
				this._getFolderContainees(view, currentFolder.id, null, null);
	
				this._setBindingObject(view, row, rowData.contentItem, false, false);
				bpmext.ui.executeEventHandlingFunction(view, this.EVT_ONFOLDERCLICKED, rowData.contentItem);
			},
			
			_setBindingObject: function(view, row, contentItem, propertyUpdate, viewerUpdate, setIfDifferent) {
				if (view.context.binding) {			
					var sameObjects = false;
					// Currently, no calls into this function are passing the set if different flag (here just in case)
					if (setIfDifferent) {
						var boundItem = view.context.binding.get("value");
						if (boundItem && boundItem.id == contentItem.id) {
							// Same objects (at lease id wise)
							sameObjects = true;
						}						
					}
					
					if (!sameObjects) {
						contentItem.rowIndex = row.index;
						contentItem.pageNumber = view._instance.pageNumber;
						contentItem.propertyUpdate = propertyUpdate; 
						contentItem.viewerUpdate = viewerUpdate; 
						view.context.binding.set("value", contentItem);
					}
				}
			},
			
			_addBreadcrumbItem: function(view, folder) {
				console.log("CS-ContentList:_addBreadcrumbItem() : Adding breadcrumb item: " + folder.name);
				view._instance.breadCrumbTrail.push(folder);
				view._instance.breadcrumb.appendItem({
					name: folder.name,
					value: folder.id,
					className: folder.className,
					isFolder: true
				});
			},
			
			_onBreadcrumbLevelClick: function (view, breadcrumbItem) {
				// Setup paging token array
				view._instance.breadcrumbLevel = breadcrumbItem.level;
				view._instance.pageTokensLevel = view._instance.pageTokensLevel.splice(0, breadcrumbItem.level + 1);
				console.log("CS-ContentList:_onBreadcrumbLevelClick() : Breadcrumb clicked, level: " + breadcrumbItem.level);

				view._instance.currentParentFolder = view._instance.breadCrumbTrail[breadcrumbItem.level];
				if (breadcrumbItem.level == 0) {
					// Back at root, hide the breadcrumb control
//					view._instance._instance.breadcrumb.setVisible(false, true);
					domClass.remove(view.context.element, "nonRoot");
				}
				
				view._instance.loadedItems = view._instance.maxItems;
				view._instance.lastPageIndex = 0;
				view._instance.breadCrumbTrail = view._instance.breadCrumbTrail.slice(0, (breadcrumbItem.level + 1));
				
				if (view.context.binding) {
					if (view._instance.currentParentFolder.id == "__id_Results") {
						view.context.binding.set("value", null);
					} else { 
						view.context.binding.set("value", view._instance.currentParentFolder);
					}
				}
				bpmext.ui.executeEventHandlingFunction(view, this.EVT_ONFOLDERCLICKED, view._instance.currentParentFolder);

				this._refresh(view);
			},

			_clearBreadCrumb: function(view, isVisible) {
				view._instance.breadcrumbLevel = 0;
				view._instance.breadcrumb.setVisible(isVisible, true);
				view._instance.breadCrumbTrail = [];
				var itemCount = view._instance.breadcrumb.getItemCount();
				for (var i = 0; i < itemCount; i++) {
					view._instance.breadcrumb.removeLastItem();
				}
			},
	
			_showHideContentListFilter: function(view, isVisible) {
				var contentListFilterInputGroup = view.ui.get("ContentListFilterInputGroup");
				contentListFilterInputGroup.setVisible(true, true); // Set root element visible in both cases
				view._instance.contentListFilterText = view.ui.get("ContentListFilterText");
				if (isVisible) {
					domStyle.set(contentListFilterInputGroup.context.element, "display", "inline-block");

					view._instance.contentListFilterText.focus();
					if (view._instance.currentParentFolder && view._instance.currentParentFolder.name == 'Documents') {
						domClass.add(view.context.element, "nonRoot");
					}
				} else {
					var filterInputGroupDiv = contentListFilterInputGroup.context.element;
					domStyle.set(filterInputGroupDiv, "display", "inline-block");
					var outerDiv = filterInputGroupDiv.children[0];
					domStyle.set(outerDiv, "display", "none");				
				}
			},
			
			_showSearchFilterButton: function(view) {
				var contentListFilterInputGroup = view.ui.get("ContentListFilterInputGroup");
				contentListFilterInputGroup.setVisible(false, true);
				domStyle.set(contentListFilterInputGroup.context.element, "display", "none");
			},
			
			_filterContentList: function (view, current, potential, selection, type) {
				var folderId = view._instance.folderId;
				if (folderId != null) {
					potential = potential.toLowerCase();  // What the user typed in
					
					var self = this;
					var searchRow = function(rowData) {
						var hasMoreItems = rowData.hasMoreItems;
//						var name = rowData.name && rowData.name.toLowerCase().includes(potential);
//						var modifiedBy = rowData.modifiedBy && rowData.modifiedBy.toLowerCase().includes(potential);
						//var lastModifiedBy =  rowData.lastModifiedDate && rowData.lastModifiedDate.toLowerCase().includes(potential);
//						return hasMoreItems || name || modifiedBy /* || lastModifiedBy */;
						var stateProperty = view.context.options.stateProperty.get("value");

						var filterMatch = false;
						var columnSpecs = view._instance._columnSpecs;
						for (var i = 0; i < columnSpecs.length; i++) {
							var columnSpec = columnSpecs[i];
							// Filter can handle column property types for String, Integer and Date
							if (columnSpec.dataElementName != "_contextMenuButton" && (columnSpec.type == "Text" || columnSpec.type == "Integer" || columnSpec.type == "Date")) {
								var symbolicName = columnSpec.dataElementName;
								var value = rowData[symbolicName];
								if (value != null) {
									if (symbolicName == "ContentSize" ) { 
										value = self._formatSize(value, 2);
									} else if (columnSpec.type == "Date") {
										var dateOptions = {
											selector: "date",
											datePattern: this.defaultDatePattern
										};
										// If user has configured custom date pattern, use that for filtering
										if (columnSpec.options.datePattern  != null) {
											dateOptions.datePattern = columnSpec.options.datePattern;
										}
										value = dateLocale.format(new Date(value), dateOptions);
									} else if (symbolicName == stateProperty) {
										// This is status property set in config settings for capture applications
										if (isNaN(value)) {
											value = value == undefined ? "" : value;
										} else {
											value = messages["status_" + value];
										}
									}
									
									filterMatch = filterMatch || (value + "").toLowerCase().includes(potential);
								}
							}
						}
						return filterMatch;
					};
					view._instance.contentTable.search(searchRow, null, false, false);
				} else {
					// Put a delay up to 700ms between searches.
					if (view._instance.intervalTimer) {
						clearTimeout(view._instance.intervalTimer);
						delete view._instance.intervalTimer;
					}
					var self = this;
					view._instance.intervalTimer = setTimeout(function () {
						console.log("CS-ContentList:_filterContentList() : Searching for: " + potential);
						// Running in search mode, call search service to get real search results from server.
						self._getSearchResults(view, potential, null, null);
					}, 700);						
				}
			},
			
			_determineActionsMenuPopupVisibility: function(view) {
				if (view._instance.actions && view._instance.actions.chartMenu) {
					var isVisible = domClass.contains(view._instance.actions.chartMenu, "open");
					return isVisible;
				}
				return false;
			},

			_showHideActionsPopup: function(view, actionsButton, isVisible) {
				if (!isVisible) {
					// Clear the old actions menu and always recreate a new one (to have current access mask checking)
					if (view._instance.actions != null) {
						var wrapper = view._instance.actions.wrapper;
						var chartMenu = view._instance.actions.chartMenu;
						var chartMenuInner = view._instance.actions.chartMenuInner;
						var menuTbl = view._instance.actions.menuTbl;
						
						view.context.element.removeChild(wrapper);
						wrapper.removeChild(chartMenu);
						chartMenu.removeChild(chartMenuInner);
						chartMenuInner.removeChild(menuTbl);
						
						view._instance.actions = null;
					}
					
					view._instance.actions = view._instance.actions ? view._instance.actions : {};
					var chartDiv = document.body;
					
					if (!view._instance.actions || !view._instance.actions.wrapper) {
						var wrapper = view._instance.actions.wrapper = document.createElement("div");
						domClass.add(wrapper, "menu contextmenu");
						domAttr.set(wrapper, "role", "region");
						//wrapper.style.position = "relative";

						var chartMenu = view._instance.actions.chartMenu = document.createElement("div");
						domClass.add(chartMenu, "menu-inner bottom");

						var chartMenuInner = view._instance.actions.chartMenuInner = document.createElement("div");
						domAttr.set(chartMenuInner, "tabindex", -1);
						domClass.add(chartMenuInner, "chart-menu dropdown-menu DropDownMenu"); 

						chartMenu.appendChild(chartMenuInner);

						var menuTbl = view._instance.actions.menuTbl = document.createElement("table");
						domClass.add(menuTbl, "inner ContextMenu"); 
						domAttr.set(menuTbl, "role", "menu");

						// Create the real menu actions
						var firstAction = view._proto._populateActionsMenu(view); 
						
						chartMenuInner.appendChild(menuTbl);

						var actionsButtonElement = actionsButton.context.element;
						var self = this;
						
						var closeMenu = function(target) {
							setTimeout(function () {
								domClass.remove(chartMenu, "open");
								if (actionsButtonElement != null) {
									actionsButtonElement.children[0].focus(); // Need child button node for focus
									self._renderActionsButtonArrow(actionsButtonElement, false);
								}
							});
						};

						chartMenuInner.onblur = function(event) {
							event.stopPropagation();
							setTimeout(function () {
								if (!chartMenu.contains(document.activeElement)) {
									var target = event.target || event.srcElement;
									closeMenu(target);
								}
							}, 150);
						};

						// Setup the mouse events so we can click outside the context menu and have it close
						var overActionMenu = false;
						chartMenuInner.onmouseover = function(evt) {
							overActionMenu = true;
						};

						chartMenuInner.onmouseout = function(evt) {
							overActionMenu = false;
						};

						document.onmousedown = function(evt) {
							if (overActionMenu == false) {
								var isOpen = domClass.contains(chartMenu, "open");
								if (isOpen) {
									var target = event.target || evt.srcElement;
									closeMenu(target);
								}
							}
						};

						chartMenuInner.onkeydown = function(evt) {
							var keyID = (evt.charCode) ? evt.charCode : ((evt.which) ? evt.which : evt.keyCode);
							// Enter, Esc and Spacebar
							if (keyID == 27 || keyID == 13 || keyID == 32) {
								var target = event.target || event.srcElement;
								closeMenu(target);
							} else if (keyID == 9) { // Tab out of last item, should close the menu
								var classList = evt.srcElement.classList;
								for (var i = 0; i < classList.length; i++) {
									var className = classList[i];
									// If we are tabbing from the last action item in the menu, close it
									if (className == "LastMenuItem") {
										var target = event.target || event.srcElement;
										closeMenu(target);
										break;
									}
								}
							} else if (keyID == 40) { // Arrow down
								evt.preventDefault();
								var nextSibling = evt.srcElement.nextSibling;
								if (nextSibling != null) {
									nextSibling.focus();
								} else { // Cycle around to top
									var parentElement = evt.srcElement.parentElement;
									parentElement.firstElementChild.focus();
								}
							} else if (keyID == 38) { // Arrow up
								evt.preventDefault();
								var previousSibling = evt.srcElement.previousSibling;
								if (previousSibling != null) {
									previousSibling.focus();
								} else { // Cycle around to bottom
									var parentElement = evt.srcElement.parentElement;
									parentElement.lastElementChild.focus();
								}
							}
						};

						chartMenu.onclick = function() {
							var target = event.target || event.srcElement;
							closeMenu(target);
						};

						wrapper.appendChild(chartMenu);
						view.context.element.appendChild(wrapper);
					
						// Fix chart menu visibility behavior on chart data point click
						domClass.add(chartMenu, "open");
						this._positionActionsMenu(view, actionsButton.context.element, chartMenu, chartDiv);
						domClass.remove(chartMenu, "open");
					
						setTimeout(function () {
							domClass.add(chartMenu, "open");
							view._proto._positionActionsMenu(view, actionsButton.context.element, chartMenu, chartDiv);
							firstAction.focus(); // Set focus to first item in the context menu
							self._renderActionsButtonArrow(actionsButtonElement, true);
						}, 230);
					}
				} else {
					var chartMenu = view._instance.actions.chartMenu;
					var target = actionsButton.context.element;

					setTimeout(function () {
						domClass.remove(chartMenu, "open");
						target.focus();
					});
				}
			},
	
			_renderActionsButtonArrow: function(actionsButtonElement, opened) {
				var buttonNode = actionsButtonElement.children[0];
				var spanNode = buttonNode.children[0];
				if (spanNode != null) {
					if (opened) {
						domClass.remove(spanNode, "CS_AddButtonDown");
						domClass.add(spanNode, "CS_AddButtonUp");
						domStyle.set(spanNode, "transform", "rotate(180deg)");
					} else {
						domClass.remove(spanNode, "CS_AddButtonUp");
						domClass.add(spanNode, "CS_AddButtonDown");
						domStyle.set(spanNode, "transform", "rotate(0deg)");
					}
				}
			},
	
			_positionActionsMenu: function (view, target, chartMenu, chartDiv) {
				var rect = target.getBoundingClientRect();

				var xOffset = window.pageXOffset;
				var yOffset = window.pageYOffset;

				// This is initial guess of top/left of drop down menu location
				var left = rect.left;
				var top = rect.bottom;

				var right = rect.right; // button size	
				var bottom = top + chartMenu.scrollHeight; // Should be button size + menu height
	
				if (right > chartDiv.offsetWidth) {
					xOffset -= right - chartDiv.offsetWidth;
				}

				if (bottom > chartDiv.offsetHeight) {
					yOffset -= bottom - chartDiv.offsetHeight;
				}
			
				var menuTop = Math.max(0, top + yOffset);
				var menuLeft = Math.max(0, right + xOffset - chartMenu.scrollWidth);

				chartMenu.style.top = menuTop + "px";
				chartMenu.style.left = menuLeft + "px";
				chartMenu.style.position = "absolute";				
			},

			_populateActionsMenu: function(view) {
				view._instance.actions._ptMenuItems = [];

				// Check the configuration settings to see if actions have been disabled
				var hideAddDocument = view.context.options.hideAddDocument.get("value");
				var hideAddFolder = view.context.options.hideAddFolder.get("value");

				// Check to see which scenario we are running under (browse or search)
				var canAddToFolder = true;
				var folderId = view._instance.folderId;
				if (folderId != null) {
					// If running in browse mode, check the permissions on the parent folder
					var contentItem = view._instance.rootFolder;
					if (view._instance.currentParentFolder != null) {
						contentItem = view._instance.currentParentFolder;
					}
					if (contentItem) {
						canAddToFolder = (contentItem.accessAllowed & this.privilegeToBitmask["privAddToFolder"]) > 0;
					} else {
						canAddToFolder = false;
					}
				}
						
				if (!hideAddDocument) {
					var onclick = function() {
						view._proto._onAddActionClicked(view, view._proto.actions.addDocument);
					};
					this._addMenuAction(view, view._instance.actions._ptMenuItems, "Add Document", null, messages.contlist_menu_action_add_doc, "", onclick, canAddToFolder);
				}
				
				if (!hideAddFolder) {
					var onclick = function(){
						view._proto._onAddActionClicked(view, view._proto.actions.addFolder);
					};
					this._addMenuAction(view, view._instance.actions._ptMenuItems, "Add Folder", null, messages.contlist_menu_action_add_folder, "", onclick, canAddToFolder);
				}
		
				// Setup and send out the open actions menu event
				console.log("CS-ContentList:_populateActionsMenu() : On actions menu open event being fired.");
				var folder = view._instance.currentParentFolder;
				bpmext.ui.executeEventHandlingFunction(view, this.EVT_ONACTIONMENUOPEN, view._instance.actions._ptMenuItems, folder);
		
				return this._populateMenuCategory(view, view._instance.actions._ptMenuItems, view._instance.actions.menuTbl);
			},
	
			_determineContextMenuPopupVisibility: function(view, cell) {
				if (view._instance.menu && view._instance.menu && view._instance.menu.chartMenu) {
					var isVisible = domClass.contains(view._instance.menu.chartMenu, "open");
					return isVisible;
				}
				return false;
			},
	
			_showHideContextMenuPopup: function(view, cell, isVisible) {
				if (!isVisible) {
					// Clear the old context menu and always recreate a new one (to have current state and access mask checking)
					if (view._instance.menu != null) {
						// Get the context menu open button div and change the style 
						var ctxMenuButtonDiv = view._instance.ctxMenuButtonDiv;
						if (ctxMenuButtonDiv != null) {
							domClass.remove(ctxMenuButtonDiv, "bx--overflow-menu-hold");
						}

						var wrapper = view._instance.menu.wrapper;
						var chartMenu = view._instance.menu.chartMenu;
						var chartMenuInner = view._instance.menu.chartMenuInner;
						var menuTbl = view._instance.menu.menuTbl;

						chartMenuInner.removeChild(menuTbl);
						menuTbl = null;
						chartMenu.removeChild(chartMenuInner);
						chartMenuInner = null;
						wrapper.removeChild(chartMenu);
						chartMenu = null;
						view.context.element.removeChild(wrapper);
						wrapper = null;
						
						view._instance.menu = null;
					}
					
					view._instance.menu = {};
					var chartDiv = document.body;
					
					var wrapper = view._instance.menu.wrapper = document.createElement("div");
					domClass.add(wrapper, "menu contextmenu");
					domAttr.set(wrapper, "data-overflow-menu", "");
					domAttr.set(wrapper, "role", "region");

					var chartMenu = view._instance.menu.chartMenu = document.createElement("div");
					domClass.add(chartMenu, "menu-inner bottom");

					var chartMenuInner = view._instance.menu.chartMenuInner = document.createElement("div");
					domAttr.set(chartMenuInner, "tabindex", -1);
					domClass.add(chartMenuInner, "chart-menu dropdown-menu DropDownMenu"); 

					chartMenu.appendChild(chartMenuInner);

					var menuTbl = view._instance.menu.menuTbl = document.createElement("table");
					domClass.add(menuTbl, "inner ContextMenu"); 
					domAttr.set(menuTbl, "role", "menu");

					// Create the real menu actions
					var firstAction = view._proto._populateContextMenu(view, cell); 
					
					chartMenuInner.appendChild(menuTbl);

					var closeMenu = function(target) {
						setTimeout(function () {
							domClass.remove(chartMenu, "open");
//							target.focus();
							view._proto._showHideContextMenuButton(target, false);
						});
					};

					chartMenuInner.onblur = function(event) {
						event.stopPropagation();
						setTimeout(function () {
							if (!chartMenu.contains(document.activeElement)) {
								var target = event.target || event.srcElement;
								closeMenu(target);
							}
						}, 150);
					};

					// Setup the mouse events so we can click outside the context menu and have it close
					var overMenu = false;
					chartMenuInner.onmouseover = function(evt) {
						overMenu = true;
					};

					chartMenuInner.onmouseout = function(evt) {
						overMenu = false;
					};

					document.onmousedown = function(evt) {
						if (overMenu == false) {
							var target = event.target || evt.srcElement;
							closeMenu(target);
						}
					};
					
					chartMenuInner.onkeydown = function(evt) {
						var keyID = (evt.charCode) ? evt.charCode : ((evt.which) ? evt.which : evt.keyCode);
						// Esc, Enter and Spacebar
						if (keyID == 27 || keyID == 13 || keyID == 32) {
							var target = event.target || event.srcElement;
							closeMenu(target);
						} else if (keyID == 9) { // Tab out of last item, should close the menu
							var classList = evt.srcElement.classList;
							for (var i = 0; i < classList.length; i++) {
								var className = classList[i];
								// If we are tabbing from the last action item in the menu, close it
								if (className == "LastMenuItem") {
									var target = event.target || event.srcElement;
									closeMenu(target);
									break;
								}
								if (evt.shiftKey && className == "FirstMenuItem") {
									var target = event.target || event.srcElement;
									closeMenu(target);
									break;
								}
							}
						} else if (keyID == 40) { // Arrow down
							evt.preventDefault();
							var nextSibling = evt.srcElement.nextSibling;
							if (nextSibling != null) {
								if (nextSibling.className == "mnTrSeparator") {
									nextSibling = nextSibling.nextSibling;
								}
								nextSibling.focus();
							} else { // Cycle around to top
								var parentElement = evt.srcElement.parentElement;
								parentElement.firstElementChild.focus();
							}
						} else if (keyID == 38) { // Arrow up
							evt.preventDefault();
							var previousSibling = evt.srcElement.previousSibling;
							if (previousSibling != null) {
								if (previousSibling.className == "mnTrSeparator") {
									previousSibling = previousSibling.previousSibling;
								}
								previousSibling.focus();
							} else { // Cycle around to bottom
								var parentElement = evt.srcElement.parentElement;
								parentElement.lastElementChild.focus();
							}
						}
					};

					chartMenu.onclick = function() {
						var target = event.target || event.srcElement;
						closeMenu(target);
					};

					wrapper.appendChild(chartMenu);
					view.context.element.appendChild(wrapper);

					var event = view._instance.event;

					// Fix chart menu visibility behavior on chart data point click
					domClass.add(chartMenu, "open");
					this._positionContextMenu(view, event, chartMenu, chartDiv);
					domClass.remove(chartMenu, "open");
					
					var cellData = cell.row.data;
					if (cellData) {
						setTimeout(function () {
							domClass.add(chartMenu, "open");
							view._proto._positionContextMenu(view, event, chartMenu, chartDiv);
							if (firstAction) {
								firstAction.focus(); // Set focus to first item in the context menu
							}
						}, 230);
					}
				} else {
					var chartMenu = view._instance.menu.chartMenu;
					var event = view._instance.event;
					var target = event.target || event.srcElement;

					setTimeout(function () {
						domClass.remove(chartMenu, "open");
//						target.focus();
						view._proto._showHideContextMenuButton(target, false);
					});
				}
			},
	
			_showHideContextMenuButton: function(target, display) {
				var parNode = target;
				if (parNode.nodeName == "IMG") {
					parNode = target.parentNode
				}
				
				if (display) {
					domClass.add(parNode, "bx--overflow-menu-hold");
				} else {
					domClass.remove(parNode, "bx--overflow-menu-hold");
				}
			},
			
			_positionContextMenu: function(view, event, chartMenu, chartDiv) {
				var target = event.target || event.srcElement;
				var rect = target.getBoundingClientRect();

				// Create the "fudge" factors for the context menu open button (depends on event target object)
				var rightFudge = 0;
				var topFudge = -2;
				if (target.nodeName == "IMG") {
					rightFudge = 6;
					topFudge = 6;
				}
				
				var xOffset = window.pageXOffset;
				var yOffset = window.pageYOffset;

				// This is initial guess of top/left of drop down menu location
				var left = rect.left;
				var top = rect.bottom + topFudge;
//				var right = left + chartMenu.scrollWidth;
				var right = rect.right + rightFudge;
				var bottom = top + chartMenu.scrollHeight;

				if (right > chartDiv.offsetWidth) {
					if (view._instance.isFirefox) {
						xOffset -= right - chartDiv.offsetWidth + 1;
					} else {
						xOffset -= right - chartDiv.offsetWidth - 1;
					}
				}

				if (bottom > chartDiv.offsetHeight) {
					yOffset -= bottom - chartDiv.offsetHeight;
					// negative offset is up and will cover ellipses button, move left a little bit
					if (view._instance.isChrome) {
						xOffset -= 18;  // Not sure why Chrome is soo far off in this regard
					} else {
						xOffset -= 32;
					}
				}
//				console.log("_positionContextMenu(): bottom: " + bottom + " chartDiv.offsetHeight: " + chartDiv.offsetHeight + " yOffset: " + yOffset);

				var menuTop = Math.max(0, top + yOffset);
				var menuLeft = Math.max(0, right + xOffset - chartMenu.scrollWidth); // below and aligned with right side

				chartMenu.style.top = menuTop + "px";
				chartMenu.style.left = menuLeft + "px";
				chartMenu.style.position = "absolute";
			},
	
			_enableActionsCustomHandler: function(view, cellData) {
				var enabled = true;
				var stateProperty = view.context.options.stateProperty.get("value");
				if (stateProperty != null) {
					var properties = cellData.contentItem.properties.items ? cellData.contentItem.properties.items : cellData.contentItem.properties;
					const property = properties.filter(property => property.id === stateProperty);
					if (property != null && property.length > 0) {
						var value = property[0].value; // filter returns a list, so need to grab first item
						if (value != null) {
							if (disabledValues){
								var disabledValues = view.context.options.disabledValues.get("value");
								if (disabledValues.items) {
									disabledValues = disabledValues.items;
								}
								for (var i = 0; i < disabledValues.length; i++) {
									if (value === disabledValues[i] || value.toString() === disabledValues[i]) {
										enabled = false;
										break;
									}
								}
							}
						}
					}
				}
				return enabled;
			},
	
			_populateContextMenu: function(view, cell) {
				var cellData = cell.row.data;
				view._instance.menu._ptMenuItems = [];
				view._instance.lastActionRow = cell.row;
				
				var type = this._getType(cellData.contentItem);
				if (type == this.typeFolder) {
					// Check the configuration settings to see if actions have been disabled
					var hideRenameFolder = view.context.options.hideRenameFolder.get("value");
					var hideEditFolderProperties = view.context.options.hideEditFolderProperties.get("value");
					var hideDeleteFolder = view.context.options.hideDeleteFolder.get("value");

					var canEditProperties = true; // Always display as enabled, property dialog may open as read only though
					var canDelete = (cellData.contentItem.accessAllowed & this.privilegeToBitmask["privDelete"]) > 0;

					var onclick = function(){
						view._proto._onFolderClick(view, cell.row);
					};
					this._addMenuAction(view, view._instance.menu._ptMenuItems, "Open", null, messages.contlist_menu_action_open, "", onclick, true);

					if (!hideRenameFolder) {
						var onclick = function() {
							view._proto._onFolderRename(view, cellData);
						};
						var canRenameFolder = (cellData.contentItem.accessAllowed & this.privilegeToBitmask["privEditProperties"]) > 0;
						this._addMenuAction(view, view._instance.menu._ptMenuItems, "Rename", null, messages.contlist_menu_action_rename, "", onclick, canRenameFolder);
					}

					if (!hideEditFolderProperties) {
						var onclick = function() {
							view._proto._onProperties(view, cellData);
						};
						this._addMenuAction(view, view._instance.menu._ptMenuItems, "Properties", null, messages.contlist_menu_action_properties, "", onclick, canEditProperties);
					}
					
					if (!hideDeleteFolder) {
						var onclick = function(){
							view._proto._onDeleteObject(view, cellData);
						};
						this._addMenuAction(view, view._instance.menu._ptMenuItems, "Delete Folder", null, messages.contlist_menu_action_delete_folder, "", onclick, canDelete);
					}
				} else if (type == this.typeDocument) { 
					// Check the configuration settings to see if actions have been hidden
					var hideViewDocument = view.context.options.hideViewDocument.get("value");
					var hideUploadNewVersionDocument = view.context.options.hideUploadNewVersionDocument.get("value");
					var hideDownloadDocument = view.context.options.hideDownloadDocument.get("value");
					var hideEditDocument = view.context.options.hideEditDocument.get("value");
					var hideCheckoutDocument = view.context.options.hideCheckoutDocument.get("value");
					var hideCancelCheckoutDocument = view.context.options.hideCancelCheckoutDocument.get("value");
					var hideEditDocumentProperties = view.context.options.hideEditDocumentProperties.get("value");
					var hideDeleteDocument = view.context.options.hideDeleteDocument.get("value");
					
					// Check the access mask settings to see if actions should be disabled (greyed out)
					var canViewDoc = (cellData.contentItem.accessAllowed & this.privilegeToBitmask["privViewDoc"]) > 0;
					var canViewProperties = canViewDoc;
					if (canViewDoc) {
						// Check the mime type for being a no content element type document
						if (cellData.contentItem.mimeType == null) {
							canViewDoc = false;
						}
					}
					var canMajorVersion = (cellData.contentItem.accessAllowed & this.privilegeToBitmask["privMajorVersion"]) > 0;
					var canMinorVersion = (cellData.contentItem.accessAllowed & this.privilegeToBitmask["privMinorVersion"]) > 0;
					var canDelete = (cellData.contentItem.accessAllowed & this.privilegeToBitmask["privDelete"]) > 0;
		
					var isReserved = cellData.contentItem.isReserved;
					var actionsEnabled = this._enableActionsCustomHandler(view, cellData);

					if (!hideViewDocument){
						var onclick = function(){
							view._proto._viewDocument(view, cellData);
						};
						this._addMenuAction(view, view._instance.menu._ptMenuItems, "View", null, messages.contlist_menu_action_view, "", onclick, actionsEnabled && canViewDoc);
					}
					if (!hideUploadNewVersionDocument) {
						// Todo: if the document is already checked out, check if it's the current logged in user
						var canUploadNewVersion = canMajorVersion || canMinorVersion; 
						var onclick = function() {
							view._proto._onUploadVersion(view, cellData);
						};
						this._addMenuAction(view, view._instance.menu._ptMenuItems, "Upload New Version", null, messages.contlist_menu_action_upload, "", onclick, actionsEnabled && canUploadNewVersion);
					}
					if (!hideDownloadDocument) {
						var onclick = function(){
							view._proto._downloadDocument(view, cellData);
						};
						this._addMenuAction(view, view._instance.menu._ptMenuItems, "Download", null, messages.contlist_menu_action_download, "", onclick, actionsEnabled && canViewDoc);
					}
					if (!hideCheckoutDocument) {
						var canCheckout = !isReserved && (canMajorVersion || canMinorVersion); // Not checked out already and have permission to version
						
						var onclick = function() {
							view._proto._onCheckoutDocument(view, cellData);
						};
						this._addMenuAction(view, view._instance.menu._ptMenuItems, "Check Out", null, messages.contlist_menu_action_checkout, "", onclick, actionsEnabled && canCheckout); 
					}
					if (!hideEditDocument) {
						// This is really the Checkout and Download action
						var canEdit = !isReserved && (canMajorVersion || canMinorVersion); // have permission to version
						
						var onclick = function() {
							view._proto._onEditDocument(view, cellData);
						};
						this._addMenuAction(view, view._instance.menu._ptMenuItems, "Edit Document", null, messages.contlist_menu_action_edit_document, "", onclick, actionsEnabled && canEdit);
					}
					if (!hideCancelCheckoutDocument) {
						// Is checked out already and is same user that checked out the document in the first place
						var canCancel = isReserved; 
						// Need to check to see if current logged in user is the one who has the document checked out
						var isCurrentUser = this._isCurrentUserCheckout(view, cellData.contentItem);
						if (!isCurrentUser) {
							canCancel = false;
						}
					
						var onclick = function() {
							view._proto._onCancelCheckout(view, cellData);
						};
						this._addMenuAction(view, view._instance.menu._ptMenuItems, "Cancel Check Out", null, messages.contlist_menu_action_cancel_checkout, "", onclick, actionsEnabled && canCancel);
					}
//						if (!hideRemoveFromFolder) {
//							var onclick = function(){
//								view._proto._onRemoveDocumentFromFolder(view, cellData);
//							};
//							this._addMenuAction(view, view._instance.menu._ptMenuItems, "Remove from folder", "minus-circle", "Remove from folder", "", onclick);
//						}
					if (!hideEditDocumentProperties){
						var onclick = function() {
							view._proto._onProperties(view, cellData);
						};
						this._addMenuAction(view, view._instance.menu._ptMenuItems, "Properties", null, messages.contlist_menu_action_properties, "", onclick, actionsEnabled && canViewProperties);
					}
					if (!hideDeleteDocument) {
						var onclick = function() {
							view._proto._onDeleteObject(view, cellData);
						};
						this._addMenuAction(view, view._instance.menu._ptMenuItems, "Delete Document", null, messages.contlist_menu_action_delete_doc, "", onclick, actionsEnabled && canDelete);
					}
				} else if (type == this.typeAbstract) {
//					var hideEditAbstractProperties = view.context.options.hideEditAbstractProperties.get("value");
					var hideEditAbstractProperties = false;
//					var hideDeleteAbstract = view.context.options.hideDeleteAbstract.get("value");
					var hideDeleteAbstract = false;
					var canViewProperties = true; // Always display as enabled, property dialog may open as read only though
//					var canDelete = (cellData.contentItem.accessAllowed & this.privilegeToBitmask["privDelete"]) > 0;
					var canDelete = true;

					if (canDelete) {
						var properties = cellData.contentItem.properties.items ? cellData.contentItem.properties.items : cellData.contentItem.properties;
						var propBatchStatus = properties.find(property => property.id == "DbaBatchStatus");
						if (propBatchStatus) {
							var batchStatus = propBatchStatus.value;
							if (batchStatus == 300 || batchStatus == 305) {
								canDelete = false;
							}
						}
					}
					
					if (canViewProperties) {
						var propLeaseTime = properties.find(property => property.id == "DbaLeaseTime");
						if (propLeaseTime) {
							var leaseTime = new Date(propLeaseTime.value); // value is a string
							var rightNow = new Date();
							if (leaseTime.getTime() > rightNow.getTime()) {
								canViewProperties = false;
							}
						}
					}

					if (!hideEditAbstractProperties){
						var onclick = function() {
							view._proto._onProperties(view, cellData);
						};
						this._addMenuAction(view, view._instance.menu._ptMenuItems, "Properties", null, messages.contlist_menu_action_properties, "", onclick, canViewProperties);
					}
					if (!hideDeleteAbstract) {
						var onclick = function(){
							view._proto._onDeleteObject(view, cellData);
						};
						this._addMenuAction(view, view._instance.menu._ptMenuItems, "Delete", null, messages.contlist_menu_action_delete, "", onclick, canDelete);
					}
				}
				
				// Setup and send out the open context menu event
				console.log("CS-ContentList:_populateContextMenu() : On context menu open event being fired.");
				view._instance.cellData = cellData;
				view._instance.cellData.contentItem.rowIndex = cell.row.index;
				bpmext.ui.executeEventHandlingFunction(view, this.EVT_ONCONTEXTMENUOPEN, view._instance.menu._ptMenuItems, cellData.contentItem);

				return this._populateMenuCategory(view, view._instance.menu._ptMenuItems, view._instance.menu.menuTbl);
			},

			_isCurrentUserCheckout: function(view, contentItem) {
				var isCurrentUser = false;
				// Need to check to see if current logged in user is the one who has the document checked out
				if (contentItem.reservation && contentItem.reservation.creator) {
					var reservationUser = contentItem.reservation.creator;
					// NOTE: The following call only works if running in ICN in platform mode
					var currentUser = this._getUserId(view);
					if (currentUser != null && reservationUser == currentUser) {
						isCurrentUser = true;
					}
				}
				return isCurrentUser;
			},
		
			_createClickFunction: function(callback) {
				return function(evt) {
					if (evt.type == "keydown") {
						var keyID = (evt.charCode) ? evt.charCode : ((evt.which) ? evt.which : evt.keyCode);
						if (keyID == 13 || keyID == 32) {
							evt.preventDefault();
							callback();
						}
					} else {
						callback();
					}
				};
			},
			
			_addMenuAction: function (view, actions, actionId, icon, text, badgeText, onclickFn, isEnabled) {
				var action = {	
					actionId: actionId,
					icon: icon,
					text: text,
					badgeText: badgeText,
					isEnabled: isEnabled
				};
				
				if (isEnabled) {
					action.onclick = this._createClickFunction(onclickFn);
				}
				
				actions.push(action);
			},
			
			_populateMenuCategory: function (view, actions, table) {
				var firstTr;
				// Add the actions to a html table for rendering the context menu
				for (var i = 0; i < actions.length; i++) {
					var action = actions[i];
					
					if (action.actionId == "__separator") {
						var tr = document.createElement("tr");
						tr.tabIndex = -1;
						domClass.add(tr, "mnTrSeparator");
						table.appendChild(tr);

						var td = document.createElement("td");
						domClass.add(td, "mnSeparator");
						tr.appendChild(td);
					} else {
						var tr = document.createElement("tr");
						tr.tabIndex = 0;
						domAttr.set(tr, "role", "menuitem");
						domAttr.set(tr, "aria-label", action.text);
						table.appendChild(tr);
						
						var td = document.createElement("td");
						domAttr.set(td, "role", "presentation");
						tr.appendChild(td);

						if (action.isEnabled) {
							domClass.add(tr, "mnTextItem ContextMenuRow");
						} else {
							domClass.add(tr, "mnTextItem RowDisabled");
							domAttr.set(tr, "aria-disabled", "true");
						}
						// Add "marker" css class to indicate that this is the last action item in the menu
						if (i == actions.length - 1) {
							domClass.add(tr, "LastMenuItem");
						} else if (i == 0) {
							domClass.add(tr, "FirstMenuItem");
						}
						
						domClass.add(td, "mnLabel");

						var a = document.createElement("a");
						a.tabIndex = -1;
						domClass.add(a, "mnItem");

						a.href = "javascript:void(0)";
						if (action.actionId !== null && action.actionId.length > 0) {
							domAttr.set(a, "data-action-id", action.actionId);
						}
						
						if (action.icon != null && action.icon.length > 0) {
							var icon = document.createElement("i");
							var ic = bpmext.text.startsWith(action.icon, "fa-") ? action.icon : "fa-" + action.icon;

							domClass.add(icon, "dropdown-icon fa " + ic);
							a.appendChild(icon);
						}

						var txt = document.createTextNode(action.text);
						a.appendChild(txt);
						td.appendChild(a);

						if (action.isEnabled) {
							if (action.onclick) {
								tr.onclick = action.onclick;
								tr.onkeydown = action.onclick;
							} else {
								view._proto._setMenuClickAction(view, tr, action);
							}
						}
					}
					
					table.appendChild(tr);
					
					if (i == 0) {
						firstTr = tr;
					}
				}

				return firstTr;
			},
			
			_setMenuClickAction: function (view, element, actionItem) {
				element.onclick = function (evt) {
					if (actionItem.onclick) {
						actionItem.onclick.call(view, actionItem);
					}
				}
			},
	
			_viewDocument: function(view, cellData, callback) {
	
				var needToOpenWindow = true;
				var title = this._getWindowTitle(cellData.contentItem);
				// Check to see if this document is already opened in a viewer popup window
				if (view._instance._openDocumentWindows && view._instance._openDocumentWindows[title]) {
					if (view._instance._openDocumentWindows[title].window && !view._instance._openDocumentWindows[title].window.closed) {
						view._instance._openDocumentWindows[title].window.focus();
						needToOpenWindow = false;
					}
				}
				
				if (needToOpenWindow) {
					var contextRoot;
					var desktop = "default";
	
					var navUrl = window.location.href;
					
					var params = navUrl.split("&");
					for (var i = 0; i < params.length; i++) {
						var param = params[i].split("=");
						if (param[0] == "contextRoot") {
							var contextRootParam = decodeURIComponent(param[1]);
							// Still need to trim back to base Url part of this string
							var base = contextRootParam.split("?");
							var contextRoot = base[0];
							if (contextRoot[contextRoot.length - 1] != "/") {
								contextRoot += "/";
							}
						} else if (param[0] == "desktop") {
							// switch over to real desktop that is specified on url
							desktop = decodeURIComponent(param[1]);
						}
					}

					if (contextRoot != null) {
						var objectStoreName = this._getObjectStoreName(view);
						var id = cellData.contentItem.id;
						var className = cellData.contentItem.className;
						var mimeType = cellData.contentItem.mimeType;
						
						var docUrl = contextRoot + "bookmark.jsp?desktop=" + desktop;
						docUrl += "&objectStoreName=" + encodeURIComponent(objectStoreName);
						docUrl += "&repositoryType=p8";
						docUrl += "&docid=" + encodeURIComponent(id);
						docUrl += "&template_name=" + encodeURIComponent(className);
						docUrl += "&mimeType=" + encodeURIComponent(mimeType);
						docUrl += "&embedded=true";
						docUrl += "&hideToolbar=true"; // Hide the viewer containers banner bar (toolbar)
						
						var width = 860;
						var height = 600;
				
						var left = (screen.width - width) / 2;
						var top = (screen.height - height) / 2;
						
						var windowParams = "status=yes,location=no,scrollbars=yes,menubar=no,toolbar=no,personalbar=no,resizable=yes,left=" + left + ",top=" + top + ",width=" + width + ",height=" + height;
						
						var documentWindow = window.open(docUrl, title, windowParams); 
						view._instance._openDocumentWindows[title] = {
							window: documentWindow,
							callback: callback,  // Currently not used
							item: cellData.contentItem
						};
					} else {
						// No context root means we are running in test mode, display a alert message
						console.log("CS-ContentList:_viewDocument() : Running in test mode, no viewer will be displayed.");
						this._setAlertMessage(view, messages.contentviewer_test_mode, true, 6000);	
					}
				}
			},

			_getWindowTitle: function(contentItem) {
				var id = contentItem.id;
				var title = "file_" + id.replace(/[{,\-,},.,~,\t,\/]/g, "");  // Remove some characters that can not be used in a window title
				return title;
			},
			
			_downloadDocument: function(view, cellData) {
				domStyle.set(view.context.element, "cursor", "wait"); 
				// Make call into get content componet to download the file contents to the browser (type = "file")
				view._instance.getContent.getContent(cellData.contentItem, "file", function() {
					// Don't display a success message, browser will do that
					domStyle.set(view.context.element, "cursor", "auto"); 
				}, function(error) {
					domStyle.set(view.context.element, "cursor", "auto"); 
					var errorText = error && error.errorText ? error.errorText : "";
					var errorMessage = string.substitute(messages.contlist_download_failed, [errorText]);
					view._proto._setAlertMessage(view, errorMessage, true);		
				});
			},
	
			_onProperties: function(view, cellData) {
				view._instance.lastActionData = cellData;
				
				var type = this._getType(cellData.contentItem);
				if (type == this.typeFolder) {
					this._showHidePropertiesModal(view, true, this.actions.folderProperties);
				} else if (type == this.typeDocument) {
					this._showHidePropertiesModal(view, true, this.actions.documentProperties);
				} else {
					this._showHidePropertiesModal(view, true, this.actions.abstractProperties);
				}
			},
			
			_showHidePropertiesModal: function (view, isVisible, actionName) {
				view._instance.propertiesModal = view.ui.get("PropertiesModal");
				view._instance.propertiesPanel = view.ui.get("PropertiesPanel");
				view._instance.propertiesTable = view.ui.get("PropertiesTable");
				view._instance.savePropertiesBtn = view.ui.get("PropertiesSaveButton");
				view._instance.actionName = actionName;
				
				var objectType = this.typeDocument;
				view._instance.propertiesModal.setVisible(isVisible);
				view._instance.propertiesTable.setVisible(isVisible);			
				if (isVisible == true) {
					view._instance.propertiesTable.setIncludeTimePicker(view.context.options.includeTimePicker.get("value"));
					view._instance.propertiesTable.setServerConfigurationName(view._instance.serverConfigurationName);
					view._instance.propertiesTable.setObjectStoreName(this._getObjectStoreName(view));
					
					view._instance.savePropertiesBtn.setVisible(true);
					view._instance.savePropertiesBtn.setEnabled(true);
					
					var contentItem = view._instance.lastActionData.contentItem;
					
					var label = '';
					if (actionName == this.actions.documentProperties) {
						label = messages.contlist_document_properties;
					} else if (actionName == this.actions.folderProperties) {
						label = messages.contlist_folder_properties;
						objectType = this.typeFolder;
					} else{
						objectType = this.typeAbstract;
						if (contentItem.className == "DbaClassificationBatch"){
							label = messages.contlist_batch_properties;
						} else {
							label = messages.contlist_abstract_properties;
						}
					}
					view._instance.propertiesPanel.context.options._metadata.label.set('value', label);
					


					var _self = this;
					var canEditProperties = view.canEditProperties(contentItem);
					view._instance.propertiesTable.setReadOnly(!canEditProperties);
					this._setPropertyListMaxHeight(view, view._instance.propertiesModal, view._instance.propertiesTable);
					view._instance.propertiesTable.displayProperties(contentItem.id, contentItem.className, objectType, null, function(error){
						var errorText = error ? error : "";
						var errMessage = string.substitute(messages.contlist_display_properties_failed, [errorText]);
						_self._setModalAlertMessage(view, view._instance.propertiesAlert, "PropertiesAlert", errMessage, true);
					});
				}
				else {
					view._instance.propertiesTable.clear();
				}	
			},
			
			_setPropertyListMaxHeight: function(view, modalSection, propertyList){
				var modalContent = modalSection.context.element.querySelector(".modal-dialog");
				var modalHeight = modalContent.offsetHeight;
				var modalStyle = window.getComputedStyle(modalContent);
				modalHeight += (parseInt(modalStyle.getPropertyValue('margin-top')) + parseInt(modalStyle.getPropertyValue('margin-bottom')));
				
				var parentHeight = view.context.element.offsetHeight;
				var parentStyle = window.getComputedStyle(view.context.element);
				parentHeight += (parseInt(parentStyle.getPropertyValue('margin-top')) + parseInt(parentStyle.getPropertyValue('margin-bottom')));
				
				var availableHeight = window.innerHeight < parentHeight ? window.innerHeight : parentHeight;
				availableHeight -= (modalHeight - propertyList.context.element.clientHeight);
				domStyle.set(propertyList.context.element, "max-height", availableHeight + "px");
			}, 

			_onSavePropertiesBtnClicked: function(view) {
				var self = this;
				view._instance.propertiesTable = view.ui.get("PropertiesTable");

				var contentItem = view._instance.lastActionData.contentItem;
				var properties = contentItem.properties.items ? contentItem.properties.items : contentItem.properties;
				var returnProperties = [];
				var objectProperties = [];
				properties.forEach(function(property) {
					returnProperties.push(property.id);
					if (property.objectValue) {
						var ovpProperties = property.objectValue.properties.items ? property.objectValue.properties.items : property.objectValue.properties;
						ovpProperties.forEach(function(objectProperty) {
							objectProperties.push(objectProperty.id);
						});
					}
				});			
				
				var isValid = view._instance.propertiesTable.save(returnProperties, objectProperties, true, function(properties) {
					self._showHidePropertiesModal(view, false, '');
					self._setAlertMessage(view, messages.contlist_save_props_success, false);

					// Update row in list view and don't refresh whole list
					var selectedRow = view._instance.lastActionRow;

					var contentItemAction = view._instance.lastActionData.contentItem;
					var contentItemBinding = view.context.binding.boundObject.contentItem;	
					if (contentItemBinding != null && contentItemAction.id == contentItemBinding.id) {
						contentItemBinding.properties = properties;
						self._setBindingObject(view, selectedRow, contentItemBinding, false, false); // Will force a call to _refreshTableRow
					}
					self._refreshTableRow(view, view._instance.actionName, selectedRow.index, properties, null, null);
				}, function(errorText) {
					// Show error in an alert box at top of properties dialog
					self._setModalAlertMessage(view, view._instance.propertiesAlert, "PropertiesAlert", messages.contlist_save_props_failed, true);
					view._instance.savePropertiesBtn.setEnabled(true);
				});

				if (isValid){
					view._instance.savePropertiesBtn.setEnabled(false);
				} else {
					// There was a validation problem and save call never made
					// Todo: should we display a message or are the controls themselves enough?
				}
			},
			
			_onUpdateProperties: function(view, contentItem) {
				// Need to convert the properties into a format that can be sent to update properties action service
				var properties = contentItem.properties.items ? contentItem.properties.items : contentItem.properties;
				if (properties) {
					var propertyValues = "[";
					for (var i = 0; i < properties.length; i++) {
						var property = properties[i];
						if (property.cardinality == "SINGLE") {
							if (property.dataType == "STRING" || property.dataType == "GUID") {
								var sanitizedValue = property.value;
								if (property.value != null) {
									sanitizedValue = property.value.replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/\t/g,'\\t').replace(/"/g,'\\"');
								}
								propertyValues += "{" + property.id + " : \"" + sanitizedValue + "\"}";
							} else if (property.dataType == "DATE") {
								var dateValue = new Date(property.value);
								propertyValues += "{" + property.id + " : \"" + dateValue.toISOString() + "\"}";
							} else {
								propertyValues += "{" + property.id + " : " + property.value + "}";
							}
						} else if (property.cardinality == "LIST") {
							propertyValues += "{" + property.id + ": [";
							var values = property.value.items ? property.value.items : property.value;
							for (var j = 0; j < values.length; j++) {
								var value = values[j];
								if (property.dataType == "STRING" || property.dataType == "GUID") {
									var sanitizedValue = value;
									if (value != null) {
										sanitizedValue = value.replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/\t/g,'\\t').replace(/"/g,'\\"');
									}
									propertyValues += "\"" + sanitizedValue + "\"";
								} else if (property.dataType == "DATE") {
									var dateValue = new Date(value);
									propertyValues += "\"" + dateValue.toISOString() + "\"";
								} else {
									propertyValues += value;
								}
								
								if (j < values.length - 1) {
									propertyValues += ", ";
								}
							}
							propertyValues +="]}";
						}
						
						if (i < properties.length - 1) {
							propertyValues += ", ";
						}
					}
					propertyValues += "]";
					
					var params = {
						objectType: contentItem.baseType,
						objectId: contentItem.id,
						classId: contentItem.className,
						properties: propertyValues,
						repository: this._getObjectStoreName(view),
						serverAppResource: view._instance.serverConfigurationName
					};
					
					// Need to make the call to update the properties on the specified content item
					view._instance.updatePropertiesSvc = view.ui.get("UpdatePropertiesSvc");
					this._callService(view._instance.updatePropertiesSvc, params);
				}
			},
			
			// Todo: merge last four parameters into contentItem and just pass that
			_refreshTableRow: function(view, actionName, rowIndex, properties, id, contentElements, contentItem) {
				console.log("CS-ContentList:_refreshTableRow() called");
				var rowRecord = null;
				if (id == null) {
					// Use the passed in index to find the record item
					rowRecord = view._instance.contentTable.getRecord(rowIndex, false);
				} else {
					// Search for the record in the list using the id
					var records = view._instance.contentTable.getRecords(true);
					if (records && records.length) {
						for (var i = 0; i < records.length; i++) {
							var record = records[i];
							if (record.contentItem.id == id) {
								rowRecord = record;
								break;
							}
						}
					}
				}
				// If can't find the row record, just return (can't update anything)
				if (rowRecord == null) {
					return;
				}
				
				var columnSpecs = view._instance._columnSpecs;
				var id = "";
				rowRecord.contentItem.isReserved = false;

				var pseudoSymName = "DocumentTitle";
				if (this._getType(rowRecord.contentItem) == this.typeFolder) {
					pseudoSymName = "FolderName";
				} else if (this._getType(rowRecord.contentItem) == this.typeAbstract) {
					pseudoSymName = "Name";
				}
	
				properties = properties.items ? properties.items : properties;
				
				for (var i = 0; i < columnSpecs.length; i++) {
					var columnSpec = columnSpecs[i];
					if (columnSpec.dataElementName != "_contextMenuButton") {
						var cspecSymbolicName = columnSpec.dataElementName;
						for (var j = 0; j < properties.length; j++) {
							var property = properties[j];
							if (cspecSymbolicName == "name" || cspecSymbolicName == "Name") {
								// Special case handling for the main column "name" property
								if (property.id == "name" || property.id == "Name") {
									rowRecord[cspecSymbolicName] = property.value;
									// Make sure the primary name property on the content item is updated
									rowRecord.contentItem.name = property.value;
									break;
								} else if (property.id == pseudoSymName) {
									// If the property is one of the specialized name properties
									rowRecord[cspecSymbolicName] = property.value;
									// Make sure the primary name property on the content item is updated
									rowRecord.contentItem.name = property.value;
									break;
								} 
							} else {
								// All other properties
								if (columnSpec.type != "Object") {
									if (property.id == cspecSymbolicName) {
										if (property.type == "DATE") {
											if (property.value != null) {
												rowRecord[cspecSymbolicName] = new Date(property.value);
											}
										} else {
											if (property.id == "ContentSize") {
												// If content size is null, don't set a new value
												if (property.value != null) {
													rowRecord[cspecSymbolicName] = property.value;
												}
											} else {
												rowRecord[cspecSymbolicName] = property.value;
											}
										}
										break;
									}
								} else {
									// Object value property as column property, name is two part string
									var index = cspecSymbolicName.indexOf(".");
									var symbolicName = cspecSymbolicName.slice(0, index);
									if (property.id == symbolicName) {
										// Now need to get the sysmbolic property name off the column spec and get the value
										symbolicName = cspecSymbolicName.slice(index+1);
										var objectValue = property.objectValue;
										if (objectValue != null) {
											var ovpProperties = objectValue.properties.items ? objectValue.properties.items : objectValue.properties;
											for (var k = 0; k < ovpProperties.length; k++) {
												var ovpProperty = ovpProperties[k];
												if (ovpProperty.id == symbolicName) {
													if (ovpProperty.type == "DATE") {
														if (ovpProperty.value != null) {
															rowRecord[cspecSymbolicName] = new Date(ovpProperty.value);
														}
													} else {
														rowRecord[cspecSymbolicName] = ovpProperty.value;
													}
													break;
												}
											}
										}
										break;
									}
								}
							}
						}
					}
				}
				
				// Make another pass through the properties to pick up any other specialized values
				for (var i = 0; i < properties.length; i++) {
					var property = properties[i];
					if (property.id == "Id"){
						// Need to save off the id value for later
						id = property.value; 
					} else if ((property.id == "IsReserved" && property.value) || (property.id == "VersionStatus" && property.value == 3)) {
						// Update the contentItem object properties inside the rowRecord with new property values
						rowRecord.contentItem.isReserved = true;
					} else if (property.id == "MimeType" && property.value != null) {
						rowRecord.contentItem.mimeType = property.value;
					} else if (property.id == "DbaBatchStatus" && property.value != null) {
						var rowRecProperties = rowRecord.contentItem.properties.items ? rowRecord.contentItem.properties.items : rowRecord.contentItem.properties;
						var rowRecProperty = rowRecProperties.find(rowRecProperty => rowRecProperty.id == "DbaBatchStatus");
						if (rowRecProperty) {
							rowRecProperty.value = property.value;
						}
					}
					
					// See if any of the extra properties need to be moved over as well
					var extraProperties = view.context.options.extraProperties.get("value");
					if (extraProperties != null) {
						var extraProperties = extraProperties.items ? extraProperties.items : extraProperties;
						for (var j = 0; j < extraProperties.length; j++) {
							var extraProp = extraProperties[j];
							// Could be multiple extra properties that have same primary property (object value properties) and need to process all of the secondary ones
							if (property.id == extraProp.primary) {
								// If the extra properties is in the new properties list, update the rowRecord property
								var rowRecProperties = rowRecord.contentItem.properties.items ? rowRecord.contentItem.properties.items : rowRecord.contentItem.properties;
								var rowRecProperty = rowRecProperties.find(tempProperty => tempProperty.id == extraProp.primary);
								if (rowRecProperty != null) {
									rowRecProperty.value = property.value;
									if (property.objectValue) {
										// State property is an object value property... now need to figure out which property on the ovp to use as the state
										if (extraProp.secondary != null && extraProp.secondary != "") {
											var objectProperties = property.objectValue.properties.items ? property.objectValue.properties.items : property.objectValue.properties;
											const objectProperty = objectProperties.filter(property => property.id === extraProp.secondary);
											if (objectProperty != null && objectProperty.length > 0) {
												var value = objectProperty[0].value;
												// Now need to find same object value property in the rowRecProperty object values
												var rowObjectProperties = rowRecProperty.objectValue.properties.items ? rowRecProperty.objectValue.properties.items : rowRecProperty.objectValue.properties;
												const rowObjectProperty = rowObjectProperties.filter(property => property.id === extraProp.secondary);
												if (rowObjectProperty != null) {
													rowObjectProperty[0].value = value;
												}
											}
										}
									}
									if (extraProp.secondary != null && extraProp.secondary != "") {
										console.log("CS-ContentList:_refreshTableRow() found extra property in row; primary: " + extraProp.primary + ", secondary: " + extraProp.secondary);
									} else  {
										console.log("CS-ContentList:_refreshTableRow() found extra property in row; primary: " + extraProp.primary);
									}
								}
							}
						}
					}				
				}
				
				// Need to make a pass with any custom state properties that are defined in the config settings
				var stateProperty = view.context.options.stateProperty.get("value");
				if (stateProperty != null && stateProperty != "") {
					var rowRecProperties = rowRecord.contentItem.properties.items ? rowRecord.contentItem.properties.items : rowRecord.contentItem.properties;
					var rowRecProperty = rowRecProperties.find(property => property.id == stateProperty);
					if (rowRecProperty != null) {
						// find the property in the new properties collection and set the new value in the rowRecord object
						var prop = properties.find(property => property.id == stateProperty);
						if (prop != null) {
							rowRecProperty.value = prop.value;
							// There could be multiple object value properties here, so need to replace just the secondary state one
							if (prop.objectValue) {
								// State property is an object value property... now need to figure out which property on the ovp to use as the state
								var stateSecondaryProperty = view.context.options.stateSecondaryProperty.get("value");
								if (stateSecondaryProperty != null) {
									var objectProperties = prop.objectValue.properties.items ? prop.objectValue.properties.items : prop.objectValue.properties;
									const objectProperty = objectProperties.filter(property => property.id === stateSecondaryProperty);
									if (objectProperty != null) {
										var value = objectProperty[0].value;
										// Now need to find same object value property in the rowRecProperty object values
										var rowObjectProperties = rowRecProperty.objectValue.properties.items ? rowRecProperty.objectValue.properties.items : rowRecProperty.objectValue.properties;
										const rowObjectProperty = rowObjectProperties.filter(property => property.id === stateSecondaryProperty);
										if (rowObjectProperty != null) {
											rowObjectProperty[0].value = value;
										}
									}
								}
							}
						}
					}
				}				
			
				// Checkout returns the reservation object. Add a reservation id so we will have it for checking in (uploading) a new version.
				if (actionName == this.actions.checkoutDocument) {
					rowRecord.contentItem.reservation = {
						id: id,
					};
					if (contentItem != null) {
						rowRecord.contentItem.reservation.creator = contentItem.creator;
					}
				} else {
					if (id != null && id != "") {
						rowRecord.contentItem.id = id;
					}
					if (actionName == this.actions.cancelCheckout) {
						rowRecord.contentItem.isReserved = false;
						rowRecord.contentItem.reservation = null;
					}
				}
				
				if (contentElements) {
					rowRecord.contentItem.contentElements = contentElements;
				}
				if (contentItem && contentItem.className){
					rowRecord.contentItem.className = contentItem.className;
				}
				
				var itemsList = view._instance.contentTable._instance.list;
				var listItem;
				if (rowIndex) {
					listItem = itemsList.getUnfiltered(rowIndex);
				} else {
					for (var i = 0; i < itemsList.list.items.length; i++) {
						var item = itemsList.list.items[i];
						if (item.contentItem.id == rowRecord.contentItem.id) {
							listItem = item;
							break;
						}
					}
				}
				var ctx = itemsList.getItemContext(listItem);
				var className = ctx.tr.className; // Save off the row selection state (is the css class)
				ctx.tr = null; 	// Clear out the tr so the the _renderCell function will be called again		
				
				// Tell the list view to refresh it's view with current data (will not call services)
				view._instance.contentTable.refresh(false);
				// If there was a row selection (className != null), then set it back to selected (refresh clears it).
				if (className) {
					ctx.tr.className = className;
				}
				console.log("CS-ContentList:_refreshTableRow() exited");
			},
			
			_onCheckoutDocument: function(view, cellData) {
				view._instance.actionName = this.actions.checkoutDocument;
				view._instance.lastActionData = cellData;
				
				// This action is ran without any UX
				var params = {
					action: this.actions.checkoutDocument,
					documentId: cellData.contentItem.id,
					repository: this._getObjectStoreName(view),
					serverAppResource: view._instance.serverConfigurationName
				};
				
				view._instance.checkoutDocumentSvc = view.ui.get("CheckoutDocumentSvc");
				this._callService(view._instance.checkoutDocumentSvc, params);
			},
		
			_onEditDocument: function(view, cellData) {
				view._instance.actionName = this.actions.editDocument;
				view._instance.lastActionData = cellData;

				// This action is ran without any UX
				var params = {
					action: this.actions.editDocument,
					documentId: cellData.contentItem.id,
					repository: this._getObjectStoreName(view),
					serverAppResource: view._instance.serverConfigurationName
				};
				
				view._instance.checkoutDocumentSvc = view.ui.get("CheckoutDocumentSvc");
				this._callService(view._instance.checkoutDocumentSvc, params);
			},
		
			_onGetRootFolderPropertiesResult: function(view) {
				try	{	
					var result = view._instance.getPropertiesSvc && view._instance.getPropertiesSvc.getResult();
					if (result) {
						var properties = result.properties.items ? result.properties.items : result.properties;
						var rootFolder = {
							className: this.typeFolder, // Assume Folder and open access, CE will enforce
							accessAllowed: 999423,
							path: "/",
							isFolder: true
						};
						for (var i = 0; i < properties.length; i++) {
							var property = properties[i];
							if (property.id == "Id") {
								rootFolder.id = property.value;
							} else if (property.id == "FolderName") {
								rootFolder.name = property.value;
							}
						}
						view._instance.rootFolder = rootFolder;

						var rootFolderName = view.context.options.rootFolderName.get("value");
						if (rootFolderName != null) {
							view._instance.rootFolder.name = rootFolderName;
						} else if (view._instance.rootFolder && (view._instance.rootFolder.name == null || view._instance.rootFolder.name == "")) {
							view._instance.rootFolder.name = messages.contlist_root_folder; // default in folder navigation mode
						}
						
						// If no items in breadcrumb yet, add a root item
						if (view._instance.breadCrumbTrail.length == 0) {
							this._addBreadcrumbItem(view, view._instance.rootFolder);
						}
					}
					
				} catch(e) {
					bpmext.log.error("Error on AJAX service invocation [" + view.context.viewid + "]: " + e);
					if (e.stack) {
						bpmext.log.error("  Call stack: " + e.stack);
					}
				}
			},
			
			_onCheckoutDocumentResult: function(view) {
				try	{	
					var resultSet = view._instance.checkoutDocumentSvc && view._instance.checkoutDocumentSvc.getResult();
					if (resultSet && resultSet.results) {
						var selectedRow = view._instance.lastActionRow;
						// Should only be on item returned in the results
						var contentItem = resultSet.results.items[0];
						this._refreshTableRow(view, this.actions.checkoutDocument, selectedRow.index, contentItem.properties.items, null, null, contentItem);
					}
					
					if (view._instance.checkoutForUpload){
						// Make the checkout transparent when checking out prior to an upload.
						this._showHideUploadVersionActionModal(view, true);
					} else if (view._instance.actionName == this.actions.editDocument) {
						// Need to also download the document (after it's checked out)
						this._downloadDocument(view, view._instance.lastActionData);
					} else {
						this._setAlertMessage(view, messages.contlist_checkout_success, false);
					}
				} catch(e) {
					bpmext.log.error("Error on AJAX service invocation [" + view.context.viewid + "]: " + e);
					if (e.stack) {
						bpmext.log.error("  Call stack: " + e.stack);
					}
				}
			},

			_onCancelCheckout: function(view, cellData) {
				view._instance.actionName = this.actions.cancelCheckout;
				view._instance.lastActionData = cellData;
				
				// This action is ran without any UX
				var params = {
					documentId: cellData.contentItem.id,
					repository: this._getObjectStoreName(view),
					serverAppResource: view._instance.serverConfigurationName
				};
				
				view._instance.cancelCheckoutSvc = view.ui.get("CancelCheckoutSvc");
				this._callService(view._instance.cancelCheckoutSvc, params);
			},
			
			_onCancelCheckoutResult: function(view) {
				try	{
					if (view._instance.checkoutForUpload){
						view._instance.checkoutForUpload = false;
						view._instance.actionName = "";
					} else {
						this._setAlertMessage(view, messages.contlist_cancel_checkout_success, false);
					}
				
					var resultSet = view._instance.cancelCheckoutSvc && view._instance.cancelCheckoutSvc.getResult();
					if (resultSet && resultSet.results) {
						// Should only be on item returned in the results
						var contentItem = resultSet.results.items[0];
						var selectedRow = view._instance.lastActionRow;

						this._refreshTableRow(view, this.actions.cancelCheckout, selectedRow.index, contentItem.properties.items, null, null);
					}
				} catch(e) {
					bpmext.log.error("Error on AJAX service invocation [" + view.context.viewid + "]: " + e);
					if (e.stack) {
						bpmext.log.error("  Call stack: " + e.stack);
					}
				}
			},
			
			_onUploadVersion: function(view, cellData) {
				view._instance.actionName = this.actions.uploadVersion;
				view._instance.lastActionData = cellData;
				if (!cellData.contentItem.isReserved) {
					// Check out the document before opening the dialog.
					view._instance.checkoutForUpload = true;
					this._onCheckoutDocument(view, cellData);
				} else {
					this._showHideUploadVersionActionModal(view, true);
				}
			},
			
			_showHideUploadVersionActionModal: function(view, isVisible) {	
				view._instance.uploadActionModal = view.ui.get("UploadVersionModal");
				view._instance.uploadVersionPropertyList = view.ui.get("UploadVersionPropertyList");
				if (isVisible) {
					var reservationId = view._instance.lastActionData.contentItem.reservation ? 
						view._instance.lastActionData.contentItem.reservation.id : view._instance.lastActionData.contentItem.id;
						
					view._instance.uploadVersionPropertyList.setServerConfigurationName(view._instance.serverConfigurationName);	
					view._instance.uploadVersionPropertyList.setObjectStoreName(this._getObjectStoreName(view));
					view._instance.uploadVersionPropertyList.displayForCheckin(reservationId);
				}
				view._instance.uploadActionModal.setVisible(isVisible);
				view._instance.uploadVersionPropertyList.setVisible(isVisible);
			},
			
			_onUploadVersionCancelBtnClicked: function(view) {
				view._instance.uploadActionModal = view.ui.get("UploadVersionModal");
				this._showHideUploadVersionActionModal(view, false);
				
				if (view._instance.checkoutForUpload) {				
					var params = {
						action: this.actions.cancelCheckout,
						documentId: view._instance.lastActionData.contentItem.id,
						repository: this._getObjectStoreName(view),
						serverAppResource: view._instance.serverConfigurationName
					};
				
					view._instance.cancelCheckoutSvc = view.ui.get("CancelCheckoutSvc");
					this._callService(view._instance.cancelCheckoutSvc, params);
				}
			},
			
			_onUploadVersionBtnClicked: function(view) {
				var self = this;
				view._instance.uploadVersionPropertyList.update(function(properties, contentElements) {
					view._instance.checkoutForUpload = false;
					self._showHideUploadVersionActionModal(view, false);
					self._setAlertMessage(view, messages.contlist_upload_version_success, false);

					// Update row in list view and don't refresh whole list
					var selectedRow = view._instance.lastActionRow;
					view._instance.actionName = "";
					
					var contentItemAction = view._instance.lastActionData.contentItem;
					var contentItemBinding = view.context.binding.boundObject.contentItem;	
					if (contentItemBinding != null && contentItemAction.id == contentItemBinding.id) {
						contentItemBinding.properties = properties;
						// Update the document id property on the content item cause we just versioned the document
						for (var i = 0; i < properties.length; i++) {
							var property = properties[i];
							if (property.id == "Id") {
								contentItemBinding.id = property.value; // Matches what in property collection
								break;
							}
						}
						self._setBindingObject(view, selectedRow, contentItemBinding, false, false);
					}
					self._refreshTableRow(view, self.actions.uploadVersion, selectedRow.index, properties, null, contentElements);
					
				}, function(errorText) {
					// Show error in an alert box at top of add dialog
					view._instance.uploadVersionBtn.setEnabled(true);
					self._setModalAlertMessage(view, view._instance.uploadVersionAlert, "UploadVersionAlert", messages.contlist_upload_failed, true);
				}, false);
			},			

			_onFolderRename: function(view, cellData) {
				view._instance.actionName = this.actions.renameFolder;
				view._instance.lastActionData = cellData;
				
				view._instance.newFolderNameTxt = view.ui.get("RenameFolderText");
				var folderName = cellData.name ? cellData.name : (cellData.Name ? cellData.Name : cellData.FolderName);
				view._instance.newFolderNameTxt.setText(folderName);
				
				this._showHideFolderActionModal(view, true, this.actions.renameFolder);
			},
			
			_showHideFolderActionModal: function(view, isVisible, actionName) {
				view._instance.folderActionModal = view.ui.get("RenameFolderModal");
				view._instance.folderActionPanel = view.ui.get("RenameFolderPanel");
				view._instance.renameFolderBtn = view.ui.get("RenameFolderButton");
				view._instance.actionName = actionName;
				
				if (isVisible == true) {
					view._instance.renameFolderBtn.setVisible(true);
					view._instance.renameFolderBtn.setEnabled(true);
					view._instance.newFolderNameTxt.setValid(true);
					view._instance.newFolderNameTxt.focus();
					var label = '';
					if (actionName == this.actions.renameFolder) {
						label = messages.contlist_menu_action_rename_folder;
					} else if (actionName == this.actions.createFolder) {
						label = messages.contlist_menu_action_add_folder;
					}
					view._instance.folderActionPanel.context.options._metadata.label.set('value', label);
				} else {
					view._instance.newFolderNameTxt.setText("");
				}

				view._instance.folderActionModal.setVisible(isVisible);

				if (isVisible) {
					view._instance.newFolderNameTxt.focus();
				}
			},
			
			_onRenameFolderBtnClicked: function(view) {
				view._instance.renameFolderBtn.setEnabled(false);
				var newFolderName = view._instance.newFolderNameTxt.getText();
				if (newFolderName != null && newFolderName != undefined && newFolderName.trim() != "") {
					if (view._instance.actionName == this.actions.renameFolder) {
						newFolderName = newFolderName.trim();
						if (newFolderName != view._instance.lastActionData.name) {
							var rowData = view._instance.lastActionData;
							var params = {
								folderId: rowData.contentItem.id,
								folderName: newFolderName,
								repository: this._getObjectStoreName(view),
								serverAppResource: view._instance.serverConfigurationName
							};
							
							view._instance.renameFolderSvc = view.ui.get("RenameFolderSvc");
							this._callService(view._instance.renameFolderSvc, params);
						}
					} else if (view._instance.actionName == this.actions.createFolder) {
						view.createFolder(view._instance.currentParentFolder.id, newFolderName, view._instance.currentParentFolder.server);
					} else {
						console.log("CS-ContentList:_onRenameFolderBtnClicked() : Unknown action on Folder Name Popup ");
					}
				} else {
					// Todo: Validation error, show alert message?
				}
			},
			
			_onRenameFolderResult: function(view) {
				try	{
					view._instance.lastPageIndex = view._instance.contentTable.getPageIndex();
					
					var data = view._instance.lastActionData;
					data.oldName = data.name;
					data.name = view._instance.newFolderNameTxt.getText();
					
					this._showHideFolderActionModal(view, false, '');

					this._setAlertMessage(view, messages.contlist_rename_folder_success, false);

					var properties = [];
					properties.push({
						id: "FolderName",
						type: "STRING",
						value: data.name
					});
					// Update row in list view and don't refresh whole list
					var selectedRow = view._instance.lastActionRow;
					
					// Need to determine if this folder is the binding object and if so, update the binding value
					var contentItemAction = data.contentItem;
					var contentItemBinding = view.context.binding.boundObject.contentItem;	
					if (contentItemBinding != null && contentItemAction.id == contentItemBinding.id) {
						var contentProps = contentItemBinding.properties;
						if (contentProps.items != null) {
							contentProps = contentProps.items;
						}
						for (var i = 0; i < contentProps.length; i++) {
							var property = contentProps[i];
							if (property.id == "FolderName" || property.id == "Name") {
								property.value = data.name;
							}
						}
						if (contentItemBinding.name != null) {
							contentItemBinding.name = data.name;
						}
						this._setBindingObject(view, selectedRow, contentItemBinding, false, false); // Will force a call to _refreshTableRow
					}
					this._refreshTableRow(view, this.actions.renameFolder, selectedRow.index, properties, null, null);

				} catch(e) {
					bpmext.log.error("Error on AJAX service invocation [" + view.context.viewid + "]: " + e);
					if (e.stack) {
						bpmext.log.error("  Call stack: " + e.stack);
					}
				}
			},
			
			_onDeleteObject: function(view, cellData) {
				view._instance.lastActionData = cellData; // Will be either folder or document
				
				view._instance.deleteObjectOutputText = view.ui.get("DeleteObjectOutputText");
				if (this._getType(cellData.contentItem) == this.typeFolder) {
					view._instance.deleteObjectOutputText.setText(string.substitute(messages.contlist_delete_folder_confirm, [cellData.contentItem.name]));
					this._showHideDeleteObjectModal(view, true, this.actions.deleteFolder);
				} else if (this._getType(cellData.contentItem) == this.typeAbstract) {
					var displayName = cellData.contentItem.name;
					if (cellData.contentItem.className  == "DbaClassificationBatch"){
						var properties = cellData.contentItem.properties.items ? cellData.contentItem.properties.items : cellData.contentItem.properties;
						for (var i = 0; i < properties.length; i ++){
							if (properties[i].id == "DbaDisplayName"){
								displayName = properties[i].value;
								break;
							}
						}
					}
					view._instance.deleteObjectOutputText.setText(string.substitute(messages.contlist_delete_confirm, [displayName]));
					this._showHideDeleteObjectModal(view, true, this.actions.deleteAbstract);
				} else {
					view._instance.deleteObjectOutputText.setText(string.substitute(messages.contlist_delete_doc_confirm, [cellData.contentItem.name]));
					this._showHideDeleteObjectModal(view, true, this.actions.deleteDocument);
				}								
			},
			
			_showHideDeleteObjectModal: function(view, isVisible, actionName) {
				view._instance.deleteObjectModal = view.ui.get("DeleteObjectModal");
				view._instance.deleteObjectPanel = view.ui.get("DeleteObjectPanel");
				view._instance.deleteObjectBtn = view.ui.get("OkDeleteObjectButton");
				view._instance.actionName = actionName;
				
				if (isVisible == true) {
					view._instance.deleteObjectBtn.setVisible(true);
					view._instance.deleteObjectBtn.setEnabled(true);
					
					var label = '';
					if (actionName == this.actions.deleteDocument) {
						label = messages.contlist_menu_action_delete_doc;
					} else if (actionName == this.actions.deleteFolder) {
						label = messages.contlist_menu_action_delete_folder;
					} else {
						label = messages.contlist_menu_action_delete;
					}
					view._instance.deleteObjectPanel.context.options._metadata.label.set('value', label);
				}

				view._instance.deleteObjectModal.setVisible(isVisible);
			},
			
			_onDeleteObjectBtnClicked: function(view) {
				view._instance.deleteObjectBtn.setEnabled(false);
				if (view._instance.actionName == this.actions.deleteDocument || view._instance.actionName == this.actions.deleteFolder  || view._instance.actionName == this.actions.deleteAbstract) {
					console.log("CS-ContentList:_onDeleteObjectBtnClicked() : Perform delete object.");
					var rowData = view._instance.lastActionData;
					if (view._instance.loadType == this.loadBatch){
						var currentBatch = view._instance.currentBatch;
						var params = {
							documentId: rowData.contentItem.id,
							versionSeriesId: rowData.contentItem.versionSeriesId,
							batchId: currentBatch.id,
							repository: this._getObjectStoreName(view),
							serverAppResource: view._instance.serverConfigurationName
						};
					
						view._instance.deleteBatchDocumentSvc = view.ui.get("DeleteBatchDocumentSvc");
						this._callService(view._instance.deleteBatchDocumentSvc, params);
					} else {
						var objectType = this.typeDocument;
						if (view._instance.actionName == this.actions.deleteFolder) {
							objectType = this.typeFolder;
						} else if (view._instance.actionName == this.actions.deleteAbstract) {
							objectType = this.typeAbstract;
						}
					
						var objectId = rowData.contentItem.id;
						if (this._getType(rowData.contentItem) == this.typeDocument) {
							objectId = rowData.contentItem.versionSeriesId;;
						} 

						var params = {
							objectId: objectId,
							objectType: objectType,
							classId: rowData.contentItem.className,
							repository: this._getObjectStoreName(view),
							serverAppResource: view._instance.serverConfigurationName
						};
					
						view._instance.deleteObjectSvc = view.ui.get("DeleteObjectSvc");
						this._callService(view._instance.deleteObjectSvc, params);
					}
				} else {
					console.log("CS-ContentList:_onDeleteObjectBtnClicked() : Unknown action on Delete Object Popup ");
				}
			},
			
			_onDeleteObjectResult: function(view) {
				try	{
					this._setAlertMessage(view, messages.contlist_delete_success, false);
					this._showHideDeleteObjectModal(view, false, '');

					view._proto._refresh(view);
					
					var contentItemAction = view._instance.lastActionData.contentItem;
					var contentItemBinding = view.context.binding.boundObject.contentItem;	
					if (contentItemBinding != null && contentItemAction.id == contentItemBinding.id) {
						view.context.binding.set("value", {});
					}
					
					if (view._instance.pollingEnabled) {
						if (view._instance.lastProcessedContentItems && view._instance.lastProcessedContentItems[contentItemAction.id]) {
							delete view._instance.lastProcessedContentItems[contentItemAction.id];
						}
						view._instance.propertyPoller.removeDocumentId(contentItemAction.id);
						view._instance.progressIndicator.removeItemRow(contentItemAction.id);
					}
					
					if (view._instance.loadType == this.loadBatch) {
						// Update the batch object with the correct status.
						var currentBatch = view._instance.currentBatch;
						if (currentBatch) {
							view._instance.uploadContent.updateBatchStatus(currentBatch.id);
						}
					}
				} catch(e) {
					bpmext.log.error("Error on AJAX service invocation [" + view.context.viewid + "]: " + e);
					if (e.stack) {
						bpmext.log.error("  Call stack: " + e.stack);
					}
				}
			},
			
			_showHideConfirmationDialog: function(view, isVisible, label, message, callback){
				view._instance.confirmationDialogCallback = callback;
				var confirmationModal = view.ui.get("ConfirmationModal");
				var confirmationPanel = view.ui.get("ConfirmationPanel");
				var confirmOkButton = view.ui.get("OkConfirmationtButton");
				var confirmationOutputText = view.ui.get("ConfirmationOutputText");
				
				if (isVisible == true) {
					confirmOkButton.setVisible(true);
					confirmOkButton.setEnabled(true);
					confirmationPanel.context.options._metadata.label.set('value', label);
					confirmationOutputText.setText(message);
				}

				confirmationModal.setVisible(isVisible);
			},
			
			_onConfirmationClicked: function(view){
				if (view._instance.confirmationDialogCallback){
					view._instance.confirmationDialogCallback(view);
					view._instance.confirmationDialogCallback = null;
				}
				view._proto._showHideConfirmationDialog(view, false);
			},

			_onAddActionClicked: function(view, actionName) {
				view._instance.actionName = actionName;

				var parentFolderId = "";
				var folderId = view._instance.folderId;
				if (folderId != null) {
					// Browse mode, get the currently navigated to folder id
					parentFolderId = view._instance.rootFolder.id;
					if (view._instance.currentParentFolder != null) {
						parentFolderId = view._instance.currentParentFolder.id;
					}
				} else {
					// Search mode, Check to see if there is a search in folder specified
					var searchFolderId = view.context.options.searchFolderId.get("value");
					if (searchFolderId != null) {
						parentFolderId = searchFolderId;
					}
					
					// If in search for folders mode and the user has navigated down into a sub-folder, use that folder
					if (view._instance.currentParentFolder != null && view._instance.currentParentFolder.id != "__id_Results") {
						parentFolderId = view._instance.currentParentFolder.id;
					}
				}

				if (actionName == this.actions.addFolder) {
					this._showHideAddFolderModal(view, true, parentFolderId, actionName);
				} else if (actionName == this.actions.addDocument) {
					var docClasses = view.context.options.documentClasses.get("value");
					if (view.context.options.hideAddDialog.get("value") && docClasses && docClasses.length() == 1) {
						if (view._instance.addDocumentClassAccess) {
							this._displayFileDialog(view, parentFolderId, "add");		
						} else {
							this._setAlertMessage(this, messages.contlist_document_create_error, true, 6000);		
						}
					} else {
						this._showHideAddDocumentModal(view, true, parentFolderId, actionName);
					}
				}
			},
			
			_displayFileDialog: function(view, folderId, action, contentItem) {				
				var _this = this;
				var inputElement = document.createElement("input");
				inputElement.type = "file";
				inputElement.multiple = !(action == "replaceDocument");
				if (view._instance.loadType == this.loadBatch || this._isCaptureApp(view)) {
					domAttr.set(inputElement, "accept", "application/pdf");
				} else {
					domAttr.remove(inputElement, "accept");
				}
				inputElement.addEventListener("change", function(evt) {
					if (_this._areSelectedFilesValid(view, this.files)) {
						if (view._instance.loadType == view._proto.loadBatch) {
							view._proto._addDocumentsToBatchNoUI(view, this.files, action, contentItem);
						} else {
							view._proto._addDocumentNoUI(view, this.files, folderId);
						}
					}
				});
				inputElement.dispatchEvent(new MouseEvent("click")); 
			},
			
			_isCaptureApp: function(view){
				var isCaptureApp = false;
				if (view._instance.loadType != this.loadBatch){
					var configuredDocumentClasses = view.context.options.documentClasses.get("value");
					var documentClasses = configuredDocumentClasses ? configuredDocumentClasses.items ? configuredDocumentClasses.items : configuredDocumentClasses : null;
					isCaptureApp = documentClasses && documentClasses.length == 1 && documentClasses[0].value == "DbaCaptureBase";					
				}
				return isCaptureApp;
			},
							
			_addDocumentNoUI: function(view, files, folderId) {
				var self = this;
				view._instance.inUpdateDocument = true; 
				domStyle.set(view.context.element, "cursor", "wait"); 
				var displayProgressIndicator = view.context.options.displayProgressIndicator.get("value");
				var configuredDocumentClasses = view.context.options.documentClasses.get("value");
				var documentClasses = configuredDocumentClasses.items ? configuredDocumentClasses.items : configuredDocumentClasses;
				view._instance.uploadContent.uploadFileSimpleWithClass(folderId, files, documentClasses[0].value, function(results) {						
					// Send out event about newly add document or documents
					if (Array.isArray(results)) {
						// Multi-document add case
						results.forEach(function(result) {
							var contentItem = self._createDocumentContentItem(result.results.properties, result.results.contentElements);
							bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONADD, contentItem);
						});
					} else {
						// Single document add case
						var contentItem = self._createDocumentContentItem(results.properties, results.contentElements);
						bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONADD, contentItem);
					}

					if (!view._instance.pollingEnabled) {
						view._instance.inUpdateDocument = false; // Done adding document
						if (!displayProgressIndicator) {
							// Display message at top of the list view
							var message;
							if (files.length > 1) {
								message = messages.contlist_add_docs_success;
							} else {
								message = messages.contlist_add_doc_success;
							}
							view._proto._setAlertMessage(view, message, false);
						}						
					}

					domStyle.set(view.context.element, "cursor", "auto");
					if (!view._instance.currentParentFolder || (view._instance.currentParentFolder.id == folderId)) {
						view._proto._refresh(view);
					}					
				}, function(error) {
					var errorMessage = "";
					var errorText = "";						
					if (Array.isArray(error)){							
						var fileNames = "";
						for (var i = 0; i < error.length; i++) {
							var documentAddError = error[i];
							if (fileNames.length > 0) {
								fileNames += ", ";
							}
							fileNames += documentAddError.fileName;
						}	
						errorMessage = string.substitute(messages.contlist_docs_not_added, [fileNames]);		
					} else {
						errorText = error ? error : "";
						errorMessage = string.substitute(messages.contlist_add_document_failed, [errorText]);
					}
					if (!displayProgressIndicator) {
						view._proto._setAlertMessage(view, errorMessage, true);		
					}
					
					view._instance.inUpdateDocument = false; // Was error, allow for adding document again
					domStyle.set(view.context.element, "cursor", "auto");
				});
			},
			
			_addDocumentsToBatchNoUI: function(view, files, action, contentItem) {
				view._instance.inUpdateDocument = true; 
				domStyle.set(view.context.element, "cursor", "wait"); 
				
				view._instance.uploadContent.setBatchUpdatedCallback(function() {
					domStyle.set(view.context.element, "cursor", "auto"); 
					view._instance.inUpdateDocument = false;
					view._proto._refresh(view);
				});	

				var callback = function(results){
					console.log("CS-ContentList:_addDocumentsToBatchNoUI() : Batch upload completed");
				};
				
				var errback = function(error){
					view._instance.inUpdateDocument = false;
					domStyle.set(view.context.element, "cursor", "auto");
					console.log("CS-ContentList:_addDocumentsToBatchNoUI() : Error occured: " + JSON.stringify(error));
				};
				
				var configuredDocumentClasses = view.context.options.documentClasses.get("value");
				var documentClasses = configuredDocumentClasses.items ? configuredDocumentClasses.items : configuredDocumentClasses;
				
				if (action == "add"){
					view._instance.uploadContent.appendDocumentsToClassificationBatch(view._instance.currentBatch.id, files, documentClasses[0].value, callback, errback);			
				} else {
					var properties = contentItem.properties.items ? contentItem.properties.items : contentItem.properties;
					var orderNo = properties.find(property => property.id == "DbaBatchOrder");
					view._instance.uploadContent.insertClassificationBatchDocument(view._instance.currentBatch.id, action, files, documentClasses[0].value, contentItem.id, orderNo.value, callback, errback);		
				}		
			},
			
			_initiateStatusPolling: function(view, documentId, properties, displayProgressIndicator) {
				view._instance.lastProcessedContentItems = null;
				view._instance.propertyPoller.addDocumentId(documentId);
			},
			
			_showHideAddFolderModal: function (view, isVisible, parentFolderId, actionName) {
				view._instance.addFolderModal = view.ui.get("AddFolderModal");
				view._instance.addFolderPanel = view.ui.get("AddFolderPanel");
				view._instance.addFolderPropsTable = view.ui.get("AddFolderPropsTable");
				view._instance.addFolderBtn = view.ui.get("AddFolderButton");
				view._instance.actionName = actionName;
				
				view._instance.addFolderModal.setVisible(isVisible);
				view._instance.addFolderPropsTable.setVisible(isVisible);
				if (isVisible == true) {
					view._instance.addFolderPropsTable.setFolderClasses(view.context.options.folderClasses.get("value"));
					view._instance.addFolderPropsTable.setIncludeTimePicker(view.context.options.includeTimePicker.get("value"));
					view._instance.addFolderPropsTable.setServerConfigurationName(view._instance.serverConfigurationName);
					view._instance.addFolderPropsTable.setObjectStoreName(this._getObjectStoreName(view));
					
					view._instance.addFolderBtn.setVisible(true);
					view._instance.addFolderBtn.setEnabled(true);
					
					var	label = messages.contlist_menu_action_add_folder						
					view._instance.addFolderPanel.context.options._metadata.label.set('value', label);
					
					this._setPropertyListMaxHeight(view, view._instance.addFolderModal, view._instance.addFolderPropsTable);
								
					var _self = this;
					view._instance.addFolderPropsTable.newFolder(parentFolderId, function(error) {
						var errorText = error ? error : "";
						var errMessage = string.substitute(messages.contlist_add_folder_failed, [errorText]);
						_self._setModalAlertMessage(view, view._instance.addFolderAlert, "AddFolderAlert", errMessage, true);
					});
				} else {
					view._instance.addFolderPropsTable.clear();
				}
			},
			
			_onAddFolderBtnClicked: function(view) {
				var self = this;
				if (!view._instance.inAddFolder) {
					view._instance.inAddFolder = true;
					domStyle.set(view._instance.addFolderModal.context.element, "cursor", "wait"); // Since no busy indicator in dialog
					console.log("CS-ContentList:_onAddFolderBtnClicked() : Enter add folder");

					view._instance.addFolderPropsTable = view.ui.get("AddFolderPropsTable");
					var isValid = view._instance.addFolderPropsTable.update(function(properties) {
						self._showHideAddFolderModal(view, false, '');
						view._instance.inAddFolder = false; // Done adding folder
						domStyle.set(view._instance.addFolderModal.context.element, "cursor", "auto");
						console.log("CS-ContentList:_onAddFolderBtnClicked() : Finished adding folder");

						var contentItem = self._createFolderContentItem(properties);
						bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONADD, contentItem);

						// Display a message at the top of the list view
						self._setAlertMessage(view, messages.contlist_add_folder_success, false);
						view._proto._refresh(view);
					}, function(error) {
						// Show error in an alert box at top of add dialog
						var errorText = error ? error : "";
						self._setModalAlertMessage(view, view._instance.addFolderAlert, "AddFolderAlert", string.substitute(messages.contlist_add_folder_failed, [errorText]), true);
						view._instance.inAddFolder = false; // Was error, allow for adding folder again
						domStyle.set(view._instance.addFolderModal.context.element, "cursor", "auto");
					}, true);

					if (!isValid){
						// There was a validation problem and add call never made
						view._instance.inAddFolder = false; // Was validation problem, allow for adding folder again
						domStyle.set(view._instance.addFolderModal.context.element, "cursor", "auto");
					}
				}
			},

			_createFolderContentItem: function(properties) {
				var contentItem = {
					isFolder: true,
					properties: properties
				};
				// Dig some properties out of the property bag and make first class properties
				for (var i = 0; i < properties.length; i++) {
					var property = properties[i];
					if (property.id == "Id") {
						contentItem.id = property.value;
					} else if (property.id == "Name") {
						contentItem.name = property.value;
					} else if (property.id == "PathName") {
						contentItem.pathName = property.value;
					}
				} 
				return contentItem;
			},

			_showHideAddDocumentModal: function (view, isVisible, parentFolderId, actionName, files, parentName) {
				view._instance.addDocumentModal = view.ui.get("AddDocumentModal");
				view._instance.addDocumentPanel = view.ui.get("AddDocumentPanel");
				view._instance.addDocumentPropsTable = view.ui.get("AddDocPropsTable");
				view._instance.addDocumentBtn = view.ui.get("AddDocumentButton");
				view._instance.actionName = actionName;
				
				view._instance.addDocumentModal.setVisible(isVisible);
				view._instance.addDocumentPropsTable.setVisible(isVisible);
				if (isVisible == true) {
					view._instance.addDocumentPropsTable.setDocumentClasses(view.context.options.documentClasses.get("value"));
					view._instance.addDocumentPropsTable.setIncludeTimePicker(view.context.options.includeTimePicker.get("value"));
					view._instance.addDocumentPropsTable.setServerConfigurationName(view._instance.serverConfigurationName);
					view._instance.addDocumentPropsTable.setObjectStoreName(this._getObjectStoreName(view));
					
					view._instance.addDocumentBtn.setVisible(true);
					view._instance.addDocumentBtn.setEnabled(true);
					
					var	label = messages.contlist_menu_action_add_doc;						
					view._instance.addDocumentPanel.context.options._metadata.label.set('value', label);					
					this._setPropertyListMaxHeight(view, view._instance.addDocumentModal, view._instance.addDocumentPropsTable);
					
					var batchId = null;
					if (view.context.binding) {
						var boundItem = view.context.binding.get("value");
						batchId = boundItem && boundItem.baseType == this.typeAbstract && boundItem.className == "DbaClassificationBatch" ? boundItem.id : null;		
					}
					
					var _self = this;
					view._instance.addDocumentPropsTable.newDocument(parentFolderId, function(error) {
						// Show error in an alert box at top of add dialog
						var errorText = error ? error : "";
						_self._setModalAlertMessage(view, view._instance.addDocumentAlert, "AddDocumentAlert", string.substitute(messages.contlist_add_document_failed, [errorText]), true);
					},  files, parentName, batchId);
				} else {
					view._instance.addDocumentPropsTable.clear();
				}
			},
			
			_onAddDocumentBtnClicked: function(view) {
				var self = this;
				var displayProgressIndicator = view.context.options.displayProgressIndicator.get("value");
				if (displayProgressIndicator || !view._instance.inUpdateDocument){
					view._instance.inUpdateDocument = true;
					domStyle.set(view._instance.addDocumentModal.context.element, "cursor", "wait"); // Since no busy indicator in dialog
					console.log("CS-ContentList:_onAddDocumentBtnClicked() : Enter add document");
					
					view._instance.addDocPropsTable = view.ui.get("AddDocPropsTable");
					var parentFolderId = view._instance.addDocPropsTable.getParentFolderId();
					var isValid = view._instance.addDocPropsTable.update(function(properties, contentElements) {
						if (view._instance.pollingEnabled) {
							self._showHideAddDocumentModal(view, false, '');
						} else {
							view._instance.inUpdateDocument = false; // Done adding document
							if (!displayProgressIndicator) {
								self._showHideAddDocumentModal(view, false, '');
								// Display message at top of the list view
								var message;
								if (properties[0].Cardinality){
									message = messages.contlist_add_doc_success;
								} else {
									message = messages.contlist_add_docs_success;
								}
								self._setAlertMessage(view, message, false);
							}
						}
						domStyle.set(view._instance.addDocumentModal.context.element, "cursor", "auto");
						console.log("CS-ContentList:_onAddDocumentBtnClicked() : Finished adding document");
						// Send out and add event for the newly add documents. The response is either a properties array of real 
						// properties (single document) or a properties array of results objects (multi-document)
						var property = properties[0];
						if (property.results && property.results.properties) {
							// Multi-document add case
							properties.forEach(function(property) {
								var contentItem = self._createDocumentContentItem(property.results.properties, property.results.contentElements);
								bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONADD, contentItem);
							});
						} else {
							// Single document add case
							var contentItem = self._createDocumentContentItem(properties, contentElements);
							bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONADD, contentItem);
						}
						
						if (!view._instance.currentParentFolder || (view._instance.currentParentFolder.id == parentFolderId)){
							view._proto._refresh(view);
						}				
					}, function(error, response) {
						var errorMessage = "";
						var errorText = "";						
						if (Array.isArray(response)) {							
							var errorString = messages.contlist_docs_not_added;
							var fileNames = "";
							for (var i = 0; i < response.length; i++){
								var documentAddError = response[i];
								if (fileNames.length > 0){
									fileNames += ", ";
								}
								fileNames += documentAddError.fileName;
							}	
							errorMessage = string.substitute(errorString, [fileNames]);		
						} else {
							errorText = error ? error : "";
							errorMessage = string.substitute(messages.contlist_add_document_failed, [errorText]);
						}
						if (displayProgressIndicator){
							self._showHideAddDocumentModal(view, true, '');
						} else {
							// Show error in an alert box at top of add dialog
							self._setModalAlertMessage(view, view._instance.addDocumentAlert, "AddDocumentAlert", errorMessage, true, 40000);
						}
												
						view._instance.inUpdateDocument = false; // Was error, allow for adding document again
						domStyle.set(view._instance.addDocumentModal.context.element, "cursor", "auto");
					});
					
					if (!isValid) {
						// There was a validation problem and add call never made
						view._instance.inUpdateDocument = false; // Was validation problem, allow for adding document again
						domStyle.set(view._instance.addDocumentModal.context.element, "cursor", "auto");
					} else if (displayProgressIndicator) {
						self._showHideAddDocumentModal(view, false, '');
					}
				}
			},
			
			_showHideAddBatchModal: function(view, isVisible){
				view._instance.addBatchModal = view.ui.get("AddBatchModal");
				view._instance.addBatchPanel = view.ui.get("AddBatchPanel");
				view._instance.addBatchPropsTable = view.ui.get("AddBatchProperties");
				
				view._instance.addBatchModal.setVisible(isVisible);
				view._instance.addBatchPropsTable.setVisible(isVisible);
				if (isVisible == true) {
					view._instance.addBatchPropsTable.setIncludeTimePicker(view.context.options.includeTimePicker.get("value"));
					view._instance.addBatchPropsTable.setServerConfigurationName(view._instance.serverConfigurationName);
					view._instance.addBatchPropsTable.setObjectStoreName(this._getObjectStoreName(view));
					
					view._instance.addBatchBtn.setVisible(true);
					view._instance.addBatchBtn.setEnabled(true);
					
					view._instance.addBatchPanel.context.options._metadata.label.set('value', messages.contlist_batch_upload_batch_title);			
					
					this._setPropertyListMaxHeight(view, view._instance.addBatchModal, view._instance.addBatchPropsTable);	
					var _this = this;
					view._instance.addBatchPropsTable.newBatch(function(error){
						_this._setAlertMessage(view, messages.contlist_batch_upload_error, true);					
					});
				} else {
					view._instance.addBatchPropsTable.clear();
				}
			},
			
			_onAddBatchBtnClicked: function(view){;
				if (view._instance.addBatchPropsTable.isValid()){
					var inputElement = document.createElement("input");
					inputElement.type = "file";
					inputElement.multiple = true;
					inputElement.accept="application/pdf";
					var _this = this;
					inputElement.addEventListener("change", function(evt) {
						if (_this._areSelectedFilesValid(view, this.files)){
							domStyle.set(view.context.element, "cursor", "wait"); 
							view._proto._showHideAddBatchModal(view, false);
							view._instance.uploadContent.setBatchUpdatedCallback(function(){
								domStyle.set(view.context.element, "cursor", "auto"); 
								view._proto._refresh(view);
							});							
							view._instance.uploadContent.setDocumentUploadedCallback(function(fileName, documentId, batchId, batchProperties){
								console.log("CS-ContentList:_onAddBatchBtnClicked() : Batch document uploaded : " + fileName + " Document Id: " +  documentId + "Batch Id: " + batchId + "Batch Properties: " + JSON.stringify(	batchProperties));
								view._proto._refreshTableRow(view, null, null, batchProperties, batchId, null, null);
							});							
							var propertyValues = view._instance.addBatchPropsTable.getPropertyValues(true);
							var configuredDocumentClasses = view.context.options.documentClasses.get("value");
							var documentClasses = configuredDocumentClasses ? configuredDocumentClasses.items ? configuredDocumentClasses.items : configuredDocumentClasses : null;
							view._instance.uploadContent.addClassificationBatch(JSON.parse(propertyValues), this.files, documentClasses[0].value, function(results){
								console.log("CS-ContentList:_onAddBatchBtnClicked() : Batch upload completed");
							}, function(error){
								domStyle.set(view.context.element, "cursor", "auto");
								console.log("CS-ContentList:_onAddBatchBtnClicked() : Error occured: " + JSON.stringify(error));
								view._proto._setAlertMessage(view, messages.contlist_batch_upload_error, true, 10000);
							});
						}
					});
					inputElement.dispatchEvent(new MouseEvent("click")); 
				}
			},
			
			_createDocumentContentItem: function(properties, contentElements) {
				var contentItem = {
					isFolder: false,
					properties: properties
				};
				if (contentElements != null) {
					contentItem.contentElements = contentElements;
				}
				// Dig some properties out of the property bag and make first class properties
				for (var i = 0; i < properties.length; i++) {
					var property = properties[i];
					if (property.id == "Id") {
						contentItem.id = property.value;
					} else if (property.id == "Name") {
						contentItem.name = property.value;
					} else if (property.id == "MimeType") {
						contentItem.mimeType = property.value;
					} else if (property.id == "IsReserved") {
						contentItem.isReserved = property.value;
					}
				} 
				return contentItem;
			},
		
			_processResultRows: function(view, results) {				
				if (results && results.items) {
					// Save off the current result set, so can be used for responsive rendering of column properties
					view._instance.lastResults = results;
					
					if (view._instance.pollingEnabled && this._isCaptureApp(view) && !view._instance.progressIndicator.isOpen()) {						
						view._instance.propertyPoller.pausePolling();
					}
		
					var columnSpecs = view._instance._columnSpecs;
					
					// This is the result json that they are digging through here
					var items = results.items;
					// Temp list of row items with updated property data
					var rowItems = []; 
					
					for (var i = 0; i < columnSpecs.length; i++) {
						var columnSpec = columnSpecs[i];
						var columnPropId = columnSpec.dataElementName; // dataElementName is property id

						for (var j = 0; j < items.length; j++) {
							var item = items[j];
							var properties = item.properties.items;

							var rowItem;
							if (j == rowItems.length) {
								rowItem = {};
								rowItem.contentItem = item;  // Add the item and primary properties to the content table row
								rowItems.push(rowItem);
							} else {
								rowItem = rowItems[j];
							}
							
							// Check for the property being a primary property first, if not check the properties array
							var value = item[columnPropId];
							var pollingProperty = false;
							if (value == undefined) {
								var options = columnSpec.options;
								// Need to loop on the item properties array here, there are more properties than columns
								for (var k = 0; k < properties.length; k++) {
									var property = properties[k];
									if (property.id == columnPropId) {
										value = this._getPropertyDisplayValue(property, options, null);
										pollingProperty = property.id == view._instance.pollingStatusPropertyId;
										break;
									} else if (property.type == "OBJECT") {
										// Check for object value properties as column property, they have two part id names
										var ovpProperties = property.objectValue ? property.objectValue.properties.items : null;
										if (ovpProperties != null) {
											for (var l = 0; l < ovpProperties.length; l++) {
												var ovpProperty = ovpProperties[l];
												if (this._getObjectPropertyId(property.id, ovpProperty.id) == columnPropId) {
													value = this._getPropertyDisplayValue(property, options, ovpProperty);
													pollingProperty = ovpProperty.id == view._instance.pollingStatusPropertyId;
													break;
												}
											}
										}
									}
								}
							}
							
							if (view._instance.pollingEnabled) {
								if (pollingProperty && (view._instance.loadType == view._proto.loadBatch || (item.className && item.className == "DbaClassificationBatch"))){						
									if (j == 0) {
										view._instance.propertyPoller.stopPolling();
									}
									// Add the item id to the poller if polling is enabled and the item is not in a terminal state.
									var addToPoller = false;
									if (view._instance.pollingExitValues && view._instance.pollingExitValues.length > 0) {
										addToPoller = !view._instance.pollingExitValues.find(exitValue => exitValue == value);
									}
									if (!addToPoller && view._instance.pollingNegativeExitValues && view._instance.pollingNegativeExitValues.length > 0) {
										addToPoller = view._instance.pollingNegativeExitValues.find(negativeExitValue => negativeExitValue == value);
									}
									if (addToPoller) {
										view._instance.propertyPoller.addDocumentId(item.id);
									}
								} else if (view._instance.propertyPoller.isPaused() && view._instance.propertyPoller.isPollingForObject(item.id)) {
									view._instance.propertyPoller.resumePolling();
								}
							}
							
							var recValue = value;
							if (recValue != undefined && (columnSpec && columnSpec.renderAs == "H")) {
								recValue = view.context.htmlEscape(recValue);
							}

							rowItem[columnPropId] = recValue;
						}
					}
	
					for (var i = 0; i < rowItems.length; i++) {
						var rowItem = rowItems[i];
						view._instance.contentTable.appendRecord(rowItem);						
					}
//					view._instance.contentTable.refresh(false);
				}
			}, 

			_getPropertyDisplayValue: function(property, options, ovpProperty) {
				var displayValue = "";
				if (property == null || property.value == null) {
					return displayValue;
				}
				
				if (property.cardinality == "LIST") {
					for (var i = 0; i < property.value.items.length; i++) {
						var value = property.value.items[i];
						// Need to change date properties into javascript Date objects
						if (property.type == "DATE" ) {
							value = new Date(value);
						}
						displayValue += value;
						if (i + 1 < property.value.items.length) {
							displayValue += "; ";
						}
					}
				} else {
					// Need to change date properties into javascript Date objects
					if (property.type == "DATE") {
						if (property.value) {
							displayValue = new Date(property.value);
						}
					} else if (property.type == "OBJECT") {
						if (ovpProperty && ovpProperty.value) {
							if (ovpProperty.type == "DATE") {
								displayValue = new Date(ovpProperty.value);
							} else {
								displayValue = ovpProperty.value;
							}
						}
					} else {
						displayValue = property.value;
					}
				}
				return displayValue;
			},
	
			_getDragOverFolderNode: function(event) {
				var folderRow, rowNode;
				var node = event.target;
				while (node){
					if (node.nodeName === "TR") {
						rowNode = node;
						break;
					} else {
						node = node.parentNode;
					}
				}
				
				if (rowNode && rowNode.__listItem && rowNode.__listItem.contentItem && this._getType(rowNode.__listItem.contentItem) == this.typeFolder) {
					folderRow = rowNode;
				}				
				return folderRow;
			},
			
			_onExternalDragLeave: function(event, view) {
				if (this._folderDrag) {
					domClass.remove(this._folderDrag, "CS_FileDragOverFolder");
					this._folderDrag = null;
				}
				var dataTableLayout = view.context.element.querySelector(".CS_DataTableLayout");
				domClass.remove(dataTableLayout, "CS_DataTableDragOver");
				var dataTable = view.context.element.querySelector(".CS_DataTable");
				domClass.remove(dataTable, "CS_FileDragOverFirstRow");
				domClass.remove(dataTable, "CS_FileDragOverFirstRowCR");
				var pagingLayout = view.context.element.querySelector(".CS_PagingLayout");
				domClass.remove(pagingLayout, "CS_FileDragOverLastRow");
				domClass.remove(pagingLayout, "CS_FileDragOverLastRowCR");
			},
			
			_onExternalDragOver: function(event, view) {
				event.preventDefault();
				var dataTable = view.context.element.querySelector(".CS_DataTable");
				folderRow = this._getDragOverFolderNode(event);
				if (folderRow) {
					domClass.remove(dataTable, "CS_DataTableDragOver");
					if (this._folderDrag && this._folderDrag.__listItem.contentItem.id != folderRow.__listItem.contentItem.id) {
						domClass.remove(this._folderDrag, "CS_FileDragOverFolder");
						this._folderDrag = folderRow;
					}
					this._folderDrag = folderRow;
					if (!domClass.contains(folderRow, "CS_FileDragOverFolder")) {
						domClass.add(folderRow, "CS_FileDragOverFolder");
					}
				} else {
					var dataTableLayout = view.context.element.querySelector(".CS_DataTableLayout");
					domClass.add(dataTableLayout, "CS_DataTableDragOver");
				}
			},
			
			_onExternalDrop: function(event, view) {
				this._onExternalDragLeave(event, view);
				event.preventDefault();
				
				// Check for folders and non-pdf files for batches.
				var foundFolder = false;
				var foundInvalidCaptureFile = false;
				var entry;
				var items = event.dataTransfer.items;
				if (this._areSelectedFilesValid(view, event.dataTransfer.items)) {
					folderRow = this._getDragOverFolderNode(event);
					var folderId;
					var folderName;
					if (folderRow) {
						folderId = folderRow.__listItem.contentItem.id;
						folderName = folderRow.__listItem.contentItem.name;
					} else {
						folderId = view._instance.currentParentFolder ? view._instance.currentParentFolder.id : view._instance.rootFolder ? view._instance.rootFolder.id : null;
						if (folderId) {
							if (view._instance.currentParentFolder) {
								folderName = view._instance.currentParentFolder.name
							} else if (view._instance.rootFolder.name && view._instance.rootFolder.name.length > 0) {
								folderName =  view._instance.rootFolder.name;
							} else {
								folderName = this._getObjectStoreName(view);
							}
						} else if (view._instance.loadType == view._proto.loadSearch) {
							// Search folder
							folderId = view.context.options.searchFolderId.get("value");
							if (!folderId) {
								// If no search folder, it will be added as an unfiled document.
								folderName = this._getObjectStoreName(view);
							}
						}
					}
					
					var docClasses = view.context.options.documentClasses.get("value");
					if (view.context.options.hideAddDialog.get("value") && docClasses && docClasses.length() == 1) {
						if (view._instance.addDocumentClassAccess){
							if (view._instance.loadType == view._proto.loadBatch) {
								view._proto._addDocumentsToBatchNoUI(view, event.dataTransfer.files, "add");
							}
							else {
								view._proto._addDocumentNoUI(view, event.dataTransfer.files, folderId);
							}
						}
						else {
							self._setAlertMessage(this, messages.contlist_document_create_error, true, 6000);	
						}								
					} else {
						view._proto._showHideAddDocumentModal(view, true, folderId, view._proto.actions.addDocument, event.dataTransfer.files, folderName);						
					}					
				}
			},
			
			_areSelectedFilesValid: function(view, items){
				var isValid = true;
				if (items.length > view._instance.uploadContent.getMaxAddsAvailable()) {
					console.log("CS-ContentList:_areSelectedFilesValid() : Number of files exceeds maximum: ." + items.length);
					this._setAlertMessage(view, string.substitute(messages.contlist_add_doc_max_exceeded, [view._instance.uploadContent.getMaxAddsAvailable(), items.length]), true);
					isValid = false;
				} else {
					for (var i = 0; i < items.length; i++) {
						var item = items[i];
						if ((view._instance.loadType == view._proto.loadBatch || this._isCaptureApp(view)) && item.type != "application/pdf"){
							console.log("CS-ContentList:_areSelectedFilesValid() : Found non-pdf file.");
							this._setAlertMessage(view, messages.contlist_drop_invalid_capture_files, true);
							isValid = false;
							break;
						} else if (item instanceof DataTransferItem) {
							// Only check for folders in drag and drop case.
							var foundFolder = false;
							if ((item.webkitGetAsEntry != null) && (entry = item.webkitGetAsEntry())) {
								if (!entry.isFile) {
									foundFolder = true;
								}
							} else if (item.getAsFile == null || item.kind !== "file") {
								foundFolder = true;
							}
							if (foundFolder) {
								console.log("CS-ContentList:_areSelectedFilesValid() : Found folder.");
								this._setAlertMessage(view, messages.contlist_drop_folder_error, true);
								isValid = false;
								break;
							}
						}
					}
				}
				return isValid;
			},

			_showHideFilter: function(view, showHide) {
				var filter = view.ui.get("ContentListFilter");
				var visible = filter.isVisible();
				if (showHide != null) {
					visible = showHide;
				}
				
				if (!visible) {
					filter.setVisible(true);
					var searchFor = view.context.options.searchFor.get("value");
					if (searchFor == null || searchFor == "") {
						searchFor = "Document";
					}
					var searchType = view.context.options.searchType.get("value");
					if (searchType == null || searchType == "") {
						if (searchFor == "Document") {
							searchType = "Document";
						} else if (searchFor == "Folder") {
							searchType = "Folder";
						} else {
							searchType = "Abstract";
						}
					}
					filter.displayProperties(searchType, searchFor);
				} else {
					filter.saveProperties();
					filter.setVisible(false, true);
				}
			},
			
			_isPollingForItemInList: function(view) {
				var isPollingForItem = false;
				if (view._instance.contentTable.getRecordCount() > 0){
					var records = view._instance.contentTable.getRecords(true);
					if (records && records.length) {
						for (var i = 0; i < records.length; i++) {
							var record = records[i];
							if (view._instance.propertyPoller.isPollingForObject(record.contentItem.id)) {
								isPollingForItem = true;
								break;
							}
						}
					}
				}
				return isPollingForItem;
			}			
		};
		
		/*
		 * Private methods and event handlers *************************************************************
		 */

    	this.constructor.prototype._parseError = function(error) {
      		if (error.errorText) {
        		if (error.errorText.indexOf("CWTBI0006E") != -1) {
					var message = string.substitute(messages.contlist_invalid_server_error, [this._instance.serverConfigurationName]);
					return message;
				}
      		}
      		return null;
    	}
		
		this.constructor.prototype._finishedLoadingResults = function(view) {
			setTimeout(function() {
				view._instance.refreshing = false;
				var hideRefresh = view.context.options.hideRefresh.get("value");
				if (!hideRefresh) {
					var refreshIconBtn = view.ui.get("RefreshImage");
					refreshIconBtn.setEnabled(true);
				}
			}, 300);
		}

		this.constructor.prototype._onLoadSearchResult = function() {
			var view = this;
			var resultSet = view._instance.searchSvc && view._instance.searchSvc.getResult();
			if (resultSet && resultSet.results) {
				view._setPagingInstanceData(resultSet, view._instance.breadcrumbLevel, true);
				view._setPagingTextData(0, resultSet.results.items.length, resultSet.totalCount);
			}			
			view._processResultService(view, resultSet);
			view._finishedLoadingResults(view);
		}

		this.constructor.prototype._onLoadMoreSearchResult = function() {
			var view = this;
			var resultSet = view._instance.moreSearchSvc && view._instance.moreSearchSvc.getResult();
			if (resultSet && resultSet.results) {
				view._setPagingMoreInstanceData(resultSet, view._instance.breadcrumbLevel);
				view._setPagingTextData(resultSet.newPageNumber, resultSet.results.items.length, resultSet.totalCount);
			}	
			view._processResultService(view, resultSet);
			view._finishedLoadingResults(view);
		}
	
		this.constructor.prototype._onLoadTextSearchResult = function() {
			var view = this;
			var resultSet = view._instance.textSearchSvc && view._instance.textSearchSvc.getResult();
			if (resultSet && resultSet.results) {
				view._setPagingInstanceData(resultSet, view._instance.breadcrumbLevel, true);
				view._setPagingTextData(0, resultSet.results.items.length, resultSet.totalCount);
			}			
			view._processResultService(view, resultSet);
			view._finishedLoadingResults(view);
		}

		this.constructor.prototype._onLoadMoreTextSearchResult = function() {
			var view = this;
			var resultSet = view._instance.moreTextSearchSvc && view._instance.moreTextSearchSvc.getResult();
			if (resultSet && resultSet.results) {
				view._setPagingMoreInstanceData(resultSet, view._instance.breadcrumbLevel);
				view._setPagingTextData(resultSet.newPageNumber, resultSet.results.items.length, resultSet.totalCount);
			}	
			view._processResultService(view, resultSet);
			view._finishedLoadingResults(view);
		}

		this.constructor.prototype._onLoadFolderContaineesResult = function() {
			var view = this;
			var resultSet = view._instance.folderContSvc && view._instance.folderContSvc.getResult();
			if (resultSet && resultSet.results) {
				view._setPagingInstanceData(resultSet, view._instance.breadcrumbLevel, false);
				view._setPagingTextData(0, resultSet.results.items.length, resultSet.totalCount);
				
				// Grab the first item (maybe a folder or document) and get parent folder information
				if (view._instance.rootFolder == null) {
					var items = resultSet.results.items;
					if (items.length > 0) {
						var firstItem = items[0];  
						if (this._proto._getType(firstItem) == this._proto.typeFolder) {
							view._instance.rootFolder = {
								id: firstItem.parent.id,
								accessAllowed: firstItem.parent.accessAllowed,
								name: firstItem.parent.name,
								className: firstItem.className,
								path: "/",
								isFolder: true,
								baseType: this._proto.typeFolder
							};
						} else { // isDocument
							var folderId = view._instance.folderId;
							var foldersFiledIn = firstItem.foldersFiledIn.folders;
							for (var i = 0; i < foldersFiledIn.items.length; i++) {
								var folder = foldersFiledIn.items[i];
								if (folder.id == folderId || folder.pathName == folderId) {
									view._instance.rootFolder = {
										id: folder.id,
										accessAllowed: folder.accessAllowed,
										name: folder.name,
										className: folder.className,
										path: "/",
										isFolder: true,
										baseType: this._proto.typeFolder
									};
									break;
								}
							}
						}
						
						var rootFolderName = view.context.options.rootFolderName.get("value");
						if (rootFolderName != null) {
							view._instance.rootFolder.name = rootFolderName;
						} else if (view._instance.rootFolder && (view._instance.rootFolder.name == null || view._instance.rootFolder.name == "")) {
							view._instance.rootFolder.name = messages.contlist_root_folder; // default in folder navigation mode
						}
						
						// If no items in breadcrumb yet, add a root item
						if (view._instance.breadCrumbTrail.length == 0) {
							this._proto._addBreadcrumbItem(view, view._instance.rootFolder);
						}
					} else {
						view._instance.actionName = this._proto.actions.folderProperties;
						// The root folder has no items, need to make a second service call to get the root folder accessAllowed setting
						if (view._instance.folderId != null) {
							var params = {
								objectId: view._instance.folderId,
								objectType: this._proto.typeFolder,
								properties: ["FolderName", "id"],
								repository: this._proto._getObjectStoreName(view),
								serverAppResource: view._instance.serverConfigurationName
							};
							view._instance.getPropertiesSvc = view.ui.get("GetPropertiesSvc");
							this._proto._callService(view._instance.getPropertiesSvc, params);
						}
					}
				}
			}

			if (view._instance.addBreadcrumbItem) {
				view._instance.addBreadcrumbItem = false;
				if (view._instance.currentParentFolder) {
					this._proto._addBreadcrumbItem(view, view._instance.currentParentFolder);
				}
			}
			view._processResultService(view, resultSet);
			view._finishedLoadingResults(view);
		}
	
		this.constructor.prototype._onLoadMoreFolderContaineesResult = function() {
			var view = this;
			var resultSet = view._instance.moreFolderContSvc && view._instance.moreFolderContSvc.getResult();
			if (resultSet && resultSet.results) {
				view._setPagingMoreInstanceData(resultSet, view._instance.breadcrumbLevel);
				view._setPagingTextData(resultSet.newPageNumber, resultSet.results.items.length, resultSet.totalCount);
			}
			view._processResultService(view, resultSet);
			view._finishedLoadingResults(view);
		}

		this.constructor.prototype._onLoadDocumentsResult = function() {
			var view = this;
			var resultSet = view._instance.documentsSvc && view._instance.documentsSvc.getResult();
			if (resultSet && resultSet.results) {
				view._setPagingInstanceData(resultSet, view._instance.breadcrumbLevel, true);
				view._setPagingTextData(0, resultSet.results.items.length, resultSet.totalCount);
			}			
			view._processResultService(view, resultSet);
			view._finishedLoadingResults(view);
		}

		this.constructor.prototype._onLoadMoreDocumentsResult = function() {
			var view = this;
			var resultSet = view._instance.moreDocumentsSvc && view._instance.moreDocumentsSvc.getResult();
			if (resultSet && resultSet.results) {
				view._setPagingMoreInstanceData(resultSet, view._instance.breadcrumbLevel);
				view._setPagingTextData(resultSet.newPageNumber, resultSet.results.items.length, resultSet.totalCount);
			}	
			view._processResultService(view, resultSet);
			view._finishedLoadingResults(view);
		}

		this.constructor.prototype._onLoadBatchDocumentsResult = function() {
			var view = this;
			var resultSet = view._instance.batchDocumentsSvc && view._instance.batchDocumentsSvc.getResult();
			if (resultSet && resultSet.results) {
				var accessAllowed = this._instance.currentBatch ? this._instance.currentBatch.accessAllowed : null;
				if (accessAllowed) {
					var items = resultSet.results.items;
					for (var i = 0; i < items.length; i++) {
						var item = items[i];
						item.accessAllowed = accessAllowed;
					}
				}
				view._setPagingInstanceData(resultSet, view._instance.breadcrumbLevel, true);
				view._setPagingTextData(0, resultSet.results.items.length, resultSet.totalCount);
			}			
			view._processResultService(view, resultSet);
			view._finishedLoadingResults(view);
		}

		this.constructor.prototype._onLoadMoreBatchDocumentsResult = function() {
			var view = this;
			var resultSet = view._instance.moreBatchDocumentsSvc && view._instance.moreBatchDocumentsSvc.getResult();
			if (resultSet && resultSet.results) {
				var accessAllowed = this._instance.currentBatch ? this._instance.currentBatch.accessAllowed : null;
				if (accessAllowed) {
					var items = resultSet.results.items;
					for (var i = 0; i < items.length; i++) {
						var item = items[i];
						item.accessAllowed = accessAllowed;
					}
				}
				view._setPagingMoreInstanceData(resultSet, view._instance.breadcrumbLevel);
				view._setPagingTextData(resultSet.newPageNumber, resultSet.results.items.length, resultSet.totalCount);
			}	
			view._processResultService(view, resultSet);
			view._finishedLoadingResults(view);
		}

		this.constructor.prototype._setPagingInstanceData = function(resultSet, breadcrumbLevel, isSearch) {
			var view = this;
			if (resultSet != null && resultSet.totalCount != null) {
				view._instance.totalCount = resultSet.totalCount;
			} else {
				view._instance.totalCount = 0;
			}
			// Determine if there are any more items that can be paged down to
			if (resultSet != null && resultSet.token != null) {
				// Need to keep track of the paging tokens so we can page backwards
				view._instance.pageNumber = 0; // First page of results
				view._instance.hasMoreItems = true;
				
				// Set up 2 dimensional array to hold bread crumb level and page tokens
				if (breadcrumbLevel == 0) {
					var tokensPage = [];
					tokensPage.push(resultSet.token);
					if (isSearch) {
						// If Searching, always clear the array out first, this is first page
						view._instance.pageTokensLevel = [];
						view._instance.pageTokensLevel.push(tokensPage);						
					} else {
						// Folder navigation
						view._instance.pageTokensLevel = [];
						view._instance.pageTokensLevel.push(tokensPage);
					}
				} else {
					var tokensPage = view._instance.pageTokensLevel[breadcrumbLevel];
					tokensPage.push(resultSet.token);
				}
				
				view._setIconButtonState("NextIcon", true);
			} else {
				var tokensPage = [];
				view._instance.pageTokensLevel.push(tokensPage);
				view._instance.hasMoreItems = false;
				view._setIconButtonState("NextIcon", false);
			}
			
			view._setIconButtonState("PreviousIcon", false);
			
			var enableSearchFilter = this.context.options.enableSearchFilter.get("value");
			if (enableSearchFilter) {
				// If we are in search filter mode, and the sreach result count = 0, display the no items message
				if (view._instance.totalCount == 0) {
					// Hide the paging bar
					var pagingLayout = this.ui.get("ContentListPagingLayout");
					domStyle.set(pagingLayout.context.element, "display", "none");
					// Show the empty message panel
					var emptyListPanel = view.context.element.querySelector(".CS_EmptyListPanel");
					domClass.remove(emptyListPanel, "CS_EmptyListPanelHide");
					domClass.add(emptyListPanel, "CS_EmptyListPanelShow");
					// Create the message information if not already.
					if (view._instance._searchMsgDiv == null) {
						var searchMsgDiv = document.createElement("div");
						domClass.add(searchMsgDiv, "CS_EmptyListSearch");
						var searchImage = document.createElement("div");
						domClass.add(searchImage, "CS_ImageSearch");
						searchMsgDiv.appendChild(searchImage);
						var msgDiv = document.createElement("div");
						domClass.add(msgDiv, "CS_EmptyListMessage");
						msgDiv.textContent = messages.contlist_filter_no_items;
						searchMsgDiv.appendChild(msgDiv);
//						var descDiv = document.createElement("div");
//						domClass.add(descDiv, "CS_EmptyListDescription");
//						descDiv.textContent = messages.contlist_filter_no_items_desc;
//						searchMsgDiv.appendChild(descDiv);
						emptyListPanel.appendChild(searchMsgDiv);
						view._instance._searchMsgDiv = searchMsgDiv;
					}
				} else {
					// Show the paging bar
					var pagingLayout = this.ui.get("ContentListPagingLayout");
					domStyle.set(pagingLayout.context.element, "display", "");
					// Hide the empty message panel
					var emptyListPanel = view.context.element.querySelector(".CS_EmptyListPanel");
					domClass.remove(emptyListPanel, "CS_EmptyListPanelShow");
					domClass.add(emptyListPanel, "CS_EmptyListPanelHide");
				}
			}
		}

		this.constructor.prototype._setPagingMoreInstanceData = function(resultSet, breadcrumbLevel) {
			var view = this;
			view._instance.totalCount = resultSet.totalCount;
			view._instance.pageNumber = resultSet.newPageNumber; 
			
			// Determine if there are any more items that can be paged down to
			if (resultSet.token != null) {

				var tokensPage = view._instance.pageTokensLevel[breadcrumbLevel];
				var length = tokensPage.length;

				if (resultSet.newPageNumber > length - 1) {
					// New page of items, token has not yet been added to the list
					
					// Setup paging token array
					tokensPage.push(resultSet.token);
				} else {
					// Existing page of items that we have navigated to before
					
					// Setup paging token array
					tokensPage.splice(resultSet.newPageNumber, 1, resultSet.token);
				}
				view._instance.hasMoreItems = true;
				view._setIconButtonState("PreviousIcon", true);
				view._setIconButtonState("NextIcon", true);
			} else {
				view._instance.hasMoreItems = false;
				view._setIconButtonState("PreviousIcon", true);
				view._setIconButtonState("NextIcon", false);
			}
		}		
		
		this.constructor.prototype._setIconButtonState = function(name, enabled) {
			var view = this;
			var iconButton = view.ui.get(name);
			iconButton.setEnabled(enabled);
		}
		
		/**
		 * Helper function to create the paging text displayed below the list view
		 * @param pageNumber current page number the list view is displaying
		 * @param numberResults current number of items return in the results
		 * @param totalCount is not supported by graphql api
		 */
		this.constructor.prototype._setPagingTextData = function(pageNumber, numberResults, totalCount) {
			var view = this;
			var pageSize = this._proto._getPageSize(this);
			var pagingText;
			if (pageNumber == 0) {
				if (numberResults == 0) {
					pagingText = "0";
				} else {
					pagingText = "1-" + numberResults;
				}
			} else if (pageNumber > 0 && numberResults == 0) {
				// Hit paging boundary and final page of results come up empty, there are no more items
				pagingText = messages.contlist_paging_no_more_items;
			} else {
			    pagingText = ((pageSize * pageNumber) + 1);
				pagingText += "-" + ((pageSize * pageNumber) + numberResults);
			}
			
			// If in Search mode, add the total count to the paging data (folder browsing, total count doesn't work at all)
			if (this._instance.folderId == null) {
				var totalCount = view._instance.totalCount;
				if (totalCount < 0) {
					pagingText = string.substitute(messages.contlist_paging_of_at_least_items, [pagingText, view._instance.countLimit]);
				} else {
					if (totalCount == null) {
						totalCount = "0";  
					}
					pagingText = string.substitute(messages.contlist_paging_of_items, [pagingText, totalCount]);
				}
			} else {
				pagingText = string.substitute(messages.contlist_paging_items, [pagingText]);
			}
	
			var pageSizeStr = string.substitute(messages.contlist_paging_items_per_page, [pageSize]);
			var pageSizeText = view.ui.get("PageSizeText");
			pageSizeText.setText(pageSizeStr);
	
			var pagingData = view.ui.get("PagingDataText");
			pagingData.setText(pagingText);
		}
		
		this.constructor.prototype._processResultService = function(view, resultSet) {
			if (view._instance.contentTable && view._instance.contentTable._instance.list != null) {
				view._instance.contentTable.clear();
			}
			// Todo:  Adding this scrolling logic to work around a bug in the Service Data Table where only on FireFox,
			// it doesn't scroll back to the top when the content list is cleared and reloaded. Chrome works fine...
			setTimeout(function(){
				var parentElement = view.context.element.parentElement;
				if (parentElement != null) {
					parentElement.scrollIntoView(true);
				}
//				view.context.element.scrollIntoView(true);
			}, 300);	

			if (resultSet && resultSet.results) {
				console.log("CS-ContentList:_processResultService() : Starting to process result set.");

				// Get the column information and set it into the Control-Table (TODO: not loading columns from search results)
//				view._proto._loadColumns(view, null);

				view._proto._processResultRows(view, resultSet.results);
			}
			
			view._instance.loadMoreClicked = false;
			
			var actionsTh = view._instance.contentTable.context.element.querySelector("th[aria-label='']");
			if (actionsTh) {
				domAttr.set(actionsTh, "aria-label", "Actions");
			}
			
			setTimeout(function() {
				if (resultSet && resultSet.results) {
					var results = resultSet.results.items ? resultSet.results.items : resultSet.results;
					bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONRESULT, results);
				}
			});
			console.log("CS-ContentList:_processResultService() : Finished processing result set.");
		};

		/**
		 * Event handlers for retrieving initial search results
		 */
		this.constructor.prototype._onSearchResultsInvoked = function() {
			// Todo: Fire indicator?
			var view = this;
		};

		this.constructor.prototype._onSearchResultsResult = function() {
			var view = this;
			console.log("CS-ContentList:_onSearchResultsResult() : called");
			view._instance.loadType = this._proto.loadSearch;

			// Get the result list that came back from the service call (should be list of DocumentItem like json)
			var resultSet = view._instance.searchSvc && view._instance.searchSvc.getResult();
			if (resultSet && resultSet.results) {
				view._onLoadSearchResult(); // Processes columns and result rows
			} else {
				console.log("CS_ContentList:_onSearchResultsResult() : Bad result set: " + resultSet);
			}
		};

		this.constructor.prototype._onSearchResultsError = function() {
			var view = this;
			var error = view._instance.searchSvc && view._instance.searchSvc.getLastError();
			if (error) {
				view._instance.error = error;

        		var message = this._parseError(error);
        		if (message == null) {
          			message = messages.contlist_search_failed; 
        		}
				console.log("CS-ContentList:_onSearchResultsError() : " + message);

				setTimeout(function() {
					bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, message);
				});
			}
			view._finishedLoadingResults(view);
		};

		/**
		 * Event handlers for getting more items for a search result (paging)
		 */
		this.constructor.prototype._onMoreSearchResultsInvoked = function() {
			// Todo: Fire indicator?
			var view = this;
		};

		this.constructor.prototype._onMoreSearchResultsResult = function() {
			var view = this;
			console.log("CS-ContentList:_onMoreSearchResultsResult() : called");
			view._instance.loadType = this._proto.loadSearch;

			// Get the result list that came back from the service call (should be list of DocumentItem like json)
			var resultSet = view._instance.moreSearchSvc && view._instance.moreSearchSvc.getResult();
			if (resultSet && resultSet.results) {
				view._onLoadMoreSearchResult(); // Processes columns and result rows
			} else {
				console.log("CS_ContentList:_onMoreSearchResultsResult() : Bad result set: " + resultSet);
			}
		};

		this.constructor.prototype._onMoreSearchResultsError = function() {
			var view = this;
			var error = view._instance.moreSearchSvc && view._instance.moreSearchSvc.getLastError();
			if (error) {
				view._instance.error = error;

        		var message = this._parseError(error);
        		if (message == null) {
          			message = messages.contlist_search_failed;   
        		}
				console.log("CS-ContentList:_onMoreSearchResultsError() : " + message);

				setTimeout(function() {
					bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, message);
				});
			}
			view._finishedLoadingResults(view);
		};
	
		/**
		 * Event handlers for retrieving initial text search results (CBR)
		 */
		this.constructor.prototype._onTextSearchResultsInvoked = function() {
			// Todo: Fire indicator?
			var view = this;
		};

		this.constructor.prototype._onTextSearchResultsResult = function() {
			var view = this;
			console.log("CS-ContentList:_onTextSearchResultsResult() : called");
			view._instance.loadType = this._proto.loadSearch;

			// Get the result list that came back from the service call (should be list of DocumentItem like json)
			var resultSet = view._instance.textSearchSvc && view._instance.textSearchSvc.getResult();
			if (resultSet && resultSet.results) {
				view._onLoadTextSearchResult(); // Processes columns and result rows
			} else {
				console.log("CS_ContentList:_onTextSearchResultsResult() : Bad result set: " + resultSet);
			}
		};

		this.constructor.prototype._onTextSearchResultsError = function() {
			var view = this;
			var error = view._instance.textSearchSvc && view._instance.textSearchSvc.getLastError();
			if (error) {
				view._instance.error = error;

        		var message = this._parseError(error);
        		if (message == null) {
          			message = messages.contlist_search_failed; 
        		}
				console.log("CS-ContentList:_onTextSearchResultsError() : " + message);

				setTimeout(function() {
					bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, message);
				});
			}
			view._finishedLoadingResults(view);
		};

		/**
		 * Event handlers for getting more items for a text search result (paging)
		 */
		this.constructor.prototype._onMoreTextSearchResultsInvoked = function() {
			// Todo: Fire indicator?
			var view = this;
		};

		this.constructor.prototype._onMoreTextSearchResultsResult = function() {
			var view = this;
			console.log("CS-ContentList:_onMoreTextSearchResultsResult() : called");
			view._instance.loadType = this._proto.loadSearch;

			// Get the result list that came back from the service call (should be list of DocumentItem like json)
			var resultSet = view._instance.moreTextSearchSvc && view._instance.moreTextSearchSvc.getResult();
			if (resultSet && resultSet.results) {
				view._onLoadMoreTextSearchResult(); // Processes columns and result rows
			} else {
				console.log("CS_ContentList:_onMoreTextSearchResultsResult() : Bad result set: " + resultSet);
			}
		};

		this.constructor.prototype._onMoreTextSearchResultsError = function() {
			var view = this;
			var error = view._instance.moreTextSearchSvc && view._instance.moreTextSearchSvc.getLastError();
			if (error) {
				view._instance.error = error;

        		var message = this._parseError(error);
        		if (message == null) {
          			message = messages.contlist_search_failed;   
        		}
				console.log("CS-ContentList:_onMoreTextSearchResultsError() : " + message);

				setTimeout(function() {
					bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, message);
				});
			}
			view._finishedLoadingResults(view);
		};
		
		/**
		 * Event handlers for retrieving folder containees
		 */
		this.constructor.prototype._onFolderContaineesInvoked = function() {
			// Todo: Fire indicator?
			var view = this;
		};

		this.constructor.prototype._onFolderContaineesResult = function() {
			var view = this;
			console.log("CS-ContentList:_onFolderContaineesResult() : called");
			view._instance.loadType = this._proto.loadFolder;

			// Check that there are results that came back from the service call
			var resultSet = view._instance.folderContSvc && view._instance.folderContSvc.getResult();
			if (resultSet) {
				view._onLoadFolderContaineesResult(); // Processes columns and result rows
			}
		};

		this.constructor.prototype._onFolderContaineesError = function() {
			var view = this;
			var error = view._instance.folderContSvc && view._instance.folderContSvc.getLastError();
			if (error) {
				if (view._instance.addBreadcrumbItem) {
					view._instance.addBreadcrumbItem = false;
				}

				view._instance.error = error;

        		var message = this._parseError(error);
        		if (message == null) {
          			message = messages.contlist_folder_containees_failed;        
        		}
				console.log("CS-ContentList:_onFolderContaineesError() : " + message);

				setTimeout(function() {
					bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, message);
				});
			}
			view._finishedLoadingResults(view);
		};
	
		this.constructor.prototype._onMoreFolderContaineesInvoked = function() {
			// Todo: Fire indicator?
			var view = this;
		};

		this.constructor.prototype._onMoreFolderContaineesResult = function() {
			var view = this;
			console.log("CS-ContentList:_onMoreFolderContaineesResult() : called");
			view._instance.loadType = this._proto.loadFolder;

			// Check that there are results that came back from the service call
			var resultSet = view._instance.moreFolderContSvc && view._instance.moreFolderContSvc.getResult();
			if (resultSet) {
				view._onLoadMoreFolderContaineesResult(); // Processes result rows
			}
		};

		this.constructor.prototype._onMoreFolderContaineesError = function() {
			var view = this;
			var error = view._instance.moreFolderContSvc && view._instance.moreFolderContSvc.getLastError();
			if (error) {
				view._instance.error = error;

        		var message = this._parseError(error);
        		if (message == null) {
					message = messages.contlist_error_retrieving_doc_props;
        		}
				console.log("CS-ContentList:_onMoreFolderContaineesError() : " + message);

				setTimeout(function() {
					bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, message);
				});
			}
			view._finishedLoadingResults(view);
		};

		/**
		 * Event handlers for retrieving documents
		 */
		this.constructor.prototype._onDocumentsInvoked = function() {
			// Todo: Fire indicator?
			var view = this;
		};

		this.constructor.prototype._onDocumentsResult = function() {
			var view = this;
			console.log("CS-ContentList:_onDocumentsResult() : called");
			view._instance.loadType = this._proto.loadDocuments;

			// Check that there are results that came back from the service call
			var resultSet = view._instance.documentsSvc && view._instance.documentsSvc.getResult();
			if (resultSet) {
				view._onLoadDocumentsResult(); // Processes columns and result rows
			}
		};

		this.constructor.prototype._onDocumentsError = function() {
			var view = this;
			var error = view._instance.documentsSvc && view._instance.documentsSvc.getLastError();
			if (error) {
				view._instance.error = error;

        		var message = this._parseError(error);
        		if (message == null) {
          			message = messages.contlist_documents_failed;        
        		}
				console.log("CS-ContentList:_onDocumentsError() : " + message);

				setTimeout(function() {
					bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, message);
				});
			}
			view._finishedLoadingResults(view);
		};
	
		this.constructor.prototype._onMoreDocumentsInvoked = function() {
			// Todo: Fire indicator?
			var view = this;
		};

		this.constructor.prototype._onMoreDocumentsResult = function() {
			var view = this;
			console.log("CS-ContentList:_onMoreDocumentsResult() : called");
			view._instance.loadType = this._proto.loadDocuments;

			// Check that there are results that came back from the service call
			var resultSet = view._instance.moreDocumentsSvc && view._instance.moreDocumentsSvc.getResult();
			if (resultSet) {
				view._onLoadMoreDocumentsResult(); // Processes result rows
			}
		};

		this.constructor.prototype._onMoreDocumentsError = function() {
			var view = this;
			var error = view._instance.moreDocumentsSvc && view._instance.moreDocumentsSvc.getLastError();
			if (error) {
				view._instance.error = error;

        		var message = this._parseError(error);
        		if (message == null) {
					message = messages.contlist_error_retrieving_doc_props;
        		}
				console.log("CS-ContentList:_onMoreDocumentsError() : " + message);

				setTimeout(function() {
					bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, message);
				});
			}
			view._finishedLoadingResults(view);
		};

		this.constructor.prototype._onBatchDocumentsResult = function() {
			var view = this;
			console.log("CS-ContentList:_onBatchDocumentsResult() : called");
			view._instance.loadType = this._proto.loadBatch;

			// Check that there are results that came back from the service call
			var resultSet = view._instance.batchDocumentsSvc && view._instance.batchDocumentsSvc.getResult();
			if (resultSet) {
				if (resultSet.update) {
					if (resultSet.results.items.length == 1) {
						var contentItem = resultSet.results.items[0];
						this._proto._refreshTableRow(this, null, null, contentItem.properties, contentItem.id, null, null);		
					} else {
						console.log("CS-ContentList:_onBatchDocumentsResult() : More than one batch document returned in the results.");
					}
				} else {
					view._onLoadBatchDocumentsResult(); // Processes columns and result rows
				}
			}
		};

		this.constructor.prototype._onBatchDocumentsError = function() {
			var view = this;
			var error = view._instance.batchDocumentsSvc && view._instance.batchDocumentsSvc.getLastError();
			if (error) {
				view._instance.error = error;

        		var message = this._parseError(error);
        		if (message == null) {
          			message = messages.contlist_documents_failed;        
        		}
				console.log("CS-ContentList:_onBatchDocumentsError() : " + message);

				setTimeout(function() {
					bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, message);
				});
			}
			view._finishedLoadingResults(view);
		};

		this.constructor.prototype._onMoreBatchDocumentsResult = function() {
			var view = this;
			console.log("CS-ContentList:_onMoreBatchDocumentsResult() : called");
			view._instance.loadType = this._proto.loadBatch;

			// Check that there are results that came back from the service call
			var resultSet = view._instance.moreBatchDocumentsSvc && view._instance.moreBatchDocumentsSvc.getResult();
			if (resultSet) {
				view._onLoadMoreBatchDocumentsResult(); // Processes result rows
			}
		};

		this.constructor.prototype._onMoreBatchDocumentsError = function() {
			var view = this;
			var error = view._instance.moreBatchDocumentsSvc && view._instance.moreBatchDocumentsSvc.getLastError();
			if (error) {
				view._instance.error = error;

        		var message = this._parseError(error);
        		if (message == null) {
					message = messages.contlist_error_retrieving_doc_props;
        		}
				console.log("CS-ContentList:_onMoreBatchDocumentsError() : " + message);

				setTimeout(function() {
					bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, message);
				});
			}
			view._finishedLoadingResults(view);
		};

		this.constructor.prototype._onGetPropertiesResult = function() {
			try {
				var view = this;
				var result = view._instance.getPropertiesSvc && view._instance.getPropertiesSvc.getResult();
				if (result && result.update) {
					var contentItem = result;
					delete contentItem.update;
					this._proto._refreshTableRow(this, null, null, result.properties, result.id, null, null);				
				} else {
					this._proto._onGetRootFolderPropertiesResult(this);
				}
			} catch (e) {
				bpmext.log.error("Error on AJAX service invocation [" + this.context.viewid + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};

		this.constructor.prototype._onGetPropertiesError = function() {
			var view = this;
			var error = view._instance.getPropertiesSvc && view._instance.getPropertiesSvc.getLastError();
			if (error) {
				var displayAlert = true;
				var message;
				if (view._instance.actionName == this._proto.actions.folderProperties) {
					if (error.errorCode == "FNRJG1001") {
						message = messages.contlist_folder_containees_failed;
					} else {
						message = messages.contlist_error_retrieving_folder_props;
					}
					error.actionName = this._proto.actions.folderProperties;
				} else {
					var params = this._instance.getPropertiesSvc.getInputData();
					if (params && params.update && params.update == "document") {
						// This is change event properties update error, possibly security related, try refreshing the list
						console.log("CS-ContentList:_onGetPropertiesError : Document can not be referenced, attempting to refresh the whole list.");
						this._proto._refresh(this);
						if (view._instance.pollingEnabled) {	
							// Need to stop polling and update the progress indicator with success message
							view._instance.propertyPoller.removeDocumentId(params.objectId);
							if (view.context.options.displayProgressIndicator.get("value")) {
								view._instance.progressIndicator.updateDocumentStatus("", "", true, true, params.objectId);
							}
						}
						displayAlert = false;
					} else {
						message = messages.contlist_error_retrieving_doc_props;
						error.actionName = this._proto.actions.documentProperties;
					}
				}
				
				if (displayAlert) {
					this._proto._setAlertMessage(view, message, true, 6000);
					view._instance.error = error;

					setTimeout(function() {
						bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, view._instance.error);
					});
				}
			}
		};

		this.constructor.prototype._onUpdatePropertiesResult = function(view, results) {
			console.log("CS-ContentList:_onUpdatePropertiesResult");
			var properties = results.properties.items ? results.properties.items : results.properties;
			var idProperty = properties.find(property => property.id == "Id");
			this._proto._refreshTableRow(this, null, null, properties, idProperty.value, null, null);
			
			if (properties.find(property => property.id == "DbaBatchStatus")){
				this._instance.propertyPoller.addDocumentId(idProperty.value);
			}
		};
		
		this.constructor.prototype._onUpdatePropertiesError = function(view, error) {
			var logMessage = error && error.errorText ? error.errorText : messages.properties_edit_save_failure;
			console.log("CS-ContentList:_onUpdatePropertiesError : " + logMessage);
			setTimeout(function() {
				bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, messages.properties_edit_save_failure);
			});
		}
	
		this.constructor.prototype._onCheckoutDocumentResult = function() {
			try {
				this._proto._onCheckoutDocumentResult(this);
			} catch (e) {
				bpmext.log.error("Error on AJAX service invocation [" + this.context.viewid + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};

		this.constructor.prototype._onCheckoutDocumentError = function() {
			var view = this;
			view._instance.checkoutForUpload = false;
			var error = view._instance.checkoutDocumentSvc && view._instance.checkoutDocumentSvc.getLastError();
			if (error) {
				error.actionName = this._proto.actions.checkoutDocument;
				var message = messages.contlist_checkout_failed;
				this._proto._setAlertMessage(view, message, true);
				view._instance.error = error;

				setTimeout(function() {
					bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, view._instance.error);
				});
			}
		};

		this.constructor.prototype._onCancelCheckoutResult = function() {
			try {
				this._proto._onCancelCheckoutResult(this);
			} catch (e) {
				bpmext.log.error("Error on AJAX service invocation [" + this.context.viewid + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};

		this.constructor.prototype._onCancelCheckoutError = function() {
			var view = this;
			view._instance.checkoutForUpload = false;
			var error = view._instance.cancelCheckoutSvc && view._instance.cancelCheckoutSvc.getLastError();
			if (error) {
				error.actionName = this._proto.actions.cancelCheckout;
				var message = messages.contlist_cancel_checkout_failed;
				this._proto._setAlertMessage(view, message, true);
				view._instance.error = error;

				setTimeout(function() {
					bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, view._instance.error);
				});
			}
		};

		this.constructor.prototype._onRenameFolderResult = function() {
			try {
				this._proto._onRenameFolderResult(this);
			} catch (e) {
				bpmext.log.error("Error on AJAX service invocation [" + this.context.viewid + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};

		this.constructor.prototype._onRenameFolderError = function() {
			var view = this;
			var error = view._instance.renameFolderSvc && view._instance.renameFolderSvc.getLastError();
			if (error) {
				error.actionName = this._proto.actions.renameFolder;
				var message = messages.contlist_rename_folder_failed;
					
				var extensions = error.items[0].extensions;
				var errorCode = extensions.errorCode;
				if (errorCode != null && errorCode == "FNRJG1005") { 
					// message = extensions.serverErrorMessage;
					view._instance.newFolderNameTxt.setValid(false, messages.contlist_folder_name_not_unique);
					view._instance.renameFolderButton.setEnabled(true);
				} else {
					this._showHideFolderActionModal(view, false, '');					
					this._proto._setAlertMessage(view, message, true);

					view._instance.error = error;

					setTimeout(function() {
						bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, view._instance.error);
					});
				}
			}
		};
	
		this.constructor.prototype._onDeleteObjectResult = function() {
			try {
				this._proto._onDeleteObjectResult(this);
			} catch (e) {
				bpmext.log.error("Error on AJAX service invocation [" + this.context.viewid + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};

		this.constructor.prototype._onDeleteObjectError = function() {
			var view = this;
			var error = view._instance.deleteObjectSvc && view._instance.deleteObjectSvc.getLastError();
			if (error) {
				error.actionName = this._instance.actionName;
				var message;
				if (error.errorCode == "FNRJG1005" && error.actionName == this._proto.actions.deleteFolder) {
					message = messages.contlist_delete_folder_referenced;
				} else {
					message = messages.contlist_delete_object_failed;
				}				

				this._proto._showHideDeleteObjectModal(view, false, '');					
				this._proto._setAlertMessage(view, message, true);

				view._instance.error = error;

				setTimeout(function() {
					bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, view._instance.error);
				});
			}
		};
		
		this.constructor.prototype._onDeleteBatchDocumentError = function() {
			var view = this;
			var error = view._instance.deleteBatchDocumentSvc && view._instance.deleteBatchDocumentSvc.getLastError();
			if (error) {
				error.actionName = this._instance.actionName;
				var message = messages.contlist_delete_document_failed;
				if (this._instance.actionName == this._proto.actions.deleteFolder) {
					message = messages.contlist_delete_folder_failed;
				} else if (this._instance.actionName == this._proto.actions.deleteAbstract) {
					message = messages.contlist_delete_object_failed;
				}
				this._proto._showHideDeleteObjectModal(view, false, '');					
				this._proto._setAlertMessage(view, message, true);

				view._instance.error = error;

				setTimeout(function() {
					bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, view._instance.error);
				});
			}
		};
					
		/**
		 * Helper function for getting a specific column specification from the list of column specs
		 */
		this.constructor.prototype._getColumnSpec = function(columnSpecs, id) {
			for (var i = 0; i < columnSpecs.length; i++) {
				if (columnSpecs[i].dataElementName == id) {
					return columnSpecs[i];
				}
			}
		};
		
		/*
		 * Public control methods *************************************************************
		 */

		/**
		 * @instance
		 * @memberof CSContentList
		 * @method getType
		 * @desc Returns the descriptive string that represents the control type.
		 * @returns {string}
		 */
		this.constructor.prototype.getType = function() {
			return "csContentList.3";
		};

		/**
		 * @instance
		 * @memberof CSContentList
		 * @method sort
		 * @desc Sorts the content list based on the specified column.
		 * @param {string} sortProperty The column property name.
		 * @param {string} order Sorts the content list in ascending/descending order in the column (or none UI component has 3 modes)
		 */
		this.constructor.prototype.sort = function(sortProperty, order) {
			console.log("CS-ContentList:sort() : called, sortProperty = " + sortProperty + " order = " + order);
			var sortOrder = "";
			if (order != null && order != "") {
				if (order == "descending" || order == "DESC") {
					sortOrder = "DESC";
				} else if (order == "ascending" || order == "ASC") {
					sortOrder = "ASC"
				}
			}
			
			var pageNumber = this._instance.pageNumber;
			var hasMoreItems = this._instance.hasMoreItems;
			if (pageNumber == undefined || (pageNumber == 0 && !hasMoreItems)) {
				// Let the list view sort the columns on the client side
				return true; // If we are not handling the sort
			} else {
				this._proto._refresh(this, sortProperty, sortOrder);
				return false; // If we handled the sort
			}
		};

		/**
		 * @instance
		 * @memberof CSContentList
		 * @method getDocumentCount
		 * @desc Returns the number of items in the content list.
		 * @returns {integer}
		 */
		this.constructor.prototype.getDocumentCount = function() {
			return this._instance.contentTable.getRecordCount();
		};
		
		/**
		 * @instance
		 * @memberof CSContentList
		 * @method refresh
		 * @desc Refreshes the content list.
		 */
		this.constructor.prototype.refresh = function()	{
			console.log("CS-ContentList:refresh() : called");
			this._proto._refresh(this, null, null);
		};
		
		this.constructor.prototype._showHideContentListFilter = function(isVisible) {
			try {
				this._proto._showHideContentListFilter(this, isVisible);
			} catch (e) {
				bpmext.log.error("Error on AJAX service invocation [" + this.context.viewid + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};

		this.constructor.prototype._showSearchFilterButton = function() {
			try {
				this._proto._showSearchFilterButton(this);
			} catch (e) {
				bpmext.log.error("Error on AJAX service invocation [" + this.context.viewid + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};
		
		this.constructor.prototype._filterContentList = function (current, potential, selection, type) {
			try {
				this._proto._filterContentList(this, current, potential, selection, type);
			} catch (e) {
				bpmext.log.error("Error on AJAX service invocation [" + this.context.viewid + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};

		this.constructor.prototype._onBreadcrumbLevelClick = function(breadcrumbItem) {
			try {
				this._proto._onBreadcrumbLevelClick(this, breadcrumbItem);
			} catch (e) {
				bpmext.log.error("Error on AJAX service invocation [" + this.context.viewid + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};
		
		this.constructor.prototype._onRowSel = function(row) {
			// Called by internal ContentTable component when user selects Single radio button or Multi checkbox (not in None mode)
			
			// Need to include setting the binding object when and item is selected with the single/multi select controls
			if (row.data && row.data.contentItem) {
				var view = this;
				this._proto._setBindingObject(view, row, row.data.contentItem, false, true);
				console.log("CS-ContentList:_onRowSel() : Item clicked: " + row.data.contentItem.name + " row: " + row.index);
			}
			return bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONROWSEL, row);
		};
		
		this.constructor.prototype._renderCell = function(table, cell) {
			var view = this;
			var data = cell.row.data;
			
			// If the column is the last column for the content menu, render it here
			if (cell.varName == "_contextMenuButton") {
				var div = view._renderContextMenuButton(view, cell);
				return div;
			}

			// From config Settings
			var displayResState = !view.context.options.displayCheckoutState.get("value"); // default is to show
			var displayCusState = view.context.options.displayCustomState.get("value");    // default is to hide

			// Get the column property information from the content items property collection (it has the real property type from CE)
			var columnProperty;
			var ovpProperty;
			var properties = data.contentItem.properties.items ? data.contentItem.properties.items : data.contentItem.properties;

			// Look to see if any column properties are object value properties, if so find the ovp property value instead
			for (var i = 0; i < properties.length; i++) {
				var property = properties[i];
				if (property.type == "OBJECT") {
					var objectValue = property.objectValue;
					if (objectValue) { // Could be not set yet
						var ovpProperties = objectValue.properties.items;
						for (var j = 0; j < ovpProperties.length; j++) {
							ovpProperty = ovpProperties[j];
							if (this._proto._getObjectPropertyId(property.id, ovpProperty.id) == cell.varName) {
								columnProperty = property;
								break;
							}
						}
					}
				} else {
					if (property.id == cell.varName) {
						columnProperty = property;
						break;
					}
				}
			}
	
			// Find the column spec for the current property, can get the data type from this later
			var columnSpec = this._instance._columnSpecsHash[cell.varName];
			
			if (data.contentItem &&	this._proto._getType(data.contentItem) == this._proto.typeFolder) {
				// Main column (first column) has extra click events to open/view a document
				if (cell.colIndex == 0) {
					var div = document.createElement("div");
					domClass.add(div, "input-group");

					// Add spacer for state column images
					if (displayCusState) {
						var divIcon = document.createElement("div");
						domClass.add(divIcon, "spacer");
						div.appendChild(divIcon);
					}
					
					if (displayResState) {
						var divIcon = document.createElement("div");
						domClass.add(divIcon, "spacer");
						domStyle.set(divIcon, "margin-left", "5px");
						div.appendChild(divIcon);
					}
					
					var iconDiv = document.createElement("div");
//					domClass.add(iconDiv, "fa fa-folder fa-lg");
//					domClass.add(iconDiv, "EltType");
//					div.appendChild(iconDiv);

					var aMime = view._createFolderLink(view, cell.row, null);
					var aLink = view._createFolderLink(view, cell.row, cell);

					// Add the mime type image
					var iconDiv = view._createMimeImage(view, data, aMime);
					div.appendChild(iconDiv);

					// Create the name link includes creating a icon to display the appropriate context menu per item type
					var nameDiv = view._createNameLink(view, cell, aLink, displayResState, displayCusState, true);
					div.appendChild(nameDiv);
				
					return div;
				} else if (cell.varName == "ContentSize" || cell.varName == "contentSize") {
					var div = document.createElement("div");
					return div; // Folders have no content 		
				} else if (cell.varName == "ClassName" || cell.varName == "className") {
					var div = document.createElement("div");
					var displayValue = data.contentItem.className;
					div.textContent = displayValue;
					return div;
				} else if (columnSpec.type == "Date" || (columnProperty && columnProperty.type == "DATE")) {
					// Render the date value based on the date formatter and also use real value for column sorting
					var div = view._renderDateValue(view, cell, data, columnSpec, columnProperty.value);
					if (div != null) {
						return div;
					}
				} else {
					// This is not the main column, display in basic style
					var div = document.createElement("div");
					var displayValue = data[cell.varName];
					div.textContent = displayValue == undefined ? "" : displayValue;
					return div;
				}
			} else {
				// Main column (first column) has extra click events to open/view a document

				// If a custom state property is defined in config settings, check to see if we need to display state column
				var stateProperty = view.context.options.stateProperty.get("value");

				if (cell.colIndex == 0) {
					var div = document.createElement("div");
					domClass.add(div, "input-group");
			
					var actionsEnabled = view._proto._enableActionsCustomHandler(view, data);
			
					if (data.contentItem.baseType == this._proto.typeAbstract && data.contentItem.className == "DbaClassificationBatch") {
						var properties = data.contentItem.properties.items ? data.contentItem.properties.items : data.contentItem.properties;
						var propBatchStatus = properties.find(property => property.id == "DbaBatchStatus");
						if (propBatchStatus.value == 310) { // Completed batch
							actionsEnabled = false; // Turns off anchors on main name column 
						}
					}
					
					var aMime = view._createDocumentLink(view, cell.row, null, actionsEnabled);
					var aLink = view._createDocumentLink(view, cell.row, cell, actionsEnabled);
		
					if (displayCusState && stateProperty != null && stateProperty != "") {
						var imgDiv = view._createCustomStateImage(view, data);
						div.appendChild(imgDiv);
					}
					
					// Standard checked out state column (is reservation)
					if (displayResState) {
						var imgDiv = view._createStateImage(view, data);
						div.appendChild(imgDiv);
					}
					
					// Add the mime type image
					var iconDiv = view._createMimeImage(view, data, aMime);
					div.appendChild(iconDiv);

					// Create the name link includes creating a icon to display the appropriate context menu per item type
					var nameDiv = view._createNameLink(view, cell, aLink, displayResState, displayCusState, actionsEnabled);
					div.appendChild(nameDiv);
					return div;
				} else if (cell.varName == "id")	{
					var div = document.createElement("div");
					domAttr.set(cell.td, "aria-label", "Actions");
					return div;
				} else if (cell.varName == "ContentSize" || cell.varName == "contentSize") {
					var div = document.createElement("div");
					var bytes = data[cell.varName];
					if (bytes != null && typeof bytes != "undefined") {
						div.textContent = this._proto._formatSize(bytes, 2);
					} else {
						div.textContent = "n/a";
					}
					return div;
				} else if (cell.varName == "ClassName" || cell.varName == "className") {
					var div = document.createElement("div");
					var displayValue = data.contentItem.className;
					div.textContent = displayValue;
					return div;
				} else if (columnSpec.type == "Date" || (columnProperty && columnProperty.type == "DATE")) {
					// Render the date value based on the date formatter and also use real value for column sorting
					var div = view._renderDateValue(view, cell, data, columnSpec, columnProperty.value);
					if (div != null) {
						return div;
					}
				} else if (cell.varName == stateProperty) {
					// This is status property set in config settings for capture applications
					var div = document.createElement("div");
					var value = data[cell.varName];
					if (isNaN(value)) {
						div.textContent = value == undefined ? "" : value;
					} else {
						div.textContent = messages["status_" + value];
					}
					return div;
				} else if (columnProperty && columnProperty.type == "OBJECT") {
					var value = data[cell.varName];
					if (ovpProperty.type == "DATE") {
						var value = data[cell.varName];
						var div = view._renderDateValue(view, cell, data, columnSpec, value);
						if (div != null) {
							return div;
						}
					} else if (columnProperty.id == stateProperty) {
						var div = document.createElement("div");
						var value = data[cell.varName];
						if (isNaN(value)) {
							div.textContent = value == undefined ? "" : value;
						} else {
							// Check for any capture status errors 900, 910 or 920
							if (value >= 900) {
								// Display an error icon in front of the status string
								var errorDiv = view._getMessageDiv("CS_IssuesError", "CS_ImageError", "CS_ErrorMessage", "100%", true, messages["status_" + value]);
								div.appendChild(errorDiv);
								var displayMessage;
								// The properties array is the contentItem properties, need to find the DbaCaptureError property from the controller
								for (var i = 0; i < properties.length; i++) {
									var property = properties[i];
									if (property.id == "DbaClassificationController" && property.objectValue) {
										var ovpProperties = property.objectValue.properties.items;
										var propCaptureError = ovpProperties.find(property => property.id == "DbaCaptureError");
										if (propCaptureError && propCaptureError.value) {
											displayMessage = view._getErrorMessage(propCaptureError.value);
										}
										break;
									}
								}
								if (displayMessage == null) {
									displayMessage  = messages["status_error_msg_" + value];
								}
								// initialize tooltip for error icon
								cs_InitTooltip(errorDiv, "documentsErrorTooltip" + cell.row.index, displayMessage, true, 10, domClass, domAttr, connect);

							} else if (value == 30) {
								// Review required, display warning icon
								var warningDiv = view._getMessageDiv("CS_IssuesWarning", "CS_ImageWarning", "CS_ErrorMessage", "100%", false, messages["status_" + value], messages["status_" + value]);
								div.appendChild(warningDiv);
								// initialize tooltip for warning icon
								var displayMessage = messages["status_error_msg_" + value];
								cs_InitTooltip(errorDiv, "documentsWarningTooltip" + cell.row.index, displayMessage, true, 10, domClass, domAttr, connect);

							} else {
								// No error, just display the status string
								div.textContent = messages["status_" + value];
							}
						}
						return div;
					} else {
						// This is not the main column, display in basic style
						var div = document.createElement("div");
						var displayValue = data[cell.varName];
						div.textContent = displayValue == undefined ? "" : displayValue;
						return div;
					}
				} else if (cell.varName == "DbaIssues") {
					var properties = data.contentItem.properties.items ? data.contentItem.properties.items : data.contentItem.properties;
					var propErrorCount = properties.find(property => property.id == "DbaVerificationErrorCount");
					var propWarningCount = properties.find(property => property.id == "DbaVerificationWarningCount");
					var errorCount = propErrorCount.value;
					var warningCount = propWarningCount.value;
					if (errorCount > 0 || warningCount > 0) {
						var div = document.createElement("div");
						if (warningCount > 0) {
							var warning;
							if (warningCount == 1) {
								warning = string.substitute(messages.contlist_issues_warning, [warningCount]);
							} else {
								warning = string.substitute(messages.contlist_issues_warnings, [warningCount]);
							}
							var warningDiv = view._getMessageDiv("CS_IssuesWarning", "CS_ImageWarningBlack", "CS_IssuesCount", null, false, warningCount, warning);
							div.appendChild(warningDiv);
						} else {
							var warningDiv = document.createElement("div");
							domClass.add(warningDiv, "CS_IssuesWarning");
							var warningImage = document.createElement("div");
							domClass.add(warningImage, "CS_ImageWarningDisabled CS_IssuesImage");
							warningDiv.appendChild(warningImage);							
							div.appendChild(warningDiv);
						}
						if (errorCount > 0) {
							var error;
							if (errorCount == 1) {
								error = string.substitute(messages.contlist_issues_error, [errorCount]);
							} else {
								error = string.substitute(messages.contlist_issues_errors, [errorCount]);
							}
							var errorDiv = view._getMessageDiv("CS_IssuesError", "CS_ImageErrorBlack", "CS_IssuesCount", null, false, errorCount, error);
							div.appendChild(errorDiv);
						} else {
							var errorDiv = document.createElement("div");
							domClass.add(errorDiv, "CS_IssuesError");
							var errorImage = document.createElement("div");
							domClass.add(errorImage, "CS_ImageErrorDisabled CS_IssuesImage");
							errorDiv.appendChild(errorImage);							
							div.appendChild(errorDiv);
						}
						return div;
					}
				} else if (cell.varName == "DbaBatchPriority") {
					// Thie is capture specific code to handle the priority column which is an integer cvl in the CPE
					var div = document.createElement("div");
					var value = data[cell.varName];
					var displayValue = messages.contlist_priority_high;
					if (value == 2) {
						displayValue = messages.contlist_priority_med;
					} else if (value == 3) {
						displayValue = messages.contlist_priority_low
					}
					div.textContent = displayValue;
					return div;
				} else if (cell.varName == "DbaBatchStatus") {
					// Thie is capture specific code to handle the status column which is an integer cvl in the CPE
					var div = document.createElement("div");
					var value = data[cell.varName];
					if (isNaN(value)) {
						div.textContent = value == undefined ? "" : value;
					} else {
						var displayText = true;
						if (value == view._proto.DbaBatchStatusUploading) {
							var percentDone = this._instance.uploadContent.getClassificationBatchPercentDone(data.contentItem.id);
							if (percentDone > 0) {
								displayText = false;
								var cancelUploadFunction = function() {
									view._instance.uploadContent.cancelClassificationBatchUpload(data.contentItem.id);
								}
								var progressBarDiv = this._createInlineProgressDiv(view, data, percentDone, cancelUploadFunction);
								div.appendChild(progressBarDiv);
							}
						}
						
						if (displayText) {
							var message = messages["batch_status_" + value];
							if (value < 1900) {
								if (message) {
									div.textContent = message;
								} else {
									div.textContent = value;
								}
							} else {
								// These are errors, include the red error icon
								var errorDiv = view._getMessageDiv("CS_IssuesError", "CS_ImageError", "CS_ErrorMessage", null, true, message);
								div.appendChild(errorDiv);
								// initialize tooltip for error icon
								var displayMessage;
								var propBatchError = properties.find(property => property.id == "DbaBatchError");
								if (propBatchError && propBatchError.value) {
									displayMessage = view._getErrorMessage(propBatchError.value);
								}
								if (displayMessage == null) {
									displayMessage  = messages["batch_error_msg_" + value];
								}
								cs_InitTooltip(errorDiv, "batchErrorTooltip" + cell.row.index, displayMessage, true, 10, domClass, domAttr, connect);
							}
						}
					}
					return div;
				} else {
					// This is not the main column, display in basic style
					var div = document.createElement("div");
					var displayValue = data[cell.varName];
					div.textContent = displayValue;
					return div;
				}
			}
		};
		
		this.constructor.prototype._createCustomStateImage = function(view, cellData) {
			var iconDiv = document.createElement("div");
			var stateProperty = view.context.options.stateProperty.get("value");
			if (stateProperty != null) {
				var properties = cellData.contentItem.properties.items ? cellData.contentItem.properties.items : cellData.contentItem.properties;
				const property = properties.filter(property => property.id === stateProperty);
				if (property != null && property.length > 0) {
					var objectValue = property[0].objectValue;
					if (objectValue) {
						// State property is an object value property... now need to figure out which property on the ovp to use as the state
						var stateSecondaryProperty = view.context.options.stateSecondaryProperty.get("value");
						if (stateSecondaryProperty != null) {
							var properties = objectValue.properties.items ? objectValue.properties.items : objectValue.properties;
							const property = properties.filter(property => property.id === stateSecondaryProperty);
							if (property != null && property.length > 0) {
								var value = property[0].value; // filter returns a list, so need to grab first item
								view._renderCustomStateImage(view, iconDiv, stateSecondaryProperty, value);
							}
						} else {
							domClass.add(iconDiv, "spacer");
						}
					} else {
						var value = property[0].value; // filter returns a list, so need to grab first item
						view._renderCustomStateImage(view, iconDiv, stateProperty, value);
					}
				} else {
					domClass.add(iconDiv, "spacer");
				}
			}
			return iconDiv;
		};

		this.constructor.prototype._renderCustomStateImage = function(view, iconDiv, stateProperty, value) {
			if (value != null) {
				var className = stateProperty;
				if (isNaN(value)) {
					if (typeof value == 'string') {
						className += value.replace(/\s+/g, ''); // remove spaces
						domAttr.set(iconDiv, "title", value);
						domAttr.set(iconDiv, "alt", value);
					} else {
						domClass.add(iconDiv, "spacer");
					}
				} else {
					className += value; // numeric values
					domAttr.set(iconDiv, "title", messages["status_" + value]);
					domAttr.set(iconDiv, "alt", messages["status_" + value]);
				}
				// "Uploading, "Processing", and "Reprocessing" need special css class
				if (value == 5 || value == 20 || value == 25) {
					className += " " + "CS_Processing";
				}
				domClass.add(iconDiv, "ftImageDivCustom " + className);
			} else {
				domClass.add(iconDiv, "spacer");
			}
		};
		
		this.constructor.prototype._createStateImage = function(view, data) {
			var imgDiv = document.createElement("div");
			domClass.add(imgDiv, "ftImageDiv");

			if (data.contentItem.baseType == this._proto.typeAbstract && data.contentItem.className == "DbaClassificationBatch") {
				var properties = data.contentItem.properties.items ? data.contentItem.properties.items : data.contentItem.properties;
				var propLeaseTime = properties.find(property => property.id == "DbaLeaseTime");
				if (propLeaseTime && propLeaseTime.value && propLeaseTime.value != "") {
					var leaseTime = new Date(propLeaseTime.value); // value is a string
					var rightNow = new Date();
					if (leaseTime.getTime() > rightNow.getTime()) {
						// display lock icon, get last modifier too
						var srcBlank = com_ibm_bpm_coach.getManagedAssetUrl('CS-ContentList-States.png', com_ibm_bpm_coach.assetType_WEB, 'SYSCST', false);
						// Add the lock icon image first
						var img = document.createElement("img");
						domClass.add(img, "isLockedIcon");
						domAttr.set(img, "src", srcBlank);
						var lockedBy =  messages.contlist_locked;
						var propLastModifier = properties.find(property => property.id == "LastModifier");
						if (propLastModifier && propLastModifier.value) {
							lockedBy = string.substitute(messages.contlist_locked_by, [propLastModifier.value]);
						}					
						domAttr.set(img, "title", lockedBy);
						domAttr.set(img, "alt", lockedBy);
						imgDiv.appendChild(img);
					} else {
						var divIcon = document.createElement("div");
						domClass.add(divIcon, "spacer");
						imgDiv.appendChild(divIcon);
					}
				} else {
					var divIcon = document.createElement("div");
					domClass.add(divIcon, "spacer");
					imgDiv.appendChild(divIcon);
				}
			} else if (data.contentItem.isReserved) {
				var srcBlank = com_ibm_bpm_coach.getManagedAssetUrl('CS-ContentList-States.png', com_ibm_bpm_coach.assetType_WEB, 'SYSCST', false);
				// Add the lock icon image first
				var img = document.createElement("img");
				domClass.add(img, "isLockedIcon");
				domAttr.set(img, "src", srcBlank);
				var checkedoutBy = messages.contlist_checked_out;
				if (data.contentItem.reservation && data.contentItem.reservation.creator) {
					checkedoutBy = string.substitute(messages.contlist_checked_out_by, [data.contentItem.reservation.creator]);
				}
				domAttr.set(img, "title", checkedoutBy);
				domAttr.set(img, "alt", checkedoutBy);
				imgDiv.appendChild(img);
			} else {
				var divIcon = document.createElement("div");
				domClass.add(divIcon, "spacer");
				imgDiv.appendChild(divIcon);
			}
			return imgDiv;
		};
		
		this.constructor.prototype._getMessageDiv = function(mainCss, imageCss, textCss, width, cursor, message, title) {
			var mainDiv = document.createElement("div");
			domClass.add(mainDiv, mainCss);
			if (width) {
				domStyle.set(mainDiv, "width", width);
			}
			if (cursor) {
				domStyle.set(mainDiv, "cursor", "pointer");
			}
			var imageDiv = document.createElement("div");
			domClass.add(imageDiv, imageCss + " CS_IssuesImage");
			if (title) {
				domAttr.set(imageDiv, "title", title);
			} else {
				domAttr.set(imageDiv, "title", messages.contlist_click_see_more);
			}
			mainDiv.appendChild(imageDiv);							
			var textDiv = document.createElement("div");
			domClass.add(textDiv, textCss);
			textDiv.textContent = message;
			mainDiv.appendChild(textDiv);
			return mainDiv;
		};
		
		this.constructor.prototype._getErrorMessage = function(message) {
			var displayMessage = "";
			// Should be json string, need to parse it back into object
			var messageObj = JSON.parse(message);
			if (messageObj) {
				var errors = messageObj.errors;
				if (Array.isArray(errors)) {
					// Loop through the error objects and accumulate them in one string
					errors.forEach(function(error) {
						displayMessage += error.Message + "\n";
					});
				} else {
					// Single message object (not an array)
					displayMessage = errors.Message;
				}
			}
			return displayMessage;
		};
		
		this.constructor.prototype._createInlineProgressDiv = function(view, data, percentDone, cancelFunction){
			var enclosingDiv = document.createElement("div");
			domClass.add(enclosingDiv, "CS_ProgessBarContainer");
			
			var progressBarDiv = document.createElement("div");
			enclosingDiv.appendChild(progressBarDiv);
			domClass.add(progressBarDiv, "CS_InlineProgressBarTrack");
			
			var progressBarIndicator = document.createElement("div");
			domClass.add(progressBarIndicator, "CS_InlineProgressBar");
			progressBarDiv.appendChild(progressBarIndicator);
			domStyle.set(progressBarIndicator, "width", percentDone + "%");
			
			var percentDoneTooltip = string.substitute(messages.contlist_inline_progress_percent, [percentDone]);
			domAttr.set(progressBarDiv, "title", percentDoneTooltip);
			domAttr.set(progressBarDiv, "title", percentDoneTooltip);
			
			if (cancelFunction){
				var cancelIcon = document.createElement("div");
				domClass.add(cancelIcon, "CS_Close");
				domAttr.set(cancelIcon, "title", "Cancel");
				domAttr.set(cancelIcon, "alt", "Cancel");
				domAttr.set(cancelIcon, "tabindex", "0");
				cancelIcon.addEventListener("click", cancelFunction);
				enclosingDiv.appendChild(cancelIcon);
			}
			
			return enclosingDiv;
		};
		
		this.constructor.prototype._renderDateValue = function(view, cell, data, columnSpec, value) {
			var displayValue;
			if (value) {
				cell.setSortValue(value);

				var includeTimeInDates = view.context.options.includeTimeInDates.get("value");
				var dateOptions = {
					selector: "date",
					datePattern: includeTimeInDates ? this._proto.defaultDateTimePattern : this._proto.defaultDatePattern
				};
				// If user has configured custom date pattern, use that for display format
				if (columnSpec.options.datePattern  != null) {
					dateOptions.datePattern = columnSpec.options.datePattern;
				}
				displayValue = dateLocale.format(new Date(value), dateOptions);
			}
			
			var div = document.createElement("div");
			div.textContent = displayValue;
			return div;
		};
	
		this.constructor.prototype._createFolderLink = function(view, row, cell) {
			var a = document.createElement("a");
			a.href = "javascript:void(0)";
			domAttr.set(a, "role", "link");
			var data = row.data;

			// This is a folder, need to add the folder navigation behavior
			a.onclick = function() {
				view._proto._onFolderClick(view, row);
			};
			a.addEventListener('keypress', function(evt) {
				var keyID = (evt.charCode) ? evt.charCode : ((evt.which) ? evt.which : evt.keyCode);
				if (keyID == 13 || keyID == 32) {
					if (!domClass.contains(this, "disabled")) {
						view._proto._onFolderClick(view, row);
					}
				}
				return true;
			});
			
			if (cell != null) {
				var	content = data[cell.varName];
				a.textContent = content;
				domAttr.set(a, "title", content);
				
				// This call tells the Data Table to sort using this value and not the displayed one
				// We are prefixing the real value with a string that places folders before documents 
				// on initial sort. Using a number so it works on different locals
				cell.setSortValue("1." + content);
			}
			return a;
		};
		
		this.constructor.prototype._createDocumentLink = function(view, row, cell, actionsEnabled) {
			var data = row.data;
			var a;
			if (actionsEnabled) {
				a = document.createElement("a");
				a.href = "javascript:void(0)";
				domAttr.set(a, "role", "link");
			
				a.onclick = function(){
					view._proto._onFileClick(view, row);
				};
			
				a.addEventListener('keypress', function(evt) {
					var keyID = (evt.charCode) ? evt.charCode : ((evt.which) ? evt.which : evt.keyCode);
					if (keyID == 13 || keyID == 32) {
						if (!domClass.contains(this, "disabled")) {
							view._proto._onFileClick(view, row);
						}
					}
					return true;
				});
			} else {
				// Just plain div, no anchor or link css styling
				a = document.createElement("div");
			}
			
			// Don't add title text if not specified
			if (cell != null) {
				var	content = data[cell.varName];
				a.textContent = content;
				
				// This call tells the Data Table to sort using this value and not the displayed one
				// We are prefixing the real value with a string that places documents after folders
				// on initial sort. Using a number so it works on different locals
				cell.setSortValue("2." + content);

			}
			return a;
		};
		
		this.constructor.prototype._createMimeImage = function(view, cellData, a) {
			var	srcBlank = com_ibm_bpm_coach.getManagedAssetUrl('CS-blank.gif', com_ibm_bpm_coach.assetType_WEB, 'SYSCST', false);
			
			var iconDiv = document.createElement("div");
			domClass.add(iconDiv, "ftImageDiv");

			var iconImg = document.createElement("img");
			domClass.add(iconImg, view._proto._getMimeCssClass(cellData.contentItem));
			domAttr.set(iconImg, "src", srcBlank);
			if (cellData.contentItem.mimeType == null || cellData.contentItem.mimeType == "" ) {
				if (view._proto._getType(cellData.contentItem) == view._proto.typeFolder) {
					domAttr.set(iconImg, "title", messages.contlist_folder_mimetype); 
					domAttr.set(iconImg, "alt", messages.contlist_folder_mimetype);
				} else if (view._proto._getType(cellData.contentItem) == view._proto.typeAbstract) {
					domAttr.set(iconImg, "title", messages.contlist_batch_mimetype); 
					domAttr.set(iconImg, "alt", messages.contlist_batch_mimetype);
				} else {
					domAttr.set(iconImg, "title", messages.contlist_no_mimetype);
					domAttr.set(iconImg, "alt", messages.contlist_no_mimetype);
				}
			} else {
				domAttr.set(iconImg, "title", cellData.contentItem.mimeType);
				domAttr.set(iconImg, "alt", cellData.contentItem.mimeType);
			}
			
			a.appendChild(iconImg);
			domClass.add(a, "ftImageAnchor");
			iconDiv.appendChild(a);

			return iconDiv;
		};

		this.constructor.prototype._createNameLink = function(view, cell, a, displayResState, displayCusState, enabled) {
			var nameDiv = document.createElement("div");
			if (displayResState && displayCusState) {
				domClass.add(nameDiv, "MainNameLink2");
			} else if (displayResState || displayCusState) {
				domClass.add(nameDiv, "MainNameLink1");
			} else {
				domClass.add(nameDiv, "MainNameLink0");
			}
	
			var childDiv = document.createElement("div");
			if (enabled) {
				domClass.add(childDiv, "NameLink");
			} else {
				domClass.add(childDiv, "NameLinkDisabled");
			}
			childDiv.appendChild(a);
			
			nameDiv.appendChild(childDiv);
			
			return nameDiv;
		};
	
		this.constructor.prototype._renderContextMenuButton = function(view, cell) {
			var div = document.createElement("div");
			domAttr.set(div, "tabindex", "0");
			domAttr.set(div, "aria-label", "Open context menu button"); // Todo: add to resource bundle
			domClass.add(div, "bx--overflow-menu");
			
			// Save the context menu button div off for later, when we want to close the menu and restyle the button
			view._instance.ctxMenuButtonDiv = div;			
			
			div.onclick = function(event) {
				view._instance.event = event;
				var isVisible = view._proto._determineContextMenuPopupVisibility(view, cell);
				view._proto._showHideContextMenuPopup(view, cell, isVisible);
				domAttr.set(div, "aria-expanded", isVisible);
				view._proto._showHideContextMenuButton(event.srcElement, true);
			};
			
			div.addEventListener('keypress', function(evt) {
				var keyID = (evt.charCode) ? evt.charCode : ((evt.which) ? evt.which : evt.keyCode);
				if (keyID == 13 || keyID == 32) {
					if (!domClass.contains(this, "disabled")) {
						view._instance.event = evt;
						var isVisible = view._proto._determineContextMenuPopupVisibility(view, cell);
						view._proto._showHideContextMenuPopup(view, cell, isVisible);
						domAttr.set(div, "aria-expanded", isVisible);
						view._proto._showHideContextMenuButton(event.srcElement, true);
					}
					evt.preventDefault();
				}
			});

			var	srcCtxButton = com_ibm_bpm_coach.getManagedAssetUrl('CS-ContextMenuButton.svg', com_ibm_bpm_coach.assetType_WEB, 'SYSCST', false);

			var iconImg = document.createElement("img");
			domClass.add(iconImg, "bx--overflow-menu__icon");
			domAttr.set(iconImg, "src", srcCtxButton);

			div.appendChild(iconImg);
			
			return div;
		};
				
		this.constructor.prototype._onRenameFolderBtnClicked = function() {
			try {
				this._proto._onRenameFolderBtnClicked(this);
			} catch (e) {
				bpmext.log.error("Error on AJAX service invocation [" + this.context.viewid + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};

		this.constructor.prototype._onDeleteObjectBtnClicked = function() {
			try {
				this._proto._onDeleteObjectBtnClicked(this);
			} catch (e) {
				bpmext.log.error("Error on AJAX service invocation [" + this.context.viewid + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};
		
		this.constructor.prototype._onAddActionClicked = function(command) {
			try {
				this._proto._onAddActionClicked(this, command);
			} catch (e) {
				bpmext.log.error("Error on AJAX service invocation [" + this.context.viewid + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};
		
		this.constructor.prototype._onDocumentStatus = function(results) {
//			console.log("CS-ContentList:_onDocumentStatus() Results: " + JSON.stringify(results));
			console.log("CS-ContentList:_onDocumentStatus() called from: " + this.context.viewid);			

			var contentElements = results.contentElements ? results.contentElements.items ? results.contentElements.items : results.contentElements: [];
			if (results.documentId){
				var contentItem = {
					name: results.name,
					id: results.documentId,
					mimeType: results.mimeType,
					baseType: results.baseType,
					contentElements: contentElements,
					className: results.className,
					properties: results.properties					
				}
				
				var boundItem = this.context.binding.get("value");
				if (boundItem && boundItem.id == contentItem.id) {
					var foundChange = false;
					var contentItemProperties =  contentItem.properties.items ? contentItem.properties.items : contentItem.properties;
					var boundItemProperties = boundItem.properties.items ? boundItem.properties.items : boundItem.properties;
					for (var i = 0; i < contentItemProperties.length; i++){
						contentItemProperty = contentItemProperties[i];
						var boundItemProperty = boundItemProperties.find(property => property.id == contentItemProperty.id);
						if (boundItemProperty){
							if (boundItemProperty.value != contentItemProperty.value && contentItemProperty.type != "OBJECT"){
								console.log("CS-ContentList:_onDocumentStatus(): Found property change for property " + contentItemProperty.id + ". Old value: " + boundItemProperty.value + " New value: " + contentItemProperty.value);
								foundChange = true;
								break;
							}
							if (contentItemProperty.objectValue && boundItemProperty.objectValue){
								contentItemOVPProperties = contentItemProperty.objectValue.properties.items ? contentItemProperty.objectValue.properties.items : contentItemProperty.objectValue.properties;
								boundItemOVPProperties = boundItemProperty.objectValue.properties.items ? boundItemProperty.objectValue.properties.items : boundItemProperty.objectValue.properties;
								for (var j = 0; j < contentItemOVPProperties.length; j++){
									var contentItemOVPProperty = contentItemOVPProperties[j];
									var boundItemOVPProperty = boundItemOVPProperties.find(ovpProperty => ovpProperty.id == contentItemOVPProperty.id);
									if (boundItemOVPProperty && boundItemOVPProperty.value != contentItemOVPProperty.value){
										console.log("CS-ContentList:_onDocumentStatus(): Found OVP property change for ovpproperty " + contentItemOVPProperty.id + ". Old value: " + boundItemOVPProperty.value + " New value: " + contentItemOVPProperty.value);
										foundChange = true;
										break;
									}
								}
							}
						}
					}	
					if (foundChange){
						// Set the binding when a property change is found to update other views bound to the same item.
						this.context.binding.set("value", contentItem);
					}
				}
				this._proto._refreshTableRow(this, null, null, results.properties, results.documentId, contentElements, contentItem);
			}
			
			var displayingProgressIndicator = this.context.options.displayProgressIndicator.get("value");
			if (results.terminal) {
				if (results.documentId) {					
					if (!this._instance.lastProcessedContentItems) {
						this._instance.lastProcessedContentItems = {};
					}
					this._instance.lastProcessedContentItems[results.documentId] = contentItem;
					
					// If we aren't displaying the progress indicator, display a message that monitoring has timed out.
					if (results.processingStatus == "Timeout" && !displayingProgressIndicator) {
						var alertElem = document.querySelector(".CS_Alert");
						if (!alertElem) {
							setAlertMessage(messages.contlist_progress_alert, messages.contlist_polling_timeout, "I", -1, domClass, domStyle, domAttr, messages);
						}

						// Remove the progress icon from the item...
						var itemsList = this._instance.contentTable._instance.list.list.items ? this._instance.contentTable._instance.list.list.items : this._instance.contentTable._instance.list.list;
						var item = itemsList.find(listItem => listItem.contentItem.id == results.documentId);
						if (item) {
							var ctx = this._instance.contentTable._instance.list.getItemContext(item);
							var statusDiv = ctx.tr.querySelector(".CS_Processing");
							if (statusDiv){
								domClass.remove(statusDiv, "CS_Processing");
																	
								var stateProperty = this.context.options.stateProperty.get("value");
								if (stateProperty != null) {
									var properties = item.contentItem.properties.items ? item.contentItem.properties.items : item.contentItem.properties;
									const property = properties.filter(property => property.id === stateProperty);
									if (property != null && property.length > 0) {
										var objectValue = property[0].objectValue;
										if (objectValue) {
											// State property is an object value property... now need to figure out which property on the ovp to use as the state
											var stateSecondaryProperty = this.context.options.stateSecondaryProperty.get("value");
											if (stateSecondaryProperty != null) {
												var properties = objectValue.properties.items ? objectValue.properties.items : objectValue.properties;
												const property = properties.filter(property => property.id === stateSecondaryProperty);
												if (property != null && property.length > 0) {
													var value = property[0].value;
													domClass.remove(statusDiv, stateSecondaryProperty + value);
												}
											} else {
												var value = property[0].value;
												domClass.remove(statusDiv, stateProperty + value);
											}
										} else {
											var value = property[0].value;
											domClass.remove(statusDiv, stateProperty + value);
										}
									}
								}

							}
						}
					}
				}
				
				if (results.numberDocumentsProcessing < 1) {
					// Allow adding documents if we are done.
					this._instance.inUpdateDocument = false;
				}
			}
	
			if (displayingProgressIndicator) {
				this._instance.progressIndicator.updateFromPolling(results);
			}
		};

		this.constructor.prototype._onDocumentStatusError = function(message) {
			console.log("CS-ContentList:_onDocumentStatusError() :  Messasge : " + message);
			this._instance.inUpdateDocument = false;
			this._proto._setAlertMessage(this, message, true);
			if (this.context.options.displayProgressIndicator.get("value")) {
				this._instance.progressIndicator.updateHeader(messages.contlist_progress_error, "error");
			}
		};
		
		this.constructor.prototype._onPollResults = function(results) {
			bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONPOLLRESULTS, results);
		};
		
		this.constructor.prototype._onProgressIndicatorClose = function() {
			if (!this._proto._isPollingForItemInList(this)) {
				this._instance.propertyPoller.pausePolling();
			}
		};
		
		this.constructor.prototype._openActionsMenu = function(actionsButton) {
			var isVisible = this._proto._determineActionsMenuPopupVisibility(this);
			this._proto._showHideActionsPopup(this, actionsButton, isVisible);
		};
		
		this.constructor.prototype._onProcessIndicatorRemovePendingFile = function(view, batchId, fileName) {
			this._instance.uploadContent.removeFileFromQueue(batchId, fileName);
			var addDocPropsTable = this.ui.get("AddDocPropsTable");
			addDocPropsTable._onProcessIndicatorRemovePendingFile(batchId, fileName);
		};
		
		this.constructor.prototype.bindToLastProcessedDocument = function(documentId) {
			console.log("CS-ContentList:bindToLastProcessedDocument() called");
			if (this._instance.lastProcessedContentItems && this._instance.lastProcessedContentItems[documentId]) {
				this.context.binding.set("value", this._instance.lastProcessedContentItems[documentId]);
			}
		};
		
		this.constructor.prototype.displayProgressIndicatorForBinding = function(display) {
			if (display) {
				var contentItem = this.context.binding.get("value");
				this._instance.progressIndicator.show(contentItem.id, contentItem.name, 20);
				this._proto._initiateStatusPolling(this, contentItem.id, contentItem.properties, true)
			} else {
				this._instance.progressIndicator.hideDisplay();
			}
		};
		
		this.constructor.prototype.isUploadingDocuments = function(){
			var isUploading = this._instance.uploadContent.isUploadingNewDocuments();
			if (!isUploading){
				var addDocPropsTable = this.ui.get("AddDocPropsTable");
				isUploading = addDocPropsTable.isUploadingDocuments();
			}
			return isUploading;
		};
		
		this.constructor.prototype.canEditProperties = function(contentItem) {
			if (contentItem && contentItem.accessAllowed) {
				var canEditProperties = (contentItem.accessAllowed & this._proto.privilegeToBitmask["privEditProperties"]) > 0;
				return canEditProperties;
			} else {
				return false;
			}
		};
		
		/**
         * @instance
         * @memberof CS-ContentList
         * @method uploadBatch
         * @desc Checks the current users security rights to add a batch and then opens the upload batch modal dialog.
         */
		this.constructor.prototype.uploadBatch = function() {
			console.log("CS-ContentList:uploadBatch() : Called");
			var configuredDocumentClasses = this.context.options.documentClasses.get("value");
			var documentClasses = configuredDocumentClasses ? configuredDocumentClasses.items ? configuredDocumentClasses.items : configuredDocumentClasses : null;
			var numDocumentClasses = documentClasses ? documentClasses.length : 0;
			if (numDocumentClasses == 1) {
				var self = this;
				this._instance.getContent.getClassAccess("ClassDefinition", "DbaClassificationBatch", null, function(accessAllowed) {
					var	canAddBatch = (accessAllowed & self._proto.privilegeToBitmask["privAddItem"]) > 0;
					if (canAddBatch) {
						self._proto._showHideAddBatchModal(self, true);
					} else {
						self._proto._setAlertMessage(this, messages.contlist_batch_create_error, true, 6000);		
					}
				}, function(error) {
					self._proto._setAlertMessage(this, messages.contlist_batch_create_error, true, 6000);		
				});
			} else {
				// If more than one class (or no class) is configured, then display an error message
				var message = string.substitute(messages.contlist_batch_class_config_error, [numDocumentClasses]);
				this._proto._setAlertMessage(this, message, true);
			}	
		};
		
		this.constructor.prototype.onInsertBatchDocument = function(contentItem, action){
			// Valid values for action are "insertAbove", "insertBelow", and "replaceDocument".
			this._proto._displayFileDialog(this, null, action, contentItem);
		};
		
		/**
		 * @instance
		 * @memberof CS-ContentList
		 * @method setLabel
		 * @desc Sets the view label.
		 * @param {string} label The new label.
		 */
		this.constructor.prototype.setLabel = function(lbl) {
			this.context.options._metadata.label.set("value", lbl);
		};

		/**
		 * @instance
		 * @memberof CS-ContentList
		 * @method getLabel
		 * @desc Returns the view label.
		 * @returns {string}
		 */
		this.constructor.prototype.getLabel = function() {
			return this.context.options._metadata.label.get("value");
		};
		
		/**
		 * @instance
		 * @memberof CS-ContentList
		 * @method setRecordSelected
		 * @desc Selects or deselects a record from the document list.
		 * @param {Object} record The record to select.
		 * @param {boolean} selected The selection value (where 'true' is selected and 'false' is deselected).
		 */
		this.constructor.prototype.setRecordSelected = function(record, selected) {
			this._instance.contentTable.setRecordSelected(record, selected);
		};

		/**
		 * @instance
		 * @memberof CS-ContentList
		 * @method getSelectedRecord
		 * @desc Returns the selected record from the document list.
		 * @returns {Object}
		 */
		this.constructor.prototype.getSelectedRecord = function() {
			return this._instance.contentTable.getSelectedRecord();
		};

		/**
         * @instance
         * @memberof CS-ContentList
         * @method setAllRecordsSelected
         * @param {boolean} selected Flag to indicate whether to select or unselect the records
         * @param {boolean} asInTable (Only used with index) If true, sets the selected status of the records that are not filtered out, if false or omitted sets the selected status of all records regardless of filtering
         * @desc Selects or unselects records
         */
        this.constructor.prototype.setAllSelected = function(selected, asInTable, selMode) {
			return;
		};

		/**
		 * @instance
		 * @memberof CS-ContentList
		 * @method clearAllSelection
		 * @desc Deselects the selected records in the document list.
		 */
		this.constructor.prototype.clearAllSelection = function() {
			var selectedRecords = this._instance.contentTable.getSelectedRecords();
			if (selectedRecords) {
				if (selectedRecords.length == 1) {
					this._instance.contentTable.setRecordSelected(selectedRecords[0], false);
				} else if (selectedRecords.length > 1) {
					this._instance.contentTable.setAllRecordsSelected(false);
				}
			}
		};
		
		/**
         * @instance
         * @memberof CS-ContentList
         * @method executeSearch
         * @param {string} searchValue property value to search on
         * @param {string} sortProperty property id to sort the results on (optional).
         * @param {string} sortOrder property value to order the results on "ASC" or "DESC" (Optional)
         * @desc Executes the configured search with the specified search property value and renders the results.
         */
		this.constructor.prototype.executeSearch = function(searchValue, sortProperty, sortOrder) {
			console.log("CS-ContentList:executeSearch() : called with value = " + searchValue);
			if (searchValue != null) {
				this._instance.contentListFilterText.setText(searchValue);
			}
			if (sortProperty != null) {
				this._instance.sortProperty = sortProperty; // Save this for paging and refresh scenarios
			}
			if (sortOrder != null) {
				this._instance.sortOrder = sortOrder;  // Save this for paging and refresh scenarios
			}
			this._proto._getSearchResults(this, searchValue, sortProperty, sortOrder); 
		};
	
		/**
         * @instance
         * @memberof CS-ContentList
         * @method executeSearchOnFilter
         * @param {string} searchValue property value to search on
         * @param {string} sortProperty property id to sort the results on (optional).
         * @param {string} sortOrder property value to order the results on "ASC" or "DESC" (Optional)
         * @desc Executes the configured search with the specified search property value and renders the results.
         */
		this.constructor.prototype.executeSearchOnFilter = function(searchValues, sortProperty, sortOrder) {
			console.log("CS-ContentList:executeSearchOnFilter() : called");

			this._instance.searchValues = searchValues;
			this._proto._getSearchResults(this, "searchValue", sortProperty, sortOrder, searchValues); 
		};
		
		/**
         * @instance
         * @memberof CS-ContentList
         * @method resetSearchOnFilter
         * @desc Resets the configured search with the specified search property values and renders the results.
         */
		this.constructor.prototype.resetSearchOnFilter = function() {
			console.log("CS-ContentList:resetSearchOnFilter() : called");

			this._instance.searchValues = null;
			this._proto._showHideFilter(this, false);

			this._proto._getSearchResults(this, "searchValue", null, null); 
		};
	
		/**
         * @instance
         * @memberof CS-ContentList
         * @method setContentItems
         * @param {CSContentItems[]} contentItems List of CSContentItem objects, the "id" property is only required property on the objects (will assume Document)
         * @desc Sets the list of items into the list view.
         */
		this.constructor.prototype.setContentItems = function(contentItems) {
			console.log("CS-ContentList:setContentItems() : called");
			if (contentItems != null) {
				this._instance.contentItems = contentItems;
			} else {
				// Call was made with a null list, just create an empty array (will render 0 items)
				this._instance.contentItems = [];
			}
			this._proto._refresh(this, null, null);
		};

		/**
         * @instance
         * @memberof CS-ContentList
         * @method getBatchContentItems
         * @param {CSContentItem} contentItem is the Batch collection object
         * @desc Sets the list of items into the list view.
         */
		this.constructor.prototype.getBatchContentItems = function(contentItem) {
			console.log("CS-ContentList:getBatchContentItems() : called for batch: " + contentItem.id);
			if (contentItem != null) {
				// clear old results in case we have an error so we don't leave stale data.
				if (this._instance.contentTable && this._instance.contentTable._instance.list != null) {
//					this._instance.contentTable.clear();
//					this._instance.contentTable.refresh(true);
				}

				// This is a abstract persistable batch collection object
				this._instance.currentBatch = contentItem;
				this._proto._getBatchDocuments(this, contentItem);
			} else {
				// Call was made with a null list, just create an empty array (will render 0 items)
				this._instance.contentItems = [];
				this._proto._refresh(this, null, null);
			}
		};

		/**
         * @instance
         * @memberof CS-ContentList
         * @method getContextMenuContentItem
         * @desc Returns the contentItem object that was used to open the context menu.
         */
		this.constructor.prototype.getContextMenuContentItem = function() {
			var contentItem;
			if (this._instance.cellData) {
				contentItem = this._instance.cellData.contentItem;
				if (contentItem != null) {
					console.log("CS-ContentList:getContextMenuContentItem() : called for: " + contentItem.name);
				} else {
					console.log("CS-ContentList:getContextMenuContentItem() : called and no contentItem specified.");
				}
			} else {
				console.log("CS-ContentList:getContextMenuContentItem() : Contenxt menu was not clicked to open, no contentItem has been selected to return.");
			}
			return contentItem;
		};
				
		/**
         * @instance
         * @memberof CS-ContentList
         * @method addContextMenuAction
         * @param {string} id of the context menu action
         * @param {string} name of the context menu items to display
		 * @param {string} type type of object to add this context menu action to "document", "folder" or "abstract"
		 * @param {boolean} enabled whether the context menu action is enabled in the menu or not
		 * @param {function} onClickFunc function that will be called when the context menu item is clicked
		 * @param {integer} index where to add the new action, if null will add action to end of list
         * @desc Adds a custom context menu action to the context menu.
         */
		this.constructor.prototype.addContextMenuAction = function(id, name, type, enabled, onClickFunc, index) {
			console.log("CS-ContentList:addContextMenuAction() : called with name: " + name + " at index: " + index);
			var addItem = false;
			if (type == null) {
				// If type is null, then add the custom menu action to all menu types
				addItem = true;
			} else if (type == "document" && this._proto._getType(this._instance.cellData.contentItem) == this._proto.typeDocument) {
				// Add the custom menu action to document context menus
				addItem = true;
			} else if (type == "folder" && this._proto._getType(this._instance.cellData.contentItem) == this._proto.typeFolder) {
				// Add the custom menu action to folder context menus
				addItem = true;
			} else if (type == "abstract" && this._proto._getType(this._instance.cellData.contentItem) == this._proto.typeAbstract) {
				// Add the custom menu action to abstract object context menus
				addItem = true;
			}
			
			if (addItem) {
				var actions = this._instance.menu._ptMenuItems;
				if (actions != null) {
					var action = {	
						actionId: id,
						icon: null,
						text: name,
						badgeText: "",
						isEnabled: enabled,
						onclick: onClickFunc
					};
					
					if (index == null || index > actions.length) {
						// Add the action to the end of the list
						actions.push(action);
					} else {
						// Add the action at the index specified
						actions.splice(index, 0, action);
					}
				}
			} else {
				console.log("CS-ContentList:addContextMenuAction() : no context menu action added.");
			}
		};		

		/**
         * @instance
         * @memberof CS-ContentList
         * @method addActionMenuAction
         * @param {string} id of the action menu action
         * @param {string} name of the action menu items to display
		 * @param {boolean} enabled whether the action menu action is enabled in the menu or not
		 * @param {function} onClickFunc function that will be called when the action menu item is clicked
		 * @param {integer} index where to add the new action, if null will add action to end of list
         * @desc Adds a custom context menu action to the context menu.
         */
		this.constructor.prototype.addActionMenuAction = function(id, name, enabled, onClickFunc, index) {
			console.log("CS-ContentList:addActionMenuAction() : called with name: " + name + " at index: " + index);
			var actions = this._instance.actions._ptMenuItems;
			if (actions != null) {
				var action = {	
					actionId: id,
					icon: null,
					text: name,
					badgeText: "",
					isEnabled: enabled,
					onclick: onClickFunc
				};
				
				if (index == null || index > actions.length) {
					// Add the action to the end of the list
					actions.push(action);
				} else {
					// Add the action at the index specified
					actions.splice(index, 0, action);
				}
			}
		};		

		/**
         * @instance
         * @memberof CS-ContentList
         * @method addContextMenuSeparator
		 * @param {integer} index where to add the separator bar, if null will add action to end of list
         * @desc Adds a context menu separator bar to the context menu.
         */
		this.constructor.prototype.addContextMenuSeparator = function(index) {
			console.log("CS-ContentList:addContextMenuSeparator() : called at index: " + index);
			var actions = this._instance.menu._ptMenuItems;
			if (actions != null) {
				var action = {	
					actionId: "__separator",
					icon: null
				};
				
				if (index == null || index > actions.length) {
					// Add the action to the end of the list
					actions.push(action);
				} else {
					// Add the action at the index specified
					actions.splice(index, 0, action);
				}
			}
		};
		
		/**
         * @instance
         * @memberof CS-ContentList
         * @method refreshListRow
         * @param {string} id of the context menu action
 		 * @param {CSDocument} contentItem object holding updated information that should be refreshed in list view
         * @desc Refreshes the list view row 
         */
		this.constructor.prototype.refreshListRow = function(actionId, contentItem) {
			var contentItemBinding = this.context.binding.boundObject.contentItem;	
			if (contentItemBinding != null && contentItem.id == contentItemBinding.id) {
				console.log("CS-ContentList:refreshListRow() : Set binding called with item: " + contentItem.name + " at row: " + contentItem.rowIndex);
				var row = {
					index: contentItem.rowIndex
				};
				this._proto._setBindingObject(this, row, contentItem, false, false); // Will force a call to _refreshTableRow
			} else {
				console.log("CS-ContentList:refreshListRow() : Refresh table row called with item: " + contentItem.name + " at row: " + contentItem.rowIndex);
				var properties = contentItem.properties;
				if (contentItem.properties.items) {
					properties = contentItem.properties.items;
				}
				this._proto._refreshTableRow(this, actionId, contentItem.rowIndex, properties, contentItem.id, null);
			}
		};
		
		/**
         * @instance
         * @memberof CS-ContentList
         * @method addAdditionalPropertyOnAdd
         * @param {string} id property to set
 		 * @param {Object} value of the property to set
         * @desc Adds additional property values that will be set on new documents.
         */
		this.constructor.prototype.addAdditionalPropertyOnAdd = function(additionalPropertyId, additionalPropertyValue){
			var uploadComponent = this.ui.get("UploadContent");
			uploadComponent.addAdditionalPropertyOnAdd(additionalPropertyId, additionalPropertyValue);
			var addDocumentPropertyList = this.ui.get("AddDocPropsTable");
			addDocumentPropertyList.addAdditionalPropertyOnAdd(additionalPropertyId, additionalPropertyValue);
		};
		
		/**
         * @instance
         * @memberof CS-ContentList
         * @method addProgressIndicatorLinkFunction
         * @param {string} status of document when link invoking function should be displayed in progrss indicator.
 		 * @param {Object} the function to call.
         * @desc Adds a function to the progress indicator that will be called when the user clicks the displayed link.
         */
		this.constructor.prototype.addProgressIndicatorLinkFunction = function(processingStatus, linkFunction){
			var progressIndicator = this.ui.get("ProgressIndicator");
			progressIndicator.addActionLinkFunction(processingStatus, linkFunction);
		};
		
		/**
         * @instance
         * @memberof CS-ContentList
         * @method addConfigValueOnAdd
         * @param {string} id of configuration value
 		 * @param {Object} configuration value
         * @desc Adds additional configuration values that will be saved as JSON data on new documents.
         */
		this.constructor.prototype.addConfigValueOnAdd = function(configId, configValue) {
			var opts = this.context.options;
			if (opts.jsonConfigProperty.get("value")){
				var uploadComponent = this.ui.get("UploadContent");
				var configProperty = opts.jsonConfigProperty.get("value");
				uploadComponent.addConfigValueOnAdd(configProperty, configId, configValue);
				var addDocumentPropertyList = this.ui.get("AddDocPropsTable");
				addDocumentPropertyList.addConfigValueOnAdd(configProperty, configId, configValue);
			}
		};

		/**
         * @instance
         * @memberof CS-ContentList
         * @method updateProperties
         * @param {string} objectType object holding type of object being processed Document, Folder or Abstract
         * @param {CSContentItem} contentItem object, used to retrieve id 
         * @param {string} properties object holding list of properties to be saved 
		 *                 in format suitable for graphql api [{PropSymName: "StringValue"},..]
         * @param {string} ovpPropertyId holding object value property id
         * @param {string} classId holding class type identifier
         * @desc Updates the property values for the object passed in. Properties are pass to graphql as they are (no conversion).
         */
		this.constructor.prototype.updateProperties = function(objectType, contentItem, properties, ovpPropertyId, classId) {
			console.log("CS-ContentList:updateProperties() : Updating the properties.");
			var params = {
				serverAppResource: this._instance.serverConfigurationName,
				repository: this._proto._getObjectStoreName(this),
				objectType: objectType,
				objectId: contentItem.id,
				ovpPropertyId: ovpPropertyId,
				classId: classId,
				properties: properties
			};
			var updatePropertiesSvc = this.ui.get("UpdatePropertiesSvc");
			this._proto._callService(updatePropertiesSvc, params);
		};

		/**
         * @instance
         * @memberof CS-ContentList
         * @method updateContentItemProperties
         * @param {CSContentItem} contentItem object holding list of properties to be saved
		 *                        in standard js format [{id: "propSymName", value: "StringValue", dataType: "STRING", cardinality: "SINGLE"},..]
         * @desc Updates the property values for the object passed in, will convert the passed in properties
		 *       into a format for passing into the update properties action service and graphql.
         */
		this.constructor.prototype.updateContentItemProperties = function(contentItem) {	
			console.log("CS-ContentList:updateContentItemProperties() : called.");
			if (contentItem) {
				this._proto._onUpdateProperties(this, contentItem);
			}
		};
		
		/**
         * @instance
         * @memberof CS-ContentList
         * @method stopPolling
         * @desc Stops and resets the property poller when polling is running.
         */
		this.constructor.prototype.stopPolling = function() {	
			console.log("CS-ContentList:stopPolling() : called.");
			if (this._instance.pollingEnabled) {
				this._instance.propertyPoller.stopPolling();
			}
		};
		
		/**
         * @instance
         * @memberof CS-ContentList
         * @method pausePolling
         * @desc Pauses the polling when the property poller is running. Polling can be resumed later by calling the resumePolling function.
         */
		this.constructor.prototype.pausePolling = function() {	
			console.log("CS-ContentList:pausePolling() : called.");
			if (this._instance.pollingEnabled) {
				this._instance.propertyPoller.pausePolling();
			}
		};
		
		/**
         * @instance
         * @memberof CS-ContentList
         * @method resumePolling
         * @desc Resumes polling when the property poller is paused.
         */
		this.constructor.prototype.resumePolling = function() {	
			console.log("CS-ContentList:resumePolling() : called.");
			if (this._instance.pollingEnabled) {
				this._instance.propertyPoller.resumePolling();
			}
		};

		/**
         * @instance
         * @memberof CS-ContentList
         * @method addFilterPropertyValue
		 * @param name Symbolic name (id) of the property you are referencing.
		 * @param value value of the property to use.
         * @desc Stores a list of filter property values that will be injected into the content list query filter at runtime.
         */
		this.constructor.prototype.addFilterPropertyValue = function(name, value) {	
			console.log("CS-ContentList:addFilterPropertyValue() : called for property: " + name + " value: " + value);
			if (name != null && value != null) {
				this._instance.filterPropertyValues.push({
					name: name,
					value: value
				});
			}
		};

		/*
		 * Coach NG Lifecycle methods *************************************************************
		 */
		 
		this.constructor.prototype.load = function() {
			console.log("CS-ContentList:load() : called from: " + this.context.viewid);
			try	{
				var opts = this.context.options;
				var mdt = opts._metadata;

				if (!opts.objectStoreName) {
                    opts.objectStoreName = bpmext.ui.substituteConfigOption(this, "objectStoreName", null);
				}

				// Behavior section
				if (!opts.selectionMode) {
					opts.selectionMode = bpmext.ui.substituteConfigOption(this, "selectionMode", "N");
				}
				if (!opts.rowHeight) {
					opts.rowHeight = bpmext.ui.substituteConfigOption(this, "rowHeight", "small");
				}
				if (!opts.initialPageSize) {
					opts.initialPageSize = bpmext.ui.substituteConfigOption(this, "initialPageSize", 20);
				}
				if (!opts.sortProperty) {
					opts.sortProperty = bpmext.ui.substituteConfigOption(this, "sortProperty", null);
				}
				if (!opts.sortOrder) {
					opts.sortOrder = bpmext.ui.substituteConfigOption(this, "sortOrder", null);
				}
				if (!opts.includeTimeInDates) {
					opts.includeTimeInDates = bpmext.ui.substituteConfigOption(this, "includeTimeInDates", false);
				}
				if (!opts.contentItems) {
					opts.contentItems = bpmext.ui.substituteConfigOption(this, "contentItems", null);
				}
				this._instance.contentItems = this.context.options.contentItems.get("value");

				if (!opts.height) {
					opts.height = bpmext.ui.substituteConfigOption(this, "height", null);
				}
				if (!opts.width) {
					opts.width = bpmext.ui.substituteConfigOption(this, "width", null);
				}
				if (!opts.nlResources) {
					opts.nlResources = bpmext.ui.substituteConfigOption(this, "nlResources", null);
				}
		
				// Folder section
				if (!opts.folderId) {
					opts.folderId = bpmext.ui.substituteConfigOption(this, "folderId", null);
				}
				this._instance.folderId = this.context.options.folderId.get("value");

				if (!opts.rootFolderName) {
					opts.rootFolderName = bpmext.ui.substituteConfigOption(this, "rootFolderName", null);
				}
	
				// Search section
				if (!opts.searchFolderId) {
					opts.searchFolderId = bpmext.ui.substituteConfigOption(this, "searchFolderId", null);
				}	
				if (!opts.searchOnlyFolder) {
					opts.searchOnlyFolder = bpmext.ui.substituteConfigOption(this, "searchOnlyFolder", false);
				}
				if (!opts.rootSearchName) {
					opts.rootSearchName = bpmext.ui.substituteConfigOption(this, "rootSearchName", null);
				}
				if (!opts.searchFor) {
					opts.searchFor = bpmext.ui.substituteConfigOption(this, "searchFor", this.typeDocument);
				}	
				if (!opts.searchType) {
					opts.searchType = bpmext.ui.substituteConfigOption(this, "searchType", null);
				}	
				if (!opts.searchProperty) {
					opts.searchProperty = bpmext.ui.substituteConfigOption(this, "searchProperty", null);
				}
				if (!opts.searchOperator) {
					opts.searchOperator = bpmext.ui.substituteConfigOption(this, "searchOperator", null);
				}
				if (!opts.searchValue) {
					opts.searchValue = bpmext.ui.substituteConfigOption(this, "searchValue", null);
				}
				if (!opts.searchPropertyType) {
					opts.searchPropertyType = bpmext.ui.substituteConfigOption(this, "searchPropertyType", "string");
				}
				if (!opts.searchPropertyCardinality) {
					opts.searchPropertyCardinality = bpmext.ui.substituteConfigOption(this, "searchPropertyCardinality", "SINGLE");
				}
				if (!opts.hideSearchField) {
					opts.hideSearchField = bpmext.ui.substituteConfigOption(this, "hideSearchField", false);
				}
				if (!opts.searchTextOption) {
					opts.searchTextOption = bpmext.ui.substituteConfigOption(this, "searchTextOption", "none");
				}
				if (!opts.enableSearchFilter) {
					opts.enableSearchFilter = bpmext.ui.substituteConfigOption(this, "enableSearchFilter", false);
				}
				
				// Actions section
				if (!opts.hideRefresh) {
					opts.hideRefresh = bpmext.ui.substituteConfigOption(this, "hideRefresh", false);
				}
				// Configuration options for the Add Toolbar button above the content list
				if (!opts.hideAddDocument) {
					opts.hideAddDocument = bpmext.ui.substituteConfigOption(this, "hideAddDocument", false);
				}
				if (!opts.hideAddFolder) {
					opts.hideAddFolder = bpmext.ui.substituteConfigOption(this, "hideAddFolder", false);
				}
				
				// Configuration options for the Document/Folder context menu actions
				if (!opts.hideRenameFolder) {
					opts.hideRenameFolder = bpmext.ui.substituteConfigOption(this, "hideRenameFolder", false);
				}
				if (!opts.hideEditFolderProperties) {
					opts.hideEditFolderProperties = bpmext.ui.substituteConfigOption(this, "hideEditFolderProperties", false);
				}
				if (!opts.hideDeleteFolder) {
					opts.hideDeleteFolder = bpmext.ui.substituteConfigOption(this, "hideDeleteFolder", false);
				}
				if (!opts.hideViewDocument) {
					opts.hideViewDocument = bpmext.ui.substituteConfigOption(this, "hideViewDocument", false);
				}
				if (!opts.hideUploadNewVersionDocument) {
					opts.hideUploadNewVersionDocument = bpmext.ui.substituteConfigOption(this, "hideUploadNewVersionDocument", false);
				}
				if (!opts.hideDownloadDocument) {
					opts.hideDownloadDocument = bpmext.ui.substituteConfigOption(this, "hideDownloadDocument", false);
				}
				if (!opts.hideEditDocument) {
					opts.hideEditDocument = bpmext.ui.substituteConfigOption(this, "hideEditDocument", false);
				}
				if (!opts.hideCheckoutDocument) {
					opts.hideCheckoutDocument = bpmext.ui.substituteConfigOption(this, "hideCheckoutDocument", false);
				}
				if (!opts.hideCancelCheckoutDocument) {
					opts.hideCancelCheckoutDocument = bpmext.ui.substituteConfigOption(this, "hideCancelCheckoutDocument", false);
				}
				if (!opts.hideEditDocumentProperties) {
					opts.hideEditDocumentProperties = bpmext.ui.substituteConfigOption(this, "hideEditDocumentProperties", false);
				}
				if (!opts.hideDeleteDocument) {
					opts.hideDeleteDocument = bpmext.ui.substituteConfigOption(this, "hideDeleteDocument", false);
				}
				if (!opts.documentClasses) {
					opts.documentClasses = bpmext.ui.substituteConfigOption(this, "documentClasses", null);
				}
				if (!opts.folderClasses) {
					opts.folderClasses = bpmext.ui.substituteConfigOption(this, "folderClasses", null);
				}
				if (!opts.includeTimePicker) {
					opts.includeTimePicker = bpmext.ui.substituteConfigOption(this, "includeTimePicker", false);
				}
				if (!opts.disableDragDropAdd) {
					opts.disableDragDropAdd = bpmext.ui.substituteConfigOption(this, "disableDragDropAdd", false);
				}
								
				// Advanced section
				if (!opts.stateProperty) {
					opts.stateProperty = bpmext.ui.substituteConfigOption(this, "stateProperty", null);
				}
				if (!opts.stateSecondaryProperty) {
					opts.stateSecondaryProperty = bpmext.ui.substituteConfigOption(this, "stateSecondaryProperty", null);
				}
				if (!opts.disabledValues) {
					opts.disabledValues = bpmext.ui.substituteConfigOption(this, "disabledValues", null);
				}
				if (!opts.displayCustomState){
					opts.displayCustomState = bpmext.ui.substituteConfigOption(this, "displayCustomState", false);
				}
				if (!opts.displayCheckoutState){
					opts.displayCheckoutState = bpmext.ui.substituteConfigOption(this, "displayCheckoutState", false);
				}
				if (!opts.extraProperties) {
					opts.extraProperties = bpmext.ui.substituteConfigOption(this, "extraProperties", null);
				}
				if (!opts.displayProgressIndicator) {
					opts.displayProgressIndicator = bpmext.ui.substituteConfigOption(this, "displayProgressIndicator", false);
				}
				if (!opts.hideAddDialog) {
					opts.hideAddDialog = bpmext.ui.substituteConfigOption(this, "hideAddDialog", false);
				}
				if (!opts.enableStatusPolling) {
					opts.enableStatusPolling = bpmext.ui.substituteConfigOption(this, "enableStatusPolling", false);
				}				
				if (!opts.statusPollingInterval) {
					opts.statusPollingInterval = bpmext.ui.substituteConfigOption(this, "statusPollingInterval", 0);
				}
				if (!opts.statusPollingTimeout) {
					opts.statusPollingTimeout = bpmext.ui.substituteConfigOption(this, "statusPollingTimeout", 0);
				}
				if (!opts.pollingStatusProperty) {
					opts.pollingStatusProperty = bpmext.ui.substituteConfigOption(this, "pollingStatusProperty", null);
				}
				if (!opts.pollingExitValues) {
					opts.pollingExitValues = bpmext.ui.substituteConfigOption(this, "pollingExitValues", null);
				}
				if (!opts.pollingNegativeExitValues) {
					opts.pollingNegativeExitValues = bpmext.ui.substituteConfigOption(this, "pollingNegativeExitValues", null);
				}
				if (!opts.jsonConfigProperty) {
					opts.jsonConfigProperty = bpmext.ui.substituteConfigOption(this, "jsonConfigProperty", null);
				}
				if (!opts.jsonConfigValues) {
					opts.jsonConfigValues = bpmext.ui.substituteConfigOption(this, "jsonConfigValues", null);
				}
				if (!opts.controllerDocumentProperty) {
					opts.controllerDocumentProperty = bpmext.ui.substituteConfigOption(this, "controllerDocumentProperty", null);
				}		
				// End of Advanced settings 
				
				domClass.add(this.context.element, "CS_ContentList");
				
				if (mdt.labelVisibility.get('value') != 'SHOW') {
					domClass.add(this.context.element, "HideHeader");
				}

  				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONADD, "contentItem");
				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONRESULT, "results");
				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONFILECLICKED, "document");
				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONFOLDERCLICKED, "folder");
				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONROWSEL, "row");
				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONERROR, "message");
				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONCONTEXTMENUOPEN, "menuItems", "contentItem");
				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONACTIONMENUOPEN, "menuItems", "folder");
				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONPOLLRESULTS, "results");

				this._proto._setHeight(this, opts.height.get("value"));
				this._proto._setWidth(this, opts.width.get("value"));

				bpmext.ui.loadView(this);

				// Get the Control-Table instance
				this._instance.contentTable = this.ui.get("ContentTable");
				this._instance.breadcrumb = this.ui.get("Breadcrumbs");
				this._instance.addActionPopup = this.ui.get("AddPopupMenu");
				
				// Todo: Following line is a hack to fix a new issue in the setPageSize function of the content table from UI toolkit
				this._instance.contentTable._instance._pageSizer = {};
				var pageSize = this._proto._getPageSize(this);
				this._instance.contentTable.setPageSize(pageSize);
				
//				this._instance.contentTable.setHeight(opts.height.get("value"));
				var height = opts.height.get("value");
				this._instance.contentTable.context.options.height.set("value", height);
				if (height == null) {
					domClass.add(this._instance.contentTable.context.element, "CS_DefaultHeight");
				}
				
				this._instance.contentTable.setWidth(opts.width.get("value"));
		
				this._instance.documentsSvc = this.ui.get("DocumentsSvc");           // Get documents service
				this._instance.moreDocumentsSvc = this.ui.get("MoreDocumentsSvc");   // Get more documents service
				this._instance.folderContSvc = this.ui.get("FolderContSvc");         // Get folder containees service
				this._instance.moreFolderContSvc = this.ui.get("MoreFolderContSvc"); // Get more folder containees service
				this._instance.searchSvc = this.ui.get("SearchSvc");                 // Get search results service
				this._instance.moreSearchSvc = this.ui.get("MoreSearchSvc");         // Get more search results service
				this._instance.textSearchSvc = this.ui.get("TextSearchSvc");         // Get text search results service
				this._instance.moreTextSearchSvc = this.ui.get("MoreTextSearchSvc"); // Get more text search results service
				this._instance.batchDocumentsSvc = this.ui.get("BatchDocumentsSvc");        // Get batch documents service
				this._instance.moreBatchDocumentsSvc = this.ui.get("MoreBatchDocumentsSvc");// Get more batch documents service

				// Need to set the selection mode on the Data Table component itself
				var selectionMode = this.context.options.selectionMode.get("value");
				this._instance.contentTable.context.options.selectionMode.set("value", selectionMode);
				var displayCusState = this.context.options.displayCustomState.get("value");   
				if (selectionMode == "N") {
					if (displayCusState) {
						domClass.add(this._instance.contentTable.context.element, "CS_TableNoneExtra");
					} else {
						domClass.add(this._instance.contentTable.context.element, "CS_TableNone");
					}
				} else {
					if (displayCusState) {
						domClass.add(this._instance.contentTable.context.element, "CS_TableSelectExtra");
					} else {
						domClass.add(this._instance.contentTable.context.element, "CS_TableSelect");
					}
				}

				var self = this;
				var refreshIconBtn = this.ui.get("RefreshImage");
				domAttr.set(refreshIconBtn.context.element, "title", messages.contlist_refresh_btn_label);
				refreshIconBtn.context.element.addEventListener('click', function(evt) {
					evt.preventDefault();
					self._instance.lastPageIndex = self._instance.contentTable.getPageIndex();
					self._proto._refresh(self);	
				});
				refreshIconBtn.context.element.addEventListener('keyup', function(evt) {
					if (evt.keyCode == 13) {
						evt.preventDefault();
						self._instance.lastPageIndex = self._instance.contentTable.getPageIndex();
						self._proto._refresh(self);	
					}
				});
				var refreshImage = refreshIconBtn.context.element.querySelector("img");
				domAttr.set(refreshImage, "title", messages.contlist_refresh_btn_label);
				domAttr.set(refreshImage, "tabindex", "-1");
	
				var hideToolbar = true;
				var enableSearchFilter;
				if  (this._instance.contentItems != null || this._instance.folderId != null) {
					enableSearchFilter = false; // Filer dosn't work when loaded with folder containees
				} else {
					enableSearchFilter = this.context.options.enableSearchFilter.get("value");
				}				

				if (enableSearchFilter) {
					var filterIconBtn = this.ui.get("FilterImage");
					var searchConfigOptions = this.context.options.searchProperties.get("value");
					searchConfigOptions = searchConfigOptions.items ? searchConfigOptions.items : searchConfigOptions;
					if (searchConfigOptions && searchConfigOptions.length == 0) {
						domStyle.set(filterIconBtn.context.element, "display", "none");
					} else {
						// Hide the search filter that is normally at the top of the list
						this._proto._showHideContentListFilter(this, false);
						// Check for any new localized display name strings in the resource bundle
						var nlResources = this.context.options.nlResources.get("value");
						if (nlResources) {
							for (var i = 0; i < searchConfigOptions.length; i++) {		
								var configOption = searchConfigOptions[i];
								var displayName = nlResources[configOption.name];
								if (displayName) {
									configOption.displayName = displayName;
								}
							}
						}

						domAttr.set(filterIconBtn.context.element, "title", messages.contlist_filter_btn_label);
						filterIconBtn.context.element.addEventListener('click', function(evt) {
							evt.preventDefault();
							self._proto._showHideFilter(self);
						});
						filterIconBtn.context.element.addEventListener('keyup', function(evt) {
							if (evt.keyCode == 13) {
								evt.preventDefault();
								self._proto._showHideFilter(self);
							}
						});
						var filterImage = filterIconBtn.context.element.querySelector("img");
						domAttr.set(filterImage, "title", messages.contlist_filter_btn_label);
						domAttr.set(filterImage, "tabindex", "-1");
						hideToolbar = false;
					}
				} else {
					var filterIconBtn = this.ui.get("FilterImage");
					domStyle.set(filterIconBtn.context.element, "display", "none");
				}
				
				var previousButton = this.ui.get("PreviousIcon");
				domAttr.set(previousButton.context.element, "title", messages.contlist_previous_btn_label);
				var nextButton = this.ui.get("NextIcon");
				domAttr.set(nextButton.context.element, "title", messages.contlist_next_btn_label);

				if (opts.hideRefresh.get("value") && opts.hideRefresh.get("value")) {
					var refreshButton = this.ui.get("RefreshImage");
					domStyle.set(refreshButton.context.element, "display", "none");
				} else {
					hideToolbar = false;
				}
				// If user is not allowed to add documents or folders, hide the actions toolbar button
				if (opts.hideAddDocument.get("value") && opts.hideAddFolder.get("value")) {
					var addButton = this.ui.get("AddButton");
					domStyle.set(addButton.context.element, "display", "none");
				} else {
					var addButton = this.ui.get("AddButton");
					var addButtonElement = addButton.context.element;
					var buttonNode = addButtonElement.children[0];
					var spanNode = buttonNode.children[0];
					domClass.add(spanNode, "CS_AddButtonDown");
					hideToolbar = false;
				}

				var hideSearchField = opts.hideSearchField.get("value");
				if (!hideSearchField) {
					hideToolbar = false;
				}
				
				if (hideToolbar) {
					// Need to set the toolbar to display none
					var toolbarLayout = this.ui.get("ContentListToolbarLayout");
					domStyle.set(toolbarLayout.context.element, "display", "none");
				}
				
				// Setup order of precedence, 1) content, 2) folder, 3) search
				if  (this._instance.contentItems != null) {
					// Don't display breadcrumb and enable the filter controls
					domStyle.set(this._instance.breadcrumb.context.element.parentNode, "display", "none");
					this._proto._showHideContentListFilter(this, true);
					this._instance.contentListFilterText.context.options.placeHolder.set("value", messages.contlist_filter_folder_hint);
				} else if (this._instance.folderId != null) {
					// Always display breadcrumb and filter bar (open) in folder navigation mode
					this._instance.breadcrumb.setVisible(true);
					this._proto._showHideContentListFilter(this, true);
					this._instance.contentListFilterText.context.options.placeHolder.set("value", messages.contlist_filter_folder_hint);
				} else {
					var searchFor = opts.searchFor.get("value");
					if (searchFor != this._proto.typeFolder) {
						domStyle.set(this._instance.breadcrumb.context.element.parentNode, "display", "none");
					}
					this._instance.contentListFilterText = this.ui.get("ContentListFilterText");
					if (!hideSearchField) {
						// In simple search mode, need to open search bar by default
						this._proto._showHideContentListFilter(this, true);
						this._instance.contentListFilterText.context.options.placeHolder.set("value", messages.contlist_filter_search_hint);
					} else {
						this._proto._showHideContentListFilter(this, false);
					}
					// Initialize the search value, it will change as the user starts typing
					this._instance.searchValue = opts.searchValue.get("value");
					if (this._instance.searchValue != null && this._instance.searchValue != "") {
						this._instance.contentListFilterText.setText(this._instance.searchValue);
					}
					this._instance.searchPropertyType = opts.searchPropertyType.get("value");
					this._instance.searchPropertyCardinality = opts.searchPropertyCardinality.get("value");
				}
	
				// This is an element injected by system UI toolkit and needs to be styled, to get right height in breadcrumb area
				var breadcrumbParent = this._instance.breadcrumb.context.element.parentNode;
				if (breadcrumbParent != null) {
					domClass.add(breadcrumbParent, "BreadcrumbContentBox");
				}
			
				// Used to fix rendering problems in these browsers (hack)
				this._instance.isFirefox = window.navigator.userAgent.indexOf("Firefox");
				this._instance.isEdge = window.navigator.userAgent.indexOf("Edge");
				this._instance.isChrome = window.navigator.userAgent.indexOf("Chrome");
				this._instance.isSafari = window.navigator.userAgent.indexOf("Safari");

				if (opts.rowHeight.get("value") == "small" ) {
					domClass.add(this._instance.contentTable.context.element, "CS_RowShort");
				} else {
					domClass.add(this._instance.contentTable.context.element, "CS_RowMedium");
				}
				
				this._instance.folderActionPanel = this.ui.get("RenameFolderPanel");
				this._instance.folderActionPanel.setTitle(messages.contlist_menu_action_rename_folder);
				this._instance.newFolderNameTxt = this.ui.get("RenameFolderText");
				this._instance.newFolderNameTxt.setLabel(messages.contlist_folder_name);
				this._instance.renameCancelBtn = this.ui.get("CancelRenameButton");
				this._instance.renameCancelBtn.setText(messages.contlist_cancel_btn_label);				
				this._instance.renameFolderBtn = this.ui.get("RenameFolderButton");
				this._instance.renameFolderBtn.setText(messages.contlist_ok_btn_label);
				
				this._instance.deleteCancelBtn = this.ui.get("CancelDeleteObjectButton");
				this._instance.deleteCancelBtn.setText(messages.contlist_cancel_btn_label);	
				this._instance.deleteOkBtn = this.ui.get("OkDeleteObjectButton");
				this._instance.deleteOkBtn.setText(messages.contlist_ok_btn_label);
				
				this._instance.savePropertiesBtn = this.ui.get("PropertiesSaveButton");
				this._instance.savePropertiesBtn.setText(messages.contlist_save_btn_label);
				this._instance.cancelPropertiesBtn = this.ui.get("PropertiesCancelButton");
				this._instance.cancelPropertiesBtn.setText(messages.contlist_cancel_btn_label);
				
				this._instance.addFolderBtn = this.ui.get("AddFolderButton");
				this._instance.addFolderBtn.setText(messages.contlist_add_btn_label);
				this._instance.cancelAddFolderBtn = this.ui.get("AddFolderCancelButton");
				this._instance.cancelAddFolderBtn.setText(messages.contlist_cancel_btn_label);
				
				this._instance.addDocumentBtn = this.ui.get("AddDocumentButton");
				this._instance.addDocumentBtn.setText(messages.contlist_add_btn_label);
				this._instance.cancelAddDocBtn = this.ui.get("AddDocCancelButton");
				this._instance.cancelAddDocBtn.setText(messages.contlist_cancel_btn_label);
				
				this._instance.uploadVersionPanel = this.ui.get("UploadVersionPanel");
				this._instance.uploadVersionPanel.setTitle(messages.contlist_menu_action_upload);
				this._instance.uploadVersionBtn = this.ui.get("UploadVersionButton");
				this._instance.uploadVersionBtn.setText(messages.contlist_upload_btn_label);
				this._instance.cancelUploadBtn = this.ui.get("CancelUploadButton");
				this._instance.cancelUploadBtn.setText(messages.contlist_cancel_btn_label);
				
				this._instance.progressIndicator = this.ui.get("ProgressIndicator");
				this._instance.uploadContent = this.ui.get("UploadContent");
				this._instance.uploadContent.setObjectStoreName(this._proto._getObjectStoreName(this));
				this._instance.getContent = this.ui.get("GetContent");
				this._instance.getContent.setObjectStoreName(this._proto._getObjectStoreName(this));
				
				this._instance.addBatchBtn = this.ui.get("AddBatchButton");
				this._instance.addBatchBtn.setText(messages.contlist_batch_select_files);
				this._instance.addBatchCancelBtn = this.ui.get("AddBatchCancelButton");
				this._instance.addBatchCancelBtn.setText(messages.contlist_cancel_btn_label);
				
				var _this = this;
				var addDocPropsTable = this.ui.get("AddDocPropsTable");
				this._instance.propertyPoller = this.ui.get("PropertyPoller");
				this._instance.pollingEnabled = opts.enableStatusPolling.get("value");
				if (this._instance.pollingEnabled) {
					this._instance.propertyPoller.setObjectStoreName(this._proto._getObjectStoreName(this));
					this._instance.pollingStatusPropertyId = opts.pollingStatusProperty.get("value");
					this._instance.propertyPoller.setStatusPropertyId(this._instance.pollingStatusPropertyId);
					this._instance.propertyPoller.setExtraProperties(opts.extraProperties.get("value"));
					this._instance.propertyPoller.setPollingInterval(opts.statusPollingInterval.get("value"));
					this._instance.propertyPoller.setPollingTimeout(opts.statusPollingTimeout.get("value"));
					
					var pollingExitValues = opts.pollingExitValues.get("value");
					this._instance.pollingExitValues = pollingExitValues ? pollingExitValues.items ? pollingExitValues.items : pollingExitValues : null;
					this._instance.propertyPoller.setExitValues(this._instance.pollingExitValues);		
					
					var pollingNegativeExitValues = opts.pollingNegativeExitValues.get("value");
					this._instance.pollingNegativeExitValues = pollingNegativeExitValues ? pollingNegativeExitValues.items ? pollingNegativeExitValues.items : pollingNegativeExitValues : null;
					this._instance.propertyPoller.setNegativeExitValues(this._instance.pollingNegativeExitValues);
					
					this._instance.progressIndicator.addActionLinkFunction("Timeout", function() {
						_this._instance.propertyPoller.getDocumentStatus(this.name);
						return false;
					});
					this._instance.uploadContent.setPropertyPoller(this._instance.propertyPoller);
					addDocPropsTable.setPropertyPoller(this._instance.propertyPoller);
				}
				if (opts.jsonConfigProperty.get("value") && opts.jsonConfigValues.get("value")) {
					var configValues = opts.jsonConfigValues.get("value");
					var nameValues = configValues.items ? configValues.items : configValues;
					var jsonConfigValues = {};
					nameValues.forEach(function(nameValue) {
						jsonConfigValues[nameValue.Name] = nameValue.Value
					});
					this.addAdditionalPropertyOnAdd(opts.jsonConfigProperty.get("value"), JSON.stringify(jsonConfigValues));
				}
				
				if (opts.displayProgressIndicator.get("value")){
					this._instance.uploadContent.setProgressIndicator(this._instance.progressIndicator);
					addDocPropsTable.setProgressIndicator(this._instance.progressIndicator);
				}
				
				if (opts.controllerDocumentProperty.get("value")){
					var controllerDocumentProperty = opts.controllerDocumentProperty.get("value");
					this._instance.uploadContent.setControllerDocumentProperty(controllerDocumentProperty);
					addDocPropsTable.setControllerDocumentProperty(controllerDocumentProperty);
					var editPropsTable = this.ui.get("PropertiesTable");
					editPropsTable.setControllerDocumentProperty(controllerDocumentProperty);
					this._instance.propertyPoller.setControllerPropertyId(controllerDocumentProperty);
				}
				
				// Get the column information and set it into the Control-Table
				this._proto._loadColumns(this, null);
				
				if (this._instance.serverConfigurationName && this._instance.serverConfigurationName != null) {
					var self = this;
					// Setting a time out interval here to allow other components on the same page as the content list
					// to load themseleves and potentially call a public api on the content list before refresh is called.
					setTimeout(function() {
						self._proto._refresh(self, null, null);
					}, 450);
				} else {
         			bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONERROR, messages.contlist_missing_server_error);
        		}
				
				if (!opts.disableDragDropAdd.get("value") && !(this._instance.contentItems && this._instance.contentItems.length() > 0)) {
					// Don't allow dropping on the breadcrumb
					var breadcrumb = this. context.element.querySelector(".BreadcrumbContainer");
					breadcrumb.addEventListener('dragover', function(evt) {
						evt.preventDefault();
						evt.stopPropagation();
						evt.dataTransfer.dropEffect = "none";
					}, false);
					breadcrumb.addEventListener('drop', function(evt) {
						evt.stopPropagation();
						evt.preventDefault();
						return false;
					}, false);
									
					this.context.element.addEventListener('dragover', function(evt) {
						evt.preventDefault();
						evt.stopPropagation();
						_this._proto._onExternalDragOver(evt, _this);
					}, false);

					this.context.element.addEventListener('drop', function(evt) {
						evt.preventDefault();
						evt.stopPropagation();
						_this._proto._onExternalDrop(evt, _this);
					}, false);
					this.context.element.addEventListener('dragleave', function(evt) {
						evt.preventDefault();
						evt.stopPropagation();
						_this._proto._onExternalDragLeave(evt, _this);
					}, false);
				}
				
				// If No UI document adds are configured and there is a single document class, check that the user has access to add documents of that type.
				// Default access to true incase the getAccessClass call fails or is slow to return (it's async). The CPE will enforce the add like before.
				this._instance.addDocumentClassAccess = true;
				if (opts.hideAddDialog.get("value") && opts.documentClasses.get("value") && opts.documentClasses.get("value").length() == 1){
					var docClasses = this.context.options.documentClasses.get("value");
					var documentClasses = docClasses.items ? docClasses.items : docClasses;
					var selectedClass = documentClasses && documentClasses[0].value;					
					this._instance.getContent.getClassAccess("ClassDefinition", selectedClass, null, function(accessAllowed) {
						_this._instance.addDocumentClassAccess = (accessAllowed & _this._proto.privilegeToBitmask["privAddItem"]) > 0;
					});
				}
			} catch (e) {
				bpmext.log.error("Error on load event [" + this.context.viewid + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};

		this.constructor.prototype.view = function () {
			console.log("CS-ContentList:view() : called from: " + this.context.viewid);
            try {
				this._proto._handleVisibility(this);
 			} catch (e) {
                bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                if (e.stack) {
                    bpmext.log.error("  Call stack: " + e.stack);
				}
            }
        };

		this.constructor.prototype.change = function(event)	{
			console.log("CS-ContentList:change() : called from: " + this.context.viewid);
			try	{
				var view = this;
				if (event.type == "config")	{
					switch (event.property)	{
						case "selectionMode": {
							this.ui.get("ContentTable").context.options.selectionMode.set("value", event.newVal);
							break;
						}
             			case "height": {
							this._proto._setHeight(this, event.newVal);
							break;
						}
            			case "width": {
							this._proto._setWidth(this, event.newVal);
							break;
						}
						case "columns": {
							var newColumns = event.newVal;	
							if (newColumns && newColumns.items && newColumns.items.length > 0) {
								// Get the rest of the column information and set it into the Control-Table
								this._proto._loadColumns(this, newColumns);
								// Now just re-render the existing result set with the new column properties
								this._proto._processResultRows(this, this._instance.lastResults);
							}
							break;
						}
						case "rowHeight": {
							var newRowHeight = event.newVal;
							// Set the row height and re-render the existing result set with the new column properties
							if (newRowHeight == "small") {
								domClass.add(this._instance.contentTable.context.element, "CS_RowShort");
							} else {
								domClass.remove(this._instance.contentTable.context.element, "CS_RowShort");
							}
							this._instance.contentTable.refresh(false);
							break;
						}
					}
				} else {
					if (this.context.binding && event.newVal && event.newVal.id) {
						var boundObject = this.context.binding.boundObject;
						if (boundObject != null) {
							var contentItem = event.newVal;
							if (contentItem.propertyUpdate) {
								if (contentItem.pageNumber == this._instance.pageNumber) {
									console.log("CS-ContentList:change() : Change update for bound object (old name): " + contentItem.name);
									var actionName = this._proto.actions.documentProperties;
									if (this._proto._getType(contentItem) == this._proto.typeFolder) {
										actionName = this._proto.actions.folderProperties;
									} else if (this._proto._getType(contentItem) == this._proto.typeAbstract) {
										actionName = this._proto.actions.abstractProperties;
									}
									this._proto._refreshTableRow(view, actionName, contentItem.rowIndex, contentItem.properties, contentItem.id, null);
								}
							} else if (contentItem.update != null) {
								console.log("CS-ContentList:change() : Change update for bound object: " + contentItem.name + ", update type: " + contentItem.update);
								if (contentItem.update == "batch") {
									// Need to get the individual batch object properties and update a row in the list view
									this._proto._updateBatch(this, contentItem);
								} else if (contentItem.update == "batchDocument") {
									// Need to get the batch document objects properties and update a row in the list view
									this._proto._updateBatchDocument(this, contentItem);
								} else if (contentItem.update == "document") {
									// Need to get the document properties and update a row in the list view
									this._proto._updateDocument(this, contentItem, contentItem.update);
									if (this._instance.pollingEnabled){
										if (this._instance.progressIndicator.isItemDisplayed(contentItem.id)){
											this._instance.propertyPoller.getDocumentStatus(contentItem.id);
										}
										this._instance.propertyPoller.addDocumentId(contentItem.id);
									}
								} else if (contentItem.update == "batches") {
									// Need to just refresh the whole batch list
									this._proto._refresh(this);
								} else if (contentItem.update == "batchDocuments") {
									// Need to just refresh the whole batch documents list
									this._instance.currentBatch = contentItem;
									this._proto._getBatchDocuments(this, contentItem);
								} else {
									console.log("CS-ContentList:change() : Update change event not recognized: " + contentItem.update);
								}
								delete contentItem.update;
							}
														
							if (this._instance.pollingEnabled && this.context.options.displayProgressIndicator.get("value")) {									
								if (this._instance.propertyPoller.isPaused() && this._proto._isPollingForItemInList(this)) {
									this._instance.propertyPoller.resumePolling();
								}
								if (this._instance.progressIndicator.isItemDisplayed(contentItem.id) &&	!this._instance.progressIndicator.isItemActive(contentItem.id)){
									// Poll for the item to update the progress indicator if necessary.
									// Its status may have been changed on the verify page.
									this._instance.propertyPoller.addDocumentId(contentItem.id);
								}
							}
						}
					}
				}
			} catch (e) {
				bpmext.log.error("Error on change event [" + this.ui.getAbsoluteName() + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};
		
		/**
		 * @instance
		 * @memberof CSContentList
		 * @method setRecordSelected
		 * @desc Selects or deselects a record from the document list.
		 * @param {Object} record The record to select.
		 * @param {boolean} selected The selection value (where 'true' is selected and 'false' is deselected).
		 */
		this.constructor.prototype.setRecordSelected = function(record, selected) {
			this._instance.contentTable.setRecordSelected(record, selected);
		};

		/**
		 * @instance
		 * @memberof CSContentList
		 * @method getSelectedRecord
		 * @desc Returns the selected record from the document list.
		 * @returns {Object}
		 */
		this.constructor.prototype.getSelectedRecord = function() {
			return this._instance.contentTable.getSelectedRecord();
		};

		/**
         * @instance
         * @memberof CSContentList
         * @method setAllRecordsSelected
         * @param {boolean} selected Flag to indicate whether to select or unselect the records
         * @param {boolean} asInTable (Only used with index) If true, sets the selected status of the records that are not filtered out, if false or omitted sets the selected status of all records regardless of filtering
         * @desc Selects or unselects records
         */
        this.constructor.prototype.setAllSelected = function(selected, asInTable, selMode) {
			return;
		};

		/**
		 * @instance
		 * @memberof CSContentList
		 * @method clearAllSelection
		 * @desc Deselects the selected records in the document list.
		 */
		this.constructor.prototype.clearAllSelection = function() {
			var selectedRecords = this._instance.contentTable.getSelectedRecords();
			if (selectedRecords) {
				if (selectedRecords.length == 1) {
					this._instance.contentTable.setRecordSelected(selectedRecords[0], false);
				} else if (selectedRecords.length > 1) {
					this._instance.contentTable.setAllRecordsSelected(false);
				}
			}
		};
		
	}
}
