/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2020 - 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

cs_InitBatchContent = function(bpmext, domClass, domStyle, domAttr, messages, string, cookie) {
	
	this._instance = {
		serverConfigurationName: "GRAPHQL_APP_RESOURCE",
		objectStoreName: null,
		batchData: [],
		checkoutDocumentSvc: null,
		batchUpdatedCallback: null,
		checkoutDocument: {},
		getProperties: {},
		updateProperties: {},
		updateBatches: {},
		saveBatches: {},
		lockBatches: {},
		rollbackBatches: {},
		updateErrback: null,
		saveErrback: null
	};

	if (!this.constructor.prototype._proto)
	{
		this.constructor.prototype._proto =
		{
			EVT_ONERROR: "eventON_ERROR",
			EVT_ONGETPROPERTIES: "eventON_GETPROPERTIES",
			EVT_ONUPDATEPROPERTIES: "eventON_UPDATEPROPERTIES",
			EVT_ONDOCUMENTCHECKEDOUT: "eventON_DOCUMENTCHECKEDOUT",
			EVT_ONUPDATEBATCH: "eventON_UPDATEBATCH",
			EVT_ONSAVEBATCH: "eventON_SAVEBATCH",
			EVT_ONROLLBACKBATCH: "eventON_ROLLBACKBATCH",
			EVT_ONSEARCHRESULTS: "eventON_SEARCHRESULTS",
			
			/**
			 * @private
			 */
			_getId: function() {
				var id = ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, c => (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16));
				console.log("CS-BatchContent: _getId : Id = " + id);
				return "{" + id.toUpperCase() + "}";
			},

			_getUserId: function(view) {
				var userId = view._instance.userId;
				if (userId == null) {
					// Todo: Currently, no way of getting logged in user information from UMS, temporary work around
					var navUrl = window.location.href;
					var params = navUrl.split("&");
					for (var i = 0; i < params.length; i++) {
						var param = params[i].split("=");
						if (param[0] == "userId") {
							userId = decodeURIComponent(param[1]);
							view._instance.userId = userId;
							break;
						}
					}
				}
				return userId;
			},
						
			/**
			 * @private
			 */
			_isCurrentUserCheckout: function(view, reservation) {
				var isCurrentUser = false;
				// Need to check to see if current logged in user is the one who has the document checked out
				if (reservation.creator) {
					var reservationUser = reservation.creator;
					// NOTE: The following call only works if running in ICN in platform mode
					var currentUser = this._getUserId(view);
					if (currentUser != null && reservationUser == currentUser) {
						isCurrentUser = true;
					}
				}
				return isCurrentUser;
			},
			
			/**
			 * @private
			 */
			_getUserId: function(view) {
				var userId = view._instance.userId;
				if (userId == null) {
					// Todo: Currently, no way of getting logged in user information from UMS, temporary work around
					var navUrl = window.location.href;
					var params = navUrl.split("&");
					for (var i = 0; i < params.length; i++) {
						var param = params[i].split("=");
						if (param[0] == "userId") {
							userId = decodeURIComponent(param[1]);
							view._instance.userId = userId;
							break;
						}
					}
				}
				return userId;
			},
			
			/**
			 * @private
			 */
			_convertJSONPropsToGraphql: function(jsonProperties){
				// Convert the JSON array of property name/value pairs into a string for graphql consumption.
				var graphqlProperties = "[";
				for (var i = 0; i < jsonProperties.length; i++){
					if (graphqlProperties.length > 1){
						graphqlProperties = graphqlProperties.concat(", ");
					}
					var jsonProperty = jsonProperties[i];
					var propertyName = Object.keys(jsonProperty)[0];
					var propertyValue = jsonProperty[propertyName];
					var graphqlPropertyValue;
					if (typeof propertyValue === 'string' || propertyValue instanceof String){
						graphqlPropertyValue = "\"" + propertyValue.replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/\t/g,'\\t').replace(/"/g,'\\"') + "\"";
					} else if (Array.isArray(propertyValue)) {
						graphqlPropertyValue = "[";
						for (var j = 0; j < propertyValue.length; j++) {
							if (graphqlPropertyValue.length > 1) {
								graphqlPropertyValue = graphqlPropertyValue.concat(",");
							}
							var multiPropertyValue = propertyValue[j];
							var multiGraphqlPropertyValue;
							if (typeof multiPropertyValue === 'string' || multiPropertyValue instanceof String) {
								multiGraphqlPropertyValue = "\"" + multiPropertyValue.replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/\t/g,'\\t').replace(/"/g,'\\"') + "\"";
							} else {
								multiGraphqlPropertyValue = multiPropertyValue;
							}
							graphqlPropertyValue  = graphqlPropertyValue.concat(multiGraphqlPropertyValue);
						}
						graphqlPropertyValue = graphqlPropertyValue.concat("]");
					} else {
						graphqlPropertyValue = propertyValue;
					}
					graphqlProperties = graphqlProperties.concat("{", propertyName, ": ", graphqlPropertyValue, "}");
				}
				graphqlProperties = graphqlProperties.concat("]");
				return graphqlProperties;
			},
	
			_callService: function(service, params) {
				// Create ecm token as a large random number
				var ecmToken = Math.floor(Math.random() * 10000000);
				console.log("CS-BatchContent:_callService() : Ecm token: " + ecmToken);

				// Add the required token value to the service params
				params.ecmToken = ecmToken;
				service.execute(params);
			},
	
			_onCheckoutDocument: function(view, contentItem, callback, errback) {
				view._instance.checkoutDocument[contentItem.id] = {
					callback: callback,
					errback: errback
				};
				view._instance.checkoutErrback = errback; // general error callback handling
				
				// This action is ran without any UX
				var params = {
					documentId: contentItem.id,
					repository: view._instance.objectStoreName,
					serverAppResource: view._instance.serverConfigurationName
				};
				
				view._instance.checkoutDocumentSvc = view.ui.get("CheckoutDocumentSvc");
				this._callService(view._instance.checkoutDocumentSvc, params);
			},
			
			_onGetProperties: function(view, contentItem, properties, callback, errback) {
				view._instance.getProperties[contentItem.id] = {
					callback: callback,
					errback: errback
				};
				view._instance.propertiesErrback = errback; // general error callback handling

				var params = {
					objectId: contentItem.id,
					objectType: contentItem.baseType,
					classId: contentItem.className,
					properties: properties,
					update: "properties",
					repository: view._instance.objectStoreName,
					serverAppResource: view._instance.serverConfigurationName
				};
				
				view._instance.getPropertiesSvc = view.ui.get("GetPropertiesSvc");
				this._callService(view._instance.getPropertiesSvc, params);
			},
						
			_onUpdateProperties: function(view, contentItem, callback, errback) {
				view._instance.updateProperties[contentItem.id] = {
					callback: callback,
					errback: errback
				};
				view._instance.propertiesErrback = errback; // general error callback handling
			
				// Need to convert the properties into a format that can be sent to update properties action service
				var properties = contentItem.properties.items ? contentItem.properties.items : contentItem.properties;
				if (properties) {
					var propertyValues = "[";
					for (var i = 0; i < properties.length; i++) {
						var property = properties[i];
						if (property.cardinality == "SINGLE") {
							if (property.dataType == "STRING" || property.dataType == "GUID") {
								var sanitizedValue = property.value;
								if (property.value != null) {
									sanitizedValue = property.value.replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/\t/g,'\\t').replace(/"/g,'\\"');
								}
								propertyValues += "{" + property.id + " : \"" + sanitizedValue + "\"}";
							} else if (property.dataType == "DATE") {
								if (property.value != null && property.value != "") {
									var dateValue = new Date(property.value);
									propertyValues += "{" + property.id + " : \"" + dateValue.toISOString() + "\"}";
								} else {
									propertyValues += "{" + property.id + " : " + null + "}";
								}
							} else {
								propertyValues += "{" + property.id + " : " + property.value + "}";
							}
						} else if (property.cardinality == "LIST") {
							propertyValues += "{" + property.id + ": [";
							var values = property.value.items ? property.value.items : property.value;
							for (var j = 0; j < values.length; j++) {
								var value = values[j];
								if (property.dataType == "STRING" || property.dataType == "GUID") {
									var sanitizedValue = value;
									if (value != null) {
										sanitizedValue = value.replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/\t/g,'\\t').replace(/"/g,'\\"');
									}
									propertyValues += "\"" + sanitizedValue + "\"";
								} else if (property.dataType == "DATE") {
									var dateValue = new Date(value);
									propertyValues += "\"" + dateValue.toISOString() + "\"";
								} else {
									propertyValues += value;
								}
								
								if (j < values.length - 1) {
									propertyValues += ", ";
								}
							}
							propertyValues +="]}";
						}
						
						if (i < properties.length - 1) {
							propertyValues += ", ";
						}
					}
					propertyValues += "]";
					
					var params = {
						objectType: contentItem.baseType,
						objectId: contentItem.id,
						classId: contentItem.className,
						properties: propertyValues,
						repository: view._instance.objectStoreName,
						serverAppResource: view._instance.serverConfigurationName
					};
					
					// Need to make the call to update the properties on the specified content item
					view._instance.updatePropertiesSvc = view.ui.get("UpdatePropertiesSvc");
					this._callService(view._instance.updatePropertiesSvc, params);
				}
			},
			
			_getBatchLeaseTimeProperties: function(view, batchItem, action, hours, callback, errback) {
				view._instance.lockBatches[batchItem.id] = {
					action: action,
					hours: hours,
					callback: callback,
					errback: errback
				};

				var properties = [];
				properties.push("DbaLeaseTime");
				properties.push("LastModifier");
				
				var params = {
					objectType: "Abstract",
					classId: "DbaClassificationBatch",
					objectId: batchItem.id,
					properties: properties,
					update: "leaseTime",
					repository: view._instance.objectStoreName,
					serverAppResource: view._instance.serverConfigurationName
				};
				
				console.log("CS-BatchContent:_getProperties() : Get properties for: " + batchItem.id);
				view._instance.getPropertiesSvc = view.ui.get("GetPropertiesSvc");
				this._callService(view._instance.getPropertiesSvc, params);
			},
			
			_lockBatch: function(view, batchItem) {
				var lockBatches = view._instance.lockBatches[batchItem.id];
				if (lockBatches.action && lockBatches.action == "properties") {
					console.log("CS-BatchContent:_lockBatch() : Getting lock properties for: " + batchItem.id);
					var properties = batchItem.properties.items ? batchItem.properties.items : batchItem.properties;
					// Action is properties, just return the new properties
					if (lockBatches.callback) {
						lockBatches.callback(properties);
					}
				} else {	
					console.log("CS-BatchContent:_lockBatch() : Checking attempting to lock: " + batchItem.id);
					// Action is "lock" need to run through the lock process
					var properties = batchItem.properties.items ? batchItem.properties.items : batchItem.properties;
					var propLeaseTime = properties.find(property => property.id == "DbaLeaseTime");
					if (propLeaseTime) {
						if (propLeaseTime.value == null) {
							// Can lock
							this._onLockBatch(view, batchItem);
						} else {
							// Check the lease time to see if it's expired
							var leaseTime = new Date(propLeaseTime.value); 
							var rightNow = new Date();
							if (leaseTime.getTime() > rightNow.getTime()) {
								// Allready locked, check by who
								var propLastModifier = properties.find(property => property.id == "LastModifier");
								if (propLastModifier) {
									var lastModifier = propLastModifier.value;
									var currentUser = this._getUserId(view);
									if (currentUser == null) {
										console.log("CS-BatchContent:_lockBatch() : Can not get current logged in user in Preview mode, must run from ICN desktop!");
									}
									if (currentUser != null && lastModifier == currentUser) {
										// Current logged in user has the lock, can extend it
										this._onLockBatch(view, batchItem);
									} else {
										// Someone else has the lock, current user can not lock it
										if (lockBatches.errback) {
											var errorMessage = string.substitute(messages.batchcontent_locked_by_error, [lastModifier]);
											lockBatches.errback(errorMessage);
										}
									}
								} else {
									// It's locked but can't tell by whom
									if (lockBatches.errback) {
										lockBatches.errback(messages.batchcontent_locked_error);
									}
								}
							} else {
								// Lease time lock date has expired, override the lock
								this._onLockBatch(view, batchItem);
							}
						}
					}
				}
			},
			
			_onLockBatch: function(view, batchItem) {
				var lockBatches = view._instance.lockBatches[batchItem.id];
				var hours = lockBatches.hours;
				if (hours == null || hours <= 0) {
					hours = 8;
				}
				var leaseTime = new Date();
				leaseTime.setHours(leaseTime.getHours() + hours);
				
				var contentItem = {
					baseType: "Abstract",
					id: batchItem.id,
					className: batchItem.className,
					properties: [{
						id: "DbaLeaseTime",
						dataType: "DATE",
						cardinality: "SINGLE",
						value: leaseTime
					}]
				};
				this._onUpdateProperties(view, contentItem, lockBatches.callback, lockBatches.errback);
			},

			_onProcessChangeSet: function(view, batchItem, contentItems, callback, errback) {
/*
				contentItem: {
					id: "{real guid from CPE}, added later on isNew documents",
					name: "New Document - 1.pdf",
					classifyChangeSet: {
						isDeleted: true/false,
						isNew: true/false,
						isIssueDismissed: true/false,
						isContentChanged: true/false,
						documentType: <Selected document type>, can be null,
						isEmpty: true/false,
						errorCount: 1-9,
						oriDocumentType: <selected doc type>, 
						tempId: "NEW-DOCUMENT-<guid>",      
					}
				}	
*/
				
				view._instance.updateBatches[batchItem.id] = {
					contentItems: contentItems,
					callback: callback,
					errback: errback
				};
				view._instance.updateErrback = errback; // general error callback handling
				
				var properties = batchItem.properties.items ? batchItem.properties.items : batchItem.properties;
				var propBatchDocCount = properties.find(property => property.id == "DbaBatchDocumentCount");
				var batchDocumentCount = propBatchDocCount.value;
				var changeSets = [];	
				var batchOrderList = [];
				var projectId;
				var captureConfig;
				// Loop through content items to create list of current Batch order values
				for (var i = 0; i < contentItems.length; i++) {
					var contentItem = contentItems[i];
					if (contentItem.classifyChangeSet && contentItem.classifyChangeSet.isNew) {
						batchOrderList.push("-1");  // New docs will have an initial order of -1
					} else {
						properties = contentItem.properties.items ? contentItem.properties.items : contentItem.properties;
						var propBatchOrder = properties.find(property => property.id == "DbaBatchOrder");
						batchOrderList.push(propBatchOrder.value);
						if (projectId == null) {
							var propProjectId = properties.find(property => property.id == "DbaProjectId");
							if (propProjectId && propProjectId.value) {
								projectId = propProjectId.value;
							}
						}
						if (captureConfig == null) {
							var propCaptureConfig = properties.find(property => property.id == "DbaCaptureConfig");
							if (propCaptureConfig && propCaptureConfig.value) {
								captureConfig = propCaptureConfig.value.replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/\t/g,'\\t').replace(/"/g,'\\"');
							}
						}
					}
				}
		
				for (var i = 0; i < contentItems.length; i++) {
					var contentItem = contentItems[i];
					if (contentItem.classifyChangeSet) {
						var changeSet = contentItem.classifyChangeSet;
						if (changeSet.isDeleted) {
							// Skip these for now, in case the transaction falis (will delete later)
						} else if (changeSet.isNew) {
							console.log("CS-BatchContent:_onProcessChangeSet() : Adding new document: " + contentItem.name);
							
							// Increment the Batch document count +1
							batchDocumentCount++;
							
							// Create new document and controller (call _getId() to get new guid)
							var documentId = this._getId();
							var controllerId = this._getId();
							// Generate the new batch order string value
							if (i == 0) {
								// No predecessor, at the begining
								var predecessor = "000";
								var successor = batchOrderList[i + 1];
								batchOrderList[i] = this._getNewOrder(predecessor, successor);
							} else if (i == contentItems.length - 1) {
								// No successor, at the end
								var predecessor = batchOrderList[i - 1];
								batchOrderList[i] = predecessor + ".1";
							} else {
								// Have both predecessor and successor
								var predecessor = batchOrderList[i - 1];
								var successor = batchOrderList[i + 1];
								batchOrderList[i] = this._getNewOrder(predecessor, successor);
							}

							// Add the new document id to the content item for reference later
							contentItem.id = documentId;
							contentItem.reservation = {
								id: documentId,
								creator: this._getUserId(view)
							};
							// Add the new controller id and batch order to the content item as well
							var properties = [];
							properties.push({
								"id": "DbaClassificationController", 
								"type": "OBJECT", 
								"cardinality": "SINGLE", 
								"value": {
									"identifier": controllerId, 
									"repositoryIdentifier": view._instance.objectStoreName, 
									"classIdentifier": "DbaClassificationController"
								}
							});
							properties.push({
								"id": "DbaBatchOrder", 
								"type": "STRING", 
								"cardinality": "SINGLE", 
								"value": batchOrderList[i]
							});
							contentItem.properties = properties;
							// Add the content elements information with download Url so that viewer can handle it in classify client
							var contentElements = [];
							contentElements.push({
								"elementSequenceNumber": 0, 
								"retrievalName": contentItem.name, 
								"downloadUrl": "/content?repositoryIdentifier=" + view._instance.objectStoreName + "&documentId=" + documentId + "&elementSequenceNumber=0"
							});
							contentItem.contentElements = contentElements;
														
							var properties = "[{DocumentTitle: \"" + contentItem.name + "\"}]";

							var controllerProperties = [];
							this._addProperty(controllerProperties, "DbaDocId", "STRING", documentId);
							this._addProperty(controllerProperties, "DbaCaptureStatus", "INTEGER", 35);
							this._addProperty(controllerProperties, "DbaBatchOrder", "STRING", batchOrderList[i]);
							this._addProperty(controllerProperties, "DbaClassificationErrorCount", "INTEGER", 0);

							if (changeSet.documentType) {
								this._addProperty(controllerProperties, "DbaSuggestedDocumentType", "STRING", changeSet.documentType);
								this._addProperty(controllerProperties, "DbaSelectedDocumentType", "STRING", changeSet.documentType);
							}					
						
							// These two settings are the same on all documents
							this._addProperty(controllerProperties, "DbaProjectId", "STRING", projectId);
							if (captureConfig != null) {
								this._addProperty(controllerProperties, "DbaCaptureConfig", "STRING", captureConfig);
							}
								
							changeSets.push({
								action: "create",
								documentId: documentId,
								documentClassId: "DbaCaptureBase",
								documentProperties: [{
									symbolicName: "DocumentTitle",
									dataType: "STRING",
									value: contentItem.name
								}],
								controllerId: controllerId,
								controllerClassId: "DbaClassificationController",
								controllerProperties: controllerProperties
							});
						} else {
							var documentId;
							if (changeSet.isContentChanged) {
								console.log("CS-BatchContent:_onProcessChangeSet() : Checking out existing document: " + contentItem.name);
								var controllerProperties = [];
								
								var reservationId = this._getId();  // Need new document reservation id
								var controllerId = this._getId();   // Need new controller on new version
								// Temporarily add the new controller id to the contnet item, will be removed later
								contentItem.controller = {
									id: controllerId
								};
	
								var properties = contentItem.properties.items ? contentItem.properties.items : contentItem.properties;
								var propBatchOrder = properties.find(property => property.id == "DbaBatchOrder");

								this._addProperty(controllerProperties, "DbaDocId", "STRING", reservationId);
								this._addProperty(controllerProperties, "DbaCaptureStatus", "INTEGER", 35);
								this._addProperty(controllerProperties, "DbaBatchOrder", "STRING", propBatchOrder.value);
								var errorCount = changeSet.errorCount;
								if (errorCount == "") {
									errorCount = 0; // Need to set the error count to an integer and not empty string
								}
								this._addProperty(controllerProperties, "DbaClassificationErrorCount", "INTEGER", errorCount);

								if (changeSet.documentType) {
									// A new document type has been selected (property change), however this is not a new document
									console.log("CS-BatchContent:_onProcessChangeSet() : Updating document type on controller object for document: " + contentItem.name);
									this._addProperty(controllerProperties, "DbaSuggestedDocumentType", "STRING", changeSet.documentType);
									this._addProperty(controllerProperties, "DbaSelectedDocumentType", "STRING", changeSet.documentType);
								} else if (changeSet.oriDocumentType) {
									// Existing document that is being versioned and a new controller created, need to set the original document type
									console.log("CS-BatchContent:_onProcessChangeSet() : Setting original document type on controller for document: " + contentItem.name);
									this._addProperty(controllerProperties, "DbaSelectedDocumentType", "STRING", changeSet.oriDocumentType);
								}
							
								// These two settings are the same on all documents
								this._addProperty(controllerProperties, "DbaProjectId", "STRING", projectId);
								if (captureConfig != null) {
									this._addProperty(controllerProperties, "DbaCaptureConfig", "STRING", captureConfig);
								}
								
								// This is an existing document that the content has been modified, need to check it out
								documentId = contentItem.id;
								if (documentId) {
									// Checking out the document and creating the controller for the new reservation object here
									changeSets.push({
										action: "checkout",
										documentId: documentId,
										reservationId: reservationId,
										controllerId: controllerId,
										controllerClassId: "DbaClassificationController",
										controllerProperties: controllerProperties
									});
								}
							}
						}
					}
				}
				// Update the current batch item documents count property
				propBatchDocCount.value = batchDocumentCount;

				var params = {
					batchId: batchItem.id,
					batchClassId: batchItem.className,
					batchDocumentCount: batchDocumentCount,
					changeSets: changeSets,
					repository: view._instance.objectStoreName,
					serverAppResource: view._instance.serverConfigurationName
				};
				
				// Need to make the call to update the batch 
				view._instance.updateBatchSvc = view.ui.get("UpdateBatchSvc");
				this._callService(view._instance.updateBatchSvc, params);
			},

			_addProperty: function(properties, name, dataType, value) {
				properties.push({
					symbolicName: name,
					dataType: dataType,
					value: value
				});								
			},
			
			_getNewOrder: function(predecessor, successor) {
				var newOrder = predecessor + ".1";
				if (newOrder < successor) {
					// should be good, save it
				} else {
					// Have a conflict, try adding zeros
					var newOrder;
					var count = 0;
					while (true) {
						// Add an extra "0" and try again
						count++;
						var increment = ".";
						for (var j = 0; j < count; j++) {
							increment += "0";
						}
						increment += "1";
						
						newOrder = predecessor + increment;
						if (newOrder < successor) {
							// should be good, save it
							break;
						}
						
						if (count == 99) {
							console.log("CS-BatchContent:_getNewOrder() : Error getting the new order value.");
							newOrder = "";
							break;
						}
					}
				}
				return newOrder;
			},
			
			_onSaveChangeSet: function(view, batchItem, contentItems, callback, errback) {

				view._instance.saveBatches[batchItem.id] = {
					contentItems: contentItems,
					callback: callback,
					errback: errback
				};
				view._instance.saveErrback = errback; // general error callback handling

				var properties = batchItem.properties.items ? batchItem.properties.items : batchItem.properties;
				var propBatchDocCount = properties.find(property => property.id == "DbaBatchDocumentCount");
				var batchDocumentCount = propBatchDocCount.value;

				var projectId;
				var captureConfig;
				// Loop through content items to create list of current Batch order values
				for (var i = 0; i < contentItems.length; i++) {
					var contentItem = contentItems[i];
					if (contentItem.classifyChangeSet && contentItem.classifyChangeSet.isNew) {
						// New docs will have an initial order of -1
					} else {
						properties = contentItem.properties.items ? contentItem.properties.items : contentItem.properties;
						var propBatchOrder = properties.find(property => property.id == "DbaBatchOrder");
						if (projectId == null) {
							var propProjectId = properties.find(property => property.id == "DbaProjectId");
							if (propProjectId && propProjectId.value) {
								projectId = propProjectId.value;
							}
						}
						if (captureConfig == null) {
							var propCaptureConfig = properties.find(property => property.id == "DbaCaptureConfig");
							if (propCaptureConfig && propCaptureConfig.value) {
								captureConfig = propCaptureConfig.value.replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/\t/g,'\\t').replace(/"/g,'\\"');
							}
						}
					}
				}

				var changeSets = [];
				for (var i = 0; i < contentItems.length; i++) {
					var contentItem = contentItems[i];
					if (contentItem.classifyChangeSet) {
						var changeSet = contentItem.classifyChangeSet;
						if (changeSet.isNew) {
							if (contentItem.reservation && contentItem.reservation.id) {
								console.log("CS-BatchContent:_onSaveChangeSet() : Checking in new document: " + contentItem.name);
								// Get the new controller id, will have been created in the process change set function above
								var properties = contentItem.properties.items ? contentItem.properties.items : contentItem.properties;
								var propController = properties.find(property => property.id == "DbaClassificationController");
								controllerId = propController.value.identifier;

								changeSets.push({
									action: "checkin",
									documentId: contentItem.id,
									reservationId: contentItem.reservation.id,
									documentClassId: "DbaCaptureBase",
									documentProperties: [],
									controllerId: controllerId
								});
							} else {
								console.log("CS-BatchContent:_onSaveChangeSet() : Error new document has no reservation: " + contentItem.name);
							}
						} else if (changeSet.isDeleted) {
							console.log("CS-BatchContent:_onSaveChangeSet() : Deleting document: " + contentItem.name);
							batchDocumentCount--;
							changeSets.push({
								action: "delete",
								documentId: contentItem.id,
								versionSeriesId: contentItem.versionSeriesId,
								documentClassId: "DbaCaptureBase",
								documentProperties: []
							});
						} else {
							var documentId = null;
							var reservationId = null;
							var controllerId;
							var oldControllerId;
							var controllerProperties = [];
							var propertiesNeedUpdating = false;

							if (changeSet.isContentChanged) {
								console.log("CS-BatchContent:_onSaveChangeSet() : Updating document version: " + contentItem.name);
								// This is an existing document that the content has been modified, need to check it in
								documentId = contentItem.id;
								reservationId = contentItem.reservation.id;
								
								var properties = contentItem.properties.items ? contentItem.properties.items : contentItem.properties;
								var propController = properties.find(property => property.id == "DbaClassificationController");
								oldControllerId = propController.value.identifier;
								console.log("CS-BatchContent:_onSaveChangeSet() : Disconnecting old controller from batch : " + oldControllerId);
							} else {
								console.log("CS-BatchContent:_onSaveChangeSet() : Updating document properties only: " + contentItem.name);
								// Property updates on the controller
								var properties = contentItem.properties.items ? contentItem.properties.items : contentItem.properties;
								var propController = properties.find(property => property.id == "DbaClassificationController");
								controllerId = propController.value.identifier;
								
								if (changeSet.documentType) {
									// A new document type has been selected (property change), however this is not a new document
									console.log("CS-BatchContent:_onSaveChangeSet() : Updating document type on document: " + contentItem.name);
									this._addProperty(controllerProperties, "DbaSuggestedDocumentType", "STRING", changeSet.documentType);
									this._addProperty(controllerProperties, "DbaSelectedDocumentType", "STRING", changeSet.documentType);
									this._addProperty(controllerProperties, "DbaCaptureStatus", "INTEGER", 35);
									propertiesNeedUpdating = true;
								}

								if (changeSet.isIssueDismissed) {
									// User dismissed issue, reset error count
									console.log("CS-BatchContent:_onSaveChangeSet() : Dismissing issue on document: " + contentItem.name);
									this._addProperty(controllerProperties, "DbaClassificationErrorCount", "INTEGER", 0);
									propertiesNeedUpdating = true;
								}
							}	

							if (documentId) {
								// Content is changed, this is a new version of the document and new controller
								changeSets.push({
									action: "version",
									documentId: documentId,
									reservationId: reservationId,
									documentClassId: "DbaCaptureBase",
									documentProperties: [],
									controllerClassId: "DbaClassificationController",
									oldControllerId: oldControllerId
								});
							} else if (propertiesNeedUpdating) {
								// Content not changed, just update properties
								changeSets.push({
									action: "properties",
									documentId: documentId,
									documentClassId: "DbaCaptureBase",
									documentProperties: [],
									controllerId: controllerId,
									controllerClassId: "DbaClassificationController",
									controllerProperties: controllerProperties
								});
							}
						}
					}
				}
				
				var batchClassId = batchItem.className;
				if (batchDocumentCount == propBatchDocCount.value) {
					// If the batch document count has not changed, don't try to set it
					batchDocumentCount = null;
					batchClassId = null;
				} else {
					// Update the current batch item documents count property
					propBatchDocCount.value = batchDocumentCount;
				}
				
				var params = {
					batchId: batchItem.id,
					batchClassId: batchClassId,
					batchDocumentCount: batchDocumentCount,
					changeSets: changeSets,
					repository: view._instance.objectStoreName,
					serverAppResource: view._instance.serverConfigurationName
				};
				
				// Need to make the call to update the batch 
				view._instance.saveBatchSvc = view.ui.get("SaveBatchSvc");
				this._callService(view._instance.saveBatchSvc, params);
			},
			
			_onRollbackChangeSet: function(view, batchItem, contentItems, callback, errback) {
				view._instance.rollbackBatches[batchItem.id] = {
					contentItems: contentItems,
					callback: callback,
					errback: errback
				};
				view._instance.saveErrback = errback; // general error callback handling
	
				var properties = batchItem.properties.items ? batchItem.properties.items : batchItem.properties;
				var propBatchDocCount = properties.find(property => property.id == "DbaBatchDocumentCount");
				var batchDocumentCount = propBatchDocCount.value;

				var changeSets = [];
				for (var i = 0; i < contentItems.length; i++) {
					var contentItem = contentItems[i];
					if (contentItem.classifyChangeSet) {
						var changeSet = contentItem.classifyChangeSet;
						if (changeSet.isNew) {
							if (contentItem.reservation && contentItem.reservation.id) {
								console.log("CS-BatchContent:_onRollbackChangeSet() : Rolling back new document (delete): " + contentItem.name);
								changeSets.push({
									action: "delete",
									documentId: contentItem.id,
									reservationId: contentItem.reservation.id,
									documentClassId: "DbaCaptureBase",
									documentProperties: []
								});
								batchDocumentCount--;
							} else {
								console.log("CS-BatchContent:_onRollbackChangeSet() : Error new document has no reservation: " + contentItem.name);
							}
						} else if (changeSet.isContentChanged) {
							console.log("CS-BatchContent:_onRollbackChangeSet() : Rolling back content changed on document (cancel checkout): " + contentItem.name);
							if (contentItem.reservation && contentItem.reservation.id) {
								changeSets.push({
									action: "cancel",
									documentId: contentItem.id,
									reservationId: contentItem.reservation.id,
									documentClassId: "DbaCaptureBase",
									documentProperties: []
								});
							} else {
								console.log("CS-BatchContent:_onRollbackChangeSet() : Error existing document has no reservation: " + contentItem.name);
							}
							// Clear out the controller object, it's not a real property on the content item
							if (contentItem.controller) {
								contentItem.controller = null;
							}
						} else if (changeSet.isDeleted) {
							console.log("CS-BatchContent:_onRollbackChangeSet() : Rolling back deleting document (nothing to do): " + contentItem.name);
						}
					}
				}
			
				// Update the current batch item documents count property
				propBatchDocCount.value = batchDocumentCount;
			
				var params = {
					batchId: batchItem.id,
					batchClassId: batchItem.className,
					batchDocumentCount: batchDocumentCount,
					changeSets: changeSets,
					repository: view._instance.objectStoreName,
					serverAppResource: view._instance.serverConfigurationName
				};
				
				// Need to make the call to update the batch 
				view._instance.rollbackBatchSvc = view.ui.get("RollbackBatchSvc");
				this._callService(view._instance.rollbackBatchSvc, params);
			},
			
			_getDeployProjectVersion: function(view, projectId, properties, callback, errback) {
				console.log("CS-BatchContent:_getDeployProjectVersion() : called.");
				view._instance.searchCallback = callback; 
				view._instance.searchErrback = errback; // general error callback handling
				
				if (properties == null || properties.length == 0) {
					properties = [];
					properties.push("DbaDisplayName");
					properties.push("DbaDescription");
					properties.push("DbaDeploymentStatus");
					properties.push("DbaCaProjectDescriptor");
					properties.push("DbaBusinessOwnersUMSTeamUUID");
					properties.push("DbaLastDeploymentError");
					properties.push("DbaDeployedDefinitions");
				}

				var params = {
					pageSize: 2000,
					countLimit: 2000,
					searchFor: "Abstract",
					searchType: "DbaDeployedProjectVersion",
					searchProperty: "id",
					searchOperator: "=",
					searchValue: projectId,
					searchPropertyType: "string",
					orderByProperty: "DateCreated",
					order: "DESC",
					properties: properties,
					repository: view._instance.objectStoreName,
					serverAppResource: view._instance.serverConfigurationName
				};
										
				view._instance.searchAbstractSvc = view.ui.get("SearchAbstractSvc");
				this._callService(view._instance.searchAbstractSvc, params);
			},
			
			_getDeployedProject: function(view, projectId, properties, tryProject, callback, errback) {
				console.log("CS-BatchContent:_getDeployedProject() : called.");
				view._instance.searchCallback = callback; 
				view._instance.searchErrback = errback; // general error callback handling
				
				view._instance.versionProperties = properties;  // Save any properties that are passed in
				if (properties == null || properties.length == 0) {
					properties = [];
					properties.push("DbaDeploymentStatus");
					properties.push("DbaLastDeploymentError");
					properties.push("DbaRepoPrimaryKey");
					properties.push("DbaCurrentDeployedVersion"); // Object value property
				}
				
				if (tryProject) {
					// If the deployed project is not found, will try querying for deployed project version
					view._instance.projectId = projectId;
				}

				var params = {
					pageSize: 2000,
					countLimit: 2000,
					searchFor: "Abstract",
					searchType: "DbaDeployedProject",
					searchProperty: "id",
					searchOperator: "=",
					searchValue: projectId,
					searchPropertyType: "string",
					orderByProperty: "DateCreated",
					order: "DESC",
					properties: properties,
					repository: view._instance.objectStoreName,
					serverAppResource: view._instance.serverConfigurationName
				};
										
				view._instance.searchAbstractSvc = view.ui.get("SearchAbstractSvc");
				this._callService(view._instance.searchAbstractSvc, params);
			}			
		};
	}
	
	/*
	 * Public control methods *************************************************************
	 */
	 
	/**
	 * @instance
	 * @memberof CS-BatchContent
	 * @method checkoutDocument
	 * @param {CSContentItem} contentItem object hold the id of the document you would like to check out.
	 * @param callback: Function called when document is checked out successfully.
	 * @param errback: Function called when an error occurs.
	 * @desc Checks out a document.
	 */
	this.constructor.prototype.checkoutDocument = function(contentItem, callback, errback) {
		console.log("CS-BatchContent:checkoutDocument() : called.");
		if (contentItem && contentItem.id) {
			this._proto._onCheckoutDocument(this, contentItem, callback, errback);
		}
	}; 
	
	/**
	 * @instance
	 * @memberof CS-BatchContent
	 * @method getProperties
	 * @param {CSContentItem} contentItem object to retrieve the properties for
	 * @param properties array of property names to retrieve
	 * @param callback: Function called when the properties are retrieved successfully.
	 * @param errback: Function called when an error occurs.
	 * @desc Retrieves the properties for the specified content item.
	 */
	this.constructor.prototype.getProperties = function(contentItem, properties, callback, errback) {	
		console.log("CS-BatchContent:getProperties() : called.");
		if (contentItem && contentItem.id) {
			this._proto._onGetProperties(this, contentItem, properties, callback, errback);
		}
	};

	/**
	 * @instance
	 * @memberof CS-BatchContent
	 * @method updateProperties
	 * @param {CSContentItem} contentItem object holding list of properties to be saved
	 *                        in standard js format [{id: "propSymName", value: "StringValue", dataType: "STRING", cardinality: "SINGLE"},..]
	 * @param callback: Function called when the properties are updated successfully.
	 * @param errback: Function called when an error occurs.
	 * @desc Updates the property values for the object passed in, will convert the passed in properties
	 *       into a format for passing into the update properties action service and graphql.
	 */
	this.constructor.prototype.updateProperties = function(contentItem, callback, errback) {	
		console.log("CS-BatchContent:updateProperties() : called.");
		if (contentItem && contentItem.id) {
			this._proto._onUpdateProperties(this, contentItem, callback, errback);
		}
	};
	
	/**
	 * @instance
	 * @memberof CS-BatchContent
	 * @method processChangeSet
	 * @param (CSContentItem) batchItem holding current batch information
	 * @param {CSContentItems} List of contentItems holding set of changes made to the individual batch documents
	 * @param callback: Function called when the changed set is processed successfully.
	 * @param errback: Function called when an error occurs.
	 * @desc Updates the Batch structure and properties based on the information in the change set.
	 */
	this.constructor.prototype.processChangeSet = function(batchItem, contentItems, callback, errback) {	
		console.log("CS-BatchContent:processChangeSet() : called.");
		if (contentItems && contentItems.length > 0) {
			this._proto._onProcessChangeSet(this, batchItem, contentItems, callback, errback);
		}
	};

	/**
	 * @instance
	 * @memberof CS-BatchContent
	 * @method saveChangeSet
	 * @param (CSContentItem) batchItem holding current batch information
	 * @param {CSContentItems} List of contentItems holding set of changes made to the individual batch documents
	 * @param callback: Function called when the change set is saved successfully.
	 * @param errback: Function called when an error occurs.
	 * @desc Checks in the new documents that were just created and had the content uploaded.
	 */
	this.constructor.prototype.saveChangeSet = function(batchItem, contentItems, callback, errback) {	
		console.log("CS-BatchContent:saveChangeSet() : called.");
		if (contentItems && contentItems.length > 0) {
			this._proto._onSaveChangeSet(this, batchItem, contentItems, callback, errback);
		}
	};

	/**
	 * @instance
	 * @memberof CS-BatchContent
	 * @method rollbackChangeSet
	 * @param (CSContentItem) batchItem holding current batch information
	 * @param {CSContentItems} List of contentItems holding set of changes made to the individual batch documents
	 * @param callback: Function called when the change set is rolled back successfully.
	 * @param errback: Function called when an error occurs.
	 * @desc Rolls back the changes maded in the processChangeSet function.
	 */
	this.constructor.prototype.rollbackChangeSet = function(batchItem, contentItems, callback, errback) {	
		console.log("CS-BatchContent:rollbackChangeSet() : called.");
		if (contentItems && contentItems.length > 0) {
			this._proto._onRollbackChangeSet(this, batchItem, contentItems, callback, errback);
		}
	};

	/**
	 * @instance
	 * @memberof CS-BatchContent
	 * @method lockBatch
	 * @param (CSContentItem) batchItem holding current batch information
	 * @param (integer) hours number of hours in future to set the lease time
	 * @param callback: Function called when the batch has been locked successfully.
	 * @param errback: Function called when an error occurs.
	 * @desc Locks a batch object.
	 */
	this.constructor.prototype.lockBatch = function(batchItem, hours, callback, errback) {	
		console.log("CS-BatchContent:lockBatch() : called.");
		if (hours == null || hours <= 0) {
			hours = 8;
		}
		// Call get properties first to get the latest lease time before trying to lock
		this._proto._getBatchLeaseTimeProperties(this, batchItem, "lock", hours, callback, errback);
	};

	/**
	 * @instance
	 * @memberof CS-BatchContent
	 * @method unlockBatch
	 * @param (CSContentItem) batchItem holding current batch information
	 * @param callback: Function called when the batch is unloacked successfully.
	 * @param errback: Function called when an error occurs.
	 * @desc Unlocks a batch object.
	 */
	this.constructor.prototype.unlockBatch = function(batchItem, callback, errback) {	
		console.log("CS-BatchContent:unlockBatch() : called.");
		var contentItem = {
			baseType: batchItem.baseType,
			id: batchItem.id,
			className: batchItem.className,
			properties: [{
				id: "DbaLeaseTime",
				dataType: "DATE",
				cardinality: "SINGLE",
				value: null
			}]
		};
		this._proto._onUpdateProperties(this, contentItem, callback, errback);
	};
	
	/**
	 * @instance
	 * @memberof CS-BatchContent
	 * @method getBatchLock
	 * @param (CSContentItem) batchItem holding current batch information
	 * @param callback: Function called when the batch has been locked successfully.
	 * @param errback: Function called when an error occurs.
	 * @desc Returns the batch lock property information.
	 */
	this.constructor.prototype.getBatchLock = function(batchItem, callback, errback) {	
		console.log("CS-BatchContent:getBatchLock() : called.");

		// Call get properties to get the latest lease time 
		this._proto._getProperties(this, batchItem, "properties", null, callback, errback);
	};

	/**
	 * @instance
	 * @memberof CS-BatchContent
	 * @method getDeployedProjectVersion
	 * @param projectId: Project id that you would like to query for
	 * @param properties: a list of properties to be returned in the results set for each item (optional, if null, will return all a default set)
	 * @param tryProject: Boolean flag indicating whether to look for a deployed project with a current deployed version first
	 * @param callback: Function called when the deployed project has been returned successfully.
	 * @param errback: Function called when an error occurs.
	 * @desc Returns a deployed project object
	 */
	this.constructor.prototype.getDeployedProjectVersion = function(projectId, properties, tryProject, callback, errback) {	
		console.log("CS-BatchContent:getDeployedProjectVersion() : called for project: " + projectId);

		// Call search service to query for the deployed project object first, if not found will look for the deployed project version
		this._proto._getDeployedProject(this, projectId, properties, tryProject, callback, errback);
	};

	/**
	 * Sets a callback method that will be called after a batch object is added or modified.
	 */
	this.constructor.prototype.setBatchUpdatedCallback = function(callback) {
		this._instance.batchUpdatedCallback = callback;
	};
	
	/**
	 * Sets the name of the object store that will be used when making calls to the server.
	 */
	this.constructor.prototype.setObjectStoreName = function(objectStoreName) {
		this._instance.objectStoreName = objectStoreName;
	};

	/*
	 * Private methods and event handlers *************************************************************
	 */
	
	this.constructor.prototype._onCheckoutDocumentResults = function (view, results) {
		if (results && results.results && results.results.items && results.results.items.length > 0) {
			var contentItem = results.results.items[0];
			var callbacks = this._instance.checkoutDocument[contentItem.id];
			if (callbacks && callbacks.callback) {
				callbacks.callback(contentItem);
			}
			bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONDOCUMENTCHECKEDOUT, contentItem);
		} else {
			console.log("CS-BatchContent._onCheckoutDocumentResults: Error getting checking out document: " + JSON.stringify(results));
			var errback = this._instance.checkoutErrback;
			if (errback) {
				errback(error);
			}
			bpmext.ui.executeEventHandlingFunction(this, this.EVT_ONERROR, messages.contlist_checkout_failed);
		}
	};
	
	this.constructor.prototype._onCheckoutDocumentError = function (view, error) {
		console.log("CS-BatchContent._onCheckoutDocumentError: Error getting checking out document: " + JSON.stringify(error));
		var errback = this._instance.checkoutErrback;
		if (errback) {
			errback(error);
		}
		bpmext.ui.executeEventHandlingFunction(this, this.EVT_ONERROR, messages.contlist_checkout_failed);
	};
	
	this.constructor.prototype._onGetPropertiesResults = function(view, results) {
		console.log("CS-BatchContent:_onGetPropertiesResults");
		if (results) {
			var contentItem = results;
			if (contentItem.update && contentItem.update == "properties") {
				var properties = contentItem.properties.items ? contentItem.properties.items : contentItem.properties;
				// The return contentItem object always has an id first class property
				var callbacks = this._instance.getProperties[contentItem.id];
				if (callbacks && callbacks.callback) {
					callbacks.callback(properties);
				}
				bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONGETPROPERTIES, properties);
			} else {
				this._proto._lockBatch(this, contentItem);
			}
		}
	};
	
	this.constructor.prototype._onGetPropertiesError = function(view, error) {
		var logMessage = error && error.errorText ? error.errorText : messages.getcontent_ret_properties_error;
		console.log("CS-BatchContent:_onGetPropertiesError : " + logMessage);
		var errback = this._instance.propertiesErrback;
		if (errback) {
			errback(error);
		}
		var self = this;
		setTimeout(function() {
			bpmext.ui.executeEventHandlingFunction(self, self._proto.EVT_ONERROR, messages.getcontent_ret_properties_error);
		});
	};

	this.constructor.prototype._onUpdatePropertiesResults = function(view, results) {
		console.log("CS-BatchContent:_onUpdatePropertiesResults");
		var properties = results.properties.items ? results.properties.items : results.properties;
		var propId = properties.find(property => property.id == "Id");
		var callbacks = this._instance.updateProperties[propId.value];
		if (callbacks && callbacks.callback) {
			callbacks.callback(properties);
		}
		bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONUPDATEPROPERTIES, properties);
	};
	
	this.constructor.prototype._onUpdatePropertiesError = function(view, error) {
		var logMessage = error && error.errorText ? error.errorText : messages.properties_edit_save_failure;
		console.log("CS-BatchContent:_onUpdatePropertiesError : " + logMessage);
		var errback = this._instance.propertiesErrback;
		if (errback) {
			errback(error);
		}
		var self = this;
		setTimeout(function() {
			bpmext.ui.executeEventHandlingFunction(self, self._proto.EVT_ONERROR, messages.properties_edit_save_failure);
		});
	};

	this.constructor.prototype._onUpdateBatchResults = function(view, results) {
		// Get the batch information from the view instance
		var data = results.data;
		var changeSet = this._instance.updateBatches[results.batchId];
		if (data.updateCmAbstractPersistable && data.updateCmAbstractPersistable.id) {
			if (changeSet && changeSet.contentItems) {
				console.log("CS-BatchContent:_onUpdateBatchResults() called");
				// If any existing documents needed to be checked out, need to get the reservation information from response
				for (var i = 0; i < changeSet.contentItems.length; i++) {
					var contentItem = changeSet.contentItems[i];
					if (contentItem.classifyChangeSet) {
						if (contentItem.classifyChangeSet.isContentChanged) {
							// Get the checked out docuemnt reservation id and add it to the content item
							var documentId = contentItem.id;
							var checkoutDocumentName = "checkoutDocument" +  documentId.replace(/[{}]/g, "").replace(/-/g, "_");
							var checkoutInfo = data[checkoutDocumentName];
							if (checkoutInfo && checkoutInfo.reservation) {
								contentItem.reservation = {
									id: checkoutInfo.reservation.id,
									name: checkoutInfo.reservation.name
								};
							}
						}
					}
				}
				if (changeSet && changeSet.callback) {
					changeSet.callback(changeSet.contentItems);
				}
				bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONUPDATEBATCH, changeSet.contentItems);
			} else {
				console.log("CS-BatchContent._onUpdateBatchResults: Error getting batch update results: " + JSON.stringify(results));
				if (changeSet && changeSet.errback) {
					changeSet.errback(messages.batchcontent_update_properties_error);
				}
				bpmext.ui.executeEventHandlingFunction(this, this.EVT_ONERROR, messages.batchcontent_update_properties_error);
			}
		} else {
			console.log("CS-BatchContent._onUpdateBatchResults: No changes were needed to be made: " + JSON.stringify(results));
			if (changeSet && changeSet.callback) {
				changeSet.callback(changeSet.contentItems);
			}
			bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONUPDATEBATCH, changeSet.contentItems);
		}
	};
	
	this.constructor.prototype._onUpdateBatchError = function(view, error) {
		var logMessage = error && error.errorText ? error.errorText : messages.batchcontent_update_properties_error;
		console.log("CS-BatchContent:_onUpdateBatchError : " + logMessage);
		var errback = this._instance.updateErrback;
		if (errback) {
			errback(error);
		}
		var self = this;
		setTimeout(function() {
			bpmext.ui.executeEventHandlingFunction(self, self._proto.EVT_ONERROR, messages.batchcontent_update_properties_error);
		});
	};

	this.constructor.prototype._onSaveBatchResults = function(view, results) {
		// Get the batch information from the view instance
		var data = results.data;
		var changeSet = this._instance.saveBatches[results.batchId];
		if (changeSet && changeSet.contentItems) {
			console.log("CS-BatchContent:_onSaveBatchResults() called");
			// If any existing documents needed to be checked out, need to get the reservation information from response
			for (var i = 0; i < changeSet.contentItems.length; i++) {
				var contentItem = changeSet.contentItems[i];
				if (contentItem.classifyChangeSet) {
					if (contentItem.classifyChangeSet.isDeleted) {
						// NA - can be a case where both isDeleted and isContentChanged are true, so need to catch isDeleted first
					} else if (contentItem.classifyChangeSet.isNew) {
						// The contentItem id will have already been set to the reservation id
						contentItem.reservation = null;						
						contentItem.isReserved = false;
						// The downloadUrl will aready be specified using the correct id
					} else if (contentItem.classifyChangeSet.isContentChanged) {
						// Content was versioned, remove the reservation information and update the id
						contentItem.id = contentItem.reservation.id;
						var properties = contentItem.properties.items ? contentItem.properties.items : contentItem.properties;
						var propId = properties.find(property => property.id == "Id");
						if (propId) {
							propId.value = contentItem.reservation.id;
						}
						contentItem.reservation = null;
						contentItem.isReserved = false;
						// Need to update the controller id in the properties collection
						var propCont = properties.find(property => property.id == "DbaClassificationController");
						if (propCont) {
							propCont.value.identifier = contentItem.controller.id;
						}
						contentItem.controller = null;
						// Need to update the download url to have the correct document id guid
						var contentElements = contentItem.contentElements.items ?  contentItem.contentElements.items : contentItem.contentElements;
						if (contentElements.length > 0) {
							var contentElement = contentElements[0];  // will only be one item
							contentElement.downloadUrl = "/content?repositoryIdentifier=" + this._instance.objectStoreName + "&documentId=" + contentItem.id + "&elementSequenceNumber=0"
						}
					}
				}
			}

			if (changeSet && changeSet.callback){
				changeSet.callback(changeSet.contentItems);
			}
			bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONSAVEBATCH, changeSet.contentItems);
		} else {
			console.log("CS-BatchContent._onSaveBatchResults: Error saving batch results: " + JSON.stringify(results));
			if (changeSet && changeSet.errback){
				changeSet.errback(messages.batchcontent_save_properties_error);
			}
			bpmext.ui.executeEventHandlingFunction(this, this.EVT_ONERROR, messages.batchcontent_save_properties_error);
		}
	};
	
	this.constructor.prototype._onSaveBatchError = function(view, error) {
		var logMessage = error && error.errorText ? error.errorText : messages.batchcontent_save_properties_error;
		console.log("CS-BatchContent:_onSaveBatchError : " + logMessage);
		var errback = this._instance.saveErrback;
		if (errback) {
			errback(error);
		}
		var self = this;
		setTimeout(function() {
			bpmext.ui.executeEventHandlingFunction(self, self._proto.EVT_ONERROR, messages.batchcontent_save_properties_error);
		});
	};

	this.constructor.prototype._onRollbackBatchResults = function(view, results) {
		// Get the batch information from the view instance
		var batchId = results.batchId;
		var changeSet = this._instance.rollbackBatches[batchId];
		if (changeSet && changeSet.contentItems) {
			console.log("CS-BatchContent:_onRollbackBatchResults() called");
			if (changeSet && changeSet.callback){
				changeSet.callback(changeSet.contentItems);
			}
			bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONROLLBACKBATCH, changeSet.contentItems);
		} else {
			console.log("CS-BatchContent._onRollbackBatchResults: Error rolling back batch results: " + JSON.stringify(results));
			if (changeSet && changeSet.errback){
				changeSet.errback(messages.batchcontent_save_properties_error);
			}
			bpmext.ui.executeEventHandlingFunction(this, this.EVT_ONERROR, messages.batchcontent_rollback_properties_error);
		}
	};
	
	this.constructor.prototype._onRollbackBatchError = function(view, error) {
		var logMessage = error && error.errorText ? error.errorText : messages.batchcontent_rollback_properties_error;
		console.log("CS-BatchContent:_onRollbackBatchError : " + logMessage);
		var errback = this._instance.saveErrback;
		if (errback) {
			errback(error);
		}
		var self = this;
		setTimeout(function() {
			bpmext.ui.executeEventHandlingFunction(self, self._proto.EVT_ONERROR, messages.batchcontent_rollback_properties_error);
		});
	};
	
	this.constructor.prototype._onSearchAbstractResults = function(view, results) {
		console.log("CS-BatchContent:_onSearchAbstractResults() called");
		if (results && results.results) {
			if (results.results.items.length == 0 && this._instance.projectId) {
				console.log("CS-BatchContent:_onSearchAbstractResults() did not find deployed project, searching for deployed project version");
				var projectId = this._instance.projectId;
				this._instance.projectId = null; // Clear the project id so we don't keep looking for it
				this._proto._getDeployProjectVersion(this, projectId, this._instance.versionProperties, this._instance.searchCallback, this._instance.searchErrback);
			} else {
				// Found something, check the result set for the returned object being a Deployed Project object
				var item = results.results.items[0]; // should only be one item
				if (item && item.className == "DbaDeployedProject") {
					// Found a real project, get the current deployed version property value and query for that object
					var properties = item.properties.items ? item.properties.items : item.properties;
					var propCurrentDeployed = properties.find(property => property.id == "DbaCurrentDeployedVersion");
					if (propCurrentDeployed) {
						var projectVersionId = propCurrentDeployed.value.identifier;
						console.log("CS-BatchContent:_onSearchAbstractResults() found deployed project, searching for deployed project version");
						this._proto._getDeployProjectVersion(this, projectVersionId, this._instance.versionProperties, this._instance.searchCallback, this._instance.searchErrback);
					}
				} else {
					console.log("CS-BatchContent:_onSearchAbstractResults() Returned results, number items found: " + results.results.items.length);
					var callback = this._instance.searchCallback;
					if (callback) {
						callback(results.results.items);
					}
					bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONSEARCHRESULTS, results.results.items);
				}
			}
		} else {
			console.log("CS-BatchContent._onSearchAbstractResults: Error retrieving search results: " + JSON.stringify(results));
			var errback = this._instance.searchErrback;
			if (errback){
				errback(messages.batchcontent_save_properties_error);
			}
			bpmext.ui.executeEventHandlingFunction(this, this.EVT_ONERROR, messages.batchcontent_search_error);
		}
	};

	this.constructor.prototype._onSearchAbstractError = function(view, error) {
		var logMessage = error && error.errorText ? error.errorText : messages.batchcontent_search_error;
		console.log("CS-BatchContent:_onSearchAbstractError : " + logMessage);
		var errback = this._instance.searchErrback;
		if (errback) {
			errback(error);
		}
		var self = this;
		setTimeout(function() {
			bpmext.ui.executeEventHandlingFunction(self, self._proto.EVT_ONERROR, messages.batchcontent_search_error);
		});
	};
	
	/*
	 * Coach NG Lifecycle methods *************************************************************
	 */

	this.constructor.prototype.load = function() {
		var opts = this.context.options;
		
		if (!opts.objectStoreName) {
            opts.objectStoreName = bpmext.ui.substituteConfigOption(this, "objectStoreName", null);
		}
		if (!this._instance.objectStoreName) {
			this._instance.objectStoreName = opts.objectStoreName.get("value");
		}
		
		bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONERROR, "message");
		bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONGETPROPERTIES, "properties");
		bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONUPDATEPROPERTIES, "properties");
		bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONDOCUMENTCHECKEDOUT, "contentItem");
		bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONUPDATEBATCH, "changeSet");
		bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONSAVEBATCH, "changeSet");
		bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONROLLBACKBATCH, "changeSet");
		bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONSEARCHRESULTS, "items");
		
		this._instance.checkoutDocumentSvc = this.ui.get("CheckoutDocumentSvc");
		this._instance.updatePropertiesSvc = this.ui.get("UpdatePropertiesSvc");
		this._instance.getPropertiesSvc = this.ui.get("GetPropertiesSvc");
		this._instance.updateBatchSvc = this.ui.get("UpdateBatchSvc");
		this._instance.saveBatchSvc = this.ui.get("SaveBatchSvc");
		this._instance.rollbackBatchSvc = this.ui.get("RollbackBatchSvc");
		this._instance.searchAbstractSvc = this.ui.get("SearchAbstractSvc");
		
		domStyle.set(this.context.element, "margin", 0);
		domStyle.set(this.context.element, "padding", 0);
	};
	
	this.constructor.prototype.change = function(event) {
	};
}