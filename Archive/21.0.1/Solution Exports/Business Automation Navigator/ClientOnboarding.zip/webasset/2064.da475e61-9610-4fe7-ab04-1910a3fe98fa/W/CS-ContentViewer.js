/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019 - 2020. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

cs_InitContentViewer = function (utilities, bpmext, domClass, domStyle, domAttr, domConstruct, messages, string) {
	
	this._instance = {
		skipIframeReset: false
	};

	if (!this.constructor.prototype._proto) {
		
		this.constructor.prototype._proto =
		{
			OPTS_COL_STLZ :
			{
				"D" : "",
				"P": "btn-primary",
				"I" : "btn-info",
				"S" : "btn-success",
				"W" : "btn-warning",
				"G" : "btn-danger"
			},
			_EVT_ON_UPLOAD_OK : "onuploadOkFunctionName",

			/**
			 * Helper function to retrieve the Object Store Name as defined in ACCE admin tool. 
			 */
			_getObjectStoreName: function(view) {
				var objectStoreName = view.context.options.objectStoreName.get("value");
				return objectStoreName;
			},

			//Private functions
			_formatUrl: function(url) {
				newUrl = url;
				newUrl = newUrl.replace(/&amp;/g, '&');
				newUrl = newUrl.replace(/&quot;/g, '"');
				newUrl = newUrl.replace(/&lt;/g, '<');
				newUrl = newUrl.replace(/&gt;/g, '>');

				return newUrl;
			},
			
			_getVisibility: function(view) {
				var visibility = "DEFAULT";
				if (view.context.options._metadata.visibility) {
					visibility = view.context.options._metadata.visibility.get("value");
				}
				if (visibility == "DEFAULT") {
					visibility = view.context.getInheritedVisibility();
				}
				return visibility;
			},
			
			_setWidth: function(view) {
				var size = view.context.options.width.get("value") ? view.context.options.width.get("value") : "100%";

				try {
					if (size != null && size != "") {
						if (!isNaN(size)) {
							size += "px";
						}
						view.context.element.style.width = size;
					}
				} catch (e)	{
					bpmext.log.error("FileViewer._setWidth() error: " + e);
					if (e.stack) {
						bpmext.log.error("  Call stack: " + e.stack);
					}
				}
			},
			
			_setHeight: function(view) {
				var size = view.context.options.height.get("value") ? view.context.options.height.get("value") : this._getDefaultHeight(view);

				try	{
					if (size != null && size != "")	{
						if (!isNaN(size)) {
							size += "px";
						}
						view.context.element.style.height = size;
					}
				} catch (e)	{
					bpmext.log.error("FileViewer._setHeight() error: " + e);
					if (e.stack) {
						bpmext.log.error("  Call stack: " + e.stack);
					}
				}
			},
			
			_getDefaultHeight: function(view) {
				if (view && view.context.element && view.context.element.parentElement && view.context.element.parentElement.className == "ContentBox") {
					return "600px";
				}
				return "100%";
			},
			
			_refreshStyle: function(view) {
				if (view._instance.iframeElement.src == null || view._instance.iframeElement.src == "") {
					return;
				}
				var width = view.context.options.fitWidth.get("value") ? "100%" : null;
				var height = view.context.options.fitHeight.get("value") ? "100%" : null;

				var css = "body > img {margin-left:auto!important;margin-right: auto!important;display: block;";

				if (width != null) {
					css += "width:" + width + ";";
					if (view._instance.fitToWidthElement) {
						var faTimes = document.createElement("i");
						domClass.add(faTimes, "fa fa-times");
						view._instance.fitToWidthElement.appendChild(faTimes);
						var fitToWidth = document.createTextNode(" Fit to width");
						view._instance.fitToWidthElement.appendChild(fitToWidth);
					}
				} else {
					if (view._instance.fitToWidthElement) {
						var faArrows = document.createElement("i");
						domClass.add(faArrows, "fa fa-arrows-h");
						view._instance.fitToWidthElement.appendChild(faArrows);
						var fitToWidth = document.createTextNode(" Fit to width");
						view._instance.fitToWidthElement.appendChild(fitToWidth);
					}
				}

				if (height != null) {
					css += "height:" + height + ";";
					if (view._instance.fitToHeightElement) {
						var faTimes = document.createElement("i");
						domClass.add(faTimes, "fa fa-times");
						view._instance.fitToWidthElement.appendChild(faTimes);
						var fitToHeight = document.createTextNode(" Fit to height");
						view._instance.fitToWidthElement.appendChild(fitToHeight);
					}
				} else {
					if (view._instance.fitToHeightElement) {
						var faArrows = document.createElement("i");
						domClass.add(faArrows, "fa fa-arrows-v");
						view._instance.fitToWidthElement.appendChild(faArrows);
						var fitToHeight = document.createTextNode(" Fit to height");
						view._instance.fitToWidthElement.appendChild(fitToHeight);
					}
				}

				css +="}";

				this._setStyle(view, "content-1", css);
			},
			
			_createCtrlRibbon: function(view, top) {
				view._instance.onwLinkCnt = document.createElement("div");
				domClass.add(view._instance.onwLinkCnt, "onwLinkCnt");

				view._instance.linkElement = document.createElement("a");
				view._instance.linkElement.target = "_blank";
				domAttr.set(view._instance.linkElement, "role", "button");
				domAttr.set(view._instance.linkElement, "tabindex", "0");

				view._instance.fitToHeightElement = document.createElement("a");
				view._instance.fitToHeightElement.href="javascript:void(0)";
				domAttr.set(view._instance.fitToHeightElement, "role", "button");
				domAttr.set(view._instance.fitToHeightElement, "tabindex", "0");

				view._instance.fitToHeightElement.onclick = function(evt) {
					view.context.options.fitHeight.set("value", !view.context.options.fitHeight.get("value"));
				}

				view._instance.fitToWidthElement = document.createElement("a");
				view._instance.fitToWidthElement.href="javascript:void(0)";
				domAttr.set(view._instance.fitToWidthElement, "role", "button");
				domAttr.set(view._instance.fitToWidthElement, "tabindex", "0");

				view._instance.fitToWidthElement.onclick = function(evt) {
					view.context.options.fitWidth.set("value", !view.context.options.fitWidth.get("value"));
				}

				view._instance.onwLinkCnt.appendChild(view._instance.fitToHeightElement);
				view._instance.onwLinkCnt.appendChild(view._instance.fitToWidthElement);
				view._instance.onwLinkCnt.appendChild(view._instance.linkElement);

				if (!top) {
					view._instance.envelope.appendChild(view._instance.onwLinkCnt);
				} else {
					view._instance.envelope.insertBefore(view._instance.onwLinkCnt, view._instance.cnt);
				}
			},
			
			_setupCtrls: function(view) {
				if (view._instance.onwLinkCnt) {
					view._instance.onwLinkCnt.parentNode.removeChild(view._instance.onwLinkCnt);

					delete view._instance.linkElement;
					delete view._instance.onwLinkCnt;
					delete view._instance.fitToHeightElement;
					delete view._instance.fitToWidthElement;
				}

				var plc = view.context.options.ctrlsPlacement.get("value");

				switch(plc) {
					case "B":
						domClass.add(view.context.element, "bottomCtrls");
						this._createCtrlRibbon(view, false);
						break;
					case "T":
						domClass.add(view.context.element, "topCtrls");
						this._createCtrlRibbon(view, true);
						break;
					default:
						domClass.remove(view.context.element, "bottomCtrls");
				}
			},
			
			_handleVisibility: function(view) {
				//var visibility = bpmext.ui.getEffectiveVisibility(view);
				var visibility = utilities.handleVisibility(view.context);		

				if (visibility != "NONE") {
					if (visibility == "READONLY") {
						domClass.remove(view._instance.disabler, "hidden");
					} else {
						domClass.add(view._instance.disabler, "hidden");
					}
				}
			},
			
			_resizeIframe: function(obj) {
				obj.style.height = 0;
				obj.style.height = obj.contentWindow.document.body.scrollHeight + 20 + 'px';
				//obj.style.width = obj.contentWindow.document.body.scrollWidth + 'px';

				//obj.contentWindow.document.body.style.textAlign = "center";
			},
			
			_setStyle: function(view, id, css) {
				var doc = view._instance.iframeElement.contentDocument;
				if (doc != null) {
					var style = doc.getElementById(id);
					if (style == null) {
						var docHead = doc.querySelector("head");
						if (docHead == null) {
							var html = doc.documentElement;

							docHead = doc.createElement("head");
							html.insertBefore(docHead, doc.body);
						}

						style = doc.createElement("style");
						style.type = "text/css";
						style.id = id;

						docHead.appendChild(style);
					}

					var cssText = document.createTextNode(css);
					style.appendChild(cssText);
				}
			}
		};

		/**
		 * Public control methods *************************************************************
		 */

		/**
		 * @instance
		 * @memberof ContentViewer
		 * @method fitContentToWidth
		 * @desc Sets the option to fit the content to the specified width.
		 * @param {boolean} flag Fits the content to the width (when 'true').
		 */
		this.constructor.prototype.fitContentToWidth = function(flag) {
			this.context.options.fitWidth.set("value", flag);
		}

		/**
		 * @instance
		 * @memberof ContentViewer
		 * @method fitContentToHeight
		 * @desc Sets the option to fit the content to the specified height.
		 * @param {boolean} flag Fits the content to the height (when 'true').
		 */
		this.constructor.prototype.fitContentToHeight = function(flag) {
			this.context.options.fitHeight.set("value", flag);
		}

		/**
		 * @instance
		 * @memberof ContentViewer
		 * @method setUrl
		 * @desc Sets the document URL to display in the viewer.
		 * @param {string} url The document URL to display.
		 */
		this.constructor.prototype.setUrl = function(url) {
			this.context.binding.set("value", {contentURL: url});
		}

		/**
		 * @instance
		 * @memberof ContentViewer
		 * @method getType
		 * @desc Returns the descriptive string that represents the control type.
		 * @returns {string}
		 */
		this.constructor.prototype.getType = function() {
			return "contentViewer.1";
		}

		/**
		 * Coach NG Lifecycle methods *************************************************************
		 */

		this.constructor.prototype.load = function() {
			try {
				var options = this.context.options;

				if (!this.context.binding) {
					this.context.binding = bpmext.ui.substituteObject(this);
				}
				if (!options.width) {
					options.width = bpmext.ui.substituteConfigOption(this, "width", null);
				}
				if (!options.height) {
					options.height = bpmext.ui.substituteConfigOption(this, "height", null);
				}
				if (!options.ctrlsPlacement) {
					options.ctrlsPlacement = bpmext.ui.substituteConfigOption(this, "ctrlsPlacement", "N");
				}
				if (!options.fitWidth) {
					options.fitWidth = bpmext.ui.substituteConfigOption(this, "fitWidth", false);
				}
				if (!options.fitHeight) {
					options.fitHeight = bpmext.ui.substituteConfigOption(this, "fitHeight", false);
				}
				
				if (!options.objectStoreName) {
                    options.objectStoreName = bpmext.ui.substituteConfigOption(this, "objectStoreName", null);
				}
				
//				bpmext.ui.registerEventHandlingFunction(this, this._proto._EVT_ON_FILE_SELECTED);

				this._instance.envelope = document.createElement("div");

				this._instance.cnt = document.createElement("div");
				domClass.add(this._instance.cnt, "cnt");
				domAttr.set(this._instance.cnt, "position", "absolute");

				this._instance.disabler = bpmext.ui.util.createDisabler(this, this._instance.envelope);

				this._instance.iframeElement = document.createElement("iframe");
				domAttr.set(this._instance.iframeElement, "frameborder", "no");

				var height = options.height.get("value");
				if (height != null) {
					if (!isNaN(height)) {
						height += "px";
					}
					domAttr.set(this._instance.iframeElement, "height", height);
				} else {
					domAttr.set(this._instance.iframeElement, "height", "100%");
				}
				
				var width = options.width.get("value");
				if (width != null) {
					if (!isNaN(width)) {
						width += "px";
					}
					domAttr.set(this._instance.iframeElement, "width", width);
				} else {
					domAttr.set(this._instance.iframeElement, "width", "100%");
				}

				domAttr.set(this._instance.iframeElement, "scrolling", "yes");
				domClass.add(this._instance.iframeElement, "viewFrm");
				domAttr.set(this._instance.iframeElement, "title", bpmext.localization.formatMsg("controlFileViewer", "TITLE_FILE_VIEWER"));

				var view = this;
				this._instance.iframeElement.onload = function() {
					view._proto._setStyle(view,	"global-0",	"html{height:100%} body{height:100%;margin:0}");
					view._proto._refreshStyle(view);
				};

				this._instance.iframeCnt = document.createElement("div");
				domClass.add(this._instance.iframeCnt, "iframeCnt");

				this._instance.iframeCnt.appendChild(this._instance.iframeElement);

				this._instance.cnt.appendChild(this._instance.iframeCnt);
				this._instance.envelope.appendChild(this._instance.cnt);
				this.context.element.appendChild(this._instance.envelope);

				this._proto._setWidth(this);
				this._proto._setHeight(this);
				this._proto._setupCtrls(this);

				bpmext.ui.loadView(this);
				
			} catch (e) {
				if (this.ui && this.ui.getAbsoluteName) {
					bpmext.log.error("Error on load event [" + this.ui.getAbsoluteName() + "]: " + e);
				} else {
					bpmext.log.error("Error on load event: " + e);
				}
			}
		};

		this.constructor.prototype.view = function() {
			try {
				if (this._instance.skipIframeReset == false) {
					this._instance.iframeElement.src = "about:blank";
				}
				
				var docUrl = this.getDocumentBaseUrl();
				if (docUrl != null) {
					// Don't execute this if bound to a list's listSelected property. 
					if (this.context.binding && this.context.binding.property != "listSelected" && this.context.binding.boundObject) {
						var newUrl = this.context.binding.boundObject.get(this.context.binding.property).contentURL;
						if (newUrl != null) {
							newUrl = this._proto._formatUrl(newUrl);

							if (this._instance.iframeElement.src != newUrl) {
								this._instance.iframeElement.src = newUrl;
								this._proto._refreshStyle(this);
							}

							if (this._instance.linkElement) {
								this._instance.linkElement.href = newUrl;
							}
						}
					}
				} else {
					this.renderTestModeMessage();
				}
				
				this._proto._handleVisibility(this);

			} catch(e) {
				bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
			}
		};

		this.constructor.prototype.change = function (event) {
			try {
				if (event.type == "config") {
					switch (event.property) {
						case "_metadata.visibility": {
							this._instance.skipIframeReset = true;
							this.view();
							this._instance.skipIframeReset = false;
							break;
						}
						case "width": {
							this._proto._setWidth(this, event.newVal);
							break;
						}
						case "height": {
							this._proto._setHeight(this, event.newVal);
							break;
						}
						case "fitWidth":
						case "fitHeight": {
							this._proto._refreshStyle(this);
							break;
						}
						case "ctrlsPlacement": {
							this._proto._setupCtrls(this);
							break;
						}
					}
				} else { 
					if (this.context.binding && event.newVal.id) {
						var boundObject = this.context.binding.boundObject;
						if (boundObject != null) {
							var contentItem = event.newVal;
							console.log("CS-ContentViewer:change() : Change update for bound object: " + contentItem.name);
							if (contentItem && (contentItem.isFolder || !contentItem.viewerUpdate || (contentItem.contentElements && contentItem.contentElements.items.length == 0))) {
								if (contentItem.isFolder || (contentItem.contentElements && contentItem.contentElements.items.length == 0)){
									this._instance.iframeElement.src = 'about:blank';
								}
								console.log("CS-ContentViewer:change() : No viewer update, viewer will not reload.");
								return;  // Can't view folders or don't need to update when only properties change
							}
							console.log("CS-ContentViewer:change() : Reloading viewer.");

							delete this._instance.style;

							this._instance.iframeElement.src = 'about:blank';
							var view = this;
							
							var docUrl = this.getDocumentBaseUrl();
							if (docUrl != null) {
								var objectStoreName = this._proto._getObjectStoreName(this);
								var id = contentItem.id;
								var className = contentItem.className;
								var mimeType = contentItem.mimeType;
								
								docUrl += "&objectStoreName=" + encodeURIComponent(objectStoreName);
								docUrl += "&repositoryType=p8";
								docUrl += "&docid=" + encodeURIComponent(id);
								docUrl += "&template_name=" + encodeURIComponent(className);
								docUrl += "&mimeType=" + encodeURIComponent(mimeType);
								docUrl += "&embedded=true";
								docUrl += "&hideToolbar=true"; // Hide the viewer containers banner bar (toolbar)
			
								setTimeout(function() {
									view._instance.iframeElement.src = docUrl;
								
									if (view._instance.linkElement) {
										view._instance.linkElement.href = docUrl;

										var faLink = document.createElement("i");
										domClass.add(faLink, "fa fa-external-link-square");
										view._instance.linkElement.appendChild(faLink);
										var openInWindow = document.createTextNode(" Open in new window");
										view._instance.linkElement.appendChild(openInWindow);
									}

									view._proto._refreshStyle(view);
								}, 100);
							} else {
								// No context root means we are running in test mode, display a message in viewer area
								console.log("CS-ContentViewer:change() : Running in test mode, no viewer will be displayed.");
								this.renderTestModeMessage();
							}
						}
					}
				}
			} catch (e) {
				bpmext.log.error("Error on change event [" + this.ui.getAbsoluteName() + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};

		this.constructor.prototype.getDocumentBaseUrl = function() {
			var contextRoot;
			var desktop = "default";

			var navUrl = window.location.href;
			
			var params = navUrl.split("&");
			for (var i = 0; i < params.length; i++) {
				var param = params[i].split("=");
				if (param[0] == "contextRoot") {
					var contextRootParam = decodeURIComponent(param[1]);
					// Still need to trim back to base Url part of this string
					var base = contextRootParam.split("?");
					var contextRoot = base[0];
					if (contextRoot[contextRoot.length - 1] != "/") {
						contextRoot += "/";
					}
				} else if (param[0] == "desktop") {
					// switch over to real desktop that is specified on url
					desktop = decodeURIComponent(param[1]);
				}
			}
			
			var docUrl;
			if (contextRoot != null) {
				docUrl = contextRoot + "bookmark.jsp?desktop=" + desktop;
			}

			return docUrl;
		};
		
		this.constructor.prototype.renderTestModeMessage = function() {
			// Check to see if we have already displayed this message
			var testModeDiv = this._instance.testModeDiv;
			if (testModeDiv == null) {
				var testModeDiv = document.createElement("div");
				var testMode = document.createTextNode(messages.contentviewer_test_mode);
				testModeDiv.appendChild(testMode);

				domStyle.set(testModeDiv, "text-align", "center");
				domStyle.set(testModeDiv, "vertical-align", "middle");
				var height = this.context.options.height.get("value");
				if (height != null) {
					if (!isNaN(height)) {
						height += "px";
					}
				} else {
					height = "100%";
				}
				domStyle.set(testModeDiv, "height", height);
				domStyle.set(testModeDiv, "border", "2px solid #dddddd");
				domStyle.set(testModeDiv, "padding", "30px 15px 15px 15px");
				
				domStyle.set(this._instance.iframeCnt, "display", "none");
			
				this._instance.cnt.prepend(testModeDiv);	
				this._instance.testModeDiv = testModeDiv;
			}
		};
		
		this.constructor.prototype.unload = function() {
			bpmext.ui.unloadView(this);
		};
	}
}
