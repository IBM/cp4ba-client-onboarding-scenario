/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2020. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

setAlertMessage = function(title, message, style, delay, domClass, domStyle, domAttr, messages) {

	ALRT_STL_MAP = {
		"P" : "alert-primary",
		"S" : "alert-success",
		"I" : "alert-info",
		"W" : "alert-warning",
		"E" : "alert-danger",
		"D" : "alert-danger"
	};

	var alertDiv = document.createElement("div");
	domClass.add(alertDiv, "Alerts CS_Alert CoachView dense CPP CoachView_show");

	var alertInnerDiv = document.createElement("div");
	domClass.add(alertInnerDiv, "alert-wrapper collapse in");
	domAttr.set(alertInnerDiv, "role", "alert");
	domAttr.set(alertInnerDiv, "aria-label", messages.contlist_progress_close);
	domStyle.set(alertInnerDiv, "height", "auto");
	alertDiv.appendChild(alertInnerDiv);

	var alertSuccessDiv = document.createElement("div");
	domClass.add(alertSuccessDiv, "alert " + ALRT_STL_MAP[style]);
	alertInnerDiv.appendChild(alertSuccessDiv);

	var alertButton = document.createElement("button");
	domAttr.set(alertButton, "type", "button");
	domAttr.set(alertButton, "title", messages.contlist_progress_close);
	domAttr.set(alertButton, "alt", messages.contlist_progress_close);
	domClass.add(alertButton, "ci close CS_AlertClose");
	alertSuccessDiv.appendChild(alertButton);

	var alertStrong = document.createElement("strong");
	var txt = document.createTextNode(title);
	alertStrong.appendChild(txt);
	alertSuccessDiv.appendChild(alertStrong);

	var divSpan = document.createElement("div");
	domClass.add(divSpan, "CS_AlertSpan");
	alertSuccessDiv.appendChild(divSpan);

	var alertSpan = document.createElement("span");
	var txt = document.createTextNode(message);
	alertSpan.appendChild(txt);

	divSpan.appendChild(alertSpan);
	
	var bodyDiv = document.body;
	bodyDiv.appendChild(alertDiv);
	
	var alertObj = {
		title: title, 
		text: message, 
		style: style, 
		element: alertDiv
	};
	
	var msgDelay = 4000;
	if (delay != null) {
		msgDelay = delay;
	}
	
	if (msgDelay > 0) {
		setTimeout(function() {
			console.log("CS_Alert: Alert closing automatically.");
			closeAlert(alertDiv, alertObj);
		}, msgDelay);	
	}

	alertButton.onclick = function(event) {
		console.log("CS_Alert: Alert closing on click.");
		closeAlert(alertDiv, alertObj);
		event.stopPropagation();
		return false;
	}
	
	return alertDiv;
}

closeAlert = function(alertDiv, alertObj) {
	if (!alertObj.closed) {
		alertObj.closed = true;
		console.log("CS_Alert: Alert closing for real now.");
		setTimeout(function() {
			alertDiv.style.height = 0;
			setTimeout(function() {
				document.body.removeChild(alertDiv);
			}, 350);							
		}, 50);	
	}
}

