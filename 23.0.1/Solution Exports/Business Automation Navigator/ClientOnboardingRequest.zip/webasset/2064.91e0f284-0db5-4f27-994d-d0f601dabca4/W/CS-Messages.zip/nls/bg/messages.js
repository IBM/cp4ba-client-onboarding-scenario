/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "Клас",

		// Property list
		properties_file_name: "Име на файла",
		properties_file_save_in: "Запазване в/ъв",
		properties_add_file: "Добавяне на файл",
		properties_add_mvcp: "Добавяне на ${0}",
		properties_remove_mvcp: "Премахване от ${0}",
		properties_use_file_name: "За това свойство ще се използва файловото име",

		properties_optional_label: "${0} (по избор)",

		properties_document_or_folder_not_found: "Документът или папката не могат да бъдат намерени.",
		properties_class_not_found: "Класът на съдържанието не може да бъде намерен.",
		properties_folder_duplicate_item_invalid_prop: "Вече съществува файл със същото име в тази папка, или сте въвели невалидна стойност на свойство.",
		properties_item_invalid_prop: "Въвели сте невалидна стойност за едно или повече свойства.",

		properties_invalid_long_value: "Стойността не е валидна. Стойността трябва да бъде цяло число, например 5 или 1349.",
		properties_invalid_float_value: "Стойността не е валидна. Стойността трябва да бъде число с плаваща точка, например 1.2 или 365.",
		properties_min_value: "Минимална стойност: ${0}",
		properties_max_value: "Максимална стойност: ${0}",
		properties_max_length: "Максимална дължина: ${0}",
		properties_invalid_guid: "Стойността не е валидна. Стойността трябва да е глобален уникален идентификатор (GUID), например {F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}.",
		properties_value_required: "Стойността е задължителна.",
		properties_unique_value_required: "Тази стойност трябва да бъде уникална.",
		properties_file_required: "Изисква се файл.",
		properties_invalid_folder_name: "Името на папката не може да съдържа следните символи: \\ / : * ? \" < > |",

		properties_move_edit_confirm_msg: "Променяте свойствата на следния документ<br>${0}<br><br>Желаете ли да запазите промените си?",
		properties_move_edit_confirm_no: "Не",
		properties_move_edit_confirm_yes: "Да",
		properties_move_edit_confirm_title: "Потвърждение",
		properties_edit_save_success: "Свойствата са запазени",
		properties_edit_save_failure: "Свойствата не са запазени",
		properties_no_item_selected: "Няма избран елемент.",

		// Content list
		contlist_column_spec_title: "Заглавие",
		contlist_column_spec_name: "Име",
		contlist_column_spec_version_label: "Версия",
		contlist_column_spec_modified_by: "Променен по",
		contlist_column_spec_mod_date: "Последна промяна",
		contlist_column_spec_created_by: "Създадено от",
		contlist_column_spec_creation_date: "Създадено",
		contlist_column_spec_mime_type: "Тип документ",
		contlist_column_spec_size: "Размер",
		contlist_column_spec_thumbnail: "Миниатюра",

		contlist_paging_no_more_items: "Няма повече елементи",
		contlist_paging_of_at_least_items: "${0} от поне ${1} елемента",
		contlist_paging_of_items: "${0} от ${1} елемента",
		contlist_paging_items: "Елементи ${0}",
		contlist_paging_items_per_page: "Елемента на страница: ${0}",

		contlist_checked_out: "Изписано",
		contlist_checked_out_by: "Изписано от ${0}",

		contlist_size_units_B: "B",
		contlist_size_units_KB: "КБ",
		contlist_size_units_MB: "MB",
		contlist_size_units_GB: "GB",
		contlist_size_units_TB: "TB",

		contlist_missing_server_error: "Не е указан сървър.",
		contlist_invalid_server_error: "Сървърът '{0}' не съществува.",
		contlist_error_retrieving_doc_props: "Грешка при извличането на свойства на документа.",
		contlist_error_retrieving_folder_props: "Грешка при извличането на свойства на папката.",
		contlist_checkout_failed: "Документът не може да бъде изписан",
		contlist_cancel_checkout_failed: "Неуспешна отмяна на изписването",
		contlist_rename_folder_failed: "Папката не може да бъде преименувана.",
		contlist_folder_name_not_unique: "Името на папката трябва да бъде уникално.",
		contlist_delete_object_failed: "Обектът не може да бъде изтрит.",
		contlist_display_properties_failed: "Свойствата не могат да бъдат показани. ${0}",
		contlist_save_props_failed: "Свойствата не могат да бъдат запазени.",
		contlist_upload_failed: "Версията не може да бъде качена",
		contlist_add_folder_failed: "Папката не може да бъде добавена. ${0}",
		contlist_add_document_failed: "Документът не може да бъде добавен. ${0}",
		contlist_search_failed: "Резултатите от търсенето не могат да бъдат извлечени",
		contlist_folder_containees_failed: "Съдържанието на папката не може да бъде извлечено",
		contlist_delete_folder_referenced: "Папката не може да бъде изтрита, защото съдържа подпапки.",
		contlist_docs_not_added: "Следните документи не могат да бъдат добавени: ${0}",

		contlist_checkout_success: "Документът е изписан",
		contlist_delete_success: "Обектът е изтрит",
		contlist_rename_folder_success: "Папката е преименувана",
		contlist_save_props_success: "Свойствата са запазени",
		contlist_cancel_checkout_success: "Успешна отмяна на изписването",
		contlist_upload_version_success: "Версията беше качена",
		contlist_add_folder_success: "Папката беше добавена",
		contlist_add_doc_success: "Документът беше добавен",
		contlist_add_docs_success: "Документите бяха добавени",

		contlist_menu_action_open: "Отворен",
		contlist_menu_action_rename: "Преименуване",
		contlist_menu_action_properties: "Свойства",
		contlist_menu_action_view: "Изглед",
		contlist_menu_action_download: "Изтегляне",
		contlist_menu_action_checkout: "Изписване",
		contlist_menu_action_edit_document: "Редактиране на документ",
		contlist_menu_action_cancel_checkout: "Отказ за изписване",
		contlist_menu_action_delete_doc: "Изтриване на документ",
		contlist_menu_action_rename_folder: "Преименуване на папка",
		contlist_menu_action_add_folder: "Добавяне на папка",
		contlist_menu_action_delete_folder: "Изтриване на папка",
		contlist_menu_action_add_doc: "Добавяне на документ",
		contlist_menu_action_upload: "Качване на нова версия",

		contlist_document_properties: "Свойства на документ",
		contlist_folder_properties: "Свойства на папка",
		contlist_folder_name: "Име на папка",

		contlist_cancel_btn_label: "Отказ",
		contlist_add_btn_label: "Добавяне",
		contlist_ok_btn_label: "ОК",
		contlist_edit_btn_label: "Редактиране",
		contlist_save_btn_label: "Запазване",
		contlist_upload_btn_label: "Качване",
		contlist_refresh_btn_label: "Обновяване",
		contlist_next_btn_label: "Напред",
		contlist_previous_btn_label: "Назад",

		contlist_delete_folder_confirm: "На път сте да изтриете папката ${0}. Желаете ли да продължите?",
		contlist_delete_doc_confirm: "На път сте да изтриете документа ${0}. Желаете ли да продължите?",

		contlist_no_mimetype: "Този елемент не съдържа съдържание.",
		contlist_folder_mimetype: "Папка",

		contlist_filter_search_hint: "Търсене на документи",
		contlist_filter_folder_hint: "Списък с филтри",

		contlist_root_folder: "Root папка",
		contlist_drop_folder_error: "Не можете да добавяте папки. Изберете само файлове.",
		contlist_add_in_process: "Моля, изчакайте, докато добавянето на предишния документ завърши, преди да добавите още един.",
		contlist_add_doc_max_exceeded: "Можете да добавяте до ${0} елемента едновременно. Опитвате се да добавите ${1} елемента.",
		contlist_progress_success: "Успешно",
		contlist_progress_alert: "Аларма",
		contlist_progress_error: "Грешка",
		contlist_progress_uploading: "Качване",
		contlist_progress_processing: "Обработване на 1 файл",
		contlist_progress_uploading_text: "Качване на 1 файл",
		contlist_progress_upload_failed: "Възникна проблем",
		contlist_progress_close: "Затваряне",
		progress_ind_uploaded_status: "Качено",
		progress_ind_uploaded: "Качен е 1 файл",
		progress_ind_uploaded_error: "Обработката не е стартирала",		
		progress_ind_processing_status: "Обработка",
		progress_ind_processing_err: "Възникна проблем",
		progress_ind_processed: "Обработен е 1 файл",	
		progress_ind_failed: "Неуспешен",
		progress_ind_review_doc: "Преглед на задължителните",	
		progress_ind_updating: "Обновяване на 1 файл",
		progress_ind_updating_status: "Обновяване",
		progress_ind_update_err: "Възникна проблем",
		progress_ind_timeout: "Времето за проследяване изтече",
		progress_ind_refresh: "Обновяване",

		getcontent_ret_versions_error: "Извличането на серии на версията е неуспешно",
		getcontent_ret_properties_error: "Извличането на свойства на документа е неуспешно",

		contentviewer_test_mode: "Средството за преглед няма да покаже документите в режим за преглед. Трябва да работите в приложение на работна площ IBM Navigator.",

		thumbnail_retreival_error: "Извличането на миниатюрно изображение е неуспешно.",

		status_10: "Качено",
		status_20: "Обработка",
		status_25: "Предварителна обработка",
		status_30: "Преглед на задължителните",
		status_40: "Обновяване",
		status_900: "Грешка в обработката",
		status_910: "Грешка в обновяването",

		/*do not remove this line*/nop: null
});
