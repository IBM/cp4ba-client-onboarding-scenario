/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "Klasa",

		// Property list
		properties_file_name: "Naziv datoteke",
		properties_file_save_in: "Spremi u",
		properties_add_file: "Dodaj datoteku",
		properties_add_mvcp: "Dodaj ${0}",
		properties_remove_mvcp: "Ukloni iz ${0}",
		properties_use_file_name: "Naziv datoteke koristit će se za ovo svojstvo",

		properties_optional_label: "${0} (opcijski)",

		properties_document_or_folder_not_found: "Dokument ili folder se ne može pronaći.",
		properties_class_not_found: "Klasa sadržaja se ne može pronaći.",
		properties_folder_duplicate_item_invalid_prop: "Stavka s istim nazivom već postoji u folderu ili ste unijeli nevažeću vrijednost svojstva.",
		properties_item_invalid_prop: "Unijeli ste nevažeću vrijednost za jedno ili više svojstava.",

		properties_invalid_long_value: "Ova vrijednost nije važeća. Vrijednost mora biti cijeli broj, na primjer, 5 ili 1349.",
		properties_invalid_float_value: "Vrijednost nije važeća. Vrijednost mora biti broj s pomičnim zarezom, na primjer 1.2 ili 365.",
		properties_min_value: "Minimalna vrijednost: ${0}",
		properties_max_value: "Maksimalna vrijednost: ${0}",
		properties_max_length: "Maksimalna dužina: ${0}",
		properties_invalid_guid: "Vrijednost nije važeća. Vrijednost mora biti globalni jednoznačni identifikator (GUID), na primjer, {F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}.",
		properties_value_required: "Ova vrijednost je potrebna.",
		properties_unique_value_required: "Ova vrijednost mora biti jedinstvena.",
		properties_file_required: "Potrebna je datoteka.",
		properties_invalid_folder_name: "Naziv foldera ne smije sadržavati bilo koji od sljedećih znakova: \\ / : * ? \" < > |",

		properties_move_edit_confirm_msg: "Mijenjali ste svojstva sljedećeg dokumenta<br>${0}<br><br>Želite li spremiti promjene?",
		properties_move_edit_confirm_no: "Ne",
		properties_move_edit_confirm_yes: "Da",
		properties_move_edit_confirm_title: "Potvrda",
		properties_edit_save_success: "Svojstva spremljena",
		properties_edit_save_failure: "Svojstva nisu spremljena",
		properties_no_item_selected: "Nema izabrane stavke.",

		// Content list
		contlist_column_spec_title: "Naziv",
		contlist_column_spec_name: "Naziv",
		contlist_column_spec_version_label: "Verzija",
		contlist_column_spec_modified_by: "Promijenio",
		contlist_column_spec_mod_date: "Zadnja promjena",
		contlist_column_spec_created_by: "Kreirao",
		contlist_column_spec_creation_date: "Kreirano",
		contlist_column_spec_mime_type: "Tip dokumenta",
		contlist_column_spec_size: "Veličina",
		contlist_column_spec_thumbnail: "Sličica",

		contlist_paging_no_more_items: "Nema više stavki",
		contlist_paging_of_at_least_items: "${0} od najmanje ${1} stavki",
		contlist_paging_of_items: "${0} od ${1} stavki",
		contlist_paging_items: "Stavke ${0}",
		contlist_paging_items_per_page: "Stavki po stranici: ${0}",

		contlist_checked_out: "Odjavljeno",
		contlist_checked_out_by: "Odjavio ${0}",

		contlist_size_units_B: "B",
		contlist_size_units_KB: "kB",
		contlist_size_units_MB: "MB",
		contlist_size_units_GB: "HR",
		contlist_size_units_TB: "TB",

		contlist_missing_server_error: "Poslužitelj nije naveden.",
		contlist_invalid_server_error: "Poslužitelj '{0}' ne postoji.",
		contlist_error_retrieving_doc_props: "Greška kod dohvaćanja svojstava dokumenta.",
		contlist_error_retrieving_folder_props: "Greška kod dohvaćanja svojstava foldera",
		contlist_checkout_failed: "Dokument se nije mogao odjaviti",
		contlist_cancel_checkout_failed: "Opoziv odjave nije uspio",
		contlist_rename_folder_failed: "Ne može se preimenovati folder.",
		contlist_folder_name_not_unique: "Naziv foldera mora biti jedinstven.",
		contlist_delete_object_failed: "Objekt se nije mogao izbrisati.",
		contlist_display_properties_failed: "Svojstva se nisu mogla prikazati. ${0}",
		contlist_save_props_failed: "Svojstva se nisu mogla spremiti",
		contlist_upload_failed: "Verzija se nije mogla učitati",
		contlist_add_folder_failed: "Folder se nije mogao dodati. ${0}",
		contlist_add_document_failed: "Dokument se nije mogao dodati. ${0}",
		contlist_search_failed: "Rezultati pretraživanja se nisu mogli dohvatiti.",
		contlist_folder_containees_failed: "Sadržaj foldera se nije mogao dohvatiti",
		contlist_delete_folder_referenced: "Folder se ne može izbrisati jer sadrži podfoldere.",
		contlist_docs_not_added: "Sljedeći dokumenti ne mogu biti dodani: ${0}",

		contlist_checkout_success: "Dokument je odjavljen",
		contlist_delete_success: "Objekt je izbrisan",
		contlist_rename_folder_success: "Folder je preimenovan.",
		contlist_save_props_success: "Svojstva su spremljena",
		contlist_cancel_checkout_success: "Uspješan opoziv odjave",
		contlist_upload_version_success: "Verzija je predana",
		contlist_add_folder_success: "Folder je dodan",
		contlist_add_doc_success: "Dokument je dodan",
		contlist_add_docs_success: "Dokumenti su bili dodani",

		contlist_menu_action_open: "Otvori",
		contlist_menu_action_rename: "Preimenuj",
		contlist_menu_action_properties: "Svojstva",
		contlist_menu_action_view: "Pogled",
		contlist_menu_action_download: "Preuzmi",
		contlist_menu_action_checkout: "Odjavi",
		contlist_menu_action_edit_document: "Uredi dokument",
		contlist_menu_action_cancel_checkout: "Opozivi odjavu",
		contlist_menu_action_delete_doc: "Briši dokument",
		contlist_menu_action_rename_folder: "Preimenuj folder",
		contlist_menu_action_add_folder: "Dodaj folder",
		contlist_menu_action_delete_folder: "Briši folder",
		contlist_menu_action_add_doc: "Dodaj dokument",
		contlist_menu_action_upload: "Predaj novu verziju",

		contlist_document_properties: "Svojstva dokumenta",
		contlist_folder_properties: "Svojstva foldera",
		contlist_folder_name: "Naziv foldera",

		contlist_cancel_btn_label: "Opoziv",
		contlist_add_btn_label: "Dodaj",
		contlist_ok_btn_label: "Ok",
		contlist_edit_btn_label: "Uredi",
		contlist_save_btn_label: "Spremi",
		contlist_upload_btn_label: "Predaj",
		contlist_refresh_btn_label: "Osvježi",
		contlist_next_btn_label: "Sljedeće",
		contlist_previous_btn_label: "Prethodno",

		contlist_delete_folder_confirm: "Izbrisat ćete folder ${0}. Želite li nastaviti?",
		contlist_delete_doc_confirm: "Izbrisat ćete dokument ${0}. Želite li nastaviti?",

		contlist_no_mimetype: "Ova stavka nema sadržaja.",
		contlist_folder_mimetype: "Folder",

		contlist_filter_search_hint: "Pretraži dokumente",
		contlist_filter_folder_hint: "Lista filtera",

		contlist_root_folder: "Osnovni folder",
		contlist_drop_folder_error: "Ne možete dodati foldere. Izaberite samo datoteke.",
		contlist_add_in_process: "Molimo pričekajte dok dodavanje prethodnog dokumenta završi prije dodavanja drugoga.",
		contlist_add_doc_max_exceeded: "Možete dodati do ${0} stavki od jednom. Pokušavate dodati ${1} stavki.",
		contlist_progress_success: "Uspjeh",
		contlist_progress_alert: "Upozorenje",
		contlist_progress_error: "Greška",
		contlist_progress_uploading: "Predaja",
		contlist_progress_processing: "Obrada 1 datoteke",
		contlist_progress_uploading_text: "Predaja 1 datoteke",
		contlist_progress_upload_failed: "Došlo je do problema",
		contlist_progress_close: "Zatvori",
		progress_ind_uploaded_status: "Predano",
		progress_ind_uploaded: "Predana 1 datoteka",
		progress_ind_uploaded_error: "obrada nije započela",		
		progress_ind_processing_status: "Obrada",
		progress_ind_processing_err: "Došlo je do problema",
		progress_ind_processed: "Obrađena 1 datoteka",	
		progress_ind_failed: "Neuspješno",
		progress_ind_review_doc: "Potreban je ponovni pregled",	
		progress_ind_updating: "Ažuriranje 1 datoteke",
		progress_ind_updating_status: "Ažuriranje",
		progress_ind_update_err: "Došlo je do problema",
		progress_ind_timeout: "Timeout nadgledanja",
		progress_ind_refresh: "Osvježi",

		getcontent_ret_versions_error: "Dohvaćanje serije verzija nije uspjelo",
		getcontent_ret_properties_error: "Dohvaćanje svojstava dokumenta nije uspjelo",

		contentviewer_test_mode: "Preglednik neće prikazati dokumente u načinu pregleda. Morate izvoditi u IBM Navigator desktop aplikaciji.",

		thumbnail_retreival_error: "Dohvaćanje sličice nije uspjelo.",

		status_10: "Predano",
		status_20: "Obrada",
		status_25: "Ponovna obrada",
		status_30: "Potreban je ponovni pregled",
		status_40: "Ažuriranje",
		status_900: "Greška obrade",
		status_910: "Greška ažuriranja",

		/*do not remove this line*/nop: null
});
