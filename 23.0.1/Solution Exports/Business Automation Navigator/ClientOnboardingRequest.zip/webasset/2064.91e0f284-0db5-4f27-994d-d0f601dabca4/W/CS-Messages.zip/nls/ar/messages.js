// NLS_MESSAGEFORMAT_NONE
// NLS_ENCODING=UNICODE
/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "الفئة",

		// Property list
		properties_file_name: "اسم الملف",
		properties_add_file: "اضافة ملف ",

		properties_optional_label: "${0} (اختياري)",

		properties_document_or_folder_not_found: "لا يمكن ايجاد الوثيقة أو الحافظة. ",
		properties_class_not_found: "لا يمكن ايجاد فئة المحتويات. ",
		properties_folder_duplicate_item_invalid_prop: "يوجد بند بنفس الاسم بالفعل في الحافظة، أو قمت بادخال قيمة خاصية غير صحيحة.  ",
		properties_item_invalid_prop: "قمت بادخال قيمة غير صحيحة لخاصية واحدة أو أكثر. ",

		properties_invalid_long_value: "هذه القيمة غير صحيحة. يجب أن تكون القيمة رقم صحيح، على سبيل المثال 5 أو 1349.  ",
		properties_invalid_float_value: "القيمة غير صحيحة. يجب أن تكون القيمة رقم ذو نقطة عائمة، على سبيل المثال 1.2 أو 365.",
		properties_min_value: "الحد الأدنى للقيمة: ${0}",
		properties_max_value: "الحد الأقصى للقيمة: ${0}",
		properties_max_length: "الحد الأقصى للطول: ${0}",
		properties_invalid_guid: "القيمة غير صحيحة. يجب أن تكون القيمة هي ‏‎Globally Unique Identifier ‎(GUID)‎‏، على سبيل المثال، {F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}.",
		properties_value_required: "يجب ادخال هذه القيمة.",
		properties_unique_value_required: "يجب أن تكون هذه القيمة متفردة.  ",
		properties_file_required: "يجب تحديد ملف.",
		properties_invalid_folder_name: "لا يمكن أن يتضمن اسم الحافظة أي من الحروف   التالية:  \\ /  : * ? \" < > |",

		properties_move_edit_confirm_msg: "أنت تقوم بتغيير خصائص الوثيقة التالية <br>${0}<br><br>هل تريد حفظ التغييرات؟",
		properties_move_edit_confirm_no: "لا",
		properties_move_edit_confirm_yes: "نعم",
		properties_move_edit_confirm_title: "تأكيد",
		properties_edit_save_success: "تم حفظ الخصائص ",
		properties_edit_save_failure: "لم يتم حفظ الخصائص ",

		// Content list
		contlist_column_spec_title: "العنوان",
		contlist_column_spec_name: "الاسم",
		contlist_column_spec_version_label: "‏النسخة‏",
		contlist_column_spec_modified_by: "تعديل بواسطة",
		contlist_column_spec_mod_date: "آخر تعديل ",
		contlist_column_spec_created_by: "تم التكوين بواسطة",
		contlist_column_spec_creation_date: "تم التكوين ",
		contlist_column_spec_mime_type: "نوع الوثيقة ",
		contlist_column_spec_size: "الحجم",
		contlist_column_spec_thumbnail: "صورة مصغرة ",

		contlist_paging_no_more_items: "لا يوجد مزيد من البنود ",
		contlist_paging_of_at_least_items: "${0} من ${1} بند على الأقل  ",
		contlist_paging_of_items: "${0} من ${1} بند ",
		contlist_paging_items: "البنود ${0}",
		contlist_paging_items_per_page: "البنود بكل صفحة: ${0}  ",

		contlist_checked_out: "تخصيص للتغيير",
		contlist_checked_out_by: "تم التخصيص بواسطة ${0}",

		contlist_size_units_B: "B",
		contlist_size_units_KB: "كيلوبايت",
		contlist_size_units_MB: "MB",
		contlist_size_units_GB: "جيجابايت",
		contlist_size_units_TB: "تيرابايت",

		contlist_missing_server_error: "لم يتم تحديد وحدة خدمة.  ",
		contlist_invalid_server_error: "وحدة الخدمة '{0}' غير موجودة.  ",
		contlist_error_retrieving_doc_props: "حدث خطأ أثناء استرجاع خصائص الوثيقة.  ",
		contlist_checkout_failed: "لا يمكن تخصيص الوثيقة  ",
		contlist_cancel_checkout_failed: "فشل الغاء التخصيص ",
		contlist_rename_folder_failed: "لا يمكن اعادة تسمية الحافظة.  ",
		contlist_folder_name_not_unique: "يجب أن يكون اسم الحافظة متفردا.  ",
		contlist_delete_object_failed: "لا يمكن حذف العنصر. ",
		contlist_display_properties_failed: "لا يمكن عرض الخصائص.  ${0}",
		contlist_save_props_failed: "لا يمكن حفظ الخصائص ",
		contlist_upload_failed: "لا يمكن تحميل النسخة  ",
		contlist_add_folder_failed: "لا يمكن اضافة الحافظة. ${0}",
		contlist_add_document_failed: "لا يمكن اضافة الوثيقة. ${0}",
		contlist_search_failed: "لا يمكن استرجاع نتائج البحث  ",
		contlist_folder_containees_failed: "لا يمكن استرجاع محتويات الحافظة ",
		contlist_delete_folder_referenced: "لا يمكن حذف الحافظة لأنها تحتوي على حافظات فرعية. ",

		contlist_checkout_success: "تم تخصيص الوثيقة ",
		contlist_delete_success: "تم حذف العنصر ",
		contlist_rename_folder_success: "تم اعادة تسمية الحافظة ",
		contlist_save_props_success: "تم حفظ الخصائص ",
		contlist_cancel_checkout_success: "تم الغاء التخصيص بنجاح ",
		contlist_upload_version_success: "تم تحميل النسخة ",
		contlist_add_folder_success: "تم اضافة الحافظة ",
		contlist_add_doc_success: "تم اضافة الوثيقة ",

		contlist_menu_action_open: "فتح",
		contlist_menu_action_rename: "اعادة تسمية",
		contlist_menu_action_properties: "الخصائص",
		contlist_menu_action_view: "‏مشاهدة‏",
		contlist_menu_action_download: "‏تحميل من‏",
		contlist_menu_action_checkout: "تخصيص",
		contlist_menu_action_edit_document: "تحرير وثيقة",
		contlist_menu_action_cancel_checkout: "الغاء التخصيص ",
		contlist_menu_action_delete_doc: "حذف وثيقة",
		contlist_menu_action_rename_folder: "اعادة تسمية حافظة ",
		contlist_menu_action_add_folder: "اضافة حافظة",
		contlist_menu_action_delete_folder: "حذف حافظة",
		contlist_menu_action_add_doc: "اضافة وثيقة",
		contlist_menu_action_upload: "تحميل نسخة جديدة ",

		contlist_document_properties: "خصائص الوثيقة ",
		contlist_folder_properties: "خصائص الحافظة ",
		contlist_folder_name: "اسم الحافظة",

		contlist_cancel_btn_label: "الغاء",
		contlist_add_btn_label: "اضافة",
		contlist_ok_btn_label: "حسنا",
		contlist_edit_btn_label: "تحرير",
		contlist_save_btn_label: "حفظ",
		contlist_upload_btn_label: "تحميل",
		contlist_refresh_btn_label: "تجديد",
		contlist_next_btn_label: "تالي",
		contlist_previous_btn_label: "‏سابق‏",

		contlist_delete_folder_confirm: "أنت على وشك حذف الحافظة ${0}. هل تريد الاستمرار؟",
		contlist_delete_doc_confirm: "أنت على وشك حذف الوثيقة ${0}. هل تريد الاستمرار؟",

		contlist_no_mimetype: "لا يتضمن هذا البند محتويات.",
		contlist_folder_mimetype: "‏حافظة‏",

		contlist_filter_search_hint: "وثائق البحث ",
		contlist_filter_folder_hint: "ترشيح نتائج الكشف الذي يتم عرضه ",

		contlist_root_folder: "الحافظة الرئيسية ",

		contentviewer_test_mode: "لن يقوم برنامج المشاهدة بعرض وثائق في نمط الاختبار. يجب أن تقوم بتشغيل تطبيق سطح المكتب IBM Navigator.  ",

		/*do not remove this line*/nop: null
});
