/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "Sınıf",

		// Property list
		properties_file_name: "Dosya adı",
		properties_file_save_in: "Şuraya kaydet",
		properties_add_file: "Dosya ekle",
		properties_add_mvcp: "${0} ekle",
		properties_remove_mvcp: "${0} içinden kaldır",
		properties_use_file_name: "Dosya adı bu özellik için kullanılır",

		properties_optional_label: "${0} (isteğe bağlı)",

		properties_document_or_folder_not_found: "Belge veya klasör bulunamıyor.",
		properties_class_not_found: "İçerik sınıfı bulunamıyor.",
		properties_folder_duplicate_item_invalid_prop: "Klasörde aynı adlı bir öğe zaten var ya da geçersiz bir özellik değeri girdiniz.",
		properties_item_invalid_prop: "Bir veya daha çok özellik için geçersiz bir değer girdiniz.",

		properties_invalid_long_value: "Bu değer geçerli değil. Değerin bir tamsayı olması gerekir; örneğin, 5 ya da 1349.",
		properties_invalid_float_value: "Değer geçersiz. Değerin bir kayar noktalı sayı olması gerekir; örneğin, 1.2 ya da 365.",
		properties_min_value: "Değer alt sınırı: ${0}",
		properties_max_value: "Değer üst sınırı: ${0}",
		properties_max_length: "Uzunluk üst sınırı: ${0}",
		properties_invalid_guid: "Değer geçersiz. Değerin bir Genel Benzersiz Tanıtıcı (Globally Unique Identifier; GUID) olması gerekir; örneğin, {F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}.",
		properties_value_required: "Bu değer zorunludur.",
		properties_unique_value_required: "Bu değer benzersiz olmalıdır.",
		properties_file_required: "Bir dosya gereklidir.",
		properties_invalid_folder_name: "Klasör adı şu karakterlerin hiçbirini içeremez: \\ / : * ? \" < > |",

		properties_move_edit_confirm_msg: "Aşağıdaki belgenin özelliklerini değiştiriyorsunuz<br>${0}<br><br>Değişikliklerinizi kaydetmek istiyor musunuz?",
		properties_move_edit_confirm_no: "Hayır",
		properties_move_edit_confirm_yes: "Evet",
		properties_move_edit_confirm_title: "Doğrulama",
		properties_edit_save_success: "Özellikler kaydedildi",
		properties_edit_save_failure: "Özellikler kaydedilmedi",
		properties_no_item_selected: "Hiçbir öğe seçilmedi.",

		// Content list
		contlist_column_spec_title: "Başlık",
		contlist_column_spec_name: "Ad",
		contlist_column_spec_version_label: "Sürüm",
		contlist_column_spec_modified_by: "Değiştiren",
		contlist_column_spec_mod_date: "Son değiştirme tarihi",
		contlist_column_spec_created_by: "Yaratan",
		contlist_column_spec_creation_date: "Yaratılma tarihi",
		contlist_column_spec_mime_type: "Belge tipi",
		contlist_column_spec_size: "Büyüklük",
		contlist_column_spec_thumbnail: "Küçük resim",

		contlist_paging_no_more_items: "Başka öğe yok",
		contlist_paging_of_at_least_items: "En az ${1} öğeden ${0} tanesi",
		contlist_paging_of_items: "${0} / ${1} öğe",
		contlist_paging_items: "Öğeler ${0}",
		contlist_paging_items_per_page: "Sayfa başına öğe: ${0}",

		contlist_checked_out: "Dışarı alan",
		contlist_checked_out_by: "${0} tarafından dışarı alındı",

		contlist_size_units_B: "B",
		contlist_size_units_KB: "KB",
		contlist_size_units_MB: "MB",
		contlist_size_units_GB: "GB",
		contlist_size_units_TB: "TB",

		contlist_missing_server_error: "Sunucu belirtilmedi.",
		contlist_invalid_server_error: "'{0}' sunucusu yok.",
		contlist_error_retrieving_doc_props: "Belge özellikleri alınırken hata oluştu.",
		contlist_error_retrieving_folder_props: "Klasör özellikleri alınırken hata oluştu.",
		contlist_checkout_failed: "Belge dışarı alınamadı",
		contlist_cancel_checkout_failed: "Dışarı alma işlemi iptal edilemedi",
		contlist_rename_folder_failed: "Klasör yeniden adlandırılamadı.",
		contlist_folder_name_not_unique: "Klasör adı benzersiz olmalıdır.",
		contlist_delete_object_failed: "Nesne silinemedi.",
		contlist_display_properties_failed: "Özellikler görüntülenemedi. ${0}",
		contlist_save_props_failed: "Özellikler kaydedilemedi",
		contlist_upload_failed: "Sürüm karşıya yüklenemedi",
		contlist_add_folder_failed: "Klasör eklenemedi. ${0}",
		contlist_add_document_failed: "Belge eklenemedi. ${0}",
		contlist_search_failed: "Arama sonuçları alınamadı",
		contlist_folder_containees_failed: "Klasör içeriği alınamadı",
		contlist_delete_folder_referenced: "Alt klasörler içerdiğinden klasör silinemiyor",
		contlist_docs_not_added: "Şu belgeler eklenemedi: ${0}",

		contlist_checkout_success: "Belge dışarı alındı",
		contlist_delete_success: "Nesne silindi",
		contlist_rename_folder_success: "Klasör yeniden adlandırıldı",
		contlist_save_props_success: "Özellikler kaydedildi",
		contlist_cancel_checkout_success: "Dışarı alma işlemi başarılı oldu",
		contlist_upload_version_success: "Sürüm karşıya yüklendi",
		contlist_add_folder_success: "Klasör eklendi",
		contlist_add_doc_success: "Belge eklendi",
		contlist_add_docs_success: "Belgeler eklendi",

		contlist_menu_action_open: "Aç",
		contlist_menu_action_rename: "Yeniden Adlandır",
		contlist_menu_action_properties: "Özellikler",
		contlist_menu_action_view: "Görüntüleme",
		contlist_menu_action_download: "Karşıdan Yükleme",
		contlist_menu_action_checkout: "Dışarı al",
		contlist_menu_action_edit_document: "Belgeyi düzenleme",
		contlist_menu_action_cancel_checkout: "Dışarı almayı iptal et",
		contlist_menu_action_delete_doc: "Belge sil",
		contlist_menu_action_rename_folder: "Klasörü yeniden adlandır",
		contlist_menu_action_add_folder: "Klasör ekle",
		contlist_menu_action_delete_folder: "Klasör silme",
		contlist_menu_action_add_doc: "Belge ekleme",
		contlist_menu_action_upload: "Yeni sürümü karşıya yükle",

		contlist_document_properties: "Belge özellikleri",
		contlist_folder_properties: "Klasör özellikleri",
		contlist_folder_name: "Klasör adı",

		contlist_cancel_btn_label: "İptal",
		contlist_add_btn_label: "Ekle",
		contlist_ok_btn_label: "Tamam",
		contlist_edit_btn_label: "Düzenle",
		contlist_save_btn_label: "Kaydet",
		contlist_upload_btn_label: "Karşıya Yükle",
		contlist_refresh_btn_label: "Yenile",
		contlist_next_btn_label: "Sonraki",
		contlist_previous_btn_label: "Önceki",

		contlist_delete_folder_confirm: "${0} klasörünü silmek üzeresiniz. Devam etmek istiyor musunuz?",
		contlist_delete_doc_confirm: "${0} belgesini silmek üzeresiniz. Devam etmek istiyor musunuz?",

		contlist_no_mimetype: "Bu öğenin içeriği yok.",
		contlist_folder_mimetype: "Klasör",

		contlist_filter_search_hint: "Belgelerde ara",
		contlist_filter_folder_hint: "Listeyi süz",

		contlist_root_folder: "Kök klasör",
		contlist_drop_folder_error: "Klasör ekleyemezsiniz. Yalnızca dosya seçin.",
		contlist_add_in_process: "Başka bir belge eklenmeden önce, lütfen önceki belgenin eklenmesi tamamlanıncaya kadar bekleyin.",
		contlist_add_doc_max_exceeded: "Bir kerede en çok ${0} öğe ekleyebilirsiniz. ${1} öğe eklemeye çalışıyorsunuz.",
		contlist_progress_success: "Başarılı",
		contlist_progress_alert: "Uyarı",
		contlist_progress_error: "Hata",
		contlist_progress_uploading: "Karşıya yükleniyor",
		contlist_progress_processing: "1 dosya işleniyor",
		contlist_progress_uploading_text: "1 dosya karşıya yükleniyor",
		contlist_progress_upload_failed: "Sorun oluştu",
		contlist_progress_close: "Kapat",
		progress_ind_uploaded_status: "Karşıya yüklendi",
		progress_ind_uploaded: "1 dosya karşıya yüklendi",
		progress_ind_uploaded_error: "İşleme başlamadı",		
		progress_ind_processing_status: "İşleniyor",
		progress_ind_processing_err: "Sorun oluştu",
		progress_ind_processed: "1 dosya işlendi",	
		progress_ind_failed: "Başarısız",
		progress_ind_review_doc: "Gözden geçirme gerekli",	
		progress_ind_updating: "1 dosya güncelleniyor",
		progress_ind_updating_status: "Güncelleniyor",
		progress_ind_update_err: "Sorun oluştu",
		progress_ind_timeout: "İzleme zaman aşımına uğradı",
		progress_ind_refresh: "Yenile",

		getcontent_ret_versions_error: "Sürüm dizisinin alınması başarısız oldu",
		getcontent_ret_properties_error: "Belge özelliklerinin alınması başarısız oldu",

		contentviewer_test_mode: "Görüntüleyici, belgeleri önizleme modunda görüntülemez. Bir IBM Navigator masaüstü uygulamasında çalıştırmanız gerekir.",

		thumbnail_retreival_error: "Küçük resim görüntüsünün alınması başarısız oldu.",

		status_10: "Karşıya yüklendi",
		status_20: "İşleniyor",
		status_25: "Yeniden işleniyor",
		status_30: "Gözden geçirme gerekli",
		status_40: "Güncelleniyor",
		status_900: "İşleme hatası",
		status_910: "Hata güncelleniyor",

		/*do not remove this line*/nop: null
});
