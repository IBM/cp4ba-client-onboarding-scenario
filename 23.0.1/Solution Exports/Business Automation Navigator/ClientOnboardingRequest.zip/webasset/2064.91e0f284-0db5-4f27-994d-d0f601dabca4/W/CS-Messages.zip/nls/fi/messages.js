/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "Luokka",

		// Property list
		properties_file_name: "Tiedoston nimi",
		properties_file_save_in: "Tallenna kohteeseen",
		properties_add_file: "Lisää tiedosto",
		properties_add_mvcp: "Lisää ${0}",
		properties_remove_mvcp: "Poista kohteesta ${0}",
		properties_use_file_name: "Tiedoston nimeä käytetään tässä ominaisuudessa",

		properties_optional_label: "${0} (valinnainen)",

		properties_document_or_folder_not_found: "Pyydettyä dokumenttia tai kansiota ei löydy.",
		properties_class_not_found: "Sisältöluokkaa ei löydy.",
		properties_folder_duplicate_item_invalid_prop: "Kansiossa on jo samanniminen objekti tai olet antanut virheellisen ominaisuuden arvon.",
		properties_item_invalid_prop: "Olet antanut virheellisen arvon yhdelle tai useammalle ominaisuudelle.",

		properties_invalid_long_value: "Arvo ei kelpaa. Arvon on oltava kokonaisluku. Esimerkki: 5 tai 1349.",
		properties_invalid_float_value: "Arvo ei kelpaa. Arvon on oltava liukuluku. Esimerkki: 1,2 tai 365.",
		properties_min_value: "Vähimmäisarvo: ${0}",
		properties_max_value: "Enimmäisarvo: ${0}",
		properties_max_length: "Enimmäispituus: ${0}",
		properties_invalid_guid: "Arvo ei kelpaa. Arvon on oltava GUID-tunnus. Esimerkki: {F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}.",
		properties_value_required: "Arvo on pakollinen.",
		properties_unique_value_required: "Arvon on oltava yksilöllinen.",
		properties_file_required: "Tiedosto on pakollinen.",
		properties_invalid_folder_name: "Kansion nimi ei saa sisältää seuraavia merkkejä: \\ / : * ? \" < > |",

		properties_move_edit_confirm_msg: "Olet muuttamassa seuraavan dokumentin ominaisuuksia<br>${0}<br><br>Tallennetaanko muutokset?",
		properties_move_edit_confirm_no: "Ei",
		properties_move_edit_confirm_yes: "Kyllä",
		properties_move_edit_confirm_title: "Vahvistus",
		properties_edit_save_success: "Ominaisuudet tallennettiin",
		properties_edit_save_failure: "Ominaisuuksia ei tallennettu",
		properties_no_item_selected: "Objektia ei ole valittu.",

		// Content list
		contlist_column_spec_title: "Otsikko",
		contlist_column_spec_name: "Nimi",
		contlist_column_spec_version_label: "Versio",
		contlist_column_spec_modified_by: "Muokkaaja",
		contlist_column_spec_mod_date: "Muokattu viimeksi",
		contlist_column_spec_created_by: "Tekijä",
		contlist_column_spec_creation_date: "Luotu",
		contlist_column_spec_mime_type: "Dokumentin laji",
		contlist_column_spec_size: "Koko",
		contlist_column_spec_thumbnail: "Pienoiskuva",

		contlist_paging_no_more_items: "Lisää objekteja ei ole",
		contlist_paging_of_at_least_items: "${0} / väh. ${1} objektia",
		contlist_paging_of_items: "${0}/${1} objektia",
		contlist_paging_items: "Objektit (${0})",
		contlist_paging_items_per_page: "Objektia sivulla: ${0}",

		contlist_checked_out: "Kuitattu ulos",
		contlist_checked_out_by: "Uloskuittaaja: ${0}",

		contlist_size_units_B: " t",
		contlist_size_units_KB: "kt",
		contlist_size_units_MB: "Mt",
		contlist_size_units_GB: "Gt",
		contlist_size_units_TB: "Tt",

		contlist_missing_server_error: "Palvelinta ei ole määritetty.",
		contlist_invalid_server_error: "Palvelinta {0} ei ole.",
		contlist_error_retrieving_doc_props: "Dokumentin ominaisuuksia noudettaessa on ilmennyt virhe.",
		contlist_error_retrieving_folder_props: "Kansion ominaisuuksia noudettaessa on ilmennyt virhe.",
		contlist_checkout_failed: "Dokumentin uloskuittaus epäonnistui",
		contlist_cancel_checkout_failed: "Uloskuittauksen peruutus epäonnistui",
		contlist_rename_folder_failed: "Kansion uudelleennimeäminen epäonnistui.",
		contlist_folder_name_not_unique: "Kansion nimen on oltava yksilöllinen.",
		contlist_delete_object_failed: "Objektin poisto epäonnistui.",
		contlist_display_properties_failed: "Ominaisuuksien näyttäminen epäonnistui. ${0}",
		contlist_save_props_failed: "Ominaisuuksien tallentaminen epäonnistui",
		contlist_upload_failed: "Version siirto epäonnistui",
		contlist_add_folder_failed: "Kansion lisääminen epäonnistui. ${0}",
		contlist_add_document_failed: "Dokumentin lisäys epäonnistui. ${0}",
		contlist_search_failed: "Hakutulosten nouto epäonnistui",
		contlist_folder_containees_failed: "Kansion sisällön nouto epäonnistui",
		contlist_delete_folder_referenced: "Kansion poisto epäonnistui, koska kansio sisältää alikansioita.",
		contlist_docs_not_added: "Seuraavien dokumenttien lisäys ei onnistunut: ${0}.",

		contlist_checkout_success: "Dokumentti kuitattiin ulos",
		contlist_delete_success: "Objekti poistettiin",
		contlist_rename_folder_success: "Kansio nimettiin uudelleen",
		contlist_save_props_success: "Ominaisuudet tallennettiin",
		contlist_cancel_checkout_success: "Uloskuittauksen peruuttaminen onnistui",
		contlist_upload_version_success: "Version siirto onnistui",
		contlist_add_folder_success: "Kansio on lisätty",
		contlist_add_doc_success: "Dokumentti on lisätty",
		contlist_add_docs_success: "Dokumentit on lisätty",

		contlist_menu_action_open: "Avaa",
		contlist_menu_action_rename: "Nimeä uudelleen",
		contlist_menu_action_properties: "Ominaisuudet",
		contlist_menu_action_view: "Näytä",
		contlist_menu_action_download: "Lataa",
		contlist_menu_action_checkout: "Kuittaa ulos",
		contlist_menu_action_edit_document: "Muokkaa dokumenttia",
		contlist_menu_action_cancel_checkout: "Peruuta uloskuittaus",
		contlist_menu_action_delete_doc: "Poista dokumentti",
		contlist_menu_action_rename_folder: "Nimeä kansio uudelleen",
		contlist_menu_action_add_folder: "Lisää kansio",
		contlist_menu_action_delete_folder: "Kansioiden poisto",
		contlist_menu_action_add_doc: "Lisää dokumentti",
		contlist_menu_action_upload: "Siirrä uusi versio",

		contlist_document_properties: "Dokumentin ominaisuudet",
		contlist_folder_properties: "Kansion ominaisuudet",
		contlist_folder_name: "Kansion nimi",

		contlist_cancel_btn_label: "Peruuta",
		contlist_add_btn_label: "Lisää",
		contlist_ok_btn_label: "OK",
		contlist_edit_btn_label: "Muokkaa",
		contlist_save_btn_label: "Tallenna",
		contlist_upload_btn_label: "Siirrä palvelimeen",
		contlist_refresh_btn_label: "Päivitä",
		contlist_next_btn_label: "Seuraava",
		contlist_previous_btn_label: "Edellinen",

		contlist_delete_folder_confirm: "Olet poistamassa kansion ${0}. Haluatko jatkaa?",
		contlist_delete_doc_confirm: "Olet poistamassa dokumentin ${0}. Haluatko jatkaa?",

		contlist_no_mimetype: "Tässä objektissa ei ole sisältöä.",
		contlist_folder_mimetype: "Kansio",

		contlist_filter_search_hint: "Hae dokumentteja",
		contlist_filter_folder_hint: "Suodata luettelo",

		contlist_root_folder: "Pääkansio",
		contlist_drop_folder_error: "Kansioita ei voi lisätä. Valitse vain tiedostoja.",
		contlist_add_in_process: "Odota edellisen dokumentin lisäyksen valmistumista, ennen kuin lisäät uuden dokumentin.",
		contlist_add_doc_max_exceeded: "Voit lisätä enintään ${0} objektia kerrallaan. Lisättävien objektien määrä on nyt ${1}.",
		contlist_progress_success: "Onnistui",
		contlist_progress_alert: "Ilmoitus",
		contlist_progress_error: "Virhe",
		contlist_progress_uploading: "Siirto on meneillään",
		contlist_progress_processing: "1 tiedoston käsittely on meneillään",
		contlist_progress_uploading_text: "1 tiedoston siirto on meneillään",
		contlist_progress_upload_failed: "On ilmennyt ongelma",
		contlist_progress_close: "Sulje",
		progress_ind_uploaded_status: "Siirretty",
		progress_ind_uploaded: "1 tiedosto on siirretty",
		progress_ind_uploaded_error: "Käsittely ei alkanut",		
		progress_ind_processing_status: "Käsittely on meneillään",
		progress_ind_processing_err: "On ilmennyt ongelma",
		progress_ind_processed: "1 tiedosto on käsitelty",	
		progress_ind_failed: "Epäonnistui",
		progress_ind_review_doc: "Arviointi on pakollinen",	
		progress_ind_updating: "1 tiedoston päivitys on meneillään",
		progress_ind_updating_status: "Päivitys on meneillään",
		progress_ind_update_err: "On ilmennyt ongelma",
		progress_ind_timeout: "Valvonta on päättynyt aikakatkaisuun",
		progress_ind_refresh: "Päivitä",

		getcontent_ret_versions_error: "Versiosarjan nouto epäonnistui",
		getcontent_ret_properties_error: "Dokumentin ominaisuuksien nouto epäonnistui",

		contentviewer_test_mode: "Katseluohjelma ei näytä dokumentteja esikatselutilassa. Käytössä on oltava IBM Navigator -työpöytäsovellus.",

		thumbnail_retreival_error: "Pienoiskuvan nouto epäonnistui.",

		status_10: "Siirretty",
		status_20: "Käsittely on meneillään",
		status_25: "Uudelleenkäsittely on meneillään",
		status_30: "Arviointi on pakollinen",
		status_40: "Päivitys on meneillään",
		status_900: "Käsittelyssä on ilmennyt virhe",
		status_910: "Päivityksessä on ilmennyt virhe",

		/*do not remove this line*/nop: null
});
