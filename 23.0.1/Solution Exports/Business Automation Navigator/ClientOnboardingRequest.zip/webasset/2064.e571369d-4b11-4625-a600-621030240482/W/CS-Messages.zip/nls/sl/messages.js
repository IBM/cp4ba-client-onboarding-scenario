/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "Razred",

		// Property list
		properties_file_name: "Ime datoteke",
		properties_file_save_in: "Shrani v",
		properties_add_file: "Dodaj datoteko",
		properties_add_mvcp: "Dodaj ${0}",
		properties_remove_mvcp: "Odstrani iz ${0}",
		properties_use_file_name: "Ime datoteke bo uporabljeno za to lastnost.",

		properties_optional_label: "${0} (izbirno)",

		properties_document_or_folder_not_found: "Dokumenta ali mape ni mogoče najti.",
		properties_class_not_found: "Razreda vsebine ni mogoče najti.",
		properties_folder_duplicate_item_invalid_prop: "Postavka z enakim imenom že obstaja v mapi ali pa ste vnesli neveljavno vrednost lastnosti.",
		properties_item_invalid_prop: "Za eno ali več lastnosti ste vnesli neveljavno vrednost.",

		properties_invalid_long_value: "Ta vrednost ni veljavna. Vrednost mora biti celo število, na primer 5 ali 1349.",
		properties_invalid_float_value: "Vrednost ni veljavna. Vrednost mora biti številka, podana v zapisu s plavajočo vejico, na primer 1,2 ali 365.",
		properties_min_value: "Najmanjša vrednost: ${0}",
		properties_max_value: "Največja vrednost: ${0}",
		properties_max_length: "Največja dolžina: ${0}",
		properties_invalid_guid: "Vrednost ni veljavna. Vrednost mora biti globalni unikatni identifikator (GUID), na primer {F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}.",
		properties_value_required: "Zahtevana je vrednost.",
		properties_unique_value_required: "Ta vrednost mora biti edinstvena.",
		properties_file_required: "Datoteka je zahtevana.",
		properties_invalid_folder_name: "Ime mape ne sme vsebovati naslednjih znakov: \\ / : * ? \" < > |",

		properties_move_edit_confirm_msg: "Spreminjate lastnosti naslednjega dokumenta<br>${0}<br><br>Ali želite shraniti spremembe?",
		properties_move_edit_confirm_no: "Ne",
		properties_move_edit_confirm_yes: "Da",
		properties_move_edit_confirm_title: "Potrditev",
		properties_edit_save_success: "Lastnosti so shranjene",
		properties_edit_save_failure: "Lastnosti niso bile shranjene",
		properties_no_item_selected: "Ni izbranih postavk.",

		// Content list
		contlist_column_spec_title: "Naslov",
		contlist_column_spec_name: "Ime",
		contlist_column_spec_version_label: "Različica",
		contlist_column_spec_modified_by: "Spremenil",
		contlist_column_spec_mod_date: "Nazadnje spremenjeno",
		contlist_column_spec_created_by: "Ustvaril",
		contlist_column_spec_creation_date: "Ustvaril",
		contlist_column_spec_mime_type: "Vrsta dokumenta",
		contlist_column_spec_size: "Velikost",
		contlist_column_spec_thumbnail: "Sličica",

		contlist_paging_no_more_items: "Ni več postavk",
		contlist_paging_of_at_least_items: "${0} od vsaj ${1} postavk",
		contlist_paging_of_items: "${0} od ${1} postavk",
		contlist_paging_items: "Postavke ${0}",
		contlist_paging_items_per_page: "Postavke na stran: ${0}",

		contlist_checked_out: "Odjavil",
		contlist_checked_out_by: "Odjavil ${0}",

		contlist_size_units_B: "B",
		contlist_size_units_KB: "KB",
		contlist_size_units_MB: "MB",
		contlist_size_units_GB: "GB",
		contlist_size_units_TB: "TB",

		contlist_missing_server_error: "Strežnik ni bil podan.",
		contlist_invalid_server_error: "Strežnik '{0}' ne obstaja.",
		contlist_error_retrieving_doc_props: "Napaka pri pridobivanju lastnosti dokumenta.",
		contlist_error_retrieving_folder_props: "Napaka pri pridobivanju lastnosti mape.",
		contlist_checkout_failed: "Dokumenta ni bilo mogoče odjaviti",
		contlist_cancel_checkout_failed: "Preklic odjave dokumenta ni uspel",
		contlist_rename_folder_failed: "Mape ni bilo mogoče preimenovati.",
		contlist_folder_name_not_unique: "Ime mape mora biti edinstveno.",
		contlist_delete_object_failed: "Objekta ni bilo mogoče izbrisati.",
		contlist_display_properties_failed: "Lastnosti ni bilo mogoče prikazati. ${0}",
		contlist_save_props_failed: "Lastnosti ni bilo mogoče shraniti",
		contlist_upload_failed: "Različice ni bilo mogoče naložiti",
		contlist_add_folder_failed: "Mape ni bilo mogoče dodati. ${0}",
		contlist_add_document_failed: "Dokumenta ni bilo mogoče dodati. ${0}",
		contlist_search_failed: "Rezultatov iskanja ni bilo mogoče pridobiti",
		contlist_folder_containees_failed: "Vsebine mape ni bilo mogoče pridobiti",
		contlist_delete_folder_referenced: "Mape ni mogoče izbrisati, ker vsebuje podmape.",
		contlist_docs_not_added: "Naslednjih dokumentov ni bilo mogoče dodati: ${0}. ",

		contlist_checkout_success: "Dokument je bil odjavljen",
		contlist_delete_success: "Objekt je bil izbrisan",
		contlist_rename_folder_success: "Mapa je bila preimenovana",
		contlist_save_props_success: "Lastnosti so bile shranjene",
		contlist_cancel_checkout_success: "Odjava je bila uspešno preklicana",
		contlist_upload_version_success: "Različica je bila naložena",
		contlist_add_folder_success: "Mapa je bila dodana",
		contlist_add_doc_success: "Dokument je bil dodan",
		contlist_add_docs_success: "Dokumenti so bili dodani",

		contlist_menu_action_open: "Odpri",
		contlist_menu_action_rename: "Preimenuj",
		contlist_menu_action_properties: "Lastnosti",
		contlist_menu_action_view: "Ogled",
		contlist_menu_action_download: "Prenesi",
		contlist_menu_action_checkout: "Odjavi",
		contlist_menu_action_edit_document: "Uredi dokument",
		contlist_menu_action_cancel_checkout: "Prekliči odjavo",
		contlist_menu_action_delete_doc: "Izbriši dokument",
		contlist_menu_action_rename_folder: "Preimenuj mapo",
		contlist_menu_action_add_folder: "Dodaj mapo",
		contlist_menu_action_delete_folder: "Izbriši mapo",
		contlist_menu_action_add_doc: "Dodaj dokument",
		contlist_menu_action_upload: "Naloži novo različico",

		contlist_document_properties: "Lastnosti dokumenta",
		contlist_folder_properties: "Lastnosti mape",
		contlist_folder_name: "Ime mape",

		contlist_cancel_btn_label: "Prekliči",
		contlist_add_btn_label: "Dodaj",
		contlist_ok_btn_label: "V redu",
		contlist_edit_btn_label: "Urejanje",
		contlist_save_btn_label: "Shrani",
		contlist_upload_btn_label: "Naloži",
		contlist_refresh_btn_label: "Osveži",
		contlist_next_btn_label: "Naslednji",
		contlist_previous_btn_label: "Prejšnji",

		contlist_delete_folder_confirm: "Izbrisali boste mapo ${0}. Ali želite nadaljevati?",
		contlist_delete_doc_confirm: "Izbrisali boste dokument ${0}. Ali želite nadaljevati?",

		contlist_no_mimetype: "Ta postavka ne vsebuje ničesar.",
		contlist_folder_mimetype: "Mapa",

		contlist_filter_search_hint: "Išči v dokumentih",
		contlist_filter_folder_hint: "Filtriraj seznam",

		contlist_root_folder: "Korenska mapa",
		contlist_drop_folder_error: "Map ni mogoče dodati. Izberite samo datoteke. ",
		contlist_add_in_process: "Počakajte, dokler se dodajanje prejšnjega dokumenta ne dokonča, preden dodate drugega. ",
		contlist_add_doc_max_exceeded: "Hkrati lahko dodate največ ${0} postavk. Poskušate dodati ${1} postavk.",
		contlist_progress_success: "Uspelo",
		contlist_progress_alert: "Opozorilo",
		contlist_progress_error: "Napaka",
		contlist_progress_uploading: "Nalaganje",
		contlist_progress_processing: "Obdelava 1 datoteke",
		contlist_progress_uploading_text: "Nalaganje 1 datoteke",
		contlist_progress_upload_failed: "Prišlo je do težave",
		contlist_progress_close: "Zapri",
		progress_ind_uploaded_status: "Naloženo",
		progress_ind_uploaded: "Naložena 1 datoteka",
		progress_ind_uploaded_error: "Obdelava se ni začela",		
		progress_ind_processing_status: "Obdelava",
		progress_ind_processing_err: "Prišlo je do težave",
		progress_ind_processed: "Obdelana 1 datoteka",	
		progress_ind_failed: "Ni uspelo",
		progress_ind_review_doc: "Pregled je obvezen",	
		progress_ind_updating: "Posodabljanje 1 datoteke",
		progress_ind_updating_status: "Posodabljanje",
		progress_ind_update_err: "Prišlo je do težave",
		progress_ind_timeout: "Nadziranje je poteklo",
		progress_ind_refresh: "Osveži",

		getcontent_ret_versions_error: "Pridobivanje niza različic ni uspelo",
		getcontent_ret_properties_error: "Pridobivanje lastnosti dokumenta ni uspelo",

		contentviewer_test_mode: "Prikazovalnik ne bo prikazal dokumentov v načinu predogleda. Za izvajanje morate uporabiti namizno aplikacijo IBM Navigator.",

		thumbnail_retreival_error: "Pridobivanje sličice ni uspelo.",

		status_10: "Naloženo",
		status_20: "Obdelava",
		status_25: "Vnovična obdelava",
		status_30: "Pregled je obvezen",
		status_40: "Posodabljanje",
		status_900: "Napaka med obdelovanjem",
		status_910: "Napaka med posodabljanjem",

		/*do not remove this line*/nop: null
});
