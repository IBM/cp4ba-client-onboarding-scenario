/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof TeamMemberDetail
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof TeamMemberDetail
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof TeamMemberDetail
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof TeamMemberDetail
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof TeamMemberDetail
 * @method setData
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 * </table>
 */
workplace_control_InitTeamMemberDetail = function (utilities, taskUtils, wpResources, domStyle) {
    "use strict";
    this._instance = {
        searchTerm: "",
        selectedCols: [
            {name: "taskStatus", value: "Status"},
            {name: "taskPriority", value: "Priority"},
            {name: "taskSubject", value: "Name"},
            {name: "taskDueDate", value: "Due on"},
            {name: "taskAtRiskTime", value: "At-risk date"},
            {name: "assignedToUser", value: "Owner"},
        ],
        filterConditions: []
    };

    if (!this.constructor.prototype._proto) {
        this.constructor.prototype._proto = {
            EXCLUDE_TABLE_COLUMNS: ["KIND", "OWNER"],
            FILTER_CONDITIONS: [
                wpResources.tasks.OPERATOR.EQUALS("interaction", wpResources.tasks.INTERACTION.CLAIMED_AND_AVAILABLE)
            ],

            /******************** Fetches - start ********************/
            _reloadTaskList: function _reloadTaskList(view) {
                var filters = view._proto._getTaskListFilters(view);
                view._instance.taskList.setFilterConditions(filters);

                view._instance.taskList.reload();
            },

            _fetchMemberDetail: function _fetchMemberDetail (view) {
                var teamId = view._instance.viewerObj.teamId;
                var username = view._instance.viewerObj.name;

                var success = function () {
                    // reserve for later use
                };

                var fail = function (error) {
                    !!error && !!error.errorMessage && taskUtils.publishError(error.errorMessage);
                    bpmext.log.error("ERROR >> There was an error fetching the user tasks: " + error);
                };

                wpResources.teamPerformance.getTeamMemberDetailByID({
                    teamId: teamId,
                    username: username
                }).then(
                    success,
                    fail
                );
            },

            _fetchTasks: function _fetchTasks(view, settings) {
                var teamId = view._instance.viewerObj.teamId;

                var success = function (tasks) {
                    view._proto._loadTasks(view, tasks);
                };

                var fail = function (error) {
                    !!error && !!error.errorMessage && taskUtils.publishError(error.errorMessage);
                    bpmext.log.error("ERROR >> There was an error fetching the user tasks: " + error);
                };

                settings = settings || {};
                settings.teamId = teamId;
                settings.size = 500;

                wpResources.teamPerformance.getTeamTasksByID(
                    settings
                ).then(
                    success,
                    fail
                );
            },
            /******************** Fetches - end ********************/


            /******************** Member icon - start ********************/
            _loadMemberIcon: function _loadMemberIcon (view, member) {
                var name = member.name || "Undefined";
                view._instance.memberName.setText(name);
                view._proto._setTeamMemberAvatar(view, name);
            },

            _setTeamMemberAvatar: function _setTeamMemberAvatar (view, memberName) {
                var avatar = view._instance.memberIconWrapper.querySelector("div.MemberAvatar");
                var nameSpan = view._instance.memberIconWrapper.querySelector("div.MemberName > span");

                // Apply a parsed dark color to the avatar
                var darkColor = view._proto._randDarkColor(name);
                domStyle.set(avatar, "background-color", darkColor);

                // Parse camel case
                var name = memberName;
                if (name.indexOf(" ") < 0) {
                    name = name.replace(/([a-z0-9])([A-Z])/g, "$1 $2");
                }

                // Set name
                nameSpan.innerText = name.toLocaleUpperCase().split(" ").reduce(function (abbr, word) {
                    return (abbr.length < 3) ? abbr + word[0] : abbr;
                }, "");
            },

            _randDarkColor: function _randDarkColor (str, seed) {
                if (!seed) {
                    seed = 0.5;
                }

                // Unifying input str
                str = (str || "").split("").map(function (char) {
                    return char.charCodeAt(0);
                });

                while (str.length < 6) {
                  seed = Math.sin(seed) * 1000;
                  str.push(Math.round(seed));
                }

                seed = Math.sin(str.reduce(function (a, b) {
                    return a + b;
                }, 0));

                var lum = -0.25;
                var hex = String("#" + seed.toString(16).slice(2, 8).toUpperCase()).replace(/[^0-9a-f]/gi, "");
                if (hex.length < 6) {
                  hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
                }

                var rgb = "#", c, i;

                for (i = 0; i < 3; i++) {
                  c = parseInt(hex.substr(i * 2, 2), 16);
                  c = Math.round(Math.min(Math.max(0, c + (c * lum)), 255)).toString(16);
                  rgb += ("00" + c).substr(c.length);
                }

                return rgb;
            },
            /******************** Member icon - end ********************/


            /******************** Tasks - start ********************/
            _loadTasks: function _loadTasks(view, tasks) {
                view._proto._getTeamTasksStats(view);
                view._instance.taskList.setTasks(tasks);
            },

            _getTeamTasksStats: function _getTeamTasksStats(view) {
                var stats = {onTrack: 0,  atRisk: 0, overdue: 0,  total: 0};
                var options = {
                    teamId: view._instance.viewerObj.teamId,
                    size: 500
                };
                wpResources.teamPerformance.getTeamTasksByID(options).then(function (tasksObj) {
                    if (tasksObj && tasksObj.riskStateSummary) {
                        stats = {
                            onTrack: tasksObj.riskStateSummary.OnTrack || 0,
                            atRisk: tasksObj.riskStateSummary.AtRisk || 0,
                            overdue: tasksObj.riskStateSummary.Overdue || 0,
                            total:  tasksObj.totalCount || 0
                        };
                    }
                    view._instance.tasksStatistics.setStats({stats: stats});
                });

            },
            /******************** Tasks - end ********************/


            /******************** Construct filters - start ********************/
            _getTaskListFilters: function _getTaskListFilters(view) {
                return taskUtils.compose([
                    view._proto._getDefaultFilters,
                    function (filters) {return view._proto._appendFilterOnUser(view, filters);},
                    function (filters) {return view._proto._appendFilterOnStatus(view, filters);}
                ])([view]);
            },

            _getDefaultFilters: function _getDefaultFilters(view) {
                return dojo.clone(view._proto.FILTER_CONDITIONS);
            },

            _appendFilterOnUser: function _appendFilterOnUser(view, filters) {
                if (!Array.isArray(filters) || !filters) {
                    filters = [];
                }

                var name = view._instance.viewerObj.name;
                return filters.concat([
                    wpResources.tasks.OPERATOR.EQUALS("assignedToUser", name)
                ]);
            },

            _appendFilterOnStatus: function _appendFilterOnStatus(view, filters) {
                if (!Array.isArray(filters) || !filters) {
                    filters = [];
                }

                var now = new Date().toISOString();
                var filterText = view._instance.taskListFilterText || "";

                if (filterText === "overdue") {
                    filters.push(wpResources.tasks.OPERATOR.LESS_THAN("taskDueDate", now));
                } else if (filterText === "atRisk") {
                    filters.push(wpResources.tasks.OPERATOR.GREATER_THAN("taskDueDate", now));
                    filters.push(wpResources.tasks.OPERATOR.LESS_THAN("taskAtRiskTime", now));
                } else if (filterText === "onTrack") {
                    filters.push(wpResources.tasks.OPERATOR.GREATER_THAN("taskDueDate", now));
                    filters.push(wpResources.tasks.OPERATOR.GREATER_THAN("taskAtRiskTime", now));
                }

                return filters;
            },
            /******************** Construct filters - end ********************/


            /******************** Others - start ********************/
            _clearViews: function _clearViews(view) {
                view._instance.viewClosed = true;

                // Clear all filers
                view._instance.tasksStatistics.removeFilters();

                view._instance.taskList.setTasks({items: []});
            },

            _initControls: function _initControls(view) {
                view._instance.viewClosed = true;

                view._instance.memberName.setLabelVisible(false);

                view._instance.taskList.setSelectedColumns(view._instance.selectedCols);
                view._instance.taskList.setExclusiveColumns(view._proto.EXCLUDE_TABLE_COLUMNS);

                view._instance.taskList.setTasks({items: []});
            },

            _localization: function _localization(view) {
                view._instance.taskList.setEmptyTableTexts({
                    header: bpmext.localization.formatMsg("TeamMemberDetail", "noTasksHeader"),
                    subHeader: bpmext.localization.formatMsg("TeamMemberDetail", "noTasksSubheader")
                });
            },

            _generateHistoryCallbacks: function _generateHistoryCallbacks (view, displayName) {
                var onViewRestore = function () {
                    taskUtils.EVENTS.BEFORE_VIEW_TEAM_MEMBER_DETAIL.publish(view._instance.viewerObj);
                };

                var onViewClose = function() {
                    view.closeTeamMemberDetail();
                };

                return {
                    identifier: "Team",
                    displayName: displayName || "Team",
                    onViewRestore: onViewRestore,
                    onViewClose: onViewClose
                };
            }
            /******************** Others - end ********************/
        };

        /*
        Public control methods *************************************************************
        */

        /**
		 * @instance
		 * @memberof TeamMemberDetail
		 * @method showTeamMemberDetail
		 * @desc Shows the views for team member detail
		 */
        this.constructor.prototype.showTeamMemberDetail = function showTeamMemberDetail() {
            bpmext.log.info("TeamMemberDetail.showTeamMemberDetail");

            if (!this.isVisible()) {
                var teamMemberDetailDS = bpmext.ui.getContainer("/Workplace_Content_Wrapper1/Team_Member_Detail_DS");
                teamMemberDetailDS.setVisible(true, true);

                this.setVisible(true, true);
            }
        };

        /**
		 * @instance
		 * @memberof TeamMemberDetail
		 * @method closeTeamMemberDetail
		 * @desc Close team member detail
		 */
        this.constructor.prototype.closeTeamMemberDetail = function() {
            bpmext.log.info("TeamMemberDetail.closeTeamMemberDetail");

            if (this.isVisible()) {
                var teamMemberDetailDS = bpmext.ui.getContainer("/Workplace_Content_Wrapper1/Team_Member_Detail_DS");
                teamMemberDetailDS.setVisible(true, true);

                this._proto._clearViews(this);

                this.setVisible(false, true);
            }
        };

        /**
		 * @instance
		 * @memberof TeamMemberDetail
		 * @method onExternalFetch
		 * @desc Triggers when tab section gets switched
		 */
        this.constructor.prototype.onExternalFetch = function onExternalFetch(target, searchSettings) {
            bpmext.log.info("TeamMemberDetail.onExternalFetch");
            this._proto._fetchTasks(this, searchSettings);
        };

        /**
		 * @instance
		 * @memberof TeamMemberDetail
		 * @method taskStatusFilterChanged
		 * @desc Triggers on team task filter changed
		 */
        this.constructor.prototype.taskStatusFilterChanged = function taskStatusFilterChanged(target, filterOpt) {
            if (this._instance.taskListFilterText !== filterOpt.filter) {
                this._instance.taskListFilterText = filterOpt.filter || "";

                // make sure no call will be processed when the view is closed
                if (!this._instance.viewClosed || !this.isVisible()) {
                    this._proto._reloadTaskList(this);

                    if (this._instance.taskListFilterText === "total") {
                        taskUtils.EVENTS.SET_TASK_BADGE.publish({clearSS:true});
                    } else if (!!this._instance.taskListFilterText) {
                        taskUtils.EVENTS.SET_TASK_BADGE.publish({text: filterOpt.text, clearSS: true});
                    }
                }
            }
        };

        /*
        Coach NG Lifecycle methods *************************************************************
        */

        this.constructor.prototype.load = function () {
            bpmext.log.info("TeamMemberDetail.load ENTER >>", this);

            this._instance.memberName = bpmext.ui.getView("MemberName", this);
            this._instance.memberName._instance.outputText.setAttribute("role", "heading");
            this._instance.memberName._instance.outputText.setAttribute("aria-level", "1");
            this._instance.memberIconWrapper = this.context.element.querySelector("div.MemberAvatarWrapper");

            this._instance.navigationBar = bpmext.ui.getContainer("Workplace_Navigation_Bar", this);

            this._instance.tasksStatistics = bpmext.ui.getView("TeamMemberTaskStatistics", this);
            this._instance.taskList = bpmext.ui.getContainer("MemberTaskList", this);

            this._proto._initControls(this);
            this._proto._localization(this);

            this.loadView(this);

            taskUtils.EVENTS.BEFORE_VIEW_TEAM_MEMBER_DETAIL.subscribe(function (eventName, eventData) {
                if (eventData.name && eventData.teamId) {
                    this.showTeamMemberDetail();

                    // Minimize info for restoring instance back
                    this._instance.viewerObj = {
                        teamId: eventData.teamId,
                        name: eventData.name
                    };

                    var historyCallbacks = this._proto._generateHistoryCallbacks(this, eventData.name);
                    taskUtils.viewHistory.addToViewHistory(historyCallbacks);
                    this._instance.navigationBar.resetView();

                    this._instance.taskList.configBatchModify({
                        params: {
                            teamId: this._instance.viewerObj.teamId || null,
                        },
                        rejectedTasks: {
                            notOwnedTask: false
                        }
                    });

                    // reload all page components
                    this._instance.viewClosed = false;
                    this._proto._loadMemberIcon(this, eventData);
                    this._proto._reloadTaskList(this);
                }
            }, this);

            taskUtils.EVENTS.MODIFY_TASK_SEARCH_TERM.subscribe(function(eventName, eventData){
                if (!this.isVisible()) {
                    return;
                }

                //add a wildcard
                if (eventData) {
                    eventData = eventData + "*";
                }

                if(this._instance.taskList.setSearchTerm(eventData)){
                    this._instance.taskList.reload();
                }
            }, this);
        };

        this.constructor.prototype.view = function () {
            try {
                utilities.handleVisibility(this.context);
            } catch (e) {
                //{#feature: US-1330 Added RT localization}
                //bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if(e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    //bpmext.log.error("  Call stack: " + e.stack);
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                }
            }
        };

        this.constructor.prototype.change = function (event) {
            bpmext.log.info("TeamMemberDetail.change ENTER >>");
            if (event.type === "config") {
                switch (event.property) {
                    case "_metadata.visibility": {
                        this.view();
                        break;
                    }
                }
            }
            bpmext.log.info("TeamMemberDetail.change EXIT >>");
        };

        this.constructor.prototype.unload = function () {
            bpmext.ui.unloadView(this);
        };
    }
};