/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2020. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof PropertiesModal
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof PropertiesModal
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof PropertiesModal
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof PropertiesModal
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof PropertiesModal
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof PropertiesModal
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof PropertiesModal
 * @method triggerFormulaUpdates
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 * </table>
 */
workplace_control_InitPropertiesModal = function (utilities, taskUtils, domClass)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            EVT_ON_CLOSE: "eventON_CLOSE",
            EVT_ON_SHOW: "eventON_SHOW",
            _setStack: function _setStack(view, targetView, showModal) {
                bpmext.log.info("PropertiesModal._setStack LOG >> ", view);
                var i, targetViewIndex, paneCount = view._instance.stack.getPaneCount();

                view._instance.panelOptions = {};
                view._instance.currentView = {};
                view._instance.currentDSView = {};

                for(i=0; i<paneCount; i++){
                    if(view._instance.stack.getViewInPane(i) && view._instance.stack.getViewInPane(i).context.viewid === targetView + "_DS"){
                        targetViewIndex = i;
                        view._instance.stack.setCurrentPane(targetViewIndex);
                        view._instance.currentDSView = view._instance.stack.getViewInPane(i);
                        if(!view._instance.currentDSView.isLoaded()){
                            showModal && view._proto._setLoaderVisible(view, true);
                            view._instance.currentDSView.lazyLoad(250,false);
                        }else{
                            showModal && view.showModal(targetView);
                        }
                        break;
                    }
                }
                if(!view._instance.currentDSView.context){
                    view.closePanel();
                }
            },
            _executeEvent: function _executeEvent(view, targetEvent) {
                bpmext.log.info("PropertiesModal._executeEvent LOG >> ", view);
                if(targetEvent){
                    if(targetEvent.method){
                        targetEvent.method(targetEvent.args);
                    }
                    if(targetEvent.closeOnEvtComplete){
                        view.closePanel();
                    }
                }
            },
            _setButton: function _setButton(buttonControl, buttonOption){
                bpmext.log.info("PropertiesModal._setButton LOG >> ", buttonControl);
                if(buttonControl && buttonOption){
                    if(buttonOption.visible!=null){
                        buttonControl.setVisible(buttonOption.visible, true);
                    }
                    if(buttonOption.enable!=null){
                        buttonControl.setEnabled(buttonOption.enable);
                    }
                    if(buttonOption.text!=null){
                        buttonControl.setText(buttonOption.text);
                    }
                }
            },
            _getProgressViewIndex: function _getProgressViewIndex(view){
                bpmext.log.info("PropertiesModal._getProgressViewIndex LOG >> ", view);
                var index, pathName = view.context.parentView().context.controlidpath;
                if (/\[\d+\]$/.test(pathName)) {
                    index = parseInt(pathName.substring(pathName.lastIndexOf("[")+1,pathName.lastIndexOf("]")));
                } else{
                    index = -1;
                }
                return index;
            },
            _setLoaderVisible: function _setLoaderVisible(view, show){
                bpmext.log.info("PropertiesModal._setLoaderVisible LOG >> ", view);
                if(show){
                    domClass.add(view._instance.skeleTitle.context.element, "skeleton");
                    domClass.add(view._instance.skeleSubtitle.context.element, "skeleton");
                    view._instance.progressBar.setVisible(false, true);
                    view._instance.categories.setVisible(false, true);
                    view._instance.title.setVisible(false,true);
                    view._instance.subtitle.setVisible(false, true);
                    view._instance.skeleTitle.setVisible(true);
                    view._instance.skeleSubtitle.setVisible(true);
                    view._proto._showModal(view);
                    view._instance.spinner.show();
                }
            },
            _showModal: function _showModal(view){
                view.show();
                document.body.classList.add("modal-open");
                var panelDom = view.context.element;
                var innerPanelDom = view._instance.panelLayout.context.element;
                domClass.add(panelDom, "openModal");
                domClass.add(innerPanelDom, "openModal");
            }
        };

		/*
        Public control methods *************************************************************
        */
        /**
         * @instance
         * @memberof PropertiesModal
         * @method primaryButtonHandler
         * @desc primary button event handler
         */
        this.constructor.prototype.primaryButtonHandler = function primaryButtonHandler() {
            bpmext.log.info("PropertiesModal.primaryButtonHandler ENTER >>", this);

            this._proto._executeEvent(this, this._instance.panelOptions.primaryBtnEvent);

            bpmext.log.info("PropertiesModal.primaryButtonHandler EXIT >>", this);
        };

        /**
         * @instance
         * @memberof PropertiesModal
         * @method secondaryButtonHandler
         * @desc secondary button event handler
         */
        this.constructor.prototype.secondaryButtonHandler = function secondaryButtonHandler() {
            bpmext.log.info("PropertiesModal.secondaryButtonHandler ENTER >>", this);

            this._proto._executeEvent(this, this._instance.panelOptions.secondaryBtnEvent);

            bpmext.log.info("PropertiesModal.secondaryButtonHandler EXIT >>", this);
        };

        /**
         * @instance
         * @memberof PropertiesModal
         * @method closePanel
         * @desc Triggered the event to close the modal
         */
        this.constructor.prototype.closePanel = function closePanel() {
            taskUtils.EVENTS.SLIDEOUT_PANEL_CLOSE.publish();
        };


        /**
         * @instance
         * @memberof PropertiesModal
         * @method closeModal
         * @desc Closes the modal
         */
        this.constructor.prototype.closeModal = function closeModal() {
            bpmext.log.info("PropertiesModal.closeModal ENTER >>", this);
            
            this._instance.previousQuery = this._instance.query;
            this._instance.query =  "[control-name*='Launch'] [tabindex]";
            if (this._instance.panelOptions.onPanelClose){
                this._proto._executeEvent(this, this._instance.panelOptions.onPanelClose);
            }
            bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ON_CLOSE);

            this._instance.panelOptions = {};
            this._instance.currentView = {};
            this._instance.currentDSView = {};
            this._instance.progressBar.setViewData([], true);
            var panelDom = this.context.element;
            var innerPanelDom = this._instance.panelLayout.context.element;
            domClass.remove(panelDom, "openModal");
            domClass.remove(innerPanelDom, "openModal");
            this.hide(true);
            document.body.classList.remove("modal-open");

            bpmext.log.info("PropertiesModal.closeModal EXIT >>", this);
        };

        /**
         * @instance
         * @memberof PropertiesModal
         * @method showModal
         * @desc Shows the modal
         */
        this.constructor.prototype.showModal = function showModal(targetView) {
            bpmext.log.info("PropertiesModal.showModal ENTER >>", this);
            if(this._instance.currentDSView && this._instance.currentDSView.ui.getChild(targetView)){
                this._instance.currentView = this._instance.currentDSView.ui.getChild(targetView);
                if(this._instance.skeleTitle.isVisible()){
                    this._instance.title.setVisible(true);
                    this._instance.subtitle.setVisible(true);
                    this._instance.skeleTitle.setVisible(false, true);
                    this._instance.skeleSubtitle.setVisible(false, true);
                    this._instance.spinner.hide();
                }
                if(this._instance.currentView && this._instance.currentView._instance.MODAL_OPTIONS){
                    var modalOptions = this._instance.currentView._instance.MODAL_OPTIONS;
                    if(modalOptions.title!=null){
                        this._instance.title.setLabel(modalOptions.title);
                    }
                    if(modalOptions.subtitle!=null){
                        this._instance.subtitle.setLabel(modalOptions.subtitle);
                        if (modalOptions.viewFrom === "NameWorkstream" && this._instance.subtitle.context.element.querySelector("span a")){
                            var a = document.createElement("a");
                            var link = document.createTextNode(bpmext.localization.formatMsg("workplace", "helpContent"));
                            a.appendChild(link);
                            a.href = "https://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.workstream/topics/con_rwf_intro.html";
                            this._instance.subtitle.context.element.querySelector("span").appendChild(a);
                        }
                    }
                    if(modalOptions.primaryBtnText!=null){
                        this._instance.primaryButton.setText(modalOptions.primaryBtnText);
                        this._instance.primaryButton.setVisible(true,true);
                        if (modalOptions.viewFrom !== "NameWorkstream" && modalOptions.viewFrom !== "Saved search" ){
                            this._instance.primaryButton.context.element.querySelector("button").classList.add("launchBtn");
                            this._instance.primaryButton.setIcon("ci-arrow-right");
                        }else{
                            this._instance.primaryButton.context.element.querySelector("button").classList.remove("launchBtn");
                            this._instance.primaryButton.setIcon("");
                        }
                    }else{
                        this._instance.primaryButton.setVisible(false,true);
                    }
                    if(modalOptions.secondaryBtnText!=null){
                        this._instance.secondaryButton.setText(modalOptions.secondaryBtnText);
                        this._instance.secondaryButton.setVisible(true,true);
                        if (modalOptions.viewFrom === "InstanceFilter"){
                            this._instance.secondaryButton.context.element.querySelector("button").classList.add("applyBtn");
                        }else{
                            this._instance.secondaryButton.context.element.querySelector("button").classList.remove("applyBtn");
                        }
                    }else{
                        this._instance.secondaryButton.setVisible(false,true);
                    }
                    if(modalOptions.primaryBtnEvent!=null){
                        this._instance.panelOptions.primaryBtnEvent = dojo.clone(modalOptions.primaryBtnEvent);
                    }
                    if(modalOptions.secondaryBtnEvent!=null){
                        this._instance.panelOptions.secondaryBtnEvent = dojo.clone(modalOptions.secondaryBtnEvent);
                    }
                    if(modalOptions.onPanelClose!=null){
                        this._instance.panelOptions.onPanelClose = dojo.clone(modalOptions.onPanelClose);
                    }
                    if(modalOptions.onPanelShow!=null){
                        this._instance.panelOptions.onPanelShow = dojo.clone(modalOptions.onPanelShow);
                    }
                    if(modalOptions.progressBarOptions!=null){
                        this._instance.panelOptions.progressBarOptions = dojo.clone(modalOptions.progressBarOptions);
                        this._instance.sidebarStack.setCurrentPane(1);
                    }else if(modalOptions.viewFrom === "Saved search"){
                        this._instance.sidebarStack.setCurrentPane(2);
                    }else{
                        this._instance.sidebarStack.setCurrentPane(0);
                    }
                }
                if(this._instance.panelOptions){
                    //Progress Bar
                    if(this._instance.panelOptions.progressBarOptions && this._instance.panelOptions.progressBarOptions.progressBarSteps && this._instance.panelOptions.progressBarOptions.progressBarSteps.length > 0){
                        this.setProgressSteps(this._instance.panelOptions.progressBarOptions.progressBarSteps);
                        this._instance.progressBar.setVisible(true);
                        this._instance.categories.setVisible(false, true);
                    }else{
                        this._instance.progressBar.setVisible(false, true);
                        this._instance.categories.setVisible(true);
                    }

                    this._proto._executeEvent(this, this._instance.panelOptions.onPanelShow);
                }

                bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ON_SHOW);
                
                if (!this._instance.currentView.isVisible()) {
                    this._instance.currentView.setVisible(true);
                }

                var stackChild = this._instance.stack._bpmextCBox;
                stackChild.ariaAtomic = null;
                stackChild.ariaLive = null;
                stackChild.ariaRelevant = null;

                var panel = this._instance.panelLayout.context.element;
                var title = this._instance.title._instance.label.innerHTML;
                panel.parentElement.setAttribute("role", "presentation");
                panel.firstElementChild.setAttribute("aria-label", title);
                panel.firstElementChild.setAttribute("aria-modal", "true");
                panel.firstElementChild.setAttribute("role", "dialog");

                if (this._instance.categories && !this._instance.categories.context.element.classList.contains("stack-hidden")) {
                    var categoryInstance = this._instance.categories._instance;
                    categoryInstance[categoryInstance.selected + "HL"].context.element.focus();
                } else if (this._instance.currentView.context.viewid !== "Name_Workstream1") {
                    var view = this;
                    setTimeout(function() {
                        view._instance.closeButton.context.element.querySelector(".SPARKIcon").focus();
                    });
                }
                this._proto._showModal(this);
                this._instance.stack.setVisible(true);
            }
            bpmext.log.info("PropertiesModal.showModal EXIT >>", this);
        };

        /**
         * @instance
         * @memberof PropertiesModal
         * @method setProgressSteps
         * @desc Add steps to the progress bar
         */
        this.constructor.prototype.setProgressSteps = function setProgressSteps(steps) {
            bpmext.log.info("PropertiesModal.setProgressSteps ENTER >>", this);
            if(steps){
                this._instance.progressBar.context.binding.set("value", steps);
            }
            bpmext.log.info("PropertiesModal.setProgressSteps EXIT >>", this);
        };

        /**
         * @instance
         * @memberof PropertiesModal
         * @method setProgressText
         * @desc Sets the text of progress view
         */
        this.constructor.prototype.setProgressText = function setProgressText(view) {
            bpmext.log.info("PropertiesModal.setProgressText ENTER >>", this);
            var progressIndex = this._proto._getProgressViewIndex(view);
            var steps = this._instance.progressBar.context.binding.get("value");
            if(progressIndex > -1 && steps && steps.items.length > progressIndex){
                view.setText(steps.get(progressIndex).displayText);
            }
            bpmext.log.info("PropertiesModal.setProgressText EXIT >>", this);
        };

        /**
         * @instance
         * @memberof PropertiesModal
         * @method setProgressIcon
         * @desc Sets the icon of progress view
         */
        this.constructor.prototype.setProgressIcon = function setProgressIcon(view) {
            bpmext.log.info("PropertiesModal.setProgressIcon ENTER >>", this);
            var viewStep = this._proto._getProgressViewIndex(view) + 1;
            var steps = this._instance.progressBar.context.binding.get("value");
            if( steps &&
                this._instance.panelOptions &&
                this._instance.panelOptions.progressBarOptions &&
                this._instance.panelOptions.progressBarOptions.currentStep &&
                this._instance.panelOptions.progressBarOptions.currentStep > 0 &&
                this._instance.panelOptions.progressBarOptions.currentStep <= steps.items.length
            ){
                var currentStepIndex = this._instance.panelOptions.progressBarOptions.currentStep;
                var className, domElement = view.context.parentView().context.element;
                if(viewStep === currentStepIndex){
                    view.setIcon("ci"); // leave blank just use blue circle
                    view.setIconSize("16px");
                    className = "currentProgress";
                }else if ( viewStep < currentStepIndex ){
                    view.setIcon("ci-checkmark-outline");
                    view.setIconSize("16px");
                    className = "completedProgress";
                }else{
                    view.setIcon("ci-radio-button");
                    view.setIconSize("16px");
                    className = "futureProgress";
                }
                domClass.add(domElement, className);
            }
            bpmext.log.info("PropertiesModal.setProgressIcon EXIT >>", this);
        };

        /**
		 * @instance
		 * @memberof PropertiesModal
		 * @method allButtonClicked
		 * @desc Show all workstreams
		 */
        this.constructor.prototype.allButtonClicked = function() {
            this._instance.previousQuery = this._instance.query;
            this._instance.query =  "[control-name*='Launch'] [tabindex]";
            taskUtils.EVENTS.OPEN_CONFIG.publish();
        };

        /**
		 * @instance
		 * @memberof PropertiesModal
		 * @method activitiesButtonClicked
		 * @desc Show activities
		 */
        this.constructor.prototype.activitiesButtonClicked = function() {
            this._instance.previousQuery = this._instance.query;
            this._instance.query =  "[control-name*='Checklist'] .stat-panel";
            taskUtils.EVENTS.OPEN_ACTIVITIES.publish();
        };

        /**
		 * @instance
		 * @memberof PropertiesModal
		 * @method recentButtonClicked
		 * @desc Show recent workstreams
		 */
        this.constructor.prototype.recentButtonClicked = function() {
            this._instance.previousQuery = this._instance.query;
            this._instance.query =  "[control-name*='Recent'] [tabindex]";
            if(this._instance.stack.ui.getChild("Recent_Workflows_DS").isLoaded()){
                taskUtils.EVENTS.OPEN_RECENT.publish();
            }else{
                taskUtils.EVENTS.LOAD_STACK_PANE.publish({targetView:"Recent_Workflows"});
            }
        };

        /**
		 * @instance
		 * @memberof PropertiesModal
		 * @method favoritesButtonClicked
		 * @desc Show favorite workstreams
		 */
        this.constructor.prototype.favoritesButtonClicked = function() {
            this._instance.previousQuery = this._instance.query;
            this._instance.query =  "[control-name*='Favorite'] [tabindex]";
            if(this._instance.stack.ui.getChild("Workflow_Favorites1_DS").isLoaded()){
                taskUtils.EVENTS.OPEN_FAVORITES.publish();
            } else {
                taskUtils.EVENTS.LOAD_STACK_PANE.publish({targetView:"Workflow_Favorites1"});
            }
        };

		 /*
        Coach NG Load Lifecycle method *************************************************************
         */
        this.constructor.prototype.load = function ()
        {
            var view = this;

            bpmext.log.info("PropertiesModal.load ENTER >>", this);

            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ON_CLOSE);
            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ON_SHOW);

            this._instance.closeButton = bpmext.ui.getView("Icon1", this);
            this._instance.title = bpmext.ui.getView("Title", this);
            this._instance.title._instance.label.setAttribute("role", "heading");
            this._instance.title._instance.label.setAttribute("aria-level", "2");
            this._instance.subtitle = bpmext.ui.getView("Subtitle", this);

            this._instance.stack = bpmext.ui.getContainer("Stack", this);
            this._instance.sidebarStack = bpmext.ui.getContainer("SidePanelLayout", this);
            this._instance.categories = bpmext.ui.getView("Categories", this);

            this._instance.primaryButton = bpmext.ui.getView("PrimaryButton", this);
            this._instance.secondaryButton = bpmext.ui.getView("SecondaryButton", this);

            this._instance.panelLayout = bpmext.ui.getContainer("PanelLayout", this);
            this._instance.progressBar = bpmext.ui.getContainer("ProgressBar", this);
            this._instance.progressBar.setViewData([{displayText: "", value: "0"}], true);

            this._instance.spinner = bpmext.ui.getView("Spinner1", this);
            this._instance.skeleTitle = bpmext.ui.getView("SkeletonTitle", this);
            this._instance.skeleSubtitle = bpmext.ui.getView("SkeletonSubtitle", this);
            this._instance.skeleTitle.setLabel("placeholder");
            this._instance.skeleSubtitle.setLabel("This is a placeholder text");
            document.addEventListener("keydown", closeOnEscape);

			function closeOnEscape(event) {
				if (event.key === "Escape" || event.key === "Esc") {
					view.closeModal();
				}
            }
            
            taskUtils.EVENTS.LOAD_STACK_PANE.subscribe(function (eventName, eventData) {
                var showModal = eventData.showModal == undefined ? true : !!eventData.showModal;
                showModal && view._instance.stack.setVisible(true, true);
                view._proto._setStack(view, eventData.targetView, showModal);
            }, this);

            taskUtils.EVENTS.SLIDEOUT_PANEL_EXPAND.subscribe(function (eventName, eventData) {
                view._proto._setStack(view, eventData.targetView);
                view.showModal(eventData.targetView);
            }, this);

            taskUtils.EVENTS.SLIDEOUT_PANEL_CLOSE.subscribe(function () {
                this.closeModal();
            }, this);

            taskUtils.EVENTS.SLIDEOUT_SET_PRIMARY_BTN.subscribe(function (eventName, eventData){
                this._proto._setButton(this._instance.primaryButton, eventData);
            }, this);

            taskUtils.EVENTS.SLIDEOUT_SET_SECONDARY_BTN.subscribe(function (eventName, eventData){
                this._proto._setButton(this._instance.secondaryButton, eventData);
            }, this);

            this.context.element.querySelector(".Vertical_Layout").onclick = function(e){
                if(e.target.parentElement.id === view.context.element.id){
                    view.closePanel();
                }
            };

            this.setVisible(false, false);

            this.loadView(this);

            bpmext.log.info("PropertiesModal.load EXIT >>", this);
		};

        /*
        Coach NG VIew Lifecycle method *************************************************************
         */
        this.constructor.prototype.view = function ()
        {
            try
            {
                utilities.handleVisibility(this.context);
            }
            catch (e)
            {
                //{#feature: US-1330 Added RT localization}
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if(e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                }
            }
        };

		/*
        Coach NG Unload Lifecycle method *************************************************************
         */
        this.constructor.prototype.unload = function ()
        {
            bpmext.ui.unloadView(this);
        };
    }
};