/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof TagInput
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof TagInput
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof TagInput
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof TagInput
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof TagInput
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof TagInput
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof TagInput
 * @method triggerFormulaUpdates
 */

 workplace_control_InitTagInput= function (taskUtils, wpResources, utilities, resourceUtils, domStyle, domClass, domAttr)
 {
     "use strict";
     this._instance =
     {
     };
 
     if (!this.constructor.prototype._proto)
     {
         this.constructor.prototype._proto =
         {
            EVT_ONLOAD : "eventON_LOAD",
            EVT_ONCHANGE : "eventON_CHANGE",
 
             _setViewData: function _setViewData(view, data, createPseudoBinding){
                 var ctx = view.context;
                 if(ctx){
                     if(ctx.binding){
                         ctx.binding.set("value", data);
                     } else if (createPseudoBinding) {
                         ctx.binding = bpmext.ui.substituteObject(view);
                         ctx.binding.set("value", data);
                     }
                 }
              },
 
              _initializeBinding: function(view) {
                view.context.options.tags.set("value", view._instance.tags);
                this._setViewData(view._instance.tagContainer, view._instance.tags,true);
             },
             
              _setTagText: function (view, stringValue) {
                 view._instance.badgeText.setLabel(stringValue);
                 view._instance.badge.setVisible(true);
             },
             
         };
 
 
         /*
         Public control methods *************************************************************
          */

         /**
          * @instance
          * @memberof TagInput
          * @method loadTagData
          * @desc Handler for loading the tag
          */
          this.constructor.prototype.loadTagData = function loadTagData(target) {
            bpmext.log.info("TagInput.loadTagData ENTER >>", this);

            var label = this._instance.tags[target.ui.getIndex()];
            if (label){
                var labelElt = target.context.element.querySelector(".Output_Text");
                labelElt.textContent = label.replaceAll('\\;', ';');
                target.setVisible(true);
            }

            bpmext.log.info("TagInput.loadTagData EXIT >>", this);
        };
 
         /**
          * @instance
          * @memberof TagInput
          * @method addTag
          * @desc Add tag based on label given
          */
         this.constructor.prototype.addTag = function addTag(label) {
             bpmext.log.info("TagInput.addTag ENTER >>", this);
 
             // Check if label is already in the list
             if (label != "" && !this._instance.tags.includes(label)){
                this._instance.tags.push(label);
                this._instance.tagContainer.context.binding.get("value").add(label);
                bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONCHANGE)
                this._instance.tagContainer.setVisible(true);
                this.setPlaceholder();
             }

             bpmext.log.info("TagInput.addTag EXIT >>", this);
         };
 
         /**
          * @instance
          * @memberof TagInput
          * @method removeTag
          * @desc Remove handler for the tag displayed
          */
          this.constructor.prototype.removeTag = function (target) {
             bpmext.log.info("TagInput.removeTag ENTER >>", this);
 
             var badge = target.context.element.parentElement.parentElement;
             var label = badge.querySelector(".Output_Text").textContent;
             badge.style.display = 'none';
 
             // Remove label from list of tags
             var index = this._instance.tags.indexOf(label);
             if (index > -1) { 
                this._instance.tags.splice(index, 1);
                this._instance.tagContainer.context.binding.get("value").remove(index); 
                bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONCHANGE);
             }

             this.setPlaceholder();

             bpmext.log.info("TagInput.removeTag EXIT >>", this);
         };

         /**
          * @instance
          * @memberof TagInput
          * @method removeAllTags
          * @desc Remove all tags
          */
          this.constructor.prototype.removeAllTags = function () {
            bpmext.log.info("TagInput.removeAllTags ENTER >>", this);

            this._instance.tags = [];
            this._proto._initializeBinding(this);
            bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONCHANGE);
            this._instance.tagContainer.setVisible(true);
            this._instance.textInput.setPlaceholder(bpmext.localization.formatMsg("savedSearchBuilder", "tagInputPlaceholder"));

            bpmext.log.info("TagInput.removeAllTags EXIT >>", this);
        };
 
         /**
          * @instance
          * @memberof TagInput
          * @method getData
          * @desc Gets the tags that are displayed
          */
          this.constructor.prototype.getData = function () {
            var tags = this._instance.tags.filter(function(element) {
                return element !== '';
              });
             return tags.join(";");
         };

         /**
          * @instance
          * @memberof TagInput
          * @method setData
          * @desc Sets the tags to display
          */
          this.constructor.prototype.setData = function (tags) {
            bpmext.log.info("TagInput.setData ENTER >>", this);

            // Split string by ; unless preceded by \\
            this._instance.tags = []
            var current = 0;
            for (var i = 0; i < tags.length; i++) {
                if(tags.charAt(i) == ";"){
                    if (i != 0 && tags.charAt(i-1) != "\\"){
                        this._instance.tags.push(tags.substring(current, i));
                        current = i + 1;
                    }
                }
            }
            if (current > 0){
                this._instance.tags.push(tags.substring(current, tags.length));
            }else{
                this._instance.tags.push(tags.substring(0, tags.length));
            }
            this._proto._initializeBinding(this);
            this._instance.tagContainer.setVisible(true);
            this.setPlaceholder();

            bpmext.log.info("TagInput.setData EXIT >>", this);
        };

        /**
          * @instance
          * @memberof TagInput
          * @method setPlaceholder
          * @desc Display placeholder when there are less than 2 tags
          */
         this.constructor.prototype.setPlaceholder = function () {
            if (this._instance.tags.length < 2){
                this._instance.textInput.setPlaceholder(bpmext.localization.formatMsg("savedSearchBuilder", "tagInputPlaceholder"));
                this._instance.intInput.setPlaceholder(bpmext.localization.formatMsg("savedSearchBuilder", "tagInputPlaceholder"));
                this._instance.decInput.setPlaceholder(bpmext.localization.formatMsg("savedSearchBuilder", "tagInputPlaceholder"));
            }else{
                this._instance.textInput.setPlaceholder("");
                this._instance.intInput.setPlaceholder("");
                this._instance.decInput.setPlaceholder("");
            }

        };

        /**
          * @instance
          * @memberof TagInput
          * @method setInputType
          * @desc Set input type (0 - String, 1 - Integer, Decimal - 2)
          */
         this.constructor.prototype.setInputType = function (index) {
            this._instance.stack.setCurrentPane(index);
        };
         
         /*
         Coach NG Lifecycle methods *************************************************************
          */
         this.constructor.prototype.load = function ()
         {
             bpmext.log.info("TagInput.load ENTER >>", this);
 
             var view = this, opts = this.context.options;
 
             if (!opts.tags) {
                 bpmext.ui.substituteConfigOption(this, "tags", []);
             }
 
             this._instance.tags = opts.tags.get('value').get("items") || [];
 
             this._instance.outer_HL = bpmext.ui.getContainer("Horizontal_Layout", this);
             this._instance.stack = bpmext.ui.getContainer("Stack", this);
             this._instance.tagContainer = bpmext.ui.getContainer("Tag_Container", this);
             this._instance.badge = bpmext.ui.getContainer("Badge", this);
             this._instance.badgeText = bpmext.ui.getView("Badge_Text", this);
             this._instance.removeIcon = bpmext.ui.getView("Remove_Icon", this);
             this._instance.textInput = bpmext.ui.getView("Text_Input", this);
             this._instance.intInput = bpmext.ui.getView("Integer", this);
             this._instance.decInput = bpmext.ui.getView("Decimal", this);

             this._proto._initializeBinding(this);
             this._instance.textInput.setPlaceholder(bpmext.localization.formatMsg("savedSearchBuilder", "tagInputPlaceholder"));
             this._instance.intInput.setPlaceholder(bpmext.localization.formatMsg("savedSearchBuilder", "tagInputPlaceholder"));
             this._instance.decInput.setPlaceholder(bpmext.localization.formatMsg("savedSearchBuilder", "tagInputPlaceholder"));
 
             // Event Handlers
             bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONLOAD);
             bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONCHANGE);

             this._instance.textInput.context.element.onkeydown = function(e) {
                 if(e.key === "Enter"){
                     var label = view._instance.textInput._instance.text.value.replaceAll(';', '\\;');
                     if(label != ""){
                        view.addTag(label);
                    }
                     view._instance.textInput._instance.text.value = "";
                 }
             }

             this._instance.textInput.context.element.addEventListener("focusin", function(e){
                view._instance.outer_HL.context.element.classList.add("active");
            });

             this._instance.textInput.context.element.onclick = function(e) {
                view._instance.outer_HL.context.element.classList.add("active");
            }

            this._instance.textInput.context.element.addEventListener("focusout", function(e){
                view._instance.outer_HL.context.element.classList.remove("active");
                var label = view._instance.textInput._instance.text.value.replaceAll(';', '\\;');
                if(label != ""){
                    view.addTag(label);
                }
                view._instance.textInput._instance.text.value = "";
            });

            // Integer Input Event Handlers
            this._instance.intInput.context.element.onkeydown = function(e) {
                if(e.key === "Enter"){
                    var label = view._instance.intInput._instance.text.value.replaceAll(';', '\\;');
                    if(label != ""){
                        view.addTag(label);
                    }
                    view._instance.intInput.setValue();
                }
            }

            this._instance.intInput.context.element.addEventListener("focusin", function(e){
               view._instance.outer_HL.context.element.classList.add("active");
           });

            this._instance.intInput.context.element.onclick = function(e) {
               view._instance.outer_HL.context.element.classList.add("active");
           }

           this._instance.intInput.context.element.addEventListener("focusout", function(e){
               view._instance.outer_HL.context.element.classList.remove("active");
               var label = view._instance.intInput._instance.text.value.replaceAll(';', '\\;');
               if(label != ""){
                view.addTag(label);
               }
               view._instance.intInput.setValue();
           });

           // Decimal Input Event Handlers
           this._instance.decInput.context.element.onkeydown = function(e) {
                if(e.key === "Enter"){
                    var label = view._instance.decInput._instance.text.value.replaceAll(';', '\\;');
                    if(label != ""){
                        view.addTag(parseFloat(label).toFixed(2));
                    }
                    view._instance.decInput.setValue();
                }
            }

            this._instance.decInput.context.element.addEventListener("focusin", function(e){
                view._instance.outer_HL.context.element.classList.add("active");
            });

            this._instance.decInput.context.element.onclick = function(e) {
                view._instance.outer_HL.context.element.classList.add("active");
            }

            this._instance.decInput.context.element.addEventListener("focusout", function(e){
                view._instance.outer_HL.context.element.classList.remove("active");
                var label = view._instance.decInput._instance.text.value.replaceAll(';', '\\;');
                if(label != ""){
                    view.addTag(parseFloat(label).toFixed(2));
                }
                view._instance.decInput.setValue();
            });
 
 
             this.loadContainer(this);
 
             bpmext.log.info("TagInput.load EXIT >>", this);
         };
 
         this.constructor.prototype.view = function ()
         {
             try
             {
                 utilities.handleVisibility(this.context);
             }
             catch (e)
             {
                 //{#feature: US-1330 Added RT localization}
                 bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e, this);
                 if (e.stack) {
                     //bpmext.log.error("  Call stack: " + e.stack);
                     bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack), this);
                 }
             }
         };
 
         this.constructor.prototype.change = function (event)
         {
             bpmext.log.info("TagInput.change ENTER >> (event): " + event, this);
             if (event && event.type === "config") {
                 switch (event.property) {
                     case "_metadata.visibility": {
                         this.view();
                         break;
                     }
                 }
             }
             bpmext.log.info("TagInput.change ENTER >>", this);
         };
 
         this.constructor.prototype.unload = function ()
         {
             bpmext.ui.unloadView(this);
         };
     }
 };