/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define("com.ibm.bpm.workplace.resources/WPResources", [
    "dojo/aspect",
    "dojo/Deferred",
    "com.ibm.bpm.coach/ViewContext",
    "./resourceBase",
    "./REPResource",
    "./TaskResource",
    "./ExposedResource",
    "./SystemsResource",
    "./GlobalTeamsResource",
    "./UsersResource",
    "./TasksResource",
    "./SearchesResource",
    "./AvatarResource",
    "./ProcessResource",
    "./ProcessesResource",
    "./CasesResource",
    "./UserResource",
    "./SocialResource",
    "./Notifications",
    "./SessionResource",
    "./TeamPerformanceResource",
    "./ServiceResource",
    "./AdhocActivityResource"
], function (
    aspect,
    Deferred,
    ViewContext,
    resourceBase,
    config,
    task,
    exposed,
    systems,
    teams,
    users,
    tasks,
    searches,
    avatar,
    process,
    processes,
    cases,
    user,
    social,
    notifications,
    session,
    teamPerformance,
    service,
    adhocActivity
) {
    "use strict";
    var PFS_SUFFIX = "", // PFS suffix is an empty string since there is only one instance of PFS in the platform
        PFS_KEY_ALIAS = "PFS",
        BAW_KEY_ALIAS = "WORKFLOW",
        RESOURCES = {
            config: config,
            task: task,
            tasks: tasks,
            exposed: exposed,
            systems: systems,
            teams: teams,
            users: users,
            searches: searches,
            avatar: avatar,
            process: process,
            processes: processes,
            cases: cases,
            user: user,
            social: social,
            notifications: notifications,
            session: session,
            teamPerformance: teamPerformance,
            service: service,
            adhocActivity: adhocActivity
        },
        cachedContext = new ViewContext();

    // hook before and after advices
    // ***** BIG GIANT NOTE: AOP wraps the original function, so you will lose the prototype of it *****

    aspect.around(resourceBase, "makeRequest", function advisedMakeRequest(originalMakeRequest) {
        /**
         * Seamlessly handle different env types:
         * AE:
         *      * URL needs to be re-written.
         *      * Need to get all system IDs before making the REST Call
         *      * Inject systemID into the response
         *      * Report offending system in error message when errors occur
         * PFS:
         *      * Need to get all system IDs before making the REST Call
         *      * Inject systemID into the response
         *      * Report offending system in error message when errors occur
         * Standalone:
         *      * No intervention needed, just make the REST call
         *      * Report offending system in error message when errors occur
         */
        return function advisedMakeRequest(url, options) {
            var keyName, suffix, systemID, promise;
            options = options || {};
            systemID =
                (options.systemID !== "undefined" && options.systemID !== "null" && options.systemID) || undefined;
            if (!options.skipInterceptor) {
                // check if we are running as an App
                if (resourceBase.isAppEngine) {
                    // add CSRF header into the request
                    options.headers = options.headers || {};
                    options.headers[cachedContext.getCSRFTokenHeaderName()] = cachedContext.getCSRFToken();
                    // the URL is federated and going to PFS
                    if (url.indexOf("federated") >= 0) {
                        keyName = PFS_KEY_ALIAS;
                        suffix = PFS_SUFFIX;
                    } else {
                        // URL is not federated
                        keyName = BAW_KEY_ALIAS;
                        suffix = systemID;
                        if (!suffix) {
                            // if we are not given a systemID then default one for us
                            promise = systems.getFederationResults().then(function success(results) {
                                suffix = results.fallback.systemID;
                                // rewrite the URI and return the new request options
                                url = cachedContext.rewriteURI(url, keyName, suffix);
                                // log out that we are using a default systemID
                                console.warn("[Workplace] Using default systemID: " + suffix + " for URL: " + url);
                                // add the system id to the options
                                options.systemID = suffix;
                                return originalMakeRequest.call(resourceBase, url, options);
                            });
                        }
                    }
                    if (!promise) {
                        url = cachedContext.rewriteURI(url, keyName, suffix);
                    }
                    promise = promise || originalMakeRequest.call(resourceBase, url, options);

                    // We activate cometD client here because cachedContext would have been initialized at this point
                    RESOURCES.notifications.activate(cachedContext);
                } else if (resourceBase.isFederated && url.indexOf(resourceBase.contextRoot.federatedURL) === -1) {
                    // going to a federated BAW
                    promise = session.getToken().then(function (data) {
                        return systems.getFederationResults().then(function success(results) {
                        	// instead of directly set to the fallback systemID we first match the context root
                        	if(!systemID) {
                        		for (var res in results) {
                        			if(results[res].contextRoot && url.indexOf(results[res].contextRoot) != -1) {
                        				systemID = results[res].systemID;
                        			}
                        		}
                        	}
                            var federatedSystem = results[systemID || "fallback"];
                            if (url.indexOf("http") !== 0) {
                                //correct the url if a different context root is configured, the default one is with current resourceBase.contextRoot.rest,need replace it with the accurate one from federation result
                                if(url.indexOf(resourceBase.contextRoot.rest) === 0) {
                                	url = federatedSystem.restUrlPrefix + url.substr(resourceBase.contextRoot.rest.length);
                                } else {
                                	url = federatedSystem.endpoint + url;
                                }
                            }
                            // add the systemID to options
                            options.systemID = federatedSystem.systemID;
                            if (data && data.headerValue) {
                                options.headers = options.headers || {};
                                options.headers[data.headerName] = data.headerValue;
                            }
                            return originalMakeRequest.call(resourceBase, url, options);
                        });
                    });
                } else {
                    // going to PFS directly or BAW in standalone mode
                    promise = session.getToken().then(function (data) {
                        if (data && data.headerValue) {
                            options.headers = options.headers || {};
                            options.headers[data.headerName] = data.headerValue;
                            // For SaaS platform, need pass the former cookie info to PFS
                            options.withCredentials = true;
                        }
                        return originalMakeRequest.call(resourceBase, url, options);
                    });
                }
            } else {
                delete options.skipInterceptor;
                promise = originalMakeRequest.call(resourceBase, url, options);
            }
            promise.then(
                function success(res) {
                    // isFederated is true when in AE
                    if (res && resourceBase.isFederated) {
                        res.systemID = options.systemID;
                    }
                    return res;
                },
                function error(err) {
                    if (err && err.response) {
                        if (err.response.status <= 0) {
                            resourceBase.showError(bpmext.localization.formatMsg("Errors", "serverDown"), err);
                        } else if (err.response.status === 401 && err.response.text) {
                            // task API returns 401 when you don't own a task
                            resourceBase.showError(bpmext.localization.formatMsg("Errors", "sessionIsInvalid"), err);
                        }
                    }
                    throw err;
                }
            );
            return promise;
        };
    });

    // set the AE locale onto the backing PS system
    if (resourceBase.isAppEngine) {
        aspect.around(RESOURCES.user, "get", function advisingFactory_get(originalGet) {
            var wasLocaleUpdated,
                innerDeferred = new Deferred();

            return function advisedGet() {
                if (innerDeferred.isFulfilled()) {
                    // locale was set, return the promise from the originalGet
                    return originalGet.apply(null, arguments);
                } else {
                    // locale was not set, lets do it
                    if (!wasLocaleUpdated) {
                        // there is no inflight request to set the locale
                        var prefs = {},
                            handleResponseFromOriginalGet = function handleResponseFromOriginalGet() {
                                innerDeferred.resolve.apply(null, arguments);
                            },
                            rejectResponseFromOriginalGet = function rejectResponseFromOriginalGet() {
                                innerDeferred.reject.apply(null, arguments);
                            },
                            invokeOriginalGetAndFulfill = function invokeOriginalGetAndFulfill() {
                                originalGet
                                    .apply(null, arguments)
                                    .then(handleResponseFromOriginalGet, rejectResponseFromOriginalGet);
                            };

                        prefs[RESOURCES.user.PREFERENCE.locale] = dojoConfig.locale || "en";
                        RESOURCES.user
                            .setPreferences({ preferences: prefs })
                            .then(invokeOriginalGetAndFulfill, invokeOriginalGetAndFulfill);

                        // I only need to come in here once
                        wasLocaleUpdated = true;
                    }
                    return innerDeferred.promise;
                }
            };
        });
    }

    aspect.around(RESOURCES.exposed, "get", function advisingFactory_get(originalGet) {
        return function advisedGet() {
            var originalArgs = arguments,
                promise;
            // ensure that we set user prefs before we get list of launchable entities
            if (resourceBase.isAppEngine) {
                promise = RESOURCES.user.get().then(function () {
                    return originalGet.apply(null, originalArgs);
                });
            } else {
                promise = originalGet.apply(null, originalArgs);
            }
            /**
             * Add a convenience "launch" method to the process object to launch the process using the process's own startURL
             * calling "launch" will return a promise that resolves to the Process Instance and Task Instance data
             */
            return promise.then(function success(res) {
                var items = (resourceBase.isFederated && res.items) || res; // federated system or non-federated
                function addLaunchPoint(item) {
                    if (item.type === "process" && item.startURL) {
                        if (item.systemID && resourceBase.isAppEngine) {
                                // AE will affix protocol, hostname, port, and context root
                                item.startURL = item.startURL.substring(item.startURL.indexOf("/v1/process"));
                        }
                        item.launch = function launch() {
                            return resourceBase
                                .post(this.startURL, {
                                    query: {
                                        parts: ["header", "excludeTaskData", "excludeDocs"].join(),
                                        // add snapshot id to default snapshots installed on PS
                                        snapshotId:
                                            this.isDefault && !this.tip && this.startURL.indexOf("snapshotId=") === -1
                                                ? this.snapshotID
                                                : undefined
                                    },
                                    systemID: this.systemID
                                })
                                .then(function success(res) {
                                    // add systemID to the returned object
                                    if (res.systemID) {
                                        res.data.systemID = res.systemID;
                                    }
                                    return res.data;
                                });
                        };
                    }
                    return item;
                }
                function filterItems(item) {
                    return item.processAppAcronym !== "SYSRP" && item.processAppAcronym !== "TWP";
                }

                items = (items || []).filter(filterItems).map(addLaunchPoint);

                if (resourceBase.isFederated) {
                    res.items = items;
                } else {
                    res = items;
                }
                return res;
            });
        };
    });

    /**
     *  Add modifyTask property to currentUser object
     */
    aspect.after(RESOURCES.user, "get", function advisingFactory_get(promise) {
        return promise.then(function success(res) {
            return config.get().then(function success(configs) {
                var showNextTaskDashboard = false, defaultNextTaskSavedSearch = null, returnTaskToTeamOnLogout = false, autoClaimNextTask = false,
                    result = {},
                    groupCheck = function groupCheck(membership) {
                        return res.memberships && res.memberships.indexOf(membership) > -1;
                    };
                /* logic is as follows:
                        check if there are groups defined in the mashups config, there are
                            1. groups to modify all the task properties
                            2. groups to modify dueDate
                            3. groups to modify priority
                            4. groups to modify task assignment
                    */
                // we check for ALL, if it is defined then check if the user is in that group(s) or not, if not defined means  user can modify the tasks
                result.any = configs.restrictModifyTask.all ? configs.restrictModifyTask.all.some(groupCheck) : true;

                if (result.any) {
                    // we check for other groups, if it is defined then check if the user is in that group(s) or not,
                    // if not defined means the user can modify that property
                    result.reassign = configs.restrictModifyTask.reassign ? configs.restrictModifyTask.reassign.some(groupCheck) : true;
                    result.due = configs.restrictModifyTask.due ? configs.restrictModifyTask.due.some(groupCheck) : true;
                    result.priority = configs.restrictModifyTask.priority ? configs.restrictModifyTask.priority.some(groupCheck) : true;

                    // recompute "any" to make sure it reflects the subgroups
                    result.any = result.reassign || result.due || result.priority;
                }
                res.modifyTask = result;

                // add next task dashboard info to currentUser object
                if( configs.showNextTaskDashboard) {
	        		if(configs.showNextTaskDashboard.indexOf("all") !== -1) {
	        			showNextTaskDashboard = true;	            		
	        		} else {
                        showNextTaskDashboard = configs.showNextTaskDashboard.some(groupCheck);
                    }
	        		
                    if( configs.defaultNextTaskSavedSearch && configs.defaultNextTaskSavedSearch.length > 0 ) {
                        defaultNextTaskSavedSearch =  configs.defaultNextTaskSavedSearch;
                    }
                    
                    if (configs.returnTaskToTeamOnLogout) {
						if(configs.returnTaskToTeamOnLogout.indexOf("all") !== -1) {
							returnTaskToTeamOnLogout = true;	            		
						} else {
                            returnTaskToTeamOnLogout = configs.returnTaskToTeamOnLogout.some(groupCheck);      
						}
					}
                    
                    if (configs.autoClaimNextTask) {
						if(configs.autoClaimNextTask.indexOf("all") !== -1) {
							autoClaimNextTask = true;	            		
						} else {
							autoClaimNextTask = configs.autoClaimNextTask.some(groupCheck);      
						}
					}
                    res.showNextTaskDashboard = showNextTaskDashboard;
                    res.defaultNextTaskSavedSearch = defaultNextTaskSavedSearch;
                    res.returnTaskToTeamOnLogout = returnTaskToTeamOnLogout;
                    res.autoClaimNextTask = autoClaimNextTask;
        		}
                

                return res;
            });
        });
    });

    // check if we are in a non app-scenario
    if (!resourceBase.isAppEngine) {
        // bootstrap system information
        RESOURCES.systems.get();
        // bootstrap the user preferences
        RESOURCES.user.get();
        // bootstrap the mashups config params
        RESOURCES.config.get();
        // activate notification when not federated
        //if (!resourceBase.isFederated || (cachedContext.isWorkflowPXServer && cachedContext.isWorkflowPXServer() === true)) {
        // activate CometD client
        	RESOURCES.notifications.activate();
    	//}
    }

    RESOURCES.contextRoot = resourceBase.contextRoot;
    RESOURCES.isFederated = resourceBase.isFederated;
    RESOURCES.isAppEngine = resourceBase.isAppEngine;

    return RESOURCES;
});
