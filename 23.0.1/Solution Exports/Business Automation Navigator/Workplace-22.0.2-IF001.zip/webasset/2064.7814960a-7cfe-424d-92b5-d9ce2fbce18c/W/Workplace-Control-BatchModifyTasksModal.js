/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
 /**
 * @ignore
 * @instance
 * @memberof BatchModifyTasksModal
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof BatchModifyTasksModal
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof BatchModifyTasksModal
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof BatchModifyTasksModal
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof BatchModifyTasksModal
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof BatchModifyTasksModal
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof BatchModifyTasksModal
 * @method triggerFormulaUpdates
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 * </table>
 */
workplace_control_InitBatchModifyTasksModal = function (utilities, taskUtils, wpResources)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            _ACTIONS: {
                date: "ACTION_UPDATEDUEDATE",
                priority :"ACTION_UPDATEPRIORITY",
                toUser :"ACTION_REASSIGNTOUSER",
                backToGroup: "ACTION_REASSIGNTOGROUP"
            },

            _canUserModifyTask: function (view) {
                var success = function (user) {
                    if (user.modifyTask) {
                        view._instance.modifyTask = user.modifyTask;
                        view._instance.defaultRosters = [{
                            name: user.userName
                        }];
                    } else {
                        view._instance.modifyTask = null;
                        bpmext.log.error("Unable to get modify task user info");
                    }
                }

                var error = function (error) {
                    bpmext.log.error(error.message);
                }

                wpResources.user.get().then(dojo.hitch(view, success), error);
            },

            _loadModal: function _loadModal(view) {
                bpmext.log.info("BatchModifyTasksModal._loadModal LOG >> ", view);

                view._proto._resetViews(view);

                // Show modify task modal
                view.showModal();

                if (view._instance.assignToSelector.isVisible()) {
                    if (view._instance.rosters) {
                        view._proto._loadRosters(view);
                    } else if (view._instance.teamId) {
                        view._proto._fetchRosters(view, view._instance.teamId);
                    }
                }
            },

            _resetViews: function _resetViews(view) {
                view._instance.updateDueCheckbox.setVisible((view._instance.modifyTask || {}).due, true);
                view._instance.prioritySelector.setVisible((view._instance.modifyTask || {}).priority, true);
                view._instance.assignToSelector.setVisible((view._instance.modifyTask || {}).reassign, true);

                view._instance.prioritySelector.setSelectedItemAt(0);
                view._instance.assignToSelector.clearItems();
                view._instance.updateDueCheckbox.setChecked(false);
                view._instance.updateDueCheckbox._instance.input.removeAttribute("aria-required");
                view._instance.modalSection.setPrimaryButtonEnabled(false);
            },

            _loadRosters: function _loadRosters(view) {
                bpmext.log.info("BatchModifyTasksModal._loadRosters LOG >> ", view);
                if (view._instance.rosters) {
                    view._instance.assignToSelector.appendItem(null, bpmext.localization.formatMsg("BatchModifyTasks", "unchanged"));
                    view._instance.assignToSelector.appendItem("backToGroup", bpmext.localization.formatMsg("BatchModifyTasks", "assignBackToGroup"));
                    view._instance.rosters.forEach(function (roster) {
                        view._instance.assignToSelector.appendItem(roster.name, roster.name);
                    });

                    view._instance.assignToSelector.setSelectedItemAt(0);
                }
            },

            _fetchRosters: function _fetchRosters (view, teamId) {
                bpmext.log.info("BatchModifyTasksModal._fetchRosters >>: ", view);

                var success = function (data) {
                    view._instance.rosters = data.teamMemberList || [];
                    view._proto._loadRosters(view);
                };

                var fail = function (error) {
                    !!error && !!error.errorMessage && taskUtils.publishError(error.errorMessage);
                    bpmext.log.error("ERROR >> There was an error fetching the rosters: " + error);
                };

                wpResources.teamPerformance.getTeamMembersByID({
                    teamId: teamId
                }).then(
                    success,
                    fail
                );
            },

            _updateDate: function _updateDate(task, newDate) {
                return wpResources.task.setDueDate({
                    tkiid: task["TASK.TKIID"] || task.tkiid,
                    systemID: task.systemID,
                    dueDate: newDate
                });
            },

            _updatePriority: function _updatePriority(task, newPriority) {
                return wpResources.task.setPriority({
                    tkiid: task["TASK.TKIID"] || task.tkiid,
                    systemID: task.systemID,
                    priority: newPriority
                });
            },

            _assignBackToGroup: function _assignBackToGroup(task) {
                return wpResources.task.assignBackToGroup({
                    tkiid: task["TASK.TKIID"] || task.tkiid,
                    systemID: task.systemID
                });
            },

            _assignToUser: function _assignToUser(task, newUser) {
                return wpResources.task.assignToUser({
                    tkiid: task["TASK.TKIID"],
                    systemID: task.systemID,
                    username: newUser
                });
            },

            _batchUpdates: function (view) {
                var updates = {};

                if (view._instance.updateDueCheckbox.isChecked() && view._instance.dueDateTimePicker.isVisible()) {
                    var newDate = view._instance.dueDateTimePicker.getDate();
                    if (newDate) {
                        updates.newDate = newDate;
                    }
                }

                if(view._instance.prioritySelector.isVisible()){
                    var newPriority = view._instance.prioritySelector.getData();
                    if (!!newPriority && newPriority !== "null") {
                        updates.newPriority = newPriority;
                    }
                }

                if(view._instance.assignToSelector.isVisible()){
                    var newAssignee = view._instance.assignToSelector.getData();
                    if (newAssignee === "backToGroup") {
                        updates.backToGroup = true;
                    } else if (!!newAssignee && newAssignee !== "null") {
                        updates.assignedUser = true;
                        updates.newAssignee = newAssignee;
                    }
                }
                if (JSON.stringify(updates) !== "{}") {
                    (view._instance.tasks || []).forEach(function (task) {
                        view._proto._postTaskInfo(view, task, updates);
                    });
                }
            },

            _minimizeUpdates: function _minimizeUpdates (task, updates) {
                var isChanged = {};

                var due = task["DUE"] || task.duetime;
                if (updates.newDate && updates.newDate.getTime) {
                    isChanged.date = (new Date(due)).getTime() !== updates.newDate.getTime();
                }

                var priority = task["PRIORITY"] || task.priority;
                if (updates.newPriority) {
                    isChanged.priority = (priority.toString() || "") !== updates.newPriority;
                }

                var owner = task["OWNER"] || task.owner;
                if (updates.backToGroup) {
                    isChanged.assignedToGroup = !!owner;
                } else if (updates.assignedUser) {
                    isChanged.assignedToUser = owner !== updates.newAssignee;
                }

                return isChanged;
            },

            _postTaskInfo: function _postTaskInfo(view, task, updates) {
                bpmext.log.info("BatchModifyTasksModal._postTaskInfo LOG >>", view);

                var isChanged = view._proto._minimizeUpdates(task, updates);

                var updateTask = function (view, task, updates, isChanged) {
                    if(isChanged.date && isChanged.priority){
                        view._proto._updateDate(task, updates.newDate).then(function () {
                            view._proto._updatePriority(task, updates.newPriority);
                        });
                    } else if(isChanged.date){
                        view._proto._updateDate(task, updates.newDate);
                    } else if(isChanged.priority){
                        view._proto._updatePriority(task, updates.newPriority);
                    }
                };

                try {
                    //Synchronous assignment and updates
                    if(updates.backToGroup){
                        view._proto._assignBackToGroup(task).then(function(){
                            updateTask(view, task, updates, isChanged);
                        });
                    }else if(updates.assignedUser){
                        view._proto._assignToUser(task, updates.newAssignee).then(function(){
                            updateTask(view, task, updates, isChanged);
                        });
                    }else{
                        updateTask(view, task, updates, isChanged);
                    }
                } catch (error) {
                    bpmext.log.error(error.message);
                }
            },

            _initPrioritySelector: function _initPrioritySelector (view) {
                view._instance.prioritySelector.appendItem(null, bpmext.localization.formatMsg("BatchModifyTasks", "unchanged"));
                for (var priorityLevel in taskUtils.PRIORITY) {
                    var priorityLevelValue = taskUtils.PRIORITY[priorityLevel];
                    view._instance.prioritySelector.appendItem(priorityLevelValue, taskUtils.getPriorityLabel(priorityLevelValue));
                }
            },

            _localizationLabels: function _localizationLabels (view) {
                view._instance.modalSection._instance.modalDialog.ariaLabel = bpmext.localization.formatMsg("BatchModifyTasks", "batchModifyTasks");
                view._instance.panel.setTitle(bpmext.localization.formatMsg("BatchModifyTasks", "batchModifyTasks"));
                view._instance.dueDateTimePicker.setLabel(taskUtils.getLabelFromTaskProperty("taskDueDate"));
                view._instance.prioritySelector.setLabel(taskUtils.getLabelFromTaskProperty("taskPriority"));
                view._instance.assignToSelector.setLabel(bpmext.localization.formatMsg("BatchModifyTasks", "assignTo"));
                view._instance.updateDueCheckbox.setLabel(bpmext.localization.formatMsg("BatchModifyTasks", "updateDueCheckbox"));
            }
        };


        /*
        Public control methods *************************************************************
        */

        /**
		 * @instance
		 * @memberof BatchModifyTasksModal
		 * @method showModal
		 * @desc Shows the modal dialog
		 */
        this.constructor.prototype.showModal = function() {
			bpmext.log.info("BatchModifyTasksModal.showModal ENTER >> ",this);
            this._instance.modalSection.show();
            this.show();
            taskUtils.setTabCycle(this);
			bpmext.log.info("BatchModifyTasksModal.showModal EXIT << ");
        };

         /**
		 * @instance
		 * @memberof BatchModifyTasksModal
		 * @method closeModal
		 * @desc Closes the modal dialog
		 */
        this.constructor.prototype.closeModal = function() {
			bpmext.log.info("BatchModifyTasksModal.closeModal ENTER >> ",this);
            this._instance.modalSection.setVisible(false, true);
            this.setVisible(false, true);
			bpmext.log.info("BatchModifyTasksModal.closeModal EXIT << ");
        };

         /**
		 * @instance
		 * @memberof BatchModifyTasksModal
		 * @method onClose
		 * @desc closes open dialogs
		 */
        this.constructor.prototype.onClose = function() {
            this._instance.dueDateTimePicker.close();
        };

         /**
		 * @instance
		 * @memberof BatchModifyTasksModal
		 * @method saveModal
		 * @desc Saves the data on the dialog
		 */
        this.constructor.prototype.saveModal = function() {
            bpmext.log.info("BatchModifyTasksModal.saveModal ENTER >> ", this);
            //Before saving check if date and assigned user is valid
            if (this.validateInput()) {
                this._proto._batchUpdates(this);
                this.closeModal();
                taskUtils.EVENTS.BATCH_MODIFY_TASKS_AFTER_SAVE.publish();
            }
			bpmext.log.info("BatchModifyTasksModal.saveModal EXIT << ");
        };


         /**
		 * @instance
		 * @memberof BatchModifyTasksModal
		 * @method validateInput
         * @returns {Boolean} the boolean value for the validity of the date time picker value
		 * @desc Controls the visibility of date picker and enables or disables the save button
		 */
        this.constructor.prototype.validateInput = function() {
            bpmext.log.info("BatchModifyTasksModal.validateInput ENTER >> ", this);

            var validPriority = this._instance.prioritySelector.getSelectedIndex() > 0;
            var validAssignTo = this._instance.assignToSelector.getSelectedIndex() > 0;
            var valid = validPriority || validAssignTo;

            var showUpdateDate = this._instance.updateDueCheckbox.isChecked();
            var validDate = this._instance.dueDateTimePicker.getDate() && this._instance.dueDateTimePicker.isValid();

            if (showUpdateDate && !validDate) {
                valid = false;
            } else if (showUpdateDate) {
                valid = valid || validDate;
            }

            this._instance.modalSection.setPrimaryButtonEnabled(valid);

            return valid;
        };

        /**
		 * @instance
		 * @memberof BatchModifyTasksModal
		 * @method toggleDueDatePicker
		 * @desc Toggle due date picker
		 */
        this.constructor.prototype.toggleDueDatePicker = function () {
            var isChecked = this._instance.updateDueCheckbox.isChecked();

            this.validateInput();
            this._instance.dueDateTimePicker.setVisible(isChecked, true);
            this._instance.dueDateTimePicker.close();

            !!isChecked && this._instance.dueDateTimePicker.clear();
        };

        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function () {
            bpmext.log.info("BatchModifyTasksModal.load ENTER >>", this);

            this._instance.modalSection = bpmext.ui.getContainer("ModalSection", this);
            this._instance.modalSection.setPrimaryButtonText(bpmext.localization.formatMsg("modifyTaskModal", "save"));
            this._instance.modalSection.setSecondaryButtonText(bpmext.localization.formatMsg("modifyTaskModal", "cancel"));

            //CV in ModalSection
            this._instance.panel = bpmext.ui.getContainer("Panel", this);

            //CV in Panel
            this._instance.prioritySelector = bpmext.ui.getView("PrioritySelector", this);
            this._instance.assignToSelector = bpmext.ui.getView("AssignToSelector", this);
            this._instance.dueDateTimePicker = bpmext.ui.getView("DueDateTimePicker", this);
            this._instance.updateDueCheckbox = bpmext.ui.getView("UpdateDueCheckbox", this);

            this._proto._canUserModifyTask(this);
            this._proto._initPrioritySelector(this);
            this._proto._localizationLabels(this);

            this.loadView(this);

            taskUtils.EVENTS.BATCH_MODIFY_TASKS.subscribe(function(eventName, eventData){
                var view = this;
                if (eventData.view === this.ui.getParent()) {
                    if (eventData.teamId) {
                        this._instance.teamId = eventData.teamId;
                        this._instance.rosters = eventData.rosters;
                    } else {
                        this._instance.teamId = null;
                        this._instance.rosters = this._instance.defaultRosters;
                    }

                    if ((eventData.tasks || []).length > 0) {
                        this._instance.tasks = eventData.tasks;
                        this._instance.federationResult = eventData.federationResult;

                        this._proto._loadModal(this);
                    }
                }
			}, this);

            bpmext.log.info("BatchModifyTasksModal.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try {
                utilities.handleVisibility(this.context);
            }
            catch (e){
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e, this);
                if(e.stack) {
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack), this);
                }
            }
        };

        this.constructor.prototype.change = function (event){
            bpmext.log.info("BatchModifyTasksModal.change ENTER >> (event): " + event, this);
            if (event.type === "config") {
                switch (event.property) {
                    case "_metadata.visibility": {
                        this.view();
                        break;
                    }
                }
            }
            bpmext.log.info("BatchModifyTasksModal.change ENTER >>", this);
        };

        this.constructor.prototype.unload = function (){
            bpmext.log.info("BatchModifyTasksModal.unload ENTER >> ", this);
            this.unloadView(this);
            bpmext.log.info("BatchModifyTasksModal.unload ENTER >>", this);
        };
    }
};