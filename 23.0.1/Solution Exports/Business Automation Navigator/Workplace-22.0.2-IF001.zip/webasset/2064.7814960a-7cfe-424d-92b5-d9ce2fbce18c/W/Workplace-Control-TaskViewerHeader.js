/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof TaskViewerHeader
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof TaskViewerHeader
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof TaskViewerHeader
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof TaskViewerHeader
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof TaskViewerHeader
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof TaskViewerHeader
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof TaskViewerHeader
 * @method triggerFormulaUpdates
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On Task Opened:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when a task or service is opened in the viewer</td>
 *               </tr>
 *           </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">data {object}</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">task or service data</td>
 *               </tr>
 *       </table>
 *     </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On Task Closed:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when the viewer is closed</td>
 *               </tr>
 * </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *               </tr>
 *           </table>
 *       </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On Task Action:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when an action is triggered from the action menu</td>
 *               </tr>
 * </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">data {object}</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">action {string}</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">task or service data</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">selected action</td>
 *               </tr>
 *       </table>
 *       </td>
 *   </tr>
 * </table>
 */
workplace_control_InitTaskViewerHeader = function (utilities, taskUtils, domConstruct, domClass, wpResources)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
			EVT_ONTASK_OPENED : "eventON_TASK_OPENED",
			EVT_ONTASK_CLOSED : "eventON_TASK_CLOSED",
			EVT_SERVICE_OPENED : "eventON_SERVICE_OPENED",
			EVT_SERVICE_CLOSED : "eventON_SERVICE_CLOSED",

			MODE : {
				TASK : "TASK",
				SERVICE : "SERVICE"
			},

			_buildDataListHTML : function(dataList){
				var toReturn = "", dataLabel, dataValue, dataLabelValue, dataTextValue;
				if (dataList) {
					for (var i = 0; i < dataList.length; i++) {
						if ((dataList[i].value + "") !== "") {
							dataLabel = dataList[i].label;
							dataLabelValue = taskUtils.getLabelFromTaskProperty(dataLabel);
							dataValue = dataList[i].value;
							dataTextValue = taskUtils.getLabelFromTaskProperty(dataValue);
							toReturn +=
								"<span class=\"businessDataItemWrapper\">"+
									"<span class=\"businessDataItem item\">" + dataLabelValue + " : </span>" +
									"<span class=\"businessDataValue\">" + dataTextValue + "</span>" +
								"</span>";

						}
					}
				}
				return toReturn;
			},

			_updateTaskHeaderDetails: function _updateTaskHeaderDetails(view, task) {
				// STATUS
                var image = "", url = taskUtils.getTaskDueStatusImageURL(task);
                if (url) {
					var altText = bpmext.localization.formatMsg("taskCard", "taskStatus");
                    image = "<span class='taskStatusIcon'><img src='" + url + "' alt='" + altText + "'></img></span>";
                }
                var statusSpan = domConstruct.toDom("<span>" + image + "</span>");
                view._instance.statusView.setData(statusSpan.outerHTML);

				bpmext.ui.util.showTooltip(
					view._instance.statusView._instance.outputText.firstElementChild,
					taskUtils.getStatusLabel(task),
					{horizontalPos: "LEFT", smartPositioning: true, openDelay: 0.5}
				);

				if(task.dueTime){
					view._instance.dueView.setText(taskUtils.formatDate(new Date(task.dueTime), true));
				}

				if(task.priority){
					view._instance.priorityView.setText(bpmext.localization.formatMsg("taskViewer", "priorityString", taskUtils.getPriorityLabel(task.priority)));
				}

				view._instance.taskId = task.tkiid;
			},

			_taskChangedNotificationHandler: function _taskChangedNotificationHandler(eventName, eventData) {
				if (this.isVisible()) {
					if (!!eventData && taskUtils.EVENTS.TASK_FIELD_CHANGED.equals(eventData.kind) && !!eventData.task && eventData.task.tkiid === this._instance.taskId) {
						var businessData = eventData.task.processData && eventData.task.processData.businessData;
						this.setTaskData(this, eventData.task, businessData);
					} else if (!taskUtils.getNotificationExistence()) {
						taskUtils.EVENTS.DELAY_RELOAD.publish();
					} else {
                        // Why are we reloading when this notification doesn't impact us???
                        //this._proto._fetchAndUpdateTask(this);
                        // we need to hold a reference to the throttled function so we don't create new copies of it
                        this.throttledFunc = this.throttledFunc || taskUtils.throttle(dojo.hitch(this._proto, "_fetchAndUpdateTask", this));
                        this.throttledFunc();
					}
				}
			},

			_updateSystemData: function(view, systemData, task) {
				var filteredSystemData = [];
				//Add basic task info to system data list
				var taskName, taskPriority, taskDueDate, taskStatus;
				if (task.name){
					taskName = { label : taskUtils.getLabelFromTaskProperty("taskSubject"), value : task.name};
					filteredSystemData.push(taskName);
				} else if (task.displayName) {
					taskName = { label : taskUtils.getLabelFromTaskProperty("taskActivityName"), value : task.displayName};
					filteredSystemData.push(taskName);
				}
				if (task.dueTime){
					taskDueDate = { label : taskUtils.getLabelFromTaskProperty("taskDueDate"), value : taskUtils.formatDate(new Date(task.dueTime), true)};
					filteredSystemData.push(taskDueDate);
				}
				if(task.priority){
					taskPriority = { label : taskUtils.getLabelFromTaskProperty("taskPriority"), value : taskUtils.getPriorityLabel(task.priority)};
					filteredSystemData.push(taskPriority);
				}
				taskStatus = { label : taskUtils.getLabelFromTaskProperty("taskStatus"), value : taskUtils.getStatusLabel(task)};
				filteredSystemData.push(taskStatus);

				for(var i = 0; systemData && (i < systemData.length); i++ ){
					var systemDataItemName = systemData[i].name,
						systemDataItemLabel = undefined,
						systemDataItemValue = undefined,
						systemDataItem = undefined;
					switch(systemDataItemName){
						case "instanceId" :
							systemDataItemLabel = systemData[i].value;
							systemDataItemValue = task["piid"];
							break;
						case "taskId" :
							systemDataItemLabel = systemData[i].value;
							systemDataItemValue = task["tkiid"];
							break;
						case "assignedToRoleDisplayName" :
							systemDataItemLabel = systemData[i].value;
							systemDataItemValue = task["teamDisplayName"];
							break;
					}

					if(systemDataItemValue){
						systemDataItem = { label : systemDataItemLabel, value : systemDataItemValue};
						filteredSystemData.push(systemDataItem);
					}
				}

				//set System Data
				view.constructor.prototype.setSystemData(view, filteredSystemData);
			},

			_fetchAndUpdateTask: function _fetchTask (view) {
                var task = view._instance.task;
				if (task) {
					wpResources.task.get({tkiid: task.tkiid, systemID: task.systemID}).then(function (data) {
						var businessData = data && data.processData && data.processData.businessData;
						view.setTaskData(view, data, businessData);
					});
				}
			}
        };

		/*
        Public control methods *************************************************************
         */

		/**
		 * @instance
		 * @memberof TaskViewerHeader
		 * @method setBusinessData
		 * @param {ANY} businessData data to be set
		 * @desc Sets the businessData
		 */
		this.constructor.prototype.setBusinessData = function(view, businessData) {
			bpmext.log.info("TaskViewerHeader.setBusinessData ENTER << setting data to: ", businessData);

			var businessDataHTML = this.constructor.prototype._proto._buildDataListHTML(businessData);
			view._instance.businessDataList.setText(businessDataHTML);

			bpmext.log.info("TaskViewerHeader.setBusinessData EXIT >> ");
		};

		/**
		 * @instance
		 * @memberof TaskViewerHeader
		 * @method setSystemData
		 * @param {ANY} systemData data to be set
		 * @desc Sets the systemData
		 */
		this.constructor.prototype.setSystemData = function(view, systemData) {
			bpmext.log.info("TaskViewerHeader.setBusinessData ENTER << setting data to: ", systemData);

			var systemDataHTML = this.constructor.prototype._proto._buildDataListHTML(systemData);
			view._instance.systemDataList.setText(systemDataHTML);

			bpmext.log.info("TaskViewerHeader.setBusinessData EXIT >> ");
		};

		/**
		 * @instance
		 * @memberof TaskViewerHeader
		 * @method setTaskData
		 * @param {ANY} task data to be set
		 * @param {ANY} businessData data to be set
		 * @param {ANY} systemData data to be set
		 * @desc Set task, businessData and systemData
		 */
		this.constructor.prototype.setTaskData = function(view, task, businessData, systemData) {
			bpmext.log.info("TaskViewerHeader.setData ENTER >> setting data to: ", task, businessData, systemData);

			view._instance.mode = view._proto.MODE.TASK;
			this.reset();
			view._proto._updateTaskHeaderDetails(view, task);

			if (view._instance.systemData === undefined) {
				view._instance.systemData = systemData;
			}

			if (view._instance.systemData === undefined) {
				//Still not set, so we need to fetch the system data
				wpResources.searches.getMetaFields()
				.then(function(sysData) {
					var isPXServer = view.context.isWorkflowPXServer && view.context.isWorkflowPXServer() === true,
						isCaseSupported = view.context.isCaseSupported && view.context.isCaseSupported() === true;
					view._instance.systemData = taskUtils.processColumns(sysData, taskUtils.getFieldsToHide(isPXServer || !isCaseSupported, false));
				});
			}

			bpmext.log.info("TaskViewerHeader.setData EXIT << ");
		};

		/**
		 * @instance
		 * @memberof TaskViewerHeader
		 * @method setServiceData
		 * @param {ANY} service data to be set
		 * @desc Sets the service
		 */
		this.constructor.prototype.setServiceData = function(view, service) {
			bpmext.log.info("TaskViewerHeader.setServiceData ENTER >> setting data to: ", service);

			view._instance.mode = view._proto.MODE.SERVICE;
			this.reset();
			bpmext.log.info("TaskViewerHeader.setData EXIT << ");
		};

        this.constructor.prototype.handleTaskAction = function(action) {
            bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONTASK_ACTION, this._instance.task, action);
		};

		/**
		 * @instance
		 * @memberof TaskViewerHeader
		 * @method openActionsMenu
		 * @desc open the actions menu
		 */
		this.constructor.prototype.openActionsMenu = function() {
			var task = this._instance.task;
			var menuButtonEle = this._instance.actionsButton && this._instance.actionsButton.context.element.querySelector("div.btn");

			if (menuButtonEle && this._instance.actionsMenu) {
				this._instance.actionsMenu.loadMenu(task.piid, task.tkiid, task.systemID, task.IS_WORKSTREAM, null, menuButtonEle);
			}
		};

		/**
		 * @instance
		 * @memberof TaskViewerHeader
		 * @method onActionsMenuOpen
		 * @desc while opening the actions menu
		 */
		this.constructor.prototype.onActionsMenuOpen = function() {
			var menuButtonEle = this._instance.actionsButton && this._instance.actionsButton.context.element.querySelector("div.btn");
			menuButtonEle && domClass.add(menuButtonEle,"active");
		};

		/**
		 * @instance
		 * @memberof TaskViewerHeader
		 * @method onActionsMenuClose
		 * @desc while closing the actions menu
		 */
		this.constructor.prototype.onActionsMenuClose = function() {
			var menuButtonEle = this._instance.actionsButton && this._instance.actionsButton.context.element.querySelector("div.btn");
			menuButtonEle && domClass.remove(menuButtonEle,"active");
		};

		/**
		 * @instance
		 * @memberof TaskViewerHeader
		 * @method hideCloseButton
		 * @desc Hides the close button
		 */
		this.constructor.prototype.showCloseButton = function() {
			this._instance.closeButton.setVisible(true,true);
		};

		/**
		 * @instance
		 * @memberof TaskViewerHeader
		 * @method closeViewer
		 * @desc Hides the close button
		 */
		this.constructor.prototype.closeViewer = function() {
			taskUtils.EVENTS.CLOSE_TASK_VIEWER.publish();
		};

		/**
		 * @instance
		 * @memberof TaskViewerHeader
		 * @method reset
		 * @desc Hides the close button
		 */
		this.constructor.prototype.reset = function() {
			this._instance.actionsMenu.close();
		};


		/*
        Coach NG Load Lifecycle method *************************************************************
         */
        this.constructor.prototype.load = function ()
        {
			var view = this;

            bpmext.ui.substituteConfigOption(this, "task", []);
			bpmext.ui.substituteConfigOption(this, "systemData", []);
			bpmext.ui.substituteConfigOption(this, "taskActions", []);
			bpmext.ui.substituteConfigOption(this, "showOnTaskClosed", false);

			this._instance.mode = this._proto.MODE.TASK;
			this._instance.statusView = bpmext.ui.getView("TaskStatusOutputText", this);
			this._instance.dueView = bpmext.ui.getView("TaskDueOutputText", this);
			this._instance.priorityView = bpmext.ui.getView("TaskPriorityOutputText", this);
			domClass.add(this._instance.dueView.context.element, "trailingSeparator");


			//labels
			this._instance.statusView.setLabel(bpmext.localization.formatMsg("taskViewer", "status"));
			this._instance.dueView.setLabel(bpmext.localization.formatMsg("taskViewer", "due"));
			this._instance.priorityView.setLabel(bpmext.localization.formatMsg("taskViewer", "priority"));

			this._instance.actionsButton = bpmext.ui.getView("ActionsIcon", this);
			this._instance.actionsMenu = bpmext.ui.getView("TaskViewerActionsMenu", this);

			this._instance.closeButton = bpmext.ui.getView("CloseButton", this);

			this.loadContainer(this);

            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONTASK_CLOSED);
			bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONTASK_OPENED);
            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONTASK_ACTION, "task", "action");

			taskUtils.EVENTS.TASK_LAUNCHED.subscribe(function(eventName, eventData){
				var task = eventData && eventData.task, businessData, systemData;

				if(task){
					this._instance.task = task;

					businessData = task && task.processData && task.processData.businessData;
					systemData = eventData && eventData.systemData;

					bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONTASK_OPENED, task);

					this.setTaskData(this, task, businessData, systemData);
					taskUtils.EVENTS.TASK_SHOWING_IN_VIEWER.publish();
				} else {
					//THROW ERROR OR LOG
				}
			}, this);

			taskUtils.EVENTS.SERVICE_LAUNCHED.subscribe(function(){
				this.setVisible(false, true);
			}, this);

			taskUtils.EVENTS.CLOSE_TASK_VIEWER.subscribe(function(){
				this.reset();
			}, this);

			//respond to task field changes
	        taskUtils.EVENTS.TASK_FIELD_CHANGED.subscribe(this._proto._taskChangedNotificationHandler, this);
            taskUtils.EVENTS.TASKLIST_TASK_RESOURCE_ASSIGNED.subscribe(this._proto._taskChangedNotificationHandler, this);
            taskUtils.EVENTS.MODIFY_INSTANCE_CLOSE.subscribe(this._proto._taskChangedNotificationHandler, this);

			// Backup reload method when notification failed
            taskUtils.EVENTS.DELAY_RELOAD.subscribe(function () {
                if (!taskUtils.getNotificationExistence()) {
                    if (view._instance.delayReloadTimer) {
                        clearTimeout(view._instance.delayReloadTimer);
                    }
                    // only update this view when it is visible
                    if (view.isVisible()) {
                        view._instance.delayReloadTimer = setTimeout(function () {
                            clearTimeout(view._instance.delayReloadTimer);
                            delete view._instance.delayReloadTimer;
                            view._proto._fetchAndUpdateTask(view);
                        }, 1000);
                    }
                }
            }, this);
		};

        /*
        Coach NG VIew Lifecycle method *************************************************************
         */
        this.constructor.prototype.view = function ()
        {
            try
            {
                utilities.handleVisibility(this.context);
            }
            catch (e)
            {
                //{#feature: US-1330 Added RT localization}
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if(e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                }
            }
        };

		/*
        Coach NG Unload Lifecycle method *************************************************************
         */
        this.constructor.prototype.unload = function ()
        {
            bpmext.ui.unloadView(this);
        };
    }
};