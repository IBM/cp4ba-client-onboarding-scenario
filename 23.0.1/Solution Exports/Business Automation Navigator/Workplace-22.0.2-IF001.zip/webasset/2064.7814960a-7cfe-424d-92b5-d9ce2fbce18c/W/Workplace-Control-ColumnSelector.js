/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof ColumnSelector
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof ColumnSelector
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof ColumnSelector
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof ColumnSelector
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof ColumnSelector
 * @method setData
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On Show:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when the column selector is shown.</td>
 *               </tr>
 *           </table>
 *       </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On Hide:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when the column selector is hidden.</td>
 *               </tr>
 *           </table>
 *       </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On Change:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when the column selection is changed.</td>
 *               </tr>
 *           </table>
 *       </td>
 *   </tr>
 * </table>
 */
workplace_control_InitColumnSelector = function (utilities, taskUtils, domClass, domGeometry, domStyle, domAttr)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        //Events
        this.constructor.prototype._proto =
        {
            EVT_ONSHOW : "eventON_SHOW",
            EVT_ONHIDE : "eventON_HIDE",
            EVT_ONCHANGE : "eventON_CHANGE",

            _handleVisibility : function (view) {
				utilities.handleVisibility(view.context);
			},

            _bindOnblurHandler: function _bindOnblurHandler(view) {
                if (view._instance.closeOnblurHandler) {
                    this._proto._removeOnblurHandler(view);
                }

                if (view._instance.dropDownPanel) {
                    // Binding onblur action to components
                    view._instance.closeOnblurHandler = function (event) {
                        event.stopPropagation();

                        // Since the activeElement won't be shown immediately
                        setTimeout(function () {
                            if (!view.context.element.contains(document.activeElement)) {
                                view._instance.Panel.isVisible() &&  view.toggleVisibility();
                            }
                        }, 150);
                    };

                    view._instance.dropDownPanel.addEventListener("blur", view._instance.closeOnblurHandler, true);
                	view._instance.toggleIconContext.addEventListener("blur", view._instance.closeOnblurHandler, true);
                }
            },

            _removeOnblurHandler: function _removeOnblurHandler(view) {
                // Removing onblur action to components
                if (view._instance.closeOnblurHandler) {
                    if (view._instance.dropDownPanel) {
                        view._instance.dropDownPanel.removeEventListener("blur", view._instance.closeOnblurHandler, true);
                        view._instance.toggleIconContext.removeEventListener("blur", view._instance.closeOnblurHandler, true);
                    }

                    delete view._instance.closeOnblurHandler;
                }
            },

            _checkNotEqual: function _checkNotEqual(list1, list2){
                if(list1 && list2){
                    if(list1.length>0 && list2.length>0){
                        if(list1.length !== list2.length){
                            return true;
                        }else{
                            for(var x=0;x<list1.length;x++){
                                var found = list2.filter(function(item){
                                    return item.value === list1[x].value;
                                });
                                if(found.length < 1){
                                    return true;
                                }
                            }
                            return false;
                        }
                    }
                    return false;
                }
            },
            _createOriginDescriptionDom: function (description){
                var id="menuitem-tooltip-content-"+bpmext.ui.makeUniqueId("");
                var infoDom = document.createElement("div");
                var infoDomWrapper = document.createElement("span");
                domClass.add(infoDomWrapper, "menuitem-tooltip-icon");
                
                var ciIcon = utilities.getCarbonIcon("ci-information");
                domAttr.set(ciIcon, "role", "button");
                domAttr.set(ciIcon, "tabindex","0");
                domAttr.set(ciIcon, "aria-describedby", id)
                domAttr.set(ciIcon, "aria-label", bpmext.localization.formatMsg("savedSearchBuilder", "information"));
                infoDomWrapper.appendChild(ciIcon);

                var tooltipWrapper = document.createElement("div");
                domClass.add(tooltipWrapper, "menuitem-tooltip");
                var tooltipContent = document.createElement("div");
                domClass.add(tooltipContent, "menuitem-tooltip-content");
                domAttr.set(tooltipContent,"id",id);

                var tooltipText = document.createTextNode(description);
                tooltipContent.appendChild(tooltipText);
                tooltipWrapper.appendChild(tooltipContent);
                infoDomWrapper.appendChild(tooltipWrapper);

                infoDom.appendChild(infoDomWrapper);

                return infoDom
            },
            _getBusinessDataOriginString: function _getBusinessDataOriginString(data){
                var messages = bpmext.localization;
                var desc = "";
                if(data.origins && data.origins.length>0){
                    desc = messages.formatMsg("savedSearchBuilder","originateFrom", '"' + data.origins[0].processName + '"');
                }
                else if(data.origins && data.origins.items && data.origins.items.length>0){
                    desc = messages.formatMsg("savedSearchBuilder","originateFrom", '"' + data.origins.items[0].processName + '"');
                }
                else{
                    desc = data.value
                }
                return desc;
            },
            _getItemInObject: function _getItemInObject(view, sourceObject, item){
                if(item.isBusinessData){
                    var htmlObj = document.createElement('div');
                    htmlObj.innerHTML = item.get("value");
                    var origin = htmlObj.querySelector(".menuitem-tooltip-content") ? htmlObj.querySelector(".menuitem-tooltip-content").innerHTML:view._proto._getBusinessDataOriginString(item);
                    htmlObj.remove();
                }
                for(var x=0; x<sourceObject.length(); x++){
                    if(item.isBusinessData){
                        var sourceOrigin = view._proto._getBusinessDataOriginString(sourceObject.get(x));
                        if(sourceObject.get(x).get("name")==item.get("name")){
                            if(!item.get("origins") || sourceOrigin == origin){
                                return sourceObject.get(x);
                            }
                        }
                    }else{
                        if(sourceObject.get(x).get("name")==item.get("name")){
                            return sourceObject.get(x);
                        }
                    }
                }
                return undefined;
            }
        };


        /*
        Public control methods *************************************************************
         */

        /**
         * @instance
         * @memberof ColumnSelector
         * @method changeSelectedColumns
         * @param onClear bool true if this is a result of an onClear event
         * @param initializing bool true if this is a result of initialization
         * @desc Reads the current selection and updates the binding
         */
        this.constructor.prototype.changeSelectedColumns = function changeSelectedColumns(onClear, initializing) {
			bpmext.log.info("ColumnSelector.changeSelectedColumns ENTER >> (onCLear, initializing): " + onClear + ", " + initializing, this);

            var skipRefresh = false;

            //Only change focus if the dropdown is opened and current focus item is the child of this component
            if (this._instance.Panel.isVisible() && this.context.element.contains(document.activeElement)) {
                this._instance.dropDownPanel.focus();
            }

        	//Only process this change if it was not a result of an onClear event
        	if (onClear !== true) {

                var selectedBinding = this.context.binding.get("value");

                //Skip if this is a result of a reload
                if (this._instance._reloadColumnSelectorFlag === true) {
                    this._instance._reloadColumnSelectorFlag = false;
                    bpmext.log.info("ColumnSelector.changeSelectedColumns EXIT >>", this);
                    return;
                }
                var selectedItems = (initializing === true) ? dojo.clone(selectedBinding.items) : this._instance.selectedColumnsCBG.getSelectedItems();
                var selectedBusinessItems = this._instance.businessColumnsCBG.getSelectedItems();
                var businessColOptions = this.context.options.businessCols.get("value");
                //build the list of currently selected items
                if (selectedBusinessItems.length !== 0) {
                	for (var i=0; i < selectedBusinessItems.length; i++) {
                        // for(var j=0; j < businessColOptions.length;)
                        // if(selectedBusinessItems[i].name == )
                		selectedBusinessItems[i].isBusinessData = true;
                	}
                    selectedItems = selectedItems.concat(selectedBusinessItems);
                    this._instance.businessColumnsCBG.removeItem(selectedBusinessItems[0].value);
                }
                var selectedSystemItems = this._instance.intrinsicColumnsCBG.getSelectedItems();
                if (selectedSystemItems.length !== 0) {
                    selectedItems = selectedItems.concat(selectedSystemItems);
                    this._instance.intrinsicColumnsCBG.removeItem(selectedSystemItems[0].value);
                }

                var x, y, found = false;

                //Need to ensure mandatory cols (e.g. taskSubject) is not removed from the selection
                var mandatoryCols = this.context.options.mandatoryCols.get("value").items;
                if (selectedItems === null || selectedItems.length === 0) {
                    selectedItems = [];
                    for (x=0; x<mandatoryCols.length; x++) {
                        this._instance.selectedColumnsCBG.addSelectedItem(mandatoryCols[x]);
                        this._instance.selectedColumnsCBG.setOptionDisabled(mandatoryCols[x].value, true);
                        selectedItems.push(mandatoryCols[x]);
                    }
                } else {
                    var missingMandatoryCols = dojo.clone(mandatoryCols);
                    if (missingMandatoryCols.length > 0) {
                        for (x=0; x<selectedItems.length; x++) {
                            for (y=0; y<missingMandatoryCols.length; y++) {
                                if (selectedItems[x].name === missingMandatoryCols[y].name) {
                                    missingMandatoryCols.splice(y,1);
                                    break;
                                }
                            }
                        }
                        for(x=0; x<missingMandatoryCols.length; x++) {
                            this._instance.selectedColumnsCBG.addSelectedItem(missingMandatoryCols[x]);
                            this._instance.selectedColumnsCBG.setOptionDisabled(mandatoryCols[x].value, true);
                            selectedItems.push(missingMandatoryCols[x]);
                        }
                    }
                }

                if (selectedItems.length > selectedBinding.length()) {
                    //new columns selected
                    for(x=0; x<selectedItems.length; x++) {
                        found = false;
                        for(y=0; y<selectedBinding.length(); y++) {
                            if (selectedItems[x].name === selectedBinding.get(y).get("name")) {
                                found = true;
                                break;
                            }
                        }
                        if(found === false) {
                            var obj = {name:selectedItems[x].name, value:selectedItems[x].value, isBusinessData: selectedItems[x].isBusinessData};
                            selectedBinding.add(obj);
                            continue;
                        }
                    }
                } else {
                    //column removed
                    for(x=0; x<selectedBinding.length(); x++) {
                        found = false;
                        for(y=0; y<businessColOptions.length(); y++) {
                            if (businessColOptions.get(y).name === selectedBinding.get(x).get("name")) {
                                selectedBinding.get(x).set("isBusinessData", true)
                                selectedBinding.get(x).set("origins", businessColOptions.get(y).get("origins"))
                                break;
                            }
                        }
                        for(y=0; y<selectedItems.length; y++) {
                            if (selectedItems[y].name === selectedBinding.get(x).get("name")) {
                                found = true;
                                break;
                            }
                        }
                        if(found === false) {
                            break;
                        }
                    }
                    if (found === false) {
                        selectedBinding.remove(x);
                    }
                }

                //Call on change event
                if (skipRefresh !== true) {
                    var columnsSelected = this.context.binding.get("value").items;
                    if(this._instance.defaultColumns.length>0 && this._instance.defaultColumns[0].value !== ""){
                        var notDefaultColumns = this._proto._checkNotEqual(this._instance.defaultColumns, columnsSelected);

                        if(notDefaultColumns){
                            if (this._instance.instanceMode){
                                taskUtils.EVENTS.SET_INSTANCE_BADGE.publish({text:bpmext.localization.formatMsg("SearchBar", "filterApplied"),clearSS:false});
                            }else{
                                taskUtils.EVENTS.SET_TASK_BADGE.publish({text:bpmext.localization.formatMsg("SearchBar", "filterApplied"),clearSS:false});
                            }
                        }
                    }
                    if (this._instance.instanceMode){
                        taskUtils.EVENTS.MODIFY_INSTANCE_COLUMNS.publish(columnsSelected);
                    }else{
                        taskUtils.EVENTS.MODIFY_TASK_COLUMNS.publish({columns: columnsSelected, ss: this._instance.ssLaunched});
                    }
                    bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONCHANGE);
                }
                this.reloadColumnSelector();

                bpmext.log.info("ColumnSelector.changeSelectedColumns EXIT >>", this);
            }
       };

        /**
         * @instance
         * @memberof ColumnSelector
         * @method reloadColumnSelector
         * @desc Reloads the available columns and selection
         */
        this.constructor.prototype.reloadColumnSelector = function reloadColumnSelector() {
            bpmext.log.info("ColumnSelector.reloadColumnSelector ENTER >>", this);

            //loop through current selected cols, if any are not in fields, then remove it from current selected cols
            //build list of cols, starting from current selected cols and then all others
            //clear the checkbox group and rebuild using the new list of cols
            var x, y, found, colsToRemove = [];
            var businessColOptions = this.context.options.businessCols.get("value");
            var systemColOptions = this.context.options.systemCols.get("value");
            var mandatoryColOptions = this.context.options.mandatoryCols.get("value");
            var selectedBinding = this.context.binding.get("value");

            if(businessColOptions.length()<1){
                this._instance.emptyBusinessDataText.setVisible(true);
            }else{
                this._instance.emptyBusinessDataText.setVisible(false, true);
            }
            this._instance._reloadColumnSelectorFlag = true;
            for (x=0; x<selectedBinding.length(); x++) {
                found = false;
                for (y=0; y<businessColOptions.length(); y++) {
                    if (selectedBinding.get(x).get("name") === businessColOptions.get(y).get("name")) {
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    for (y=0; y<systemColOptions.length(); y++) {
                        if (selectedBinding.get(x).get("name") === systemColOptions.get(y).get("name")) {
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        colsToRemove.push(x);
                    }
                }
            }
            for (x=0; x<colsToRemove.length; x++) {
                selectedBinding.remove(colsToRemove[x]);
            }
            var selectedCols = [];
            var businessCols = [];
            var systemCols = [];
            for (x=0; x<businessColOptions.length(); x++) {
                found = false;
                for (y=0; y<selectedBinding.length(); y++) {
                    if (selectedBinding.get(y).get("name") === businessColOptions.get(x).get("name")) {
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    businessCols.push({name: businessColOptions.get(x).get("name"), value: businessColOptions.get(x).get("value"), origins: businessColOptions.get(x).get("origins"), selected: false});
                }
            }

            for (x=0; x<systemColOptions.length(); x++) {
                found = false;
                for (y=0; y<selectedBinding.length(); y++) {
                    if (selectedBinding.get(y).get("name") === systemColOptions.get(x).get("name")) {
                        found = true;
                        break;
                    }
                }
                if (!found && systemColOptions.get(x).get("name") !== "taskState") {
                    systemCols.push({name: systemColOptions.get(x).get("name"), value: systemColOptions.get(x).get("value"), description: systemColOptions.get(x).get("description"), selected: false});
                }
            }

            var selectedItems = [];
            for (x=selectedBinding.length()-1; x>=0; x--) {
                if(selectedBinding.get(x).get("isBusinessData")){
                    var obj = this._proto._getItemInObject(this, businessColOptions, selectedBinding.get(x));
                    obj && selectedCols.unshift({name: obj.get("name"), value: obj.get("value"), origins: this._proto._getBusinessDataOriginString(obj), selected: true});
                }else{
                    obj = this._proto._getItemInObject(this, systemColOptions, selectedBinding.get(x));
                    obj && selectedCols.unshift({name: obj.get("name"), value: obj.get("value"), description: obj.get("description"), selected: true});
                }
                selectedItems.push(x);
            }

            // Clear tooltips
            for (x=0; x<selectedCols.length + 1; x++) {
                if(this._instance.tooltipEltVCBG != null && this._instance.tooltipEltVCBG[x] != null){
                    var iconElt = this._instance.selectedColumnsCBG.context.element.querySelector("span[id*='VisibleColumnsCBG["+ x +"]'] .menuitem-tooltip-icon");
                    bpmext.ui.util.closeTooltip(this._instance.tooltipEltVCBG[x], iconElt);
                }
            }
            for (x=0; x<businessCols.length + 1; x++) {
                if(this._instance.tooltipEltBCBG != null && this._instance.tooltipEltBCBG[x] != null){
                    iconElt = this._instance.businessColumnsCBG.context.element.querySelector("span[id*='BusinessColumnsCBG["+ x +"]'] .menuitem-tooltip-icon");
                    bpmext.ui.util.closeTooltip(this._instance.tooltipEltBCBG[x], iconElt);
                }
            }
            for (x=0; x<systemCols.length + 1; x++) {
                if(this._instance.tooltipEltICBG != null && this._instance.tooltipEltICBG[x] != null){
                    iconElt = this._instance.intrinsicColumnsCBG.context.element.querySelector("span[id*='IntrinsicColumnsCBG["+ x +"]'] .menuitem-tooltip-icon");
                    bpmext.ui.util.closeTooltip(this._instance.tooltipEltICBG[x], iconElt);
                }
            }
            this._instance.tooltipEltVCBG = [];
            this._instance.tooltipEltBCBG = [];
            this._instance.tooltipEltICBG = [];
            this._instance.selectedColumnsCBG.clearItems();
            this._instance.businessColumnsCBG.clearItems();
            this._instance.intrinsicColumnsCBG.clearItems();
            var visibleColumns = [];
            for (x=0; x<selectedCols.length; x++) {
                var val = selectedCols[x].value;
                for(y=0; y<mandatoryColOptions.length(); y++) {
                    if (selectedCols[x].name === mandatoryColOptions.get(y).get("name")) {
                        val = "*" + val;
                    }
                }
                this._instance.selectedColumnsCBG.appendItem(selectedCols[x].name, val+this._proto._createOriginDescriptionDom(selectedCols[x].origins? selectedCols[x].origins : selectedCols[x].description).innerHTML);
                if (val[0] === "*") {
                    this._instance.selectedColumnsCBG.setOptionDisabled(selectedCols[x].name, true);
                }

                // Add mouse hover tooltip
                var description = selectedCols[x].origins? selectedCols[x].origins : selectedCols[x].description;
                var iconElt = this._instance.selectedColumnsCBG.context.element.querySelector("span[id*='VisibleColumnsCBG["+ x +"]'] .menuitem-tooltip-icon svg");
                this._instance.tooltipEltVCBG[x] = bpmext.ui.util.showTooltip(iconElt, description, {
                    horizontalPos: "LEFT",
                    smartPositioning: true,
                    alwaysShow: false,
                    openDelay: "0.4"
                });

                visibleColumns.push({name: selectedCols[x].name, value: selectedCols[x].value, desc: description}); 
            }
            taskUtils.EVENTS.UPDATE_COLUMNS.publish({columns: visibleColumns});
            this._instance._reloadColumnSelectorFlag = true;
            this._instance.selectedColumnsCBG.setSelectedItems(selectedCols);
            businessCols.sort(function(a,b){
                return a.value.localeCompare(b.value);
            });
            for (x=0; x<businessCols.length; x++) {
            	var val = businessCols[x].value;
                var desc = this._proto._getBusinessDataOriginString(businessCols[x]);
                this._instance.businessColumnsCBG.appendItem(businessCols[x].name, val + this._proto._createOriginDescriptionDom(desc).innerHTML);

                // Add mouse hover tooltip
                iconElt = this._instance.businessColumnsCBG.context.element.querySelector("span[id*='BusinessColumnsCBG["+ x +"]'] .menuitem-tooltip-icon svg");
                this._instance.tooltipEltBCBG[x] = bpmext.ui.util.showTooltip(iconElt, desc, {
                    horizontalPos: "LEFT",
                    smartPositioning: true,
                    alwaysShow: false,
                    openDelay: "0.4"
                });
            }
            systemCols.sort(function(a,b){
                return a.value.localeCompare(b.value);
            });
            for (x=0; x<systemCols.length; x++) {
                var desc = systemCols[x].description? systemCols[x].description: systemCols[x].name;
                this._instance.intrinsicColumnsCBG.appendItem(systemCols[x].name, systemCols[x].value + this._proto._createOriginDescriptionDom(desc).innerHTML);

                // Add mouse hover tooltip
                iconElt = this._instance.intrinsicColumnsCBG.context.element.querySelector("span[id*='IntrinsicColumnsCBG["+ x +"]'] .menuitem-tooltip-icon svg");
                this._instance.tooltipEltICBG[x] = bpmext.ui.util.showTooltip(iconElt, desc, {
                    horizontalPos: "LEFT",
                    smartPositioning: true,
                    alwaysShow: false,
                    openDelay: "0.4"
                });
                
            }

            this.updatePanelPosition();

            bpmext.log.info("ColumnSelector.reloadColumnSelector EXIT >>", this);
        };

        /**
         * @instance
         * @memberof ColumnSelector
         * @method setColumns
         * @desc Initializes the column selector with the given properties
         * @param {[NameValuePair]} systemCols list of system columns
         * @param {[NameValuePair]} businessCols list of business columns
         * @param {[NameValuePair]} mandatoryCols list of mandatory columns that must be selected
         * @param {[NameValuePair]} selectedCols list of selected columns
         */
        this.constructor.prototype.setColumns = function setColumns(systemCols, businessCols, mandatoryCols, selectedCols, defaultCols, initialization) {
            if (systemCols) {
                this.context.options.systemCols.set("value", systemCols);
            }
            if (businessCols) {
                this.context.options.businessCols.set("value", businessCols);
            }
            if (mandatoryCols) {
                this.context.options.mandatoryCols.set("value", mandatoryCols);
            }
            if (selectedCols) {
                this.context.binding.set("value", selectedCols);
            }
            if(initialization){
                this.setCurrentDefault(defaultCols);
            }
            this.changeSelectedColumns(false, true);
        };

        /**
         * @instance
         * @memberof ColumnSelector
         * @method toggleVisibility
         * @desc Toggles the visibility of the column selector
         */
        this.constructor.prototype.toggleVisibility = function toggleVisibility() {
            if(this._instance.toggleIcon){
                var buttonDom;
                if (this._instance.Panel.isVisible())  {
                    this._instance.Panel.setVisible(false, true);
                    bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONHIDE);

                    buttonDom = this._instance.toggleIcon.context.element;
                    if(domClass.contains(buttonDom, "active")){
                        domClass.remove(this._instance.toggleIcon.context.element,"active");
                    }

                    this._proto._removeOnblurHandler(this);
                } else {
                    this.reloadColumnSelector();
                    this._instance.Panel.setVisible(true);
                    this.updatePanelPosition();
                    bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONSHOW);

                    buttonDom = this._instance.toggleIcon.context.element;
                    domClass.add(this._instance.toggleIcon.context.element,"active");

                    this._proto._bindOnblurHandler(this);
                    this._instance.Panel.context.element.focus();
                }
            }
        };

        /**
         * @instance
         * @memberof ColumnSelector
         * @method updatePanelPosition
         * @desc Update panel position to below the button
         */
        this.constructor.prototype.updatePanelPosition = function updatePanelPosition() {
            bpmext.log.info("ColumnSelector.updatePanelPosition ENTER: >>");

            var button = this._instance.toggleIcon.context.element.querySelector(".SPARKIcon.btn");
            var panel = this._instance.Panel.context.element;

            var buttonGeo = domGeometry.position(button);
            var bodyGeo = domGeometry.position(document.getElementsByTagName("body")[0]);
            var panelRight = bodyGeo.w - buttonGeo.x - buttonGeo.w;
            var panelTop = buttonGeo.y + buttonGeo.h - bodyGeo.y;
            domStyle.set(panel, {
                top: panelTop + "px",
                right: panelRight + "px"
            });
        };

        /**
         * @instance
         * @memberof ColumnSelector
         * @method getCurrentSelectedColumns
         * @return {string[]} List of selected columns
         * @desc Returns the list of currently selected columns
         */
        this.constructor.prototype.getCurrentSelectedColumns = function getCurrentSelectedColumns() {
            bpmext.log.info("ColumnSelector.getCurrentSelectedColumns ENTER: >>");
            var selectedColumns =  [];
            this.context.binding.get("value").items.forEach(function(col){
                selectedColumns.push(col.name);
            });
            return selectedColumns;
        };

        /**
         * @instance
         * @memberof ColumnSelector
         * @method setAlwaysShow
         * @param {boolean} value property to set
         * @desc Sets the always show property to always show each section of the column selector without clicking on the icon
         */
        this.constructor.prototype.setAlwaysShow = function setAlwaysShow(value) {
            bpmext.log.info("ColumnSelector.setAlwaysShow ENTER: >>");
            bpmext.ui.substituteConfigOption(this, "alwaysShow", value);
            if(value){
                this._instance.Panel.setVisible(true);
                this._instance.toggleIcon.setVisible(false,true);
            }
        };

        /**
         * @instance
         * @memberof ColumnSelector
         * @method checkIfModified
         * @return {boolean} true if the current column list has been modified and not the same
         * @desc Check if the column list has been modified
         */
        this.constructor.prototype.checkIfModified = function checkIfModified() {
            bpmext.log.info("ColumnSelector.checkIfModified ENTER: >>");
            return this._proto._checkNotEqual(this._instance.defaultColumns, this.context.binding.get("value").items);
        };

        /**
         * @instance
         * @memberof ColumnSelector
         * @method setCurrentDefault
         * @desc Sets the current default base list to compare for differences
         */
        this.constructor.prototype.setCurrentDefault = function setCurrentDefault(cols) {
            this._instance.defaultColumns = cols.slice();
        };
        /**
         * @instance
         * @memberof ColumnSelector
         * @method setInstanceMode
         * @desc Sets the instance mode for this view
         */
        this.constructor.prototype.setInstanceMode = function setInstanceMode(option) {
            this._instance.instanceMode = option;
        };

        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function ()
        {
            bpmext.log.info("ColumnSelector.load ENTER >>", this);
            
            var opts = this.context.options;
            var messages = bpmext.localization;

            if (!this.context.binding) {
                this.context.binding = bpmext.ui.substituteObject(this, "binding", "selectedCols", []);
            }

            if (!opts.businessCols) {
                bpmext.ui.substituteConfigOption(this, "businessCols", []);
            }

            if (!opts.systemCols) {
                bpmext.ui.substituteConfigOption(this, "systemCols", []);
            }

            if (!opts.mandatoryCols) {
                bpmext.ui.substituteConfigOption(this, "mandatoryCols", []);
            }

            if (!opts.alwaysShow) {
                bpmext.ui.substituteConfigOption(this, "alwaysShow", false);
            }

            this._instance.instanceMode = false;

            this._instance.selectedColumnsCBG = bpmext.ui.getView("VisibleColumnsCBG", this);
            this._instance.selectedColumnsCBG.context.options.allowHTML.set("value", true);
            this._instance.businessColumnsCBG = bpmext.ui.getView("BusinessColumnsCBG", this);
            this._instance.businessColumnsCBG.context.options.allowHTML.set("value", true);
            this._instance.intrinsicColumnsCBG = bpmext.ui.getView("IntrinsicColumnsCBG", this);
            this._instance.intrinsicColumnsCBG.context.options.allowHTML.set("value", true);
            this._instance.toggleIcon = bpmext.ui.getView("columnsSelectorButton", this);

            this._instance.Panel = bpmext.ui.getContainer("ColumnsSelector", this);
            this._instance.visibleColumnsPanel = bpmext.ui.getContainer("VisibleColumnsPanel", this);
            this._instance.intrinsicDataPanel = bpmext.ui.getContainer("IntrinsicDataPanel", this);
            this._instance.businessDataPanel = bpmext.ui.getContainer("BusinessDataPanel", this);

            this._instance.emptyBusinessDataText = bpmext.ui.getView("emptyBusinessDataText", this);
            this._instance.emptyBusinessDataText.setLabel(messages.formatMsg("savedSearchBuilder", "emptyBusinessState"));

            this._instance.visibleColumnsPanel.setTitle(messages.formatMsg("workplace", "visibleColumn"));
            this._instance.intrinsicDataPanel.setTitle(messages.formatMsg("workplace", "intrinsicData"));
            this._instance.businessDataPanel.setTitle(messages.formatMsg("workplace", "businessData"));

            this._instance.toggleIcon.setIcon("ci-filter-edit");
            this._instance.toggleIconContext = this._instance.toggleIcon && this._instance.toggleIcon.context.element.querySelector("div[role=button]");
            taskUtils.EVENTS.SAVED_SEARCH_LAUNCHED.subscribe(function(eventName, eventData){
                this._instance.ssLaunched = true;
            }, this);

            // Make the main panel able to be focused and blurred
            this._instance.dropDownPanel = this._instance.Panel && this._instance.Panel.context.element;
            domAttr.set(this._instance.dropDownPanel, "tabindex", "0");
            domAttr.set(this._instance.dropDownPanel, "role", "menu");

            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONSHOW);
            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONHIDE);
            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONCHANGE);
            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONVISIBILITYCHANGE);

            this.loadView(this);

            bpmext.log.info("ColumnSelector.load EXIT >>");
        };

        this.constructor.prototype.view = function ()
        {
            try
            {
                this._proto._handleVisibility(this);
            }
            catch (e)
            {
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e, this);
                if(e.stack) {
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack), this);
                }
            }
        };

        this.constructor.prototype.change = function (event)
        {
            bpmext.log.info("ColumnSelector.change ENTER >> (event): " + event, this);
            if (event.type === "config") {
                switch (event.property) {
                    case "_metadata.visibility": {
                        this._proto._handleVisibility(this);
                        break;
                    }
                }
            } else {
                if(JSON.stringify(event.newVal) !== JSON.stringify(event.oldVal)) {
                    //this.reloadColumnSelector();
                }
            }
            bpmext.log.info("ColumnSelector.change EXIT >>", this);
        };

        this.constructor.prototype.unload = function () {
            this._proto._removeOnblurHandler(this);
            bpmext.ui.unloadView(this);
        };
    }
};