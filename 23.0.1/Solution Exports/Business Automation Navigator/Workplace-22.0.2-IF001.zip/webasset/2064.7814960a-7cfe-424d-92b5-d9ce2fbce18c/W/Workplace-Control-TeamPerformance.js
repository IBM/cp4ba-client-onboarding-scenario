/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof TeamPerformance
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof TeamPerformance
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof TeamPerformance
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof TeamPerformance
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof TeamPerformance
 * @method setData
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 * </table>
 */
workplace_control_InitTeamPerformance = function (utilities, taskUtils, wpResources, domClass){
    "use strict";
    this._instance = {
        // Essential for make save search run
        searchTerm: "",
        selectedCols: [
            {name: "taskStatus", value: "Status"},
            {name: "taskPriority", value: "Priority"},
            {name: "taskSubject", value: "Name"},
            {name: "taskDueDate", value: "Due on"},
            {name: "assignedToUser", value: "Owner"},
            {name: "assignedToRoleDisplayName", value: "Team assigned"}
        ],
        filterConditions: []
    };

    if (!this.constructor.prototype._proto) {
        this.constructor.prototype._proto = {
            EXCLUDE_TABLE_COLUMNS: ["KIND", "ASSIGNED_TO_ROLE_DISPLAY_NAME"],
            ROSTER_FILTER_OPTIONS: [
                {value: "", displayName: bpmext.localization.formatMsg("TeamDashboard", "sortBy")},
                {value: "allTasks", displayName: bpmext.localization.formatMsg("TeamDashboard", "sortByOpened")},
                {value: "onTrack", displayName: bpmext.localization.formatMsg("TeamDashboard", "sortByOnTrack")},
                {value: "atRisk", displayName: bpmext.localization.formatMsg("TeamDashboard", "sortByAtRisk")},
                {value: "overdue", displayName: bpmext.localization.formatMsg("TeamDashboard", "sortByOverdue")},
            ],

            /******************** Set config - start ********************/
            _setEnableHistoryNav: function _setEnableHistoryNav(view) {
                view._instance.closeBtn.setVisible(!view.context.options.enableHistoryNav.get("value"), true);
                view._instance.navigationBar.setVisible(view.context.options.enableHistoryNav.get("value"), true);
            },
            /******************** Set config - end ********************/



            /******************** fetch data - start ********************/
            _fetchTeamSummary: function (view, teamId) {
                bpmext.log.info("TeamPerformance._fetchTeamSummary >>: ", view);

                var success = function (teamSummary) {
                    view._proto._loadTeamSummary(view, teamSummary.summary || []);
                };

                var fail = function (error) {
                    !!error && !!error.errorMessage && taskUtils.publishError(error.errorMessage);
                    bpmext.log.error("ERROR >> There was an error fetching the team summary: " + error);
                };

                try {
                    wpResources.teamPerformance.getTeamSummaryByID({
                        teamId: teamId
                    }).then(success, fail);
                } catch (data) {
                    view._proto._errorOnFetch(data);
                }
            },

            _fetchRosters: function _fetchRosters (view, teamId) {
                bpmext.log.info("TeamPerformance._fetchRosters >>: ", view);

                var success = function (data) {
                    view._instance.rosters = (data.teamMemberList || []).map(function (member) {
                        member.teamId = teamId;
                        return member;
                    });

                    view._instance.overallTeamTasks = [];
                    view._proto._fetchOverallTeamTasks(view, teamId, {size: 1000});
                };

                var fail = function (error) {
                    !!error && !!error.errorMessage && taskUtils.publishError(error.errorMessage);
                    bpmext.log.error("ERROR >> There was an error fetching the rosters: " + error);
                };

                try {
                    wpResources.teamPerformance.getTeamMembersByID({
                        teamId: teamId
                    }).then(success, fail);
                } catch (data) {
                    view._proto._errorOnFetch(data);
                }
            },

            _fetchTeamTasks: function _fetchTeamTasks(view, teamId, saveSearchSettings) {
                bpmext.log.info("TeamPerformance._fetchTeamTasks >>: ", view);

                var success = function (tasks) {
                    view._proto._loadTeamTasks(view, tasks || []);
                };

                var fail = function (error) {
                    !!error && !!error.errorMessage && taskUtils.publishError(error.errorMessage);
                    bpmext.log.error("ERROR >> There was an error fetching the team tasks: " + error);
                };

                try {
                    saveSearchSettings = saveSearchSettings || {};
                    saveSearchSettings.teamId = teamId;
                    saveSearchSettings.size = saveSearchSettings.size || 500;

                    wpResources.teamPerformance.getTeamTasksByID(
                        saveSearchSettings
                    ).then(
                        success,
                        fail
                    );
                } catch (data) {
                    view._proto._errorOnFetch(data);
                }
            },

            _fetchOverallTeamTasks: function _fetchOverallTeamTasks(view, teamId, saveSearchSettings) {
                bpmext.log.info("TeamPerformance._fetchOverallTeamTasks >>: ", view);

                var success = function (tasks) {
                    view._instance.overallTeamTasks =  (tasks && tasks.items) || [];
                    setRosterData();
                };

                var fail = function (error) {
                    setRosterData();
                    !!error && !!error.errorMessage && taskUtils.publishError(error.errorMessage);
                    bpmext.log.error("ERROR >> There was an error fetching the team tasks: " + error);
                };

                var setRosterData = function () {
                    view._instance.rosters = view._proto._composeRosterStats(view);
                    view._proto._loadRoster(view);
                };

                try {
                    saveSearchSettings = saveSearchSettings || {};
                    saveSearchSettings.teamId = teamId;
                    saveSearchSettings.size = saveSearchSettings.size || 1000;

                    wpResources.teamPerformance.getTeamTasksByID(
                        saveSearchSettings
                    ).then(
                        success,
                        fail
                    );
                } catch (data) {
                    view._proto._errorOnFetch(data);
                }
            },

            _errorOnFetch: function _errorOnFetch(data) {
                bpmext.log.error("TeamPerformance._errorOnFetch ERROR >> There was an error loading the teams (data): " + data, this);
            },
            /******************** fetch data - end ********************/

            /******************** Load data - start ********************/
            _loadTeamSummary: function _loadTeamSummary(view, summary) {
                view._instance.teamName.setText(summary.name);
                view._instance.rosterStatistics.setStats(view._proto._getTeamTasksStats(summary, true));
                view._instance.teamTasksStatistics.setStats(view._proto._getTeamTasksStats(summary, true));
            },

            _loadRoster: function _loadRoster(view) {
                var rosters = view._proto._sortRoster(view);

                // pagination controls
                var perPage = view._instance.pagination.getPerPage();
                view._instance.pagination.setVisible(rosters.length !== 0, true);
                view._instance.pagination.setItemLength(rosters.length);
                view._instance.pagination.setCurPageNumber(1);

                rosters = rosters.splice(0, perPage);

                view._instance.rosterCards.setListData(rosters, "roster");
            },

            _getRosterStatistics: function _getRosterStatistics(view) {
                var stats = {onTrack: 0,  atRisk: 0, overdue: 0,  total: 0};

                var roster = dojo.clone(view._instance.rosters);
                roster.forEach(function (member) {
                    stats.onTrack += member.onTrackTask;
                    stats.atRisk += member.atRiskTask;
                    stats.overdue += member.overdueTask;
                });

                stats.total = stats.onTrack + stats.atRisk + stats.overdue;

                return {stats: stats};
            },

            _composeRosterStats: function _composeRosterStats(view, roster) {
                if (!roster && !Array.isArray(roster)) {
                    roster = roster || dojo.clone(view._instance.rosters) || [];
                }

                if (!view._instance.overallTeamTasks && !Array.isArray(view._instance.overallTeamTasks)) {
                    view._instance.overallTeamTasks = [];
                }

                var owner, status;
                var memberStats = (view._instance.overallTeamTasks || []).reduce(function (memberStats, task) {
                    status = taskUtils.getStatusClassName(task);
                    owner = task["OWNER"] || task.owner;
                    memberStats[owner] = memberStats[owner] || {};
                    memberStats[owner][status] = memberStats[owner][status] ? memberStats[owner][status] + 1 : 1;
                    return memberStats;
                }, {});

                var computedStats;
                return roster.map(function (member) {
                    computedStats = memberStats[member.name] || {};

                    member.overdueTask = computedStats.overdueTask || 0;
                    member.atRiskTask = computedStats.atRiskTask || 0;
                    member.onTrackTask = computedStats.onTrackTask || 0;
                    member.totalTask = member.overdueTask + member.atRiskTask + member.onTrackTask;

                    return member;
                });
            },

            _sortRoster: function _sortRoster(view) {
                bpmext.log.info("TeamPerformance._sortRoster");

                var fieldMapping = {
                    "name": "name",
                    "allTasks": "totalTask",
                    "onTrack": "onTrackTask",
                    "atRisk": "atRiskTask",
                    "overdue": "overdueTask"
                };

                // Make sure later changes will not apply to config teams
                var rosters = dojo.clone(view._instance.rosters || []);
                rosters = view._proto._rosterTaskStatusFilter(view, rosters);
                rosters = view._proto._rosterFilter(view, rosters);

                // Order and filter, default as order by name in ascending order
                var status = view._instance.rosterStatusFilter.getData() || "name";

                // Applying order at selected filter
                var order = "descending";
                return rosters.sort(function (team1, team2){
                    var field = fieldMapping[status];
                    if (status !== "name" && order === "descending") {
                        return team1[field] > team2[field] ? -1 : 1;
                    } else {
                        return team1[field] > team2[field]  ? 1 : -1;
                    }
                });
            },

            _rosterFilter: function _rosterFilter(view, rosters) {
                return (rosters || []).filter(function (roster) {
                    if (!!view._instance.rostersFilterText) {
                        var name = (roster.name || "").toLocaleLowerCase();
                        var jobTitle = (roster.jobTitle || "").toLocaleLowerCase();

                        var matchName = name.indexOf(view._instance.rostersFilterText.toLocaleLowerCase()) > -1;
                        var matchJobTitle = jobTitle.indexOf(view._instance.rostersFilterText.toLocaleLowerCase()) > -1;

                        return matchName || matchJobTitle;
                    }
                    return true;
                });
            },

            _rosterTaskStatusFilter: function _rosterTaskStatusFilter(view, roster) {
                var statusFilterText  = view._instance.rosterTaskStatusFilterText || "";
                return !statusFilterText ? roster : roster.filter(function (member) {
                    return member[statusFilterText] > 0;
                });
            },

            _loadTeamTasks: function _loadTeamTasks(view, tasks) {
                view._instance.teamTasks = (tasks && tasks.items) || [];
                view._instance.federationResult = (tasks && tasks.federationResult) || [];

                view._instance.teamTaskList.setTasks(tasks);
            },

            _getTeamTasksStats: function _getTeamTasksStats(tasksObj, isTotal) {
                var stats = {onTrack: 0,  atRisk: 0, overdue: 0,  total: 0};

                if (!isTotal) {
                    if (tasksObj && tasksObj.riskStateSummary) {
                        stats = {
                            onTrack: tasksObj.riskStateSummary.OnTrack || 0,
                            atRisk: tasksObj.riskStateSummary.AtRisk || 0,
                            overdue: tasksObj.riskStateSummary.Overdue || 0,
                            total:  tasksObj.totalCount || 0
                        };
                    }
                } else if (!!tasksObj) {
                    stats = {
                        onTrack: tasksObj.countOnTrack || 0,
                        atRisk: tasksObj.countAtRisk || 0,
                        overdue: tasksObj.countOverdue || 0,
                        total:  tasksObj.totalOpenTasks || 0
                    };
                }

                return {stats: stats};
            },

            /******************** Load data - end ********************/

            /******************** Others - start ********************/
            _getBindingData: function _getBindingData (target, list) {
                if (list && target) {
                    var curIndex = target.ui.getIndex();
                    return list[curIndex];
                }

                return {};
            },

            _toggleLabelVisibility: function _toggleLabelVisibility (view) {
                view._instance.teamName.setLabelVisible(false, true);
            },

            _clearViews: function _clearViews(view) {
                // Tab section
                view._instance.tabSection.setCurrentPane(0);

                // Clear changes on control
                if (view._instance.rosterStatusFilter.getSelectedIndex() !== 0) {
                    view._instance.rosterStatusFilter.setSelectedItemAt(0);
                }

                view._instance.rosterStatistics.removeFilters();
                view._instance.teamTasksStatistics.removeFilters();

                // clear filter
                view.clearRosterFilter();

                view._instance.rosters = [];
                view._proto._loadRoster(view);

                view._instance.teamName.setText("");
                view._instance.teamTasksStatistics.setStats(view._proto._getTeamTasksStats({}));

                view._proto._loadTeamTasks(view, []);
            },

            _initControls: function _initControls(view) {
                view._instance.rosters = [];
                view._proto._loadRoster(view);

                view._instance.teamName.setText("");
                view._instance.teamTasksStatistics.setStats(view._proto._getTeamTasksStats({}));

                view._proto._loadTeamTasks(view, []);
            },

            _initTeamTasklist: function _initTeamTasklist(view) {
                view._instance.teamTaskList.setExclusiveColumns(view._proto.EXCLUDE_TABLE_COLUMNS);
                view._instance.teamTaskList.setSelectedColumns(view._instance.selectedCols);
            },

            _initRosterStatusFilter: function _initRosterStatusFilter(view) {
                bpmext.log.info("TeamPerformance._initRosterStatusFilter");

                // Append options to the filter
                view._proto.ROSTER_FILTER_OPTIONS.forEach(function(term) {
                    view._instance.rosterStatusFilter.appendItem(term.value, term.displayName);
                });

                // Init filter option
                view._instance.rosterStatusFilter.setSelectedItemAt(0);
            },

            _initRosterFilter: function _initRosterFilter(view) {
                bpmext.log.info("TeamPerformance._initRosterFilter");

                if (!!view._instance.rosterFilter) {
                    view._instance.rosterFilter.setPlaceholder(bpmext.localization.formatMsg("TeamPerformance", "rosterFilterPlaceHolder"));

                    var input = view._instance.rosterFilter.context.element.querySelector(".input > input");
                    !!input && input.setAttribute("autocomplete", "off");
                }

                if (view._instance.rosterClearTextBtn) {
                    view._instance.rosterClearTextBtn.setVisible(false, true);
                }

                view.toggleRosterFilterExpansion(false);
            },

            _localization: function _localization(view) {
                view._instance.tabSection.setTabText(bpmext.localization.formatMsg("TeamPerformance", "rosterTitle"), 0);
                view._instance.tabSection.setTabText(bpmext.localization.formatMsg("TeamPerformance", "teamTasksTitle"), 1);

                // empty table text
                view._instance.teamTaskList.setEmptyTableTexts({
                    header: bpmext.localization.formatMsg("TeamPerformance", "noTasksHeader"),
                    subHeader: bpmext.localization.formatMsg("TeamPerformance", "noTasksSubheader")
                });
            },

            // _setTaskTableBtnTooltips: function _setTaskTableBtnTooltips(view) {
            //     var EDT_BtnCtl = view._instance.batchEditBtn.context.element.querySelector('.SPARKIcon[role="button"]');
            //     bpmext.ui.util.showTooltip(
            //         EDT_BtnCtl,
            //         bpmext.localization.formatMsg("TeamPerformance", "edtTooltip"),
            //         {horizontalPos: "LEFT", smartPositioning: true, openDelay: 0.5}
            //     );
            // },

            _generateHistoryCallbacks: function _generateHistoryCallbacks (view, displayName) {
                var onViewRestore = function () {
                    taskUtils.EVENTS.BEFORE_VIEW_TEAM_PERFORMANCE.publish(view._instance.viewerObj);
                };

                var onViewClose = function() {
                    view.closeTeamPerformance();
                };

                return {
                    identifier: "Team",
                    displayName: displayName || "Team",
                    onViewRestore: onViewRestore,
                    onViewClose: onViewClose
                };
            }
            /******************** Others - end ********************/
        };

        /*
        Public control methods *************************************************************
        */

        /**
		 * @instance
		 * @memberof TeamPerformance
		 * @method showTeamPerformance
		 * @desc Show team performance
		 */
        this.constructor.prototype.showTeamPerformance = function() {
            bpmext.log.info("TeamPerformance.showTeamPerformance");

            if (!this.isVisible()) {
                var teamPerformanceDS = bpmext.ui.getContainer("/Workplace_Content_Wrapper1/Team_Performance_DS");
                teamPerformanceDS.setVisible(true, true);

                this.setVisible(true, true);
            }
        };

        /**
		 * @instance
		 * @memberof TeamPerformance
		 * @method closeTeamPerformance
		 * @desc Close team performance
		 */
        this.constructor.prototype.closeTeamPerformance = function() {
            bpmext.log.info("TeamPerformance.closeTeamPerformance");

            if (this.isVisible()) {
                var teamPerformanceDS = bpmext.ui.getContainer("/Workplace_Content_Wrapper1/Team_Performance_DS");
                teamPerformanceDS.setVisible(false, true);

                this._proto._clearViews(this);

                this.setVisible(false, true);
            }
        };

        /**
		 * @instance
		 * @memberof TeamPerformance
		 * @method reloadTeamPerformance
		 * @desc Reload team performance
		 */
        this.constructor.prototype.reloadTeamPerformance = function () {
            bpmext.log.info("TeamPerformance.reloadTeamPerformance");

            if (this.isVisible()) {
                this._instance.teamTaskList.reload();
                this.reloadTeamRoster();
            }
        };

        /**
		 * @instance
		 * @memberof TeamPerformance
		 * @method reloadTeamTasks
		 * @desc Reload team tasks
		 */
        this.constructor.prototype.reloadTeamTasks = function (target, saveSearchSettings) {
            bpmext.log.info("TeamPerformance.reloadTeamTasks");

            if (this.isVisible()) {
                var teamId = (this._instance.viewerObj || {}).teamId;
                this._proto._fetchTeamSummary(this, teamId);
                this._proto._fetchTeamTasks(this, teamId, saveSearchSettings);
            }
        };

        /**
		 * @instance
		 * @memberof TeamPerformance
		 * @method reloadTeamRoster
		 * @desc Reload team roster
		 */
        this.constructor.prototype.reloadTeamRoster = function () {
            bpmext.log.info("TeamPerformance.reloadTeamRoster");

            if (this.isVisible()) {
                var teamId = (this._instance.viewerObj || {}).teamId;
                this._proto._fetchRosters(this, teamId);
            }
        };


        /**
		 * @instance
		 * @memberof TeamPerformance
		 * @method openBatchModifyTasks
		 * @desc Event handler for launch batch modify tasks modal
         */
        this.constructor.prototype.openBatchModifyTasks = function openFilter() {
            bpmext.log.info("TeamPerformance.openBatchModifyTasks >>", this);
            taskUtils.EVENTS.BATCH_MODIFY_TASKS.publish({
                view: this,
                teamId: (this._instance.viewerObj || {}).teamId,
                tasks: this._instance.teamTaskList.getSelectedRecords(),
                rosters: this._instance.rosters,
                federationResult: this._instance.federationResult
            });
        };

        /**
		 * @instance
		 * @memberof TeamPerformance
		 * @method rosterStatusFilterChanged
		 * @desc Updates the list when roster filter changed
		 */
        this.constructor.prototype.rosterStatusFilterChanged = function (target, newVal, oldVal) {
            bpmext.log.info("TeamPerformance.rosterStatusFilterChanged");
            if (oldVal !== null && oldVal !== undefined) {
                this.reloadTeamRoster();
            }
        };

         /**
		 * @instance
		 * @memberof TeamPerformance
		 * @method updateRosterFilter
         * @return {boolean} True if the search term has changed, false otherwise
		 * @desc Sets the roster search term.  If a search term is provided, it will override any previously specified search conditions.
         */
        this.constructor.prototype.updateRosterFilter = function updateRosterFilter(target) {
            var filterText = target.getText();
            if (!!target && this._instance.rostersFilterText !== filterText) {
                this._instance.rostersFilterText = filterText;
                this.reloadTeamRoster();
            }
        };

        /**
		 * @instance
		 * @memberof TeamPerformance
		 * @method toggleFilterExpansion
		 * @desc Whether roster filter should be expanded or collapsed
		 */
        this.constructor.prototype.toggleRosterFilterExpansion = function (expand) {
            bpmext.log.info("TeamPerformance.toggleRosterFilterExpansion");

            if (expand) {
                domClass.add(this._instance.rosterSearchWrapper.context.element, "expanded");
                domClass.remove(this._instance.rosterSearchWrapper.context.element, "collapsed");
            } else if (!this._instance.rostersFilterText) {
                domClass.remove(this._instance.rosterSearchWrapper.context.element, "expanded");
                domClass.add(this._instance.rosterSearchWrapper.context.element, "collapsed");
            }
        };

        /**
		 * @instance
		 * @memberof TeamPerformance
		 * @method toggleRosterClearTextBtn
		 * @desc Toggle clear text button
		 */
        this.constructor.prototype.toggleRosterClearTextBtn = function () {
            bpmext.log.info("TeamPerformance.toggleClearTextBtn");
            var value = this._instance.rosterFilter._instance.text.value || "";
            this._instance.rosterClearTextBtn.setVisible(!!value, true);

            if (!!value) {
                domClass.add(this._instance.rosterFilter._instance.input, "showCloseBtn");
            } else if (!this._instance.rostersFilterText) {
                domClass.remove(this._instance.rosterFilter._instance.input, "showCloseBtn");
            }
        };

        /**
		 * @instance
		 * @memberof TeamPerformance
		 * @method clearRosterFilter
		 * @desc Clear roster filter
		 */
        this.constructor.prototype.clearRosterFilter = function () {
            bpmext.log.info("TeamDashboard.clearRosterFilter");
            this._instance.rosterFilter.setText("");

            this.toggleRosterClearTextBtn();
            this.toggleRosterFilterExpansion(false);
        };

        /**
		 * @instance
		 * @memberof TeamPerformance
		 * @method onActionMenuClosed
         * @param {View} actionsMenuView The actions menu view
         * @param {Element} actionsMenuTargetElement The action menu button that was clicked to invoke the menu.
		 * @desc Called when the actions menu is closed.
         */
        this.constructor.prototype.onActionMenuClosed = function onActionMenuClosed(actionsMenuView, actionsMenuTargetElement) {
            // close action menu from task table
            if (!!actionsMenuTargetElement && !!actionsMenuTargetElement.firstElementChild) {
                var classes = actionsMenuTargetElement.firstElementChild.getAttribute("class");
                actionsMenuTargetElement.firstElementChild.setAttribute("class", classes.replace(" active", "").trim());
            }

            // close action menu that open from task cards
            if (actionsMenuTargetElement && actionsMenuTargetElement.classList && actionsMenuTargetElement.classList.contains("active")) {
                actionsMenuTargetElement.classList.remove("active");
            }
            if(actionsMenuTargetElement){
                actionsMenuTargetElement.focus();
            }

        };

        /**
		 * @instance
		 * @memberof TeamPerformance
		 * @method tabContentSwitched
		 * @desc Triggers when tab is being switched
         */
        this.constructor.prototype.tabContentSwitched = function tabContentSwitched(target, oldTabIndex, newTabIndex) {
            var statsControls = [
                this._instance.rosterStatistics,
                this._instance.teamTasksStatistics
            ];

            statsControls[oldTabIndex].setVisible(false, true);
            statsControls[newTabIndex].setVisible(true, true);

            this._instance.teamTaskList._instance.searchBar.closeSearchBar();
        };

        /**
		 * @instance
		 * @memberof TeamPerformance
		 * @method rosterTaskStatusFilterChanged
		 * @desc Triggers on roster filter changed
		 */
        this.constructor.prototype.rosterTaskStatusFilterChanged = function rosterTaskStatusFilterChanged(target, filter) {
            var fieldMatching = {
                total: "",
                onTrack: "onTrackTask",
                atRisk: "atRiskTask",
                overdue: "overdueTask"
            };

            if (this._instance.rosterTaskStatusFilterText !== fieldMatching[filter.filter]) {
                this._instance.rosterTaskStatusFilterText = fieldMatching[filter.filter];
                this.reloadTeamRoster();
            }
        };

        /**
		 * @instance
		 * @memberof TeamPerformance
		 * @method teamTaskStatusFilterChanged
		 * @desc Triggers on team task filter changed
		 */
        this.constructor.prototype.teamTaskStatusFilterChanged = function teamTaskStatusFilterChanged(target, filterOpt) {
            var now = new Date().toISOString();
            var filter = [wpResources.tasks.OPERATOR.EQUALS("interaction", wpResources.tasks.INTERACTION.CLAIMED_AND_AVAILABLE)];

            if (filterOpt.filter === "overdue") {
                filter.push(wpResources.tasks.OPERATOR.LESS_THAN("taskDueDate", now));
            } else if (filterOpt.filter === "atRisk") {
                filter.push(wpResources.tasks.OPERATOR.GREATER_THAN("taskDueDate", now));
                filter.push(wpResources.tasks.OPERATOR.LESS_THAN("taskAtRiskTime", now));
            } else if (filterOpt.filter === "onTrack") {
                filter.push(wpResources.tasks.OPERATOR.GREATER_THAN("taskDueDate", now));
                filter.push(wpResources.tasks.OPERATOR.GREATER_THAN("taskAtRiskTime", now));
            } else {
                filter = [];
            }

            this._instance.filterConditions = filter;

            var filterText = filterOpt.filter || "";
            if (filterText === "total") {
                filterText = "";
            }

            if (this._instance.teamTaskStatusFilterText !== filterText) {
                this._instance.teamTaskStatusFilterText = filterText;
                this._instance.teamTaskList.setFilterConditions(this._instance.filterConditions);
                this._instance.teamTaskList.reload();

                if (filterOpt.filter === "total") {
                    taskUtils.EVENTS.SET_TASK_BADGE.publish({clearSS:true});
                } else if (!!filterOpt.filter) {
                    taskUtils.EVENTS.SET_TASK_BADGE.publish({text: filterOpt.text, clearSS: true});
                }
            }
        };

        /**
		 * @instance
		 * @memberof TeamPerformance
		 * @method setItemsForPage
		 * @desc Set item for different pagination control settings
		 */
        this.constructor.prototype.setItemsForPage = function (target) {
            var perPage = target.getPerPage();
            var curPage = target.getCurPageNumber();

            if (!this._instance.rosters) {
                return;
            }

            if (this.isVisible()) {
                if (this._instance.perPage === perPage && this._instance.curPage === curPage) {
                    return;
                }

                var rosters = this._proto._sortRoster(this);
                rosters = rosters.splice(perPage * (curPage - 1), perPage);

                this._instance.rosterCards.setListData(rosters, "roster");

                this._instance.perPage = perPage;
                this._instance.curPage = curPage;
            }
        };

        /*
        Coach NG Lifecycle methods *************************************************************
        */

        this.constructor.prototype.load = function () {
            bpmext.log.info("TeamPerformance.load ENTER >>", this);

            var view = this, opts = this.context.options;

            if (!opts.enableHistoryNav) {
                bpmext.ui.substituteConfigOption(this, "enableHistoryNav", false);
            }

            if (!opts.workplaceUserSettings) {
                bpmext.ui.substituteConfigOption(this, "workplaceUserSettings", {});
            }

            this._instance.teamName = bpmext.ui.getView("Team_Name", this);
            this._instance.teamName._instance.outputText.setAttribute("role", "heading");
            this._instance.teamName._instance.outputText.setAttribute("aria-level", "1");

            this._instance.teamTaskList = bpmext.ui.getContainer("TeamTaskList", this);

            // Statistics bars
            this._instance.rosterStatistics = bpmext.ui.getView("Roster_Statistics", this);
            this._instance.teamTasksStatistics = bpmext.ui.getView("Team_Tasks_Statistics", this);

            // Tab section
            this._instance.tabSection = bpmext.ui.getContainer("Team_Performance_Body", this);

            // Roster
            this._instance.rosterCards = bpmext.ui.getContainer("Roster_Cards", this);

            // Roster search bar
            this._instance.rosterSearchWrapper = bpmext.ui.getContainer("Roster_Filter_Wrapper", this);
            this._instance.rosterFilter = bpmext.ui.getView("Roster_Filter", this);
            this._instance.rosterClearTextBtn = bpmext.ui.getView("Roster_ClearTextBtn", this);

            // Roster status single select
            this._instance.rosterStatusFilter = bpmext.ui.getView("Roster_Status_Filter", this);

            // Roster pagination
            this._instance.pagination = bpmext.ui.getView("Roster_Pagination", this);

            // Refresh button
            this._instance.refreshBtn = bpmext.ui.getView("Refresh_Button", this);

            // Close button
            this._instance.closeBtn = bpmext.ui.getView("Close_Button", this);

            // Navigation bar
            this._instance.navigationBar = bpmext.ui.getContainer("Workplace_Navigation_Bar", this);

            this._proto._toggleLabelVisibility(this);
            this._proto._setEnableHistoryNav(this);
            this._proto._localization(this);
            this._proto._initTeamTasklist(this);
            this._proto._initRosterFilter(this);
            this._proto._initRosterStatusFilter(this);
            this._proto._initControls(this);

            bpmext.ui.loadView(this);

            taskUtils.EVENTS.BEFORE_VIEW_TEAM_PERFORMANCE.subscribe(function (eventName, eventData) {
                if (eventData.teamId) {
                    this.showTeamPerformance();

                    // Minimize info for restoring instance back
                    this._instance.viewerObj = {
                        teamId: eventData.teamId,
                        name: eventData.name
                    };

                    var historyCallbacks = this._proto._generateHistoryCallbacks(this, eventData.name);
                    taskUtils.viewHistory.addToViewHistory(historyCallbacks);

                    this._instance.teamTaskList.configBatchModify({
                        params: {
                            teamId: this._instance.viewerObj.teamId || null,
                        },
                        rejectedTasks: {
                            notOwnedTask: false
                        }
                    });

                    this.reloadTeamPerformance();
                    this._instance.navigationBar.resetView();
                }
            }, this);

            // Respond to shell actions
            taskUtils.EVENTS.CLOSE_TEAM_PERFORMANCE.subscribe(function () {
                if(!opts.enableHistoryNav.get("value")){
                    this.closeTeamPerformance();
                }else{
                    taskUtils.viewHistory.loadViewFromHistory();
                }
            }, this);

            taskUtils.EVENTS.RELOAD_TEAM_PERFORMANCE.subscribe(function () {
                this.reloadTeamPerformance();
            }, this);

            taskUtils.EVENTS.MODIFY_TASK_SEARCH_TERM.subscribe(function(eventName, eventData){
                if (!this.isVisible()) {
                    return;
                }

                //add a wildcard
                if (eventData) {
                    eventData = eventData + "*";
                }

                if(this._instance.teamTaskList.setSearchTerm(eventData)){
                    this._instance.teamTaskList.reload();
                }
            }, this);

            // reload team roster on new task assignment and task field changes,
            // related actions are delegate to task list, so there it is not required to reload list
            var reloadTeamRosterOnTaskUpdate = function () {
                if (view._instance.accumulatedTO) {
                    clearTimeout(view._instance.accumulatedTO);
                }

                // accumulate consecutive updates into one update call
                view._instance.accumulatedTO = setTimeout(function () {
                    view.reloadTeamRoster();
                    delete view._instance.accumulatedTO;
                }, 300);
            };
            taskUtils.EVENTS.TASKLIST_TASK_RESOURCE_ASSIGNED.subscribe(taskUtils.throttle(dojo.hitch(this, reloadTeamRosterOnTaskUpdate)), this);
            taskUtils.EVENTS.TASK_FIELD_CHANGED.subscribe(taskUtils.throttle(dojo.hitch(this, reloadTeamRosterOnTaskUpdate)), this);
        };

        this.constructor.prototype.view = function () {
            try {
                utilities.handleVisibility(this.context);
            } catch (e) {
                //{#feature: US-1330 Added RT localization}
                //bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if(e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    //bpmext.log.error("  Call stack: " + e.stack);
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                }
            }
        };

        this.constructor.prototype.change = function (event) {
            bpmext.log.info("TeamPerformance.change ENTER >>");
            if (event.type === "config") {
                switch (event.property) {
                    case "_metadata.visibility": {
                        this.view();
                        break;
                    }
                    case "enableHistoryNav": {
                        this._proto._setEnableHistoryNav(this);
                        break;
                    }
                }
            }
            bpmext.log.info("TeamPerformance.change EXIT >>");
        };

        this.constructor.prototype.unload = function () {
            bpmext.ui.unloadView(this);
        };
    }
};