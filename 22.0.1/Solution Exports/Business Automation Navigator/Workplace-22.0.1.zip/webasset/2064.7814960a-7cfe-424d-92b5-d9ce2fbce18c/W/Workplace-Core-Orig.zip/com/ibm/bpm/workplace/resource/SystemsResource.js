/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define("com.ibm.bpm.workplace.resources/SystemsResource", ["dojo/_base/url", "./resourceBase"], function(URL, resource) {
    "use strict";
    var ROUTE = resource._buildUrl("${urlPrefix}/v1/systems", {
            urlPrefix: resource.contextRoot.federatedURL || resource.contextRoot.rest
        }),
        cachedPromise,
        federationResultPromise;

    /**
     * Get system details
     * @param {Boolean} refresh - true to bust the cached data and retrieve new values
     * @returns {Promise} that resolves to the system information
     */
    function get(refresh) {
        if (!cachedPromise || refresh) {
            cachedPromise = resource
                .get(ROUTE, {
                    query: {
                        federationMode: resource.isFederated
                    }
                })
                .then(
                    function success(res) {
                        return resource.isFederated ? res : res.data;
                    },
                    function error(err) {
                        if (err && err.status === 500 && err.errorNumber === "CWMFS4021E" ) {
                            resource.showError(bpmext.localization.formatMsg("Errors", "noFederatedSystem"), err);
                        }
                        throw err;
                    }
                );
        }
        return cachedPromise;
    }

    /**
     * Get the set of federation Results
     * @param {Boolean} refresh - true to bust the cached data and retrieve new values
     * @returns {Promise} that resolves to the the set of federated systems
     */
    function getFederationResults(refresh) {
        if (!federationResultPromise || refresh) {
            // get systems and extract federation results
            federationResultPromise = get(refresh).then(
                function success(res) {
                    var temp,
                        parsedURL,
                        fallback = undefined,
                        federationResult = {};
                    // convert array to dictionary
                    if (res && res.federationResult) {
                        for (var i = 0; i < res.federationResult.length; i++) {
                            temp = res.federationResult[i];
                            if ((temp.statusCode === "200") && temp.restUrlPrefix) {
                                // check if system resources are URL addressable
                                parsedURL = new URL(temp.taskCompletionUrlPrefix);
                                // add convenient endpoint property
                                temp.endpoint = parsedURL.uri.replace(parsedURL.path, "");
                                federationResult[temp.systemID] = temp;
                                // set a fallback system
                                if (!fallback && (temp.systemType === "SYSTEM_TYPE_WLE")) {
                                    fallback = temp;
                                    federationResult.fallback = fallback;
                                }
                            }
                        }
                    }
                    return federationResult;
                },
                function error(err) {
                    if (err && err.status === 500 && err.errorNumber === "CWMFS4021E" ) {
                        resource.showError(bpmext.localization.formatMsg("Errors", "noFederatedSystem"), err);
                    }
                    throw err;
                }
            );
        }
        return federationResultPromise;
    }

    /**
     * Returns the system that contains the task filter service
     *
     * @param {boolean} refresh - true to bust the cached data and retrieve new values
     * @returns {Promise} that resolves to the Task Filter service system information
     */
    function getTaskFilterServiceSystem(refresh) {
        return get(refresh).then(function (res) {
            return (res.systems || [])
                .filter(function (system) {
                    return system.hostsTaskFilterService;
                })
                .map(_addGetTaskFilterServiceConfig)[0];
        });
    }

    /**
     * Helper function to add a convenience method on the system that hosts the Task Filter service
     *
     * @param {Object} system - system object
     */
    function _addGetTaskFilterServiceConfig(system) {
        if (system && !system.getTaskFilterServiceConfig) {
            system.getTaskFilterServiceConfig = function getTaskFilterServiceConfig() {
                if (!this._cachedTaskFilterServiceConfigPromise) {
                    var url = resource._buildUrl("${urlPrefix}/v1/system/rep/${provider}", {
                            urlPrefix: resource.contextRoot.rest,
                            provider: "Mashups_ConfigService"
                        }),
                        properties = [
                            "com.ibm.bpm.portal.task.filter.service.alwaysRun",
                            "com.ibm.bpm.portal.task.filter.service.name",
                            "com.ibm.bpm.portal.task.filter.service.showToggle"
                        ];
                    this._cachedTaskFilterServiceConfigPromise = resource
                        .get(url, {
                            query: {
                                properties: "[" + properties.join() + "]"
                            },
                            systemID: this.systemID
                        })
                        .then(function success(data) {
                            var props = data.propertyList;
                            function _parseBoolean(str) {
                                return (str && ("" + str).toLowerCase() === "true") || false;
                            }
                            if (props) {
                                return {
                                    taskFilterService: {
                                        name: props["com.ibm.bpm.portal.task.filter.service.name"],
                                        alwaysRun: _parseBoolean(props["com.ibm.bpm.portal.task.filter.service.alwaysRun"]),
                                        showToggle: _parseBoolean(props["com.ibm.bpm.portal.task.filter.service.showToggle"])
                                    }
                                };
                            }
                        });
                }
                return this._cachedTaskFilterServiceConfigPromise;
            };
        }
        return system;
    }

    // module.exports
    return {
        get: get,
        getFederationResults: getFederationResults,
        getTaskFilterServiceServer: getTaskFilterServiceSystem
    };
});
