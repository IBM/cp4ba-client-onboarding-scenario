/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
define("com.ibm.bpm.workplace.resources/TaskResource", ["dojo/Deferred", "./resourceBase"], function(Deferred, resource) {
    "use strict";
    var ROUTE = "${urlPrefix}/v1/task/${id}",
        ACTION = {
            ASSIGN: "assign",
            CLAIM: "claim",
            UPDATE: "update",
            GET_DETAILS: "getdetails"
        },
        PARTS = {
            ALL: "all",
            DATA: "data",
            ACTIONS: "actions",
            NONE: "none"
        },
        STATE = {
            CLAIMED: "STATE_CLAIMED",
            FINISHED: "STATE_FINISHED"
        },
        EXTERNAL = "/External",
        COACH = "/IBM_WLE_COACH";

    /**
     *  Perform a task assignment operation either to another user to back to group
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {Number} options.tkiid - task instance id
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     * @param {String} [options.urlPrefix] - optional urlPrefix. This parameter is required when federated
     * @param {Boolean} [options.back] - true to return task back to group
     * @param {String} [options.toUser] - name of the user to assign task to
     * @returns {Promise} promise that resolves to result of the assignment
     */
    function _saveAssignment(options) {
        var url, query, data;
        if (options && options.tkiid && (typeof options.back === "boolean" || options.toUser)) {
            // build URL
            url = resource._buildUrl(ROUTE, {urlPrefix: (options || {}).urlPrefix || resource.contextRoot.rest, id: options.tkiid});

            // build query params
            query = {
                action: ACTION.ASSIGN,
                parts: PARTS.NONE
            };

            if (options.toUser) {
                data = {};
                data.toUser = options.toUser;
            } else if (typeof options.back === "boolean") {
                query.back = options.back;
            }

            return resource
                .put(url, {
                    query: query,
                    data: data ? JSON.stringify(data) : null
                })
                .then(
                    function success(res) {
                        return res.data;
                    }, function error (err) {
                        if (err && err.response && err.response.status === 401) {
                            resource.showError(bpmext.localization.formatMsg("workplace", "taskNotAuthorized"), err);
                        }
                        throw err;
                    }
                );
        }
    }

    /**
     *  Perform an update operation either to the priority or the due date of the task
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {Number} options.tkiid - task instance id
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     * @param {String} [options.urlPrefix] - optional urlPrefix. This parameter is required when federated
     * @param {Date} [options.dueDate] - date object of the new due date
     * @param {String} [options.priority] - the new priority to set for the task. E.g. Highest/10, High/20, Normal/30, Low/40 or Lowest/50
     * @returns {Promise} promise that resolves to result of the update operation
     */
    function _updateTask(options) {
        var url, query, data;
        if (options && options.tkiid && (options.dueDate || options.priority)) {
            // build URL
            url = resource._buildUrl(ROUTE, {
                urlPrefix: (options || {}).urlPrefix || resource.contextRoot.rest,
                id: options.tkiid
            });

            // build query params
            query = {
                action: ACTION.UPDATE,
                parts: PARTS.NONE
            };

            if (options.dueDate instanceof Date) {
                data = {};
                data.dueDate = options.dueDate.toISOString();
            }
            if (options.priority) {
                query.priority = options.priority;
            }

            return resource
                .put(url, {
                    query: query,
                    systemID: options.systemID,
                    data: data ? JSON.stringify(data) : null
                })
                .then(
                    function success(res) {
                        // add systemID to the returned object
                        if (res.systemID) {
                            res.data.systemID = res.systemID;
                        }
                        return res.data;
                    }, function error (err) {
                        if (err) {
                            if (err.response && err.response.status === 401) {
                                resource.showError(bpmext.localization.formatMsg("workplace", "taskNotAuthorized"), err);
                            } else {
                                resource.showError(bpmext.localization.formatMsg("Errors", "taskUpdateFailed"), err);
                            }
                        }
                        throw err;
                    }
                );
        }
    }

    /**
     *  Get a launchable URL for the task, either Coach URL or External implementation
     *
     * @param {Object} options - optional params to pass to the underlying API
     * @param {Number} options.tkiid - task instance id
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     * @param {String} [options.urlPrefix] - optional urlPrefix. This parameter is required when federated
     * @param {Boolean} [options.isCoach] - true to return coach start url
     * @param {Boolean} [options.isExternal] - true to return the External implementation URL
     * @returns {Promise} promise that resolves to the URL
     */
    function _getURL(options) {
        var url;
        if (
            options &&
            options.tkiid &&
            (typeof options.isCoach === "boolean" || typeof options.isExternal === "boolean")
        ) {
            // build URL
            url = resource._buildUrl(ROUTE, {
                urlPrefix: (options || {}).urlPrefix || resource.contextRoot.rest,
                id: options.tkiid
            });
            url += "/clientSettings";

            if (options.isExternal) {
                url += EXTERNAL;
            } else if (options.isCoach) {
                url += COACH;
            }

            return resource.get(url, {systemID: options.systemID}).then(
                function success(res) {
                    return res.data.url;
                }, function error (err) {
                    if (err && err.response && err.response.status === 401) {
                        resource.showError(bpmext.localization.formatMsg("workplace", "taskNotAuthorized"), err);
                    }
                    throw err;
                }
            );
        }
    }

    /**
     * Get details of task
     *
     * @param {Object} options - params to pass API
     * @param {Number} options.tkiid- list of ids to return details for
     * @param {Boolean} [options.excludeData] - true to return business data of task, default is false
     * @param {Boolean} [options.excludeActions] - true to return task's available actions, default is false
     * @param {Boolean} [options.includeURL] - true to include the launchable url of this task, default is false
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     * @param {String} [options.urlPrefix] - optional urlPrefix. This parameter is required when federated
     * @returns {Promise} promise that resolves to the task details
     */
    function get(options) {
        var url, parts;
        
        if (options && options.tkiid) {
            url = resource._buildUrl(ROUTE, {
                urlPrefix: (options || {}).urlPrefix || resource.contextRoot.rest,
                id: options.tkiid
            });

            if (options.excludeActions && options.excludeData) {
                parts = PARTS.NONE;
            } else if (options.excludeData) {
                parts = PARTS.ACTIONS;
            } else if (options.excludeActions) {
                parts = PARTS.ALL;
            } else {
                // data is implicitly included with ALL
                parts = [PARTS.ACTIONS, PARTS.ALL].join();
            }

            return resource
                .get(url, {
                    query: {
                        federationMode: resource.isFederated,
                        includeURL: options.includeURL,
                        parts: parts
                    },
                    systemID: options.systemID
                })
                .then(
                    function success(res) {
                        var data = resource.isFederated ? res : res.data; // extract data if it is wrapped
                        // add systemID to the returned object
                        if (res.systemID) {
                            data.systemID = res.systemID;
                        }
                        return data;
                    }, function error(err) {
                        if (err && err.response) {
                            if (err.response.status === 404) {
                                resource.showError(bpmext.localization.formatMsg("controlTaskList", "taskNotFound"), err);
                            } else if (err.response.status === 401) {
                                resource.showError(bpmext.localization.formatMsg("workplace", "taskNotAuthorized"), err);
                            }
                        }
                        throw err;
                    }
                );
        }
    }

    /**
     * Claim the given task
     *
     * @param {Object} options - task object containing id
     * @param {Number} options.tkiid - task instance id
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     * @param {String} [options.urlPrefix] - optional urlPrefix. This parameter is required when federated
     * @returns {Promise} promise that resolves to the result of the claim action
     */
    function claim(options) {
        var url;
        if (options && options.tkiid) {
            url = resource._buildUrl(ROUTE, {
                urlPrefix: (options || {}).urlPrefix || resource.contextRoot.rest,
                id: options.tkiid
            });

            return resource
                .put(url, {
                    query: {
                        action: ACTION.CLAIM,
                        parts: PARTS.NONE
                    },
                    systemID: options.systemID
                }, function error(err) {
                    if (err && err.response && err.response.status === 404) {
                        resource.showError(bpmext.localization.formatMsg("controlTaskList", "taskNotFound"), err);
                    }
                    throw err;
                });
        }
    }

    /**
     * Assign the given task to a specific user
     *
     * @param {Object} options - task object containing id and username
     * @param {Number} options.tkiid - task instance id
     * @param {String} options.username - name of the user to assign the task to
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     * @returns {Promise} promise that resolves to result of the assignment
     */
    function assignToUser(options) {
        if (options && options.tkiid && options.username) {
            return _saveAssignment({
                tkiid: options.tkiid,
                systemID: options.systemID,
                toUser: options.username
            });
        }
    }

    /**
     * Assign the given task back to the group
     *
     * @param {Object} options - task object containing id
     * @param {Number} options.tkiid - task instance id
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     * @returns {Promise} promise that resolves to result of the assignment
     */
    function assignBackToGroup(options) {
        if (options && options.tkiid) {
            return _saveAssignment({
                tkiid: options.tkiid,
                systemID: options.systemID,
                back: true
            });
        }
    }

    /**
     * Update the priority of the given task
     *
     * @param {Object} options - task object containing id and priority
     * @param {Number} options.tkiid - task instance id
     * @param {String} options.priority - the new priority to set for the task. E.g. Highest/10, High/20, Normal/30, Low/40 or Lowest/50
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     * @returns {Promise} promise that resolves to result of the priority update
     */
    function setPriority(options) {
        if (options && options.tkiid && options.priority) {
            // convert to string
            options.priority = "" + options.priority;
            //check if priority is a valid value
            if (
                options.priority.toLowerCase() === "highest" ||
                options.priority.toLowerCase() === "high" ||
                options.priority.toLowerCase() === "normal" ||
                options.priority.toLowerCase() === "low" ||
                options.priority.toLowerCase() === "lowest" ||
                options.priority.toLowerCase() === "10" ||
                options.priority.toLowerCase() === "20" ||
                options.priority.toLowerCase() === "30" ||
                options.priority.toLowerCase() === "40" ||
                options.priority.toLowerCase() === "50"
            ) {
                return _updateTask(options);
            }
        }
    }

    /**
     * Update the priority of the given task
     *
     * @param {Object} options - task object containing id and dueDate
     * @param {Number} options.tkiid - task instance id
     * @param {Date} options.dueDate - date object of the new due date
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     * @returns {Promise} promise that resolves to result of the priority update
     */
    function setDueDate(options) {
        if (options && options.tkiid && options.dueDate) {
            return _updateTask(options);
        }
    }

    /**
     *  Get a launchable Coach URL for task
     *
     * @param {Object} options - params to pass to the underlying API
     * @param {Number} options.tkiid - task instance id
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     * @returns {Promise} promise that resolves to the URL
     */
    function getCoachURL(options) {
        return _getURL({
            tkiid: options.tkiid,
            systemID: options.systemID,
            isCoach: true
        });
    }

    /**
     *  Get a launchable External Implementation URL for task
     *
     * @param {Object} options - params to pass to the underlying API
     * @param {Number} options.tkiid - task instance id
     * @param {String} [options.systemID] - optional systemID. This parameter is required when federated
     * @returns {Promise} promise that resolves to the URL
     */
    function getExternalImplURL(options) {
        return _getURL({
            tkiid: options.tkiid,
            systemID: options.systemID,
            isExternal: true
        });
    }

    /**
     *  Get tasks' permissions 
     *
     * @param {Object} options - params to pass to the underlying API
     * @param {[String]} options.tkiids - task ids
     * @param {[String]} [options.actions] - optional actions. Specify which actions will be focused on
     * @param {String} [options.urlPrefix] - optional urlPrefix. This parameter is required when federated
     * @returns {Promise} promise that resolves to the URL
     */
    function getTasksPermission(options) {
        var query = {};
        var url = resource._buildUrl("${urlPrefix}/v1/task/actions", {
            urlPrefix: (options || {}).urlPrefix || resource.contextRoot.rest
        });

        // build query params
        if (options) {
            if (Array.isArray(options.tkiids)) {
                query.taskIDs = options.tkiids.join(",");
            }

            if (Array.isArray(options.actions) && options.actions.length > 0) {
                query.actions = options.actions.join(",");
            }
        }

        return resource.get(url, {query: query});
    }

    /**
     * @param {string[]} options.tkiids - array of task ids
     * @param {boolean} options.excludeActions
     * @param {boolean} options.excludeData 
     * @param {string} [options.systemID] - system ID of the task
     * @param {String} [options.urlPrefix] - optional urlPrefix. This parameter is required when federated
     */
    function getBatchTaskDetails(options) {
        if (options && Array.isArray(options.tkiids)) {
            var url = resource._buildUrl("${urlPrefix}/v1/task/", {
                urlPrefix: (options || {}).urlPrefix || resource.contextRoot.rest
            });

            var parts;
            if (options.excludeActions && options.excludeData) {
                parts = PARTS.NONE;
            } else if (options.excludeData) {
                parts = PARTS.ACTIONS;
            } else if (options.excludeActions) {
                parts = PARTS.ALL;
            } else {
                // data is implicitly included with ALL
                parts = [PARTS.ACTIONS, PARTS.ALL].join();
            }

            return resource
                .get(url, {
                    query: {
                        action: ACTION.GET_DETAILS,
                        federationMode: false,
                        parts: parts,
                        taskIDs: options.tkiids.join(",")
                    },
                    systemID: options.systemID
                });
        }
    }

    // module.exports
    return {
        ACTION: ACTION,
        PARTS: PARTS,
        STATE: STATE,
        get: get,
        claim: claim,
        assignToUser: assignToUser,
        assignBackToGroup: assignBackToGroup,
        setPriority: setPriority,
        setDueDate: setDueDate,
        getCoachURL: getCoachURL,
        getExternalImplURL: getExternalImplURL,
        getTasksPermission: getTasksPermission,
        getBatchTaskDetails: getBatchTaskDetails
    };
});
