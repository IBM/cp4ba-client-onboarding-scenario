/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof StreamCards
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof StreamCards
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof StreamCards
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof StreamCards
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof StreamCards
 * @method setData
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 */
workplace_control_InitStreamCards = function (utilities, query, domConstruct, domClass, domAttr, taskUtils)
{
	"use strict";

    this._instance =
    {

    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            EVT_ONLOAD : "eventON_LOAD",

            _setViewData: function _setViewData(view, data, createPseudoBinding){
                var ctx = view.context;
                if(ctx){
                    if(ctx.binding){
                        ctx.binding.set("value", data);
                    } else if (createPseudoBinding) {
                        ctx.binding = bpmext.ui.substituteObject(view);
                        ctx.binding.set("value", data);
                    }
                }
            },

            _generateOwner: function _generateOwner(owner) {
                var div = domConstruct.create("div", {
                    className: "commentAuthorWrapper",
                    "aria-label": bpmext.localization.formatMsg("social", "author") + ": " + owner
                });
                // @todo change to the user avatar in the future, currently use a common icon for all users
                var ownerIcon = utilities.getCarbonIcon("ci-user-filled");
                var ownerText = domConstruct.create("span",  {className: "commentAuthorName"});

                if (owner) {
                    ownerText.innerText = owner;
                }

                domConstruct.place(ownerIcon, div);
                domConstruct.place(ownerText, div);

                return div;
            },

            _createComment: function _createComment(data) {
            	var replyDiv = domConstruct.create("div", {"class": "reply"}), contentDiv, authorDiv, publishTimeTxt;

            	if(data.author && data.author.displayName) {
            		authorDiv = this._generateOwner(data.author.displayName);
            		replyDiv.appendChild(authorDiv);
            	}
            	if(data.content) {
            		contentDiv = domConstruct.create("div", {"class": "content", innerHTML: data.content}, authorDiv);
            	}
             	if (data.published) {
             		var dateStr = bpmext.localization.formatMsg("social", "publishDate") + " " + taskUtils.formatDate(new Date(data.published), true);
                 	publishTimeTxt = domConstruct.create("div", {"class": "publish-time"}, replyDiv);
                 	publishTimeTxt.innerText = dateStr;
             	}

             	return replyDiv;
            }
        };

        /*
        Public control methods *************************************************************
         */

        /**
		 * @instance
		 * @memberof StreamCards
		 * @method setViewData
         * @param {Streams[]} data New stream list binding
		 * @desc Sets the data
         */
        this.constructor.prototype.setViewData = function(data, createPseudoBinding) {
            bpmext.log.info("StreamCards.setViewData ENTER >>", this, data);
            this.context.options.streams.set("value", data);

            this._proto._setViewData(this._instance.cardsWrapper, data,createPseudoBinding);
            bpmext.log.info("StreamCards.setViewData Exit >>", this);
        };

        /**
		 * @instance
		 * @memberof StreamCards
		 * @method setUserInfo
		 * @desc set user information
		 */
        this.constructor.prototype.setUserInfo = function(target) {
        	bpmext.log.info("StreamCards.setUserInfo ENTER>>", this);
        	target.setLabelVisible(false);
        	target.setVisible(false, true);
            var stream = this.ui.getOption("streams").items[target.ui.getIndex()], author;
            if (stream && stream.actor && stream.actor.objectType === "PERSON"){
            	author =  stream.actor.displayName;
            }
            if (author) {
                var div = this._proto._generateOwner(author);
                target.setData(div.outerHTML);
                target.setVisible(true, true);
            }
        },

        /**
		 * @instance
		 * @memberof StreamCards
		 * @method setContent
		 * @desc set the detail content info
		 */
        this.constructor.prototype.setContent = function(target) {
        	bpmext.log.info("StreamCards.setContent ENTER>>", this);
        	target.setLabelVisible(false);
        	target.setVisible(false, true);
        	var stream = this.ui.getOption("streams").items[target.ui.getIndex()];
            if (stream && stream.content){
                target.setData(stream.content);
                target.setVisible(true, true);
            }
        };
        /**
		 * @instance
		 * @memberof StreamCards
		 * @method setPublishDate
		 * @desc set publish date
		 */
        this.constructor.prototype.setPublishDate = function(target) {
        	bpmext.log.info("StreamCards.setPublishDate ENTER>>", this);
        	target.setVisible(false, true);
        	var stream = this.ui.getOption("streams").items[target.ui.getIndex()];
            if (stream && stream.published){
                var publishDate = new Date(stream.published);
                target.setData(taskUtils.formatDate(publishDate, true));
                target.setLabel(bpmext.localization.formatMsg("social", "publishDate"));
                target.setVisible(true, true);
            }
        };

        /**
		 * @instance
		 * @memberof StreamCards
		 * @method setContentIcon
		 * @desc set icon
		 */
        this.constructor.prototype.setContentIcon = function(target) {
        	bpmext.log.info("StreamCards.setContentIcon ENTER>>", this);
        	target.setLabelVisible(false);
        	var stream = this.ui.getOption("streams").items[target.ui.getIndex()];
            if (stream){
            	target.setLabelVisible(true);
            }
        };

        /**
		 * @instance
		 * @memberof StreamCards
		 * @method toggleReplyPanel
		 * @desc toggle reply panel
		 */
        this.constructor.prototype.toggleReplyPanel = function(target) {
        	bpmext.log.info("StreamCards.toggleReplyPanel ENTER>>", this);
        	target.setLabelVisible(false);
        	var stream = this.ui.getOption("streams").items[target.ui.getIndex()];
            if (stream && stream.replies && stream.replies.items){
            	var parentView = target.context._parentView;
                var replyPanel = parentView.context.getSubview("ReplyPanel", parentView)[0];
                var collapseArea = replyPanel.context.element.querySelector("div.panel-collapse");
                var iconSpan = target.context.element.querySelector(".replyIcon");
                domConstruct.empty(iconSpan);
                if(replyPanel.isExpanded()) {
                	replyPanel.collapse();
                    domConstruct.place(utilities.getCarbonIcon("ci-chevron-down"), iconSpan);
                    domAttr.set(collapseArea, "aria-hidden", "true");
                    domAttr.set(iconSpan, "aria-label", bpmext.localization.formatMsg("taskCard", "moreComments"));
                } else {
                	replyPanel.expand();
                    domConstruct.place(utilities.getCarbonIcon("ci-chevron-up"), iconSpan);
                    domAttr.set(collapseArea, "aria-hidden", "false");
                    domAttr.set(iconSpan, "aria-label", bpmext.localization.formatMsg("taskCard", "lessComments"));
                }

                var cardWrapperContext = parentView.context.element.querySelector("div.SPARKWell");
                setTimeout(function(){
                    cardWrapperContext.focus();
                }, 100);
            }
        };

        /**
		 * @instance
		 * @memberof StreamCards
		 * @method setReplyLink
		 * @desc set reply link
		 */
        this.constructor.prototype.setReplyLink = function(target) {
        	bpmext.log.info("StreamCards.setReplyLink ENTER>>", this);
        	target.setVisible(false, true);
        	var stream = this.ui.getOption("streams").items[target.ui.getIndex()];
        	if (stream && stream.replies && stream.replies.items){
            	var replies = stream.replies.items;
            	var replyNo = replies.length, linkText;
            	if(replyNo > 0) {
            		target.setVisible(true, true);
            		linkText = bpmext.localization.formatMsg("social", replyNo === 1 ? "replyTitleSingle" : "replyTitleMulti", replyNo);
            	}

                target.setText(linkText);

                var icon = utilities.getCarbonIcon("ci-chevron-down");
                var iconSpan = domConstruct.create("span",  {className: "replyIcon"});
                domConstruct.place(icon, iconSpan);
                var link = target.context.element.querySelector("a[role=link]");
                domConstruct.place(iconSpan, link, "first");
            }
        };

        /**
		 * @instance
		 * @memberof StreamCards
		 * @method setReplyPanel
		 * @desc set replay panel
		 */
        this.constructor.prototype.setReplyPanel = function(target) {
        	bpmext.log.info("StreamCards.setReplyPanel ENTER>>", this);
        	var stream = this.ui.getOption("streams").items[target.ui.getIndex()];
            if (stream && stream.replies && stream.replies.items){
            	var replies = stream.replies.items;
            	var replyNo = replies.length;
            	if(replyNo > 0) {
            		target.setVisible(true, true);
            	} else {
            		target.setVisible(false, true);
            	}
                var  nestedCommentsEle = query(".nestedComments", target.context.element)[0];
                domConstruct.empty(nestedCommentsEle);
                for(var i = 0; i < replyNo; i++) {
                	var comNode = this._proto._createComment(replies[i]);
                	nestedCommentsEle.appendChild(comNode);
                }
            }
        };

        /**
		 * @instance
		 * @memberof StreamCards
		 * @method toggleAddCommentLayout
		 * @desc toggle add comment layout
		 */
        this.constructor.prototype.toggleAddCommentLayout = function(target) {
        	bpmext.log.info("StreamCards.toggleAddCommentLayout ENTER>>", this);
        	var cl = target.ui.getSibling("AddCommentLayout");
        	var visible = cl && cl.getVisibility();
        	if(visible !== "NONE") {
        		cl.setVisible(false, true);
        	} else {
        		cl.setVisible(true, true);
        	}
        };

        /**
		 * @instance
		 * @memberof StreamCards
		 * @method addComment
		 * @desc add comment
		 */
        this.constructor.prototype.addComment = function(target) {
        	bpmext.log.info("StreamCards.addComment ENTER>>", this);
        	var stream = this.ui.getOption("streams").items[target.ui.getIndex()];
        	var commentCV = target.ui.getSibling("AddCommentText");
        	var newComment = commentCV.getData(), origCommentId = stream.object.id;
        	var parentView = this.ui.getParent();
        	parentView.addComment(newComment, origCommentId);

        };
        /**
		 * @instance
		 * @memberof StreamCards
		 * @method refresh
		 * @desc Reloads the mention list
		 */
        this.constructor.prototype.refresh = function() {
        	bpmext.log.info("StreamCards.refresh ENTER>>", this);
			this._proto._loadResource(this);
        };

		/**
		 * @instance
		 * @memberof StreamCards
		 * @method StreamCardsToggle
		 * @desc To expand or collapse panel
		 */
        this.constructor.prototype.StreamCardsToggle = function() {
			bpmext.log.info("StreamCards.StreamCardsToggle ENTER >>", this);
			var domObj = this.context.element;

			var btnElement = this._instance.buttonCV && this._instance.buttonCV.context.element.querySelector(".btn[role=button]");
			btnElement && btnElement.focus();

			if(this._instance.mentionsCV.isExpanded()){
				domClass.add(domObj,"collapse");
				this._instance.mentionsCV.collapse();
			}else{
				domClass.remove(domObj,"collapse");
				this._instance.mentionsCV.expand();
			}
		};

        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function ()
        {
        	bpmext.log.info("StreamCards.load ENTER >>", this);
        	var opts = this.context.options;

        	if (!opts.streams) {
                 bpmext.ui.substituteConfigOption(this, "streams", []);
            }

        	this._instance.cardsWrapper = bpmext.ui.getContainer("TLStreamCards", this);

        	this.loadContainer(this);

            bpmext.log.info("StreamCards.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try
            {
                utilities.handleVisibility(this.context);
            }
            catch (e)
            {
                //{#feature: US-1330 Added RT localization}
                //bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if(e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    //bpmext.log.error("  Call stack: " + e.stack);
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                }
            }
        };

        this.constructor.prototype.change = function (event)
        {
        	bpmext.log.info("StreamCards.change ENTER >> (event): " + event, this);
			if (event.type === "config") {
                switch (event.property) {
                    case "_metadata.visibility": {
                        this.view();
                        break;
                    }
                }
            }
             bpmext.log.info("StreamCards.change EXIT >>", this);
        };

        this.constructor.prototype.unload = function ()
        {
            bpmext.ui.unloadView(this);
        };
    }
};