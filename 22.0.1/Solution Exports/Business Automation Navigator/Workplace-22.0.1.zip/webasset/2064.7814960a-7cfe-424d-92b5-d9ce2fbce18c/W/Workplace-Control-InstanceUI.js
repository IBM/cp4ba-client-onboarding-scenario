/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof InstanceUI
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof InstanceUI
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof InstanceUI
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof InstanceUI
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof InstanceUI
 * @method setData
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 * 
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>This event is fired when the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 * 
 *   <tr class=Prop>
 *     <td>On instance UI launched:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>This event is fired when an instance is launched</td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 * 
 *   <tr class=Prop>
 *     <td>On instance closed:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>This event is fired when an instance is closed</td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 * 
 *   <tr class=Prop>
 *     <td>On instance action:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>This event is fired when an action is triggered from the action menu (for example, modify, terminate, suspend)</td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 * 
 *   <tr class=Prop>
 *     <td>On instance tab change:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>This event is fired when the user changes the instance tab</td>
 *         </tr>
 *       </table>
 *       <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">oldTabIndex {Number}</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">previous tab index</td>
 *               </tr>
 *       </table>
 *      <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">tabIndex {Number}</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">current tab index</td>
 *               </tr>
 *       </table>
 *     </td>
 *   </tr>
 * 
 *   <tr class=Prop>
 *     <td>On instance comment post:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>This event is fired when a comment is posted in the Overview setion</td>
 *         </tr>
 *       </table>
 *       <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">data {object}</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">comment data</td>
 *               </tr>
 *       </table>
 *     </td>
 *   </tr>
 * 
 *   <tr class=Prop>
 *     <td>On instance activity selected:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>This event is fired when an activity is selected from the Activities section</td>
 *         </tr>
 *       </table>
 *       <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">activity {object}</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">activity data</td>
 *               </tr>
 *       </table>
 *     </td>
 *   </tr>
 * </table>
 */
workplace_control_InitInstanceUI = function (utilities, taskUtils, resourceUtils, domConstruct, wpResources, domStyle, domClass)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            OPT_ALL_ACT: "activityAll",
            OPT_INPROGRESS_ACT: "activityInProgress",
            OPT_COMPLETED_ACT: "activityCompleted",
            OPT_APPROVED_ACT: "activityApproved",
            OPT_REJECTED_ACT: "activityRejected",

            EVT_ONLOAD: "eventON_LOAD",
            EVT_ONINSTANCE_OPENED: "eventON_INSTANCE_OPENED",
            EVT_ONINSTANCE_CLOSED: "eventON_INSTANCE_CLOSED",
            EVT_ONINSTANCE_ACTION: "eventON_INSTANCE_ACTION",
            EVT_ONINSTANCE_TAB_CHANGE: "eventON_INSTANCE_TAB_CHANGE",
            EVT_ONINSTANCE_COMMENT_POST: "eventON_INSTANCE_COMMENT_POST",
            EVT_ONINSTANCE_ACTIVITY_SELECTED: "eventON_INSTANCE_ACTIVITY_SELECTED",

            TABS: {
                OVERVIEW: 0,
                TASKS: 1,
                ACTIVITIES: 2,
                DOCUMENTS: 3,
                HISTORY: 4
            },

            /* Initializes the view */
            _initView: function(view) {

                var opts = view.context.options;

                if (!opts.instance) {
                    bpmext.ui.substituteConfigOption(view, "instance", {});
                }

                if (!opts.responsiveMode) {
                    bpmext.ui.substituteConfigOption(view, "responsiveMode", "LARGE");
                }

                if (!opts.processMode) {
                    bpmext.ui.substituteConfigOption(view, "processMode", false);
                }

                if (!opts.enableHistoryNav) {
                    bpmext.ui.substituteConfigOption(view, "enableHistoryNav", false);
                }

                if (!opts.skipClaimForTasks) {
                    bpmext.ui.substituteConfigOption(view, "skipClaimForTasks", false);
                }

                view._proto._initImages(view);

                // Instance info
                view._instance.instanceStatus = bpmext.ui.getView("Instance_Status", view);

                //Tabs
                view._instance.tabContainer = bpmext.ui.getContainer("InstanceTabs", view);

                // Overview
                view._instance.overviewSection = bpmext.ui.getContainer("Overview_Section", view);
                view._instance.overviewContent = bpmext.ui.getView("Overview_Content", view);
                view._instance.dueDate = bpmext.ui.getView("Due", view);
                view._instance.completionDate = bpmext.ui.getView("Complete", view);
                view._instance.modifiedDate = bpmext.ui.getView("Modified", view);
                view._instance.overviewDue = bpmext.ui.getView("OverviewDue", view);
                view._instance.processName = bpmext.ui.getView("ProcessName", view);
                view._instance.progressWrapper = bpmext.ui.getContainer("Progress_Wrapper", view);
                view._instance.progressBarCreatedText = bpmext.ui.getView("ProgressBarCreatedText", view);
                view._instance.progressBar = view._instance.progressWrapper.context.element.querySelector(".Progress-bar");
                view._instance.summaryTitle = bpmext.ui.getView("SummaryTitle", view);
                view._instance.summaryTitle._instance.outputText.setAttribute("role", "heading");
                view._instance.summaryTitle._instance.outputText.setAttribute("aria-level", "2");
                view._instance.commentsTitle = bpmext.ui.getView("Comment_Section_Title", view);
                view._instance.commentsTitle._instance.outputText.setAttribute("role", "heading");
                view._instance.commentsTitle._instance.outputText.setAttribute("aria-level", "2");

                view._instance.dueDate.setLabelVisible(true);
                view._instance.completionDate.setLabelVisible(true);
                view._instance.modifiedDate.setLabelVisible(true);
                view._instance.overviewDue.setLabelVisible(false);
                view._instance.overviewContent.setLabelVisible(false);
                view._instance.progressBarCreatedText.setLabelVisible(false);
                domClass.add(view._instance.dueDate.context.element, "trailingSeparator");

                // Documents
                view._instance.activityDocumentSection = bpmext.ui.getContainer("Activity_File_Section", view);
                view._instance.activityDocumentsCards = bpmext.ui.getContainer("Activity_Documents_Cards", view);
                view._instance.documentsTable = bpmext.ui.getContainer("InstanceDocumentsTable", view);
                view._instance.documentsPanel = bpmext.ui.getContainer("DocumentsPanel", view);
                view._instance.noDocumentsToDisplayView = bpmext.ui.getContainer("NoInstanceDocumentsToDisplayView", view);

                view._proto._initDocumentsPanel(view);

                // Data
                view._instance.systemDataCards = bpmext.ui.getContainer("System_Data_Cards", view);
                view._instance.dataCards = bpmext.ui.getContainer("Data_Cards", view);
                view._instance.activityDataCards = bpmext.ui.getContainer("Activity_Data_Cards", view);
                view._instance.activityDataSection = bpmext.ui.getContainer("Activity_Data_Section", view);

                // Comments
                view._instance.commentSection = bpmext.ui.getContainer("Comment_Section", view);
                view._instance.commentCards = bpmext.ui.getContainer("Comment_Cards", view);
                view._instance.activityCommentSection = bpmext.ui.getContainer("Activity_Comment_Section", view);
                view._instance.activityCommentCards = bpmext.ui.getContainer("Activity_Comment_Cards", view);
                view._instance.noCommentsFound = bpmext.ui.getContainer("No_Comments_Found", view);
                view._instance.noCommentsFoundText = bpmext.ui.getView("NoCommentsText", view);
                view._instance.addCommentsLink =  bpmext.ui.getView("AddCommentsLink", view);
                view._instance.postCommentButton = bpmext.ui.getView("PostCommentButton", view);
                view._instance.cancelCommentButton = bpmext.ui.getView("CancelCommentButton", view);
                view._instance.commentBox = bpmext.ui.getView("CommentBox", view);
                view._instance.commentBoxLayout = bpmext.ui.getContainer("CommentsBoxLayout", view);
                view._proto._initCommentsSection(view);

                // Activities
                view._instance.activitySelector = bpmext.ui.getView("Activity_State", view);
                view._instance.activityCards = bpmext.ui.getContainer("Activity_Cards", view);
                view._instance.activityPanelLayout = bpmext.ui.getContainer("InstanceActivitiesLayout", view);
                view._instance.noActivitiesPanel = bpmext.ui.getContainer("NoInstanceActivitiesPanel", view);
                view._instance.noActivitiesTable = bpmext.ui.getContainer("NoInstanceActivitiesToDisplayView", view);
                view._instance.noActivitiesComments = bpmext.ui.getContainer("NoInstanceActivitiesCommentsView", view);
                view._instance.noActivitiesCommentsText = bpmext.ui.getView("NoInstanceActivitiesCommentsText", view);
                view._instance.noActivitiesData = bpmext.ui.getContainer("NoInstanceActivitiesDataView", view);
                view._instance.noActivitiesDataText = bpmext.ui.getView("NoInstanceActivitiesDataText", view);
                view._instance.noActivitiesDocuments = bpmext.ui.getContainer("NoInstanceActivitiesDocumentsView", view);
                view._instance.noActivitiesDocumentsText = bpmext.ui.getView("NoInstanceActivitiesDocumentsText", view);
                view._instance.startableActivityCards = bpmext.ui.getContainer("Activity_Startable_Cards", view);
                view._instance.startableActivityPanelLayout = bpmext.ui.getContainer("Activity_Startable_Section", view);
                view._proto._initActivitiesPanel(view);

                // History
                view._instance.historyTable = bpmext.ui.getContainer("InstanceHistoryTable", view);
                view._instance.historyPanel = bpmext.ui.getContainer("HistoryPanel", view);
                view._instance.noHistoryToDisplayView = bpmext.ui.getContainer("NoInstanceHistoryToDisplayView", view);
                view._proto._initHistoryPanel(view);

                // Modify instance modal
                view._instance.modifyInstanceModal = bpmext.ui.getContainer("Modify_Instance_Modal", view);

                // Claimed task modal
                view._instance.claimedTaskModal = bpmext.ui.getContainer("Claim_Task_Modal", view);
                view._instance.claimedTaskModal.setTargetEvents([taskUtils.EVENTS.INSTANCE_TASK_BEFORE_LAUNCH]);

                // Workstream error detail modal
                view._instance.workstreamErrorDetailModal = bpmext.ui.getContainer("WorkstreamErrorDetailModal", view);

                view._instance.actionsMenu = bpmext.ui.getView("Actions_Menu", view);
                view._instance.actionsMenu.settingTaskLaunchingEvents(taskUtils.EVENTS.INSTANCE_TASK_BEFORE_LAUNCH);

                // Instance Action menu
                view._instance.instanceActionMenuButton = bpmext.ui.getView("Instance_Actions_Menu_Btn", view);
                view._instance.instanceActionsMenu = bpmext.ui.getContainer("Workstream_Actions_Menu", view);
                view._instance.instanceActionsMenu.handelBtnVisibilityOnEmpty(view._instance.instanceActionMenuButton, true);

                // Navigation bar
                view._instance.navigationBar = bpmext.ui.getContainer("Workplace_Navigation_Bar1", view);

                // Reload button
                view._instance.reloadBtn = bpmext.ui.getView("Reload_Instance_Btn", view);
                view._instance.lastRefreshed = new Date();
                view._proto._setRefreshButtonTooltip(view);

                //Task list
                view._instance.taskListView = bpmext.ui.getView("InstanceTaskList", view);

                view._instance.taskListView.configBatchModify({
                    rejectedTasks: {
                        notOwnedTask: true
                    }
                });

                view._proto._initFilter(view);
                view._proto._localizingLabels(view);
                view._proto._accessibilities(view);

                //Let the page context know that we are running a Workplace view
                domClass.add(document.getElementById("mainBody"), "Workplace");

                //Close button
                view._instance.closeBtn = bpmext.ui.getView("CloseButton", view);

                if(!opts.enableHistoryNav.get("value")){
                    view._instance.closeBtn.setVisible(true,false);
                    view._instance.navigationBar.setVisible(false,true);
                }

                if(opts.embededView.get("value")){
                    view._instance.closeBtn.setVisible(false,true);
                }

                // Binding Events
                bpmext.ui.registerEventHandlingFunction(view, view._proto.EVT_ONLOAD);
                bpmext.ui.registerEventHandlingFunction(view, view._proto.EVT_ONINSTANCE_OPENED,"eventData");
                bpmext.ui.registerEventHandlingFunction(view, view._proto.EVT_ONINSTANCE_CLOSED);
                bpmext.ui.registerEventHandlingFunction(view, view._proto.EVT_ONINSTANCE_ACTION);
                bpmext.ui.registerEventHandlingFunction(view, view._proto.EVT_ONINSTANCE_TAB_CHANGE, "oldTabIndex", "tabIndex");
                bpmext.ui.registerEventHandlingFunction(view, view._proto.EVT_ONINSTANCE_COMMENT_POST, "data");
                bpmext.ui.registerEventHandlingFunction(view, view._proto.EVT_ONINSTANCE_ACTIVITY_SELECTED, "activity");

                // Activated on instance info fetched (with complete instance info)
                taskUtils.EVENTS.INSTANCE_FETCHED.subscribe(function (eventName, eventData) {
                    var instance = eventData && eventData.instance;

                    if (instance) {
                        taskUtils.EVENTS.VIEW_INSTANCE.publish();
                        view.setInstance(instance);
                    }

                    //update the current instance info to the parent frame if needed
                    if (parent && parent !== parent.parent) {
                        try {
                            var data = {
                                name: "updateInstanceInfo",
                                instance: instance
                            };
                            parent.parent.postMessage(JSON.stringify(data), "*");
                        } catch (e) {
                            bpmext.log.error("InstanceUI._fetchInstance " + bpmext.localization.formatMsg("general", "ERROR") + ": " + e);
                            if (e.stack) {
                                bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                            }
                        }
                    }

                }, view);

                // Showing instance content
                taskUtils.EVENTS.VIEW_INSTANCE.subscribe(function (eventName, eventData) {
                    bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONINSTANCE_OPENED, eventData);
                }, view);

                // Activated after the instance ad hoc activities are fetched
                taskUtils.EVENTS.INSTANCE_ADHOC_ACTIVITIES_FETCHED.subscribe(function (eventName, eventData) {
                    var activities = eventData && eventData.activities;
                    var systemID = eventData && eventData.systemID;

                    //clean the instance id in case it is of the form 2072.206
                    eventData.instanceId = eventData.instanceId.substring(eventData.instanceId.indexOf(".")+1);
                    if (activities && view._instance.processedData.header.instanceID === eventData.instanceId) {
                        view._proto._settingAdhocActivities(view, activities, systemID);
                    }
                }, view);

                // Activated after the instance history stream is fetched
                taskUtils.EVENTS.INSTANCE_HISTORY_STREAM_FETCHED.subscribe(function (eventName, eventData) {
                    var history = eventData && eventData.history;

                    //clean the instance id in case it is of the form 2072.206
                    eventData.instanceId = eventData.instanceId.substring(eventData.instanceId.indexOf(".")+1);
                    if (history && view._instance.processedData.header.instanceID === eventData.instanceId) {
                        view._proto._settingHistory(view, history);
                    }
                }, view);
                
                // Respond to instance changes
                taskUtils.EVENTS.RELOAD_INSTANCE.subscribe(view.reloadInstance, view);

                // Respond to shell actions
                taskUtils.EVENTS.CLOSE_INSTANCE.subscribe(function () {
                    if(!view.context.options.enableHistoryNav.get("value")){
                        view.closeInstance();
                    }else{
                        taskUtils.viewHistory.loadViewFromHistory();
                    }
                }, view);

                // Config for the instance action menu
                taskUtils.EVENTS.CONFIG_INSTANCE_CONTROL.subscribe(function(eventName, eventData){
                    var actions = eventData && eventData.actions;
                    var ident = eventData && eventData.ident;
                    var target = view._instance.instanceActionMenuButton.context.element.querySelector(".SPARKIcon.btn");

                    if (ident && ident.piid) {
                        view._instance.instanceActionsMenu.loadMenu(target, ident, null, actions);
                    }
                }, view);

                // Respond to open modify instance modal
                taskUtils.EVENTS.MODIFY_INSTANCE_OPEN.subscribe(view.modifyInstance, view);

                taskUtils.EVENTS.FOLLOW_INSTANCE.subscribe(view.followInstance, view);

                taskUtils.EVENTS.UNFOLLOW_INSTANCE.subscribe(view.unFollowInstance, view);

                // Respond to task field changes
                taskUtils.EVENTS.MODIFY_INSTANCE_CLOSE.subscribe(function() {
                    bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONINSTANCE_ACTION);
                    view.reloadInstance();
                }, view);
                
                // Respond to task field changes
                taskUtils.EVENTS.ACTION_PERFORMED.subscribe(function() {
                    bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONINSTANCE_ACTION);
                    view.reloadInstance();
                }, view);

                // Respond to task field changes
                taskUtils.EVENTS.TASK_FIELD_CHANGED.subscribe(view.taskListNotificationsHandler, view);
                taskUtils.EVENTS.TASKLIST_TASK_RESOURCE_ASSIGNED.subscribe(function(){
                    view._instance.tabContainer.setPaneVisible(true, [1]);
                    view.taskListNotificationsHandler();
                }, view);

                // Backup reload method when notification failed
                taskUtils.EVENTS.DELAY_RELOAD.subscribe(view.delayReload, view);

                //if a binding was passed in, use it to load the instance
                if (view.context.binding) {
                    var instanceSummary = view.context.binding.get("value");
                    if (instanceSummary) {
                        var instanceId = instanceSummary.get("instanceId");
                        if (instanceId) {
                            // Minimize info for restoring instance back
                            view._instance.viewerObj = {
                                data: {
                                    piid: instanceId,
                                    name: instanceSummary.get("name")
                                }
                            };
                            //Hide the nav bar since it is not needed when the view is loaded remotely
                            view._instance.navigationBar.setVisible(false, true);
                            view._proto._fetchInstance(view, instanceId);
                        }
                    }
                }
                view.setVisible(opts.processMode.get("value"), true);

                view._proto._processPendingEvents(view);
            },

            _wakeUp: function(view, pendingEvent) {
                view._instance.pendingEvent = pendingEvent;
                if (!view._instance.instanceDeferredSection.isLoaded()) {
                    view._instance.instanceDeferredSection.lazyLoad();
                } else {
                    view._proto._processPendingEvents(view);
                }
            },

            _processPendingEvents: function(view) {
                if (view._instance.pendingEvent) {
                    var pendingEvent = view._instance.pendingEvent;
                    pendingEvent.func(pendingEvent.eventName, pendingEvent.eventData);
                    view._instance.pendingEvent = null;
                }
            },

            /*
            * Skeleton
            *
            * Fetching instance data:
            *   => event: BEFORE_VIEW_INSTANCE ({piid, systemID})
            *   => function: _fetchInstance
            *   => event: INSTANCE_FETCHED ({instance})
            *   => event: VIEW_INSTANCE()
            *   => function: setInstance
            *
            * Loading instance data:
            *   => function: _loadInstance
            *   => function: _composeData
            *   => function: _mappingDataToControls
            */


            /******************** Fetching data - start ********************/
            _fetchInstance: function(view, instanceID, systemID) {
                bpmext.log.info("InstanceUI._fetchInstance ENTER >>: ", view);

                if (!instanceID && instanceID !== 0) {
                    return;
                }

                if (view._instance.blockMultipleLoads) {
                    return;
                }

                try{
                    var successFetchInstanceAdHocActivities = function(adhocActivities) {
                        var activities = (adhocActivities && adhocActivities.activities) ? adhocActivities.activities : (adhocActivities && adhocActivities.data ? adhocActivities.data.activities : []);
                        if (activities && activities.length > 0) {
                            taskUtils.EVENTS.INSTANCE_ADHOC_ACTIVITIES_FETCHED.publish({
                                instanceId: instanceID,
                                activities: activities,
                                systemID: systemID
                            });
                        }
                    };

                    var errorFetchInstanceAdhocActivities = function (error) {
                        bpmext.log.error("ERROR >> There was an error fetching the Instance add-hoc activities: " + error);
                    };

                    var successFetchInstanceHistory = function(stream) {
                        var history = (stream && stream.items) ? stream.items : (stream && stream.data ? stream.data.items : []);
                        if (history && history.length > 0) {
                            taskUtils.EVENTS.INSTANCE_HISTORY_STREAM_FETCHED.publish({
                                instanceId: instanceID,
                                history: history
                            });
                        }
                    };

                    var errorFetchInstanceHistory = function (error) {
                        bpmext.log.error("ERROR >> There was an error fetching the Instance history stream: " + error);
                    };

                    var successFetchInstance = function (instance) {
                        // unlock fetching instance
                        view._instance.blockMultipleLoads = false;

                        taskUtils.EVENTS.INSTANCE_FETCHED.publish({
                            instance: instance
                        });

                        //only retrieve the adhoc activities and stream after the instance has been fetched
                        if (!taskUtils.isWorkstreamProcess(instance)) {
                            wpResources.process.getAdHocActivities({piid: instanceID, systemID: systemID}).then(
                                successFetchInstanceAdHocActivities,
                                errorFetchInstanceAdhocActivities
                            );
                        }
                        wpResources.social.getStreamForInstance({piid: instanceID, systemID: systemID}).then(
                            successFetchInstanceHistory,
                            errorFetchInstanceHistory
                        );
                };

                    var errorFetchInstance = function (error) {
                        bpmext.log.error("ERROR >> There was an error fetching the Instance UI: " + error);

                        // unlock fetching instance
                        view._instance.blockMultipleLoads = false;

                        wpResources.process.reportInstanceError({piid: instanceID,  systemID: systemID});
                        taskUtils.EVENTS.INSTANCE_ERROR.publish({piid: instanceID, systemID: systemID});
                        taskUtils.viewHistory.loadViewFromHistory();
                    };

                    // lock down fetching instance
                    view._instance.blockMultipleLoads = true;

                    view._proto._resetViews(view);
                    view.show();

                    wpResources.process.get({piid: instanceID, systemID: systemID}).then(
                        successFetchInstance,
                        errorFetchInstance
                    );
                } catch (data) {
                    view._proto._errorLoadInstance(data);
                }

                bpmext.log.info("InstanceUI._fetchInstance EXIT >>: ", view);
            },

            _errorLoadInstance: function _errorLoadTasks(data) {
                bpmext.log.error("InstanceUI._errorLoadInstance ERROR >> There was an error loading the Instance UI (data): " + data, this);
            },

            /******************** Fetching data - end ********************/



            /******************** Load instance data - start ********************/
            _loadInstance: function _loadInstance (view, instance) {
                // init false positive indicator
                view._instance.dirtyData = false;
                !! view._instance.cleanDirtyDataTimeout && clearTimeout(view._instance.cleanDirtyDataTimeout);

                // compose default data and set to UI
                view._instance.processedData = view._proto._composeData(view, instance);

                // if false positive happens - resulted by the instance & WS instance data sync
                // then do the reload instance to make correction (at most 5 times = Fault tolerance at most 2 seconds)
                if ((instance.executionState === "Active") && view._instance.dirtyData && ((view._instance.numberOfDirtyReloads || 0) < 5)) {
                    !! view._instance.cleanDirtyDataTimeout && clearTimeout(view._instance.cleanDirtyDataTimeout);

                    // reduce number of calls
                    view._instance.cleanDirtyDataTimeout = setTimeout(function () {
                        view._instance.numberOfDirtyReloads = (view._instance.numberOfDirtyReloads || 0) + 1;
                        view.reloadInstance();
                    }, 400);
                } else {
                    view._instance.numberOfDirtyReloads = 0;
                    view._proto._mappingDataToControls(view, view._instance.processedData);
                }
            },
            /******************** Load instance data - end ********************/



            /******************** Compose data - start ********************/
            _composeData: function _composeData (view, instance) {
                return !instance ? {} : [
                    view._proto._extractHeaderData,
                    view._proto._extractDocumentsData,
                    view._proto._extractData,
                    view._proto._composeTasks,
                    view._proto._composeActivities,
                    view._proto._composeDanglingTasks,
                    view._proto._extractOverviewData,
                    view._proto._extractComments
                ].reduce(function (aggregatedData, fun) {
                    return fun(view, instance, aggregatedData);
                }, {comments: null});
            },

            /********** data for header section - start **********/
            _extractHeaderData: function _extractHeaderData(view, instance, target) {
                if (!target) {
                    target = {};
                }
                target.isWorkstream = (target.isWorkstream === undefined) ? taskUtils.isWorkstreamProcess(instance) : false;
                target.header = {
                    instanceName: instance.name,
                    instanceID: instance.piid,
                    statusImageURL: taskUtils.getInstanceDueStatusImageURL(instance),
                    instanceStatusLabel: taskUtils.getDueStatusLabel(instance)
                };

                return target;
            },
            /********** data for header section - end **********/


            /********** data for documents section - start **********/
            _extractDocumentsData: function _extractDocumentsData (view, instance, target) {
                if (!target) {
                    target = {};
                }

                target.documents = taskUtils.compose([
                	view._proto._mergingDocumentsData,
                	view._proto._documentAttributeChecking,
                ])([
                    view._proto._extractInstanceDocuments(instance),
                    view._proto._extractWorkstreamInstanceDocuments(instance)
                ]);

                return target;
            },

            _extractInstanceDocuments: function _extractInstanceDocuments (instance) {
                return instance.documents || [];
            },

            _extractWorkstreamInstanceDocuments: function _extractWorkstreamInstanceDocuments (instance) {
                var workstreamDocuments = instance.variables && instance.variables._documents && instance.variables._documents.items;
                return  workstreamDocuments || [];
            },

            _mergingDocumentsData: function _mergingDocumentsData (instanceDocuments, workstreamDocuments) {
                var documents = [];
                for (var i=0; i<workstreamDocuments.length; i++) {
                    var addDoc = true;
                    var workstreamDoc = workstreamDocuments[i];

                    for (var j=0; j<instanceDocuments.length; j++) {
                        var doc = instanceDocuments[j];

                        // duplicate doc
                        if ((workstreamDoc.ecmID === doc.ecmID) || (workstreamDoc.url && workstreamDoc.url.indexOf(doc.ecmID) > -1)) {
                            addDoc = false;
                            instanceDocuments[j] = Object.assign({}, doc, workstreamDoc);
                            break;
                        }
                    }

                    addDoc && documents.push(workstreamDoc);
                }

                documents = documents.concat(instanceDocuments);
                return documents;
            },

            _documentAttributeChecking: function _documentAttributeChecking(documents) {
            	return documents;
            },
            /********** data for documents section - end **********/


            /********** data for data section - start **********/
            _extractData: function _extractData (view, instance, target) {
                if (!target) {
                    target = {};
                }

                target.data = instance.businessData.filter(function (data) {
                    return data.name !== "workstreamDefintion.description";
                });

                for(var key in instance.variables.__workstreamData){
                    if(Object.prototype.hasOwnProperty.call(instance.variables.__workstreamData, key)) {
                        var obj = instance.variables.__workstreamData[key];
                        var id = obj["id"];
                        var value = new Date(obj["value"]);
                        var type = obj["type"];

                        target.data.forEach(function(element) {
                            if(element.name.indexOf(id) > -1 && new Date(element.value).toString() === value.toString()){
                                element.type = type;
                            }
                        });
                    }
                }

                return target;
            },
            /********** data for data section - end **********/

            /********** data for comments section - start **********/
            _extractComments: function _extractComments(view, instance, target) {
                if (!target) {
                    target = {};
                }
                target.comments = instance.comments;

                //check if user can post comments
                target.canPostComments = (instance.actions.indexOf("ACTION_ADD_COMMENT") !== -1);

                return target;
            },
            /********** data for  section - end **********/


            /*********** build a task Dictionary - start **********/
            _composeTasks: function _composeTasks (view, instance, target) {
                if (!target) {
                    target = {};
                }

                var systemID = view._instance.viewerObj.data.systemID;
                var patchAdditionData = function (executionRecords) {
                    return function (dict) {
                        return  view._proto._patchAdditionData(executionRecords, dict);
                    };
                }(view._proto._extractTaskExecutionRecords(instance));

                target.tasks = taskUtils.compose([
                    view._proto._appendSystemID,
                    view._proto._filterUserTasks,
                    view._proto._buildTasksDictionary,
                    patchAdditionData
                ])([instance.tasks || [], systemID, target.isWorkstream]);

                return target;
            },

            _extractTaskExecutionRecords: function _extractTaskExecutionRecords (instance) {
                var executionRecord = instance.variables && instance.variables._execution && instance.variables._execution.items;
                return executionRecord || [];
            },

            _appendSystemID: function _appendSystemID (tasks, systemID, workstreamFlag) {
                return tasks.map(function (task) {
                    task.systemID = task.systemID || systemID;
                    task.IS_WORKSTREAM = workstreamFlag ? "true" : "false";
                    return task;
                });
            },

            _filterUserTasks: function _filterUserTasks (tasks) {
                return tasks.filter(function (task) {
                    return taskUtils.isUserTask(task);
                });
            },

            // dict returns immutable data
            _buildTasksDictionary: function (tasks) {
                var sortByStatus = function(a, b) {
                    var statusA = a.status, statusB = b.status;
                    if (statusB > statusA) {
                        return 1;
                    } else if (statusB < statusA) {
                        return -1;
                    } else {
                        return 0;
                    }
                };

                return {
                    dict: tasks.reduce(function(dict, task) {
                        var tkiid = task.tkiid || task["tkiid"];
                        dict[tkiid] = task;
                        return dict;
                    }, {}),

                    fetchTaskByID: function (taskID) {
                        return dojo.clone(this.dict[taskID]);
                    },

                    fetchTaskByIDs: function (taskIDs, sortFunc) {
                        var _this = this;
                        var tasks = (taskIDs || []).reduce(function (tasks, taskID) {
                            var task = _this.fetchTaskByID(taskID);
                            task && tasks.push(task);
                            return tasks;
                        }, []);
                        return sortFunc ? tasks.sort(sortFunc) : tasks.sort(sortByStatus);
                    },

                    fetchAllTasks: function (sortFunc) {
                        return sortFunc ? dojo.clone(Object.values(this.dict).sort(sortFunc)) : dojo.clone(Object.values(this.dict).sort(sortByStatus));
                    },

                    fetchAllTaskIDs: function () {
                        return dojo.clone(Object.keys(this.dict));
                    },

                    patchAdditionalData: function (taskID, termName, extraData) {
                        var task = this.dict[taskID];
                        if (typeof extraData !== "object" || !task) {
                            return false;
                        }

                        task[termName] = Object.assign({}, task[termName], extraData);

                        return true;
                    }
                };
            },

            _patchAdditionData: function _patchAdditionData (executionRecords, taskDict) {
                executionRecords.forEach(function (executionRecord) {
                    var record = dojo.clone(executionRecord);

                    var patchingFields = ["completedBy", "timestamp", "approved", "activityId", "comments", "activityType"];
                    var recordKeys = dojo.clone(Object.keys(record));
                    recordKeys.forEach(function (field) {
                        if (patchingFields.indexOf(field) < 0) {
                            delete record[field];
                        }
                    });

                    taskDict.patchAdditionalData(executionRecord.taskId, "_EXTRA_DATA", record);
                });
                return taskDict;
            },
            /********** build a task Dictionary - end **********/

            /********** data for activities - start **********/
            _composeActivities: function _composeActivities(view, instance, target) {
                if (!target) {
                    target = {};
                }

                var summarizeActivities = function (activities) {
                    return view._proto._summarizeActivities(view, target, activities);
                };

                target.activities = taskUtils.compose([
                    view._proto._getAllExecutionRecords,
                    view._proto._extractActivities,
                    summarizeActivities
                ])([view, instance, target]);

                return target;
            },

            _extractSteps: function _extractSteps (instance) {
                var steps = instance.variables && instance.variables.steps && instance.variables.steps.items;
                return steps || [];
            },

            _getAllExecutionRecords: function (view, instance, target) {
                var steps = view._proto._extractSteps(instance);
                var allTaskIDs = view._proto._getAllTaskIDs(target);

                var executionRecords = view._proto._extractTaskExecutionRecords(instance);
                var instanceExecutionRecordTaskIDs = executionRecords.map(function (record) {
                    return record.taskId;
                });

                var danglingTaskIDs = view._proto._extractDanglingTasks(allTaskIDs, instanceExecutionRecordTaskIDs);
                var tempExecutionRecords = view._proto._genTempExecutionRecords(target.tasks, danglingTaskIDs, steps);

                return [].concat(executionRecords).concat(tempExecutionRecords);
            },

            _genTempExecutionRecords: function _genTempExecutionRecords (dict, danglingTaskIDs, steps) {
                var tempExecutionRecords = [];

                if (!dict) {
                    return tempExecutionRecords;
                }

                var tasks = dict.fetchTaskByIDs(danglingTaskIDs);

                tasks.forEach(function (task) {
                    for (var i=0; i<steps.length; i++) {
                        if (steps[i].type !== "APPROVAL") {
                            var step = dojo.clone(steps[i]);
                            if (step.name === task.name || step.name === task.displayName) {
                                // converting data fields
                                step.activityName = step.name;
                                step.activityType = step.type;
                                step.activityId = step.name + "_" + i;
                                step.taskId = task.tkiid;

                                tempExecutionRecords.push(step);
                                break;
                            }
                        }
                    }
                });

                return tempExecutionRecords;
            },

            _extractActivities: function _extractActivities (executionRecords) {
                return executionRecords.reduce(function(activities, executionRecord){
                    var activity = activities[executionRecord.activityId];

                    if (!activity) {
                        activity = dojo.clone(executionRecord);
                        activity.subTasks = [];

                        var skippingFields = ["completedBy", "timestamp", "approved", "taskId", "comments"];
                        skippingFields.map(function(field){
                            if (Object.prototype.hasOwnProperty.call(activity, field)) {
                                delete activity[field];
                            }
                        });

                        activities[executionRecord.activityId] = activity;
                    }

                    var taskId = executionRecord.taskId;
                    activity.subTasks.push(taskId.slice(taskId.indexOf(".") + 1));

                    return activities;
                }, {});
            },

            _summarizeActivities: function _summarizeActivities (view, target, activities) {
                var taskDict = target.tasks;
                var steps = view._proto._extractSteps(view.getInstance());

                Object.keys(activities).forEach(function (activityID) {
                    var activity = activities[activityID];
                    var tasks = taskDict ? taskDict.fetchTaskByIDs(activity.subTasks || []) : [];

                    if (activity.activityType === "APPROVAL" && activity.approved === undefined) {
                        steps.forEach(function (step) {
                            if (step.name === activity.activityName && step.type === activity.activityType) {
                                activity._EXTRA_DATA = {
                                    approval: step.approval,
                                    assignees: (step.assignees && step.assignees.items) || []
                                };
                            }
                        });
                    }

                    taskUtils.composeMap([
                        view._proto._computeActivityStatus,
                        view._proto._computeActivityLatestTask
                    ])([view, activity, tasks]);
                });

                return activities;
            },

            _computeActivityStatus: function _computeActivityStatus (view, activity, tasks) {
                if (!tasks || tasks.length === 0) {
                    return;
                }

                var status = "";
                var tasksStatus = tasks.map(function (task) {
                    return taskUtils.getStatusLabel(task);
                });

                if (tasksStatus.indexOf(bpmext.localization.formatMsg("controlTaskList", "taskOverdue")) > -1 ||
                    tasksStatus.indexOf(bpmext.localization.formatMsg("controlTaskList", "taskAtRisk")) > -1 ||
                    tasksStatus.indexOf(bpmext.localization.formatMsg("controlTaskList", "taskOnTrack")) > -1) {
                    status = "activityInProgress";
                } else if (activity.activityType === "APPROVAL") {
                    var approvalStatus;

                    var sequentialReview = activity._EXTRA_DATA && activity._EXTRA_DATA.approval && activity._EXTRA_DATA.approval.sequentialReview;
                    var sequentialReviewAssignees = ((activity._EXTRA_DATA && activity._EXTRA_DATA.assignees) || []).length;

                    if (sequentialReview && (sequentialReviewAssignees > tasks.length)) {
                        status = "activityInProgress";
                    }

                    if (activity.allMustApprove) {
                        approvalStatus = tasks.reduce(function (approval, task) {
                            // false positive case, where instance task is complete but the execution haven't been updated
                            view._instance.dirtyData = task._EXTRA_DATA.approved === undefined;
                            return approval && (!!task._EXTRA_DATA && !!task._EXTRA_DATA.approved);
                        }, true);
                        status = approvalStatus ? (status || "activityApproved") : "activityRejected";
                    } else {
                        approvalStatus =  tasks.reduce(function (approval, task) {
                            // false positive case, where instance task is complete but the execution haven't been updated
                            view._instance.dirtyData = task._EXTRA_DATA.approved === undefined;
                            return approval || (!!task._EXTRA_DATA && !!task._EXTRA_DATA.approved);
                        }, false);
                        status = status || (approvalStatus ? "activityApproved" : "activityRejected");
                    }
                } else {
                    status = "activityCompleted";
                }

                activity.status = status;
            },

            _computeActivityLatestTask: function _computeActivityPriority (view, activity, tasks) {
                if (!tasks || tasks.length === 0) {
                    return;
                }

                activity.assignees = tasks.reduce(function (assignees, task) {
                    var assignee = task.owner || task.teamDisplayName;
                    if (assignees.indexOf(assignee) < 0) {
                        assignees.push(assignee);
                    }
                    return assignees;
                }, []);

                if (activity.status === "activityInProgress") {
                    // filter out active tasks
                    tasks = tasks.filter(function (task) {
                        return taskUtils.getStatusLabel(task) !== bpmext.localization.formatMsg("controlTaskList", "taskCompleted");
                    });
                    // false positive case, activity is still in progress, but no upcoming task
                    view._instance.dirtyData = tasks.length === 0;
                }

                tasks = tasks.sort(function (taskA, taskB) {
                    var taskADue = new Date(taskA.dueTime) || new Date();
                    var taskBDue = new Date(taskB.dueTime) || new Date();
                    return taskBDue > taskADue ? 1 : -1;
                });

                if (tasks.length > 0) {
                    activity.priority = tasks[0].priority;
                    activity.dueTime = tasks[0].dueTime;
                }
            },
            /********** data for activities - end **********/


            /********** find dangling tasks (tasks no belong to any activities) - start **********/
            _composeDanglingTasks: function (view, instance, target) {
                if (!target) {
                    target = {};
                }

                var allTasksIDs = view._proto._getAllTaskIDs(target);
                var allActivitiesTaskIDs = view._proto._getActivitiesTaskIDs(target);

                target.danglingTasks = view._proto._extractDanglingTasks(allTasksIDs, allActivitiesTaskIDs);

                return target;
            },

            _getAllTaskIDs: function (target) {
                return (target.tasks && target.tasks.fetchAllTaskIDs()) || [];
            },

            _getActivitiesTaskIDs: function _getActivitiesTaskIDs (target) {
                var activities = Object.values(target.activities);
                return (activities || []).reduce(function (tasks, activity) {
                    if (activity.subTasks) {
                        tasks = tasks.concat(activity.subTasks);
                    }
                    return tasks;
                }, []);
            },

            _extractDanglingTasks: function _extractDanglingTasks (allTasksIDs, allActivitiesTaskIDs) {
                return allTasksIDs.reduce(function (danglingTasks, taskID) {
                    if (allActivitiesTaskIDs.indexOf(taskID) < 0) {
                        danglingTasks.push(taskID);
                    }
                    return danglingTasks;
                }, []);
            },
            /********** data for activities - end **********/


            /********** data for overview section - start **********/
            _extractOverviewData: function _extractOverviewData(view, instance, target) {
                if (!target) {
                    target = {};
                }

                var workstreamDescription = instance.businessData.filter(function (data) {
                    return data.name === "workstreamDefintion.description";
                })[0];

                target.overview = {
                    instanceDescription: instance.description || (workstreamDescription ? workstreamDescription.value : null) || instance.name,
                    instanceCreateDate: instance.creationTime,
                    instanceModifiedDate: instance.lastModificationTime,
                    instanceDueDate: instance.dueDate,
                    instanceState: instance.executionState,
                    processName: instance.processTemplateName,
                    completionRate: taskUtils.compose([
                        view._proto._computeCompletionRate,
                        view._proto._completionRateRangeCheck
                    ])([view, instance, target])
                };

                return target;
            },

            _computeCompletionRate: function _computeCompletionRate(view, instance, target) {

                var percentComplete = 0;
                var remainingDays = 0, currentStatus = "onTrack", isComplete = false;
                //Completion check based on dates [completion  = (overdue date - creation creation date)]

                // if instance is completed, or already overdue return 100% complete
                if (target.header.instanceStatusLabel === bpmext.localization.formatMsg("searchFilter", "completed")) {
                    percentComplete = 100;
                    isComplete = true;
                } else if ([bpmext.localization.formatMsg("controlTaskList", "taskOverdue"),
                            bpmext.localization.formatMsg("controlTaskList", "instanceStatusTerminated")
                            ].indexOf(target.header.instanceStatusLabel) !== -1) {
                        percentComplete = 100;
                        currentStatus = "overdue";
                } else {
                    //it is before the due date, so calculate the percentage elapsed
                    percentComplete = taskUtils.getCompletionPercentage(instance);
                    if (taskUtils.isInstanceAtRisk(instance)) {
                        currentStatus = "atRisk";
                    }
                    var now = new Date();
                    var dueDate = new Date(instance.dueDate);
                    remainingDays = Math.ceil((dueDate - now) / (24*3600*1000));

                }

                return {percentComplete: percentComplete, overdueInDays: remainingDays, currentStatus: currentStatus, isComplete: isComplete};


                /*
                if (view.getOption("processMode", false) === false) {

                    //Note: this method only works under following assumptions
                    //  Assumptions:
                    //      1. steps are ordered in logic sequence

                    // instance completed completed
                    if (target.header.instanceStatusLabel === bpmext.localization.formatMsg("controlTaskList", "instanceStatusCompleted")) {
                        return 100;
                    }

                    var steps = view._proto._extractSteps(instance);
                    var stepsCompletion = taskUtils.compose([
                        view._proto._computeStepsCompletion,
                        view._proto._stepsCompletionCheck
                    ])([view, instance, target]);

                    // not a workstream instance
                    if (steps.length === 0) {
                        return 0;
                    }

                    // currentStep only existed in new workstreams (after init task)
                    var currentStep = instance.variables.currentStep;
                    if (currentStep) {
                        // find out cursor in all steps
                        var currentStepIndex = steps.reduce(function (stepIndex, step, index) {
                            var checkedResults = ["name", "type"].reduce(function (result, field) {
                                return result && currentStep[field] === step[field];
                            }, true);
                            return checkedResults? index : stepIndex;
                        }, -1);

                        if (currentStepIndex > -1) {
                            // find out if the cursor activity is marked as completed
                            currentStepIndex += stepsCompletion[currentStepIndex] ? 1 : 0;
                            return Math.round(currentStepIndex / steps.length * 100);
                        }
                    } else {
                        if (stepsCompletion.indexOf(false) > -1) {
                            // find the last in progress activity
                            return Math.round(stepsCompletion.indexOf(false) / stepsCompletion.length * 100);
                        } else {
                            return 100;
                        }
                    }
                } else {
                    //We are in process mode so just find the percentage of completed tasks
                    var x, completedTasks = 0;
                    if (instance.tasks) {
                        for (x=0; x<instance.tasks.length; x++) {
                            if (instance.tasks[x].completionTime) {
                                completedTasks++;
                            }
                        }
                        return Math.round(completedTasks/instance.tasks.length * 100);
                    }
                }
                return 0;
                */
            },

            _computeStepsCompletion: function _computeStepsCompletion(view, instance, target) {
                var steps = view._proto._extractSteps(instance);
                var activities = target.activities;

                // true - completed activity, false - in progress activity, null - unreached activity
                return steps.map(function (step) {
                    return Object.values(activities).reduce(function (isCompleted, activity) {
                        if ((step.name === activity.activityName) && (step.type === activity.activityType)) {
                            if (isCompleted === null) {
                                return activity.status !== view._proto.OPT_INPROGRESS_ACT;
                            } else {
                                return isCompleted && (activity.status !== view._proto.OPT_INPROGRESS_ACT);
                            }
                        }
                        return isCompleted;
                    }, null);
                });
            },

            _stepsCompletionCheck: function _stepsCompletionCheck (stepsCompletion) {
                var i;
                if (stepsCompletion.indexOf(false) > -1) {
                    for (i=stepsCompletion.indexOf(false); i<stepsCompletion.length; i++) {
                        stepsCompletion[i] = false;
                    }

                    stepsCompletion = stepsCompletion.map(function (isCompleted) {return isCompleted === null ? true : isCompleted;});
                } else if (stepsCompletion.indexOf(null) > -1) {
                    var splitPoint = stepsCompletion.lastIndexOf(true);

                    for (i=splitPoint; i>=0; i--) {
                        stepsCompletion[i] = true;
                    }

                    for (i=splitPoint+1; i<stepsCompletion.length; i++) {
                        stepsCompletion[i] = false;
                    }
                }
                return stepsCompletion;
            },

            _completionRateRangeCheck: function _completionRateRangeCheck(rate) {
                rate.percentComplete = (rate.percentComplete < 0) ? 0 : (rate.percentComplete > 100) ? 100 : rate.percentComplete;
                return rate;
            },
            /********** data for overview section - end **********/
            /******************** Compose data - end ********************/



            /******************** Mapping data to UI - start ********************/
            _mappingDataToControls: function _mappingDataToControls (view, processedData) {
                if (!processedData) {
                    return;
                }

                // set data for each section if been told to
                view._proto._settingOverview(view, processedData);
                !!processedData.documents && view._proto._settingDocuments(view, processedData.documents);
                !!processedData.data && view._proto._settingData(view, processedData.data);
                !!processedData.activities && view._proto._settingActivities(view, processedData.activities);
                !!processedData.danglingTasks && view._proto._settingDanglingTasks(view, processedData.danglingTasks);
                !!processedData.history && view._proto._settingHistory(view, processedData.history);

                view._proto._settingComments(view, processedData.comments);

                // setting instance actions
                view._proto._configControlActions(view);

            },

            /********** setting overview - start **********/
            // entry point
            _settingOverview: function _settingOverview(view, data) {
                var overview = data.overview || {};
                var headerData = data.header || {};

                view._proto._loadInstanceStatus(view, headerData);

                data.isWorkstream && !!overview.instanceDescription && view._instance.overviewContent.setData(overview.instanceDescription);
                view._instance.processName.setVisible(!data.isWorkstream && overview.processName, true);
                view._instance.processName.setData(overview.processName);

                //setting system data
                var createdDate = taskUtils.formatDate(new Date(overview.instanceCreateDate), true);
                var systemData = [
                    {label: bpmext.localization.formatMsg("instanceUI", "status"), value: headerData.instanceStatusLabel},
                    {label: bpmext.localization.formatMsg("instanceUI", "dateCreated"), value: createdDate},
                    {label: bpmext.localization.formatMsg("instanceUI", "dateModified"), value: taskUtils.formatDate(new Date(overview.instanceModifiedDate), true)},
                ];

                var hasDueDate = !!overview.instanceDueDate;
                var isComplete = overview.completionRate.isComplete;
                var hasModified = !!overview.instanceModifiedDate;
                if (isComplete) {
                    view._instance.completionDate.setVisible(isComplete, !isComplete);
                    view._instance.dueDate.setVisible(false, true);
                    view._instance.modifiedDate.setVisible(false, true);

                } else if (hasDueDate) {
                view._instance.dueDate.setVisible(hasDueDate, !hasDueDate);
                    view._instance.completionDate.setVisible(false, true);
                    view._instance.modifiedDate.setVisible(false, true);
                } else if (hasModified) {
                    view._instance.modifiedDate.setVisible(!hasDueDate, hasDueDate);
                    view._instance.dueDate.setVisible(false, true);
                    view._instance.completionDate.setVisible(false, true);
                }
                if (hasDueDate || isComplete || hasModified) {
                    var dateText = isComplete ? "completionDate" : "dueDate";
                    var date = isComplete ? overview.instanceModifiedDate : overview.instanceDueDate;
                    var formattedDate = taskUtils.formatDate(new Date(date), true);
                    view._instance.dueDate.setData(formattedDate);
                    view._instance.completionDate.setData(formattedDate);
                    view._instance.modifiedDate.setData(systemData[2].value);
                    if (hasDueDate || isComplete) {
                        systemData.push({label: bpmext.localization.formatMsg("instanceUI", dateText), value: formattedDate});
                        if (isComplete) {
                            view._instance.completionDate.context.element.classList.add("trailingSeparator");
                        }
                        view._instance.overviewSection.setVisible(true, false);
                    }
                    if (hasDueDate) {
                        var dueDate = taskUtils.formatDate(new Date(overview.instanceDueDate), true);
                        view._instance.dueDate.context.element.classList.add("trailingSeparator");
                    } else {
                        view._instance.overviewSection.setVisible(false, true);
                        view._instance.modifiedDate.context.element.classList.add("trailingSeparator");
                    }
                } else {
                    view._instance.dueDate.context.element.classList.remove("trailingSeparator");
                }
                if(!data.isWorkstream) {
                    systemData.push({label: bpmext.localization.formatMsg("instanceUI", "processName"), value: overview.processName});

                    bpmext.ui.util.showTooltip(
                        view._instance.processName.context.element,
                        bpmext.localization.formatMsg("instanceUI", "processTooltip"),
                        {horizontalPos: "LEFT", smartPositioning: true, openDelay: 0.5}
                    );
                }
                view._proto._setViewData(view._instance.systemDataCards, systemData, true);

                // setting progress
                domStyle.set(view._instance.progressBar, "width", (overview.completionRate.percentComplete || 0) + "%");
                domClass.remove(view._instance.progressBar, ["onTrack", "overdue", "atRisk"]);

                view._instance.progressBarCreatedText.setData(bpmext.localization.formatMsg("instanceUI", "createdTemplate", createdDate));
                var status = overview.completionRate.currentStatus;
                domClass.add(view._instance.progressBar, status);

                var dueText;
                if (overview.completionRate.isComplete === true) {
                    dueText = bpmext.localization.formatMsg("instanceUI", "isComplete");
                } else if (!overview.instanceDueDate) {
                    return;
                } else {
                    var daysUntilDue = taskUtils.getDaysUntil(overview.instanceDueDate);
                    dueText = taskUtils.getDueLabel(daysUntilDue);
                }
                view._instance.overviewDue.setData(dueText);
            },

            _loadInstanceStatus: function _loadInstanceStatus(view, headerData) {

                //The status shows either the state or status.  If the state is not "Active", then the status is shown
                var image = "";
                if (headerData.statusImageURL) {
                    var altText = bpmext.localization.formatMsg("instanceUI", "instanceState");
                    image = "<span class='instanceStatusIcon'><img src='" + headerData.statusImageURL + "' alt='" + altText + "'></img></span>";
                }
                var stateSpan = domConstruct.toDom("<span>" + image + "</span>");
                view._instance.instanceStatus.setData(stateSpan.outerHTML);

                bpmext.ui.util.showTooltip(
					view._instance.instanceStatus.context.element,
					headerData.instanceStatusLabel,
					{horizontalPos: "LEFT", smartPositioning: true, openDelay: 0.5}
				);
            },
            /********** setting overview - end **********/


            /********** setting documents - start **********/
            // entry point
            _settingDocuments: function _settingDocuments(view, documents, isForActivityOnly) {
                var checkedDocuments =  taskUtils.compose([
                    view._proto._documentsFieldsCheck,
                    view._proto._documentsOrdering
                ])([documents]);

                var isDocumentEmpty = checkedDocuments.length === 0;

                if (isForActivityOnly) {
                    view._proto._setViewData(view._instance.activityDocumentsCards, checkedDocuments, true);

                    if (isDocumentEmpty) {
                        var text = view._instance.noActivitiesDocumentsText.context.element.querySelector(".noActivitiesCardText");
                        text.innerText = bpmext.localization.formatMsg("instanceUI", "noDocumentsForActivity");
                    } else {
                        view._instance.noActivitiesDocuments.setVisible(false, true);
                    }

                } else {
                    view._proto._setViewData(view._instance.documentsTable, checkedDocuments, true);
                    view._instance.tabContainer.setPaneVisible(!isDocumentEmpty, [3]);
                    view._instance.documentsPanel.setVisible(!isDocumentEmpty, true);
                }
            },

            _documentsFieldsCheck: function _documentsFieldsCheck (documents) {
                return (documents || []).reduce(function (checkedDocument, document) {
                    if (document.name) {
                        if (document.ecmID || document.url) {
                            checkedDocument.push(document);
                        }
                    }
                    return checkedDocument;
                }, []);
            },

            _documentsOrdering: function (documents) {
                return (documents || []).sort(function (document1, document2) {
                    if (document1.name === document2.name) {
                        return 0;
                    }
                    return document1.name > document2.name ? 1 : -1;
                }, []);
            },

            _loadDocumentCard: function _loadDocumentCard(view, target, document, endpoint) {
                target.setVisible(false, true);

                var documentNameTemplate = "<DOCUMENT_NAME> (V<VERSION>)";
                var url = document.url || view._proto._buildDocumentURLString(view, document.ecmID, endpoint); // use pass in url first

                var documentTitle = target.context.getSubview("Activity_Document_Card_Title", target)[0];
                if (documentTitle) {
                    var documentTitleMain = documentTitle.context.getSubview("Activity_Document_Title_Main", documentTitle)[0];
                    if (documentTitleMain) {
                        var documentTitleName = documentTitleMain.context.getSubview("Activity_File_Name", documentTitleMain)[0];
                        var documentOwner = documentTitleMain.context.getSubview("Activity_File_Owner", documentTitleMain)[0];

                        documentTitleName.setLabelVisible(false, true);
                        documentOwner.setLabelVisible(false, true);

                        documentTitleName.setData(document.name);
                        !!document.creator && documentOwner.setData(document.creator);

                        documentOwner.setVisible(!!document.creator, true);
                    }
                }

                var documentBody = target.context.getSubview("Activity_Document_Card_Body", target)[0];
                if (documentBody) {
                    var documentIcon = documentBody.context.getSubview("Activity_Document_Type_Icon", documentBody)[0];
                    var documentName = documentBody.context.getSubview("Activity_Document_Name", documentBody)[0];

                    documentName.setLabelVisible(false, true);

                    documentIcon.setIcon("ci-attachment");
                    documentName.setText(documentNameTemplate.replace("<DOCUMENT_NAME>", document.name).replace("<VERSION>", document.version));
                    documentName.setLinkURL(url);
                }

                target.setVisible(true, true);
            },

            _buildDocumentURLString: function _buildDocumentURLString (view, ecmID, endpoint) {
                if (!ecmID) {
                    return "";
                }

                var ecmServerConfigurationName = "EMBEDDED_ECM_SERVER";
                var systemSnapshotID = view.context.bpm.system.snapshotId;
                var portalContextRoot = view.context.contextRootMap.processPortalSupport;

                return ((endpoint || "") + portalContextRoot + "/jsp/ecmDocument?operation=ajax_getDocumentContent&snapshotId=" +
                    systemSnapshotID + "&ecmServerConfigurationName=" + ecmServerConfigurationName + "&documentId=" + ecmID);
            },

            _launchDocument: function _launchDocument(view, document) {
                wpResources.systems.getFederationResults().then(function (systems) {
                    var endpoint = (systems[taskUtils.safeGet(view, "_instance.viewerObj.data.systemID".split("."))] || {}).endpoint;
                    var url = document.url || view._proto._buildDocumentURLString(view, document.ecmID, endpoint); // use pass in url first
                    window.open(url, "_blank");
                });
            },
            /********** setting documents - end **********/


            /********** setting data - start **********/
            // entry point
            _settingData: function _settingData(view, data, isForActivity) {
                var checkedData = taskUtils.compose([
                    view._proto._dataFieldsCheck,
                    view._proto._dataOrdering
                ])([data]);

                var dataCards = isForActivity ? view._instance.activityDataCards : view._instance.dataCards;
                view._proto._setViewData(dataCards, checkedData, true);

                var isDataEmpty = checkedData.length === 0;

                if (isForActivity) {
                    if (isDataEmpty) {
                        var text = view._instance.noActivitiesDataText.context.element.querySelector(".noActivitiesCardText");
                        text.innerText = bpmext.localization.formatMsg("instanceUI", "noDataForActivity");
                    } else {
                        view._instance.noActivitiesData.setVisible(false, true);
                    }
                }

                dataCards.setVisible(!isDataEmpty, true);
            },

            _dataFieldsCheck: function _dataFieldsCheck (dataList) {
                return (dataList || []).reduce(function (checkedData, data) {
                    if (data.label && [null, undefined, ""].indexOf(data.value) < 0) {
                        checkedData.push(data);
                    }
                    return checkedData;
                }, []);
            },

            _dataOrdering: function _dataOrdering (dataList) {
                return (dataList || []).sort(function (dataObj1, dataObj2) {
                    if (dataObj1.label === dataObj2.label) {
                        return 0;
                    }

                    return dataObj1.label > dataObj2.label ? 1 : -1;
                }, []);
            },

            _loadDataCard: function _loadDataCard(view, target, data) {
                target.setVisible(false, true);
                target.setLabel(data.label);

                var value = data.value, date;
                if(data.type === "DatePicker"  || data.type === "Date" || (data.widgetType && data.widgetType === "DatePicker")){
                    date = new Date(data.value) || new Date();
                    value = taskUtils.formatDate(date, false);
                }
                else if (data.type === "DateTimePicker" || data.type === "Time" || (data.widgetType && data.widgetType.indexOf("Date") > -1)) {
                    date = new Date(data.value) || new Date();
                    value = taskUtils.formatDate(date, true);
                }
                target.setData(value);
                target.setVisible(true, true);
            },
            /********** setting data - end **********/


            /********** setting comments - start **********/
            // entry point
            _settingComments: function _settingComments(view, comments, isForActivity) {
                view._instance.commentSection.setVisible(true, false);

                //if this is not specifically for an activity, then retrieve and merge all the activity comments with the instance comments
                var activityComments = [];
                if (!isForActivity) {
                    var activities = view._instance.activityCards._instance.activityCards.context.binding.get("value").items;
                    activities.forEach(function (activity) {
                        activityComments = activityComments.concat(view._proto._getCommentsFromActivity(activity));
                    });

                    //Display the Add Comments button if allowed
                    view._instance.addCommentsLink.setVisible(view._instance.processedData.canPostComments, true);
                }


                var checkedComments = view._proto._commentFieldsCheck(comments.concat(activityComments));
                if (!isForActivity) {
                    //sort for stream, reverse chronological order
                    checkedComments = checkedComments.sort(function(a,b) {
                        return (a.timestamp < b.timestamp) ? 1 : (a.timestamp === b.timestamp) ? 0 : -1;
                    });
                }

                var commentCards = isForActivity ? view._instance.activityCommentCards : view._instance.commentCards;

                view._proto._setViewData(commentCards, checkedComments, true);

                var isCommentsEmpty = checkedComments.length === 0;
                view._instance.noCommentsFound.setVisible(isCommentsEmpty, true);

                if (isForActivity) {
                    if (isCommentsEmpty) {
                        var text = view._instance.noActivitiesCommentsText.context.element.querySelector(".noActivitiesCardText");
                        text.innerText = bpmext.localization.formatMsg("instanceUI", "noCommentsForActivity");
                    } else {
                        view._instance.noActivitiesComments.setVisible(false, true);
                    }
                }
                commentCards.setVisible(!isCommentsEmpty, true);
            },

            _commentFieldsCheck: function (comments) {
                return (comments || []).reduce(function (checkedComments, comment) {
                    if (comment.completedBy && comment.comments && comment.timestamp) {
                        checkedComments.push(comment);
                    } else if (comment.who && comment.message && comment.date) {
                        checkedComments.push({completedBy: comment.who, comments: comment.message, timestamp: comment.date});
                    }
                    return checkedComments;
                }, []);
            },

            _loadCommentCard: function _loadCommentCard (view, target, comment, isForActivity) {
                target.setVisible(false, true);
                var prefix = isForActivity ? "Activity_" : "";
                var commentTitle = target.context.getSubview(prefix + "Comment_Card_Title", target)[0];
                var commentDate = target.context.getSubview(prefix + "Comment_Date", target)[0];
                var headerNode;
                if (commentTitle) {
                    var commentTitleMain = commentTitle.context.getSubview(prefix + "Comment_Title_Main", commentTitle)[0];
                    if (commentTitleMain) {
                        var commenter = commentTitleMain.context.getSubview(prefix + "Commenter", commentTitleMain)[0];
                        var altText = bpmext.localization.formatMsg("instanceUI", "profileImage");
                        headerNode = '<span><span><img class="commentAvatar" src="'
                                        +  view._instance.profileImageURL
                                        + '" alt="'+ altText +'"></img></span><span class="commenter">' + comment.completedBy + "</span>";
                        commenter.setLabelVisible(false, true);
                        commenter.setData(headerNode);

                        //Create the commenter tooltip
                        var commenterNode = commenter.context.element.querySelector(".commenter");
                        commenterNode.onmouseenter = function(target) {
                            if (!target.target.tooltipCreated) {
                                target.target.tooltipCreated = true;
                                wpResources.user.get({username: comment.completedBy, noCache: true, includeEditableUserPreferences: false, parts: wpResources.user.PARTS.NONE}).then(function(user) {
                                    commenterNode.tabIndex = -1;
                                    bpmext.ui.util.showTooltip(
                                        commenterNode,
                                        user.userName + "<br/>" + user.fullName + (user.emailAddress ?  "<br/>" + user.emailAddress : ""),
                                        {horizontalPos: "LEFT", smartPositioning: true, openDelay: 0.5}
                                    );
                                    commenterNode.focus();
                                });
                            }
                        };

                        commenterNode.onmouseleave = function() {
                            commenterNode.blur();
                        };

                        var commentTaskName = commentTitleMain.context.getSubview(prefix + "Comment_Task_Name", commentTitleMain)[0];
                        commentTaskName.setLabelVisible(false, true);
                        var taskName = comment.taskName ? "(" + comment.taskName + ")" :"";
                        commentTaskName.setData(taskName);
                        commentTaskName.setVisible(!!taskName, true);
                    }

                }

                var commentBody = target.context.getSubview(prefix + "Comment_Card_Body", target)[0];
                if (commentBody) {
                    var commentContent = commentBody.context.getSubview(prefix + "Comment_Content", commentBody)[0];
                    commentContent.setLabelVisible(false, true);
                    commentContent.setData(comment.comments);
                }
                if (commentDate) {
                    commentDate.setLabelVisible(false, true);
                    commentDate.setData(taskUtils.formatDate(new Date(comment.timestamp), true));
                }

                target.setVisible(true, true);
            },
            /********** setting comments - end **********/


            /********** setting startable ad-hoc activities - start **********/
            _settingStartableAdhocActivities: function _settingStartableAdhocActivities(view, activities) {
                view._proto._setViewData(view._instance.startableActivityCards, activities, true);
                view._instance.startableActivityPanelLayout.setVisible(true);
            },

            _loadStartableActivityCard: function _loadStartableActivityCard (view, target, activity) {
                target.setVisible(false, true);
                var activityName = target.context.getSubview("Activity_Startable_Name", target)[0];
                var startIcon = target.context.getSubview("Activity_Startable_Icon", target)[0];
                bpmext.ui.util.showTooltip(
                    startIcon.context.element,
                    bpmext.localization.formatMsg("instanceUI", "activityStart"),
                    {horizontalPos: "LEFT", smartPositioning: true}
                );


                activityName.setLabelVisible(false, true);
                activityName.setData(activity.name);



                target.setVisible(true, true);
            },
            /********** setting startable ad-hoc activities - end **********/

            /********** setting activities - start **********/
            // entry point
            _settingActivities: function _settingActivities(view, activities) {
                var composeActivitySubTasks = function (activities) {
                    return view._proto._composeActivitySubTasks(view, activities);
                };

                var filterActivities = function (activities) {
                    return view._proto._filterActivities(view, activities);
                };

                var activitiesList = taskUtils.compose([
                    view._proto._getActivityList,
                    filterActivities,
                    composeActivitySubTasks
                ])([activities]);

                view._instance.activityCards.setActivities(activitiesList);

                var isActivityEmpty = activitiesList.length === 0;
                var isWorkstream = view._instance.processedData.isWorkstream;
                view._instance.activityCards.setVisible(!isActivityEmpty,true);
                view._instance.activityCommentSection.setVisible(!isActivityEmpty && isWorkstream,true);
                view._instance.activityDocumentSection.setVisible(!isActivityEmpty && isWorkstream,true);
                view._instance.activityDataSection.setVisible(!isActivityEmpty && isWorkstream,true);
                //view._instance.activitySelector.setVisible(!isActivityEmpty,true);
                view._instance.noActivitiesPanel.setVisible(isActivityEmpty,true);
                view._instance.tabContainer.setPaneVisible(!isActivityEmpty, [2]);
            },

            _getActivityList: function (activities) {
                var ret = dojo.clone(Object.values(activities) || []);

                // sort by latest task due time (descending)
                return ret.sort(function (activity1, activity2) {
                    var a1Due = new Date(activity1.dueTime) || new Date();
                    var a2Due = new Date(activity2.dueTime) || new Date();
                    return a1Due < a2Due ? 1 : -1;
                });
            },

            _filterActivities: function _filterActivities (view, activities) {
                var activitySelector = view._instance.activitySelector;
                var selectedItem = activitySelector.getSelectedItem();

                switch (selectedItem) {
                    case view._proto.OPT_INPROGRESS_ACT:
                        return activities.filter(function (activity) {
                            return (activity.status === view._proto.OPT_INPROGRESS_ACT ||
                                    activity.executionState === wpResources.adhocActivity.CONSTANTS.STATE_WORKING);
                        });
                    case view._proto.OPT_COMPLETED_ACT:
                        return activities.filter(function (activity) {
                            return (activity.status === view._proto.OPT_COMPLETED_ACT  || activity.status === view._proto.OPT_APPROVED_ACT || activity.status === view._proto.OPT_REJECTED_ACT ||
                                    activity.executionState === wpResources.adhocActivity.CONSTANTS.STATE_COMPLETED);
                        });
                    case view._proto.OPT_APPROVED_ACT:
                        return activities.filter(function (activity) {
                            return activity.status === view._proto.OPT_APPROVED_ACT;
                        });
                    case view._proto.OPT_REJECTED_ACT:
                        return activities.filter(function (activity) {
                            return activity.status === view._proto.OPT_REJECTED_ACT;
                        });
                    default:
                        return activities;
                }
            },

            _composeActivitySubTasks: function (view, activities) {
                var processedData = view._instance.processedData;

                var taskDict = processedData && processedData.tasks;
                if (!taskDict) {
                    return [];
                }

                return (activities || []).map(function (activity) {
                    activity.subTasks = taskDict.fetchTaskByIDs(activity.subTasks);
                    return activity;
                });
            },
            /********** setting activities - end **********/

            /********** setting ad-hoc activities tasks - start **********/
            _settingAdhocActivities: function (view, activities, systemID) {
                //for each activity, get the details of the activity
                view._instance.processedData.workingAdhocActivities = [];
                view._instance.processedData.nonWorkingAdhocActivities = [];
                view._instance.processedData.startableAdhocActivities = [];
                view._instance.processedData.nonStartableAdhocActivities = [];

                var processAdhocActivity = function(activity) {

                    var workingActivity = {
                        activityName: activity.name,
                        activityId: activity.id,
                        subTasks: activity.taskId ? ([activity.taskId.substring(activity.taskId.indexOf(".")+1)]) : [],
                        dueTime: activity.dueDate,
                        activityType: (activity.optionType === wpResources.adhocActivity.CONSTANTS.OPTION_TYPE_REQUIRED) ? "activityRequired" : "",
                        startTime: activity.startTime,
                        endTime: activity.endTime,
                        executionState: activity.executionState
                    };

                    view._instance.processedData.workingAdhocActivities.push(workingActivity);

                    view._instance.processedData.activities = view._instance.processedData.activities || {};
                    view._instance.processedData.activities[workingActivity.activityId] = workingActivity;

                    if(activities.length === (view._instance.processedData.workingAdhocActivities.length + view._instance.processedData.nonWorkingAdhocActivities.length) ) {
                        //set the merged list of activities
                        view._proto._settingActivities(view, view._instance.processedData.activities);
                        view._proto._composeDanglingTasks(view, null, view._instance.processedData);
                        view._proto._settingDanglingTasks(view, view._instance.processedData.danglingTasks);
                    }
                };

                var processStartableAdhocActivity = function(actions, activity) {
                    if (actions && actions.actions && actions.actions.indexOf(wpResources.adhocActivity.ACTIONS.ACTION_START_ACTIVITY) !== -1) {
                        view._instance.processedData.startableAdhocActivities.push(activity);
                    }

                    if(activities.length ===
                        (view._instance.processedData.startableAdhocActivities.length + view._instance.processedData.nonStartableAdhocActivities.length ) ) {
                            if (view._instance.processedData.startableAdhocActivities.length !== 0) {
                                view._proto._settingStartableAdhocActivities(view, view._instance.processedData.startableAdhocActivities);
                            }
                    }
                };

                var workingActivities = [];
                var startableActivities = [];
                var otherActivities = [];
                activities.forEach(function(activity) {
                    activity.systemID = systemID;
                    if(activity.hidden === true) {
                        otherActivities.push(activity);
                    } else if (activity.executionState === wpResources.adhocActivity.CONSTANTS.STATE_READY) {
                        startableActivities.push(activity);
                    } else if (activity.executionState === wpResources.adhocActivity.CONSTANTS.STATE_WORKING || activity.executionState === wpResources.adhocActivity.CONSTANTS.STATE_COMPLETED) {
                        workingActivities.push(activity);
                    } else {
                        otherActivities.push(activity);
                    }
                });

                view._instance.processedData.nonWorkingAdhocActivities = startableActivities.concat(otherActivities);
                view._instance.processedData.nonStartableAdhocActivities = workingActivities.concat(otherActivities);

                workingActivities.forEach(function(activity) {
                    wpResources.adhocActivity.get({activityId: activity.id, systemID: systemID}).then(processAdhocActivity);
                });

                startableActivities.forEach(function(activity) {
                    wpResources.adhocActivity.getActions({activityId: activity.id, systemID: systemID})
                        .then(function(actions) {
                            return processStartableAdhocActivity(actions, activity);
                        });
                });

                if(startableActivities.concat(workingActivities).length > 0){
                    view._instance.tabContainer.setPaneVisible(true, [2]);
                }
            },
            /********** setting ad-hoc activities - end **********/

            /********** setting dangling tasks - start **********/
            // entry point
            _settingDanglingTasks: function _settingDanglingTasks(view, tasks) {
                var processedData = view._instance.processedData;
                if (!processedData || !processedData.tasks){
                    return;
                }

                var taskDict = processedData.tasks;
                var danglingTasks = taskDict.fetchTaskByIDs(tasks);

				//populate the tasks table
				if(view._instance.taskListView) {
					//Need to mock up the attributes so that the task list can process the table
					var attributes = [
                        {"name":"dueTime","type":"TIMESTAMP","content":"TASK.DUE","isArray":false,"sourceAttribute":".taskDueDate","sourceQueryTableIdentifier":"n/a"},
                        {"name":"displayName","type":"STRING","content":"TASK_DESC.DISPLAY_NAME","isArray":false,"sourceAttribute":".taskSubject","sourceQueryTableIdentifier":"n/a"},
                        {"name":"status","type":"STRING","content":"TASK.STATUS","isArray":false,"sourceAttribute":".taskStatus","sourceQueryTableIdentifier":"n/a"},
                        {"name":"priority","type":"NUMBER","content":"TASK.PRIORITY","isArray":false,"sourceAttribute":".taskPriority","sourceQueryTableIdentifier":"n/a"},
                        {"name":"assignedToDisplayName","type":"STRING","content":"TASK.OWNER","isArray":false,"sourceAttribute":".assignedToUser","sourceQueryTableIdentifier":"n/a"}
                    ];
                    if (danglingTasks.length === 0){
                        view._instance.tabContainer.setPaneVisible(false, [1]);
                    }else{
                        view._instance.taskListView.setTasks({attributeInfo: attributes, items: danglingTasks, isWorkstream: processedData.isWorkstream});
                    }
                }
            },
            /********** setting dangling tasks - end **********/


            /********** setting instance actions - start **********/
            _configControlActions: function _configControlActions(view) {
                var instance = view.getInstance();
            	var userActions = (instance && instance.actions) || [];
            	this._isSocialDisabled("following").then(function(disabled) {
            		if(!disabled) {
            			wpResources.social.isFollowingInstance({piid: instance.piid, systemID: instance.systemID}).then(function(res) {
                            if(res && res.followed){
                            	userActions.push("ACTION_UNFOLLOW_INSTANCE");
                            } else {
                            	userActions.push("ACTION_FOLLOW_INSTANCE");
                            }
                            taskUtils.EVENTS.CONFIG_INSTANCE_CONTROL.publish({ident: {
                                workstreamName: instance.name,
                                piid: instance.piid,
                                systemID: instance.systemID
                            }, actions: userActions});
                        });
            		} else {
            			  taskUtils.EVENTS.CONFIG_INSTANCE_CONTROL.publish({ident: {
                              workstreamName: instance.name,
                              piid: instance.piid,
                              systemID: instance.systemID
                          }, actions: userActions});
            		}
            	});
            },

            _isSocialDisabled: function(feature) {
            	return wpResources.config.get().then(function(mashupsConfig) {
            		if(mashupsConfig.disableSocial && mashupsConfig.disableSocial.indexOf("all") !== -1) {
            			return true;
            		}
            		return mashupsConfig && mashupsConfig.disableSocial && (mashupsConfig.disableSocial.indexOf(feature) !== -1);
            	});
            },
            /********** setting instance actions - end **********/


            /********** setting history - start **********/
            _settingHistory: function _settingHistory(view, items) {
                var history = view._instance.processedData.history = [];

                if (items) {
                    items.forEach(function(item) {
                        if (item.object && item.object.objectType === "ibm.bpm.comment") {
                            item.content = bpmext.localization.formatMsg("instanceUI", "userComment", "<span class='proper-noun'>" + item.content + "</span>");
                        }
                        history.push({
                            user: (item && item.actor) ? item.actor.displayName : "",
                            details: item ? item.content : "",
                            date: item ? item.published : ""
                        });
                    });
                }

                if (history.length !== 0) {
                    view._instance.historyTable.setViewData(history, true);
                    view._instance.historyPanel.setVisible(true, true);
                    view._instance.noHistoryToDisplayView.setVisible(false, true);
                } else {
                    view._instance.historyPanel.setVisible(false, true);
                    view._instance.noHistoryToDisplayView.setVisible(true, true);
                }

            },
            /********** setting history - end **********/
            /******************** Mapping data to UI - end ********************/



            /******************** Reset UI - start ********************/
            /********** reset controls - start **********/
            _resetViews: function _resetViews(view) {
            	taskUtils.composeMap([
                    view._proto._resetInfoSection,
                    view._proto._resetOverviewSection,
                    view._proto._resetDocumentSection,
                    view._proto._resetDataSection,
                    view._proto._resetCommentSection,
                    view._proto._resetActivitySection,
                    view._proto._resetHistorySection
                ])([view]);

            },
            /********** reset controls - end **********/


            /********** reset info - start **********/
            _resetInfoSection: function _resetInfoSection (view) {
                !!view._instance.instanceStatusIcon && view._instance.instanceStatusIcon.setData("<span class=\"instanceStatusIcon\"></span>");
                !!view._instance.instanceActionMenuButton && view._instance.instanceActionMenuButton.setVisible(false, true);

                if (view._instance.instanceStatus) {
                    view._instance.instanceStatus.setVisible(true, false);
                    view._instance.instanceStatus.setData("");
                }
            },
            /********** reset info - end **********/


            /********** reset overview - start **********/
             _resetOverviewSection: function _resetOverviewSection (view) {
                !!view._instance.overviewContent && view._instance.overviewContent.setData("");
                //hide description
                !!view._instance.overviewContent && view._instance.overviewContent.setVisible(false, true);

            	!!view._instance.dueDate && view._instance.dueDate.setData("");
            	!!view._instance.dueDate && view._instance.overviewDue.setData("");
            	!!view._instance.processName && view._instance.processName.setData("");
                !!view._instance.progressBar && domStyle.set(view._instance.progressBar, "width", "0%");
            },
            /********** reset overview - end **********/


            /********** reset document - start **********/
            _resetDocumentSection: function _resetDocumentSection (view, isForActivityOnly) {
                if(!isForActivityOnly) {
                    if (view._instance.documentsTable) {
                        view._proto._setViewData(view._instance.documentsTable, [], true);
                        view._instance.noDocumentsToDisplayView.setVisible(false, true);
                        view._instance.documentsPanel.setVisible(true, true);
                    }
                } else {
                    var text = view._instance.noActivitiesDocumentsText.context.element.querySelector(".noActivitiesCardText");
                    text.innerText = bpmext.localization.formatMsg("instanceUI", "selectActivity");
                    view._instance.noActivitiesDocuments.setVisible(true, true);
                }

                if (view._instance.activityDocumentsCards) {
                    view._instance.activityDocumentsCards.setVisible(false, true);
                    view._proto._setViewData(view._instance.activityDocumentsCards, [], true);
                }
            },
            /********** reset document - end **********/


            /********** reset data - start **********/
             _resetDataSection: function _resetDataSection (view, isForActivityOnly) {
                 if(!isForActivityOnly) {
                    if (view._instance.dataCards) {
                        view._instance.dataCards.setVisible(false, true);
                        view._proto._setViewData(view._instance.dataCards, [], true);
                    }
                    if (view._instance.systemDataCards) {
                        view._instance.systemDataCards.setVisible(false, true);
                        view._proto._setViewData(view._instance.systemDataCards, [], true);
                    }
                } else {
                    var text = view._instance.noActivitiesDataText.context.element.querySelector(".noActivitiesCardText");
                    text.innerText = bpmext.localization.formatMsg("instanceUI", "selectActivity");
                    view._instance.noActivitiesData.setVisible(true, true);
                }

                if (view._instance.activityDataCards) {
                    view._instance.activityDataCards.setVisible(false, true);
                    view._proto._setViewData(view._instance.activityDataCards, [], true);
                }
            },
            /********** reset data - end **********/


            /********** reset comment - start **********/
            _resetCommentSection: function _resetCommentSection (view, isForActivityOnly) {
                if(!isForActivityOnly) {
                    !!view._instance.noCommentsFound && view._instance.noCommentsFound.setVisible(true, true);
                    if (view._instance.commentCards) {
                        view._instance.commentCards.setVisible(false, true);
                        view._instance.commentSection.setVisible(false, true);
                        view._proto._setViewData(view._instance.commentCards, [], true);
                    }
                } else {
                    var text = view._instance.noActivitiesCommentsText.context.element.querySelector(".noActivitiesCardText");
                    text.innerText = bpmext.localization.formatMsg("instanceUI", "selectActivity");
                    view._instance.noActivitiesComments.setVisible(true, true);
                }
                if (view._instance.activityCommentCards) {
                    view._instance.activityCommentCards.setVisible(false, true);
                    view._proto._setViewData(view._instance.activityCommentCards, [], true);
                }
            },
            /********** reset comment - end **********/


            /********** reset activities - start **********/
            _resetActivitySection: function _resetActivitySection (view) {
                if (view._instance.activityPanelLayout) {
                    view._instance.activityCards.setVisible(false, true);
                    view._instance.activityCards.setActivities([]);
                    view._instance.noActivitiesPanel.setVisible(true, true);
                    view._instance.startableActivityPanelLayout.setVisible(false, true);
                }
            },
            /********** reset activities - end **********/

            /********** reset history - start **********/
            _resetHistorySection: function _resetHistorySection (view) {
                view._instance.noActivitiesDocuments.setVisible(true, true);
            },
            /********** reset history - end **********/
            /******************** Reset UI - end ********************/



            /******************** Others - start ********************/
            _setViewData: function _setViewData(view, data, createPseudoBinding){
                var ctx = view.context;

                if (!data || data.length < 1) {
                    view.setVisible(false, true);
                } else {
                    view.setVisible(true, true);
                }

                if(ctx){
                    if(ctx.binding){
                        ctx.binding.set("value", data);
                    } else if (createPseudoBinding === true) {
                        ctx.binding = bpmext.ui.substituteObject(view);
                        ctx.binding.set("value", data);
                    }
                }
            },

            _getTargetViewBindingData: function (target) {
                if (target) {
                    var parentView = target.context._parentView;
                    var curIndex = target.ui.getIndex();
                    if (parentView) {
                        var bindingVal = parentView.context.binding.get("value");
                        return bindingVal && bindingVal.items && bindingVal.items[curIndex];
                    }
                }
            },

            _localizingLabels: function _localizingLabels (view) {
                // General
                view._instance.noDetailFound = bpmext.localization.formatMsg("instanceUI", "noDetailFound");
                view._instance.noTasksAvailable = bpmext.localization.formatMsg("instanceUI", "noTasksAvailable");
                view._instance.noActivitiesAvailable = bpmext.localization.formatMsg("instanceUI", "noActivitiesAvailable");

                //Tabs
                view._instance.tabContainer.setTabText(bpmext.localization.formatMsg("instanceUI", "overview"),view._proto.TABS.OVERVIEW);
                view._instance.tabContainer.setTabText(bpmext.localization.formatMsg("instanceUI", "tasksTitle"),view._proto.TABS.TASKS);
                view._instance.tabContainer.setTabText(bpmext.localization.formatMsg("instanceUI", "activityPanel"),view._proto.TABS.ACTIVITIES);
                view._instance.tabContainer.setTabText(bpmext.localization.formatMsg("instanceUI", "documents"),view._proto.TABS.DOCUMENTS);
                view._instance.tabContainer.setTabText(bpmext.localization.formatMsg("instanceUI", "history"),view._proto.TABS.HISTORY);

                // Overview
                view._instance.modifiedDate.setLabel(bpmext.localization.formatMsg("instanceUI", "dateModified"));
                view._instance.completionDate.setLabel(bpmext.localization.formatMsg("instanceUI", "completionDate"));
                view._instance.dueDate.setLabel(bpmext.localization.formatMsg("instanceUI", "dueDate"));
                view._instance.overviewDue.setLabel(bpmext.localization.formatMsg("instanceUI", "dueDate"));
                view._instance.processName.setLabel(bpmext.localization.formatMsg("instanceUI", "processName"));
                view._instance.instanceStatus.setLabel(bpmext.localization.formatMsg("instanceUI", "status"));

                // Comments
				if (view._instance.noCommentsFoundText) {
                    var url = view._instance.emptyCubeImageURL;
                    var altText = bpmext.localization.formatMsg("instanceUI", "emptyCube");
                    var noCommentsTemplate = '<div class="instanceNoComments"><img src="' + url + '" alt="' + altText + '"></img><span class="instanceNoCommentsText">' + bpmext.localization.formatMsg("instanceUI", "noComments") + "</span></div>";
					view._instance.noCommentsFoundText.setData(noCommentsTemplate);
                }

                if(view._instance.postCommentButton) {
                    view._instance.postCommentButton.setText(bpmext.localization.formatMsg("instanceUI", "postComment"));
                }

                if(view._instance.cancelCommentButton) {
                    view._instance.cancelCommentButton.setText(bpmext.localization.formatMsg("instanceUI", "cancelComment"));
                }

                view._instance.taskListView.setEmptyTableTexts({
                    header: bpmext.localization.formatMsg("instanceUI", "noTasksAvailable"),
                    subHeader: bpmext.localization.formatMsg("instanceUI", "noTasksAvailableSubheader")
                });

                //tasks
                var taskListCols = [
                    {name:"taskStatus", value: taskUtils.getLabelFromTaskProperty("taskStatus")},
                    {name:"taskPriority", value: taskUtils.getLabelFromTaskProperty("taskPriority")},
                    {name:"taskSubject", value: taskUtils.getLabelFromTaskProperty("taskSubject")},
                    {name:"taskDueDate", value: taskUtils.getLabelFromTaskProperty("taskDueDate")},
                    {name:"assignedToUser", value: taskUtils.getLabelFromTaskProperty("assignedToUser")}
                ];
                view._instance.taskListView.setSelectedColumns(taskListCols);

            },

            _initImages: function _initImages(view) {
                view._instance.emptyCubeImageURL = com_ibm_bpm_coach.getManagedAssetUrl("emptyCube.png", com_ibm_bpm_coach.assetType_WEB,"SYSWPT");
                view._instance.profileImageURL =  com_ibm_bpm_coach.getManagedAssetUrl("profile.png", com_ibm_bpm_coach.assetType_WEB,"SYSWPT");
            },

            _initFilter: function _initFilter (view) {
                var instanceActivityFilter = view._instance.activitySelector;
                instanceActivityFilter.clearItems();

                instanceActivityFilter.appendItem(view._proto.OPT_ALL_ACT, bpmext.localization.formatMsg("instanceUI", view._proto.OPT_ALL_ACT));
                instanceActivityFilter.appendItem(view._proto.OPT_INPROGRESS_ACT, bpmext.localization.formatMsg("instanceUI", view._proto.OPT_INPROGRESS_ACT));
                instanceActivityFilter.appendItem(view._proto.OPT_COMPLETED_ACT, bpmext.localization.formatMsg("instanceUI", view._proto.OPT_COMPLETED_ACT));
                instanceActivityFilter.appendItem(view._proto.OPT_APPROVED_ACT, bpmext.localization.formatMsg("instanceUI", view._proto.OPT_APPROVED_ACT));
                instanceActivityFilter.appendItem(view._proto.OPT_REJECTED_ACT, bpmext.localization.formatMsg("instanceUI", view._proto.OPT_REJECTED_ACT));

                instanceActivityFilter.setSelectedItemAt(0);
            },

            _initDocumentsPanel: function _initDocumentsPanel(view) {
                var documentsCols = [
                    {
                        visibility: true,
                        sortable: true,
                        renderAs: "H",
                        dataElementName: "name",
                        label: bpmext.localization.formatMsg("instanceUI", "fileName"),
                        name: "name",
                        type: taskUtils.COLUMN_TYPES.LINK,
                        options: "\"onclick\":\"theView=bpmext.ui.getView('" + view.ui.getAbsoluteName() + "');theView._proto._launchDocument(theView,value.data)\""

                    },                {
                        visibility: true,
                        sortable: true,
                        renderAs: "H",
                        dataElementName: "version",
                        label: bpmext.localization.formatMsg("instanceUI", "version"),
                        name: "version",
                        type: taskUtils.COLUMN_TYPES.STRING
                    },
                    {
                        visibility: true,
                        sortable: true,
                        renderAs: "H",
                        dataElementName: "date",
                        label: bpmext.localization.formatMsg("instanceUI", "uploadedDate"),
                        name: "date",
                        type: taskUtils.COLUMN_TYPES.TIMESTAMP,
                        options: {dateOptions: {selector: "date", formatLength: "medium"}}

                    },
                    {
                        visibility: true,
                        sortable: true,
                        renderAs: "H",
                        dataElementName: "creator",
                        label: bpmext.localization.formatMsg("instanceUI", "uploadedBy"),
                        name: "creator",
                        type: taskUtils.COLUMN_TYPES.STRING
                    }
                ];
                view._instance.documentsTable.setColumns(documentsCols);
                view._instance.noDocumentsToDisplayView.setVisible(false, true);
                view._instance.documentsPanel.setVisible(true, true);

                //add dummy row to empty doc state table
                view._instance.noDocumentsToDisplayView.setViewData([{name: 0}], true);
                view._instance.noDocsImage = bpmext.ui.getView("NoDocsImage", view._instance.noDocumentsToDisplayView);
                var image = view._instance.noDocsImage.context.element.querySelector("img");
                image.tabIndex = -1;
                var headerId = bpmext.ui.getView("NoDocsHeader", view._instance.noDocumentsToDisplayView).context.element.id;
                image.setAttribute("aria-labelledby", headerId);

            },

            _initActivitiesPanel: function _initActivitiesPanel(view) {
                view._instance.noActivitiesPanel.setVisible(false, true);
                //add dummy row to empty activities table
                view._instance.noActivitiesTable.setViewData([{name: 0}], true);
                view._instance.noActivitiesImage = bpmext.ui.getView("NoActivitiesImage", view._instance.noActivitiesTable);
                var image = view._instance.noActivitiesImage.context.element.querySelector("img");
                image.tabIndex = -1;
                var headerId = bpmext.ui.getView("NoActivitiesHeader", view._instance.noActivitiesTable).context.element.id;
                image.setAttribute("aria-labelledby", headerId);

                //activities detail boxes
                var noActivitySelectedText = bpmext.localization.formatMsg("instanceUI", "selectActivity");
                var altText = bpmext.localization.formatMsg("instanceUI", "emptyCube");
                var noActivitiesTemplate = '<span class="noActivitiesCardLayout"><span><img class="noActivitiesCardImage" src="'
                                                + view._instance.emptyCubeImageURL
                                                + '"  alt="' + altText + '"></span><span class="noActivitiesCardText">' + noActivitySelectedText + "</span></span>";
                view._instance.noActivitiesCommentsText.setData(noActivitiesTemplate);
                view._instance.noActivitiesDataText.setData(noActivitiesTemplate);
                view._instance.noActivitiesDocumentsText.setData(noActivitiesTemplate);
            },

            _initCommentsSection: function _initCommentsSection(view) {
                //inject the add comment icon into the link
                var icon = utilities.getCarbonIcon("ci-add-comment");
                var anchor = view._instance.addCommentsLink.context.element.querySelector("a");
                anchor.innerHTML = "<span><span>" + bpmext.localization.formatMsg("instanceUI", "addComment") + "</span><span class=\"btn-label icon ci\">" + icon.outerHTML + "</span></span>";
            },

            _initHistoryPanel: function _initHistoryPanel(view) {
                var historyCols = [
                    {
                        visibility: true,
                        sortable: true,
                        renderAs: "H",
                        dataElementName: "details",
                        label: bpmext.localization.formatMsg("instanceUI", "details"),
                        name: "details",
                        type: taskUtils.COLUMN_TYPES.STRING
                    },
                    {
                        visibility: true,
                        sortable: true,
                        renderAs: "H",
                        dataElementName: "user",
                        label: bpmext.localization.formatMsg("instanceUI", "user"),
                        name: "user",
                        type: taskUtils.COLUMN_TYPES.STRING
                    },
                    {
                        visibility: true,
                        sortable: true,
                        renderAs: "H",
                        dataElementName: "date",
                        label: bpmext.localization.formatMsg("instanceUI", "dateModified"),
                        name: "date",
                        type: taskUtils.COLUMN_TYPES.TIMESTAMP,
                        options: {dateOptions: {selector: "datetime", formatLength: "medium"}}
                    }
                ];
                view._instance.historyTable.setColumns(historyCols);
                view._instance.noHistoryToDisplayView.setVisible(false, true);
                view._instance.historyPanel.setVisible(true, true);

                //add dummy row to empty history state table
                view._instance.noHistoryToDisplayView.setViewData([{name: 0}], true);
                view._instance.noHistoryImage = bpmext.ui.getView("NoHistoryImage", view._instance.noHistoryToDisplayView);
                var image = view._instance.noHistoryImage.context.element.querySelector("img");
                image.tabIndex = -1;
                var headerId = bpmext.ui.getView("NoHistoryHeader", view._instance.noHistoryToDisplayView).context.element.id;
                image.setAttribute("aria-labelledby", headerId);

            },

            _accessibilities: function  _accessibilities(view) {
                if (view._instance.reloadBtn) {
                    var reloadBtn = view._instance.reloadBtn.context.element.querySelector("div[role=button]");
                    !!reloadBtn && reloadBtn.setAttribute("title", bpmext.localization.formatMsg("instanceUI", "reload"));
                    !!reloadBtn && reloadBtn.setAttribute("aria-label", bpmext.localization.formatMsg("instanceUI", "reload"));
                }

                if (view._instance.instanceActionMenuButton) {
                    var instanceActionsBtn = view._instance.instanceActionMenuButton.context.element.querySelector("div[role=button]");
                    !!instanceActionsBtn && instanceActionsBtn.setAttribute("aria-haspopup", "true");
                    !!instanceActionsBtn && instanceActionsBtn.setAttribute("title", bpmext.localization.formatMsg("instanceUI", "instanceActions"));
                    !!instanceActionsBtn && instanceActionsBtn.setAttribute("aria-label", bpmext.localization.formatMsg("instanceUI", "instanceActions"));
                }

                if (view._instance.activitySelector) {
                    var instanceActivityFilter = view._instance.activitySelector.context.element.querySelector(".input > select");
                    instanceActivityFilter.setAttribute("title", bpmext.localization.formatMsg("instanceUI", "activityStateFilter"));
                    view._instance.activitySelector.setLabel(bpmext.localization.formatMsg("instanceUI", "activityStateFilter"));
                }
            },

            _launchModifyInstance: function _launchModifyInstance(view, data) {
                bpmext.log.info("InstanceUI._launchModifyInstance LOG >> (data): " + data, view);
                view._instance.modifyInstanceModal.setupProcess(data);
                view._instance.modifyInstanceModal.showModal();
            },

            _launchTask: function _launchTask(view, data) {
                bpmext.log.info("InstanceUI._launchTask LOG >> (data): " + data, view);
                bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONTASK_LAUNCHED, data);
                var origin = view.ui.getParent().context? view.ui.getParent().context.viewid: null;
                taskUtils.EVENTS.INSTANCE_TASK_BEFORE_LAUNCH.publish({task: data, skipClaim: view.context.options.skipClaimForTasks.get("value"), origin: origin});
            },

	        _followInstance: function (view, instance){
                var piid = instance.piid;
                var systemID = instance.systemID;

                if (piid) {
                    wpResources.social.followInstance({piid: piid, systemID: systemID}).then(function() {
                        // refresh the action menu
                        taskUtils.EVENTS.UPDATE_FOLLOW_ACTION.publish();
                        // refresh following list
                        taskUtils.EVENTS.UPDATE_FOLLOWING.publish();
                    });
                }
            },

            _unfollowInstance: function(view, instance) {
                var piid = instance.piid;
                var systemID = instance.systemID;

                if (piid) {
                    wpResources.social.unfollowInstance({piid: piid, systemID: systemID}).then(function() {
                        // refresh the action menu
                        taskUtils.EVENTS.UPDATE_FOLLOW_ACTION.publish();
                        // refresh following list
                        taskUtils.EVENTS.UPDATE_FOLLOWING.publish();
                    });
                }
            },

            _generateHistoryCallbacks: function _generateHistoryCallbacks (view, displayName) {
                var viewerObj = view._instance.viewerObj;
                var data = {
                    piid: viewerObj.data.piid,
                    systemID: viewerObj.data.systemID
                };

                var onViewRestore = function () {
                    taskUtils.EVENTS.BEFORE_VIEW_INSTANCE.publish(view._instance.viewerObj.data);
                };

                var onViewClose = function() {
                    view.closeInstance();
                };

                return {
                    data: data,
                    identifier: "InstanceUI",
                    displayName: displayName || "Instance UI",
                    onViewRestore: onViewRestore,
                    onViewClose: onViewClose
                };
            },

            _getCommentsFromActivity: function _getCommentsFromActivity(activity) {
                var comments = activity.subTasks.reduce(function (comments, task) {
                    if (task._EXTRA_DATA) {
                        task._EXTRA_DATA.taskName = task.displayName;
                        comments.push(task._EXTRA_DATA);
                    }
                    return comments;
                }, []);
                return comments;
            },

            _setRefreshButtonTooltip: function _setRefreshButtonTooltip(view){
                var refreshButtonCtl = view._instance.reloadBtn.context.element.querySelector('.SPARKIcon[role="button"]');
                var currentTime, secondsSinceRefresh, minutesSinceRefresh, lastRefreshedText;

                refreshButtonCtl.onmouseenter = function (){
                        currentTime = new Date();
                        secondsSinceRefresh = Math.floor((currentTime - view._instance.lastRefreshed)/1000);
                        if (secondsSinceRefresh > 60){
                            minutesSinceRefresh = Math.floor(secondsSinceRefresh%60);
                            if(minutesSinceRefresh > 30){
                                lastRefreshedText = bpmext.localization.formatMsg("controlTaskList", "maxRefreshButtonTooltip");
                            }
                            else{
                                lastRefreshedText = bpmext.localization.formatMsg("controlTaskList", "minuteRefreshButtonTooltip", minutesSinceRefresh, secondsSinceRefresh);
                            }
                        }
                        else{
                            lastRefreshedText = bpmext.localization.formatMsg("controlTaskList", "secondRefreshButtonTooltip", secondsSinceRefresh);
                        }
    
                        view._instance.lastRefreshedTP = bpmext.ui.util.showTooltip(
                            refreshButtonCtl,
                            lastRefreshedText,
                            {horizontalPos: "LEFT", smartPositioning: true, alwaysShow: true}
                        );
                };

                refreshButtonCtl.onmouseleave = function() {
                    bpmext.ui.util.closeTooltip(view._instance.lastRefreshedTP, refreshButtonCtl);
                };
            }
            /******************** Others - end ********************/
        };

        /*
        Public control methods *************************************************************
        */

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method loadDocumentCard
         * @param {view} target The document card wrapper view
		 * @desc Loads a document card.
		 */
        this.constructor.prototype.loadDocumentCard = function(target) {
            bpmext.log.info("InstanceUI.loadDocumentCard ENTER >> event: ", event);

            var document = this._proto._getTargetViewBindingData(target),
                _this = this;
            if (document) {
                wpResources.systems.getFederationResults().then(function (systems) {
                    var endpoint = (systems[taskUtils.safeGet(_this, "_instance.viewerObj.data.systemID".split("."))] || {}).endpoint;
                    _this._proto._loadDocumentCard(_this, target, document, endpoint);
                });
            }

			bpmext.log.info("InstanceUI.loadDocumentCard EXIT << ");
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method loadDataCard
         * @param {view} target The data card wrapper view
		 * @desc Load a data card.
		 */
        this.constructor.prototype.loadDataCard = function(target) {
            bpmext.log.info("InstanceUI.loadDocumentCard ENTER >> event: ", event);

            var data = this._proto._getTargetViewBindingData(target);
            data && this._proto._loadDataCard(this, target, data);

			bpmext.log.info("InstanceUI.loadDataCard EXIT << ");
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method loadCommentCard
         * @param {view} target The comment card wrapper view
         * @param {boolean} isForActivity Returns true if it is a Workstream activity and not an instance-level activity
		 * @desc Load a comment card.
		 */
        this.constructor.prototype.loadCommentCard = function(target, isForActivity) {
            bpmext.log.info("InstanceUI.loadCommentCard ENTER >> event: ", event);

            var comment = this._proto._getTargetViewBindingData(target);
            comment && this._proto._loadCommentCard(this, target, comment, isForActivity);

			bpmext.log.info("InstanceUI.loadCommentCard EXIT << ");
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method loadActivityCommentCard
         * @param {view} target The comment card wrapper view
		 * @desc Loads a comment card for a specific activity.
		 */
        this.constructor.prototype.loadActivityCommentCard = function loadActivityCommentCard (target) {
            this.loadCommentCard (target, true);
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method loadActivityDetail
         * @param {view} view All the activity card views
         * @param {view} target A single activity card view
		 * @desc Loads the activity document, data, and comments into the side panel.
		 */
        this.constructor.prototype.loadActivityDetail = function(view, target) {
            bpmext.log.info("InstanceUI.loadActivityDetail ENTER >> event: ", event);

            var activity = this._proto._getTargetViewBindingData(target);
            if (activity) {
                var documents = activity.documents && activity.documents.items;
                var data = activity.data && activity.data.items;
                var comments = this._proto._getCommentsFromActivity(activity);

                this._proto._settingDocuments(this, documents || [], true);
                this._proto._settingData(this, data || [], true);
                this._proto._settingComments(this, comments, true);
                bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONINSTANCE_ACTIVITY_SELECTED, activity);
            }

			bpmext.log.info("InstanceUI.loadActivityDetail EXIT << ");
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method showDefaultActivityDetail
		 * @desc Load the default document, data, and comments into the side panel.
		 */
        this.constructor.prototype.showDefaultActivityDetail = function() {
            bpmext.log.info("InstanceUI.showDefaultActivityDetail ENTER >> event: ", event);

            var processedData = this._instance.processedData;

            if (processedData) {
                this._proto._settingDocuments(this, processedData.documents);
                this._proto._resetDocumentSection(this,true);
                this._proto._settingData(this, processedData.data);
                this._proto._resetDataSection(this, true);
                this._proto._settingComments(this, processedData.comments);
                this._proto._resetCommentSection(this, true);
            }

			bpmext.log.info("InstanceUI.showDefaultActivityDetail EXIT << ");
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method loadStartableActivityCard
         * @param {view} target The activity startable card wrapper view
		 * @desc Load a startable activity card.
		 */
        this.constructor.prototype.loadStartableActivityCard = function(target) {
            bpmext.log.info("InstanceUI.loadStartableActivityCard ENTER");

            var activity = this._proto._getTargetViewBindingData(target);
            activity && this._proto._loadStartableActivityCard(this, target, activity);

			bpmext.log.info("InstanceUI.loadStartableActivityCard EXIT << ");
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method startableAdhocActivity
         * @param {view} target The activity startable icon view
		 * @desc Start an adhoc activity.
		 */
        this.constructor.prototype.startAdhocActivity = function(target) {
            bpmext.log.info("InstanceUI.startAdhocActivity ENTER");

            var curIndex = target.ui.getParent(true).ui.getIndex();
            var activity = target.ui.getParent(true).ui.getParent(true).context.binding.get("value").items[curIndex];
            if(activity && activity.id && target.alreadyStarted !== true) {
                target.alreadyStarted = true;
                target.setIcon("ci-checkmark-filled");
                wpResources.adhocActivity.startActivity({activityId: activity.id, systemID: activity.systemID});
            }

			bpmext.log.info("InstanceUI.startAdhocActivity EXIT << ");
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method getInstance
         * @return {Object} The instance data
		 * @desc Get the instance data.
		 */
        this.constructor.prototype.getInstance = function() {
            return this.context.options.instance.get("value");
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method setInstance
         * @param {Object} instance The instance data
		 * @desc Set the instance data.
		 */
        this.constructor.prototype.setInstance = function(instance) {
            this.context.options.instance.set("value", instance);
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method closeInstance
		 * @desc Close the instance UI.
		 */
        this.constructor.prototype.closeInstance = function() {
            bpmext.log.info("InstanceUI.closeInstance ENTER");

            // clear dirty reload variables
            this._instance.dirtyData = false;
            this._instance.numberOfDirtyReloads = 0;
            !! this._instance.cleanDirtyDataTimeout && clearTimeout(this._instance.cleanDirtyDataTimeout);

            bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONINSTANCE_CLOSED);
            if (this.isVisible()){
                this.setVisible(false, true);
                taskUtils.EVENTS.AFTER_CLOSE_INSTANCE.publishSync();
            }

			bpmext.log.info("InstanceUI.closeInstance EXIT << ");
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method reloadInstance
         * @param {view} event The reload instance button view
		 * @desc Close the instance UI.
		 */
        this.constructor.prototype.reloadInstance = function(event) {
			bpmext.log.info("InstanceUI.reloadInstance ENTER >> event: ", event);

            this._instance.lastRefreshed = new Date();
            if (this.isVisible()) {
                var instance = this.getInstance();
                this._proto._fetchInstance(this, instance.piid, instance.systemID);
            }

			bpmext.log.info("InstanceUI.reloadInstance EXIT << ", this);
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method modifyInstance
         * @param {string} event The event name
		 * @desc Modifies the Instance UI.
		 */
        this.constructor.prototype.modifyInstance = function(event) {
			bpmext.log.info("InstanceUI.modifyInstance ENTER >> event: ", event);

            var instance =this.getInstance();
            this._proto._launchModifyInstance(this, instance);

			bpmext.log.info("InstanceUI.modifyInstance EXIT << ");
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method openInstanceActionMenu
         * @param {view} event The instance action menu button view
		 * @desc Modify the Instance UI.
		 */
        this.constructor.prototype.openInstanceActionMenu = function(event) {
			bpmext.log.info("InstanceUI.openInstanceActionMenu ENTER >> event: ", event);
            this._instance.instanceActionsMenu.open();
			bpmext.log.info("InstanceUI.openInstanceActionMenu EXIT << ");
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method beforeViewInstance
         * @param {String} eventName The event name
         * @param {Object} eventData A new workstream object binding
		 * @desc Call the event before the instance is shown, and extract target instance information (piid & systemID).
		 */
        this.constructor.prototype.beforeViewInstance = function(eventName, eventData){
            if (this._instance.blockMultipleLoads) {
                return;
            }

            var task = eventData && eventData.task;
            var target = task || eventData;

            if (target){
                var piid = target.piid || target["PROCESS_INSTANCE.PIID"];
                var systemID = target.systemID;
                var displayName = target.processInstanceName || target.name || target.PI_NAME;

                var ident = {piid: piid, systemID: systemID};
                var prevHistoryIndex = taskUtils.viewHistory.fetchHistoryIndexByIdentData(ident);

                if (prevHistoryIndex > -1) {
                    return taskUtils.viewHistory.loadHistoryItem(prevHistoryIndex);
                }

                if(target._IS_WORKSTREAM || target.isWorkstream) {

                    // Minimize info for restoring instance back
                    this._instance.viewerObj = {
                        data: {
                            piid: piid,
                            systemID: systemID,
                            name: displayName,
                            isWorkstream: true
                        }
                    };

                    var historyCallbacks = this._proto._generateHistoryCallbacks(this, displayName);
                    taskUtils.viewHistory.addToViewHistory(historyCallbacks);
                    this._instance.tabContainer.setCurrentPane(0);

                    !!piid && this._proto._fetchInstance(this, piid, systemID);
                } else {
                    var data = {
                        piid: piid,
                        name: displayName,
                        systemID: systemID,
                        isWorkstream: false
                    };
                    var curSystemInfo, runURLPrefix = dojoConfig.App._bpmContextRootMap.teamworks;
                    if(systemID) {
                        curSystemInfo = resourceUtils.getFederatedSystemInfo(systemID);
                        runURLPrefix = curSystemInfo.taskCompletionUrlPrefix;
                    }
                    data.runURL = runURLPrefix + "/launchInstanceUI?origin=workplace&instanceId=" + piid;
                    taskUtils.EVENTS.SERVICE_LAUNCHED.publish(data);
                }


            }
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method taskListNotificationsHandler
         * @param {String} eventName The event name
         * @param {Object} eventData A new workstream object binding
		 * @desc Call the event to handle the task updates.
		 */
        this.constructor.prototype.taskListNotificationsHandler = function refreshLogic(eventName, eventData){
            var delayReload = function (view) {
                if (!taskUtils.getNotificationExistence()) {
                    taskUtils.EVENTS.DELAY_RELOAD.publish();
                } else {
                    // we need to hold a reference to the throttled function so we don't create new copies of it
                    view.throttledFunc = view.throttledFunc || taskUtils.throttle(dojo.hitch(view, "reloadInstance"));
                    view.throttledFunc();
                }
            };

            if (eventData) {
                // block irrelevant reloads
                var currentInstance = this.context.options.instance;
                if (!currentInstance) {
                    return;
                }

                var instancePiid = currentInstance.get("value").piid;
                if (!(eventData.task && eventData.task.piid === instancePiid)) {
                    return;
                }

                if (taskUtils.EVENTS.TASK_RESOURCE_ASSIGNED.equals(eventData.kind) ||
                        eventData.task.state === "STATE_FINISHED"){
                    delayReload(this);
                } else if (eventData.task.state === "STATE_CLAIMED") {
                    delayReload(this);
                   } else if (taskUtils.EVENTS.TASK_FIELD_CHANGED.equals(eventData.kind)) {
                    delayReload(this);
                }
            } else {
                delayReload(this);
            }
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method delayReload
		 * @desc Event called to handle back up reloading when the notification fails.
		 */
        this.constructor.prototype.delayReload = function () {
            if (!taskUtils.getNotificationExistence()) {
                if (this._instance.delayReloadTimer) {
                    clearTimeout(this._instance.delayReloadTimer);
                }

                this._instance.delayReloadTimer = setTimeout(function () {
                    clearTimeout(this._instance.delayReloadTimer);
                    delete this._instance.delayReloadTimer;
                    this.reloadInstance();
                }, 1000);
            }
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method followInstance
		 * @desc Follow the instance.
		 */
        this.constructor.prototype.followInstance = function(event) {
			bpmext.log.info("InstanceUI.followInstance ENTER >> event: ", event);

            var instance = this.getInstance();
            this._proto._followInstance(this, instance);

			bpmext.log.info("InstanceUI.followInstance EXIT << ");
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method unFollowInstance
		 * @desc Unfollows the instance.
		 */
        this.constructor.prototype.unFollowInstance = function(event) {
			bpmext.log.info("InstanceUI.unFollowInstance ENTER >> event: ", event);

            var instance = this.getInstance();
            this._proto._unfollowInstance(this, instance);

			bpmext.log.info("InstanceUI.unFollowInstance EXIT << ");
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method launchTask
         * @param {Task} task The table row that contains the instance record.
		 * @desc Launch the instance for the given row.
         */
        this.constructor.prototype.launchTask = function launchTask(task) {
            var view = this;
            var tkiid = task["TASK.TKIID"] || task.tkiid;

            if (!taskUtils.isTaskCompleted(task)) {
                wpResources.task.get({tkiid: tkiid, includeURL: true, systemID: task.systemID}).then(function(task) {
                    view._proto._launchTask(view, task);
                });
            }
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method onActionMenuOpen
         * @param {View} actionsMenuView The actions menu view
         * @param {Element} actionsMenuTargetElement In the instance list, the button you click to invoke the menu.
		 * @desc Open the actions menu.
         */
        this.constructor.prototype.onActionMenuOpen = function onActionMenuOpen() {
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method onActionMenuClosed
         * @param {View} actionsMenuView The actions menu view
         * @param {Element} actionsMenuTargetElement In the instance list, the button you click to invoke the menu.
		 * @desc Close the actions menu.
         */
        this.constructor.prototype.onActionMenuClosed = function onActionMenuClosed(actionsMenuView, actionsMenuTargetElement) {
            // close action menu from task list
            if (!!actionsMenuTargetElement && !!actionsMenuTargetElement.firstElementChild) {
                var classes = actionsMenuTargetElement.firstElementChild.getAttribute("class");
                actionsMenuTargetElement.firstElementChild.setAttribute("class", classes.replace(" active", "").trim());
            }

            // close action menu that open from task cards
            if (actionsMenuTargetElement && actionsMenuTargetElement.classList && actionsMenuTargetElement.classList.contains("active")) {
                actionsMenuTargetElement.classList.remove("active");
            }

            !!this._instance.activityCards && this._instance.activityCards.resetFocusState();
        };

         /**
		 * @instance
		 * @memberof InstanceUI
		 * @method openWorkstreamErrorDetailModal
		 * @desc Open the workstream error details modal.
         */
        this.constructor.prototype.openWorkstreamErrorDetailModal = function() {
            bpmext.log.info("InstanceUI.openWorkstreamErrorDetailModal ENTER >> ",this);

            var instance = this.getInstance();

            taskUtils.EVENTS.SHOW_ERROR_DETAIL.publish({
                piid: instance.piid,
                systemID: instance.systemID,
                workstream: instance
            });

			bpmext.log.info("InstanceUI.openWorkstreamErrorDetailModal EXIT << ");
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method activitySelectorConditionChanged
         * @param {view} event The single select activity state view
		 * @desc Change the filter condition.
		 */
        this.constructor.prototype.activitySelectorConditionChanged = function(event) {
			bpmext.log.info("InstanceUI.activitySelectorConditionChanged ENTER >> event: ", event);
            var processedData = this._instance.processedData;
            processedData && this._proto._settingActivities(this, processedData.activities || []);
			bpmext.log.info("InstanceUI.activitySelectorConditionChanged EXIT << ");
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method closeButtonHandler
         * @param {view} event The close button view
		 * @desc Close the button handler.
		 */
        this.constructor.prototype.closeButtonHandler = function(event) {
			bpmext.log.info("InstanceUI.closeButtonHandler ENTER >> event: ", event);
            taskUtils.EVENTS.CLOSE_INSTANCE.publish();
			bpmext.log.info("InstanceUI.closeButtonHandler EXIT << ");
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method addCommentClicked
         * @param {view} event Instance UI view
		 * @desc Add comment handler.
		 */
        this.constructor.prototype.addCommentClicked = function(view) {
            view._instance.commentBoxLayout.setVisible(true);
            setTimeout(function() {
                view._instance.commentBox.context.element.querySelector("textarea").focus();
            }, 250);
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method postComment
         * @param {view} event Instance UI view
		 * @desc Post the current comment to the instance.
		 */
        this.constructor.prototype.postComment = function(view) {
            var data,
                comment = view._instance.commentBox.getText();

            if (comment) {
                data = {
                    piid: view._instance.viewerObj.data.piid,
                    comment: comment,
                    systemID: view._instance.viewerObj.data.systemID
                };
                wpResources.process.postComment(data);
                view._instance.commentBox.setText("");
                view._instance.commentBoxLayout.setVisible(false, true);

                //inject comment into the existing stream
                var newComment = {completedBy: view.context.bpm.system.user_loginName || view.context.bpm.system.user_fullName || view.context.bpm.system.user_id,
                                  comments: view.context.htmlEscape(comment),
                                  timestamp: new Date().toISOString()
                                };
                view._instance.processedData.comments.unshift(newComment);
                view._proto._settingComments(view, view._instance.processedData.comments, false);
                view._instance.addCommentsLink._instance.btn.focus();
                bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONINSTANCE_COMMENT_POST, data);
            }
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method cancelComment
         * @param {view} event Instance UI view
		 * @desc Cancel comment handler.
		 */
        this.constructor.prototype.cancelComment = function(view) {
            view._instance.commentBox.setText("");
            view._instance.commentBoxLayout.setVisible(false, true);
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method initializeView
         * @param {view} event Instance UI view
		 * @desc Initialize the view.
		 */
        this.constructor.prototype.initializeView = function(view) {
            view._proto._initView(view);
        };

        /**
		 * @instance
		 * @memberof InstanceUI
		 * @method onTabChange
         * @param {view} event Instance UI view
         * @param {Number} oldTabIndex previous tab index
         * @param {Number} tabIndex current tab index
		 * @desc On Tab Change.
		 */
        this.constructor.prototype.onTabChange = function(view, oldTabIndex, tabIndex) {
            bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONINSTANCE_TAB_CHANGE, oldTabIndex, tabIndex);
        };


        /*
        Coach NG Lifecycle methods *************************************************************
        */

        this.constructor.prototype.load = function ()
        {
            bpmext.log.info("InstanceUI.load ENTER >>", this);

            var view = this, opts = view.context.options;

            if (!opts.embededView) {
                bpmext.ui.substituteConfigOption(view, "embededView", false);
            }

            //deferred section for performance.  The view should only be loaded if it is needed
            this._instance.instanceDeferredSection = bpmext.ui.getContainer("InstanceDeferredSection", this);

            //use the embedded view option to determine if the view should be initialized right awy, or wait for an event
            if(opts.embededView.get("value")){
                this._proto._wakeUp(this);
            }

            bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONLOAD);

            this.loadContainer(this);


            var handleEvent = function(func) {
                return function (eventName, eventData) {
                    var pendingEvent = {
                        func: dojo.hitch(this, func),
                        eventName: eventName,
                        eventData: eventData
                    };
                    this._proto._wakeUp(this, pendingEvent);
                };
            };

            // Extracts target instance info (piid & systemID)
            taskUtils.EVENTS.BEFORE_VIEW_INSTANCE.subscribe(handleEvent(this.beforeViewInstance), this);

            bpmext.log.info("InstanceUI.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try
            {
                utilities.handleVisibility(this.context);
            }
            catch (e)
            {
                //{#feature: US-1330 Added RT localization}
                //bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if(e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    //bpmext.log.error("  Call stack: " + e.stack);
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                }
            }
        };

        this.constructor.prototype.change = function (event)
        {
            bpmext.log.info("InstanceUI.change ENTER >>");
            if (event.type === "config") {
                switch (event.property) {
                    case "_metadata.visibility": {
                        this.view();
                        break;
                    }
                    case "responsiveMode": {
                        if (event.oldVal !== event.newVal) {
                            // update responsive views
                        }
                        break;
                    }
                    case "instance": {
                        this._proto._loadInstance(this, event.newVal);
                        break;
                    }
                }
            }
            bpmext.log.info("InstanceUI.change EXIT >>");
        };

        this.constructor.prototype.unload = function ()
        {
            bpmext.ui.unloadContainer(this);
        };
    }
};
