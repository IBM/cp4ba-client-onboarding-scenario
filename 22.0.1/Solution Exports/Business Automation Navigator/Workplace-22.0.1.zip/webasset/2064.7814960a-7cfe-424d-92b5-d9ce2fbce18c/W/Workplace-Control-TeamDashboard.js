/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof TeamDashboard
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof TeamDashboard
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof TeamDashboard
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof TeamDashboard
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof TeamDashboard
 * @method setData
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 * </table>
 */
workplace_control_InitTeamDashboard = function (utilities, taskUtils, wpResources, domClass){
    "use strict";
    this._instance = {};

    if (!this.constructor.prototype._proto) {
        this.constructor.prototype._proto = {
            FILTER_OPTIONS: [
                {value: "", displayName: bpmext.localization.formatMsg("TeamDashboard", "sortBy")},
                {value: "allTasks", displayName: bpmext.localization.formatMsg("TeamDashboard", "sortByOpened")},
                {value: "onTrack", displayName: bpmext.localization.formatMsg("TeamDashboard", "sortByOnTrack")},
                {value: "atRisk", displayName: bpmext.localization.formatMsg("TeamDashboard", "sortByAtRisk")},
                {value: "overdue", displayName: bpmext.localization.formatMsg("TeamDashboard", "sortByOverdue")},
            ],

            TEAM_BLACK_LIST: [
                {name: "Workstreams Administrators", id: "24.4857dfd1-0ab0-4507-aa5a-721bb57f5ef9"},
                {name: "Workstreams Configurators", id: "24.78cfaca8-f199-4d3c-a050-fdb884e71811"},
                {name: "Workstreams Group Managers", id: "24.415591d2-66a9-4533-ad00-c874839a2166"},
                {name: "Workstreams Publishers", id: "24.c7dac125-5b34-41aa-90b1-04a1990c5e6b"},
                {name: "Workstreams Testers", id: "24.12bfbbed-a45f-465c-9085-ad6076fa75f4"},
                {name: "Workstreams Template Contributors", id: "24.12e6146e-3826-4932-a7ca-6149e5066bd0"}
            ],

            /******************** Fetching data - start ********************/
            _fetchTeamSummaries: function _fetchTeamSummaries (view) {
                bpmext.log.info("TeamDashboard._fetchTeamSummaries ENTER >>: ", view);

                try{
                    var successFetchTeams = function (teamSummaries) {
                        view.setTeams(teamSummaries.summaries || []);
                    };

                    var errorFetchTeams = function (error) {
                        !!error && !!error.errorMessage && taskUtils.publishError(error.errorMessage);
                        bpmext.log.error("ERROR >> There was an error fetching the team summaries: " + error);
                    };

                    wpResources.teamPerformance.getTeamSummaries().then(
                        successFetchTeams,
                        errorFetchTeams
                    );
                } catch (data) {
                    view._proto._errorLoadTeams(data);
                }

                bpmext.log.info("TeamDashboard._fetchTeamSummaries EXIT >>: ", view);
            },


            _errorLoadTeams: function _errorLoadTeams(data) {
                bpmext.log.error("TeamCards._errorLoadTeams ERROR >> There was an error loading the teams (data): " + data, this);
            },
            /******************** Fetching data - end ********************/

            /******************** Setting data - end ********************/
            _setTeams: function _setTeams(view) {
                bpmext.log.info("TeamDashboard._setTeams");

                // Total tasks stats count
                var totalTasks = view._proto._countTotalTasks(view);
                view._instance.taskStats.setStats(totalTasks);

                // Applying order and filter on config teams
                var teams = view._proto._sortSummaries(view);

                // pagination controls
                var perPage = view._instance.pagination.getPerPage();
                view._instance.pagination.setVisible(teams.length !== 0, true);
                view._instance.pagination.setItemLength(teams.length);
                view._instance.pagination.setCurPageNumber(1);

                teams = teams.splice(0, perPage);

                // Set teams value to controls
                view._instance.teamCards.setListData(teams, "team");
            },

            _countTotalTasks: function _countTotalTasks(view, teams) {
                if (!teams && !Array.isArray(teams)) {
                    teams = dojo.clone(view.getTeams());
                }

                var stats = teams.reduce(function(stats, team) {
                    return {
                        onTrack: (stats.onTrack || 0) + team.countOnTrack,
                        atRisk: (stats.atRisk || 0) + team.countAtRisk,
                        overdue: (stats.overdue || 0) + team.countOverdue,
                        total: (stats.total || 0) + team.totalOpenTasks
                    };
                }, {onTrack: 0, atRisk: 0, overdue: 0, total: 0});

                return {stats: stats};
            },

            _sortSummaries: function _sortSummaries(view) {
                bpmext.log.info("TeamDashboard._sortSummaries");

                var fieldMapping = {
                    "name": "name",
                    "allTasks": "totalOpenTasks",
                    "onTrack": "countOnTrack",
                    "atRisk": "countAtRisk",
                    "overdue": "countOverdue"
                };

                // Make sure later changes will not apply to config teams
                var teams = dojo.clone(view.getTeams());
                teams = view._proto._taskStatusFilter(view, teams);
                teams = view._proto._teamNameFilter(view, teams);

                // Order and filter, default as order by name in ascending order
                var status = view._instance.statusFilter.getData() || "name";

                // Applying order at selected filter
                var order = "descending";
                return teams.sort(function (team1, team2){
                    var field = fieldMapping[status];
                    if (status !== "name" && order === "descending") {
                        return team1[field] > team2[field] ? -1 : 1;
                    } else {
                        return team1[field] > team2[field]  ? 1 : -1;
                    }
                });
            },


            _teamNameFilter: function _teamNameFilter(view, teams) {
                var teamNameFilterText = view._instance.teamNameFilterText || "";
                return !teamNameFilterText ? teams : teams.filter(function (team) {
                    var name = team.name;
                    name = name.toLowerCase();

                    return name.indexOf(teamNameFilterText.toLowerCase()) >= 0;
                });
            },

            _taskStatusFilter: function _taskStatusFilter(view, teams) {
                var taskStatusFilterText  = view._instance.taskStatusFilterText || "";
                return !taskStatusFilterText ? teams : teams.filter(function (team) {
                    return team[taskStatusFilterText] > 0;
                });
            },
            /******************** Setting data - end ********************/


            /******************** Others - start ********************/
            // Remove cache values on screen
            _clearViews: function _clearViews(view) {
                // Clear changes on control
                if (view._instance.statusFilter.getSelectedIndex() !== 0) {
                    view._instance.statusFilter.setSelectedItemAt(0);
                }

                view._instance.taskStats.removeFilters();

                // clear filter
                view.clearTeamNameFilter();

                // clear team cards
                view.setTeams([]);
            },

            _initStatusFilter: function _initStatusFilter(view) {
                bpmext.log.info("TeamDashboard._initStatusFilter");

                // Append options to the filter
                view._proto.FILTER_OPTIONS.forEach(function(term) {
                    view._instance.statusFilter.appendItem(term.value, term.displayName);
                });

                // Init filter option
                view._instance.statusFilter.setSelectedItemAt(0);
            },

            _initTeamNameFilter: function _initTeamNameFilter(view) {
                bpmext.log.info("TeamDashboard._initTeamNameFilter");

                if (!!view._instance.teamNameFilter) {
                    view._instance.teamNameFilter.setPlaceholder(bpmext.localization.formatMsg("TeamDashboard", "teamNameFilterPlaceHolder"));

                    var input = view._instance.teamNameFilter.context.element.querySelector(".input > input");
                    !!input && input.setAttribute("autocomplete", "off");
                }

                if (view._instance.clearText) {
                    view._instance.clearText.setVisible(false, true);
                }

                view.toggleFilterExpansion(false);
            },

            _initControls: function _initControls(view) {
                view.setTeams([]);
            },

            _applyTeamBlackList: function _applyTeamBlackList(view, teams) {
                if (!teams && !Array.isArray(teams)) {
                    teams = dojo.clone(view.getTeams());
                }

                var teamIds = [], teamNames = [];
                view._proto.TEAM_BLACK_LIST.forEach(function (blackTeam) {
                    teamNames.push(blackTeam.name);
                    teamIds.push(blackTeam.id);
                });

                return teams.filter(function (team) {
                    var hasTeamName = teamNames.indexOf(team.name) >= 0;
                    var hasTeamId = teamIds.indexOf(team.teamId) >= 0;
                    return !hasTeamName && !hasTeamId;
                });
            },

            _localization: function _localization(view) {
                taskUtils.addTooltip(view._instance.copyLinkIcon, bpmext.localization.formatMsg("workplace", "copyLink"), 500);
            },

            _generateHistoryCallbacks: function _generateHistoryCallbacks (view, displayName) {
                bpmext.log.info("TeamDashboard._generateHistoryCallbacks: ", displayName);

                var onViewRestore = function () {
                    taskUtils.EVENTS.BEFORE_VIEW_TEAM_DASHBOARD.publish();
                };

                var onViewClose = function() {
                    view.closeTeamDashboard();
                };

                return {
                    identifier: "TeamDashboard",
                    displayName: displayName || bpmext.localization.formatMsg("TeamDashboard", "TeamDashboard"),
                    onViewRestore: onViewRestore,
                    onViewClose: onViewClose
                };
            }
            /******************** Others - end ********************/
        };

        /*
        Public control methods *************************************************************
        */

        /**
		 * @instance
		 * @memberof TeamDashboard
		 * @method setTeams
		 * @desc Get teams
		 */
        this.constructor.prototype.setTeams = function(teams) {
            bpmext.log.info("TeamDashboard.setTeams ENTER >> event: ", event);
            teams = this._proto._applyTeamBlackList(this, dojo.clone(teams || []));
            this.context.options.teams && this.context.options.teams.set("value", teams);
			bpmext.log.info("TeamDashboard.setTeams EXIT << ");
        };

        /**
		 * @instance
		 * @memberof TeamDashboard
		 * @method getTeams
		 * @desc Get teams
		 */
        this.constructor.prototype.getTeams = function() {
            bpmext.log.info("TeamDashboard.getTeams");
            return this.context.options.teams ? this.context.options.teams.get("value").items : [];
        };

        /**
		 * @instance
		 * @memberof TeamDashboard
		 * @method showTeamSummaries
		 * @desc Show team summaries
		 */
        this.constructor.prototype.showTeamSummaries = function() {
            bpmext.log.info("TeamDashboard.showTeamSummaries");

            if (!this.isVisible()) {
                var teamDashboardDS = bpmext.ui.getContainer("/Workplace_Content_Wrapper1/Team_Dashboard_DS");
                !!teamDashboardDS && teamDashboardDS.setVisible(true, true);

                this.setVisible(true, true);
            }
        };

        /**
		 * @instance
		 * @memberof TeamDashboard
		 * @method closeTeamDashboard
		 * @desc Close team dashboard
		 */
        this.constructor.prototype.closeTeamDashboard = function() {
            bpmext.log.info("TeamDashboard.closeTeamDashboard");

            if (this.isVisible()) {
                var teamDashboardDS = bpmext.ui.getContainer("/Workplace_Content_Wrapper1/Team_Dashboard_DS");
                !!teamDashboardDS && teamDashboardDS.setVisible(false, true);

                this._proto._clearViews(this);

                this.setVisible(false, true);
            }
        };

        /**
		 * @instance
		 * @memberof TeamDashboard
		 * @method reloadTeamDashboard
		 * @desc Reload team dashboard
		 */
        this.constructor.prototype.reloadTeamDashboard = function () {
            bpmext.log.info("TeamDashboard.reloadTeamDashboard");

            if (this.isVisible()) {
                this._proto._fetchTeamSummaries(this);
            }
        };

        /**
		 * @instance
		 * @memberof TeamDashboard
		 * @method filterChanged
		 * @desc Updates the list when filter changed
		 */
        this.constructor.prototype.filterChanged = function (target, newVal, oldVal) {
            bpmext.log.info("TeamDashboard.filterChanged");
            if (oldVal !== null && oldVal !== undefined) {
                this._proto._fetchTeamSummaries(this);
            }
        };

        /**
		 * @instance
		 * @memberof TeamDashboard
		 * @method updateSearchContent
		 * @desc Updates the search content
		 */
        this.constructor.prototype.updateSearchContent = function (target) {
            bpmext.log.info("TeamDashboard.updateSearchContent");
            var teamNameFilterText = target.getText();
            if (!!target && this._instance.teamNameFilterText !== teamNameFilterText) {
                this._instance.teamNameFilterText = teamNameFilterText;
                this._proto._fetchTeamSummaries(this);
            }
        };

        /**
		 * @instance
		 * @memberof TeamDashboard
		 * @method toggleClearTextBtn
		 * @desc Toggle clear text button
		 */
        this.constructor.prototype.toggleClearTextBtn = function () {
            bpmext.log.info("TeamDashboard.toggleClearTextBtn");
            var value = this._instance.teamNameFilter._instance.text.value || "";
            this._instance.clearText.setVisible(!!value, true);

            if (!!value) {
                domClass.add(this._instance.teamNameFilter._instance.input, "showCloseBtn");
            } else if (!this._instance.teamNameFilterText) {
                domClass.remove(this._instance.teamNameFilter._instance.input, "showCloseBtn");
            }
        };

        /**
		 * @instance
		 * @memberof TeamDashboard
		 * @method clearTeamNameFilter
		 * @desc Clear team name filter
		 */
        this.constructor.prototype.clearTeamNameFilter = function () {
            bpmext.log.info("TeamDashboard.clearTeamNameFilter");
            this._instance.teamNameFilter.setText("");

            this.toggleClearTextBtn();
            this.toggleFilterExpansion(false);
        };

        /**
		 * @instance
		 * @memberof TeamDashboard
		 * @method toggleFilterExpansion
		 * @desc Whether team name filter should be expanded or collapsed
		 */
        this.constructor.prototype.toggleFilterExpansion = function (expand) {
            bpmext.log.info("TeamDashboard.toggleFilterExpansion");

            if (expand) {
                domClass.add(this._instance.searchWrapper.context.element, "expanded");
                domClass.remove(this._instance.searchWrapper.context.element, "collapsed");
            } else if (!this._instance.teamNameFilterText) {
                domClass.remove(this._instance.searchWrapper.context.element, "expanded");
                domClass.add(this._instance.searchWrapper.context.element, "collapsed");
            }
        };

        /**
		 * @instance
		 * @memberof TeamDashboard
		 * @method taskStatusFilterChange
		 * @desc Whether team name filter should be expanded or collapsed
		 */
        this.constructor.prototype.taskStatusFilterChange = function (target, filter) {
            var fieldMatching = {
                atRisk: "countAtRisk",
                overdue: "countOverdue",
                onTrack: "countOnTrack",
                total: ""
            };

            if (this._instance.taskStatusFilterText !== fieldMatching[filter.filter]) {
                this._instance.taskStatusFilterText = fieldMatching[filter.filter];
                this._proto._fetchTeamSummaries(this);
            }
        };


        /**
		 * @instance
		 * @memberof TeamDashboard
		 * @method setItemsForPage
		 * @desc Set item for different pagination control settings
		 */
        this.constructor.prototype.setItemsForPage = function (target) {
            var perPage = target.getPerPage();
            var curPage = target.getCurPageNumber();

            if (!this._instance.teamCards) {
                return;
            }

            if (this.isVisible()) {
                if (this._instance.perPage === perPage && this._instance.curPage === curPage) {
                    return;
                }

                var teams = this._proto._sortSummaries(this);
                teams = teams.splice(perPage * (curPage - 1), perPage);

                this._instance.teamCards.setListData(teams, "team");

                this._instance.perPage = perPage;
                this._instance.curPage = curPage;
            }
        };

        /**
		 * @instance
		 * @memberof TeamDashboard
		 * @method copyLink
		 * @desc Copy the Link
    	 */
         this.constructor.prototype.copyLink = function() {
            if (this.isVisible() && this.context.getInheritedVisibility() !== "NONE") {
                taskUtils.EVENTS.COPY_LINK.publish();
            }
       };

       /*
        Coach NG Lifecycle methods *************************************************************
        */

        this.constructor.prototype.load = function () {
            bpmext.log.info("TeamDashboard.load ENTER >>", this);

            var view = this, opts = this.context.options;

            if (!opts.teams) {
                bpmext.ui.substituteConfigOption(this, "teams", []);
            }

            // Title
            this._instance.teamTitle = bpmext.ui.getView("Team_Card_Title", this);
            this._instance.teamTitle._instance.outputText.setAttribute("role", "heading");
            this._instance.teamTitle._instance.outputText.setAttribute("aria-level", "1");

            // Task statistics
            this._instance.taskStats = bpmext.ui.getView("Task_Statistics", this);

            // Control & filter
            this._instance.refreshBtn = bpmext.ui.getView("Refresh_Button", this);
            this._instance.closeBtn = bpmext.ui.getView("Close_Button", this);
            this._instance.statusFilter = bpmext.ui.getView("StatusFilter", this);
            this._instance.pagination = bpmext.ui.getView("Pagination", this);
            this._instance.searchWrapper = bpmext.ui.getContainer("SearchWrapper", this);
            this._instance.teamNameFilter = bpmext.ui.getView("TeamNameFilter", this);
            this._instance.clearText = bpmext.ui.getView("ClearText", this);

            // Cards
            this._instance.teamCards = bpmext.ui.getContainer("Team_cards", this);

            //Modals
            this._instance.copyLinkIcon = bpmext.ui.getView("CopyLinkIcon", this);

            // Init pages
            this._proto._localization(this);
            this._proto._initStatusFilter(this);
            this._proto._initTeamNameFilter(this);
            this._proto._initControls(this);

            // Apply configs
            this.getTeams() && this._proto._setTeams(this);


            this.loadView(this);


            taskUtils.EVENTS.BEFORE_VIEW_TEAM_DASHBOARD.subscribe(function () {
                this.showTeamSummaries();

                // Minimize info for restoring instance back
                this._instance.viewerObj = {};

                // Push to history stack
                var historyCallbacks = this._proto._generateHistoryCallbacks(this, bpmext.localization.formatMsg("TeamDashboard", "TeamDashboard"));
                taskUtils.viewHistory.addToViewHistory(historyCallbacks);

                this.reloadTeamDashboard();
            }, this);

            taskUtils.EVENTS.CLOSE_TEAM_DASHBOARD.subscribe(function () {
                // Open previous page by calling history
                taskUtils.viewHistory.loadViewFromHistory();
            }, this);


            var reloadTeamDashboard = function () {this.reloadTeamDashboard();};
            taskUtils.EVENTS.RELOAD_TEAM_DASHBOARD.subscribe(reloadTeamDashboard, this);

            // reload team dashboard on new task assignment and task field changes
            var reloadTeamDashboardOnTaskUpdate = function () {
                if (view._instance.accumulatedTO) {
                    clearTimeout(view._instance.accumulatedTO);
                }

                // accumulate consecutive updates into one update call
                view._instance.accumulatedTO = setTimeout(function () {
                    view.reloadTeamDashboard();
                    delete view._instance.accumulatedTO;
                }, 300);
            };

            taskUtils.EVENTS.TASKLIST_TASK_RESOURCE_ASSIGNED.subscribe(taskUtils.throttle(dojo.hitch(this, reloadTeamDashboardOnTaskUpdate)), this);
            taskUtils.EVENTS.TASK_FIELD_CHANGED.subscribe(taskUtils.throttle(dojo.hitch(this, reloadTeamDashboardOnTaskUpdate)), this);
        };

        this.constructor.prototype.view = function () {
            try {
                utilities.handleVisibility(this.context);
            } catch (e) {
                //{#feature: US-1330 Added RT localization}
                //bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if(e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    //bpmext.log.error("  Call stack: " + e.stack);
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                }
            }
        };

        this.constructor.prototype.change = function (event) {
            bpmext.log.info("TeamDashboard.change ENTER >>");
            if (event.type === "config") {
                switch (event.property) {
                    case "_metadata.visibility": {
                        this.view();
                        break;
                    }
                    case "teams": {
                        this._proto._setTeams(this);
                        break;
                    }
                }
            }
            bpmext.log.info("TeamDashboard.change EXIT >>");
        };

        this.constructor.prototype.unload = function () {
            bpmext.ui.unloadView(this);
        };
    }
};