/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof SearchFilter
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof SearchFilter
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof SearchFilter
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof SearchFilter
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof SearchFilter
 * @method setData
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On Change:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when the task filter is changed.</td>
 *               </tr>
 *           </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *               </tr>
 *       </table>
 *     </td>
 *   </tr>
 * </table>
 */
workplace_control_InitFilter = function (utilities, taskUtils, resourceUtils, wpResources, domAttr)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto = {
            //Event constants
            EVT_ONCHANGE: "eventON_CHANGE",

            //SEARCH FILTER CONSTANTS
            STRING_OPERATOR: [
                { name: taskUtils.OPERATOR.EQUALS, value: bpmext.localization.formatMsg("searchFilter", "is") },
                {
                    name: taskUtils.OPERATOR.NOT_EQUALS,
                    value: bpmext.localization.formatMsg("searchFilter", "isNot")
                },
                {
                    name: taskUtils.OPERATOR.CONTAINS,
                    value: bpmext.localization.formatMsg("searchFilter", "contains")
                },
                {
                    name: taskUtils.OPERATOR.STARTS_WITH,
                    value: bpmext.localization.formatMsg("searchFilter", "startsWith")
                }
            ],
            SEARCHABLE_STRING_OPERATOR: [
                { name: taskUtils.OPERATOR.EQUALS, value: bpmext.localization.formatMsg("searchFilter", "is") },
                {
                    name: taskUtils.OPERATOR.NOT_EQUALS,
                    value: bpmext.localization.formatMsg("searchFilter", "isNot")
                },
                {
                    name: taskUtils.OPERATOR.CONTAINS,
                    value: bpmext.localization.formatMsg("searchFilter", "contains")
                },
                {
                    name: taskUtils.OPERATOR.STARTS_WITH,
                    value: bpmext.localization.formatMsg("searchFilter", "startsWith")
                },
                {
                    name: taskUtils.OPERATOR.FULL_TEXT_SEARCH,
                    value: bpmext.localization.formatMsg("searchFilter", "searchFor")
                }
            ],
            NUMBER_OPERATOR: [
                { name: taskUtils.OPERATOR.EQUALS, value: bpmext.localization.formatMsg("searchFilter", "is") },
                {
                    name: taskUtils.OPERATOR.NOT_EQUALS,
                    value: bpmext.localization.formatMsg("searchFilter", "isNot")
                },
                {
                    name: taskUtils.OPERATOR.LESS_THAN,
                    value: bpmext.localization.formatMsg("searchFilter", "isLessThan")
                },
                {
                    name: taskUtils.OPERATOR.GREATER_THAN,
                    value: bpmext.localization.formatMsg("searchFilter", "isGreaterThan")
                }
            ],
            DATE_OPERATOR: [
                { name: taskUtils.OPERATOR.EQUALS, value: bpmext.localization.formatMsg("searchFilter", "is") },
                {
                    name: taskUtils.OPERATOR.LESS_THAN,
                    value: bpmext.localization.formatMsg("searchFilter", "isBefore")
                },
                {
                    name: taskUtils.OPERATOR.GREATER_THAN,
                    value: bpmext.localization.formatMsg("searchFilter", "isAfter")
                }
            ],
            PRIORITY_VALUES: [
                { name: "Lowest", value: bpmext.localization.formatMsg("controlTaskList", "PriorityVeryLow") },
                { name: "Low", value: bpmext.localization.formatMsg("controlTaskList", "PriorityLow") },
                { name: "Normal", value: bpmext.localization.formatMsg("controlTaskList", "PriorityMedium") },
                { name: "High", value: bpmext.localization.formatMsg("controlTaskList", "PriorityHigh") },
                { name: "Highest", value: bpmext.localization.formatMsg("controlTaskList", "PriorityVeryHigh") }
            ],
            BOOLEAN_VALUES: [
                { name: "true", value: bpmext.localization.formatMsg("searchFilter", "true") },
                { name: "false", value: bpmext.localization.formatMsg("searchFilter", "false") }
            ],
            TASK_STATUS: [
                { name: "New_or_Received", value: bpmext.localization.formatMsg("searchFilter", "newOrReceived") },
                { name: "Actioned", value: bpmext.localization.formatMsg("searchFilter", "actioned") },
                { name: "Alert", value: bpmext.localization.formatMsg("searchFilter", "alert") },
                {
                    name: "Answered_Help_Request",
                    value: bpmext.localization.formatMsg("searchFilter", "answeredHelpRequest")
                },
                { name: "Closed", value: bpmext.localization.formatMsg("searchFilter", "closed") },
                { name: "Collaboration", value: bpmext.localization.formatMsg("searchFilter", "collaboration") },
                { name: "Comment", value: bpmext.localization.formatMsg("searchFilter", "comment") },
                { name: "Deleted", value: bpmext.localization.formatMsg("searchFilter", "deleted") },
                { name: "Followed", value: bpmext.localization.formatMsg("searchFilter", "followed") },
                { name: "Forwarded", value: bpmext.localization.formatMsg("searchFilter", "forwarded") },
                { name: "Help_Request", value: bpmext.localization.formatMsg("searchFilter", "helpRequest") },
                {
                    name: "Ignored_Help_Request",
                    value: bpmext.localization.formatMsg("searchFilter", "ignoredHelpRequest")
                },
                { name: "New", value: bpmext.localization.formatMsg("searchFilter", "new") },
                { name: "Received", value: bpmext.localization.formatMsg("searchFilter", "received") },
                { name: "Replied", value: bpmext.localization.formatMsg("searchFilter", "replied") },
                { name: "Sent", value: bpmext.localization.formatMsg("searchFilter", "sent") },
                { name: "Special", value: bpmext.localization.formatMsg("searchFilter", "special") },
                { name: "Tagged", value: bpmext.localization.formatMsg("searchFilter", "tagged") }
            ],
            INSTANCE_STATUS: [
                { name: "Active", value: bpmext.localization.formatMsg("searchFilter", "active") },
                { name: "Completed", value: bpmext.localization.formatMsg("searchFilter", "completed") },
                { name: "Failed", value: bpmext.localization.formatMsg("searchFilter", "failed") },
                { name: "Terminated", value: bpmext.localization.formatMsg("searchFilter", "terminated") },
                { name: "Did_not_Start", value: bpmext.localization.formatMsg("searchFilter", "didNotStart") },
                { name: "Suspended", value: bpmext.localization.formatMsg("searchFilter", "suspended") }
            ],
            ACTIVITY_TYPE: [
                { name: "USER_TASK", value: bpmext.localization.formatMsg("searchFilter", "userTask") },
                { name: "SERVICE_TASK", value: bpmext.localization.formatMsg("searchFilter", "serviceTask") },
                { name: "DECISION_TASK", value: bpmext.localization.formatMsg("searchFilter", "decisionTask") }
            ],
            INSTANCE_TYPE: [
                { name: "Process", value: bpmext.localization.formatMsg("searchFilter", "processes") },
                { name: "Workstream", value: bpmext.localization.formatMsg("searchFilter", "workstreams") }
            ],
            INSTANCE_PROJECT_FILTER_TYPE: [
                { name: "BpdAppAcronym", value: bpmext.localization.formatMsg("searchFilter", "processes") },
                { name: "CaseSolution", value: bpmext.localization.formatMsg("searchFilter", "caseSolution") },
                { name: "CaseType", value: bpmext.localization.formatMsg("searchFilter", "caseType") }
            ],
            STACK_PANE: {
                STRING: 0,
                DATE: 1,
                INTEGER: 2,
                DECIMAL: 3,
                SELECT: 4,
                BOOLEAN: 5
            },

            DEFAULT_VALUE_SIZE: 20,

            //Gets the current filter conditions
            _getCurrentFilter: function _getCurrentFilter(view) {
                bpmext.log.info("SearchFilter._getCurrentFilter ENTER >>", view);

                var x,
                    item,
                    currentName,
                    currentValue,
                    currentOperator,
                    val = [];
                var filter = view._instance.filterView.context.binding.get("value");
                for (x = 0; x < filter.length(); x++) {
                    currentName = "";
                    item = filter.get(x);
                    if(item.get("name")){
                        currentName = item.get("name");
                    }else if(item.get("field")){
                        currentName = item.get("field");
                    }else{
                        currentName = (x===0 && !currentName) ? "interaction" : currentName;
                    }
                    if (currentName && currentName !== "") {
                        currentValue = item.get("value");
                        currentOperator = item.get("operator");
                        if (currentValue instanceof Date) {
                            currentValue = JSON.stringify(new Date(currentValue.toUTCString())).replace(/"/g, "");
                        }
                        switch (currentOperator) {
                            case taskUtils.OPERATOR.NOT_EQUALS:
                                val.push(wpResources.tasks.OPERATOR.NOT_EQUALS(currentName, currentValue));
                                break;
                            case taskUtils.OPERATOR.CONTAINS:
                                val.push(wpResources.tasks.OPERATOR.CONTAINS(currentName, currentValue));
                                break;
                            case taskUtils.OPERATOR.STARTS_WITH:
                                val.push(wpResources.tasks.OPERATOR.STARTS_WITH(currentName, currentValue));
                                break;
                            case taskUtils.OPERATOR.LESS_THAN:
                                val.push(wpResources.tasks.OPERATOR.LESS_THAN(currentName, currentValue));
                                break;
                            case taskUtils.OPERATOR.GREATER_THAN:
                                val.push(wpResources.tasks.OPERATOR.GREATER_THAN(currentName, currentValue));
                                break;
                            case taskUtils.OPERATOR.FULL_TEXT_SEARCH:
                                val.push(wpResources.tasks.OPERATOR.FULL_TEXT_SEARCH(currentValue));
                                break;
                            case taskUtils.OPERATOR.EQUALS:
                            default:
                                val.push(wpResources.tasks.OPERATOR.EQUALS(currentName, currentValue));
                        }
                    }
                }
                bpmext.log.debug("SearchFilter._getCurrentFilter Filter is: " + val, view);
                bpmext.log.info("SearchFilter._getCurrentFilter EXIT >>", view);
                return val;
            },

            _getData: function _getData(view) {
                if(view._instance.instanceFilter) {
                    if(wpResources.isFederated){
                        wpResources.searches.getInstanceMetaFields().then(function(systemData) {
                            wpResources.searches.getInstanceMetaBusinessDataFields().then(function(businessData) {
                                var isPXServer = view.context.isWorkflowPXServer && view.context.isWorkflowPXServer() === true,
                                	isCaseSupported = view.context.isCaseSupported && view.context.isCaseSupported() === true;
                                var fieldsToHide = taskUtils.NON_SEARCHABLE_FIELDS.concat(taskUtils.getFieldsToHide(isPXServer || !isCaseSupported, true));
                                view._instance.systemData = taskUtils.processColumns(
                                    systemData,
                                    fieldsToHide,
                                    true
                                );
                                view._instance.businessData = taskUtils.processBusinessDataColumns(businessData);
                                view._instance.columnList = view.buildColumnsList(
                                    view._instance.businessData.concat(view._instance.systemData)
                                );
                            });
                        });
                    }else{
                        wpResources.systems.getFederationResults().then(function success(systems) {
                            var isCaseEnabled = false, columList = taskUtils.COMMON_SEARCHABLEFIELDS;
                            for (var systemInfo in systems) {
                                if(systems[systemInfo].systemType === "SYSTEM_TYPE_CASE") {
                                    isCaseEnabled = true;
                                    break;
                                }
                            }
                            if (isCaseEnabled) {
                                columList = columList.concat(taskUtils.CASE_SEARCHABLEFIELDS);
                            }
                            for (var i = 0; i < columList.length; i++) {
                                columList[i].value  = bpmext.localization.formatMsg("searchFilter", columList[i].name);
                            }
                            view._instance.columnList = view.buildColumnsList(columList);
                            view._instance.isCaseEnabled = isCaseEnabled;
                        });
                    }
                } else {
                    wpResources.searches.getMetaFields().then(function(systemData) {
                        wpResources.searches.getMetaBusinessDataFields().then(function(businessData) {
                            var isPXServer = view.context.isWorkflowPXServer && view.context.isWorkflowPXServer() === true,
                            	isCaseSupported = view.context.isCaseSupported && view.context.isCaseSupported() === true;
                            var fieldsToHide = taskUtils.NON_SEARCHABLE_FIELDS.concat(taskUtils.getFieldsToHide(isPXServer || !isCaseSupported, false));
                            view._instance.systemData = taskUtils.processColumns(
                                systemData,
                                fieldsToHide
                            );
                            view._instance.businessData = taskUtils.processBusinessDataColumns(businessData);
                            view._instance.columnList = view.buildColumnsList(
                                view._instance.businessData.concat(view._instance.systemData)
                            );
                            var columnSelector = bpmext.ui.getView("SearchFilterDataSelector", view);
                            if (columnSelector) {
                                view.resetName(columnSelector);
                            }
                        });
                    });
                }
            },
            _setInputSize: function _setInputSize(view, inputView) {
                bpmext.log.info("SearchFilter._setInputSize ENTER >>", inputView);
                var placeholderElement, paneElement, inputElement;
                paneElement = inputView.context.element;
                inputElement = paneElement.querySelector("input");
                if(inputElement){
                    placeholderElement = domAttr.get(inputElement, "placeholder");
                    if(placeholderElement){
                        domAttr.set(inputElement, "size", placeholderElement.length > view._proto.DEFAULT_VALUE_SIZE ? placeholderElement.length : view._proto.DEFAULT_VALUE_SIZE);
                    }
                }
            },

            _checkCaseOptions: function _checkCaseOptions(view) {
                bpmext.log.info("SearchFilter._checkCaseOption ENTER >>", view);
                var fetchError = function (error) {
                    !!error && !!error.errorMessage && taskUtils.publishError(error.errorMessage);
                    bpmext.log.error("ERROR >> There was an error fetching casetypes: " + error);
                };
                if(resourceUtils.exposedResources && resourceUtils.exposedResources.caseTypes) {
                    view._proto._setCaseOptions(view, resourceUtils.exposedResources.caseTypes);
                } else {
                    wpResources.config.get().then(function(config) {
                        var options = {
                            excludeReferencedFromToolkit: !!config.excludeReferencedFromToolkit,
                            includeDescription: true,
                            subtypes: [
                                wpResources.exposed.SERVICE_SUBTYPE.STARTABLE_SERVICE,
                                wpResources.exposed.SERVICE_SUBTYPE.DASHBOARD
                            ]
                        };

                        wpResources.exposed.get(options).then(
                            function (exposedData) {
                                var data = resourceUtils.buildResources(exposedData, options);
                                view._proto._setCaseOptions(view, data.caseTypes);
                            },
                            fetchError
                        );
                    }, fetchError);
                }
            },

            _setCaseOptions: function _setCaseOptions(view, caseTypes) {
                bpmext.log.info("SearchFilter._setCaseOptions ENTER >>", view);
                var caseInfo = resourceUtils.processCaseTypeInfo(caseTypes);
                view._instance.allCaseTypes = caseInfo.allCaseTypes;
                view._instance.allProjects = caseInfo.allCaseSolution;
                view._instance.allCaseStages = caseInfo.allCaseStages;
            }
        };

        /*
        Public control methods *************************************************************
        */

        /**
         * @instance
         * @memberof SearchFilter
         * @method buildColumnsList
         * @param {NameLabelPair[]} cols The list of columns to populate the select list
         * @return {NameValuePair[]} The output list of columns
         * @desc Builds the list of selectable columns based on the provided cols
         */
        this.constructor.prototype.buildColumnsList = function buildColumnsList(cols) {
            bpmext.log.info("SearchFilter.buildColumnsList ENTER >>", this);

            var x, item, fields = [], outCols = [];
                this._instance.typeMap = {};

                for(x=0; x<cols.length; x++) {
                    item = {"value": cols[x].value, "name": cols[x].name};
                    this._instance.typeMap[cols[x].name] = cols[x].type;
                    if ((cols[x].name === "taskPriority") || (cols[x].name === "taskActivityType") || (cols[x].name === "taskStatus") || (cols[x].name === "instanceStatus") || (cols[x].type === "enum")) {
                        //special handling for priority
                        this._instance.typeMap[cols[x].name] = "Select";
                    }
                    if (cols[x].name !== "taskState") {
                        fields.push(item);
                    }
                }
                outCols = fields.concat(outCols);

                //special handling for interaction
                this._instance.typeMap["interaction"] = "Select";

                bpmext.log.debug("SearchFilter.buildColumnsList outCols: " + outCols, this);
                bpmext.log.info("SearchFilter.buildColumnsList EXIT >>", this);
                return outCols;
        };

        /**
         * @instance
         * @memberof SearchFilter
         * @method getColumnList
         * @return {NameValuePair[]} The list of columns
         * @desc Returns the current columns list
         */
        this.constructor.prototype.getColumnList = function getColumnList() {
                return this._instance.columnList;
            };

        /**
         * @instance
         * @memberof SearchFilter
         * @method populateSelectorWithColumnList
         * @param {View} selectView The view that holds the list of selectable columns
         * @param {View} searchFilterView The parent search filter view
         * @desc Initializes the filter selector with the column list
         */
        this.constructor.prototype.populateSelectorWithColumnList = function populateSelectorWithColumnList(selectView, searchFilterView) {
                var stack  = selectView.ui.getSibling("Stack1");
                var taskStateLabelView = selectView.ui.getSibling("TaskState", this);
                var isPXServer = searchFilterView.context.isWorkflowPXServer && searchFilterView.context.isWorkflowPXServer() === true;
                var scopeFilters = isPXServer ? taskUtils.DEFAULT_PX_SCOPE_FILTERS : taskUtils.DEFAULT_SCOPE_FILTERS;
                if(this._instance.scopeFilter && !this._instance.instanceFilter){
                    filter = searchFilterView._instance.filterView.context.binding.get("value");
                    var addIcon = stack.ui.getSibling("AddIcon");
                    taskStateLabelView.setVisible(false,true);
                    addIcon.setVisible(false,true);
                    var scopeData = [];
                    for(var i=0; i<scopeFilters.length; i++){
                        for(var j=0; j<this._instance.systemData.length; j++){
                            if(scopeFilters[i] == this._instance.systemData[j].name){
                                scopeData.push(this._instance.systemData[j]);
                            }
                        }
                    }
                    selectView.setSearchData(scopeData,null);
                    
                    this._proto._setInputSize(this, stack.getViewInPane(this._proto.STACK_PANE.STRING));
                    if (!!filter && !!filter.get(0)) {
                        var data = filter.get(0);
                        selectView.setSelectedItem(data.name);
                        var valueInput = stack.getViewInPane(this._proto.STACK_PANE.STRING);
                        valueInput.setData(data.value);
                    }
                }
                else if (selectView.ui.getIndex() !== 0) {
                    taskStateLabelView.setVisible(false,true);
                    if (this._instance.instanceFilter) {
                        if(wpResources.isFederated){
                            selectView.setSearchData(this._instance.systemData, this._instance.businessData);
                        }else{
                            selectView.setSearchData(null, this.getColumnList());     
                        }
                    } else {
                        selectView.setSearchData(taskUtils.removeScopedFileds(this._instance.systemData, isPXServer), this._instance.businessData);
                    }
                    this._proto._setInputSize(this, stack.getViewInPane(this._proto.STACK_PANE.STRING));
                } else {
                    selectView.setVisible(false, true);
                    var stateSelectView = stack.getViewInPane(this._proto.STACK_PANE.SELECT);
                    stateSelectView.clearItems();
                    var item, initialSelected, filter = searchFilterView._instance.filterView.context.binding.get("value");

                    //set initial filter to task state
                    if(this._instance.instanceFilter) {
                        taskStateLabelView.setData(bpmext.localization.formatMsg("searchFilter", "instanceState"));
                        stateSelectView.appendItem(wpResources.processes.INTERACTION.ALL, bpmext.localization.formatMsg("searchFilter", "tasksAll"));
                        stateSelectView.appendItem(wpResources.processes.INTERACTION.ACTIVE, bpmext.localization.formatMsg("searchFilter", "active"));
                        stateSelectView.appendItem(wpResources.processes.INTERACTION.COMPLETED, bpmext.localization.formatMsg("searchFilter", "completed"));
                        stateSelectView.appendItem(wpResources.processes.INTERACTION.FAILED, bpmext.localization.formatMsg("searchFilter", "failed"));
                        initialSelected = wpResources.processes.INTERACTION.ACTIVE;
                    } else {
                        taskStateLabelView.setData(bpmext.localization.formatMsg("searchFilter", "taskState"));
                        stateSelectView.appendItem(wpResources.tasks.INTERACTION.ALL, bpmext.localization.formatMsg("searchFilter", "tasksAll"));
                        stateSelectView.appendItem(wpResources.tasks.INTERACTION.CLAIMED, bpmext.localization.formatMsg("searchFilter", "tasksClaimed"));
                        stateSelectView.appendItem(wpResources.tasks.INTERACTION.AVAILABLE, bpmext.localization.formatMsg("searchFilter", "tasksAvailable"));
                        stateSelectView.appendItem(wpResources.tasks.INTERACTION.COMPLETED, bpmext.localization.formatMsg("searchFilter", "tasksCompleted"));
                        stateSelectView.appendItem(wpResources.tasks.INTERACTION.CLAIMED_AND_AVAILABLE, bpmext.localization.formatMsg("searchFilter", "tasksClaimedAndAvailable"));
                        initialSelected = wpResources.tasks.INTERACTION.CLAIMED_AND_AVAILABLE;
                    }
                    taskStateLabelView.setVisible(true);
                    if (!!filter && !!filter.get(0) && !!filter.get(0).get("value")) {
                        item = filter.get(0).get("value");
                    } else {
                        item = initialSelected;
                    }
                    stateSelectView.setSelectedItem(item);
                    stack.setCurrentPane(this._proto.STACK_PANE.SELECT);


                    var operatorCV = selectView.ui.getSibling("FilterOperator");
                    var isOperatorCV = operatorCV.ui.getSibling("isOperator");
                    operatorCV.setVisible(false, true);
                    isOperatorCV.setVisible(true);

                    searchFilterView.publishFilter();
                }
        };

        /**
         * @instance
         * @memberof SearchFilter
         * @method getType
         * @return {string} The name of the data type
         * @desc Returns the data type of the given filter
         */
        this.constructor.prototype.getType = function(name) {
            this._instance.typeMap = this._instance.typeMap ? this._instance.typeMap : {};
            return this._instance.typeMap[name];
        };

        /**
         * @instance
         * @memberof SearchFilter
         * @method getStackControlId
         * @param {string} type The data type of the filter
         * @return {int} The identifier of the stack pane
         * @desc Returns The identifier of the stack pane that corresponds to the given data type
         */
        this.constructor.prototype.getStackControlId = function(type) {
            var controlId;
            switch(type) {
            case "Boolean":
                controlId = this._proto.STACK_PANE.BOOLEAN;
                break;
            case "Date":
                controlId = this._proto.STACK_PANE.DATE;
                break;
            case "Integer":
                controlId = this._proto.STACK_PANE.INTEGER;
                break;
            case "Decimal":
                controlId = this._proto.STACK_PANE.DECIMAL;
                break;
            case "Select":
                controlId = this._proto.STACK_PANE.SELECT;
                break;
            default:
                controlId = this._proto.STACK_PANE.STRING;
            }
            return controlId;
        };

        /**
         * @instance
         * @memberof SearchFilter
         * @method updateFilterValue
         * @param {View} view The current parent view
         * @desc Updates the filter with the current value and then publishes the change events
         */
        this.constructor.prototype.updateFilterValue = function(view) {
            bpmext.log.info("SearchFilter.updateFilterValue ENTER >>", this);

            var oldValue = "", changed = false;
            var index = view.ui.getSibling("SearchFilterDataSelector").ui.getIndex();
            var filter = this._instance.filterView.context.binding.get("value");
            var viewData = view.getData();
            var condition = filter.get(index);
            if (!this._instance.scopeFilter && (viewData === null || viewData === undefined || viewData === "")) {
                //reset the filter
                changed = (condition.get("value") !== "");
                condition.set("name", "");
            } else {
                //set the filter item name
                var fieldName = view.ui.getSibling("SearchFilterDataSelector").getData();
                if (fieldName != null) {
                    condition.set("name", fieldName);
                }

                var operator = view.ui.getSibling("FilterOperator");
                if(operator.getSelectedItem()){
                    changed = condition.get("operator") !== operator.getSelectedItem();
                    condition.set("operator", operator.getSelectedItem());
                }

                if (operator !== view) {
                    //set the filter item value
                    oldValue = condition.get("value");
                    changed = (changed || (oldValue !== viewData));
                    condition.set("value", viewData);
                }
                var filterValue = condition.get("value");
                if (filterValue === null || filterValue === undefined || (filterValue === "" && oldValue === "")) {
                    changed = false;
                }
            }
            if(changed){
                //publish filter changed event
                this.publishFilter();
                //only fire the changed event if the operator or the value changed
                bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONCHANGE);
            }
            bpmext.log.info("SearchFilter.updateFilterValue EXIT >>", this);
        };

        /**
         * @instance
         * @memberof SearchFilter
         * @method publishFilter
         * @desc Publishes and event with the current filter
         */
        this.constructor.prototype.publishFilter = function() {
            var x, filterCondition = [], currentFilterCondition = this.getCurrentFilter(this);

            //First remove any filters that do not have a value
            for (x=0; x<currentFilterCondition.length; x++) {
                if (this._instance.scopeFilter || (!!currentFilterCondition[x].value && currentFilterCondition[x].value !== "undefined")) {
                    filterCondition.push(dojo.clone(currentFilterCondition[x]));
                }
            }
            
            for(x = filterCondition.length-1 ; x>=0; x--){
                if(this.getType(filterCondition[x].field)==="Date"){
                    if(filterCondition[x].operator === taskUtils.OPERATOR.EQUALS){
                        var day = 86400000; //24*60*60*1000
                        var currentValue = filterCondition[x].value;
                        var startDate = new Date(new Date(currentValue).getTime()-1);
                        var endDate = new Date(new Date(currentValue).getTime()+day);// from local time 00:00 to 23:59
                        var startDateString = JSON.stringify(new Date(startDate.toUTCString())).replace(/"/g, "");
                        var endDateString = JSON.stringify(new Date(endDate.toUTCString())).replace(/"/g, "");
                        filterCondition[x].operator = taskUtils.OPERATOR.GREATER_THAN;
                        filterCondition[x].value = startDateString;
                        filterCondition.push(wpResources.tasks.OPERATOR.LESS_THAN(filterCondition[x].field, endDateString));
                    }
                }
            }
            if (filterCondition.length > 0) {
                if(this._instance.instanceFilter) {
                    if(!this._instance.scopeFilter && this.isVisible()){
                        if(this.compareFilterConditions(taskUtils.DEFAULT_INSTANCE_FILTER_CONDITION, filterCondition)){
                            taskUtils.EVENTS.SET_INSTANCE_BADGE.publish({text:bpmext.localization.formatMsg("SearchBar", "filterApplied"), clearSS:false});
                        }
                        taskUtils.EVENTS.MODIFY_INSTANCE_FILTER.publish({filterCondition:filterCondition, filterWithoutDateProcess: currentFilterCondition});
                    }
                }else {
                    if(this._instance.scopeFilter){
                        taskUtils.EVENTS.SET_SAVED_SEARCH_SCOPE.publish({filterCondition:filterCondition});
                    }
                    if(this.compareFilterConditions(taskUtils.DEFAULT_FILTER_CONDITION, filterCondition)){
                        taskUtils.EVENTS.SET_TASK_BADGE.publish({text:bpmext.localization.formatMsg("SearchBar", "filterApplied"),clearSS:false});
                    }
                    taskUtils.EVENTS.MODIFY_TASK_FILTER.publish({filterCondition:filterCondition, filterWithoutDateProcess: currentFilterCondition});
                }
            }
        };

        /**
         * @instance
         * @memberof SearchFilter
         * @method updateSelectionValue
         * @param {View} stackView The selection view
         * @param {string} field The current selected field
         * @desc Sets a new option list for the selected field
         */
        this.constructor.prototype.updateSelectionValue = function(field, stackView) {
            var view = stackView.getViewInPane(this._proto.STACK_PANE.SELECT);
            if(view.context.viewid === "selectType") {
                //special handling for priority
                if (view.getItemCount() === 0) {
                    var x;
                    if(field === "taskStatus") {
                        for (x=0; x<this._proto.TASK_STATUS.length; x++) {
                            view.appendItem(this._proto.TASK_STATUS[x].name, this._proto.TASK_STATUS[x].value);
                        }
                    } else if(field === "taskPriority"){
                        for (x=0; x<this._proto.PRIORITY_VALUES.length; x++) {
                            view.appendItem(this._proto.PRIORITY_VALUES[x].name, this._proto.PRIORITY_VALUES[x].value);
                        }
                    } else if(field === "taskActivityType"){
                        for (x=0; x<this._proto.ACTIVITY_TYPE.length; x++) {
                            view.appendItem(this._proto.ACTIVITY_TYPE[x].name, this._proto.ACTIVITY_TYPE[x].value);
                        }
                    } else if(field === "instanceStatus"){
                        for (x=0; x<this._proto.INSTANCE_STATUS.length; x++) {
                            view.appendItem(this._proto.INSTANCE_STATUS[x].name, this._proto.INSTANCE_STATUS[x].value);
                        }
                    }
                    else if(field === "type"){
                        for (x=0; x<this._proto.INSTANCE_TYPE.length; x++) {
                            view.appendItem(this._proto.INSTANCE_TYPE[x].name, this._proto.INSTANCE_TYPE[x].value);
                        }
                        if (this._instance.isCaseEnabled) {
                            view.appendItem("Case", bpmext.localization.formatMsg("searchFilter", "cases"));
                        }
                    }
                    else if(field === "caseType") {
                        for (x = 0; x < this._instance.allCaseTypes.length; x++) {
                            view.appendItem(this._instance.allCaseTypes[x].casetypeSymbolicName, this._instance.allCaseTypes[x].display);
                        }
                    }
                    else if(field === "projectFilter"){
                        for (var projectObj in this._instance.allProjects) {
                            view.appendItem(projectObj, this._instance.allProjects[projectObj]);
                        }
                    }
                    else if(field === "caseStage"){
                        for (var caseStageObj in this._instance.allCaseStages) {
                            view.appendItem(caseStageObj, this._instance.allCaseStages[caseStageObj]);
                        }
                    }
                }
            }
        };
        /**
         * @instance
         * @memberof SearchFilter
         * @method updateOperator
         * @param {View} operatorCV The filter item operator view
         * @param {string} type The operator type.  For example, Date, Integer or String
         * @param {string} currentOperator The current filter item operator
         * @desc Sets a new operator for the filter item
         */
        this.constructor.prototype.updateOperator = function(operatorCV, type, currentOperator) {
                if (operatorCV._instance.operatorType !== type) {
                    var isOperatorCV = operatorCV.ui.getSibling("isOperator");
                    operatorCV._instance.operatorType = type;
                    operatorCV.clearItems();
                    var typeList;
                    if (type === "Boolean" || type === "Select") {
                        operatorCV.setVisible(false, true);
                        isOperatorCV.setVisible(true);
                        //reset the operator for boolean
                        var currentFilter = this._instance.filterView.context.binding.get("value").get(operatorCV.ui.getIndex());
                        if (currentFilter) {
                            currentFilter.set("operator", "");
                        }
                    } else {
                        switch(type) {
                            case "Date":
                                typeList = this._proto.DATE_OPERATOR;
                                break;
                            case "Integer":
                            case "Decimal":
                                typeList = this._proto.NUMBER_OPERATOR;
                                break;
                            case "Search":
                                typeList = this._proto.SEARCHABLE_STRING_OPERATOR;
                                break;
                            default:
                                typeList = this._proto.STRING_OPERATOR;
                        }

                        var x;
                        for (x=0; x<typeList.length; x++) {
                            operatorCV.appendItem(typeList[x].name, typeList[x].value);
                        }
                        isOperatorCV.setVisible(false, true);
                        operatorCV.setVisible(true);
                        this._instance.operatorListenerTriggered = true;
                        if (this._instance.scopeFilter) {
                            operatorCV.setSelectedItem(currentOperator);
                        }else if (currentOperator) {
                            operatorCV.setSelectedItem(currentOperator);
                        } else {
                            operatorCV.setSelectedItemAt(0);
                        }
                    }
                }
        };

        /**
         * @instance
         * @memberof SearchFilter
         * @method deleteFilter
         * @param {int} index The index of the filter item to delete
         * @desc Deletes the filter item at the given index
         */
        this.constructor.prototype.deleteFilter = function(index) {
            bpmext.log.info("SearchFilter.deleteFilter ENTER >>", this);
            bpmext.log.debug("SearchFilter.deleteFilter Deleting filter at: " + index, this);

            var view = this;

            var filter = view._instance.filterView.context.binding.get("value");
            var x, newFilter = [];
            var refresh = false;

            view.context.element.onkeypress = function(event) {
                if (event.key === " " || event.key === "Spacebar") {
                    event.preventDefault();
                }
            };

            //First construct a new filter representation
            if (filter && filter.length() > 0) {
                for (x=0; x<filter.length(); x++) {
                    if (x === index) {
                        if (filter.get(x).get("value") !== "") {
                            refresh = true;
                        }
                        continue;
                    }
                    newFilter.push({name: filter.get(x).get("name"), operator: filter.get(x).get("operator"), value: filter.get(x).get("value")});
                }

                setTimeout(function() {
                    //delay the setting of the new filter to allow the event execution to complete
                    view._instance._filtersLeftToProcess = newFilter.length;
                    view._instance.filterView.context.binding.set("value", newFilter);
                },0);

                if (refresh) {
                    setTimeout(function() {
                        //publish filter changed event
                        view.publishFilter();

                        //call the change event
                        bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONCHANGE);
                    }, 0);
                }
            }

            bpmext.log.info("SearchFilter.deleteFilter EXIT >>", this);
        };

        /**
         * @instance
         * @memberof SearchFilter
         * @method addFilter
         * @param {View} addView The add filter view icon that was clicked
         * @desc Adds an empty filter item
         */
        this.constructor.prototype.addFilter = function(addView) {
            bpmext.log.info("SearchFilter.addFilter ENTER >>", this);

            addView.context.element.onkeypress = function(event) {
                if (event.key === " " || event.key === "Spacebar") {
                    event.preventDefault();
                }
            };

            var x, name;
            for (x=0; x<=addView.ui.getIndex(); x++) {
                //check if it ends in a index e.g. [2]
                name = addView.ui.getAbsoluteName();
                if (/\[\d+\]$/.test(name)) {
                    name = name.substring(0, name.lastIndexOf("["));
                }
                bpmext.ui.getView(name + "[" + x + "]").setVisible(false, false);
            }
            //set the new empty filter item
            this._instance.filterView.context.binding.get("value").add({name:"",value:""});

            bpmext.log.info("SearchFilter.addFilter EXIT >>", this);
        };

        /**
         * @instance
         * @memberof SearchFilter
         * @method resetName
         * @param {View} view The current filter item
         * @desc Sets the filter item name at the current filter location
         */
        this.constructor.prototype.resetName = function(view) {
            if (view.getItemCount() === 0) {
                //initialize
                this.populateSelectorWithColumnList(view, this);
            }
            var filter = this._instance.filterView.context.binding.get("value");
            var item = filter.get(view.ui.getIndex());
            if (item.get("name")  && view.ui.getIndex() > 0) {//First field is always interaction so no need to set
                view.setSelectedItem(item.get("name"));
            } else if(item.get("field") && view.ui.getIndex() > 0){
                view.setSelectedItem(item.get("field"));
            }
        };

        /**
         * @instance
         * @memberof SearchFilter
         * @method resetOperator
         * @param {View} view The current filter item
         * @desc Sets the filter item operator at the current filter location
         */
        this.constructor.prototype.resetOperator = function(view) {
            var filter = this._instance.filterView.context.binding.get("value");
            var operator = filter.get(view.ui.getIndex()).get("operator");
            if (operator) {
                view.setData(operator);
            }
        };

        /**
         * @instance
         * @memberof SearchFilter
         * @method resetValue
         * @param {View} view The current filter item
         * @desc Sets the filter item value at the current filter location
         */
        this.constructor.prototype.resetValue = function(view) {
            var input;
            var filter = this._instance.filterView.context.binding.get("value");
            var item = filter.get(view.ui.getIndex());
            if (item && item.get("value")!== "" && view.isVisible()) {
                view.setData(item.get("value"));
            }
            if(view.context.viewid === "boolType") {
                //special handling for booleans
                if (view.getItemCount() === 0) {
                    var x;
                    for (x=0; x<this._proto.BOOLEAN_VALUES.length; x++) {
                        view.appendItem(this._proto.BOOLEAN_VALUES[x].name, this._proto.BOOLEAN_VALUES[x].value);
                    }
                }
            }

            //turn off the autocomplete
            input = view.context.element.querySelector("input");
            if (input) {
                domAttr.set(input, "autocomplete", "off");
            }

        };

        /**
         * @instance
         * @memberof SearchFilter
         * @method setSelection
         * @param {View} selectView The selected item to filter on
         * @desc Sets the filter item value based on the current selection
         */
        this.constructor.prototype.setSelection = function(selectView) {
            bpmext.log.info("SearchFilter.setSelection ENTER >>", this);
            var field = selectView.getData(), operatorCV = selectView.ui.getSibling("FilterOperator");
            if (field) {
                var stack  = selectView.ui.getSibling("Stack1");
                var type = this.getType(field);

                var filter = this._instance.filterView.context.binding.get("value");
                var currentFilter = filter.get(selectView.ui.getIndex());

                //show the appropriate view based on the data type of the filter item
                var pane = this.getStackControlId(type);
                if (this._instance._filtersLeftToProcess > 0) {
                    //if this number is greater than zero, it means that the view is still
                    //building the filters after the binding has changed
                    this._instance._filtersLeftToProcess--;
                } else {
                    if (pane !== undefined) {
                        var view = stack.getViewInPane(pane);
                        var oldValue = currentFilter.get("value");
                        var data = view.getData();
                        if ((oldValue !== data && oldValue !== "") || (data !== undefined && data !== null && data !== "") || (view.context.viewid === "selectType" && view.getItemCount() > 0)) {
                            //clear the value
                            currentFilter.set("value", "");
                            view.setData("");
                            if(view.context.viewid === "selectType"){
                                view.clearItems();
                            }
                            this.publishFilter();
                        }
                    }
                }
                stack.setCurrentPane(pane);

                //update operator
                this.updateOperator(operatorCV, type, currentFilter.get("operator"));
                // remove isNot operator for createdBy as the users rest api didn't support that operator
                if(field === "createdBy") {
                    operatorCV.removeItemAt(1);
                }

                //update value selection
                this.updateSelectionValue(field, selectView.ui.getSibling("Stack1"));

                this._proto._setInputSize(this, stack.getViewInPane(pane));

                this._instance.listenerTriggered = false;
            }
            bpmext.log.info("SearchFilter.setSelection EXIT >>", this);
        };


        /**
         * @instance
         * @memberof SearchFilter
         * @method resetFilter
         * @param {View} selectView The wrapper view
         * @desc Clear the entire filter and publish an event with an empty filter
         */
        this.constructor.prototype.resetFilter = function(view) {
            bpmext.log.info("SearchFilter.resetFilter ENTER >>", this);
            if(view._instance.scopeFilter){
                view._instance.filterView.context.binding.set("value",[]);
                this.publishFilter();
            }else{
                var initialFilter;
                if(view._instance.instanceFilter) {
                    initialFilter = taskUtils.DEFAULT_INSTANCE_FILTER_CONDITION;
                } else{
                    initialFilter = taskUtils.DEFAULT_FILTER_CONDITION;
                }
                view._instance._filtersLeftToProcess = initialFilter.length;
                view._instance.filterView.context.binding.set("value", initialFilter);
                this.publishFilter();
            }
            bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONCHANGE);
            bpmext.log.info("SearchFilter.resetFilter EXIT >>", this);
        };

        /**
         * @instance
         * @memberof SearchFilter
         * @method getCurrentFilter
         * @return {NameValuePair[]} The filter
         * @desc Returns the current filter
         */
        this.constructor.prototype.getCurrentFilter = function getCurrentFilter() {
            return this._proto._getCurrentFilter(this);
        };

        /**
         * @instance
         * @memberof SearchFilter
         * @method setCurrentFilter
         * @param {NameValuePair[]} filter The filter to set
         * @desc Sets the current filter
         */
        this.constructor.prototype.setCurrentFilter = function setCurrentFilter(filter) {
            var view = this;
            if(filter){
                for(var x = 0; x < filter.length; x ++){
                    if(!filter[x].name){
                        filter[x].name = filter[x].field;
                    }
                }
                setTimeout(function() {
                    view._instance._filtersLeftToProcess = filter.length;
                    view._instance.filterView.context.binding.set("value", filter);
                },0);
            }
        };

        /**
         * @instance
         * @memberof SearchFilter
         * @method showFilter
         * @param {View} filter The wrapper view
         * @desc Shows the filter and changes the label
         */
        this.constructor.prototype.showFilter = function showFilter(view) {
            view._instance.filterView.setVisible(true);
            view.setVisible(true);
        };

        /**
         * @instance
         * @memberof SearchFilter
         * @method showScopeFilter
         * @desc Shows the scope filter
         */
        this.constructor.prototype.showScopeFilter = function showScopeFilter() {
            this.setVisible(true,true);
            this._instance.filterView.context.binding.set("value",[{name:"bpdName",operator:"Equals" ,value:""}]);
        };

        /**
         * @instance
         * @memberof SearchFilter
         * @method hideFilter
         * @param {View} filter The wrapper view
         * @desc Hides the filter and changes the label
         */
        this.constructor.prototype.hideFilter = function hideFilter(view) {
            view._instance.filterView.setVisible(false, true);
            view.setVisible(false, true);
        };

        /**
         * @instance
         * @memberof SearchFilter
         * @method removeOnload
         * @param {View} button The remove button icon view
         * @desc Determines if the remove button should be shown
         */
        this.constructor.prototype.removeOnload = function removeOnload(button) {
            bpmext.log.info("SearchFilter.removeOnload ENTER >>", this);
            domAttr.set(button.context.element.querySelector(".SPARKIcon.btn"), "aria-label", bpmext.localization.formatMsg("searchFilter", "removeFilter"));
            if (button.ui.getIndex() === 0) {
                button.setVisible(false, true);
            }
        };

        /**
         * @instance
         * @memberof SearchFilter
         * @method addOnLoad
         * @param {View} button The add button icon view
         * @desc Determines if the add button should be shown
         */
        this.constructor.prototype.addOnLoad = function addOnLoad(button) {
            bpmext.log.info("SearchFilter.addOnLoad ENTER >>", this);
            domAttr.set(button.context.element.querySelector(".SPARKIcon.btn"), "aria-label", bpmext.localization.formatMsg("searchFilter", "addFilter"));
            if (button.ui.getCount() > 1) {
                if (button.ui.getIndex() < button.ui.getCount() -1) {
                    button.setVisible(false, true);
                }
                var singleSelectCV = this._instance.filterView.ui.getChild("Horizontal_Layout1", button.ui.getIndex()+1).ui.getChild("SearchFilterDataSelector");
                if (singleSelectCV) {
                    var selectElem = singleSelectCV.context.element.querySelector("input");
                    selectElem.focus();
                }

            } else {
                button.context.element.firstElementChild.focus();
            }
        };

        /**
         * @instance
         * @memberof SearchFilter
         * @method compareFilterConditions
         * @param {Array} filter1 The filter you want to compare
         * @param {Array} filter2 The filter you want to compare
         * @desc Compares the filter to determine if it has been modified
         */
        this.constructor.prototype.compareFilterConditions = function compareFilterConditions(filter1, filter2) {
            if(filter1.length!==filter2.length){
                return true;
            }else{
                for(var x=0;x<filter2.length;x++){
                    for(var y=0;y<filter1.length;y++){
                        var f1 = filter1[y], f2 = filter2[x];
                        if(f2.field===f1.name){
                            if(f2.operator !== f1.operator){
                                return true;
                            }else if(this.getType(f1.name)==="Date"){
                                if(new Date(f2.value).toDateString() !== new Date(f1.value).toDateString()){
                                    return true;
                                }
                            }else if (f2.value !== f1.value){
                                return true;
                            }
                            break;
                        }
                    }
                }
                return false;
            }
        };

        /**
         * @instance
         * @memberof SearchFilter
         * @method cleanUp
         * @desc Performs any clean up that is needed when the filter is closed.
         */
        this.constructor.prototype.cleanUp = function cleanUp() {
            var x, item;
            var dataSelector = bpmext.ui.getView("SearchFilterDataSelector", this);
            if (dataSelector) {
                for (x=0; x < dataSelector.ui.getCount(); x++) {
                    item = this.ui.get(this.ui.getAbsoluteName() + "/SearchFilterDataSelector", x);
                    if (item && item.hideDropdown) {
                        item.hideDropdown();
                    }
                }

            }
        };

        /**
         * @instance
         * @memberof SearchFilter
         * @method setBusinessDate
         * @desc 
         */
        this.constructor.prototype.setBusinessData = function setBusinessData(data) {
            this._instance.businessData = data;
        };

        /*
        Coach NG Lifecycle methods *************************************************************
        */
        this.constructor.prototype.load = function ()
        {
            bpmext.log.info("SearchFilter.load ENTER >>", this);
            var view = this, opts = this.context.options;

            if (!opts.instanceFilter) {
                bpmext.ui.substituteConfigOption(this, "instanceFilter", false);
            }

            if (!opts.taskFilters) {
                bpmext.ui.substituteConfigOption(this, "taskFilters", null);
            }

            if (!opts.instanceFilters) {
                bpmext.ui.substituteConfigOption(this, "instanceFilters", null);
            }

            if (!opts.scopeFilter) {
                bpmext.ui.substituteConfigOption(this, "scopeFilter", false);
            }
            this._instance.scopeFilter = opts.scopeFilter.get("value");

            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONCHANGE);
            this._instance.instanceFilter = opts.instanceFilter.get("value");
            this._instance.filterView = bpmext.ui.getContainer("TLFilter", this);
            this._instance.filterView.context.binding = bpmext.ui.substituteObject(this._instance.filterView);

            this._instance.columnList = [];
            this._instance.typeMap = {};

            var filters;
            if(this._instance.instanceFilter) {
                if(opts.instanceFilters.get("value") && opts.instanceFilters.get("value").length() > 0) {
                    filters = opts.instanceFilters.get("value").toJSObject().items;
                } else {
                    filters = [{name: "interaction", value: wpResources.processes.INTERACTION.ACTIVE, operator: "Equals"}];
                }
                this._proto._checkCaseOptions(view);
                taskUtils.EVENTS.CASETYPE_READY.subscribe(function(eventName, eventData) {
                    this._proto._setCaseOptions(view, eventData);
                }, this);
            } else if(opts.scopeFilter.get("value")) {
                filters = [];
            } else {
                if(opts.taskFilters.get("value") && opts.taskFilters.get("value").length() > 0) {
                    var isPXServer = view.context.isWorkflowPXServer && view.context.isWorkflowPXServer() === true;
                    var defaultScopeFilters = isPXServer ? taskUtils.DEFAULT_PX_SCOPE_FILTERS : taskUtils.DEFAULT_SCOPE_FILTERS;
                    filters = dojo.clone(opts.taskFilters.get("value").items);
                    if(filters){
                        for(var x=0; x<filters.length; x++){
                            if(defaultScopeFilters.indexOf(filters[x].field)>-1){
                                filters.splice(x);
                            }
                        }
                    }
                } else {
                    filters = taskUtils.DEFAULT_FILTER_CONDITION;
                }
            }
            this.setCurrentFilter(filters);

            this._instance.typeMap["interaction"] = "Select";
            //Get the System and Business data
            view._proto._getData(view);
            view.showFilter(view);
            this.loadView(this);

            bpmext.log.info("SearchFilter.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try
            {
                utilities.handleVisibility(this.context);
            }
            catch (e)
            {
                //{#feature: US-1330 Added RT localization}
                //bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if(e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    //bpmext.log.error("  Call stack: " + e.stack);
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                }
            }
        };

        this.constructor.prototype.change = function ()
        {
        };

        this.constructor.prototype.unload = function ()
        {
            bpmext.ui.unloadView(this);
        };
    }
};
