/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof TaskList
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof TaskList
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof TaskList
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof TaskList
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof TaskList
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof TaskList
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof TaskList
 * @method triggerFormulaUpdates
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>This event is fired whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On Task Launched:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when a task is launched from the Task List.</td>
 *               </tr>
 *           </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">task {object}</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">task data</td>
 *               </tr>
 *       </table>
 *     </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On Task Action:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when a task action is invoked from the actions menu.</td>
 *               </tr>
 * </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">action {object}</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">action data</td>
 *               </tr>
 *           </table>
 *       </td>
 *   </tr>
 * </table>
 */
workplace_control_InitTaskList = function (utilities, lang, taskUtils, resourceUtils, wpResources, domAttr, domConstruct, domClass, all)
{
    "use strict";
    this._instance =
    {
        taskCache: new Map()
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            //Event constants
            EVT_ONTASK_LAUNCHED : "eventON_TASK_LAUNCHED",
            EVT_ONMODIFY_TASK_ACTION : "eventON_MODIFY_TASK_ACTION",
            EVT_ONINSTANCE_LAUNCHED: "eventON_INSTANCE_LAUNCHED",
            EVT_ONEXTERNAL_FETCH: "eventON_EXTERNAL_FETCH",

            EMPTY_TASKS_TABLE_TEXT: {
                header: bpmext.localization.formatMsg("controlTaskList", "noTasksHeader"),
                subHeader: bpmext.localization.formatMsg("controlTaskList", "noTasksSubheader")
            },

            _excludeColumns: ["KIND"],

            _translate: function _translate() {
                var args = [].slice.call(arguments);
                args.unshift("controlTaskList");
                return bpmext.localization.formatMsg.apply(null, args);
            },

            _setDefaultSearchParameters: function _setDefaultSearchParameters (view, search) {
                var conditions = [{field:"interaction", operator:"Equals", value:search.interaction}], selectedCols = [], x;
                if (search.conditions) {
                    for(x = 0; x < search.conditions.length; x++) {
                        var val = search.conditions[x];
                        conditions.push({field: val.field, operator: val.operator, value: val.value}); 
                    }
                }
                if(search.fields) { 
                    var businessDataList = {};
                    // double check if business data still exists in current business data list
                    for(x = 0; x < search.fields.length; x++) {
                        var val = search.fields[x], origins ="";
                        if(val.indexOf("@")!==-1){ 
                            var businessDataField = val.split("@")[0];
                            var businessDataAlias = "";
                            for (var y =0; y < search.aliases.length; y++) {
                                if(search.aliases[y].field === businessDataField) { 
                                    businessDataAlias = search.aliases[y].alias;
                                    break;
                                }// get business data alias
                            }
                            for (y = 0; y < view._instance.businessData.length; y++) {
                                if(search.fields[x] == view._instance.businessData[y].name+"@"+view._instance.businessData[y].type) {
                                    origins = view._instance.businessData[y].origins;
                                    break;
                                }
                            }
                            if (businessDataField && businessDataAlias) {
                                selectedCols.push({name: businessDataField, value: businessDataAlias, origins:origins, isBusinessData: true});
                            }
                        } else {
                            selectedCols.push({name: val, value: taskUtils.getLabelFromTaskProperty(val)});
                        }
                    }
                }
                view._instance.selectedCols = selectedCols;
                view._instance.filterConditions = conditions;
            },

            _getCurrentUserInfo: function _getCurrentUserInfo (view) {
                // refresh user's information
                return wpResources.user.get().then(function(currentUser) {
                    view._instance.user = {
                        currentUser: currentUser.userName,
                        currentUserMemberships: currentUser.memberships
                    };
                    view._instance.isNextTaskMode = currentUser.showNextTaskDashboard;
                    view._instance.autoClaimNextTask = currentUser.autoClaimNextTask;
                    // if a defaultNextTaskSavedSearch is defined, load the specified saved searches in next task dashboard, otherwise use the default one
                    if (currentUser.showNextTaskDashboard && currentUser.defaultNextTaskSavedSearch) {
                        view.loadDefaultSavedSearch(currentUser.defaultNextTaskSavedSearch);
                    } else {
                        view.refreshTaskList();
                    } 
                    // hide search filter if auto-claim next task to prevent cherry picking other task
                    if (view._instance.isNextTaskMode && view._instance.autoClaimNextTask) {
                    	view._instance.savedSearchBuilderLauncher.setVisible(false, true);
                    	view._instance.addWorkflowButton.setVisible(false, true);
                    	taskUtils.EVENTS.DISABLE_NAV_LINK.publish();
                    }
                });
            },
            
            _autoClaimNextTask: function _autoClaimNextTask (view, task) {
                view._instance.taskResource.get({ tkiid: task["TASK.TKIID"], includeURL: true, systemID: task.systemID }).then(function(task) {
                    if (!task.message) {
                        task.systemID = task.systemID;
                        if((taskUtils.isUserTask(task) || view._instance.portalConfig.enableSystemTaskLaunchByPortal)) {
                            taskUtils.EVENTS.TASK_LAUNCHED.publish({task: task, systemData: view._instance.systemData});
                        } else {
                            taskUtils.publishError(bpmext.localization.formatMsg("controlTaskList", "systemTaskLaunchError"));
                        }
                    }
                }, function error (error) {
                	bpmext.log.error(error);
                    taskUtils.EVENTS.CREATE_TOAST.publish({
                        title: bpmext.localization.formatMsg("notifications", "notificationErrorTitle"),
                        text: bpmext.localization.formatMsg("Errors", "loadTaskDetails"),
                        style: "D"
                    });
                });
            },

            /* loads the task list based on the current binding */
            _loadTasks: function _loadTasks(tasks) {
                bpmext.log.info("TaskList._loadTasks ENTER >>");

                var view = this;

                if (!!tasks && !!tasks.items && !!tasks.items.length > 0) {
                    bpmext.log.info("TaskList._loadTasks LOG >> Tasks to display: " + tasks.items.length, view);

                    view._instance.respUpdateHistory = {
                        card: false,
                        table: false
                    };

                    //set visibility
                    view._instance.basicTasksPanel.setVisible(true);
                    view._instance.sortBy.setVisible(true, true);
                    view._instance.noTasksToDisplayView.setVisible(false, true);

                    //Create the column definition for the table(s) based on the selected columns
                    var currentCols = view._proto._formulateTaskTableColumns(view, tasks);
                    if(!view._instance.updatedTaskCols){
                        view._instance.taskTable.setColumns(currentCols);
                        view._instance.updatedTaskCols = true;
                    }
                    view._instance.taskTable.setOption("showTableStats", true);

                    if (tasks.items) {
                        if (!view._instance.tasks || JSON.stringify(tasks.items) !== JSON.stringify(view._instance.tasks.items)) {
                            view._proto._updateTaskCache(view, tasks.items);
                        }
                        // set disableSelection attribute
                        tasks.items.forEach(function(task) {
                        	if (taskUtils.isTaskCompleted(task)) {
                        		task.disableSelection = true;
                        	}
                        }); 
                        view._instance.tasks = { attributes: tasks.attributeInfo, items: tasks.items };
                        
                        //auto claim the task if in next task dashboard
                        if (view._instance.isNextTaskMode && view._instance.autoClaimNextTask) {
                            this._proto._autoClaimNextTask(view, tasks.items[0]);
                        } 
                    } else {
                        view._instance.tasks = { attributes: [], items: [] };
                        view._instance.tasksLabel.setVisible(false, true);
                    }
                    if(view._instance.ssLaunched){
                        view._instance.ssLaunched = false;
                        taskUtils.EVENTS.UPDATE_SORT_FILTER.publish();
                    }
                    view._proto._updateResponsiveness(view);
                    if(view._instance.searchBar.isExpanded()){
                        view._instance.searchBar.updatePosition();
                    }
                    if (view._instance.batchEditBtn.isVisible()) {
                        view._instance.taskTable.setAllRecordsSelected(false);
                    }

                    // Update initial sorting icon
                    if(view._instance.currentSort == null){
                        if(view.context.options.taskSortBy.get("value")) {
                            var sortByValue = view.context.options.taskSortBy.get("value");
                            if (sortByValue && sortByValue.name !== "") {
                                var field = sortByValue.name;
                                var ascSort = sortByValue.value === "descending" ? false : sortByValue.value === "ascending" ? true : "none";
                                if (ascSort !== "none") {
                                    // Matching attribute name
                                    var srcAttrName, srcAttribute, srcAttb;
                                    ((this._instance.tasks && this._instance.tasks.attributes) || []).forEach(function (attribute) {
                                        srcAttrName = attribute.name;
                                        srcAttb = (attribute.sourceAttribute && attribute.sourceAttribute.indexOf(".")==0) ? attribute.sourceAttribute.substring(1) : attribute.sourceAttribute;
                                        if (srcAttb === field) {
                                            srcAttribute = srcAttrName;
                                        }
                                    });
                                    // Inverse sorting arrow for priority
                                    if (srcAttribute === "PRIORITY") {
                                        ascSort = !ascSort;
                                    }
                                    view.updateSortIcons(view._instance.taskTable, srcAttribute, ascSort);
                                    taskUtils.EVENTS.SET_TASK_BADGE.publish({text:bpmext.localization.formatMsg("SearchBar", "filterApplied"),clearSS:false});
                                }
                            }
                        }
                    }

                } else {
                    //show the NoTasks view and hide the others
                    view._instance.basicTasksPanel.setVisible(false, true);
                    view._instance.sortBy.setVisible(false, true);
                    view._instance.sortByOrder.setVisible(false, true);
                    view._instance.noTasksToDisplayView.setVisible(true, true);
                    view._instance.loadingTable.setVisible(false, true);
                    view._instance.taskTable.setVisible(false, true);
                    bpmext.log.info("TaskList._loadTasks LOG >> No tasks to display.", view);
                }

                // clear all previous selected rows
                if (view._instance.batchEditBtn.isVisible()) {
                    view._instance.batchEditBtn.setEnabled(false, true);
                }

                bpmext.log.info("TaskList._loadTasks EXIT >>", view);
            },

            _formulateTaskTableColumns: function (view, taskObj) {
                var selectedCols = view._instance.selectedCols || [];
                var skippedCols = view._instance.excludeColumns || view._proto._excludeColumns;
                var showActionMenu = !view.context.options.hideActionMenu.get("value");
                var columnWidths = view._instance.columnWidths || [];

                var i, attrName, col, currentCols = [], displayName;
                var attributes = taskObj.attributeInfo;
                selectedCols.forEach(function (column) {
                    for (i = 0; i < attributes.length; i++) {
                        // Skipping exclusive columns
                        if (skippedCols.indexOf(attributes[i].name) > -1) {
                            continue;
                        }

                        //Instance status returns two attributes, instance state and instance status
                        //we are only interested in instance status, so skip state
                        if (attributes[i].name === "PI_STATE") {
                            continue;
                        }

                        //use just the suffix as the attribute name
                        attrName = attributes[i].sourceAttribute;
                        attrName = attrName ? attrName.substring((attrName.lastIndexOf(".")+1)) : null;

                        if (!!attrName && column.name === attrName) {
                            if (attrName === wpResources.searches.METADATA.TASK_STATUS ||
                                attrName === wpResources.searches.METADATA.INSTANCE_STATUS) {
                                col = {
                                    visibility: true,
                                    sortable: false,
                                    renderAs: "C",
                                    label: bpmext.localization.formatMsg("controlTaskList", attrName),
                                    dataElementName: attributes[i].name,
                                    name: attrName,
                                    rearrangeColumn: true
                                };
                            } else if (attributes[i].name === "TAD_DISPLAY_NAME" || attributes[i].name === "displayName" || attributes[i].name === "PRIORITY" || attributes[i].name === "priority" || attributes[i].name === "TASK_ACTIVITY_TYPE" || attributes[i].name === "taskActivityType") {
                                col = {
                                    visibility: true,
                                    sortable: true,
                                    renderAs: "C",
                                    label: taskUtils.getLabelFromTaskProperty(attrName),
                                    dataElementName: attributes[i].name,
                                    name: attrName,
                                    rearrangeColumn: true
                                };
                            } else {
                            	displayName = taskUtils.getLabelFromTaskProperty(attrName);
                            	if(column.isBusinessData) {
                                    if(column.value.indexOf("<") != -1) {
                                        displayName = column.value.substring(0, column.value.indexOf("<"));
                                        
                                    }else{
                                        displayName = column.value;
                                    }
                                } 
                                col = {
                                    visibility: true,
                                    sortable: true,
                                    renderAs: "H",
                                    dataElementName: attributes[i].name,
                                    label: displayName,
                                    name: attrName,
                                    rearrangeColumn: true
                                };

                                switch(attributes[i].type) {
                                    case "BOOLEAN":
                                        col.type = taskUtils.COLUMN_TYPES.BOOLEAN;
                                        break;
                                    case "TIMESTAMP":
                                        col.type = taskUtils.COLUMN_TYPES.TIMESTAMP;
                                        col.options = {dateOptions: {selector: "date", formatLength: "medium"}};
                                        break;
                                    case "NUMBER":
                                    case "DECIMAL":
                                        var isDecimal = taskObj.items.some(function(taskItem){
                                            return taskItem[attributes[i].name] && taskItem[attributes[i].name] % 1 !== 0;
                                        });
                                        col.type = isDecimal ? taskUtils.COLUMN_TYPES.DECIMAL : taskUtils.COLUMN_TYPES.NUMBER;
                                        break;
                                    case "STRING":
                                    default:
                                        if(column.isBusinessData) {
                                            col.renderAs = "C";
                                        }
                                        col.type = taskUtils.COLUMN_TYPES.STRING;
                                }
                            }

                            currentCols.push(col);
                            break;
                        }
                    }

                    // Add width for persistance
                    for(var ndx = 0; ndx < columnWidths.length; ndx++){
                        if(columnWidths[ndx].name === column.name){
                            col.width = columnWidths[ndx].value;
                            columnWidths.splice(ndx, 1);
                            break;
                        }
                    }
                });

                //add actions picker
                if (showActionMenu) {
                    currentCols.push({
                        visibility: true,
                        sortable: false,
                        renderAs: "C",
                        label: " ",
                        dataElementName: "actionMenu",
                        rearrangeColumn: false
                    });
                    if(columnWidths && columnWidths.length){
                        currentCols[currentCols.length-1].width = columnWidths[0].value;
                    }
                }

                return currentCols;
            },

            _computeTaskStatistics: function _computeTaskStatistics(tasks) {
                return tasks && tasks.reduce && tasks.reduce(function(statistics, task) {
                    var taskStatus = taskUtils.getStatusClassName(task);
                    if (taskStatus === "completedTask") {
                        statistics.completed += 1;
                    } else if (taskStatus === "overdueTask") {
                        statistics.overdue += 1;
                    } else if (taskStatus === "atRiskTask") {
                        statistics.atRisk += 1;
                    } else if (taskStatus === "onTrackTask") {
                        statistics.onTrack += 1;
                    }
                    return statistics;
                }, {total: tasks.length, completed: 0, onTrack: 0, atRisk: 0, overdue: 0});
            },

            _updateResponsiveness: function _updateResponsiveness(view) {
                var responsiveMode = view.context.options.responsiveMode.get("value");
                var respUpdateHistory = view._instance.respUpdateHistory;

                // block the case that change responsiveness happens before load tasks
                if (!respUpdateHistory) {
                    return;
                }

                var tasks = view._instance.tasks;
                var items = (tasks && tasks.items) || [];

                if (responsiveMode === "SMALL" && !respUpdateHistory.card) {
                    view._instance.taskCards.setViewData(items, true);
                    view._instance.loadingTable.setVisible(false, true);
                    view._instance.taskTable.setVisible(false, true);
                    view._instance.respUpdateHistory.table = false;
                    view._instance.respUpdateHistory.card = true;
                } else if (!respUpdateHistory.table) {
                    view._instance.taskTable.setViewData(items, true);
                    view._instance.loadingTable.setVisible(false, true);
                    view._instance.taskTable.setVisible(true, true);
                    view._instance.respUpdateHistory.table = true;
                    view._instance.respUpdateHistory.card = false;
                }
            },

            _errorLoadTasks: function _errorLoadTasks(view, data) {
                bpmext.log.error("TaskList._errorLoadTasks ERROR >> There was an error loading the tasks (data): " + data, view);

                //show the NoTasks view and hide the others
                view._instance.basicTasksPanel.setVisible(false, true);
                view._instance.sortBy.setVisible(false, true);
                view._instance.sortByOrder.setVisible(false, true);
                view._instance.noTasksToDisplayView.setVisible(true, true);
                view._instance.paginationView.setVisible(false, true);
                view._instance.loadingTable.setVisible(false, true);
                view._instance.taskTable.setVisible(false, true);

                if (data && data.response && data.response.data && data.response.data.status === 500 && data.response.data.errorNumber === "CWMFS4021E") {
                    view._instance.savedSearchBuilderLauncher.setEnabled(false, true);
                    view._instance.addWorkflowButton.setEnabled(false, true);
                    view._instance.searchBar.setEnabled(false, true);
                    view._instance.batchEditBtn.setEnabled(false, true);
                }

                taskUtils.EVENTS.CREATE_TOAST.publish({
                    title: bpmext.localization.formatMsg("notifications", "notificationErrorTitle"), 
                    text: bpmext.localization.formatMsg("Errors", "loadTasks"),
                    style: "D"
                });
            },

            _setTaskLaunchEvent: function _setTaskLaunchEvent(view) {
                var launchEvent = view.context.options.taskLaunchEvent.get("value") || "TASK_BEFORE_LAUNCH";
                view._instance.claimedTaskModal.setTargetEvents([taskUtils.EVENTS[launchEvent]]);
                view._instance.actionsMenu.settingTaskLaunchingEvents(taskUtils.EVENTS[launchEvent]);
            },

            _launchTask: function _launchTask(view, data) {
                bpmext.log.info("TaskList._launchTask LOG >> (data): " + data, view);
                bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONTASK_LAUNCHED, data);

                var launchEvent = view.context.options.taskLaunchEvent.get("value") || "TASK_BEFORE_LAUNCH", 
                	origin = view.ui.getParent().context? view.ui.getParent().context.viewid: null;
                taskUtils.EVENTS[launchEvent].publish({task: data, systemData: view._instance.systemData, skipClaim: view.context.options.skipClaimForTasks.get("value"), origin: origin});
            },

            _launchInstance: function _launchInstance(view, data) {
                bpmext.log.info("TaskList._launchInstance LOG >> (data): " + data, view);

                // prevent multiple launch action
                if (view._instance.launchInstanceLock) {
                    return;
                }

                bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONINSTANCE_LAUNCHED, data);

                if (!data.name) {
                    view._instance.launchInstanceLock = true;
                    this._fetchInstance(data).then(function (instance) {
                        view._instance.launchInstanceLock = false;
                        data.name = instance.name;
                        data.isWorkstream = data.isWorkstream || taskUtils.isWorkstreamProcess(instance);
                        data.isWorkstream = (data.isWorkstream || instance.bpdName === "Configurable Workstream" || instance.processName === "Configurable Workstream") ? true : data.isWorkstream;
                        taskUtils.EVENTS.BEFORE_VIEW_INSTANCE.publish(data);
                    });
                } else {
                    taskUtils.EVENTS.BEFORE_VIEW_INSTANCE.publish(data);
                }
            },

            /**
             * @param {object} data - the row's data
             * @param {boolean} getActions
             * @return {Promise<workflow-instance>}
             */
            _fetchInstance: function _fetchInstance(data, getActions) {
                var options = {
                    piid: data["PROCESS_INSTANCE.PIID"],
                    systemID: data.systemID
                };
                if (getActions) {
                    options.parts = "actions";
                }
                return wpResources.process.get(options);
            },

            _errorLaunchTask: function _errorLaunchTask(data) {
                bpmext.log.info("TaskList._errorLaunchTask ERROR >> (data): " + data, this);
                taskUtils.EVENTS.CREATE_TOAST.publish({
                    title: bpmext.localization.formatMsg("notifications", "notificationErrorTitle"), 
                    text: bpmext.localization.formatMsg("Errors", "launchTask"),
                    style: "D"
                });
            },

            _fetchTasks: function _fetchTasks(view, sort) {
            	var delay = 500;
                var t = delay + new Date().getTime();
            	if (view._instance.runCurrentTimer) {
            		if (t < view._instance.runCurrentTimerTime) {
            			return;
            		}
            		clearTimeout(view._instance.runCurrentTimer);
            		view._instance.runCurrentTimer = undefined;
            		view._instance.runCurrentTimerTime = undefined;
            	}
            	view._instance.runCurrentTimerTime = t;
            	view._instance.runCurrentTimer = setTimeout(function() {
            		view._instance.runCurrentTimer = undefined;
            		view._instance.runCurrentTimerTime = undefined;
                    if (view.context.options.useEventTriggeringFetchAction.get("value") !== true) {
                        view._instance.taskTable.setVisible(false, true);
                        view.reloadSkeletonTable();
                    } else {
                        view._instance.paginationView.setVisible(false, true);
                    }
         			view._proto._actualFetchTasks(view, sort);
            	}, delay);
            },

            _actualFetchTasks: function _actualFetchTasks(view, sort) {
                var searchObj = view._proto._generateTasksQueryObject(view, sort);

                if (!view.context.options.useEventTriggeringFetchAction.get("value")) {
                    view._instance.tasksResource.get(searchObj);
                } else {
                    bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONEXTERNAL_FETCH, searchObj);
                }
            },

            /**
             * @param {View} view
             * @param {task[]} tasks - (TASK.TKIID, PROCESS_INSTANCE.PIID, systemID)
             * Gets all of the task details, grouped by system id and
             * puts the task details in a map cache
             * (task -> task details)
             */
            _updateTaskCache: function _updateTaskCache(view, tasks) {
                var groupedTasks = {};
                for (var i = 0; i < tasks.length; i++) {
                    var task = tasks[i];
                    var tkiid = task["TASK.TKIID"] || task["tkiid"];
                    if (!groupedTasks[task.systemID]) {
                        groupedTasks[task.systemID] = [];
                    }
                    groupedTasks[task.systemID].push(tkiid);
                }

                var promises = [];
                for (var systemID in groupedTasks) {
                    promises.push(view._instance.taskResource.getBatchTaskDetails({ 
                        tkiids: groupedTasks[systemID],
                        systemID: systemID === "undefined" ? null : systemID
                    }));
                }

                return all(promises).then(function(groupedTasks) {
                    view._instance.taskCache.clear();
                    for (var i = 0; i < groupedTasks.length; i++) {
                        var group = groupedTasks[i];
                        var taskObjects = group.data.tasks;
                        for (var j = 0; j < taskObjects.length; j++) {
                            view._instance.taskCache.set(tasks[j], taskObjects[j]);
                        }
                    }
                }, function(error) {
                    bpmext.log.error("Unable to pre-fetch task details at this time.");
                    bpmext.log.error(error);
                });
            },

            /**
             * @param {View} view
             * @param {View} row - task table row
             * @param {object} task - result from task GET
             */
            _displayExpandedRow: function _displayExpandedRow(view, row, task) {
                var td = row.td;
                var systemData = new Map();
                var businessData = new Map();

                systemData.set(bpmext.localization.formatMsg("workplace", "workflow"), {
                    type: view.context.options.enableInstanceDetails.get("value") ? "LINK" : "STRING",
                    value: task.processInstanceName,
                    onclick: function () {
                        view._proto._launchInstance(view, row.data);
                    }
                });

                // people
                systemData.set(view._proto._translate("assignedToUser"), task.owner);
                systemData.set(bpmext.localization.formatMsg("searchFilter", "team"), task.teamDisplayName);
                systemData.set(bpmext.localization.formatMsg("searchFilter", "manager"), task.managerTeamDisplayName);

                // dates/times
                if (task.completionTime) {
                    systemData.set(view._proto._translate("taskClosedDate"), taskUtils.formatDate(task.completionTime, true));
                }
                systemData.set(view._proto._translate("taskDueDate"), taskUtils.formatDate(row.data.DUE || row.data.dueTime, true));
                if (!task.completionTime) {
                    systemData.set(view._proto._translate("atRiskOn"), taskUtils.formatDate(task.atRiskTime, true));
                }
                systemData.set(bpmext.localization.formatMsg("searchFilter", "lastModificationTime"), taskUtils.formatDate(task.lastModificationTime, true));
                systemData.set(bpmext.localization.formatMsg("searchFilter", "creationDate"), taskUtils.formatDate(task.startTime, true));

                task.processData.businessData.forEach(function(data) {
                    if (data.value != null) {
                        if (data.type === "Date") {
                            data.value = taskUtils.formatDate(data.value, true);
                        } else if (data.name === "workstreamDefintion.description") {
                            return;
                        }
                        businessData.set(data.label, data.value);
                    }
                });

                var rowContainer = td.children[0];
                var description = view._proto._getTaskDescription(task);
                taskUtils.createExpandableRow(view, utilities, rowContainer, {
                    description: description,
                    systemData: systemData,
                    businessData: businessData,
                    rowData: row.data,
                    taskOrInstance: task
                });

                var buttonView = row.views[0];
                var openButton = buttonView.context.element.querySelector("button");
                openButton.onclick = function openTaskDetails() {
                    view.launchTask(row.data);
                };

                if (taskUtils.isTaskCompleted(row.data)) {
                    view._proto._fetchInstance(row.data, true).then(function(instance) {
                        row.data.name = instance.name;
                        if (instance.actions.indexOf("ACTION_VIEW_INSTANCE") !== -1) {
                            buttonView.setText(bpmext.localization.formatMsg("instanceList", "openWorkflow"));
                            buttonView.setVisible(true);
                        }
                    });
                } else if (view._proto._checkIsLaunchable(view, task)){
                    buttonView.setText(view._proto._translate("openTask"));
                    buttonView.setVisible(true);
                }
            },

            /*********** CONSTRUCT SAVE SEARCH OBJECT START ***********/
            _generateTasksQueryObject: function _generateTasksQueryObject(view, sort) {
                return {
                	aliases: view._proto._getAlias(view),
                    calcStats: view._proto._getCalcStats(view),
                    sort: view._proto._getSortingOrder(view, sort),
                    fields: view._proto._getQueryFields(view),
                    conditions: view._proto._getQueryConditions(view),
                    interaction: view._proto._getQueryInteraction(view),
                    size: view._proto._getQuerySize(view),
                    offset: parseInt(view._instance.paginationView.getCurPageNumber())-1
                };
            },

            _getCalcStats: function _getCalcStats(view) {
                return view.context.options.showStats.get("value") === true;
            },

            _getSortingOrder: function _getSortingOrder(view, sort) {
                var ascending = wpResources.tasks.SORT_BY.ASCENDING;
                var descending = wpResources.tasks.SORT_BY.DESCENDING;
                //Keep the sort for task cards (small screen)
                if (!view._instance.sortByWrap.isVisible()) {
                    if(view.context.options.taskSortBy.get("value")) {
                        var sortByValue = view.context.options.taskSortBy.get("value");
                        if (sortByValue.value === "ascending") {
                            sort = [ascending(sortByValue.name)];
                        } else if(sortByValue.value === "descending"){
                            sort = [descending(sortByValue.name)];
                        }
                    }
                }
                if (!sort || !Array.isArray(sort)) {
                    sort = [];
                }

                return sort || [ascending("taskDueDate"), ascending("taskAtRiskTime"), ascending("taskPriority")];
            },

            _getQueryFields: function _getQueryFields(view) {
                var selectedCols = view._instance.selectedCols || [];

                var fields = dojo.clone(selectedCols);
                fields =  (fields || []).map(function (field) {
                    return field.name;
                });

                if (wpResources.isAppEngine) {
                    fields = fields.concat(["IS_WORKSTREAM", "WORKSTREAM_STATUS"]);
                }

                if (wpResources.isFederated) {
                    fields.push("taskIsAtRisk");
                } else {
                    // Defect 364010: AT_RISK_TIME isn't accurate on standalone
                    fields.push("taskAtRiskTime");
                }
                return fields;
            },
            
            _getAlias: function _getAlias(view) {
            	var selectedCols = view._instance.selectedCols || [], aliases = [];
            	for(var i = 0; i < selectedCols.length; i++) {
            		if(selectedCols[i].isBusinessData) {
            			var bdVal = selectedCols[i].value;
            			// if there are process name, only send the alias name without the process name 
            			if(bdVal.indexOf("(") != -1) {
            				bdVal = bdVal.substring(0, bdVal.indexOf("("));
            			}
                        else if(bdVal.indexOf("<") != -1) {
            				bdVal = bdVal.substring(0, bdVal.indexOf("<"));
                        }
                		aliases.push({field: selectedCols[i].name, alias: bdVal});
                	}
            	}
                return aliases;
            },

            _getQueryConditions: function _getQueryConditions(view) {
                var filterConditions = view._instance.filterConditions || [{field: "taskActivityType",operator: "Equals",value: "USER_TASK"}];
                var scopeFilterConditions = view._instance.scopeFilterConditions || [];
                if(scopeFilterConditions){
                    for(var x=0;x<scopeFilterConditions.length; x++){
                        if(filterConditions.length>0){
                            for(var y=filterConditions.length-1; y>=0; y--){
                                if(filterConditions[y].field === scopeFilterConditions[x].field){
                                    filterConditions.splice(y);
                                    break;
                                }
                            }
                        }
                        if(scopeFilterConditions[x].name){
                            delete scopeFilterConditions[x].name;
                        }
                    }
                }

                var searchTerm = view._instance.searchTerm || "";
                var processAppAcro = view.context.options.processAppAcro.get("value");
                var quickFilterConditions = dojo.clone(view._instance.quickFilterConditions);

                var conditions = dojo.clone(filterConditions);
                conditions = conditions.filter(function (condition) {
                    return condition.field !== "interaction";
                });

               
                for(var x = scopeFilterConditions.length - 1 ; x>=0; x--){
                    conditions.push(scopeFilterConditions[x]);                    
                }

                if (searchTerm) {
                    conditions.unshift(wpResources.tasks.OPERATOR.FULL_TEXT_SEARCH(searchTerm || ""));
                }

                if (processAppAcro) {
                    conditions.push({operator: taskUtils.OPERATOR.EQUALS, field: "instanceProcessApp", value: processAppAcro});
                }

                if (quickFilterConditions) {
                    conditions = conditions.concat(quickFilterConditions);
                }

                return conditions;
            },

            _getQueryInteraction: function _getQueryInteraction(view) {
                var filterConditions = view._instance.filterConditions || [];

                if (!filterConditions || !Array.isArray(filterConditions)) {
                    filterConditions = [];
                }

                return filterConditions.reduce(function(interaction, condition) {
                    return interaction ? interaction : condition.field === "interaction" ? condition.value : interaction;
                }, "");
            },

            _getQuerySize: function _getQuerySize(view) {
                if (view._instance.isNextTaskMode) {
                    return 1;
                }
                return view._instance.paginationView.getPerPage() || 10;
            },
            /*********** CONSTRUCT SAVE SEARCH OBJECT END ***********/

            _checkTaskOwnership: function _checkTaskOwnership(view, task) {
                var ownershipCheckEnabled = view.context.options.requiredOwnershipCheck.get("value");

                if (!ownershipCheckEnabled) {
                    return true;
                } else {
                    if (view._instance.user) {
                        task["OWNER"] = task["OWNER"] || task["owner"];
                        if (task["OWNER"]) {
                            // check if current user is the task owner
                            return task["OWNER"] === view._instance.user.currentUser;
                        } else if (task["ASSIGNED_TO_ROLE_DISPLAY_NAME"] || task["assignedToDisplayName"]) {
                            var assignedToRole = task["ASSIGNED_TO_ROLE_DISPLAY_NAME"] || task["assignedToDisplayName"];
                            // check if current user belong to the task assign group
                            return (view._instance.user.currentUserMemberships || [])
                                .indexOf(assignedToRole) > -1;
                        }
                    }
                }

                return false;
            },

            /**
             * @return {boolean}
             */
            _checkIsLaunchable: function _checkIsLaunchable(view, task) {
                var disableCompleteTasks = !!view.context.options.disableCompleteTasks.get("value");
                var isTaskCompleted = taskUtils.getStatusClassName(task) === "completedTask";
                var isOwner = view._proto._checkTaskOwnership(view, task);
                return isOwner && !(disableCompleteTasks && isTaskCompleted);
            },

            /************ CUSTOM TABLE CELL START ************/
            /************ TASK NAME CELL ************/
            _setTaskNameCell: function _setTaskNameCell(view, data) {
                var taskNameEle;
                if (this._checkIsLaunchable(view, data)) {
                    taskNameEle = domConstruct.create("a", {
                        "href": "javascript:void(0)",
                        "target": "_self",
                        "aria-label": (data["TAD_DISPLAY_NAME"] || data["displayName"])
                            + " " + bpmext.localization.formatMsg("controlTaskList", "task")
                    });

                    taskNameEle.addEventListener("click", function () {
                        view.launchTask(data);
                    });
                } else {
                    taskNameEle = domConstruct.create("span");
                }

                taskNameEle.innerText = data["TAD_DISPLAY_NAME"] || data["displayName"];

                return taskNameEle;
            },

            /************ ACTION MENU CELL ************/
            _setActionMenu: function _setActionMenu(view, data) {
                var iconWrapper = domConstruct.create("div", {"class": "Icon"});
                var btnWrapper = domConstruct.create("div", {
                    "class": "OverflowIconBtn SPARKIcon btn",
                    "role": "button",
                    "tabindex": "0",
                    "aria-label": bpmext.localization.formatMsg("controlTaskList", "overFlowMenu"),
                    "aria-haspopup": "true",
                    "parentViewName": view.ui.getAbsoluteName(),
                    "taskId": data["TASK.TKIID"] || data["tkiid"] || "",
                    "processId": data["PROCESS_INSTANCE.PIID"] || data["piid"] || "",
                    "systemID": data["systemID"] || "",
                    "isWorkstream": data["IS_WORKSTREAM"] || "",
                    "isTaskLaunchable": view._proto._checkTaskOwnership(view, data) + ""
                }, iconWrapper);

                var btnLabel = domConstruct.create("span", {
                    "class": "btn-label icon ci"
                }, btnWrapper);

                var icon = utilities.getCarbonIcon("ci-overflow-menu-vertical");
                domConstruct.place(icon, btnLabel);

                btnWrapper.addEventListener("click", function(){
                    view._proto._openOverflowMenuHandler(view, this);
                }, true);

                btnWrapper.addEventListener("keydown", function(event){
                    // if input key is space or enter key
                    if (event.key === "Enter" || event.key === " " || event.key === "Spacebar") {
                        view._proto._openOverflowMenuHandler(view, this);
                    }
                }, true);

                return iconWrapper;
            },

            _openOverflowMenuHandler: function(view, ele){
                var actionIcon = ele,
                    actionsMenu = view._instance.actionsMenu;

                // remove active class
                domClass.remove(actionIcon, "active");

                var processId = actionIcon.getAttribute("processId"),
                    taskId = actionIcon.getAttribute("taskId"),
                    systemID = actionIcon.getAttribute("systemID"),
                    isWorkstream = actionIcon.getAttribute("isWorkstream"),
                    isTaskLaunchable = actionIcon.getAttribute("isTaskLaunchable");

                view._proto._justifyActionsMenuOptions(view, {
                    isTaskLaunchable: isTaskLaunchable === "true"
                });

                // Load actions menu
                actionsMenu.loadMenu(processId, taskId, systemID, isWorkstream, null, ele);

                // Add active class
                domClass.add(actionIcon, "active");
            },

            _justifyActionsMenuOptions: function _justifyActionsMenuOptions(view, rights) {
                var actionsMenu = view._instance.actionsMenu;

                var disabledActions = actionsMenu.context.options.disableActions.get("value").items || [];
                disabledActions = dojo.clone(disabledActions);

                // Disabled the launch task option if current user does not has right to access it
                var isDisabledLaunchTask = disabledActions.indexOf("ACTION_LAUNCH_TASK") > -1;
                if (rights.isTaskLaunchable && isDisabledLaunchTask) {
                    disabledActions.splice(disabledActions.indexOf("ACTION_LAUNCH_TASK"), 1);
                    actionsMenu.context.options.disableActions.set("value", disabledActions);
                } else if (!rights.isTaskLaunchable && !isDisabledLaunchTask) {
                    disabledActions.push("ACTION_LAUNCH_TASK");
                    actionsMenu.context.options.disableActions.set("value", disabledActions);
                }
            },
            /************ CUSTOM TABLE CELL END ************/

            _generateHistoryCallbacks: function _generateHistoryCallbacks (view) {
                var onViewRestore = function () {
                    if (!view.isVisible()) {
                        view.setVisible(true, true);
                        var historyCallbacks = view._proto._generateHistoryCallbacks(view);
                        taskUtils.viewHistory.addToViewHistory(historyCallbacks);

                        view.refreshTaskList();
                    }
                };

                var onViewClose = function () {
                    if (view.isVisible()) {
                        view.setVisible(false, true);
                    }
                };

                return {
                    identifier: "TaskList",
                    onViewRestore: onViewRestore,
                    onViewClose: onViewClose
                };
            },

            /**
             * @param {Object} task
             * @return {string} - key generated from the task systemID, TKIID and PI_PIID
             */
            _getKey: function _getKey(task) {
                return [
                    task.systemID || "",
                    task.TKIID || task["TASK.TKIID"],
                    task.PI_PIID || task["PROCESS_INSTANCE.PIID"]
                ].join("-");
            },

            _initTaskPrioritization: function _initTaskPrioritization(view, tasks) {
                view._proto._calculateTfsConfig(view).then(function (tfsConfig) {
                    // run only when we have tasks and the service is configured
                    if (tasks && tasks.size > 0 && tfsConfig.name) {
                        view._instance.tfsConfig = tfsConfig;
                        // call the service when we always run or toggle is set to ON
                        if (tfsConfig.alwaysRun || tfsConfig.showToggle) {
                            view._instance.prioritizeTasksContainer.setVisible(true);
                            view._proto._setPrioritizationTooltip(view);
                            
                            if (tfsConfig.alwaysRun) {
                                view._instance.prioritizeTasksToggle.setEnabled(false);
                                view._instance.prioritizeTasksToggle.setChecked(true);
                            }
                            if (tfsConfig.alwaysRun || view._instance.prioritizeTasksToggle.getData()) {
                                view._proto._executeTaskFilterService(view, tasks.items);
                            }
                        }
                    }
                });
            },

            /**
             * Default TFS is overridden by the workplaceTFS config
             * If alwaysRun is on, showToggle is turned off
             * @returns {Promise} promise
             */
            _calculateTfsConfig: function _calculateTfsConfig(view) {
                // cache the config call
                if (!view._instance._tfsConfigPromise) {
                    // check the config on the current system AE or BAW
                    view._instance._tfsConfigPromise = wpResources.config.get().then(function(config) {
                        view._instance.portalConfig = config;
                        return wpResources.systems.getTaskFilterServiceServer();
                    }).then(function (system) {
                        // check if one of the backend systems has TFS
                        if (system && system.getTaskFilterServiceConfig) {
                            view._instance.tfsSystemID = system.systemID;
                            return system.getTaskFilterServiceConfig().then(function (configRes) {
                                var defaultTFS = configRes.taskFilterService;
                                var workplaceTFS = view._instance.portalConfig.taskFilterService;

                                // firstly, use defaultTFS and override it with workplaceTFS
                                // finally, make sure we have a name for the service
                                // may return an object with only the name populated
                                view._instance.tfsConfig = {
                                    name: workplaceTFS.name || defaultTFS.name,
                                    alwaysOn: workplaceTFS.alwaysOn || defaultTFS.alwaysOn,
                                    showToggle: workplaceTFS.showToggle || defaultTFS.showToggle
                                };
                                return view._instance.tfsConfig;
                            });
                        }
                        return {};
                    });
                }
                // always use the cached promise
                return view._instance._tfsConfigPromise;
            },

            /**
             * @param {Array} filter1 The filter you want to compare
             * @param {Array} filter2 The filter you want to compare
             * @desc Compares the filter to determine if it has been modified
             */	
            _compareFilterConditions: function _compareFilterConditions(filter1, filter2) {	
                if (filter1.length !== filter2.length) {
                    return true;
                } else {
                    for (var x = 0; x < filter2.length; x++) {
                        for (var y = 0; y < filter1.length; y++) {
                            var f1 = filter1[y], f2 = filter2[x];
                            if (f2.field === f1.name) {
                                if (f2.operator !== f1.operator) {
                                    return true;
                                } else if (f2.value !== f1.value) {
                                    return true;
                                }
                                break;
                            }
                        }
                    }
                    return false;
                }
            },

            /**
             * @param {View} view
             * @param {Object[]} tasks - tasks array
             *
             * Sets the taskTable's items to be in the order set by TFS
             */
            _executeTaskFilterService: function _executeTaskFilterService(view, tasks) {
                if (!view._instance.tfsConfig || !view._instance.tfsConfig.name) {
                    return;
                }
                return wpResources.service.start({
                    name: view._instance.tfsConfig.name,
                    data: { "tw.local.jsonPayload": JSON.stringify(tasks) },
                    systemID: view._instance.tfsSystemID
                })
                .then(function (res) {
                    var items = taskUtils.safeGet(res, ["data", "data", "taskIdentifiers", "items"]);
                    if (!items) {
                        taskUtils.publishError(bpmext.localization.formatMsg("controlTaskList", "errorCallingService"));
                        return;
                    }
                    // build map of taskIdentifiers to be passed to the service
                    var taskMap = (tasks || []).reduce(function(acc, task) {
                        acc[view._proto._getKey(task)] = task;
                        return acc;
                    }, {});
                    var filteredTasks = items.reduce(function (accm, item) {
                        var task = taskMap[view._proto._getKey(item)];
                        if (task) {
                            accm.push(task);
                        }
                        return accm;
                    }, []);
                    view._instance.taskTable.setViewData(filteredTasks, true);
                    view._instance.loadingTable.setVisible(false, true);
                    view._instance.taskTable.setVisible(true, true);
                    view._instance.taskTable.refresh();
                }, function () {
                    taskUtils.publishError(bpmext.localization.formatMsg("controlTaskList", "errorCallingService"));
                });
            },
            
            _setPrioritizationTooltip: function _setPrioritizationTooltip(view) {
                var messageKey;
                if (view._instance.tfsConfig.alwaysOn) {
                    messageKey = "alwaysOnPrioritizationTooltip";
                } else {
                    messageKey = "taskPrioritizationTooltip";
                }
                bpmext.ui.util.showTooltip(
                    view._instance.prioritizeTasksInfoIcon.context.element.querySelector('.SPARKIcon[role="button"]'),
                    view._proto._translate(messageKey),
                    {horizontalPos: "LEFT", smartPositioning: true, openDelay: 0.5}
                );
            },

            /**
             * Add status content to div
             * @param {HTMLElement} div
             * @param {Object} rowData
             */
            _addStatusContent: function _addStatusContent(div, rowData) {
                var statusIconSpan = domConstruct.toDom("<span class='statusIcon'></span>");

                var statusImageURL = taskUtils.getTaskDueStatusImageURL(rowData, true);
                if (statusImageURL) {
                    var imageSpan = domConstruct.toDom("<img src='" + statusImageURL +"' alt='" + bpmext.localization.formatMsg("taskCard", "taskStatus") + "'></img>");
                    domConstruct.place(imageSpan, statusIconSpan);
                }

                var labelSpan = domConstruct.toDom("<span class='InstanceStatusLabel'></span>");
                labelSpan.innerText = taskUtils.getStatusLabel(rowData);

                domConstruct.place(statusIconSpan, div);
                domConstruct.place(labelSpan, div);
            },

            _getTaskDescription: function _getTaskDescription(task) {
                var variables = task.data.variables;

                if (variables.approval) {
                    return variables.approval.taskDescription;
                } else if (variables.checkListStep) {
                    return variables.checkListStep.description;
                } else if (variables.formStep) {
                    return variables.formStep.description;
                }
                return "";
            },

            _enableBatchModify: function _enableBatchModify(view) {
                var enable = view.context.options.enableBatchModify.get("value") || false;

                view._instance.taskTable.context.options.selectionMode.set("value", enable ? "M" : "N");
                view._instance.batchEditBtn.setEnabled(false, true);
                view._instance.batchEditBtn.setVisible(enable, true);
            },

            _setButtonTooltip: function _setButtonTooltip(view, message){
            	// set tooltip for filter button
            	var filterButtonCtl = view._instance.savedSearchBuilderLauncher.context.element.querySelector('.SPARKIcon[role="button"]');
            	filterButtonCtl.onmouseenter = function () {
            		view._instance.filterTP = bpmext.ui.util.showTooltip(
                		filterButtonCtl,
                        bpmext.localization.formatMsg("controlTaskList", "filterTooltip"),
                        {horizontalPos: "LEFT", smartPositioning: true, alwaysShow: true}
                    );
            	};
            	filterButtonCtl.onmouseleave = function() {
                    bpmext.ui.util.closeTooltip(view._instance.filterTP, filterButtonCtl);
                    filterButtonCtl.blur();
                };

                filterButtonCtl.onfocus = function () {
            		view._instance.filterTPFocus = bpmext.ui.util.showTooltip(
                		filterButtonCtl,
                        bpmext.localization.formatMsg("controlTaskList", "filterTooltip"),
                        {horizontalPos: "LEFT", smartPositioning: true, alwaysShow: true}
                    );
            	};
            	filterButtonCtl.onblur = function() {
                    bpmext.ui.util.closeTooltip(view._instance.filterTPFocus, filterButtonCtl);
                };

            	// set tooltip for batch edit button
            	var EDT_BtnCtl = view._instance.batchEditBtn.context.element.querySelector('.SPARKIcon[role="button"]');
                EDT_BtnCtl.setAttribute("aria-label", bpmext.localization.formatMsg("controlTaskList", "batchModify"));
                // if the tooltip text remain same, do nothing
                if (!view._instance.batchModifyTP_TEXT || view._instance.batchModifyTP_TEXT !== message) {
                    view._instance.batchModifyTP_TEXT = message || bpmext.localization.formatMsg("TeamPerformance", "edtTooltip");
                } else {
                    return;
                }
                if (view._instance.batchModifyTP) {
                    bpmext.ui.util.closeTooltip(view._instance.batchModifyTP, EDT_BtnCtl);
                }
                EDT_BtnCtl.onmouseenter = function () {
                	view._instance.batchModifyTP = bpmext.ui.util.showTooltip(
                        EDT_BtnCtl,
                        view._instance.batchModifyTP_TEXT,
                        {horizontalPos: "LEFT", smartPositioning: true, alwaysShow: true}
                    );
                };
                EDT_BtnCtl.onmouseleave = function() {
                    bpmext.ui.util.closeTooltip(view._instance.batchModifyTP, EDT_BtnCtl);
                    EDT_BtnCtl.blur();
                };

                EDT_BtnCtl.onfocus = function () {
                    view._instance.batchModifyTPFocus = bpmext.ui.util.showTooltip(
                        EDT_BtnCtl,
                        view._instance.batchModifyTP_TEXT,
                        {horizontalPos: "LEFT", smartPositioning: true, alwaysShow: true}
                    );
                };
                EDT_BtnCtl.onblur = function() {
                    bpmext.ui.util.closeTooltip(view._instance.batchModifyTPFocus, EDT_BtnCtl);
                };
            	
            	//set tooltip for refresh button
                var refreshButtonCtl = view._instance.refreshButton.context.element.querySelector('.SPARKIcon[role="button"]');
                var currentTime, secondsSinceRefresh, minutesSinceRefresh, lastRefreshedText;
                var refreshSecCalculation = function () {
                    currentTime = new Date();
                    secondsSinceRefresh = Math.floor((currentTime - view._instance.lastRefreshed)/1000);
                    if (secondsSinceRefresh > 60){
                        minutesSinceRefresh = Math.floor(secondsSinceRefresh/60);
                        if(minutesSinceRefresh > 30){
                            lastRefreshedText = bpmext.localization.formatMsg("controlTaskList", "maxRefreshButtonTooltip");
                        }
                        else{
                            lastRefreshedText = bpmext.localization.formatMsg("controlTaskList", "minuteRefreshButtonTooltip", minutesSinceRefresh);
                        }
                    }
                    else{
                        lastRefreshedText = bpmext.localization.formatMsg("controlTaskList", "secondRefreshButtonTooltip", secondsSinceRefresh);
                    }
                };

                refreshButtonCtl.onmouseenter = function () {
                    refreshSecCalculation();
                    view._instance.lastRefreshedTP = bpmext.ui.util.showTooltip(
                        refreshButtonCtl,
                        lastRefreshedText,
                        {horizontalPos: "LEFT", smartPositioning: true, alwaysShow: true}
                    );
                };
                refreshButtonCtl.onmouseleave = function() {
                    bpmext.ui.util.closeTooltip(view._instance.lastRefreshedTP, refreshButtonCtl);
                    refreshButtonCtl.blur();
                };

                refreshButtonCtl.onfocus = function () {
                    refreshSecCalculation();
                    view._instance.lastRefreshedTPFocus = bpmext.ui.util.showTooltip(
                        refreshButtonCtl,
                        lastRefreshedText,
                        {horizontalPos: "LEFT", smartPositioning: true, alwaysShow: true}
                    );
                };
                refreshButtonCtl.onblur = function() {
                    bpmext.ui.util.closeTooltip(view._instance.lastRefreshedTPFocus, refreshButtonCtl);
                };

                // set tooltip for start workflow button if overflow
                var startButtonCtl = view._instance.addWorkflowButton.context.element.querySelector('[role="button"]');
                var startInitialWidth = startButtonCtl.offsetWidth;
                var startButtonTooltip = false;
                startButtonCtl.onmouseenter = function () {
                    if (startInitialWidth > startButtonCtl.offsetWidth || (view.context.options.responsiveMode.get("value") === "SMALL"
                    && startButtonCtl.offsetWidth < "170")) {
                        startButtonTooltip = true;
                        view._instance.startTP = bpmext.ui.util.showTooltip(
                            startButtonCtl,
                            bpmext.localization.formatMsg("workplace", "addWorkflow"),
                            {horizontalPos: "LEFT", smartPositioning: true, alwaysShow: true}
                        );
                    };
                };
                startButtonCtl.onmouseleave = function() {
                    if (startButtonTooltip) {
                        startButtonTooltip = false;
                        bpmext.ui.util.closeTooltip(view._instance.startTP, startButtonCtl);
                    };
                };
            },

            _isTaskAbleToModify: function _isTaskAbleToModify(view, task) {
                var taskRistrictions = (view._instance.batchModifyConfig || {}).rejectedTasks;
                    
                if (taskUtils.isTaskCompleted(task)) {
                    return {
                        enable: false,
                        warningMessage: bpmext.localization.formatMsg("controlTaskList", "cannotModifyCompletedTask")
                    };
                } else if ((taskRistrictions || {}).notOwnedTask) {
                    if (!view._proto._checkTaskOwnership(view, task)) {
                        return {
                            enable: false,
                            warningMessage: bpmext.localization.formatMsg("controlTaskList", "cannotModifyNotOwnedTask")
                        };
                    }
                }

                return {
                    enable: true
                };
            }
        };


        /*
        Public control methods *************************************************************
         */

        /**
		 * @instance
		 * @memberof TaskList
		 * @method launchTask
         * @param {Row} row The row of the table that contains the task record.
		 * @desc Launches the task referenced by the given row.
         */
        this.constructor.prototype.launchTask = function launchTask(row) {
            var view = this;
            //prevent multiple clicks
            if (this._instance.taskClicked !== true) {
                this._instance.taskClicked = true;
                if (taskUtils.isTaskCompleted(row)) {
                    this._proto._launchInstance(view, row);
                } else {
                    this._instance.taskResource.get({ tkiid: row["TASK.TKIID"] || row["tkiid"], includeURL: true, systemID: row.systemID }).then(function(task) {
                        if (!task.message) {
                            task.systemID = task.systemID || row.systemID;
                            if (taskUtils.isTaskCompleted(task)) {
                                view._proto._launchInstance(view, task);
                            } else if((taskUtils.isUserTask(task) || view._instance.portalConfig.enableSystemTaskLaunchByPortal)) {
                                view._proto._launchTask(view, task);
                            } else {
                                taskUtils.publishError(bpmext.localization.formatMsg("controlTaskList", "systemTaskLaunchError"));
                            }
                        }
                    }, function error () {
                        //the task has probably already been deleted, try to handle by removing it from the task list
                        var x, length, taskList = view.context.binding.get("value").get("items");
                        length = taskList && taskList.length() || 0;
                        for (x = 0; x < length; x++) {
                            if (taskList.items[x]["TASK.TKIID"] === row["TASK.TKIID"]) {
                                taskList.remove(x);
                                view._proto._loadTasks.call(view, view.context.binding.get("value"));
                                break;
                            }
                        }
                    });
                }
                setTimeout(function() {
                    view._instance.taskClicked = false;
                },1000);
            }
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method createStatusCell
         * @param {View} theView The current view
         * @param {Cell} cell The table cell where the status information will be displayed
         * @return {div} The div with the formatted status information
		 * @desc Creates the status cell with the appropriate highlighting based on the current task status.
         */
        this.constructor.prototype.createStatusCell = function createStatusCell(theView, cell) {
            var field = (cell || {}).varName;
            var data = (cell || {}).row && (cell.row || {}).data;

            if (field === "skeleton" || field === "skeletonActionMenu"){
                var span = document.createElement("span");
                span.classList.add("skeleton"); 
                if (field === "skeleton" ){
                    return span;
                } else if (field === "skeletonActionMenu"){
                    var skeletonAMDiv = this._proto._setActionMenu(this, data);
                    domConstruct.place(skeletonAMDiv, span);
                    return span;
                }
            }
            // not recognizable data field or empty row data
            if (!field || JSON.stringify(data) === "{}") {
                return;
            }

            var div = document.createElement("div");


            if (["STATUS", "STATE", "status", "state"].indexOf(field) > -1) {
                this._proto._addStatusContent(div, data);
            } else if (field === "PI_STATUS" || field === "instanceStatus") {
                div.innerText = taskUtils.getInstanceStatus(data);
            } else if (field === "PRIORITY" || field === "priority") {
                div.innerText = taskUtils.getPriorityLabel(data["PRIORITY"] || data["priority"]);
            } else if (field === "TASK_ACTIVITY_TYPE" || field === "taskActivityType") {
                div.innerText = taskUtils.getActivityTypeLabel(data["TASK_ACTIVITY_TYPE"]);
            } else if (field === "TAD_DISPLAY_NAME" || field === "displayName") {
                cell.setSortValue(cell.getFormattedValue().toLowerCase());
                var taskNameEle = this._proto._setTaskNameCell(this, data);
                domConstruct.place(taskNameEle, div);
            } else if (field === "actionMenu") {
                var disableCompleteTasks = !!this.context.options.disableCompleteTasks.get("value");
                var isTaskCompleted = taskUtils.getStatusClassName(data) === "completedTask";

                var disabledOnCompleteTasks = disableCompleteTasks && isTaskCompleted;
                if (!disabledOnCompleteTasks) {
                    cell.parentNode.setAttribute("aria-label", bpmext.localization.formatMsg("controlTaskList", "overFlowMenu"));

                    var actionMenuBtn = this._proto._setActionMenu(this, data);
                    domConstruct.place(actionMenuBtn, div);
                } else {
                    cell.parentNode.setAttribute("aria-hidden", "true");
                }
            }else{
                div.innerText = data[field] || "";
            }

            return div;
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method onActionMenuOpen
         * @param {View} actionsMenuView The actions menu view
         * @param {Element} actionsMenuTargetElement The action menu button that was clicked to invoke the menu.
		 * @desc Called when the actions menu is opened.
         */
        this.constructor.prototype.onActionMenuOpen = function onActionMenuOpen() {
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method onActionMenuClosed
         * @param {View} actionsMenuView The actions menu view
         * @param {Element} actionsMenuTargetElement The action menu button that was clicked to invoke the menu.
		 * @desc Called when the actions menu is closed.
         */
        this.constructor.prototype.onActionMenuClosed = function onActionMenuClosed(actionsMenuView, actionsMenuTargetElement) {
            // close action menu from task table
            if (!!actionsMenuTargetElement && !!actionsMenuTargetElement.firstElementChild) {
                var classes = actionsMenuTargetElement.firstElementChild.getAttribute("class");
                actionsMenuTargetElement.firstElementChild.setAttribute("class", classes.replace(" active", "").trim());
            }

            // close action menu that open from task cards
            if (actionsMenuTargetElement && actionsMenuTargetElement.classList && actionsMenuTargetElement.classList.contains("active")) {
                actionsMenuTargetElement.classList.remove("active");
            }
            if(actionsMenuTargetElement){
                actionsMenuTargetElement.focus();
            }

        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method handleTaskAction
         * @param {event} event The actions menu click event
		 * @desc Handles the task action when a menu item is clicked.
         */
        this.constructor.prototype.handleTaskAction = function handleTaskAction(event) {
            var node = event.currentTarget;
            var taskId = node.getAttribute("taskId");
            var action = node.getAttribute("action");
            var parentView = bpmext.ui.getView(node.getAttribute("parentViewName"));
            switch(action) {
              case "modifyTask":
                  parentView._proto._handleModifyTask(parentView, taskId);
                  break;
            }
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method reload
		 * @desc Reloads the Task List.
         */
        this.constructor.prototype.reload = function reload() {
            bpmext.log.info("TaskList.reload ENTER >>", this);

            this._instance.shouldReloadWhenVisible = !this.isVisible();

            if (this._instance.shouldReloadWhenVisible) {
                return;
            }

            if (this._instance.isNextTaskMode) {
                this._instance.paginationView.setVisible(false, true);
            } else {
                this._instance.paginationView.setVisible(true, true);
            }

            //Reload methods for different screen size
            if (this._instance.sortByWrap.isVisible()) {
                this.sortByConditionOnChange(); //Reload from task cards (small screen)
            } else {
                if (this._instance.sortBy.getItemCount() > 0) {
                    this._instance.sortBy.setSelectedItemAt(0); //Reset sorting parameters
                }
                this._proto._fetchTasks(this, this._instance.currentSort); //Reload from task table (large/medium screen)
            }
            bpmext.log.info("TaskList.reload EXIT >>", this);
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method setSelectedColumns
         * @param {NameValuePair[]} columns The list of selected columns.
         * @return {boolean} True if the selected columns have changed, false otherwise
		 * @desc Sets the selected columns that the task list displays, and reloads the list.
         */
        this.constructor.prototype.setSelectedColumns = function setSelectedColumns(columns) {
            var hasChanged = (JSON.stringify(this._instance.selectedCols) !== JSON.stringify(columns));
            if(columns && hasChanged === true) {
                this._instance.selectedCols = dojo.clone(columns);

                //Update config option
                this.setOption("columns", columns);
            }
            return hasChanged;
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method setFilterConditions
         * @param {NameValuePair[]} conditions The list of filter conditions.
         * @return {boolean} True if the filter conditions have changed, false otherwise
		 * @desc Sets the list of conditions to filter the task list. If a search term is provided, it overrides the previously specified search conditions.
         */
        this.constructor.prototype.setFilterConditions = function setFilterConditions(conditions, rawConditions) {
            var hasChanged = false;
            if (this._instance.filterConditions !== null) {
                hasChanged = (JSON.stringify(this._instance.filterConditions) !== JSON.stringify(conditions));
            }
            this._instance.filterConditions = conditions;

            //Update config option
            this.setOption("searchFilters", rawConditions);

            return hasChanged;
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method setScopeCondition
         * @param {NameValuePair[]} conditions The list of filter conditions.
         * @return {boolean} True if the filter conditions have changed, false otherwise
		 * @desc Sets the list of scope conditions to filter the task list.
         */
         this.constructor.prototype.setScopeCondition = function setScopeCondition(conditions) {
            var hasChanged = false;
            var filterCondition = [];
            if (this._instance.scopeFilterConditions !== null) {
                hasChanged = (JSON.stringify(this._instance.scopeFilterConditions) !== JSON.stringify(conditions));
            }
            for(var x=0;x<conditions.length;x++){
                if (!!conditions[x].value && conditions[x].value !== "undefined") {
                    if(conditions[x].name){
                        filterCondition.push({field:conditions[x].name,operator:conditions[x].operator,value:conditions[x].value});
                    }else{
                        filterCondition.push(conditions[x]);
                    }
                }
            }
            this._instance.scopeFilterConditions = filterCondition;

            return hasChanged;
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method setFilterConditions
         * @param {NameValuePair[]} conditions The list of filter conditions.
         * @return {boolean} True if the filter conditions have changed, false otherwise
		 * @desc Sets the list of conditions to filter the task list. If a search term is provided, it overrides the previously specified search conditions.
         */
        this.constructor.prototype.setQuickFilterConditions = function setFilterConditions(conditions) {
            var hasChanged = false;
            if (this._instance.quickFilterConditions !== null) {
                hasChanged = (JSON.stringify(this._instance.quickFilterConditions) !== JSON.stringify(conditions));
            }
            this._instance.quickFilterConditions = conditions;

            return hasChanged;
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method setExclusiveColumns
         * @param {String[]} fields The list of colum name.
         * @return {boolean} True if the filter conditions have changed, false otherwise
		 * @desc Sets the list of exclusive columns to filter the task list.
         */
        this.constructor.prototype.setExclusiveColumns = function setExclusiveColumns(fields) {
            var hasChanged = false;
            if (this._instance.excludeColumns !== null) {
                hasChanged = (JSON.stringify(this._instance.excludeColumns) !== JSON.stringify(fields));
            }
            this._instance.excludeColumns = fields;

            return hasChanged;
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method setSearchTerm
         * @param {string} searchTerm The search term used to filter the task list.
         * @return {boolean} True if the search term has changed, false otherwise
		 * @desc Sets the search term. If a search term is provided, it overrides any previously specified search conditions.
         */
        this.constructor.prototype.setSearchTerm = function setSearchTerm(searchTerm) {
            var hasChanged = this._instance.searchTerm !== searchTerm;
            this._instance.searchTerm = searchTerm;
            return hasChanged;
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method setSortByOptions
		 * @desc Sets the sort by a drop-down value.
         */
        this.constructor.prototype.setSortByOptions = function setSortByOptions(view, columnList) {
            var defaultCol = {
                name: bpmext.localization.formatMsg("controlTaskList", "defaultSortColName"),
                value: bpmext.localization.formatMsg("controlTaskList", "defaultSortColValue")
            };

            //Adding a default row to improve semantic fluency
            columnList = [defaultCol].concat(columnList);
            for (var x=0; x<columnList.length; x++) {
                view._instance.sortBy.appendItem(columnList[x].name, columnList[x].value);
            }

            view._instance.sortBy.setSelectedItemAt(0);
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method sortByConditionOnChange
		 * @desc Sets the conditions of the task displaying order.
         */
        this.constructor.prototype.sortByConditionOnChange = function sortByConditionOnChange() {
            var field = this._instance.sortBy.getSelectedItem();
            var initState = !this._instance.sortByOrderValue;
            var sortByOrderBtn = this._instance.sortByOrder.context.element.querySelector("div[role=button]");

            //Reload tasks without ordering if the field value is missing or setting to default
            if (!field || field === bpmext.localization.formatMsg("controlTaskList", "defaultSortColName")) {
                //Reload tasks on at small screen mode, except the initializing
                if (this._instance.sortByWrap.isVisible() && !initState) {
                    this._proto._fetchTasks(this);
                }

                //Initialize the icon value and icon
                if (initState) {
                    this._instance.sortByOrderValue = "DESC";
                    this._instance.sortByOrder.setIcon("ci-arrow-down");

                    !!sortByOrderBtn && domAttr.set(sortByOrderBtn, "aria-label", bpmext.localization.formatMsg("controlTaskList", "desc"));
                }

                this._instance.sortByOrder.setVisible(false, true);
                this.context.options.showSortByArrow.set("value", false);

                return;
            } else {
                //Update sorting condition or reload tasks based on previous sorting parameters
                if (!this.context.options.showSortByArrow.get("value")) {
                    this._instance.sortByOrderValue = "DESC";
                    this._instance.sortByOrder.setIcon("ci-arrow-down");
                    this._instance.sortByOrder.setVisible(true, true);
                    this.context.options.showSortByArrow.set("value", true);

                    !!sortByOrderBtn && domAttr.set(sortByOrderBtn, "aria-label", bpmext.localization.formatMsg("controlTaskList", "desc"));
                }

                //Fetch tasks with customized ordering
                var curOrder = this._instance.sortByOrderValue;
                if (curOrder) {
                    var ascending = this._instance.tasksResource.SORT_BY.ASCENDING;
                    var descending = this._instance.tasksResource.SORT_BY.DESCENDING;
                    var sort = (curOrder === "DESC") ? [descending(field)] : [ascending(field)];

                    //To include the at risk tasks
                    if (field !== "taskAtRiskTime") {
                        sort.push(descending("taskAtRiskTime"));
                    }

                    this._proto._fetchTasks(this, sort);
                }
            }
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method toggleOrder
		 * @desc Toggles the order button.
         */
        this.constructor.prototype.toggleOrder = function toggleOrder() {
            var order = this._instance.sortByOrderValue;
            var sortByOrderBtn = this._instance.sortByOrder.context.element.querySelector("div[role=button]");

            if (order === "DESC") {
                this._instance.sortByOrderValue = "ASC";
                this._instance.sortByOrder.setIcon("ci-arrow-up");

                !!sortByOrderBtn && domAttr.set(sortByOrderBtn, "aria-label", bpmext.localization.formatMsg("controlTaskList", "asc"));
            } else {
                this._instance.sortByOrderValue = "DESC";
                this._instance.sortByOrder.setIcon("ci-arrow-down");

                !!sortByOrderBtn && domAttr.set(sortByOrderBtn, "aria-label", bpmext.localization.formatMsg("controlTaskList", "desc"));
            }

           this.sortByConditionOnChange();
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method openFilter
		 * @desc The event handler for the slideout toggle.
         */
        this.constructor.prototype.openFilter = function openFilter() {
            bpmext.log.info("TaskList.openFilter ENTER >>", this);
            var action = this._instance.searchBar.getCurrentSavedSearchLaunched();
            if(action){
                bpmext.log.info("open saved search editor: >>" + action);
                taskUtils.EVENTS.EDIT_SAVED_SEARCH.publish({search: action});
            }else{
                taskUtils.EVENTS.CREATE_SAVED_SEARCH.publish();
            }
            bpmext.log.info("TaskList.openFilter EXIT >>", this);
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method toggleTFS
		 * @desc Set the task Table
         */
        this.constructor.prototype.toggleTFS = function toggleTFS() {
            bpmext.log.info("TaskList.toggleTFS ENTER >>", this);
            var isTFSOn = this._instance.prioritizeTasksToggle.getData();
            var items = this.getData().items;
            if (isTFSOn) {
                this._proto._executeTaskFilterService(this, items);
                if (this._instance.tfsConfig.alwaysRun) {
                    this._instance.prioritizeTasksToggle.setEnabled(false);
                }
            } else {
                this._instance.taskTable.setViewData(this._instance.tasks.items, true);
                this._instance.loadingTable.setVisible(false, true);
                this._instance.taskTable.setVisible(true, true);
                this._instance.prioritizeTasksToggle.setEnabled(true);
                this._instance.taskTable.refresh();
            }
            bpmext.log.info("TaskList.toggleTFS EXIT >>", this);
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method setTasks
		 * @desc Sets tasks for displaying
		 */
        this.constructor.prototype.setTasks = function setTasks(tasks) {
            var view = this;
            if (view._instance.setTasksTimeout) {
                clearTimeout(view._instance.setTasksTimeout);
            }
            //In some cases, the current user is not updated, so we may need to delay the loading of the tasks until the user is loaded
            if (view._instance.user) {
                view._proto._loadTasks.call(view, tasks);
            } else {
                view._instance.setTasksTimeout = setTimeout(function() {
                      view.setTasks.call(view, tasks);
                },100);
            }
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method getSelectedRecords
		 * @desc Gets selected tasks
		 */
        this.constructor.prototype.getSelectedRecords = function getSelectedRecords() {
            var selectedRecords = [], all;
        	if (this._instance.taskTable._instance.list) {
            	all = this._instance.taskTable.getSelectedRecords() || [];
            	selectedRecords = all.filter(function(task) {
                	return !taskUtils.isTaskCompleted(task);
                });
            }

            return selectedRecords;
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method loadEmptyTasksTableContent
		 * @desc Loads empty task table content
		 */
        this.constructor.prototype.loadEmptyTasksTableContent = function(target) {
            var texts = this.getEmptyTableTexts();

            var noTasksImage = target.context.getSubview("NoTasksImage", target)[0];
            if (noTasksImage) {
                var image = noTasksImage.context.element.querySelector("img");
                domAttr.remove(image, "tabindex");
            }

            var noTasksContentLayout = target.context.getSubview("NoTasksContentLayout", target)[0];
            if (noTasksContentLayout) {
                var noTasksHeader= noTasksContentLayout.context.getSubview("NoTasksHeader", noTasksContentLayout)[0];
                if (noTasksHeader) {
                    var headerId = noTasksHeader.context.element.id;
                    domAttr.set(image, "aria-labelledby", headerId);

                    noTasksHeader.setText(texts.header);
                    noTasksHeader.setLabelVisible(false);
                }

                var noTasksSubheader= noTasksContentLayout.context.getSubview("NoTasksSubheader", noTasksContentLayout)[0];
                if (noTasksSubheader) {
                    noTasksSubheader.setText(texts.subHeader);
                    noTasksSubheader.setLabelVisible(false);
                }
            }
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method setEmptyTableTexts
		 * @desc Set texts in the empty table
		 */
        this.constructor.prototype.setEmptyTableTexts = function setEmptyTableTexts(emptyTableText) {
            var checkingFields = ["header", "subHeader"];

            this._instance.emptyTableText = checkingFields.reduce(function (texts, field) {
                texts[field] = emptyTableText[field];
                return texts;
            }, {});

            //refresh empty task table
            this._instance.noTasksToDisplayView.setViewData([{name: 0}], true);
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method getEmptyTableTexts
		 * @desc Gets texts in the empty table
		 */
        this.constructor.prototype.getEmptyTableTexts = function getEmptyTableTexts() {
            return dojo.clone(this._instance.emptyTableText || this._proto.EMPTY_TASKS_TABLE_TEXT);
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method displayExpandedTaskRow
         * @param {object} row.td - task data
         * @param {object} row.data - task data
         * @param {string} row.data.TASK.TKIID || row.data.tkiid
		 * @desc Set the task Table's expanded row
         */
        this.constructor.prototype.displayExpandedTaskRow = function displayExpandedTaskRow(table, row) {
            var view = this;
            var task = this._instance.taskCache.get(row.data);

            if (task) {
                this._proto._displayExpandedRow(this, row, task);
            } else {
                var tkiid = row.data["TASK.TKIID"] || row.data["tkiid"];
                this._instance.taskResource.get({ tkiid: tkiid, includeURL: true, systemID: row.data.systemID }).then(function (task) {
                    view._proto._displayExpandedRow(view, row, task);
                }, function error(error) {
                    bpmext.log.error(error);
                    // TODO: close the expandable row
                    taskUtils.EVENTS.CREATE_TOAST.publish({
                        title: bpmext.localization.formatMsg("notifications", "notificationErrorTitle"),
                        text: bpmext.localization.formatMsg("Errors", "loadTaskDetails"),
                        style: "D"
                    });
                });
            }
        };

        this.constructor.prototype.onRearrangeColumn = function onRearrangeColumn(view, columns) {
            var newColumnOrder = [];
            var i;
            for(i = 0; i < columns.length; i++) {
                if(columns[i].dataElementName !== "actionMenu") {
                    newColumnOrder[columns[i].columnOrder] = {
                        name: columns[i].name || columns[i].dataElementName,
                        value: columns[i].label
                    };
                }
            }
            this.setSelectedColumns(newColumnOrder);
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method onResizeColumn
		 * @desc Sets the column widths to the columnWidths binding
         */
        this.constructor.prototype.onResizeColumn = function onResizeColumn(view, cspecs) {
            var newColumnWidths = [];
            var i;
            for(i = 0; i< cspecs.length; i++){
                newColumnWidths[cspecs[i].columnOrder] = {
                    name: cspecs[i].name || cspecs[i].dataElementName,
                    value: cspecs[i].width ? cspecs[i].width : null
                };
            }
            this.setOption("columnWidths", newColumnWidths);
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method onColumnSorting
		 * @desc Triggered on column sorting
		 */
        this.constructor.prototype.onColumnSorting = function onColumnSorting(target, field, order) {
            var asc = order === "ascending" ? true : order === "descending" ? false : undefined;

            // Matching attribute name
            var srcAttrName, attributeName, srcAttribute, srcAttb;
            var fromSS = this._instance.sortFromSS;
            ((this._instance.tasks && this._instance.tasks.attributes) || []).forEach(function (attribute) {
                srcAttrName = attribute.name;
                srcAttb = (attribute.sourceAttribute && attribute.sourceAttribute.indexOf(".")==0) ? attribute.sourceAttribute.substring(1) : attribute.sourceAttribute;
                // srcAttb is from saved search
                if (srcAttrName === field || srcAttb === field) {
                    attributeName = srcAttrName;
                    srcAttribute = srcAttb;
                }
            });

            if (this._instance.prioritizeTasksContainer.isVisible()) {
                this._instance.prioritizeTasksToggle.setChecked(false);
                if (this._instance.tfsConfig.alwaysRun) {
                    this._instance.prioritizeTasksToggle.setEnabled(true);
                }
            }

            // Sorting on original field
            if (attributeName && !this.context.options.useEventTriggeringFetchAction.get("value")) {
                // reverse priority order since highest priority's value is 10
                // and the lowest one is 50
                asc = attributeName === "PRIORITY" && asc !== undefined ? !asc : asc;

                var ascending = this._instance.tasksResource.SORT_BY.ASCENDING;
                var descending = this._instance.tasksResource.SORT_BY.DESCENDING;
                if(asc){
                    this._instance.currentSort = [ascending(srcAttribute)];
                } else if(asc === false){
                    this._instance.currentSort = [descending(srcAttribute)];
                } else {
                    this._instance.currentSort = null;
                }

                if (!fromSS) {
                    if (asc === undefined) {
                        this.context.options.taskSortBy.set("value", {name: "taskDueDate", value: "none"});
                        taskUtils.EVENTS.CHANGE_SORT_FILTER.publish({field: "taskDueDate", order: "none"});

                        // Delete the badge if selected cols and filters are default
                        var defaultCol = taskUtils.DEFAULT_SELECTED_COLUMNS;
                        var nonDefaultCol = [];
                        var columns = this._instance.selectedCols;
                        for(var i=0; i<columns.length; i++){
                            var val1 = columns[i], found = false;
                            for(var j=0; j<defaultCol.length; j++){
                                var val2 = defaultCol[j];
                                if(val1.name == val2){
                                    found = true;
                                    break;
                                }
                            }
                            !found && nonDefaultCol.push(val1);
                        }
                        var isDefaultSearchFilter = !this._instance.filterConditions || !this._proto._compareFilterConditions(taskUtils.DEFAULT_FILTER_CONDITION, this._instance.filterConditions);
                        if (nonDefaultCol.length === 0 && isDefaultSearchFilter) {
                            taskUtils.EVENTS.SET_TASK_BADGE.publish({clearSS:false});
                        }
                    } else {
                        var sortByValue = this.context.options.taskSortBy.get("value");
                        if (attributeName === "PRIORITY") {
                            asc = !asc;
                        }
                        var sortValue = asc ? "ascending" : "descending";
                        //Only set if the sort is different
                        if (sortByValue && (sortByValue.name !== srcAttribute || sortByValue.value !== sortValue)) {
                            if (sortByValue.name !== "taskDueDate" || srcAttribute !== "taskDueDate" || sortByValue.value !== "none" || order !== "none") {
                                this.context.options.taskSortBy.set("value", {name: srcAttribute, value: sortValue});
                                taskUtils.EVENTS.CHANGE_SORT_FILTER.publish({field: srcAttribute, order: asc ? "ASC" : "DESC"});
                                taskUtils.EVENTS.SET_TASK_BADGE.publish({text:bpmext.localization.formatMsg("SearchBar", "filterApplied"),clearSS:false});
                            }
                        }
                    }
                }
                this.refreshTaskList();

                // Manually update sort icons when sorting from saved search
                if (fromSS) {
                    this.updateSortIcons(this._instance.taskTable, attributeName, asc);
                }
                this._instance.sortFromSS = false;

                return false;
            }
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method updateSortIcons
		 * @desc Update sort icons displayed on table headers
         */
         this.constructor.prototype.updateSortIcons = function(view, col, asc) {
            if(view._instance.headerRow != null){
                var children = view._instance.headerRow.childNodes;
                var i;
                if(col != null){
                    for(i = 0; i < children.length; i++){
                        var c = children[i];
                        if(c.tagName != "TH")
                            continue;

                        if(c.__varName != null){
                            var sorterTh = c;
                            var sorterDiv = sorterTh.querySelector(".sorter");
                            var icon = sorterDiv && sorterDiv.querySelector(".ci");

                            if(c.__varName != col) {
                                // Set not selected columns to default sort
                                domClass.remove(sorterTh, "asc desc");
                                domAttr.set(sorterTh, "aria-sort", "none");
                                if (icon) {
                                    utilities.replaceCarbonIcon(icon, "ci-arrows");
                                } else if (sorterDiv) {
                                    sorterDiv.appendChild(utilities.getCarbonIcon("ci-arrows"));
                                }
                            } else {
                                var replacedIconName = "ci-arrows";
                                if (c.__varName === "PRIORITY") {
                                    asc = asc === undefined ? undefined : !asc;
                                }
                                if (asc) {
                                    domClass.remove(sorterTh, "desc");
                                    domClass.add(sorterTh, "asc");
                                    replacedIconName = "ci-arrow-up";
                                } else if (asc === false) {
                                    domClass.remove(sorterTh, "asc");
                                    domClass.add(sorterTh, "desc");
                                    replacedIconName = "ci-arrow-down";
                                } else {
                                    domClass.remove(sorterTh, "asc desc");
                                }

                                if (icon) {
                                    utilities.replaceCarbonIcon(icon, replacedIconName);
                                } else if (sorterDiv) {
                                    domConstruct.place(utilities.getCarbonIcon(replacedIconName), sorterDiv, "first");
                                }
                            }
                        }
                    }
                }
            }
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method loadSavedSearch
		 * @desc Load saved search stack
         */
        this.constructor.prototype.loadSavedSearch = function() {
            taskUtils.EVENTS.LOAD_MODAL.publish({showModal:true, modal:"Saved search"});
            this.openFilter();
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method onTableRowSelected
		 * @desc Triggered when table row get (all) selected
		 */
        this.constructor.prototype.onTableRowSelected = function() {
            var selectedRecords = this.getSelectedRecords();

            if (this._instance.batchEditBtn) {
                // Enable the button whenever rows on select
                this._instance.batchEditBtn.setEnabled(selectedRecords.length > 0, true);
                this._instance.batchEditBtn.setColorStyle("T");
            } 
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method openBatchModifyTasks
		 * @desc Event handler for launch batch modify tasks modal
         */
        this.constructor.prototype.openBatchModifyTasks = function openBatchModifyTasks() {
            bpmext.log.info("TaskList.openBatchModifyTasks >>", this);

            var result, view = this;

            // Skipping all tasks that are not able to modify
            var tasks = this.getSelectedRecords().filter(function (task) {
                result = view._proto._isTaskAbleToModify(view, task);
                return result.enable;
            });

            var batchConfig = Object.assign({}, {
                view: this,
                tasks: tasks
            }, (this._instance.batchModifyConfig || {}).params || {});

            taskUtils.EVENTS.BATCH_MODIFY_TASKS.publish(batchConfig);
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method configBatchModify
		 * @desc Setting batch config options 
         */
        this.constructor.prototype.configBatchModify = function configBatchModify(config) {
            this._instance.batchModifyConfig = config || {};
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method paginationHandler
		 * @desc Handler for when the pagination view's value changes
         */
        this.constructor.prototype.paginationHandler = function paginationHandler() {
            if(this.isVisible() && this._instance.paginationView){
            	this.refreshTaskList();
            }
        };
    
        this.constructor.prototype.reloadSkeletonTable = function reloadSkeletonTable() {
            this._instance.loadingTable.setVisible(false, true);
            var perPage = this._instance.paginationView.getPerPage();
            var skeletonData = taskUtils.createSkeletonTableData(perPage ? perPage : taskUtils.DEFAULT_PER_PAGE);
            var skeletonColumn = taskUtils.createSkeletonTableColumns(this._instance.defaultSelectedCols.length, !this.context.options.hideActionMenu.get("value"));
            this._instance.loadingTable.setColumns(skeletonColumn);
            this._instance.loadingTable.setViewData(skeletonData, true);
            this._instance.loadingTable.setVisible(true, true);
        };

        /**
		 * @instance
		 * @memberof TaskList
		 * @method refreshTaskList
		 * @desc Refresh tasklist when the refresh button is clicked
         */
        this.constructor.prototype.refreshTaskList = function refreshTaskList() {
            this.reload();
            this._instance.lastRefreshed = new Date();
        };

         // for next task dashboard to load the default next task saved search if defined, if the defined one is not available to current user, load the default adhoc search
        this.constructor.prototype.loadDefaultSavedSearch = function loadDefaultSavedSearch (search) {
            wpResources.searches.get({id: search}).then(dojo.hitch(this,
                function(defaultSearch) {
                    this._proto._setDefaultSearchParameters(this, defaultSearch);
                    this.refreshTaskList();
                }
            ), dojo.hitch(this, function() {
                this.refreshTaskList();
            }));
        };

        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function ()
        {
            bpmext.log.info("TaskList.load ENTER >>", this);

            var view = this, opts = this.context.options, taskListNotificationsHandler;

            if (!this.context.binding) {
                this.context.binding = bpmext.ui.substituteObject(this, "binding", "tasks", {});
            }

            if (!opts.columns) {
                bpmext.ui.substituteConfigOption(this, "columns", taskUtils.DEFAULT_SELECTED_COLUMNS);
            }

            if(!opts.columnWidths){
                bpmext.ui.substituteConfigOption(this, "columnWidths", null);
            }

            if (!opts.searchFilters) {
                bpmext.ui.substituteConfigOption(this, "searchFilters", null);
            }

            if (!opts.showSingleList) {
                bpmext.ui.substituteConfigOption(this, "showSingleList", false);
            }

            if (!opts.hideColumnSelector) {
                bpmext.ui.substituteConfigOption(this, "hideColumnSelector", false);
            }

            if (!opts.showStats) {
                bpmext.ui.substituteConfigOption(this, "showStats", false);
            }

            if (!opts.hideStatusColumn) {
                bpmext.ui.substituteConfigOption(this, "hideStatusColumn", false);
            }

            if (!opts.tasksLabel) {
                bpmext.ui.substituteConfigOption(this, "tasksLabel", bpmext.localization.formatMsg("controlTaskList", "taskList"));
            }

            if (!opts.extendedTasksLabel) {
                bpmext.ui.substituteConfigOption(this, "extendedTasksLabel", bpmext.localization.formatMsg("controlTaskList", "later"));
            }

            if (!opts.showSortByArrow) {
                bpmext.ui.substituteConfigOption(this, "showSortByArrow", false);
            }

            if (!opts.showRefresh) {
                bpmext.ui.substituteConfigOption(this, "showRefresh", false);
            }

            if (!opts.responsiveMode) {
                bpmext.ui.substituteConfigOption(this, "responsiveMode", "LARGE");
            }

            if (!opts.showSavedSearches) {
                bpmext.ui.substituteConfigOption(this, "showSavedSearches", false);
            }

            if (!opts.enableSavedSearchEditing){
                bpmext.ui.substituteConfigOption(this, "enableSavedSearchEditing", false);
            }

            if (!opts.enableInstanceDetails){
                bpmext.ui.substituteConfigOption(this, "enableInstanceDetails", false);
            }

            if (!opts.processAppAcro){
                bpmext.ui.substituteConfigOption(this, "processAppAcro", "");
            }

            if (!opts.enableAddWorkflow){
                bpmext.ui.substituteConfigOption(this, "enableAddWorkflow", false);
            }

            if (!opts.disableFilterEvents){
                bpmext.ui.substituteConfigOption(this, "disableFilterEvents", false);
            }

            if (!opts.hideActionMenu) {
                bpmext.ui.substituteConfigOption(this, "hideActionMenu", false);
            }

            if (!opts.useEventTriggeringFetchAction) {
                bpmext.ui.substituteConfigOption(this, "useEventTriggeringFetchAction", false);
            }

            if (!opts.taskLaunchEvent) {
                bpmext.ui.substituteConfigOption(this, "taskLaunchEvent", "");
            }

            if (!opts.requiredOwnershipCheck) {
                bpmext.ui.substituteConfigOption(this, "requiredOwnershipCheck", false);
            }

            if (!opts.hideSearchBar) {
                bpmext.ui.substituteConfigOption(this, "hideSearchBar", false);
            }

            if (!opts.disableCompleteTasks) {
                bpmext.ui.substituteConfigOption(this, "disableCompleteTasks", false);
            }

            if (!opts.skipClaimForTasks) {
                bpmext.ui.substituteConfigOption(this, "skipClaimForTasks", false);
            }
            
            if (!opts.enableBatchModify) {
                bpmext.ui.substituteConfigOption(this, "enableBatchModify", false);
            }

            if (!opts.savedSearchName) {
                bpmext.ui.substituteConfigOption(this, "savedSearchName", "");
            }

            if (!opts.taskSortBy) {
                bpmext.ui.substituteConfigOption(this, "taskSortBy", null);
            }

            this._instance.selectedCols = [];
            var defaultCol = taskUtils.DEFAULT_SELECTED_COLUMNS;
            var columns = opts.columns.get("value").length() > 0 ? opts.columns.get("value").toJSObject().items : defaultCol;
            if(opts.columns.get("value").length() === 0) {
                for(var i=0; i<columns.length; i++){
                    var val = columns[i];
                    if(val)
                        view._instance.selectedCols.push({name: val, value: taskUtils.getLabelFromTaskProperty(val)});
                }
            } else {
                view._instance.selectedCols = columns;
                var nonDefaultCol = [];
                for(var i=0; i<columns.length; i++){
                    var val1 = columns[i], found = false;
                    for(var j=0; j<defaultCol.length; j++){
                        var val2 = defaultCol[j];
                        if(val1.name == val2){
                            found = true;
                            break;
                        }
                    }
                    !found && nonDefaultCol.push(val1);
                }
                if(!opts.savedSearchName.get("value") && nonDefaultCol.length>0){
                    taskUtils.EVENTS.SET_TASK_BADGE.publish({text:bpmext.localization.formatMsg("SearchBar", "filterApplied"),clearSS:false});
                }
            }
            this._instance.defaultSelectedCols = lang.clone(this._instance.selectedCols);
            this._instance.mandatoryColumns = taskUtils.DEFAULT_MANDATORY_COLUMNS;

            if(opts.searchFilters.get("value") && opts.searchFilters.get("value").length() > 0) {
                this._instance.filterConditions = opts.searchFilters.get("value").toJSObject().items;
                var isDefaultSearchFilter = !this._instance.filterConditions || !this._proto._compareFilterConditions(taskUtils.DEFAULT_FILTER_CONDITION, this._instance.filterConditions);
                if(!opts.savedSearchName.get("value") && !isDefaultSearchFilter){
                    taskUtils.EVENTS.SET_TASK_BADGE.publish({text:bpmext.localization.formatMsg("SearchBar", "filterApplied"),clearSS:false});
                }
            }

            // Resize columns
            this._instance.columnWidths = opts.columnWidths.get("value") !== null ? opts.columnWidths.get("value").toJSObject().items : null;

            //get child CVs
            this._instance.defaultTodayTableEntries = 10;
            this._instance.taskTable = bpmext.ui.getContainer("TasksTable", this);
            this._instance.taskTable.setTitle(bpmext.localization.formatMsg("workplace", "tasksTitle"));
            this._instance.basicTasksPanel = bpmext.ui.getContainer("BasicTasksPanel", this);
            this._instance.refreshButton = bpmext.ui.getView("taskRefreshButton", this);
            this._instance.batchEditBtn = bpmext.ui.getView("BatchModifyButton", this);
            this._instance.noTasksToDisplayView = bpmext.ui.getContainer("NoTasksToDisplayView", this);
            this._instance.noTasksToDisplayView.setVisible(false, true);
            this._instance.savedSearchBuilderLauncher = bpmext.ui.getView("TaskListFiltersButton", this);
            this._instance.addWorkflowButton = bpmext.ui.getView("AddWorkflowButton", this);
            this._instance.prioritizeTasksContainer = bpmext.ui.getContainer("PrioritizeTasksContainer", this);
            this._instance.prioritizeTasksToggle = bpmext.ui.getView("PrioritizeTasksToggle", this);
            this._instance.prioritizeTasksInfoIcon = bpmext.ui.getView("PrioritizeTasksInfoIcon", this);
            this._instance.getLink = bpmext.ui.getView("GetLink", this);

            //Pagination
            this._instance.paginationView = bpmext.ui.getView("Pagination1", this);

            //Table Sekelton Loading
            this._instance.loadingTable = bpmext.ui.getContainer("SkeletonLoadingTable", this);
            this.reloadSkeletonTable();

            this._instance.lastRefreshed = new Date();
            this._proto._setButtonTooltip(this);

            //add dummy row to empty state table
            this._instance.noTasksToDisplayView.setViewData([{name: 0}], true);

            //Small form factor
            this._instance.sortByWrap = bpmext.ui.getContainer("SortByWrap", this);
            this._instance.sortBy = bpmext.ui.getView("SortBy", this);
            this._instance.sortByOrder = bpmext.ui.getView("SortByOrder", this);
            this._instance.taskCards = bpmext.ui.getContainer("Task_Cards", this);
            this._instance.extendedTasksCards = bpmext.ui.getContainer("Extended_Task_Cards", this);

            this._instance.taskCards.muteLaunchCompleteTask(opts.disableCompleteTasks.get("value"));

            // Refresh button
            if (this.context.options.showRefresh.get("value") === true) {
                this._instance.refreshButton.setVisible(true, true);
                var refreshButtonDom = this._instance.refreshButton.context.element.querySelector(".SPARKIcon.btn");
                domAttr.set(refreshButtonDom, "aria-label", this._proto._translate("refresh"));
            } else{
                this._instance.refreshButton.setVisible(false, true);

                // Show the refresh button if the notification server is down
                taskUtils.EVENTS.SHOW_REFRESH_BUTTON.subscribe(function (){
                    this._instance.refreshButton.setVisible(true, true);
                }, this);
            }

            if (this.context.options.showSortByArrow.get("value")) {
                this._instance.sortByOrder.setVisible(true, true);
            } else {
                this._instance.sortByOrder.setVisible(false, true);
            }
            if (this.context.options.hideStatusColumn.get("value") === true) {
                //remove the first item in each list which is the status column
                this._instance.mandatoryColumns.shift();
                this._instance.selectedCols.shift();
                taskUtils.DEFAULT_SELECTED_COLUMNS.shift();
                this._instance.taskStat.showTotalOnly(true);
                this._instance.extendedTaskStat.showTotalOnly(true);
            }
            if(!this.context.options.enableSavedSearchEditing.get("value")){
                this._instance.savedSearchBuilderLauncher.setVisible(false, true);
            }
            if(!this.context.options.enableAddWorkflow.get("value")){
                this._instance.addWorkflowButton.setVisible(false, true);
            }

            // Claimed task modal
            this._instance.claimedTaskModal = bpmext.ui.getContainer("Claim_Task_Modal", this);

            //Get the System and Business data
            wpResources.searches.getMetaFields()
            .then(function(systemData) {
                wpResources.searches.getMetaBusinessDataFields()
                    .then(function(businessData) {
                        var isPXServer = view.context.isWorkflowPXServer && view.context.isWorkflowPXServer() === true,
                        	isCaseSupported = view.context.isCaseSupported && view.context.isCaseSupported() === true;
                        view._instance.systemData = taskUtils.processColumns(systemData, taskUtils.getFieldsToHide(isPXServer || !isCaseSupported, false));
                        view._instance.businessData = taskUtils.processBusinessDataColumns(businessData);
                        var combinedOptions = view._instance.businessData.concat(view._instance.systemData);

                        view.setSortByOptions(view, combinedOptions.sort(function(a, b){return a.value.localeCompare(b.value);}));
                    }, function (error) {
                        view._proto._errorLoadTasks(view, error);
                    });
                }, function (error) {
                    view._proto._errorLoadTasks(view, error);
                }
            );

            //Actions menu
            this._instance.actionsMenu = bpmext.ui.getView("Actions_Menu", this);

            //Search bar
            this._instance.searchBar = bpmext.ui.getView("SearchBar1", this);

            if(this.context.options.hideSearchBar.get("value")){
                this._instance.searchBar.setVisible(false, true);
            } else {
            	//set tooltip for search button
            	var searchButtonCtl = this._instance.searchBar._instance.searchIcon.context.element.querySelector('.SPARKIcon[role="button"]');
            	searchButtonCtl.onmouseenter = function() {
            		view._instance.searchTP = bpmext.ui.util.showTooltip(
               	 		searchButtonCtl,
               	 		bpmext.localization.formatMsg("controlTaskList", "searchBarTooltip"),
                        {horizontalPos: "LEFT", smartPositioning: true, alwaysShow: true}
                    );
            	};
            	searchButtonCtl.onmouseleave = function() {
           	 		bpmext.ui.util.closeTooltip(view._instance.searchTP, searchButtonCtl);
           	 	};
            }

            if(!this.context.options.enableInstanceDetails.get("value")){
                this._instance.actionsMenu.context.options.disableActions.get("value").items.push("ACTION_VIEW_INSTANCE", "ACTION_MODIFY_INSTANCE");
            }

            if(this.context.options.showSavedSearches.get("value")){
                this._instance.searchBar.context.options.showSavedSearches.set("value", true);
            } else {
                this._instance.searchBar.context.options.placeholder.set("value", bpmext.localization.formatMsg("controlTaskList", "allFieldsSearchPlaceholder"));
            }

            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONTASK_LAUNCHED, "task");
            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONMODIFY_TASK_ACTION, "taskId");
            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONEXTERNAL_FETCH, "searchSettings");

            this._instance.taskResource = wpResources.task;
            this._instance.tasksResource = wpResources.tasks;
            this._instance.configResource = wpResources.config;
            this._instance.serviceResource = wpResources.service;
            this._instance.size = this._instance.size ? this._instance.size : this._instance.tasksResource.get.default_size;

            this._proto._getCurrentUserInfo(this);
            this._proto._setTaskLaunchEvent(this);
            this._proto._enableBatchModify(this);
//            this._proto._fetchTasks(this);

            taskUtils.EVENTS.NO_FEDERATED_SYSTEM.subscribe(function(eventName, eventData){
                if (eventData) {
                    this._proto._errorLoadTasks(this, eventData);
                }
            }, this);

            // callback triggered every time the saved search results are fetched
            view._instance.tasksResource.get.register(view,
                function (tasks) {
                    view.context.binding.set("value", tasks);

                    view._instance.paginationView.setItemLength(tasks.stats.total);

                    view._instance.shouldReloadWhenVisible = !view.isVisible();
                    // do not load ui the task lists when it is not visible
                    if (!view._instance.shouldReloadWhenVisible) {
                        view._proto._loadTasks.call(view, tasks);
                        this._proto._initTaskPrioritization(view, tasks);
                        
                    }
                }, function (error) {
                    view._proto._errorLoadTasks(view, error);
                }
            );

            this._instance.shouldReloadWhenVisible = false;
            this._instance.sortFromSS = false;

            taskListNotificationsHandler = function refreshLogic(){
                if (!taskUtils.getNotificationExistence()) {
                    taskUtils.EVENTS.DELAY_RELOAD.publish();
                } else {
                	view.refreshTaskList();
                }
            };

            taskUtils.EVENTS.NOTIFICATION_TASK_RESOURCE_ASSIGNED.subscribe(taskUtils.throttle(dojo.hitch(this, taskListNotificationsHandler)), this);
            taskUtils.EVENTS.NOTIFICATION_PROCESS_STARTED.subscribe(taskUtils.throttle(dojo.hitch(this, taskListNotificationsHandler)), this);
            
            taskUtils.EVENTS.TASKLIST_TASK_RESOURCE_ASSIGNED.subscribe(taskUtils.throttle(dojo.hitch(this, taskListNotificationsHandler)), this);
            taskUtils.EVENTS.TASK_FIELD_CHANGED.subscribe(taskUtils.throttle(dojo.hitch(this, taskListNotificationsHandler)), this);

            taskUtils.EVENTS.GET_LINK.subscribe(function(eventName, eventData) {
                var data;
                if (view.isVisible() && eventData && eventData.task) {
                    data = {name: "Workplace", type: "task", data: {tkiid: eventData.task.tkiid, systemID: eventData.task.systemID}};
                    if(!view.context.options.useEventTriggeringFetchAction.get("value")) {
                        view._instance.getLink.copyLink(data);
                    } else {
                        //raise an event to allow the parent window to handle the copy event
                        if (parent && parent !== parent.parent) {
                            try {
                                var eventInfo = {
                                    name: "copyLinkRequest",
                                    data: data
                                };
                                parent.parent.postMessage(JSON.stringify(eventInfo), "*");
                            } catch (e) {
                                bpmext.log.error("InstanceUI._fetchInstance " + bpmext.localization.formatMsg("general", "ERROR") + ": " + e);
                                if (e.stack) {
                                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                                }
                            }
                        }                    }
                }
            }, this);

            // Reassign back to team
            taskUtils.EVENTS.REASSIGN_BACK.subscribe(function (eventName, eventData) {
                if (eventData && eventData.task) {
                    wpResources.task.assignBackToGroup(eventData.task); 
                    taskUtils.viewHistory.loadViewFromHistory();
                }
            }, this);

            if(opts.disableFilterEvents.get("value") !== true) {
                // Reload the list when the workstream state/fields change has been done
                taskUtils.EVENTS.MODIFY_INSTANCE_CLOSE.subscribe(this.refreshTaskList, this);
                taskUtils.EVENTS.ACTION_PERFORMED.subscribe(this.refreshTaskList, this);
                // reload when return from Team dashboard
                taskUtils.EVENTS.FORCED_REFRESH.subscribe(this.refreshTaskList, this);

                //Listen for the event set the search term
                taskUtils.EVENTS.MODIFY_TASK_SEARCH_TERM.subscribe(function(eventName, eventData){
                    if (!this.isVisible()) {
                        return;
                    }

                    //add a wildcard
                    if (eventData) {
                        eventData = eventData + "*";
                    }
                    if(this.setSearchTerm(eventData)){
                    	this.refreshTaskList();
                    }
                }, this);

                //Listen for the event to set the filter conditions
                taskUtils.EVENTS.MODIFY_TASK_FILTER.subscribe(function(eventName, eventData){
                    //only reload if the filter has changed
                    if (this.setFilterConditions(eventData.filterCondition, eventData.filterWithoutDateProcess) === true) {
                    	this.refreshTaskList();
                    }
                }, this);

                taskUtils.EVENTS.SET_SAVED_SEARCH_SCOPE.subscribe(function(eventName, eventData){
                    //only reload if the filter has changed
                    if (this.setScopeCondition(eventData.filterCondition) === true) {
                    	this.refreshTaskList();
                    }
                }, this);

                //Listen for the event to set the filter conditions
                taskUtils.EVENTS.MODIFY_TASK_QUICK_FILTER.subscribe(function(eventName, eventData){
                    //only reload if the filter has changed
                    if (this.setQuickFilterConditions(eventData.filterCondition)) {
                    	this.refreshTaskList();
                    }
                }, this);

                taskUtils.EVENTS.MODIFY_TASK_COLUMNS.subscribe(function(eventName, eventData){
                    //only reload if the columns have changed
                    if (this.setSelectedColumns(eventData.columns) === true) {
                        this._instance.currentSort = null;
                        this._instance.updatedTaskCols = false;
                        this._instance.isNextTaskMode = false;
                        this._instance.ssLaunched = eventData.ss;
                        this.refreshTaskList();
                    }
                }, this);

                taskUtils.EVENTS.NUMBER_OF_TASK_CHANGED.subscribe(function(eventName, eventData){
                    this._instance.size = eventData;
                    this.refreshTaskList();
                }, this);

                taskUtils.EVENTS.SET_DEFAULT_STATS.subscribe(function(eventName){
                    if (this.setQuickFilterConditions("")) {
                    	this.refreshTaskList();
                    }
                }, this);
                taskUtils.EVENTS.SLIDEOUT_PANEL_CLOSE.subscribe(function () {
                    setTimeout(function() {
                        var filterButtonCtl = view._instance.savedSearchBuilderLauncher.context.element.querySelector('.SPARKIcon[role="button"]');
                        filterButtonCtl.blur();
                    });
                }, this);
                taskUtils.EVENTS.CLEAR_TASK_FILTERS.subscribe(function(eventName){
                    this._instance.selectedCols = [];
                    var defaultCol = taskUtils.DEFAULT_SELECTED_COLUMNS;
                        for(var i=0; i<defaultCol.length; i++){
                            var val = defaultCol[i]
                            if(val)
                                view._instance.selectedCols.push({name: val, value: taskUtils.getLabelFromTaskProperty(val)});
                        }
                    opts.columns.set("value",this._instance.selectedCols);
                    opts.searchFilters.set("value",view._instance.filterConditions);
                    opts.taskSortBy.set("value", {name: "taskDueDate", value: "none"});
                }, this);
                taskUtils.EVENTS.SORT_FROM_SS.subscribe(function(){
                    view._instance.sortFromSS = true;
                }, this);
                taskUtils.EVENTS.SORT_TASKLIST.subscribe(function(eventName, eventData){
                    view.onColumnSorting(null, eventData.field, eventData.order);
                }, this);
            }

            // Show loader
            taskUtils.EVENTS.TASKLIST_SHOW_LOADER.subscribe(function(){
                this._instance.taskTable.setVisible(false, true);
                this.reloadSkeletonTable();
            }, this);

            // Backup reload method when notification failed
            taskUtils.EVENTS.DELAY_RELOAD.subscribe(function () {
                if (!taskUtils.getNotificationExistence()) {
                    if (view._instance.delayReloadTimer) {
                        clearTimeout(view._instance.delayReloadTimer);
                    }

                    view._instance.delayReloadTimer = setTimeout(function () {
                        clearTimeout(view._instance.delayReloadTimer);
                        delete view._instance.delayReloadTimer;
                        view.refreshTaskList();
                    }, 1000);
                }
            }, this);

            // update next task mode
            taskUtils.EVENTS.SET_NEXT_TASK_MODE.subscribe(function(eventName, eventData) {
                view._instance.isNextTaskMode = eventData.isNextTaskMode;
                if (view._instance.isNextTaskMode) {
                    view._instance.paginationView.setVisible(false, true);
                } else {
                    view._instance.paginationView.setVisible(true, true);
                }
            }, this);

            taskUtils.EVENTS.LOAD_DEFAULT_SAVED_SEARCH.subscribe(function(eventName, eventData) {
                if (eventData.search) {
                    view.loadDefaultSavedSearch(eventData.search);
                }
            });
            
            taskUtils.EVENTS.LAUNCH_FROM_PREVIEW.subscribe(function() {
            	view._instance.addWorkflowButton.setVisible(false, true);
            });

            this.loadContainer(this);

            bpmext.log.info("TaskList.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try
            {
                utilities.handleVisibility(this.context);
            }
            catch (e)
            {
                //{#feature: US-1330 Added RT localization}
                //bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e, this);
                if(e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    //bpmext.log.error("  Call stack: " + e.stack);
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack), this);
                }
            }
        };

        this.constructor.prototype.change = function (event)
        {
            bpmext.log.info("TaskList.change ENTER >> (event): " + event, this);
            if (event.type === "config") {
                switch (event.property) {
                    case "_metadata.visibility": {
                        // make sure that the searchbar drop down close on visibility changes
                        this._instance.searchBar.closeSearchBar();
                        this._instance.launchInstanceLock = false;

                        if (this._instance.shouldReloadWhenVisible) {
                        	this.refreshTaskList();
                            this._instance.shouldReloadWhenVisible = false;
                        }
                        this.view();
                        break;
                    }
                    case "responsiveMode": {
                        if (event.oldVal !== event.newVal) {
                            this.isVisible() && this._proto._updateResponsiveness(this);
                        }
                        break;
                    }
                    case "taskLaunchEvent": {
                        this._proto._setTaskLaunchEvent(this);
                        break;
                    }
                    case "enableBatchModify": {
                        this._proto._enableBatchModify(this);
                        break;
                    }
                }
            }
            bpmext.log.info("TaskList.change ENTER >>", this);
        };

        this.constructor.prototype.unload = function ()
        {
            bpmext.ui.unloadView(this);
        };
    }
};