/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof DeleteSavedSearchModal
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof DeleteSavedSearchModal
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof DeleteSavedSearchModal
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof DeleteSavedSearchModal
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof DeleteSavedSearchModal
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof DeleteSavedSearchModal
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof DeleteSavedSearchModal
 * @method triggerFormulaUpdates
 */


/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>Triggers whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 * </table>
 */
workplace_control_InitDeleteSavedSearchModal = function (utilities, taskUtils, wpResources, domAttr)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
            _loadModal: function __loadModal(view){
                bpmext.log.info("DeleteSavedSearchModal.__loadModal LOG >>", view);
            }

        };


        /*
        Public control methods *************************************************************
         */

        /**
		 * @instance
		 * @memberof DeleteSavedSearchModal
		 * @method closeModal
		 * @desc Closes the modal dialog
		 */
        this.constructor.prototype.closeModal = function() {
			bpmext.log.info("DeleteSavedSearchModal.closeModal ENTER >> ",this);
            this._instance.modalSection.hide();
            this.hide();
			bpmext.log.info("DeleteSavedSearchModal.closeModal EXIT << ");
        };

        /**
		 * @instance
		 * @memberof DeleteSavedSearchModal
		 * @method deleteAction
		 * @desc Deletes the current saved search definition and closes the dialog
		 */
        this.constructor.prototype.deleteAction = function() {
            bpmext.log.info("DeleteSavedSearchModal.deleteAction ENTER >> ", this);
            var delSSId = this._instance.deletedSS;
            this._instance.searchResource.deleteSearch({id: delSSId}).then(function() {
                taskUtils.EVENTS.SAVED_SEARCH_DELETED.publish({savedSearch: delSSId});
            });

            this.closeModal();
			bpmext.log.info("DeleteSavedSearchModal.deleteAction EXIT << ");
        };
        /*
        Coach NG Lifecycle methods *************************************************************
         */
        this.constructor.prototype.load = function (){
            bpmext.log.info("DeleteSavedSearchModal.load ENTER >>", this);

            this._instance.searchResource = wpResources.searches;
            
            this._instance.modalSection = bpmext.ui.getContainer("DeleteSSModalSection", this);
            this._instance.modalSection.setPrimaryButtonText(bpmext.localization.formatMsg("savedSearchList", "delete"));
            this._instance.modalSection.setSecondaryButtonText(bpmext.localization.formatMsg("workplace", "cancel"));
            //CV in ModalSection
            this._instance.panel = bpmext.ui.getContainer("DeleteSSPanel", this);
            //CV in Panel
            this._instance.deleteSSMessage = bpmext.ui.getView("DeleteSSMessage", this);
            
            this._instance.modalSection._instance.modalDialog.ariaLabel = bpmext.localization.formatMsg("savedSearchList", "deleteDialogTitle");
            this._instance.panel.setTitle(bpmext.localization.formatMsg("savedSearchList", "deleteDialogTitle"));
            this._instance.deleteSSMessage.setLabel(bpmext.localization.formatMsg("savedSearchList", "deleteConfirm"));

            var panelHeaderIcon = this._instance.panel.context.element.querySelector("div.panel-heading-controls > div.panel-heading-icon > i");
            !!panelHeaderIcon && domAttr.remove(panelHeaderIcon, "tabindex");

			taskUtils.EVENTS.DELETE_SAVED_SEARCH.subscribe(function(eventName, eventData){
                this._instance.deletedSS = eventData.search;
                this._instance.panel.setTitle(bpmext.localization.formatMsg("savedSearchList", "deleteDialogTitle", eventData.display));
                !!this._instance.modalSection && this._instance.modalSection.show();
                this.show();
                taskUtils.setTabCycle(this);
			}, this);

            this.loadContainer(this);

            bpmext.log.info("DeleteSavedSearchModal.load EXIT >>", this);
        };

        this.constructor.prototype.view = function ()
        {
            try {
                utilities.handleVisibility(this.context);
            }
            catch (e){
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e, this);
                if(e.stack) {
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack), this);
                }
            }
        };

        this.constructor.prototype.change = function (event){
            bpmext.log.info("DeleteSavedSearchModal.change ENTER >> (event): " + event, this);
            bpmext.log.info("DeleteSavedSearchModal.change ENTER >>", this);
        };

        this.constructor.prototype.unload = function (){
            bpmext.log.info("DeleteSavedSearchModal.unload ENTER >> ", this);
            bpmext.ui.unloadContainer(this);
            bpmext.log.info("DeleteSavedSearchModal.unload ENTER >>", this);
        };
    }
};