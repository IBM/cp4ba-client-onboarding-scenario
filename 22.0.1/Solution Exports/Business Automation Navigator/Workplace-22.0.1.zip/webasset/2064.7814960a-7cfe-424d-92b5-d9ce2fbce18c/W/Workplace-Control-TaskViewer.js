/*************************************************************************
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019, 2022. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *************************************************************************/
/**
 * @ignore
 * @instance
 * @memberof TaskViewer
 * @method isValid
 */

/**
 * @ignore
 * @instance
 * @memberof TaskViewer
 * @method setValid
 */

/**
 * @ignore
 * @instance
 * @memberof TaskViewer
 * @method recalculate
 */

/**
 * @ignore
 * @instance
 * @memberof TaskViewer
 * @method getData
 */

/**
 * @ignore
 * @instance
 * @memberof TaskViewer
 * @method setData
 */

/**
 * @ignore
 * @instance
 * @memberof TaskViewer
 * @method propagateUpValueChange
 */

/**
 * @ignore
 * @instance
 * @memberof TaskViewer
 * @method triggerFormulaUpdates
 */

/**
 *   <tr class=Prop>
 *     <td class=SectionName colspan=3>Events</td>
 *   </tr>
 *   <tr class=Prop>
 *     <td>On Load:</td>
 *     <td colspan="2">
 *       <table>
 *         <tr class=Prop>
 *           <td>Description: </td>
 *           <td>This event is fired whenever the view is loaded.</td>
 *         </tr>
 *         <tr class=Prop>
 *           <td>Example: </td>
 *           <td><pre class="prettyprint"><code>console.log("View loaded")</code></pre></td>
 *         </tr>
 *       </table>
 *     </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On Task Opened:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when a task or service is opened in the viewer.</td>
 *               </tr>
 *           </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">data {object}</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">task or service data</td>
 *               </tr>
 *       </table>
 *     </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On Task Closed:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when the viewer is closed.</td>
 *               </tr>
 * </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *               </tr>
 *           </table>
 *       </td>
 *   </tr>
 *   <tr class=Prop>
 *       <td>On Task Action:</td>
 *       <td colspan="2">
 *           <table>
 *               <tr class=Prop>
 *                   <td>Description: </td>
 *                   <td>This event is fired when an action is triggered from the action menu.</td>
 *               </tr>
 * </table>
 *           <table style="border: 1px solid black; border-collapse: collapse; ">
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Context Variables</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">data {object}</th>
 *                   <th
 *                       style="border: 1px solid black; border-collapse: collapse; padding: 5px;">action {string}</th>
 *               </tr>
 *               <tr style="border: 1px solid black; border-collapse: collapse;">
 *                   <td rowspan="5"
 *                       style="border: 1px solid black; border-collapse: collapse;padding: 5px;">Properties</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">task or service data</td>
 *                   <td
 *                       style="color: black; font-weight: normal; border: 1px solid black; border-collapse: collapse;padding: 5px;">selected action</td>
 *               </tr>
 *       </table>
 *       </td>
 *   </tr>
 * </table>
 */
workplace_control_InitTaskViewer = function (utilities, taskUtils, resourceUtils, domClass, wpResources, domAttr)
{
    "use strict";
    this._instance =
    {
    };

    if (!this.constructor.prototype._proto)
    {
        this.constructor.prototype._proto =
        {
			EVT_ONTASK_OPENED : "eventON_TASK_OPENED",
			EVT_ONTASK_CLOSED : "eventON_TASK_CLOSED",
			EVT_SERVICE_OPENED : "eventON_SERVICE_OPENED",
			EVT_SERVICE_CLOSED : "eventON_SERVICE_CLOSED",

			MODE : {
				TASK : "TASK",
				SERVICE : "SERVICE"
			},

			VIEW_WORKSTREAM_CSHS_ID : "1.ef90b641-932c-4d08-85e7-a8d8f061cb85",

			_generateHistoryCallbacks: function _generateHistoryCallbacks (view, displayName, actionId) {
				var viewerObj = view._instance.viewerObj;
            	var viewerRestoreCallback = viewerObj.type === "PROCESS" ? taskUtils.EVENTS.TASK_LAUNCHED : taskUtils.EVENTS.SERVICE_LAUNCHED;

				var data = {};
				if (viewerObj.type === "PROCESS") {
					data = {
						tkiid: viewerObj.data.task.tkiid,
						systemID: viewerObj.data.task.systemID
					};
				} else {
					if (viewerObj.data.piid) {
						// launching from instance UI
						data = {
							piid: viewerObj.data.piid,
							systemID: viewerObj.data.systemID,
							type: viewerObj.data ? viewerObj.data.type : undefined
						};
					} else if (viewerObj.data.service) {
						//launching from startable service
						data = {
							itemID: viewerObj.data.service.itemID,
							systemID: viewerObj.data.systemID,
							type: viewerObj.type
						};
						if(viewerObj.data.service.isSnapshot) {
							data.snapshotID = viewerObj.data.service.snapshotID;
						}
					}
					
					if (viewerObj.data && data.type && data.type === wpResources.processes.TYPE.CASES) {
						data.runURL = viewerObj.data.runURL;
					}
				}
				if (actionId) {
					data.actionId = actionId;
				}

                var onViewRestore = function () {
                    viewerRestoreCallback.publish(viewerObj.data);
                };

				var onViewClose =  function(){
					return view.closeViewer();
				};

                return {
                    data: data,
					identifier: "TaskViewer(TYPE)".replace("TYPE", viewerObj.type),
					displayName: displayName,
                    onViewRestore: onViewRestore,
                    onViewClose: onViewClose
                };
            },

			_launchProcessInstanceUI: function(view, data) {
				var historyCallbacks = view._proto._generateHistoryCallbacks(view, data.name || data.PI_NAME || "Instance UI");
				//store the systemID in the history
				historyCallbacks.systemID = data.systemID;
				taskUtils.viewHistory.addToViewHistory(historyCallbacks);

				view.setServiceData(view, data);

				taskUtils.EVENTS.SERVICE_SHOWING_IN_VIEWER.publish();

				view.show();
			},

			_cleanUpFrame: function(view) {
				// replace the current iframe with a new one
				var newIframe = document.createElement("iframe");
				domAttr.set(newIframe, "id", view._instance.iframe.getAttribute("id"));
				domAttr.set(newIframe, "aria-hidden", "true");
				view._instance.iframe.parentNode.replaceChild(newIframe, view._instance.iframe);
				view._instance.iframe = newIframe;

				view._instance.taskViewerHeader.reset();
				domClass.remove(view._instance.iframe, "noHeader");

				if (!(view.context.options.showOnTaskClosed && view.context.options.showOnTaskClosed.get("value"))){
					view.hide(true);
				}

				taskUtils.EVENTS.VIEWER_CLOSED.publishSync();
			},

			_setIframeUrl: function (view, url){
				if(url){
					if(!view._instance.spinnerLoader.isVisible()){
						view._instance.spinnerLoader.show();
					}
					view._instance.iframe.src = url;
					setTimeout(dojo.hitch(view, view.checkIframeLoaded), 500);
				}
			}
        };

		/*
        Public control methods *************************************************************
         */
		/**
		 * @instance
		 * @memberof TaskViewer
		 * @method setTaskData
		 * @param {ANY} task The data to be set on Task Viewer.
		 * @param {ANY} businessData The data to be set on Task Viewer.
		 * @param {ANY} systemData The data to be set on Task Viewer.
		 * @desc Sets the task, businessData, and systemData of the view.
		 */
		this.constructor.prototype.setTaskData = function(view, task, businessData, systemData) {
			bpmext.log.info("TaskViewer.setData ENTER >> setting data to: ", task, businessData, systemData);
			var taskName = task.displayName || "Task";
			view._instance.spinnerLoader.show();
			if (task && task.systemID) {
                wpResources.systems.getFederationResults().then(function success(systems) {
                    if (task.runURL.indexOf("http") === 0) {
						view._proto._setIframeUrl(view, task.runURL + "#" + task.systemID);
                    } else {
                        view._proto._setIframeUrl(view, systems[task.systemID].endpoint + task.runURL + "#" + task.systemID);
					}
					domAttr.set(view._instance.iframe, "title", taskName);
					domAttr.set(view._instance.iframe, "aria-hidden", "false");
                });
            } else {
                view._proto._setIframeUrl(view, task.runURL.substring(task.runURL.indexOf(dojoConfig.App._bpmContextRootMap.teamworks)));
				domAttr.set(view._instance.iframe, "title", taskName);
				domAttr.set(view._instance.iframe, "aria-hidden", "false");
			}

			domClass.remove(view._instance.iframe, "ServiceViewer");

			bpmext.log.info("TaskViewer.setData EXIT << ");
		};

		/**
		 * @instance
		 * @memberof TaskViewer
		 * @method setServiceData
		 * @param {ANY} service The data to be set on the Task Viewer view.
		 * @desc Sets the service on the view.
		 */
		this.constructor.prototype.setServiceData = function(view, service) {
			bpmext.log.info("TaskViewer.setServiceData ENTER >> setting data to: ", service);
			var serviceName = service.displayName || "Services", iframeUrl;
            view._instance.mode = view._proto.MODE.SERVICE;
			view._instance.spinnerLoader.show();
			if(service && service.runURL) {
                view._proto._setIframeUrl(view, service.runURL);
			} else if (service && service.systemID) {
                wpResources.systems.getFederationResults().then(function success(systems) {
                    if (service.runURL.indexOf("http") === 0) {
                    	iframeUrl = service.runURL;
                    } else {
                        iframeUrl = systems[service.systemID].endpoint + service.runURL;
					}
                	view._proto._setIframeUrl(view, iframeUrl);
                });
            } else {
                view._proto._setIframeUrl(view, service.runURL.substring(service.runURL.indexOf(dojoConfig.App._bpmContextRootMap.teamworks)));
			}

			domAttr.set(view._instance.iframe, "title", serviceName);
			domAttr.set(view._instance.iframe, "aria-hidden", "false");
			domClass.add(view._instance.iframe, "ServiceViewer");
			bpmext.log.info("TaskViewer.setData EXIT << ");
		};

		/**
		 * @instance
		 * @memberof TaskViewer
		 * @method closeViewer
		 * @desc Closes the view.
		 */
        this.constructor.prototype.closeViewer = function(event) {
			bpmext.log.info("TaskViewer.closeViewer ENTER >> event: ", event);

            if (event && event.data && dojo.fromJson(event.data).name !== "onCompleted") {
                return;
			}

			if (!this.isVisible()) {
				return;
			}

            bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONTASK_CLOSED);

			//Needs a pub/sub with the child frame to determine whether to send an onClose and wait for an acknowledgement
			//Without an acknowledgement, the child iframe gets removed before the postMessage can be processed
			if (this._instance.requiresOnCloseAcknowledgement === true) {
				//send the current iframe an onClose event so that it can do any needed cleanup
				var childWindow;
				if (this._instance.iframe && this._instance.iframe.contentWindow) {
					childWindow = this._instance.iframe.contentWindow.frames[0];
					if (childWindow) {
						childWindow.postMessage(JSON.stringify({name: "onClose"}), "*");
					}

				}
			} else {
				this._proto._cleanUpFrame(this);
			}

			bpmext.log.info("TaskViewer.closeViewer EXIT << ");

			//returns true if the history navigation should be paused.
			return this._instance.requiresOnCloseAcknowledgement;
        };

        this.constructor.prototype.handleTaskAction = function(action) {
            bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONTASK_ACTION, this._instance.task, action);
        };

		this.constructor.prototype.checkIframeLoaded = function () {
			try{
				// Check if loading is complete or if timeout
				if (this._instance.iframeLoadedCheckCounter > 99 || this._instance.frameInitialized === true ) {
					this._instance.iframeLoadedCheckCounter = 0;
					this._instance.frameInitialized = false;
					this._instance.spinnerLoader.hide();
					return;
				} 
				this._instance.iframeLoadedCheckCounter ++;
				window.setTimeout(dojo.hitch(this, this.checkIframeLoaded), 500);
			}catch(error){
				this._instance.iframeLoadedCheckCounter = 0;
				this._instance.frameInitialized = false;
				this._instance.spinnerLoader.hide();
			}
		};
		/*
        Coach NG Load Lifecycle method *************************************************************
         */
        this.constructor.prototype.load = function ()
        {
			var opts = this.context.options, view = this;
            bpmext.ui.substituteConfigOption(this, "task", []);
			bpmext.ui.substituteConfigOption(this, "systemData", []);
			bpmext.ui.substituteConfigOption(this, "taskActions", []);
			bpmext.ui.substituteConfigOption(this, "showOnTaskClosed", false);
			if (!opts.enableHistoryNav) {
                bpmext.ui.substituteConfigOption(this, "enableHistoryNav", false);
            }

			this._instance.mode = this._proto.MODE.TASK;
			this._instance.dataCollapsiblePanel = bpmext.ui.getContainer("DataCollapsiblePanel", this);
			this._instance.businessDataList = bpmext.ui.getView("BusinessDataList", this);
			this._instance.systemDataList = bpmext.ui.getView("SystemDataList", this);
			this._instance.claimedTaskModal = bpmext.ui.getContainer("Claim_Task_Modal", this);
            this._instance.claimedTaskModal.setTargetEvents([taskUtils.EVENTS.TASK_CONFIRM_CLAIM]);
			this._instance.taskViewerHeader = bpmext.ui.getView("TaskViewerHeader", this);
			this._instance.workplaceNavigationBar = bpmext.ui.getView("Workplace_Navigation_Bar1", this);
			this._instance.closeIcon = bpmext.ui.getView("CloseIcon", this);
			this._instance.spinnerLoader = bpmext.ui.getView("SpinnerLoader", this);
			this._instance.frameInitialized = false;

            this.loadContainer(this);

            this._instance.iframe = this.context.element.querySelector("#launchTaskViewer");

			if(!opts.enableHistoryNav.get("value")){
				this._instance.workplaceNavigationBar.setVisible(false, true);
				this._instance.taskViewerHeader.showCloseButton();
			}

			window.addEventListener("message", dojo.hitch(this, function(event){
				var view = this;
				if (event && event.data){
                    var data = dojo.fromJson(event.data), viewHistory,
                        props = {
                            title: bpmext.localization.formatMsg("notifications", "notificationErrorTitle"),
                            style: "E",
                            timeout: 5000
                        };

                    if (data.name === "onError") {
                        if (data.parameters[1] === "tm_task_not_owned") {
                            props.text = bpmext.localization.formatMsg("workplace", "taskNotAuthorized");
                        } else if (data.parameters[1] === "tm_task_closed") {
                            props.text = bpmext.localization.formatMsg("workplace", "taskAlreadyCompleted");
                        } else if (data.parameters[0]) {
							props.text = data.parameters[0];
						}
                        if(view._instance.spinnerLoader.isVisible()){
    						view._instance.spinnerLoader.hide();
    					}
                        // Directly show the error message on task viewer page,no need close it, just like Portal
                        //taskUtils.publishAlert(props);
                        //taskUtils.EVENTS.CLOSE_TASK_VIEWER.publish();
                    } else if ((data.name === "onCompleted" || data.name === "onSuspended") && data.taskID !== undefined) { // services' taskID is null
                    	var nextTaskId = null, viewHistory = taskUtils.viewHistory.getViewHistory();
                    	var systemID = viewHistory[viewHistory.length-1].systemID;
                    	if(!this.context.options.enableHistoryNav.get("value")) {
							this.closeViewer();
						} else {
							taskUtils.viewHistory.loadViewFromHistory();
						}
                    	if (data.parameters && data.parameters.length > 0 && typeof data.parameters[0] === "string") {
                    		// if there is auto-flow next task defined, directly open it in task viewer
                            nextTaskId = data.parameters[0];
                            wpResources.task.get({tkiid: nextTaskId, includeURL: true, systemID: systemID}).then(function success(task) {
								taskUtils.EVENTS[view.isVisible() ? "TASK_CONFIRM_CLAIM" : "TASK_BEFORE_LAUNCH"].publish({task: task, systemData: null});
							});
        				} else {
    						taskUtils.EVENTS.DELAY_RELOAD.publish();
        				}
					} else if (data.name === "onInitialized") {
						this._instance.frameInitialized = true;
					} else if (data.name === "launchTask" && (data.task !== undefined || data.taskID !== undefined)) {
						if (data.task) {
							if (data.task.systemID === undefined) {
								//get the system id from the view history if it has been previously stored
								viewHistory = taskUtils.viewHistory.getViewHistory();
								data.task.systemID = viewHistory[viewHistory.length-1].systemID;
							}
							taskUtils.EVENTS[view.isVisible() ? "TASK_CONFIRM_CLAIM" : "TASK_BEFORE_LAUNCH"].publish({task: data.task, systemData: null});
						} else  {
							wpResources.task.get({tkiid: data.taskID, includeURL: true, systemID: data.systemID}).then(function success(task) {
								taskUtils.EVENTS[view.isVisible() ? "TASK_CONFIRM_CLAIM" : "TASK_BEFORE_LAUNCH"].publish({task: task, systemData: null});
							});
						}
					} else if (data.name === "launchWorkstream" && data.URLParam) {
						var options = {
							subtypes: ["url"]
						};

						wpResources.exposed.get(options).then(function(exposedData) {
							var exposedItems = exposedData.items || exposedData;
							for(var i=0; i < exposedItems.length; i++){
                                var item = exposedItems[i];
								if(item.itemID === view._proto.VIEW_WORKSTREAM_CSHS_ID) {
                                    item = JSON.parse(JSON.stringify(item));
									item.runURL = (item.runURL || item.startURL) + data.URLParam;
									item.startURL = item.runURL;

									taskUtils.EVENTS.SERVICE_LAUNCHED.publish({service: item});
									break;
							    }
							}
						});
					} else if (data.name === "closeAndLaunchTask" && data.taskID !== undefined) {
						//Close current view
						if(!this.context.options.enableHistoryNav.get("value")){
							this.closeViewer();
						}else{
							taskUtils.viewHistory.loadViewFromHistory();
						}

						//Launch task
						wpResources.task.get({tkiid: data.taskID, includeURL: true, systemID: data.systemID}).then(function success(task) {
							taskUtils.EVENTS.TASK_BEFORE_LAUNCH.publish({task: task, systemData: null});
						});
					} else if (data.name === "processesUpdated") {
						// TODO: catch a parameter from message call to trigger the delay updating (defect 341904)
						var startUpdating = false;

						if (startUpdating) {
							taskUtils.EVENTS.PROCESSES_UPDATING.publish({ms: 5000});
						} else {
							taskUtils.EVENTS.PROCESSES_UPDATED.publish();
						}
					} else if (data.name === "teamUpdated") {
						taskUtils.EVENTS.TEAM_UPDATED.publish();
					} else if (data.name === "modifyInstance") {
						taskUtils.EVENTS.MODIFY_INSTANCE_CLOSE.publish();
					} else if  (data.name === "viewInstance") {
						var curSystemInfo, runURLPrefix = dojoConfig.App._bpmContextRootMap.teamworks;

						//if the system id has not been provided, try to get the systemID from the current history object
						if (!data.systemID) {
							viewHistory = taskUtils.viewHistory.getViewHistory();
							data.systemID = viewHistory[viewHistory.length-1].systemID;
						}
						if(data.systemID) {
							curSystemInfo = resourceUtils.getFederatedSystemInfo(data.systemID);
							runURLPrefix = curSystemInfo.taskCompletionUrlPrefix;
						}
						data.runURL = runURLPrefix + "/launchInstanceUI?origin=workplace&instanceId=" + data.piid;
						data.name = data.displayName || data.name;
						taskUtils.EVENTS.SERVICE_LAUNCHED.publish(data);
					} else if  (data.name === "updateInstanceInfo") {
						var instance = data.instance;
						viewHistory = taskUtils.viewHistory.getViewHistory();
						if (instance && instance.name && viewHistory && viewHistory.length > 0) {
							if (viewHistory[viewHistory.length-1].displayName !== instance.name) {
								//update the instance name in the nav bar
								viewHistory[viewHistory.length-1].displayName = instance.name;
								this._instance.workplaceNavigationBar.resetView();
							}
						}
					} else if (data.name === "showURL") {
						//update the breadcrumb with the display name and set the iframe to the new URL
						var launchObj = {displayName: data.displayName,
										 runURL: data.runURL,
										 replaceExisting: data.replaceExistingWindow,
										 clearBreadcrumb: data.clearBreadcrumb
						};
						if (data.systemID && data.runURL && data.runURL.indexOf("http") !== 0) {
							wpResources.systems.getFederationResults().then(function success(systems) {
								var endpoint = "";
								if (systems[data.systemID]) {
									endpoint = systems[data.systemID].restUrlPrefix; 
									if (endpoint.lastIndexOf("/") === endpoint.length -1) {
										endpoint = endpoint.substring(0, endpoint.length-1);
									}
									if (data.runURL.indexOf("/") === 0) {
										data.runURL = data.runURL.substring(1, (data.runURL.length));
									}
									launchObj.runURL = endpoint + "/" + data.runURL;
								}
								taskUtils.EVENTS.SERVICE_LAUNCHED.publish({service:launchObj});			
							});
						} else {
							taskUtils.EVENTS.SERVICE_LAUNCHED.publish({service:launchObj});
						}
					}  else if (data.name === "closeAcknowledgement") {
						//the child windows has acknowledged the onclose event, so we can clean up the frame
						taskUtils.viewHistory.resumeRestore();
						this._proto._cleanUpFrame(this);
					} else if (data.name === "requireCloseAcknowledgement") {
						//indicates that the child window is requesting not to be closed until it returns an onClose acknowledgement
						this._instance.requiresOnCloseAcknowledgement = true;
					} else if (data.name === "copyLinkRequest") {
						taskUtils.copyToClipboard(null, taskUtils.getLink(this, data.data));
						taskUtils.publishAlert({title: bpmext.localization.formatMsg("workplace", "copied"), text: "", timeout: 3000});			
					}
				}
			}), false);

			bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONTASK_CLOSED);
			bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONTASK_OPENED);
            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_SERVICE_OPENED);
            bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_SERVICE_CLOSED);

			// get next task dashboard related properties
			wpResources.user.get().then(function(currentUser) {
				view._instance.isNextTaskMode = currentUser.showNextTaskDashboard;
				view._instance.returnTaskToTeamOnLogout = currentUser.returnTaskToTeamOnLogout;
			})

			taskUtils.EVENTS.TASK_LAUNCHED.subscribe(function(eventName, eventData){
				var task = eventData && eventData.task, businessData, systemData;

				this._instance.requiresOnCloseAcknowledgement = false;
				if(task){
					this._instance.viewerObj = {
						type: "PROCESS",
						data: eventData
					};

					var historyCallbacks = this._proto._generateHistoryCallbacks(this, task.displayName);
                    taskUtils.viewHistory.addToViewHistory(historyCallbacks);

					businessData = task && task.processData && task.processData.businessData;
					systemData = eventData && eventData.systemData;

					bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONTASK_OPENED, task);

					this.setTaskData(this, task, businessData, systemData);

					taskUtils.EVENTS.TASK_SHOWING_IN_VIEWER.publish();

					//Hide header when showing inline workstreams task
					var showTaskHeader = (taskUtils.Workstreams_InlineTasks.indexOf(task.serviceID) === -1);
					if (showTaskHeader === true) {
						domClass.remove(this._instance.iframe, "noHeader");
					} else {
						domClass.add(this._instance.iframe, "noHeader");
					}
					this._instance.taskViewerHeader.setVisible(showTaskHeader, true);

					this.show();
					if(this._instance.isNextTaskMode && this._instance.returnTaskToTeamOnLogout) {
						taskUtils.EVENTS.POTENTIAL_REASSIGN_BACK_TO_TEAM.publish({reassignTask: task});
					}
				} else {

					//THROW ERROR OR LOG
				}
			}, this);

			taskUtils.EVENTS.SERVICE_LAUNCHED.subscribe(function(eventName, eventData){
				var service = eventData && eventData.service,
					historyCallbacks ;
				var piid = eventData && (eventData.piid || eventData.PI_PIID);
				if (eventData && piid !== undefined) {
					eventData.piid = piid;
				}
				this._instance.requiresOnCloseAcknowledgement = false;
				if(service){
					this._instance.viewerObj = {
						type: "SERVICES",
						data: eventData
					};

                    historyCallbacks = this._proto._generateHistoryCallbacks(this, service.displayName || service.title || service.display, eventData.serviceActionId);
                    taskUtils.viewHistory.addToViewHistory(historyCallbacks, service.replaceExisting, service.clearBreadcrumb);

					bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONSERVICE_OPENED, service);

					this.setServiceData(this, service);

					taskUtils.EVENTS.SERVICE_SHOWING_IN_VIEWER.publish();

					this.show();

				} else if (eventData && piid !== undefined) {
					var ident = {piid: piid, systemID: eventData.systemID};
					var prevHistoryIndex = taskUtils.viewHistory.fetchHistoryIndexByIdentData(ident);

					if (prevHistoryIndex > -1) {
						return taskUtils.viewHistory.loadHistoryItem(prevHistoryIndex);
					}

					//show instance
					this._instance.viewerObj = {
						type: "SERVICES",
						data: eventData
					};
					this._proto._launchProcessInstanceUI(this, eventData);

				} else {
					//THROW ERROR OR LOG
				}
			}, this);

			taskUtils.EVENTS.CLOSE_TASK_VIEWER.subscribe(function () {
				if(!this.context.options.enableHistoryNav.get("value")){
					this.closeViewer();
				}else{
					taskUtils.viewHistory.loadViewFromHistory();
				}
			}, this);
			this.setVisible(false, true);
		};

        /*
        Coach NG VIew Lifecycle method *************************************************************
         */
        this.constructor.prototype.view = function ()
        {
            try
            {
                utilities.handleVisibility(this.context);
            }
            catch (e)
            {
                //{#feature: US-1330 Added RT localization}
                bpmext.log.error(bpmext.localization.formatMsg("general", "ERROR_ONVIEW_EVENT") + " [" + this.ui.getAbsoluteName() + "]: " + e);
                if(e.stack) {
                    //{#feature: US-1330 Added RT localization}
                    bpmext.log.error("  " + bpmext.localization.formatMsg("general", "CALL_STACK", e.stack));
                }
            }
        };

		/*
        Coach NG Unload Lifecycle method *************************************************************
         */
        this.constructor.prototype.unload = function ()
        {
            bpmext.ui.unloadView(this);
        };
    }
};