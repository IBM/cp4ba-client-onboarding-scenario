/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "Сынып",

		// Property list
		properties_file_name: "Файл аты",
		properties_file_save_in: "Сақтау",
		properties_add_file: "Файл қосу",
		properties_add_mvcp: "Қосу ${0}",
		properties_remove_mvcp: "${0} ішінен алып тастау",
		properties_use_file_name: "Файл аты осы сипат үшін қолданылады",

		properties_optional_label: "${0} (міндетті емес)",

		properties_document_or_folder_not_found: "Құжат немесе қалта табылмады.",
		properties_class_not_found: "Мазмұн сыныбы табылмады.",
		properties_folder_duplicate_item_invalid_prop: "Осындай атаумен элемент қалтада бұрыннан бар немесе сіз жарамсыз сипат мәнін енгіздіңіз.",
		properties_item_invalid_prop: "Сіз бір немесе бірнеше сипат үшін жарамсыз мән енгіздіңіз.",

		properties_invalid_long_value: "Бұл мән жарамсыз. Мән бүтін сан болу керек, мысалы, 5 немесе 1349.",
		properties_invalid_float_value: "Мән жарамсыз. Мән қалқыма нүкте мәні болу керек, мысалы, 1.2 немесе 365.",
		properties_min_value: "Ең кіші мән: ${0}",
		properties_max_value: "Ең үлкен мәні: ${0}",
		properties_max_length: "Ең үлкен ұзындығы: ${0}",
		properties_invalid_guid: "Мән жарамсыз. Мән Жаһандық Бірегей Анықтаушы (GUID) болуы тиіс, мысалы, {F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}.",
		properties_value_required: "Бұл мән талап етілген.",
		properties_unique_value_required: "Бұл мән бірегей болуы керек.",
		properties_file_required: "Файл қажет.",
		properties_invalid_folder_name: "Қалта атауы төмендегі таңбалардың ешқайсысын қамтымауы керек: \\ / : * ? \" < > |",

		properties_move_edit_confirm_msg: "Сіз келесі құжаттың сипаттарын өзгертудесіз<br>${0}<br><br>Өзгертулеріңізді сақтағыңыз келеді ме?",
		properties_move_edit_confirm_no: "Жоқ",
		properties_move_edit_confirm_yes: "Иә",
		properties_move_edit_confirm_title: "Растау",
		properties_edit_save_success: "Сипаттар сақталды",
		properties_edit_save_failure: "Сипаттар сақталмады",
		properties_no_item_selected: "Таңдалған элемент жоқ.",

		// Content list
		contlist_column_spec_title: "Тақырып",
		contlist_column_spec_name: "Аты",
		contlist_column_spec_version_label: "Нұсқа",
		contlist_column_spec_modified_by: "Арқылы өзгертілген",
		contlist_column_spec_mod_date: "Соңғы өзгертілген",
		contlist_column_spec_created_by: "Жасаған",
		contlist_column_spec_creation_date: "Жасалған",
		contlist_column_spec_mime_type: "Құжат Түрі",
		contlist_column_spec_size: "Өлшем",
		contlist_column_spec_thumbnail: "Нобай",

		contlist_paging_no_more_items: "Басқа элементтер жоқ",
		contlist_paging_of_at_least_items: "Кемінде ${1} элементтің ${0}",
		contlist_paging_of_items: "${1} элементтердің ${0}",
		contlist_paging_items: "${0} элементтері",
		contlist_paging_items_per_page: "Бір беттегі элементтер: ${0}",

		contlist_checked_out: "Бөліп алынған:",
		contlist_checked_out_by: "${0} элементімен тексерілген",

		contlist_size_units_B: "B",
		contlist_size_units_KB: "КБайт",
		contlist_size_units_MB: "MB",
		contlist_size_units_GB: "ГБайт",
		contlist_size_units_TB: "TB",

		contlist_missing_server_error: "Сервер көрсетілмеген.",
		contlist_invalid_server_error: "'{0}' сервері жоқ.",
		contlist_error_retrieving_doc_props: "Құжат сипаттарын алу кезінде қате пайда болды.",
		contlist_error_retrieving_folder_props: "Қалта сипаттарын шығарып алу кезінде қате пайда болды.",
		contlist_checkout_failed: "Құжат тексерілмеді",
		contlist_cancel_checkout_failed: "Тіркеуден бас тарту сәтсіз аяқталды",
		contlist_rename_folder_failed: "Қалтаның атын өзгерту мүмкін болмады.",
		contlist_folder_name_not_unique: "Қалтаның атауы ерекше болуы керек.",
		contlist_delete_object_failed: "Нысанды жою мүмкін емес.",
		contlist_display_properties_failed: "Сипаттар көрсетілмеді. ${0}",
		contlist_save_props_failed: "Сипаттарды сақтау мүмкін болмады",
		contlist_upload_failed: "Нұсқаны жүктеу мүмкін болмады",
		contlist_add_folder_failed: "Қалтаны қосу мүмкін болмады. ${0}",
		contlist_add_document_failed: "Құжатты қосу мүмкін болмады. ${0}",
		contlist_search_failed: "Іздеу нәтижелерін шығару мүмкін болмады",
		contlist_folder_containees_failed: "Қалтаның мазмұнын шығару мүмкін болмады",
		contlist_delete_folder_referenced: "Қалтаны жою мүмкін емес, өйткені оның ішінде ішкі қалталар бар.",
		contlist_docs_not_added: "Келесі құжаттарды қосу мүмкін болмады: ${0}",

		contlist_checkout_success: "Құжат тексерілді",
		contlist_delete_success: "Нысан жойылды",
		contlist_rename_folder_success: "Қалтаның атауы өзгертілді",
		contlist_save_props_success: "Сипаттар сақталды",
		contlist_cancel_checkout_success: "Тексеру сәттілігінен бас тарту",
		contlist_upload_version_success: "Нұсқа жүктелді",
		contlist_add_folder_success: "Қалта қосылды",
		contlist_add_doc_success: "Құжат қосылды",
		contlist_add_docs_success: "Құжаттар қосылды",

		contlist_menu_action_open: "Ашу",
		contlist_menu_action_rename: "Қайта атау",
		contlist_menu_action_properties: "Сипаттар",
		contlist_menu_action_view: "Көрініс",
		contlist_menu_action_download: "Жүктеу",
		contlist_menu_action_checkout: "Шығарып алу",
		contlist_menu_action_edit_document: "Құжатты өңдеу",
		contlist_menu_action_cancel_checkout: "Тексеруден бас тарту",
		contlist_menu_action_delete_doc: "Құжатты жою",
		contlist_menu_action_rename_folder: "Қалтаны қайта атау",
		contlist_menu_action_add_folder: "Қалтаны қосу",
		contlist_menu_action_delete_folder: "Қалтаны жою",
		contlist_menu_action_add_doc: "Құжат қосу",
		contlist_menu_action_upload: "Жаңа нұсқасын жүктеңіз",

		contlist_document_properties: "Құжат сипаттары",
		contlist_folder_properties: "Қалта сипаттары",
		contlist_folder_name: "Қалта аты",

		contlist_cancel_btn_label: "Болдырмау",
		contlist_add_btn_label: "Қосу",
		contlist_ok_btn_label: "Ok",
		contlist_edit_btn_label: "Өңдеу",
		contlist_save_btn_label: "Сақтау",
		contlist_upload_btn_label: "Жүктеп салу",
		contlist_refresh_btn_label: "Жаңарту",
		contlist_next_btn_label: "Келесі",
		contlist_previous_btn_label: "Алдыңғы",

		contlist_delete_folder_confirm: "${0} қалтасын жойғыңыз келеді. Жалғастырғыңыз келеді ме?",
		contlist_delete_doc_confirm: "${0} құжатын жойғалы жатырсыз. Жалғастырғыңыз келеді ме?",

		contlist_no_mimetype: "Бұл элементтің құрамында мазмұн жоқ.",
		contlist_folder_mimetype: "Қалта",

		contlist_filter_search_hint: "Құжаттарды іздеу",
		contlist_filter_folder_hint: "Сүзгілер тізімі",

		contlist_root_folder: "Түбірлік қалта",
		contlist_drop_folder_error: "Сіз қалталарды қоса алмайсыз. Тек файлдарды таңдаңыз.",
		contlist_add_in_process: "Басқа құжатты қоспас бұрын алдыңғы құжатты қосу аяқталғанша күте тұрыңыз.",
		contlist_add_doc_max_exceeded: "Сіз бір уақытта ${0} элементке дейін қоса аласыз. ${1} элементтерді қосуға тырысыңыз.",
		contlist_progress_success: "Сәтті",
		contlist_progress_alert: "Ескерту",
		contlist_progress_error: "Қате",
		contlist_progress_uploading: "Жүктеу",
		contlist_progress_processing: "1 файлды өңдеу",
		contlist_progress_uploading_text: "1 файл жүктелуде",
		contlist_progress_upload_failed: "Мәселе туындады",
		contlist_progress_close: "Жабу",
		progress_ind_uploaded_status: "Жүктелген",
		progress_ind_uploaded: "1 файл жүктелді",
		progress_ind_uploaded_error: "Өңдеу басталмады",		
		progress_ind_processing_status: "Орындалу барысында",
		progress_ind_processing_err: "Мәселе туындады",
		progress_ind_processed: "1 файл өңделді",	
		progress_ind_failed: "Сәтсіз",
		progress_ind_review_doc: "Review required",	
		progress_ind_updating: "1 файл жаңартылуда",
		progress_ind_updating_status: "Жаңарту",
		progress_ind_update_err: "Мәселе туындады",
		progress_ind_timeout: "Бақылау уақыты аяқталды",
		progress_ind_refresh: "Жаңарту",

		getcontent_ret_versions_error: "Нұсқалар сериясын шығару сәтсіз аяқталды",
		getcontent_ret_properties_error: "Құжат сипаттарын алу сәтсіз аяқталды",

		contentviewer_test_mode: "Қарау құралы алдын-ала қарау режимінде құжаттарды көрсетпейді. Сіз IBM Navigator жұмыс үстелі бағдарламасында жұмыс істеуіңіз керек.",

		thumbnail_retreival_error: "Нобай кескінін шығару сәтсіз аяқталды.",

		status_10: "Жүктелген",
		status_20: "Орындалу барысында",
		status_25: "Өңдеу",
		status_30: "Review required",
		status_40: "Жаңарту",
		status_900: "Өңдеу қатесі",
		status_910: "Жаңарту қатесі",

		/*do not remove this line*/nop: null
});
