/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019 - 2020. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */
/*
*	To include localized messages:
*	1. Add this file to your view in the Included Scripts section of the Behavior tab.
*	2. Add "CS-Messages" to the AMD section and map it to a meaningful name (like "messages").
*	3. Include the mapped name in the call to intialize your view along with other AMD dependencies.
*/

require({
    packages: [{
		name: "CS-Messages",
		location: com_ibm_bpm_coach.getManagedAssetUrl("CS-Messages.zip", com_ibm_bpm_coach.assetType_WEB, "SYSCST")
	}]
});	
