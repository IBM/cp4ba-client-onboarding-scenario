/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2020. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */
 
cs_InitQuery = function(bpmext, cookie, dateStamp)
{
	this._instance =
	{
		serverConfigurationName: "GRAPHQL_APP_RESOURCE",
		objectStoreName: "",
		searchFor: "",
		searchType: "",
		searchProperty: "",
		searchOperator: "",
		searchValues: [],
		searchPropertyType: "",
		searchPropertyCardinality: "",
		sortProperty: "",
		sortOrder: "",
		maxResults: 0,
		resultProperties: [],
		executeOnView: false,
		executeOnChange: false,
		filterPropertyValues: [],	
		searchSvc: null
	};

	if (!this.constructor.prototype._proto)
	{
		this.constructor.prototype._proto = {
			searchTypes: {
				TYPE_DOCUMENT: "Document",
				TYPE_FOLDER: "Folder",
				TYPE_ABSTRACT: "Abstract"
			},
			
			EVT_ONRESULT: "eventON_RESULT",
			EVT_ONERROR: "eventON_ERROR",

			_callService: function(service, params) {
				// Create ecm token as a large random number
				var csrfToken = Math.floor(Math.random() * 10000000);
				console.log("CS-Query:_callService() : Ecm token: " + csrfToken);

				// Add the required token value to the service params
				params.csrfToken = csrfToken;
				service.execute(params);
			},
			
			_getSearchResults: function(view) {		
				// Get the specified operator first and check if its one that does not require a value to be entered
				var operatorLowerCase;
				if (view._instance.searchOperator != null) {
					operatorLowerCase = view._instance.searchOperator.toLowerCase();
					if (operatorLowerCase == "is null") {
						valueRequired = false;
					} else if (operatorLowerCase == "is not null") {
						valueRequired = false;
					}
				} else {
					console.log("CS-Query:_getSearchResults() : Property search no operator configured.");
				}

				var searchProperties = [];
				
				var propertyLowerCase;
				if (view._instance.searchProperty != null) {
					propertyLowerCase = view._instance.searchProperty.toLowerCase();
					var searchValues = view._instance.searchValues.items ? view._instance.searchValues.items : view._instance.searchValues;
					for (var i = 0; i < searchValues.length; i++){
						var searchValue = searchValues[i];
						var searchProperty = this._createSearchProperty(view, view._instance.searchProperty, searchValue, view._instance.searchOperator.toLowerCase(), view._instance.searchPropertyCardinality,
							view._instance.searchPropertyType);
							
						if (searchValues.length > 1) {
							if (searchProperties.length == 0) {
								searchProperty.lparen = true;
							} else if (searchProperties.length == searchValues.length - 1) {
								searchProperty.rparen = true;
							}
						}

						if (i < searchValues.length - 1) {
							searchProperty.logical = "OR";
						}
						searchProperties.push(searchProperty);
					}
				}
				else {
					console.log("CS-Query:_getSearchResults() : Search property is null");
				}
				
				if (searchProperties.length > 0 && view._instance.filterPropertyValues.length > 0){
					searchProperties[searchProperties.length -1].logical = "AND";
				}
				
				for (var j = 0; j < view._instance.filterPropertyValues.length; j++){
					var filteredPropertyValue = view._instance.filterPropertyValues[j];
					var searchProperty = this._createSearchProperty(view, filteredPropertyValue.name, filteredPropertyValue.value, filteredPropertyValue.operator.toLowerCase(), filteredPropertyValue.cardinality.toUpperCase(),
							filteredPropertyValue.dataType.toLowerCase());
	
					if (j < view._instance.filterPropertyValues.length - 1) {
						searchProperty.logical = "AND";
					}	
					searchProperties.push(searchProperty);					
				}
						
				// See if there has been a order by property specified in the config settings
				var orderByProperty;
				if (view._instance.sortProperty != null && view._instance.sortProperty != "") {
					orderByProperty = sortProperty;
				}
				if (orderByProperty == "Name" || orderByProperty == "name") {
					orderByProperty = "DocumentTitle";
				}

				var params = {
					pageSize: view._instance.maxResults,
					countLimit: view._instance.maxResults.toString(),
					searchFolderId: null,
					searchOnlyFolder: false,
					searchFor: view._instance.searchFor,
					searchType: view._instance.searchType,
					searchProperty: propertyLowerCase,
					searchOperator: operatorLowerCase,
					searchValue: searchValue,
					searchPropertyType: view._instance.searchPropertyType,
					searchProperties: searchProperties,
					orderByProperty: orderByProperty,
					order: view._instance.sortOrder,
					properties: view._instance.resultProperties.items ? view._instance.resultProperties.items : view._instance.resultProperties,
					ovpProperties: [],
					repository: view._instance.objectStoreName,
					serverAppResource: view._instance.serverConfigurationName
				};
				
				this._callService(view._instance.searchSvc, params);
			},
			
			_createSearchProperty(view, propertyName, searchValue, operator, propertyCardinality, dataType){
						
				// When property data type is string, need to convert to lower case (later on)
				var propertyLowerCase = propertyName;
				var orderByProperty;
				var checkDataType = true;
				var operatorLowerCase;
				var addNotOperator = false;
								
				if (operator != null) {
					// Check to see if a multi-value operator has been specified (assume mvcp property too)
					operatorLowerCase = operator.toLowerCase();
					if (operatorLowerCase == "intersects") {
						// Todo: not in operator choice list
						searchValue = this._modifyIncludeAnyValueSearchValue(view, searchValue);
						orderByProperty = "DocumentTitle"; // Can't orderBy on mvcp properties
						checkDataType = false;
					} else if (operatorLowerCase == "in") {
						// Todo: not in operator choice list
						searchValue = this._modifyIncludeAnyValueSearchValue(view, searchValue);
						orderByProperty = "DocumentTitle"; 
						checkDataType = false;
					} else if (operatorLowerCase == "include any") {
						searchValue = this._modifyIncludeValueSearchValue(view, searchValue, "Or");
						propertyLowerCase = "";
						operatorLowerCase = "";
						orderByProperty = "DocumentTitle"; 
						checkDataType = false;
					} else if (operatorLowerCase == "include all") {
						searchValue = this._modifyIncludeValueSearchValue(view, searchValue, "And");
						propertyLowerCase = "";
						operatorLowerCase = "";
						orderByProperty = "DocumentTitle"; 
						checkDataType = false;
					} else if (operatorLowerCase == "is null") {
						searchValue = "";
						orderByProperty = "DocumentTitle"; // Can't orderBy on mvcp properties
						checkDataType = false;
					} else if (operatorLowerCase == "is not null") {
						searchValue = "";
						orderByProperty = "DocumentTitle"; // Can't orderBy on mvcp properties
						checkDataType = false;
					} else if (operatorLowerCase == "like") {
						// If 'like' operator specified (or default set in action), add '%' if not already specified
						searchValue = this._addSearchValueWildCardChars(searchValue, true, true);
					} else if (operatorLowerCase == "starts with") {
						// If 'starts with' operator specified, change it into like and add '%' at the end
						operatorLowerCase = "like";
						searchValue = this._addSearchValueWildCardChars(searchValue, false, true);
					} else if (operatorLowerCase == "ends with") {
						// If 'ends with' operator specified, change it into like and add '%' at beginning
						operatorLowerCase = "like";
						searchValue = this._addSearchValueWildCardChars(searchValue, true, false);
					} else if (operatorLowerCase == "not like") {
						// 'not like' needs to be burst apart into a 'not' prefix and a 'like' operator
						operatorLowerCase = 'like';
						searchValue = this._addSearchValueWildCardChars(searchValue, true, false);
						addNotOperator = true;
					} else if (operatorLowerCase == "exclude all") {
						if (propertyCardinality == "SINGLE") {
							// 'exclude all' needs to be burst apart into a 'not' prefix and a 'in' operator
							operatorLowerCase = 'in';
							searchValue = this._modifyIncludeAnyValueSearchValue(view, searchValue);
							checkDataType = false; // Will not add "LOWER" macro
							addNotOperator = true;
						} else {
							// Using 'Or' operator here to match what ICN does... seems like it should really be an 'And'
							searchValue = this._modifyIncludeValueSearchValue(view, searchValue, "Or");
							propertyLowerCase = "";
							operatorLowerCase = "";
							orderByProperty = "DocumentTitle"; 
							checkDataType = false;
							addNotOperator = true;
						}
					}
				} else {
					// If operator is null, will default to 'like'
					searchValue = this._addSearchValueWildCardChars(searchValue, true, true)							
				}
						
				if (propertyCardinality == "LIST") {
					orderByProperty = "DocumentTitle"; // Can't orderBy on mvcp properties
				}
									
				if (checkDataType) {
					if (dataType == "string") {
						searchValue = this._modifyStringSearchValue(searchValue);
						if (operatorLowerCase != "is null" && operatorLowerCase != "is not null") {
							propertyLowerCase = "LOWER(" + propertyName + ")";
						}
					} else if (dataType == "date") {
						searchValue = this._modifyDateTimeSearchValue(searchValue, true);
					} else if (dataType == "guid") {
						searchValue = this._modifyGUIDSearchValue(searchValue);
					}
				}
								
				if (addNotOperator) {
					// Need to add the not opeartor at front of where clause
					propertyLowerCase = "Not ( " + propertyLowerCase;
					searchValue = searchValue + " )";
				}
						
				var searchProperty = {
					property: propertyLowerCase,
					operator: operatorLowerCase,
					value: searchValue,
					dataType: dataType
				};
						
				return searchProperty
			},
			
			_modifyIncludeAnyValueSearchValue: function(view, searchValue) {
				// Need to make sure string values have ' around each value
				var searchValueEnhanced = "(";
				var words = searchValue.split(",");
				if (words.length > 0) {
					for (var i = 0; i < words.length; i++) {
						var word = words[i];
						if (word != null && word != "") {
							var wordTrimmed = word.trim();
							if (view._instance.searchPropertyType == "string") {
								// Check first to see if words have surrounding tic's (if not add them)
								if (!wordTrimmed.startsWith("'")) {
									wordTrimmed = "'" + wordTrimmed;
								}
								if (!wordTrimmed.endsWith("'")) {
									wordTrimmed = wordTrimmed + "'";
								}
								searchValueEnhanced = this._addIncludeAnySearchValue(i, searchValueEnhanced, wordTrimmed);
							} else if (view._instance.searchPropertyType == "date") {
								var searchDateStr = this._modifyDateTimeSearchValue(wordTrimmed, false);
								searchValueEnhanced = this._addIncludeAnySearchValue(i, searchValueEnhanced, searchDateStr);
							} else if (view._instance.searchPropertyType == "guid") {
								var searchGuid = this._modifyGUIDSearchValue(wordTrimmed);
								searchValueEnhanced = this._addIncludeAnySearchValue(i, searchValueEnhanced, searchGuid);								
							} else if (view._instance.searchPropertyType == "integer" || view._instance.searchPropertyType == "decimal") {
								if (!isNaN(wordTrimmed)) {
									searchValueEnhanced = this._addIncludeAnySearchValue(i, searchValueEnhanced, wordTrimmed);
								}
							} else {
								// Boolean
								searchValueEnhanced = this._addIncludeAnySearchValue(i, searchValueEnhanced, wordTrimmed);
							}
						}
					}
				}
				searchValueEnhanced += ")";
				return searchValueEnhanced;
			},

			_addIncludeAnySearchValue: function(i, searchValueEnhanced, searchValue) {
				if (searchValue != null) {
					if (i != 0) {
						searchValueEnhanced += ", ";
					}
					searchValueEnhanced += searchValue;
				}
				return searchValueEnhanced;
			},
			
			_modifyIncludeValueSearchValue: function(view, searchValue, anyall) {
				// Need to make sure string values have ' around each value
				var searchValueEnhanced = "";
				var words = searchValue.split(",");
				if (words.length > 0) {
					for (var i = 0; i < words.length; i++) {
						var word = words[i];
						if (word != null && word != "") {
							var wordTrimmed = word.trim();
							if (view._instance.searchPropertyType == "string") {
								// Check first to see if words have surrounding tic's (if not add them)
								if (!wordTrimmed.startsWith("'")) {
									wordTrimmed = "'" + wordTrimmed;
								}
								if (!wordTrimmed.endsWith("'")) {
									wordTrimmed = wordTrimmed + "'";
								}
								searchValueEnhanced = this._addIncludeSearchValue(searchValueEnhanced, wordTrimmed, view._instance.searchProperty, anyall);
							} else if (view._instance.searchPropertyType == "date") {
								var searchDateStr = this._modifyDateTimeSearchValue(wordTrimmed, false);
								searchValueEnhanced = this._addIncludeSearchValue(searchValueEnhanced, searchDateStr, view._instance.searchProperty, anyall);
							} else if (view._instance.searchPropertyType == "guid") {
								var searchGuid = this._modifyGUIDSearchValue(wordTrimmed);
								searchValueEnhanced = this._addIncludeSearchValue(searchValueEnhanced, searchGuid, view._instance.searchProperty, anyall);
							} else if (view._instance.searchPropertyType == "integer" || view._instance.searchPropertyType == "decimal") {
								if (!isNaN(wordTrimmed)) {
									searchValueEnhanced = this._addIncludeSearchValue(searchValueEnhanced, wordTrimmed, view._instance.searchProperty, anyall);
								}
							} else {
								// Boolean
								searchValueEnhanced = this._addIncludeSearchValue(searchValueEnhanced, wordTrimmed, view._instance.searchProperty, anyall);
							}
						}
					}
				}
				return searchValueEnhanced;
			},
			
			_addIncludeSearchValue: function(searchValueEnhanced, searchValue, property, anyall) {
				if (searchValue != null) {
					if (searchValueEnhanced != "") {
						searchValueEnhanced += " " + anyall + " ";
					}
					searchValueEnhanced += searchValue + " In " + property + " ";
				}
				return searchValueEnhanced;
			},
			
			_isValidDate: function(d) {
				return d instanceof Date && !isNaN(d);
			},
		
			_modifyStringSearchValue: function(searchValue) {
				// Add ' around search value (for graphql), for string type properties
				// Note: Converting property values and query string to lower case for case-insensitive queries by default
				if (searchValue != null && searchValue != "") {
					searchValue = "LOWER('" + searchValue + "')";
				}
				return searchValue;
			},
			
			_modifyDateTimeSearchValue: function(searchValue, obfuscate) {
				// If there is no time part of the date, treat as a date-only search.
				var regExp = /\b([01]\d|2[0-3]):[0-5]\d:[0-5]\d\b/g;
				var isDateOnly = (!searchValue.match(regExp));
				
				// Date properties need to be converted to ISO format for graphql
				var searchDate = new Date(searchValue);
				if (this._isValidDate(searchDate)) {
					if (isDateOnly){
						searchDate.setHours(12);
						var timezoneOffset = searchDate.getTimezoneOffset();
						searchDate.setMinutes(-timezoneOffset, 0, 0);
					}
					var searchDateStr = dateStamp.toISOString(searchDate, {
						milliseconds: true
					});	
					if (obfuscate) {
						// Todo: adding characters so the Studio's "execute" function will not change the date format (is a string but still gets modified)
						// The extra characters will get sliced off in the service action code before sending request to graphql
						searchValue = "&&" + searchDateStr;
					} else {
						searchValue = searchDateStr;
					}
				} else {
					searchValue = null;
				}
				return searchValue;
			},
		
			_modifyGUIDSearchValue: function(searchValue) {
				searchValue = searchValue.trim(); // remove white space at both ends
				if (!searchValue.startsWith("{")) {
					searchValue = "{" + searchValue;
				}
				if (!searchValue.endsWith("}")) {
					searchValue = searchValue + "}";
				}
				return searchValue;
			},
			
			_addSearchValueWildCardChars: function(searchValue, atBeginning, atEnd) {
				var value = searchValue;
				if (atBeginning) {
					if (!value.startsWith("%")) {
						value = "%" + value;
					}
				}
				if (atEnd) {
					if (!value.endsWith("%")) {
						value = value + "%";
					}
				}
				return value;
			}
		};
		
		/*
		 * Private methods and event handlers *************************************************************
		 */
		this.constructor.prototype._onSearchResultsResult = function(view, response){
//			console.log("CS-Query:_onSearchResultsResult() : called: " + JSON.stringify(results));
			bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONRESULT, response.results);
		};

		 this.constructor.prototype._onSearchResultsError = function(view, error){
			console.log("CS-Query:_onSearchResultsError() : called: " + JSON.stringify(error));
			bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONERROR, error);
		};
		 
		/*
		 * Public control methods *************************************************************
		 */
	
		/**
         * @instance
         * @memberof CS-Query
         * @method setObjectStoreName
		 * @param objectStoreName Name of the object store.
         * @desc Sets the name of the object store that will be searched.
         */
		this.constructor.prototype.setObjectStoreName = function(objectStoreName) {
			this._instance.objectStoreName = objectStoreName;
		};
		
		/**
         * @instance
         * @memberof CS-Query
         * @method executeSearch
         * @desc Executes the configured search and fires an event when the search results are returned.
         */
		this.constructor.prototype.executeSearch = function() {
			this._proto._getSearchResults(this);
		};
		
		/**
         * @instance
         * @memberof CS-Query
         * @method addFilterPropertyValue
		 * @param name Symbolic name (id) of the property you are referencing.
		 * @param value value of the property to use.
		 * @param operator The search operator to use
		 * @param dataType The data type of the property (String, Integer, Guid, Date, Decimal, or Boolean)
		 * *param cardinality The cardinality of the property (Single or List))
         * @desc Adds an additional filter criteria that will be ANDed to the configured values.
         */
		this.constructor.prototype.addFilterPropertyValue = function(name, value, operator, dataType, cardinality) {	
			console.log("CS-Query:addFilterPropertyValue() : called for property: " + name + " value: " + value);
			if (name != null && value != null) {
				this._instance.filterPropertyValues.push({
					name: name,
					value: value,
					operator: operator,
					dataType, dataType,
					cardinality: cardinality
				});
			}
		};
		
		/*
		 * Coach NG Lifecycle methods *************************************************************
		 */
		 
		this.constructor.prototype.load = function() {
			console.log("CS-Query:load() : called");
	
			try	{
				var opts = this.context.options;

				if (!opts.objectStoreName) {
                    opts.objectStoreName = bpmext.ui.substituteConfigOption(this, "objectStoreName", null);
				}
				this._instance.objectStoreName = opts.objectStoreName.get("value");
				
				if (!opts.searchFor) {
					opts.searchFor = bpmext.ui.substituteConfigOption(this, "searchFor", this._proto.searchTypes.TYPE_DOCUMENT);
				}	
				this._instance.searchFor = opts.searchFor.get("value");
				
				if (!opts.searchType) {
					opts.searchType = bpmext.ui.substituteConfigOption(this, "searchType", null);
				}	
				this._instance.searchType = opts.searchType.get("value");
				
				if (!opts.searchProperty) {
					opts.searchProperty = bpmext.ui.substituteConfigOption(this, "searchProperty", null);
				}
				this._instance.searchProperty = opts.searchProperty.get("value");
				
				if (!opts.searchOperator) {
					opts.searchOperator = bpmext.ui.substituteConfigOption(this, "searchOperator", null);
				}
				this._instance.searchOperator = opts.searchOperator.get("value");
				
				if (!opts.searchValues) {
					opts.searchValues = bpmext.ui.substituteConfigOption(this, "searchValues", []);
				}
				this._instance.searchValues = opts.searchValues.get("value");
				
				if (!opts.searchPropertyType) {
					opts.searchPropertyType = bpmext.ui.substituteConfigOption(this, "searchPropertyType", "string");
				}
				this._instance.searchPropertyType = opts.searchPropertyType.get("value");
				
				if (!opts.searchPropertyCardinality) {
					opts.searchPropertyCardinality = bpmext.ui.substituteConfigOption(this, "searchPropertyCardinality", "SINGLE");
				}
				this._instance.searchPropertyCardinality = opts.searchPropertyCardinality.get("value");		

				if (!opts.sortProperty) {
					opts.sortProperty = bpmext.ui.substituteConfigOption(this, "sortProperty", null);
				}
				this._instance.sortProperty = opts.sortProperty.get("value");	
				
				if (!opts.sortOrder) {
					opts.sortOrder = bpmext.ui.substituteConfigOption(this, "sortOrder", null);
				}
				this._instance.sortOrder = opts.sortOrder.get("value");
				
				if (!opts.maxResults) {
					opts.maxResults = bpmext.ui.substituteConfigOption(this, "maxResults", 0);
				}
				this._instance.maxResults = opts.maxResults.get("value");
				
				if (!opts.resultProperties){
					opts.resultProperties = bpmext.ui.substituteConfigOption(this, "resultProperties", []);
				}
				this._instance.resultProperties = opts.resultProperties.get("value");
				
				if (!opts.executeOnView) {
					opts.executeOnView = bpmext.ui.substituteConfigOption(this, "executeOnView", false);
				}
				this._instance.executeOnView = opts.executeOnView.get("value");
				
				if (!opts.executeOnChange) {
					opts.executeOnChange = bpmext.ui.substituteConfigOption(this, "executeOnChange", false);
				}
				this._instance.executeOnChange = opts.executeOnChange.get("value");
				
				this._instance.searchSvc = this.ui.get("SearchSvc");				
				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONRESULT, "results");
				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONERROR, "message");
			} catch (e) {
				bpmext.log.error("Error on load event [" + this.context.viewid + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};

		this.constructor.prototype.view = function (param) {
			console.log("CS-Query:view() : called");
            try {
				if (this._instance.executeOnView){
					this.executeSearch();
				}
 			} catch (e) {
                bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                if (e.stack) {
                    bpmext.log.error("  Call stack: " + e.stack);
				}
            }
        };
		
		this.constructor.prototype.change = function (param) {
			console.log("CS-Query:change() : called");
            try {
				if (this._instance.executeOnChange){
					this.executeSearch();
				}
 			} catch (e) {
                bpmext.log.error("Error on change event [" + this.ui.getAbsoluteName() + "]: " + e);
                if (e.stack) {
                    bpmext.log.error("  Call stack: " + e.stack);
				}
            }
        };
	}
}
	
