/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

cs_InitFileDropZone = function(bpmext, domClass, domStyle, domAttr, messages, string) {
	
	_uploadContent: null;
	_objectStoreName: null;
	_parentFolder: null;
	
	if (!this.constructor.prototype._proto)	{
		
		this.constructor.prototype._proto =	{
			
			EVT_ONADD: "eventON_ADD",
			EVT_ONERROR: "eventON_ERROR",
	
			_setAlertMessage: function(view, message, isError, delay) {
				var title = messages.contlist_progress_success;
				var style = "S";
				if (isError) {
					title = messages.contlist_progress_alert;
					style = "D";
				}
				// Call out to the CS_Alert utility class to handle displaying the alert message
				setAlertMessage(title, message, style, delay, domClass, domStyle, domAttr, messages);
			},

			_setHeight: function(view) {
				var size = view.context.options.height.get("value");
				if (size ) {
					try	{
						if (size != null && size != "")	{
							if (!isNaN(size)) {
								size += "px";
							}
							view.context.element.style.height = size;
							
							var fileUpload = view.context.element.querySelector(".CS_FileUpload");
							if (fileUpload) {
								fileUpload.style.height = size;
							}
						}
					} catch (e)	{
						bpmext.log.error("CS-FileDropZone._setHeight() error: " + e);
						if (e.stack) {
							bpmext.log.error("  Call stack: " + e.stack);
						}
					}
				}
			},
			
			_setWidth: function(view) {
				var size = view.context.options.width.get("value");
				if (size) {
					try {
						if (size != null && size != "") {
							if (!isNaN(size)) {
								size += "px";
							}
							view.context.element.style.width = size;
						}
					} catch (e)	{
						bpmext.log.error("CS-FileDropZone._setWidth() error: " + e);
						if (e.stack) {
							bpmext.log.error("  Call stack: " + e.stack);
						}
					}
				}
			},
			
			_onExternalDragOver: function(event, view, fileUpload) {
				event.preventDefault();
				domClass.add(fileUpload, "CS_FileDropZoneDragOver");
			},

			_onExternalDrop: function(event, view, fileUpload) {
				this._onExternalDragLeave(event, view, fileUpload);
				event.preventDefault();
				this._uploadFiles(event.dataTransfer.files, event.dataTransfer.items, view);
			},
		
			_onExternalDragLeave: function(event, view, fileUpload) {
				event.preventDefault();
				domClass.remove(fileUpload, "CS_FileDropZoneDragOver");
			},
		
			_uploadFiles: function(files, items, view, index) {
				document.body.style.cursor = 'wait';
				this._uploadFile(files, items, view, 0, function() {
					document.body.style.cursor = 'default';
					console.log("CS-FileDropZone:_uploadFiles() : Uploaded successfully.");
				}, function(error) {
					document.body.style.cursor = 'default';
					console.log("CS-FileDropZone:_uploadFiles() : Error occured.");
				});
			},

			_checkForFolders: function(view, items) {
				var foundFolder = false;
				if (items) {
					for (var i = 0; i < items.length; i++) {
						var item = items[i];
						var entry;
						if ((item.webkitGetAsEntry != null) && (entry = item.webkitGetAsEntry())) {
							if (!entry.isFile){
								foundFolder = true;
								break;
							}
						} else if (item.getAsFile == null || item.kind !== "file") {
							foundFolder = true;
							break;
						}
					}
				}
				return foundFolder;
			},
			
			_checkFileType: function(view, files) {
				var filesOfWrongType = [];
				var acceptFileTypes = view.context.options.acceptFileTypes.get("value");
				if (acceptFileTypes && acceptFileTypes.items.length > 0) {
					for (var i = 0; i < files.length; i++) {
						var file = files[i];
						var ext =  "." + file.name.split('.').pop();
						ext = ext.toLowerCase();
						// Compare the selected files dot etension with those that are allowed
						var allowedFileType = false;
						for (var j = 0; j < acceptFileTypes.items.length; j++) {
							var acceptFileType = acceptFileTypes.items[j].trim();
							if (!acceptFileType.startsWith(".")) {
								acceptFileType = "." + acceptFileType;
							}
							if (ext == acceptFileType.toLowerCase()) {
								allowedFileType = true;
								break;
							}
						}
						if (!allowedFileType) {
							filesOfWrongType.push(file.name);
						}
					}
				}
				return filesOfWrongType;
			},

			_checkFileSize: function(view, files) {
				var filesThatAreTooBig = [];
				var maxDocumentSize = view.context.options.maxDocumentSize.get("value");
				if (maxDocumentSize > 0) {
					for (var i = 0; i < files.length; i++) {
						var file = files[i];
						// Divide the real file size by 1024 to get the the size in KB 
						if ((file.size/1024) > maxDocumentSize) {
							filesThatAreTooBig.push(file.name);
						}
					}
				}
				return filesThatAreTooBig;
			},
			
			_uploadFile: function(files, items, view, index, callback, errback) {
				var self = this;
				// Check for folders, can only drop files
				var foundFolder = this._checkForFolders(view, items);
				if (foundFolder) {
					var message = messages.contlist_drop_folder_error;
					view._proto._setAlertMessage(view, message, true);
					bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONERROR, message);
					errback(message);
				} else if (files.length > view.context.options.maxAddDocuments.get("value")) {
					document.body.style.cursor = 'default';
					var message = string.substitute(messages.contlist_add_doc_max_exceeded, [view.context.options.maxAddDocuments.get("value"), files.length]);
					view._proto._setAlertMessage(view, message, true, 6000);
					bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONERROR, message);
					errback(message);
				} else {
					// Check to see if the files are of the correct file type(s) if they have been specified
					var filesOfWrongType = this._checkFileType(view, files);
					if (filesOfWrongType && filesOfWrongType.length > 0) {
						var message = "";
						if (filesOfWrongType.length == 1) {
							message = string.substitute(messages.filedropzone_filewrongtype, [filesOfWrongType[0]]);
						} else {
							var filesMessage = "";
							for (var i = 0; i < filesOfWrongType.length; i++) {
								filesMessage += filesOfWrongType[i];
								if (i < filesOfWrongType.length - 1) {
									filesMessage += ", ";
								}
							}
							message = string.substitute(messages.filedropzone_fileswrongtype, [filesMessage]);							
						}
						if (files.length > filesOfWrongType.length) {
							message = string.substitute(messages.filedropzone_filesnotadded, [message]);
						}
						var alertTime = 6000;
						if (filesOfWrongType.length > 2) {
							alertTime = 10000;
						}
						view._proto._setAlertMessage(view, message, true, alertTime);
						bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONERROR, message);
						errback(message);					
					} else {
						// Check to see if a max file size setting has been specified and if any files are too big
						var filesThatAreTooBig = this._checkFileSize(view, files);
						if (filesThatAreTooBig && filesThatAreTooBig.length > 0) {
							var message = "";
							if (filesThatAreTooBig.length == 1) {
								message = string.substitute(messages.filedropzone_filetoobig, [filesThatAreTooBig[0]]);
							} else {
								var filesMessage = "";
								for (var i = 0; i < filesThatAreTooBig.length; i++) {
									filesMessage += filesThatAreTooBig[i];
									if (i < filesThatAreTooBig.length - 1) {
										filesMessage += ", ";
									}
								}
								message = string.substitute(messages.filedropzone_filestoobig, [filesMessage]);							
							}
							if (files.length > filesThatAreTooBig.length) {
								message = string.substitute(messages.filedropzone_filesnotadded, [message]);
							}
							var alertTime = 6000;
							if (filesThatAreTooBig.length > 2) {
								alertTime = 10000;
							}
							view._proto._setAlertMessage(view, message, true, alertTime);
							bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONERROR, message);
							errback(message);					
						} else {
							if (index >= files.length) {
								if (files.length == 1) {
									console.log("CS-FileDropZone:_uploadFile() : Successfully added the file.");
									view._proto._setAlertMessage(view, messages.contlist_add_doc_success, false);	
								} else {
									console.log("CS-FileDropZone:_uploadFile() : Successfully added the files.");
									view._proto._setAlertMessage(view, messages.contlist_add_docs_success, false);	
								}
								callback();
							} else {
								var file = files[index];
								// See if a document type has been specified in the config settings, if not use base Document type
								var documentType = view.context.options.defaultDocumentType.get("value");
								if (documentType == null || documentType == "") {
									documentType = "Document";
								}
								console.log("CS-FileDropZone:_uploadFile() : Adding document with type: " + documentType + " and name: " + file.name);
								
								view._uploadContent.uploadFileSimpleWithClass(view._parentFolder, file, documentType, function(result) {
									var contentItem = self._createDocumentContentItem(result.properties, result.contentElements);
									bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONADD, contentItem);

									// If there were multiple files selected or dropped, get the file at the next index and add it.
									view._proto._uploadFile(files, null, view, ++index, callback, errback);
								}, function(error) {
									var message = string.substitute(messages.contlist_add_document_failed, [file.name]);
									view._proto._setAlertMessage(view, message, true, 6000);
									bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONERROR, message);
									errback(error);
								});		
							}
						}
					}
				}
			},
			
			_createDocumentContentItem: function(properties, contentElements) {
				var contentItem = {
					baseType: "Document",
					isFolder: false,
					properties: properties
				};
				if (contentElements != null) {
					contentItem.contentElements = contentElements;
				}
				// Dig some properties out of the property bag and make first class properties
				for (var i = 0; i < properties.length; i++) {
					var property = properties[i];
					if (property.id == "Id") {
						contentItem.id = property.value;
					} else if (property.id == "Name") {
						contentItem.name = property.value;
					} else if (property.id == "MimeType") {
						contentItem.mimeType = property.value;
					} else if (property.id == "IsReserved") {
						contentItem.isReserved = property.value;
					}
				} 
				return contentItem;
			}
		}		
	}
	
	/*
	 * Public control methods *************************************************************
	 */
	
	/**
	 * @instance
	 * @memberof CS-FileDropZone
	 * @method setFolder
	 * @param {CSContentItem} contentItem object holding the folder information id or pathName
	 * @desc Changes the file in folder where the content will be added.
	 */
	this.constructor.prototype.setFolder = function(contentItem) {
		console.log("CS-FileDropZone:setFolder() : called");
		if (contentItem) {
			if (contentItem.baseType && contentItem.baseType == "Folder") {
				// Get the folder information out of the contentItem
				this._parentFolder = contentItem.id ? contentItem.id : contentItem.pathName;
				console.log("CS-FileDropZone:setFolder() : Setting folder: " + this._parentFolder);
			} else {
				console.log("CS-FileDropZone:setFolder() : Error: passed in object is not a folder.");
			}
		}
	};

	/*
	 * Coach NG Lifecycle methods *************************************************************
	 */
	
	this.constructor.prototype.load = function() {
		console.log("CS-FileDropZone:load() : called from: " + this.context.viewid);
		var options = this.context.options;
		
		if (!options.objectStoreName) {
			options.objectStoreName = bpmext.ui.substituteConfigOption(this, "objectStoreName", "");
		} else {
			this._objectStoreName = options.objectStoreName.get("value");
		}
		
		if (!options.uploadDetails) {
			options.uploadDetails = bpmext.ui.substituteConfigOption(this, "uploadDetails", "");
		}				
		
		if (!options.folderId) {
			options.folderId = bpmext.ui.substituteConfigOption(this, "folderId", "");
		} else {
			this._parentFolder = options.folderId.get("value");
		}
	
		if (!options.maxAddDocuments) {
			options.maxAddDocuments = bpmext.ui.substituteConfigOption(this, "maxAddDocuments", 50);
		}				
		if (options.maxAddDocuments.get("value") > 50) {
			options.maxAddDocuments.set("value", 50);
		}
		
		if (!options.defaultDocumentType) {
			options.defaultDocumentType = bpmext.ui.substituteConfigOption(this, "defaultDocumentType", "");
		}

		if (!options.acceptFileTypes) {
			options.acceptFileTypes = bpmext.ui.substituteConfigOption(this, "acceptFileTypes", null);
		}
		
		if (!options.maxDocumentSize) {
			options.maxDocumentSize = bpmext.ui.substituteConfigOption(this, "maxDocumentSize", 0);
		}				
		
		if (!options.height) {
			options.height = bpmext.ui.substituteConfigOption(this, "height", null);
		}
		if (!options.width) {
			options.width = bpmext.ui.substituteConfigOption(this, "width", null);
		}

		domClass.add(this.context.element, "CS_FileDropZone");
	
	  	bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONADD, "contentItem");
		bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONERROR, "message");

		this._proto._setWidth(this);
		this._proto._setHeight(this);

		bpmext.ui.loadView(this);

		this._uploadDetailsText = this.ui.get("UploadDetailsText");
		this._uploadContent = this.ui.get("UploadContent");
	
		var uploadDetails = options.uploadDetails.get("value");
		if (uploadDetails) {
			this._uploadDetailsText.setVisible(true);
			var txt = document.createTextNode(uploadDetails);
			this._uploadDetailsText.context.element.appendChild(txt);
		}
	
		var fileUpload = this.context.element.querySelector(".CS_FileUpload");
		var self = this;

		fileUpload.addEventListener('dragover', function(evt) {
			evt.preventDefault();
			evt.stopPropagation();
			self._proto._onExternalDragOver(evt, self, fileUpload);
		}, false);
		
		fileUpload.addEventListener('drop', function(evt) {
			evt.preventDefault();
			evt.stopPropagation();
			event.stopPropagation();
			self._proto._onExternalDrop(evt, self, fileUpload);
		}, false);
		
		fileUpload.addEventListener('dragleave', function(evt) {
			evt.preventDefault();
			evt.stopPropagation();
			self._proto._onExternalDragLeave(evt, self, fileUpload);
		}, false);
		
		var fileButton = this.context.element.querySelector(".CS_FileButton");
		var btnTxt = document.createTextNode(messages.filedropzone_upload_msg);
		fileButton.appendChild(btnTxt);

		var fileInput = this.context.element.querySelector(".CS_FileInput");

		var acceptFileTypes = options.acceptFileTypes.get("value");
		if (acceptFileTypes && acceptFileTypes.items.length > 0) {
			var fileTypesString = "";
			for (var i = 0; i < acceptFileTypes.items.length; i++) {
				fileType = acceptFileTypes.items[i].trim();
				if (fileType.startsWith(".")) {
					fileTypesString += fileType;
				} else {
					fileTypesString += "." + fileType; // Add dot if missing
				}
				if (i < acceptFileTypes.items.length - 1) {
					fileTypesString += ",";
				}
			}
			domAttr.set(fileInput, "accept", fileTypesString);
		}

		fileInput.onchange = function() {
			if (this.files.length > 0) {
				self._proto._uploadFiles(this.files, null, self);
			}
		}		
	};
	
	this.constructor.prototype.change = function(event) {
		console.log("CS-FileDropZone:change() : called from: " + this.context.viewid);

	};
}