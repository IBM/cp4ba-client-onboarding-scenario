/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

var mimeTypeToCssClass = {
	"": "ftNoContent",
	"item": "ftNoContent",
	"application/afp": "ftAfp",
	"application/vnd.ibm.afplinedata": "ftAfp",
	"application/pdf": "ftPdf",
	"text/plain": "ftPlain",
	"application/rtf": "ftPlain",
	"application/x-rtf": "ftPlain",
	"text/richtext": "ftPlain",
	"application/dca-rft": "ftPlain",
	"text/html": "ftWeb",
	"text/htm": "ftWeb",
	"application/x-compress": "ftCompressed",
	"application/x-compressed": "ftCompressed",
	"application/x-zip-compressed": "ftCompressed",
	"application/x-zip": "ftCompressed",
	"application/zip": "ftCompressed",
	"multipart/x-zip": "ftCompressed",
	"application/x-rar-compressed": "ftCompressed",
	"application/x-gzip": "ftCompressed",
	"text/xml": "ftCode",
	"application/xml": "ftCode",
	"application/x-vnd.oasis.opendocument.presentation": "ftPresentation",
	"application/vnd.ms-powerpoint": "ftPresentation",
	"application/vnd.lotus-freelance": "ftPresentation",
	"application/vnd.oasis.opendocument.presentation": "ftPresentation",
	"application/vnd.oasis.opendocument.presentation-template": "ftPresentation",
	"application/vnd.openxmlformats-officedocument.presentationml.presentation": "ftPresentation",
	"application/vnd.openxmlformats-officedocument.presentationml.slideshow": "ftPresentation",
	"application/vnd.openxmlformats-officedocument.presentationml.template": "ftPresentation",
	"application/vnd.ms-powerpoint.addin.macroEnabled.12": "ftPresentation",
	"application/vnd.ms-powerpoint.presentation.macroEnabled.12": "ftPresentation",
	"application/vnd.ms-powerpoint.slideshow.macroEnabled.12": "ftPresentation",
	"application/vnd.ms-powerpoint.template.macroEnabled.12": "ftPresentation",
	"application/x-mspowerpoint": "ftPresentation",
	"application/vnd.ms-infopath": "ftInfoPath",
	"application/line": "ftData",
	"application/x-vnd.oasis.opendocument.spreadsheet": "ftData",
	"application/vnd.ms-excel": "ftData",
	"application/vnd.ms-excel.addin.macroEnabled.12": "ftData",
	"application/vnd.ms-excel.sheet.binary.macroEnabled.12": "ftData",
	"application/vnd.ms-excel.sheet.macroEnabled.12": "ftData",
	"application/vnd.ms-excel.template.macroEnabled.12": "ftData",
	"application/vnd.lotus-1-2-3": "ftData",
	"application/vnd.openxmlformats-officedocument.spreadsheetml.template": "ftData",
	"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "ftData",
	"application/vnd.oasis.opendocument.spreadsheet": "ftData",
	"application/vnd.oasis.opendocument.spreadsheet-template": "ftData",
	"application/x-msexcel": "ftData",
	"text/csv": "ftData",
	"application/csv": "ftData",
	"application/x-vnd.oasis.opendocument.text": "ftWordProcessing",
	"application/msword": "ftWordProcessing",
	"application/vnd.lotus-wordpro": "ftWordProcessing",
	"application/wordperfect5.1": "ftWordProcessing",
	"application/vnd.oasis.opendocument.text": "ftWordProcessing",
	"application/vnd.oasis.opendocument.text-template": "ftWordProcessing",
	"application/vnd.openxmlformats-officedocument.wordprocessingml.document": "ftWordProcessing",
	"application/vnd.openxmlformats-officedocument.wordprocessingml.template": "ftWordProcessing",
	"application/vnd.ms-word.template.macroEnabled.12": "ftWordProcessing",
	"application/vnd.ms-word.document.macroEnabled.12": "ftWordProcessing",
	"application/x-msword": "ftWordProcessing",
	"application/x-filenet-searchtemplate": "ftSearchTemplate",
	"application/x-searchtemplate": "ftSearchTemplate",
	"application/x-searchtemplate.automatic": "ftSearchStored",
	"application/x-filenet-search": "ftSearchStored",
	"application/x-unifiedsearchtemplate": "ftUnifiedSearch",
	"application/x-icn-documententrytemplate": "ftIcnDocumentEntryTemplate",
	"application/x-icn-folderentrytemplate": "ftIcnFolderEntryTemplate",
	"application/x-filenet-external": "ftExternalFile",
	"application/x-box-web-link": "ftExternalFile",
	"application/csbundled": "ftMail",
	"message/rfc822": "ftMail",
	"application/iccxit": "ftMail",
	"application/x-filenet-filetype-msg": "ftMail",
	"application/icccsn": "ftNotesMail",
	"application/vnd.ms-outlook": "ftOutlookMail",
	"application/x-box-note": "ftBoxNote",
	"application/vnd.google-apps.document": "ftGdoc",
	"application/vnd.google-apps.spreadsheet": "ftGsheet",
	"application/vnd.visio": "ftWordProcessing",
	"application/visio": "ftWordProcessing",
	"application/x-visio": "ftWordProcessing",
	"application/vnd.ms-project": "ftWordProcessing",
	"application/msproject": "ftWordProcessing",
	"application/x-project": "ftWordProcessing"
};
	
getType = function(contentItem) {
	var type;
	if (contentItem.baseType) {
		type = contentItem.baseType;
	} else if (contentItem.isFolder) {
		type = "Folder";
	} else {
		type = "Document";
	}
	return type;
}

getMimeCssClass = function(contentItem, isLarge) {
	var cssClass;
	if (getType(contentItem) == "Folder") {
		if (!isLarge) {
			cssClass = "ftFolderClosed";
		} else {
			cssClass = "ftFolder";
		}
	} else if (getType(contentItem) == "Abstract") {
		cssClass = "ftBatch";
	} else {
		var mimeType = contentItem.mimeType;
		cssClass = mimeTypeToCssClass[mimeType];
		if (!cssClass) {
			if (mimeType == null || mimeType == "" || mimeType == "item") {
				cssClass = "ftNoContent";
			} else if (mimeType.substr(0, "audio/".length) == "audio/") {
				cssClass = mimeTypeToCssClass["audio/*"] || "ftAudio";
			} else if (mimeType.substr(0, "image/".length) == "image/") {
				cssClass = mimeTypeToCssClass["image/*"] || "ftGraphic";
			} else if (mimeType.substr(0, "video/".length) == "video/") {
				cssClass = mimeTypeToCssClass["video/*"] || "ftVideo";
			} else if (mimeType == "teamspace" || mimeType == "Teamspace") {
				cssClass = "ecmTeamspaceIcon";
				isLarge = false;
			} else if (mimeType == "application/x-unifiedsearchtemplate") {
				cssClass = "ftUnifiedSearch";
			} else if (mimeType == "application/x-icn-documententrytemplate") {
				cssClass = "ftIcnDocumentEntryTemplate";
			} else if (mimeType == "application/x-icn-folderentrytemplate") {
				cssClass = "ftIcnFolderEntryTemplate";
			} else {
				cssClass = "ftDefault";
			}
		}
	}
	if (isLarge) {
		cssClass += "Large";  // need larger version of mime type image
	}
	return cssClass;
}
