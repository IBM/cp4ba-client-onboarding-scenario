/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2020. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

cs_InitSummaryCard = function(bpmext, domClass, domStyle, domAttr, messages, connect){
	
	this._instance =
	{
		initializedTooltip: false,
		helpText: "",
		helpLearnMoreUrl: ""
	};

	if (!this.constructor.prototype._proto)
	{
		this.constructor.prototype._proto =
		{
			EVT_ONCLICK: "eventON_CLICK",
			
			_setTextNode: function(parentNode, text){
				var textNode;
				for(i = 0; i < parentNode.childNodes.length; i++){
					var child = parentNode.childNodes[i];
					if (child.nodeType == Node.TEXT_NODE){
						textNode = child;
						break;
					}
				}
				if (!textNode){
					textNode = document.createTextNode("");
					parentNode.appendChild(textNode);
				}
				textNode.nodeValue = text;
			},
			
			_intializeHelpTooltip: function(view, helpIconElement){
				if (!view._instance.initializedTooltip){
					var tooltipText = messages[view._instance.helpText] ? messages[view._instance.helpText] : view._instance.helpText;
					cs_InitTooltip(helpIconElement, Math.floor(Math.random() * 10000000) + "tooltip", tooltipText, false, 3, domClass, domAttr, connect, messages, view._instance.helpLearnMoreUrl);
					view._instance.initializedTooltip = true;
					helpIconElement.dispatchEvent(new MouseEvent("click")); 
				}
			}
		}
	}
	
	this.constructor.prototype.setTitle = function(title){
		var summaryCardTitle = this.context.element.querySelector(".CS_SummaryCardTitle");
		this._proto._setTextNode(summaryCardTitle, title);
		
		var icon = this.context.element.querySelector(".CS_SummaryCardIcon");
		if (icon){
			domAttr.set(icon, "alt", title);
			domAttr.set(icon, "title", title);
		}
	};
	
	this.constructor.prototype.setDetails = function(details){		
		var summaryCardDetails = this.context.element.querySelector(".CS_SummaryCardDetails");
		this._proto._setTextNode(summaryCardDetails, details);
	};
		
	this.constructor.prototype.load = function(){
		domClass.add(this.context.element, "CS_SummaryCard");
		domAttr.set(this.context.element, "tabindex", "0");
		
		var titleId = Math.floor(Math.random() * 10000000) + "title";
		var summaryCardTitle = this.context.element.querySelector(".CS_SummaryCardTitle");
		domAttr.set(summaryCardTitle, "id", titleId);
		
		var opts = this.context.options;
		if (!opts.summaryTitle) {
			opts.title = bpmext.ui.substituteConfigOption(this, "summaryTitle", "");
		}
		this.setTitle(opts.summaryTitle.get("value"));
		
		if (!opts.summaryDetails) {
			opts.summaryDetails = bpmext.ui.substituteConfigOption(this, "summaryDetails", "");
		}
		this.setDetails(opts.summaryDetails.get("value"));
		
		var _this = this;
		if (!opts.displayHelpIcon){
			opts.displayHelpIcon = bpmext.ui.substituteConfigOption(this, "displayHelpIcon", false);
		}
		if (opts.displayHelpIcon.get("value")){
			var	helpIconElement = this.context.element.querySelector(".CS_SummaryCardHelpIcon");
			domStyle.set(helpIconElement, "display", "inline-block");
			domAttr.set(helpIconElement, "aria-labelledby", titleId);
			
			helpIconElement.onclick = function(evt){
				evt.stopPropagation();
				if (!_this._instance.initializedTooltip){
					_this._proto._intializeHelpTooltip(_this, helpIconElement);
				}
			}
			helpIconElement.addEventListener('keypress', function(evt) {
				var keyID = (evt.charCode) ? evt.charCode : ((evt.which) ? evt.which : evt.keyCode);
				if (keyID == 13 || keyID == 32) {
					evt.stopPropagation();
					if (!_this._instance.initializedTooltip){
						_this._proto._intializeHelpTooltip(_this, helpIconElement);
					}
				}
				return true;
			});
					
			if (!opts.helpText) {
				opts.helpText = bpmext.ui.substituteConfigOption(this, "helpText", "");
			}
			this._instance.helpText = opts.helpText.get("value");
			
			if (!opts.helpLearnMoreUrl) {
				opts.helpLearnMoreUrl = bpmext.ui.substituteConfigOption(this, "helpLearnMoreUrl", "");
			}
			this._instance.helpLearnMoreUrl = opts.helpLearnMoreUrl.get("value")
		}
		
		bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONCLICK);

		this.context.element.onclick = function(){
			bpmext.ui.executeEventHandlingFunction(_this, _this._proto.EVT_ONCLICK);
		}
		
		this.context.element.addEventListener('keypress', function(evt) {
			var keyID = (evt.charCode) ? evt.charCode : ((evt.which) ? evt.which : evt.keyCode);
			if (keyID == 13 || keyID == 32) {
				bpmext.ui.executeEventHandlingFunction(_this, _this._proto.EVT_ONCLICK);
			}
			return true;			
		});
	};
}