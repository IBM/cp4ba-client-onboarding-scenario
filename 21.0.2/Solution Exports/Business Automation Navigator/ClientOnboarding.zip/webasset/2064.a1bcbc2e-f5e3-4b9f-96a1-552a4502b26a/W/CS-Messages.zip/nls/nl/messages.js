/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5725-C95
 * (C) Copyright IBM Corporation 2019. All Rights Reserved.
 * US Government Users Restricted Rights- Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

define({
		// Class selector
		class_selector_class: "Klasse",

		// Property list
		properties_file_name: "Bestandsnaam",
		properties_file_save_in: "Opslaan in",
		properties_add_file: "Bestand toevoegen",
		properties_add_mvcp: "${0} toevoegen",
		properties_remove_mvcp: "Verwijderen uit ${0}",
		properties_use_file_name: "De bestandsnaam wordt voor deze eigenschap gebruikt",

		properties_optional_label: "${0} (optioneel)",

		properties_document_or_folder_not_found: "Het document of de map is niet gevonden.",
		properties_class_not_found: "De contentklasse is niet gevonden.",
		properties_folder_duplicate_item_invalid_prop: "Er bestaat al een item met dezelfde naam in de map, of u hebt een ongeldige eigenschapswaarde opgegeven.",
		properties_item_invalid_prop: "U hebt een ongeldige waarde voor een of meer eigenschappen opgegeven.",

		properties_invalid_long_value: "Dit is een ongeldige waarde. De waarde moet een geheel getal zijn, bv. 5 of 1349.",
		properties_invalid_float_value: "De waarde is niet geldig. De waarde moet een getal met drijvende komma zijn, bv. 1,2 of 365.",
		properties_min_value: "Minimumwaarde: ${0}",
		properties_max_value: "Maximumwaarde: ${0}",
		properties_max_length: "Maximumlengte: ${0}",
		properties_invalid_guid: "De waarde is niet geldig. De waarde moet een GUID (Globally Unique Identifier) zijn, bv.{F8DF248A-D0F8-4FEC-B086-1F52DA81A5EF}.",
		properties_value_required: "Deze waarde is verplicht.",
		properties_unique_value_required: "Deze waarde moet uniek zijn.",
		properties_file_required: "Er moet een bestand worden opgegeven.",
		properties_invalid_folder_name: "In de mapnaam mogen de volgende tekens niet voorkomen: \\ / : * ? \" < > |",

		properties_move_edit_confirm_msg: "U wijzigt de eigenschappen van het volgende<br>${0}<br><br>Wilt u de wijzigingen opslaan?",
		properties_move_edit_confirm_no: "Nee",
		properties_move_edit_confirm_yes: "Ja",
		properties_move_edit_confirm_title: "Bevestiging",
		properties_edit_save_success: "Eigenschappen opgeslagen",
		properties_edit_save_failure: "De eigenschappen zijn niet opgeslagen",
		properties_no_item_selected: "Er is geen item geselecteerd.",

		// Content list
		contlist_column_spec_title: "Titel",
		contlist_column_spec_name: "Naam",
		contlist_column_spec_version_label: "Versie",
		contlist_column_spec_modified_by: "Aangepast door",
		contlist_column_spec_mod_date: "Laatst gewijzigd",
		contlist_column_spec_created_by: "Gemaakt door",
		contlist_column_spec_creation_date: "Gemaakt",
		contlist_column_spec_mime_type: "Documenttype",
		contlist_column_spec_size: "Grootte",
		contlist_column_spec_thumbnail: "Miniatuur",

		contlist_paging_no_more_items: "Er zijn geen items meer",
		contlist_paging_of_at_least_items: "${0} van ten minste ${1} items",
		contlist_paging_of_items: "${0} van ${1} items",
		contlist_paging_items: "Items ${0}",
		contlist_paging_items_per_page: "Items per pagina: ${0}",

		contlist_checked_out: "Uitgecheckt",
		contlist_checked_out_by: "Uitgecheckt door ${0}",

		contlist_size_units_B: "B",
		contlist_size_units_KB: "kB",
		contlist_size_units_MB: "MB",
		contlist_size_units_GB: "GB",
		contlist_size_units_TB: "TB",

		contlist_missing_server_error: "Er is geen server opgegeven.",
		contlist_invalid_server_error: "De server '{0}' bestaat niet.",
		contlist_error_retrieving_doc_props: "Fout bij ophalen van documenteigenschappen.",
		contlist_error_retrieving_folder_props: "Fout bij ophalen van mapeigenschappen.",
		contlist_checkout_failed: "Het document kan niet worden uitgecheckt.",
		contlist_cancel_checkout_failed: "Annuleren van uitchecken is mislukt.",
		contlist_rename_folder_failed: "De naam van de map kan niet gewijzigd worden.",
		contlist_folder_name_not_unique: "De naam van de map moet uniek zijn.",
		contlist_delete_object_failed: "Het object kan niet worden gewist.",
		contlist_display_properties_failed: "De eigenschappen kunnen niet worden afgebeeld. ${0}",
		contlist_save_props_failed: "De eigenschappen kunnen niet worden opgeslagen.",
		contlist_upload_failed: "De versie kan niet worden geüpload",
		contlist_add_folder_failed: "De map kan niet worden toegevoegd. ${0}",
		contlist_add_document_failed: "Het document kan niet worden toegevoegd. ${0}",
		contlist_search_failed: "Het zoekresultaat kan niet opgehaald worden.",
		contlist_folder_containees_failed: "De inhoud van de map kan niet worden opgehaald",
		contlist_delete_folder_referenced: "De map kan niet worden gewist omdat hij submappen bevat.",
		contlist_docs_not_added: "De volgende documenten kunnen niet worden toegevoegd: ${0}",

		contlist_checkout_success: "Het document is uitgecheckt",
		contlist_delete_success: "Het object is gewist",
		contlist_rename_folder_success: "De naam van de map is gewijzigd",
		contlist_save_props_success: "De eigenschappen zijn opgeslagen",
		contlist_cancel_checkout_success: "Annuleren van uitcheckprocedure geslaagd",
		contlist_upload_version_success: "De versie is geüpload",
		contlist_add_folder_success: "De map is toegevoegd",
		contlist_add_doc_success: "Het document is toegevoegd",
		contlist_add_docs_success: "De documenten zijn toegevoegd",

		contlist_menu_action_open: "Open",
		contlist_menu_action_rename: "Naam wijzigen",
		contlist_menu_action_properties: "Eigenschappen",
		contlist_menu_action_view: "Weergave",
		contlist_menu_action_download: "Downloaden",
		contlist_menu_action_checkout: "Uitchecken",
		contlist_menu_action_edit_document: "Document bewerken",
		contlist_menu_action_cancel_checkout: "Uitchecken annuleren",
		contlist_menu_action_delete_doc: "Document wissen",
		contlist_menu_action_rename_folder: "Naam map wijzigen",
		contlist_menu_action_add_folder: "Map toevoegen",
		contlist_menu_action_delete_folder: "Map wissen",
		contlist_menu_action_add_doc: "Document toevoegen",
		contlist_menu_action_upload: "Nieuwe versie uploaden",

		contlist_document_properties: "Documenteigenschappen",
		contlist_folder_properties: "Mapeigenschappen",
		contlist_folder_name: "Mapnaam",

		contlist_cancel_btn_label: "Annuleren",
		contlist_add_btn_label: "Toevoegen",
		contlist_ok_btn_label: "OK",
		contlist_edit_btn_label: "Bewerken",
		contlist_save_btn_label: "Opslaan",
		contlist_upload_btn_label: "Uploaden",
		contlist_refresh_btn_label: "Vernieuwen",
		contlist_next_btn_label: "Volgende",
		contlist_previous_btn_label: "Vorige",

		contlist_delete_folder_confirm: "U staat op het punt de map ${0} te wissen. Wilt u doorgaan?",
		contlist_delete_doc_confirm: "U staat op het punt het document ${0} te wissen. Wilt u doorgaan?",

		contlist_no_mimetype: "Dit item bevat geen content.",
		contlist_folder_mimetype: "Map",

		contlist_filter_search_hint: "Documenten doorzoeken",
		contlist_filter_folder_hint: "Filterlijst",

		contlist_root_folder: "Hoofdmap",
		contlist_drop_folder_error: "U kunt geen mappen toevoegen. Selecteer alleen bestanden.",
		contlist_add_in_process: "Wacht tot het toevoegen van het vorige document is voltooid voordat u een ander document toevoegt.",
		contlist_add_doc_max_exceeded: "U kunt maximaal ${0} items tegelijk toevoegen. U probeert ${1} items toe te voegen.",
		contlist_progress_success: "Gelukt",
		contlist_progress_alert: "Waarschuwing",
		contlist_progress_error: "Fout",
		contlist_progress_uploading: "Bezig met uploaden",
		contlist_progress_processing: "Er wordt 1 bestand verwerkt",
		contlist_progress_uploading_text: "Er wordt 1 bestand geüpload",
		contlist_progress_upload_failed: "Probleem opgetreden",
		contlist_progress_close: "Sluiten",
		progress_ind_uploaded_status: "Geüpload",
		progress_ind_uploaded: "1 bestand geüpload",
		progress_ind_uploaded_error: "Verwerking is niet gestart",		
		progress_ind_processing_status: "Bezig...",
		progress_ind_processing_err: "Probleem opgetreden",
		progress_ind_processed: "Er is 1 bestand verwerkt",	
		progress_ind_failed: "Mislukt",
		progress_ind_review_doc: "Review vereist",	
		progress_ind_updating: "1 bestand wordt bijgewerkt",
		progress_ind_updating_status: "Bijwerken",
		progress_ind_update_err: "Probleem opgetreden",
		progress_ind_timeout: "Timeout bij bewaking",
		progress_ind_refresh: "Vernieuwen",

		getcontent_ret_versions_error: "Ophalen van versieseries is mislukt",
		getcontent_ret_properties_error: "Ophalen van documenteigenschappen is mislukt",

		contentviewer_test_mode: "De viewer beeldt geen documenten af in de previewmodus. U moet in een IBM Navigator-desktoptoepassing werken.",

		thumbnail_retreival_error: "Het ophalen van de miniatuurafbeelding is mislukt",

		status_10: "Geüpload",
		status_20: "Bezig...",
		status_25: "Opnieuw verwerken",
		status_30: "Review vereist",
		status_40: "Bijwerken",
		status_900: "Verwerkingsfout",
		status_910: "Bijwerkfout",

		/*do not remove this line*/nop: null
});
