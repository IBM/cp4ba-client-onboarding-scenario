/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

cs_InitUploadVersion = function (utilities, bpmext, domClass, domStyle, domAttr, messages, string)
{
	this._instance = {
		serverConfigurationName: "GRAPHQL_APP_RESOURCE",
		objectStoreName: null,
		actionName: null,
		contentItem: null,
		callback: null,
		errback: null
	};

	if (!this.constructor.prototype._proto)	{
		
		this.constructor.prototype._proto =	{
			EVT_ONUPLOADVERSION: "eventON_UPLOADVERSION",
			EVT_ONCANCEL: "eventON_CANCEL",
			EVT_ONERROR: "eventON_ERROR",

			typeDocument: "Document",
			typeFolder: "Folder",
			typeAbstract: "Abstract",
			
			privilegeToBitmask: {
				"privEditProperties": 0x2,
				"privAddToFolder": 0x10,
				"privViewDoc": 0x80,
				"privDelete": 0x10000,
				"privMajorVersion": 0x4,
				"privMinorVersion": 0x40,
				"privAddItem": 0x100,
			},	

			_handleVisibility: function (view) {
				var vis = utilities.handleVisibility(view.context);
			},
			
			_setVisibilityOfControl: function (control, vis) {
				control.context.options["_metadata"].visibility.set("value", vis);
				control.context.setDisplay(vis != "NONE");
				control.context.setVisibility(vis != "HIDDEN");
			},
			
			_setAlertMessage: function(view, message, isError, delay) {
				var title = messages.contlist_progress_success;
				var style = "S";
				if (isError) {
					title = messages.contlist_progress_alert;
					style = "D";
				}
				// Call out to the CS_Alert utility class to handle displaying the alert message
				setAlertMessage(title, message, style, delay, domClass, domStyle, domAttr, messages);
			},
			
			_setModalAlertMessage: function(view, modalAlert, modalAlertId, message, isError, delay) {
				var title = messages.contlist_progress_success;
				var style = "S";
				if (isError) {
					title = messages.contlist_progress_alert;
					style = "D";
				}
				// Call out to the CS_Alert utility class to handle displaying the alert message
				var alertDiv = setAlertMessage(title, message, style, delay, domClass, domStyle, domAttr, messages);
				
				setTimeout(function(){
					alertDiv.scrollIntoView(true);
				}, 300);	
			},
	
			_getType: function(contentItem) {
				var type;
				if (contentItem.baseType) {
					type = contentItem.baseType;
				} else if (contentItem.isFolder) {
					type = this.typeFolder;
				} else {
					type = this.typeDocument;
				}
				return type;
			},
	
			/**
			 * Helper function to retrieve the Object Store Name as defined in ACCE admin tool. This is the 
			 * string that will be passed to all the graphql action services since it's working against CE
			 * and not ICN).
			 */
			_getObjectStoreName: function(view) {
				var objectStoreName = view.context.options.objectStoreName.get("value");
				if (view._instance.objectStoreName) {
					objectStoreName = view._instance.objectStoreName;
				}
				return objectStoreName;
			},

			_showHideUploadVersionActionModal: function(view, isVisible, contentItem, callback, errback) {	
				console.log("CS-UploadVersion:_showHideUploadVersionActionModal() : Show upload version modal, isVisible: " + isVisible);

				view._instance.uploadVersionModal = view.ui.get("UploadVersionModal");
				view._instance.propertiesList = view.ui.get("PropertiesList");
				
				if (isVisible) {
					view._instance.callback = callback; 
					view._instance.errback = errback; 

					view._instance.contentItem = contentItem;
					var reservationId = contentItem.reservation ? contentItem.reservation.id : contentItem.id;
						
					view._instance.propertiesList.setServerConfigurationName(view._instance.serverConfigurationName);	
					view._instance.propertiesList.setObjectStoreName(this._getObjectStoreName(view));
					view._instance.propertiesList.displayForCheckin(reservationId);
				}
				view._instance.uploadVersionModal.setVisible(isVisible);
				view._instance.propertiesList.setVisible(isVisible);
			},

			_onCancelBtnClicked: function(view) {
				view._instance.uploadVersionModal = view.ui.get("UploadVersionModal");
				view._instance.propertiesList = view.ui.get("PropertiesList");
				
				view._instance.uploadVersionModal.setVisible(false);
				view._instance.propertiesList.setVisible(false);

				bpmext.ui.executeEventHandlingFunction(view, this.EVT_ONCANCEL);
			},
			
			_setPropertyListMaxHeight: function(view, modalSection, propertyList) {
				var modalContent = modalSection.context.element.querySelector(".modal-dialog");
				var modalHeight = modalContent.offsetHeight;
				var modalStyle = window.getComputedStyle(modalContent);
				modalHeight += (parseInt(modalStyle.getPropertyValue('margin-top')) + parseInt(modalStyle.getPropertyValue('margin-bottom')));
				
				var parentHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
				var parentStyle = window.getComputedStyle(view.context.element);
				parentHeight += (parseInt(parentStyle.getPropertyValue('margin-top')) + parseInt(parentStyle.getPropertyValue('margin-bottom')));
				
				var availableHeight = window.innerHeight < parentHeight ? window.innerHeight : parentHeight;
				availableHeight -= (modalHeight - propertyList.context.element.clientHeight);
				domStyle.set(propertyList.context.element, "max-height", availableHeight + "px");
			}, 

			_onUploadVersionBtnClicked: function(view) {
				console.log("CS-UploadVersion:_onUploadVersionBtnClicked()");
				domStyle.set(view.context.element, "cursor", "wait"); 

				var self = this;
				view._instance.propertiesList.update(function(properties, contentElements, cmThumbnails) {
					domStyle.set(view.context.element, "cursor", "auto"); 
					view._instance.checkoutForUpload = false;
					self._showHideUploadVersionActionModal(view, false);
					self._setAlertMessage(view, messages.contlist_upload_version_success, false);

					var contentItem = self._createDocumentContentItem(properties, contentElements, cmThumbnails);
					var callback = view._instance.callback;
					if (callback) {
						callback(contentItem);
					}
					bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONUPLOADVERSION, contentItem);
					
				}, function(errorText) {
					// Show error in an alert box at top of add dialog
					domStyle.set(view.context.element, "cursor", "auto"); 
					view._instance.uploadVersionBtn.setEnabled(true);
					self._setModalAlertMessage(view, view._instance.uploadVersionAlert, "UploadVersionAlert", messages.contlist_upload_failed, true);
				}, false);
			},
			
			_createDocumentContentItem: function(properties, contentElements, cmThumbnails) {
				var contentItem = {
					isFolder: false,
					baseType: "Document",
					properties: properties
				};
				if (contentElements != null) {
					contentItem.contentElements = contentElements;
				}
				if (cmThumbnails != null) {
					contentItem.cmThumbnails = cmThumbnails;
				}
				// Dig some properties out of the property bag and make first class properties
				for (var i = 0; i < properties.length; i++) {
					var property = properties[i];
					if (property.id == "Id") {
						contentItem.id = property.value;
					} else if (property.id == "Name") {
						contentItem.name = property.value;
					} else if (property.id == "MimeType") {
						contentItem.mimeType = property.value;
					} else if (property.id == "IsReserved") {
						contentItem.isReserved = property.value;
					}
				} 
				return contentItem;
			}
			
		};

		/*
		 * Private methods and event handlers *************************************************************
		 */
		 
		this.constructor.prototype._canEditProperties = function(contentItem) {
			if (contentItem && contentItem.accessAllowed) {
				var canEditProperties = (contentItem.accessAllowed & this._proto.privilegeToBitmask["privEditProperties"]) > 0;
				return canEditProperties;
			} else {
				return false;
			}
		};

		/*
		 * Public control methods *************************************************************
		 */

		/**
		 * @instance
		 * @memberof CSUploadVersion
		 * @method uploadVersion
		 * @desc Uploads a new version of a document and updates the properties
		 * @returns 
		 */
		this.constructor.prototype.uploadVersion = function(contentItem, callback, errback) {

			this._proto._showHideUploadVersionActionModal(this, true, contentItem, callback, errback);
			
		};

		/*
		 * Coach NG Lifecycle methods *************************************************************
		 */
		 
		this.constructor.prototype.load = function() {
			console.log("CS-UploadVersion:load() : called from: " + this.context.viewid);
			try	{
				var opts = this.context.options;
				var mdt = opts._metadata;

				if (!opts.objectStoreName) {
                    opts.objectStoreName = bpmext.ui.substituteConfigOption(this, "objectStoreName", null);
				}

				if (!opts.hideTimePicker) {
					opts.hideTimePicker = bpmext.ui.substituteConfigOption(this, "hideTimePicker", false);
				}
			
				domClass.add(this.context.element, "CS_UploadVersion");
				
  				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONUPLOADVERSION, "contentItem");
				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONCANCEL);
				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONERROR, "message");

				bpmext.ui.loadView(this);			
				
			} catch (e) {
				bpmext.log.error("Error on load event [" + this.context.viewid + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};

		this.constructor.prototype.view = function () {
			console.log("CS-UploadVersion:view() : called from: " + this.context.viewid);
            try {
//				this._proto._handleVisibility(this);
 			} catch (e) {
                bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                if (e.stack) {
                    bpmext.log.error("  Call stack: " + e.stack);
				}
            }
        };

		this.constructor.prototype.change = function(event)	{
			console.log("CS-UploadVersion:change() : called from: " + this.context.viewid);
			try	{
				var view = this;
				if (event.type == "config")	{
					// NA
				} else {
					if (this.context.binding && event.newVal && event.newVal.id) {
						var boundObject = this.context.binding.boundObject;
						if (boundObject != null) {
														
						}
					}
				}
			} catch (e) {
				bpmext.log.error("Error on change event [" + this.ui.getAbsoluteName() + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};
	}
}	
