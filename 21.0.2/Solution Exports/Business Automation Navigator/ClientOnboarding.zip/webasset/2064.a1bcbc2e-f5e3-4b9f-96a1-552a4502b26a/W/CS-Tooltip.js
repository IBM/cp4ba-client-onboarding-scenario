/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2020 - 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

/**
 * Use this method to create hover help bubbles that open when the user clicks on the passed in "ele" element (or space or return key).  
 * The bubble will close when the user clicks out side the element or a keydown space or return event is fired.
 */
cs_InitTooltip = function(ele, tooltipId, tooltipText, bAbove, horiAdjust, domClass, domAttr, connect, messages, learnMoreLink) {

	this._instance = {
		_tooltipEle: null,
		_hoverTooltipEle: null
	};

	if (!ele || !tooltipId || !tooltipText) {
		return;
	}
	horiAdjust = (horiAdjust || 0);

	domAttr.set(ele, "tabindex", 0);

	connect.connect(ele, "onclick", this, function() {
		console.log("CS-Tooltip:onclick() : Opening the tooltip.");
		var _tooltipEle = createTooltip(ele, tooltipId, tooltipText, bAbove, horiAdjust, domClass, domAttr, connect, messages, learnMoreLink);
	});
	
	connect.connect(ele, "onkeydown", this, function(evt) {
		var keyID = (evt.charCode) ? evt.charCode : ((evt.which) ? evt.which : evt.keyCode);
		if (keyID == 13 || keyID == 32) {
			console.log("CS-Tooltip:onkeydown() : Opening the tooltip.");
			var _tooltipEle = createTooltip(ele, tooltipId, tooltipText, bAbove, horiAdjust, domClass, domAttr, connect, messages, learnMoreLink);
		}
	});
	
	return;
}

createTooltip = function(ele, tooltipId, tooltipText, bAbove, horiAdjust, domClass, domAttr, connect, messages, learnMoreLink) {
	console.log("CS-Tooltip:createTooltip() : Creating the tooltip.");
	if (this._instance._tooltipEle) {
		var myparent = this._instance._tooltipEle.parentElement;
		myparent.removeChild(this._instance._tooltipEle);
	}

	var _tooltipEle = createTooltipHtml(ele, tooltipId, tooltipText, bAbove, horiAdjust, domClass, domAttr, messages, learnMoreLink);
	this._instance._tooltipEle = _tooltipEle;	

	// Setup the mouse events so we can click outside the context menu and have it close
	connect.connect(_tooltipEle, "onmouseover", this, function() {
		overTooltip = true;
	});

	var overTooltip = false;
	connect.connect(_tooltipEle, "onmouseout", this, function() {
		overTooltip = false;
	});

	document.onmousedown = function(evt) {
		if (overTooltip == false) {
			var isClosed = domClass.contains(_tooltipEle, "CS_Hidden");
			if (!isClosed) {
				setTimeout(function () {
					console.log("CS-Tooltip:onmousedown() : Closing the tooltip.");
					domClass.add(_tooltipEle, "CS_Hidden");
				});
			}
		}
	};

	document.onkeydown = function(evt) {
		var keyID = (evt.charCode) ? evt.charCode : ((evt.which) ? evt.which : evt.keyCode);
		// Esc or Tab key closes the tooltip
		if (keyID == 27 || keyID == 9) {
			if (overTooltip == false) {
				var isClosed = domClass.contains(_tooltipEle, "CS_Hidden");
				if (!isClosed) {
					setTimeout(function () {
						console.log("CS-Tooltip:onmousedown() : Closing the tooltip.");
						domClass.add(_tooltipEle, "CS_Hidden");
					});
				}
			}
		}
	};

	return _tooltipEle;
}

/**
 * Use this method to create hover help bubbles that open when the mouse hovers over the passed in "ele" element. It will 
 * close when the mouse moves out of the element.
 */
cs_InitHoverTooltip = function(ele, tooltipId, tooltipText, bAbove, horiAdjust, domClass, domAttr, connect, messages, learnMoreLink) {
	if (!ele || !tooltipId || !tooltipText) {
		return;  // Not enough info to create a tooltip
	}
	
	this._instance = {
		_hoverTooltipEle: null
	};

	horiAdjust = (horiAdjust || 0);

	domAttr.set(ele, "tabindex", 0);

	connect.connect(ele, "onmouseover", this, function() {
		console.log("CS-Tooltip:onmouseover() : Called.");
		var _hoverTooltipEle = createHoverTooltip(ele, tooltipId, tooltipText, bAbove, horiAdjust, domClass, domAttr, connect, messages, learnMoreLink);
	});
	
	connect.connect(ele, "onmouseout", this, function() {
		console.log("CS-Tooltip:onmouseout() : Closing the tooltip.");
		domClass.add(this._instance._hoverTooltipEle, "CS_Hidden");
	});

	return;
}

createHoverTooltip = function(ele, tooltipId, tooltipText, bAbove, horiAdjust, domClass, domAttr, connect, messages, learnMoreLink) {
	console.log("CS-Tooltip:createHoverTooltip() : Creating tooltip: " + tooltipId);
	
	var tooltip = document.getElementById(tooltipId);
	if (tooltip) {
		console.log("CS-Tooltip:createHoverTooltip() : Removing old tooltip from document: " + tooltipId);
		this._instance._hoverTooltipEle = null;
		var myparent = tooltip.parentElement;
		myparent.removeChild(tooltip);
	}

	var _hoverTooltipEle = createTooltipHtml(ele, tooltipId, tooltipText, bAbove, horiAdjust, domClass, domAttr, messages, learnMoreLink);
	this._instance._hoverTooltipEle = _hoverTooltipEle;	

	return _hoverTooltipEle;
}

createTooltipHtml = function(ele, tooltipId, tooltipText, bAbove, horiAdjust, domClass, domAttr, messages, learnMoreLink) {
	var _tooltipEle = document.createElement("span");
	domClass.add(_tooltipEle, "CS_Tooltip");
	domAttr.set(_tooltipEle, "id", tooltipId);

	var arrow = document.createElement("span");
	// If the tooltip is above the element, we need a "down" arrow at the bottom of tooltip
	// If the tooltip is below the element, we need an "up" arrow on the top of tooltip
	bAbove ? domClass.add(arrow, "CS_TooltipArrowDown") : domClass.add(arrow, "CS_TooltipArrowUp");

	var textNode = document.createElement("p");
	domClass.add(textNode, "CS_TooltipP");
	textNode.appendChild(document.createTextNode(tooltipText));
	_tooltipEle.appendChild(textNode);
	
	var learnMoreElement = createLearnMore(_tooltipEle, domClass, domAttr, messages, learnMoreLink);
	
	_tooltipEle.appendChild(arrow);
	_tooltipEle.arrow = arrow;

	document.body.appendChild(_tooltipEle);

	var rect = ele.getBoundingClientRect();
	var slide = (_tooltipEle.offsetWidth - rect.width)/2;
	var eleLeft = rect.left - slide;

	// calculate the position of the tooltip
	var horizScroll = document.body.parentNode.scrollTop;
	
	_tooltipEle.style.left = eleLeft + "px";
	
	_tooltipEle.style.bottom = (bAbove ? 
		((document.body.clientHeight - rect.top - horizScroll + horiAdjust) + "px") :
		((document.body.clientHeight - rect.bottom - horizScroll - _tooltipEle.clientHeight - horiAdjust) + "px"));
		
	var arrowLeft = _tooltipEle.offsetWidth/2;
	_tooltipEle.arrow.style.left = arrowLeft + "px";
	
	if (learnMoreElement) {
		learnMoreElement.focus();
	}
	return _tooltipEle;
}

createLearnMore = function(_tooltipEle, domClass, domAttr, messages, learnMoreLink) {
	var learnMoreElement;
	if (learnMoreLink && learnMoreLink.length > 0) {
		var tooltipFooter = document.createElement("div");
		domClass.add(tooltipFooter, "CS_TooltipFooter");
		_tooltipEle.appendChild(tooltipFooter);
		learnMoreElement = document.createElement("a");
		tooltipFooter.appendChild(learnMoreElement);
		domClass.add(learnMoreElement, "CS-TooltipA");
		domAttr.set(learnMoreElement, 'href', learnMoreLink);
		domAttr.set(learnMoreElement, 'target', "_blank");
		learnMoreElement.rel = "noreferrer noopener";
		var learnMoreText = document.createTextNode(messages.contlist_click_learn_more);
		learnMoreElement.appendChild(learnMoreText);
	}
	return learnMoreElement;
}


