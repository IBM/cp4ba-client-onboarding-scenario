/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2020 - 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */
 
cs_InitThumbnail = function (utilities, bpmext, domClass, domStyle, domAttr, domConstruct, messages, string, cookie) {
	
	this._instance = {
		serverConfigurationName: "GRAPHQL_APP_RESOURCE"
	};

	if (!this.constructor.prototype._proto) {
		
		this.constructor.prototype._proto =
		{
			EVT_ONERROR: "eventON_ERROR",

			/**
			 * Helper function to retrieve the Object Store Name as defined in ACCE admin tool. 
			 */
			_getObjectStoreName: function(view) {
				var objectStoreName = view.context.options.objectStoreName.get("value");
				return objectStoreName;
			},

			_getVisibility: function(view) {
				var visibility = "DEFAULT";
				if (view.context.options._metadata.visibility) {
					visibility = view.context.options._metadata.visibility.get("value");
				}
				if (visibility == "DEFAULT") {
					visibility = view.context.getInheritedVisibility();
				}
				return visibility;
			},
			
			_setHeight: function(view) {
				var size = view.context.options.height.get("value") ? view.context.options.height.get("value") : null;
				try	{
					if (size != null && size != "")	{
						if (!isNaN(size)) {
							size += "px";
						}
//						view.context.element.style.height = size;
						view._instance.img.style.height = size;
					}
				} catch (e)	{
					bpmext.log.error("CS-Thumbnail._setHeight() error: " + e);
					if (e.stack) {
						bpmext.log.error("  Call stack: " + e.stack);
					}
				}
			},

			_setWidth: function(view) {
				var size = view.context.options.width.get("value") ? view.context.options.width.get("value") : null;
				try {
					if (size != null && size != "") {
						if (!isNaN(size)) {
							size += "px";
						}
//						view.context.element.style.width = size;
						view._instance.img.style.width = size;
					}
				} catch (e)	{
					bpmext.log.error("CS-Thumbnail._setWidth() error: " + e);
					if (e.stack) {
						bpmext.log.error("  Call stack: " + e.stack);
					}
				}
			},
			
			_handleVisibility: function(view) {
				var visibility = utilities.handleVisibility(view.context);		
//				if (visibility != "NONE") {
//				}
			},

			_callService: function(service, params) {
				// Create ecm token as a large random number
				var csrfToken = Math.floor(Math.random() * 10000000);
				console.log("CS-Thumbnail:_callService() : Ecm token: " + csrfToken);

				// Add the required token value to the service params
				params.csrfToken = csrfToken;
				service.execute(params);
			},
	
			_loadImage: function(view, contentItem) {
				console.log("CS-Thumbnail:_loadImage() : called");
				if (contentItem != null) {
					view._instance._mimeType = contentItem.mimeType;
					var retrievingThumbnail = false;
					// Get the thumbnails property, has id of thumbnail object we need to download the image bits from
					var cmThumbnails = contentItem.cmThumbnails;
					if (cmThumbnails && cmThumbnails.cmThumbnails) {
						cmThumbnails = cmThumbnails.cmThumbnails.items ? cmThumbnails.cmThumbnails.items : cmThumbnails.cmThumbnails;
						if (cmThumbnails.length > 0) {
							var thumbnailId = cmThumbnails[0].id;
							var params = {
								thumbnailId: thumbnailId,
								properties: ["name"],
								repository: this._getObjectStoreName(view),
								serverAppResource: view._instance.serverConfigurationName
							};
							view._instance.getThumbnailSvc = view.ui.get("GetThumbnailSvc");
							this._callService(view._instance.getThumbnailSvc, params);
							retrievingThumbnail = true;
						}
					} 
					
					if (!retrievingThumbnail) {
						// Display default icon based on mime type of original document
						this._displayDefaultMimeImage(view, contentItem);
					}
				} else {
					// NA
				}
			},

			_displayDefaultMimeImage: function(view, contentItem) {
				// Display default icon based on mime type of original document

				// Get the mime type css class name from the mime type utility JS
				var cssClass = getMimeCssClass(contentItem, true);
			
				var iconImg = view._instance.img;
				domClass.remove(iconImg, "CS_Image");
				if (view._instance.lastCssClass) {
					domClass.remove(iconImg, view._instance.lastCssClass);
				}
				domClass.add(iconImg, cssClass);
				view._instance.lastCssClass = cssClass;

				var	srcBlank = com_ibm_bpm_coach.getManagedAssetUrl('CS-blank.gif', com_ibm_bpm_coach.assetType_WEB, 'SYSCST', false);
				domAttr.set(iconImg, "src", srcBlank);

				if (contentItem.mimeType == null || contentItem.mimeType == "" ) {
					if (contentItem.isFolder) {
						domAttr.set(iconImg, "title", messages.contlist_folder_mimetype); 
						domAttr.set(iconImg, "alt", messages.contlist_folder_mimetype);
					} else {
						domAttr.set(iconImg, "title", messages.contlist_no_mimetype);
						domAttr.set(iconImg, "alt", messages.contlist_no_mimetype);
					}
				} else {
					domAttr.set(iconImg, "title", contentItem.mimeType);
					domAttr.set(iconImg, "alt", contentItem.mimeType);
				}
			},
			
			_displayNoItemSelected: function(view) {
				var iconImg = view._instance.img;
				domClass.remove(iconImg, "CS_Image");
				if (view._instance.lastCssClass) {
					domClass.remove(iconImg, view._instance.lastCssClass);
				}
				// Need to also set the src url to blank
				var	srcBlank = com_ibm_bpm_coach.getManagedAssetUrl('CS-blank.gif', com_ibm_bpm_coach.assetType_WEB, 'SYSCST', false);
				domAttr.set(iconImg, "src", srcBlank);
				
				domAttr.set(iconImg, "title", "");
				domAttr.set(iconImg, "alt", "");
			},
			
			_onLoadThumbnailResult: function(view, thumbnail) {
				console.log("CS-Thumbnail:_onLoadThumbnailResult() : called");
				if (thumbnail.image) {
					var iconImg = view._instance.img;
					if (view._instance.lastCssClass) {
						domClass.remove(iconImg, view._instance.lastCssClass);
					}
					domClass.add(iconImg, "CS_Image");

					// Lop off the first two charaters "0x", the image format is hex
					var temp  = thumbnail.image.toString();
					temp = temp.substr(2);
					// Convert the image to base64 encoding
					iconImg.src = "data:" + thumbnail.mimeType + ";base64," + this.hexToBase64(temp);

					iconImg.alt = thumbnail.mimeType;
					iconImg.title = thumbnail.mimeType;
				} else {
					// If no thumbnail, display default image based on mimetype
					console.log("CS-Thumbnail:_onLoadThumbnailResult() : Error: Supposed to have thumbnail, but nothing returned.");
					this._displayDefaultMimeImage(view, false);
				}
			},

			/**
			 * Graphql api returns image in Hex format, need to convert it into base64 for img element
			 */
			hexToBase64: function(str) {
				return btoa(String.fromCharCode.apply(null, str.replace(/\r|\n/g, "").replace(/([\da-fA-F]{2}) ?/g, "0x$1 ").replace(/ +$/, "").split(" ")));
			}

		};

		/**
		 * Public control methods *************************************************************
		 */

		/**
		 * @instance
		 * @memberof CS-Thumbnail
		 * @method getType
		 * @desc Returns the descriptive string that represents the control type.
		 * @returns {string}
		 */
		this.constructor.prototype.getType = function() {
			return "thumbnail.2";
		};
		
		/**
		 * @instance
		 * @memberof CS-Thumbnail
		 * @method setContentItem
		 * @param {CSContentItem} contentItem object holding the object to be displayed as a thumbnail
		 * @desc Changes the item that will be displayed in the view.
		 */
		this.constructor.prototype.setContentItem = function(contentItem) {
			console.log("CS-Thumbnail:setContentItem() : called");
			if (contentItem) {
				if (contentItem.baseType && (contentItem.baseType == "Document" || contentItem.baseType == "Folder")) {
					this._contentItem = contentItem;
					console.log("CS-Thumbnail:setContentItem() : Setting item: " + contentItem.name);
					// Since a new document (contentItem) was set, need to reload the component
					var self = this;
					setTimeout(function() {
						self._proto._loadImage(self, contentItem);
					}, 300);
				} else {
					console.log("CS-Thumbnail:setContentItem() : Error: passed in object is not a type that can be displayed as a thumbnail.");
				}
			}
		};

		/**
		 * Private methods and event handlers *************************************************************
		 */

		this.constructor.prototype._parseError = function(error) {
			if (error.errorText) {
			  if (error.errorText.indexOf("CWTBI0006E") != -1) {
				  var message = string.substitute(messages.contlist_invalid_server_error, [this._instance.serverConfigurationName]);
				  return message;
			  }
			}
			return null;
		};

		this.constructor.prototype._onGetThumbnailResult = function() {
			var view = this;
			console.log("CS-Thumbnail:_onGetThumbnailResult() : called");

			// Check that there are results that came back from the service call
			var resultSet = view._instance.getThumbnailSvc && view._instance.getThumbnailSvc.getResult();
			if (resultSet && resultSet.results) {
				view._proto._onLoadThumbnailResult(view, resultSet.results); 
			}
		};

		this.constructor.prototype._onGetThumbnailError = function() {
			var view = this;
			var error = view._instance.getThumbnailSvc && view._instance.getThumbnailSvc.getLastError();
			if (error) {
				view._instance.error = error;

        		var message = this._parseError(error);
        		if (message == null) {
          			message = messages.thumbnail_retreival_error;        
        		}
				console.log("CS-Thumbnail:_onGetThumbnailError() : " + message);

				setTimeout(function() {
					bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, message);
				});
			}
			view._instance.refreshing = false;
		};

		/**
		 * Coach NG Lifecycle methods *************************************************************
		 */

		this.constructor.prototype.load = function() {
			console.log("CS-Thumbnail:load() : called from: " + this.context.viewid);
			try {
				var options = this.context.options;

				if (!this.context.binding) {
					this.context.binding = bpmext.ui.substituteObject(this);
				}

				if (!options.height) {
					options.height = bpmext.ui.substituteConfigOption(this, "height", null);
				}
				if (!options.width) {
					options.width = bpmext.ui.substituteConfigOption(this, "width", null);
				}
				
				if (!options.objectStoreName) {
                    options.objectStoreName = bpmext.ui.substituteConfigOption(this, "objectStoreName", null);
				}
				
				this._instance.envelope = document.createElement("div");
				domClass.add(this._instance.envelope, "CS_ImageDiv");
				this._instance.img = document.createElement("img");

				this._proto._setHeight(this);
				this._proto._setWidth(this);

				this._instance.envelope.appendChild(this._instance.img);
				this.context.element.appendChild(this._instance.envelope);

				domClass.add(this.context.element, "CS_Thumbnail");

				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONERROR, "message");

				bpmext.ui.loadView(this);

				this._proto._loadImage(this, null);
				
			} catch (e) {
				if (this.ui && this.ui.getAbsoluteName) {
					bpmext.log.error("Error on load event [" + this.ui.getAbsoluteName() + "]: " + e);
				} else {
					bpmext.log.error("Error on load event: " + e);
				}
			}
		};

		this.constructor.prototype.view = function() {
			console.log("CS-Thumbnail:view() : called from: " + this.context.viewid);
			try {
				this._proto._handleVisibility(this);
				// Check for a bound object use it to re-render the properties UX with
				if (this.context.binding) {
					var boundProperty = this.context.binding.property;
					if (boundProperty != null) {
						var contentItem = this.context.binding.boundObject[boundProperty];
						if (contentItem.id != null && contentItem.id != "") {
							console.log("CS-Thumbnail:view() : View update for: " + contentItem.name);
							this._proto._loadImage(this, contentItem);
						} else {
							console.log("CS-Thumbnail:view() : No bound object to view.");
						}
					}
				}
			} catch(e) {
				bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
			}
		};

		this.constructor.prototype.change = function (event) {
			console.log("CS-Thumbnail:change() : called from: " + this.context.viewid);
			try {
				var view = this;
				if (event.type == "config") {
					switch (event.property) {
						case "width": {
							this._proto._setWidth(this, event.newVal);
							break;
						}
						case "height": {
							this._proto._setHeight(this, event.newVal);
							break;
						}
					}
				} else { 
					if (this.context.binding && event.newVal && event.newVal.id) {
						var boundObject = this.context.binding.boundObject;
						if (boundObject != null) {
							var contentItem = event.newVal;
							console.log("CS-Thumbnail:change() : Change update for bound object: " + contentItem.name);

							this._proto._loadImage(view, contentItem);
						}
					} else {
						this._proto._displayNoItemSelected(view);
					}
				}
			} catch (e) {
				bpmext.log.error("Error on change event [" + this.ui.getAbsoluteName() + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};

		this.constructor.prototype.unload = function() {
			bpmext.ui.unloadView(this);
		};
	}
}
