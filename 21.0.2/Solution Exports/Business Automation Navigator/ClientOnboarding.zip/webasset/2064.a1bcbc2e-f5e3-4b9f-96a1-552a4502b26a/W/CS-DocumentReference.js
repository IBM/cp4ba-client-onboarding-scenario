/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

cs_InitDocumentReference = function(utilities, bpmext, domClass, domStyle, domAttr, messages, string) {
	
	this._instance = {
		serverConfigurationName: "GRAPHQL_APP_RESOURCE",
		contentItem: null,
		parentFolder: null,
		uploadContent: null,
		uploadDetailsText: null,
		getProperties: {},
		_openDocumentWindows: {}
	};
	
	if (!this.constructor.prototype._proto)	{
		
		this.constructor.prototype._proto =	{
			
			EVT_ONADD: "eventON_ADD",
			EVT_ONCLEAR: "eventON_CLEAR",
			EVT_ONCONTEXTMENUOPEN: "eventON_CONTEXTMENUOPEN",
			EVT_ONERROR: "eventON_ERROR",

			privilegeToBitmask: {
				"privEditProperties": 0x2,
				"privAddToFolder": 0x10,
				"privViewDoc": 0x80,
				"privDelete": 0x10000,
				"privMajorVersion": 0x4,
				"privMinorVersion": 0x40,
				"privAddItem": 0x100,
			},	
			actions: {
				checkoutDocument: "CheckoutDocument",
				uploadVersion: "UploadVersion",
				editDocument: "EditDocument",
				cancelCheckout: "CancelCheckout",
				renameFolder: "RenameFolder",
				createFolder: "CreateFolder",
				deleteDocument: "DeleteDocument",
				deleteFolder: "DeleteFolder",
				deleteAbstract: "DeleteAbstract",
				addDocument: "AddDocument",
				addFolder: "AddFolder",
				documentProperties: "DocumentProperties",			
				folderProperties: "FolderProperties",
				abstractProperties: "AbstractProperties",
			},

			_handleVisibility: function (view) {
				var vis = utilities.handleVisibility(view.context);
			},

			_setAlertMessage: function(view, message, isError, delay) {
				var title = messages.contlist_progress_success;
				var style = "S";
				if (isError) {
					title = messages.contlist_progress_alert;
					style = "D";
				}
				// Call out to the CS_Alert utility class to handle displaying the alert message
				setAlertMessage(title, message, style, delay, domClass, domStyle, domAttr, messages);
			},

			_setHeight: function(view) {
				var size = view.context.options.height.get("value");
				if (size) {
					try	{
						if (size != null && size != "")	{	
							if (!isNaN(size)) {
								size += "px";
							}
							view.context.element.style.height = size;
							// The size really specifies the height of the thumbnail
							var thumbnail = view.ui.get("Thumbnail");
							thumbnail._instance.envelope.style.height = size;
							thumbnail._instance.img.style.height = size;
						}
					} catch (e)	{
						bpmext.log.error("CS-DocumentReference._setHeight() error: " + e);
						if (e.stack) {
							bpmext.log.error("  Call stack: " + e.stack);
						}
					}
				}
			},
			
			_setWidth: function(view) {
				var size = view.context.options.width.get("value");
				if (size) {
					try {
						if (size != null && size != "") {
							if (!isNaN(size)) {
								size += "px";
							}
							view.context.element.style.width = size;

							var normalNameText = view.ui.get("NormalNameText");
							normalNameText.context.element.style.width = size;
							
							// The size really specifies the width of the thumbnail
							var thumbnail = view.ui.get("Thumbnail");
							thumbnail._instance.envelope.style.width = size;
							thumbnail._instance.img.style.width = size;
						}
					} catch (e)	{
						bpmext.log.error("CS-DocumentReference._setWidth() error: " + e);
						if (e.stack) {
							bpmext.log.error("  Call stack: " + e.stack);
						}
					}
				}
			},
			
			/**
			 * Helper function to retrieve the Object Store Name as defined in ACCE admin tool. This is the 
			 * string that will be passed to all the graphql action services since it's working against CE
			 * and not ICN).
			 */
			_getObjectStoreName: function(view) {
				var objectStoreName = view.context.options.objectStoreName.get("value");
				return objectStoreName;
			},
	
			_displayMimeImage: function(view, contentItem, isLarge) {
				// Display image based on mime type of original document
				var cssClass = getMimeCssClass(contentItem, isLarge);
				
				var iconImg = view._instance._docImg;
				domClass.remove(iconImg, "CS_Image");
				if (view._instance.lastCssClass) {
					domClass.remove(iconImg, view._instance.lastCssClass);
				}
				domClass.add(iconImg, cssClass);
				view._instance.lastCssClass = cssClass;

				var	srcBlank = com_ibm_bpm_coach.getManagedAssetUrl('CS-blank.gif', com_ibm_bpm_coach.assetType_WEB, 'SYSCST', false);
				domAttr.set(iconImg, "src", srcBlank);

				if (contentItem.mimeType == null || contentItem.mimeType == "" ) {
					domAttr.set(iconImg, "title", messages.contlist_no_mimetype);
					domAttr.set(iconImg, "alt", messages.contlist_no_mimetype);
				} else {
					domAttr.set(iconImg, "title", contentItem.mimeType);
					domAttr.set(iconImg, "alt", contentItem.mimeType);
				}
			},

			_callService: function(service, params, setInputData) {
				// Create csrf token as a large random number
				var csrfToken = Math.floor(Math.random() * 10000000);
				console.log("CS-DocumentReference:_callService() : Csrf token: " + csrfToken);

				// Add the required token value to the service params
				params.csrfToken = csrfToken;
				if (setInputData) {
					service.setInputData(params);
					service.execute();
				} else {
					service.execute(params);
				}
			},
	
			_onGetProperties: function(view, contentItem, properties, callback, errback) {
				view._instance.getProperties[contentItem.id] = {
					callback: callback,
//					errback: errback
				};
				view._instance.propertiesErrback = errback; // general error callback handling

				var params = {
					objectId: contentItem.id,
					objectType: contentItem.baseType,
					repository: this._getObjectStoreName(view),
					serverAppResource: view._instance.serverConfigurationName
				};

				if (properties && properties.length > 0) {
					params.properties = properties;
				} else {
					params.properties = ["DocumentTitle", "MimeType", "IsReserved", "Name", "Id"];
				}
				
				view._instance.getPropertiesSvc = view.ui.get("GetPropertiesSvc");
				this._callService(view._instance.getPropertiesSvc, params);
			},
		
			_loadView: function(view, contentItem) {
				console.log("CS-DocumentReference:_loadView() : called");
				var viewMode = view.context.options.viewMode.get("value");
				if (contentItem != null) {
					// Make sure the content item is a document
					if (contentItem.baseType != "Document" || contentItem.isFolder) {
						console.log("CS-DocumentReference:_loadView() : Error: Content item is not a document object.");
						this._renderEmptyView(view, viewMode);
						return;
					}
					view._instance.contentItem = contentItem;
					
					// Check to see if is has the appropriate properties already, if not make call to get them
					// Need name, mimeType (and cmThumbnails if in that view mode)
					var needMoreProperties = false;
					if (!contentItem.name || !contentItem.mimeType) {
						needMoreProperties = true;
					}
					if (viewMode == "T") {
						// Make sure cmThumbnails is part of the contentItem
						if (!contentItem.cmThumbnails) {
							needMoreProperties = true;
						}
					}
					if (needMoreProperties) {
						// Call service to retrieve the rest of the properties required to render
						var self = this;
						this._onGetProperties(view, contentItem, null, function(newContentItem) {
							self._renderDocumentView(view, newContentItem, viewMode);
						});
					} else {
						this._renderDocumentView(view, contentItem, viewMode);
					}
				} else {
					// If no contentItem yet, could be empty and need to display empty state or
					// The application maybe going to call setDocument at some point to load the view
					this._renderEmptyView(view, viewMode);
				}
			},
			
			_renderDocumentView: function(view, contentItem, viewMode) {
				console.log("CS-DocumentReference:_renderDocumentView() : called, view mode = " + viewMode);
				// Make sure the add document actions are not displayed
				var addMode = view.context.options.addMode.get("value");
				if (addMode == "none") {
					view._instance.emptyVerLayout = view.ui.get("EmptyVerticalLayout");
					view._instance.emptyVerLayout.setVisible(false);
					domStyle.set(view._instance.emptyVerLayout.context.element, "display", "none");
				} else {
					view._instance.emptyAddVerLayout = view.ui.get("EmptyAddVerticalLayout");
					view._instance.emptyAddVerLayout.setVisible(false);
					domStyle.set(view._instance.emptyAddVerLayout.context.element, "display", "none");
				}

				var docTitle = contentItem.name;
				var properties = contentItem.properties.items ? contentItem.properties.items : contentItem.properties;
				var propDocTitle = properties.find(property => property.id == "DocumentTitle");
				if (propDocTitle) {
					docTitle = propDocTitle.value;
				} else {
					// If no document title, try getting the "Name" property
					var propName = properties.find(property => property.id == "Name");
					if (propName) {
						docTitle = propName.value;
					}
				}

				if (viewMode == "N") {
					// Grab the horizontal layout and make it visible
					view._instance.normHorLayout = view.ui.get("NormalHorizontalLayout");
					view._instance.normHorLayout.setVisible(true);
					domStyle.set(view._instance.normHorLayout.context.element, "display", "");
					
					// Get the css class for the mime type image and apply it to the img (HTML component)
					var docImg = view.context.element.querySelector(".CS_NormalMimeImage");
					view._instance._docImg = docImg;
					this._displayMimeImage(view, contentItem, false);
					
					// Display the document name
					view._instance._normalNameText = view.ui.get("NormalNameText");
					view._instance._normalNameText.setVisible(true);
					view._instance._normalNameText.setText(docTitle);
					
					// Check to see if we need to display the clear link or the context menu actions
					this._renderActions(view, contentItem, view._instance._normalNameText, "NormalClearLink", ".CS_NormalContextMenuHTML");
					
				} else {
					// Grab the vertical layout and make it visible
					view._instance.thumbVerLayout = view.ui.get("ThumbnailVerticalLayout");
					view._instance.thumbVerLayout.setVisible(true);
					domStyle.set(view._instance.thumbVerLayout.context.element, "display", "");
	
					// Get the thumbnail component and load it with the contentItem
					view._instance._thumbnail = view.ui.get("Thumbnail");
					view._instance._thumbnail.setVisible(true);
					view._instance._thumbnail.setContentItem(contentItem); 

					// Display the document name
					view._instance._thumbnailNameText = view.ui.get("ThumbnailNameText");
					view._instance._thumbnailNameText.setVisible(true);
					view._instance._thumbnailNameText.setText(docTitle);

					// Check to see if we need to display the clear link or the context menu actions
					this._renderActions(view, contentItem, view._instance._thumbnailNameText, "ThumbnailClearLink", ".CS_ThumbnailContextMenuHTML");
				}
			},

			_renderActions(view, contentItem, nameText, clearLink, htmlButton) {
				// If the view allows removing the document, render the remove 'x' action on far right
				var allowsClearDoc = view.context.options.allowsClearDoc.get("value");
				var allowsActions = view.context.options.allowsActions.get("value");
				var allowsTitleAction = view.context.options.allowsTitleAction.get("value");

				if (allowsTitleAction) {
					// Get the document title element and add click handler for view action
					var nameTextElement = nameText.context.element;
	
					// Create the context menu so we can get the first action (it could be a custom action)
					window.CSContextMenu.removeContextMenu(view, domClass);
					view._instance.menu = {};
					var wrapper = window.CSContextMenu.createWrapper(view, domClass, domAttr);
					var chartMenu = window.CSContextMenu.createChartMenu(view, domClass);
					var chartMenuInner = window.CSContextMenu.createChartMenuInner(view, chartMenu, domClass, domAttr);
					var menuTable = window.CSContextMenu.createMenuTable(view, domClass, domAttr);

					var firstAction = view._proto._populateContextMenu(view, contentItem, allowsClearDoc); 
					var clickFunc = firstAction.onclick;
	
					if (view._instance.mouseUpFunc) {
						nameTextElement.removeEventListener('mouseup', view._instance.mouseUpFunc);
						nameTextElement.removeEventListener('keypress', view._instance.kypressFunc);
					}

					view._instance.mouseUpFunc = function(evt) {
						evt.preventDefault();
						evt.stopPropagation();
						clickFunc(view, contentItem);
					};					
					nameTextElement.addEventListener('mouseup', view._instance.mouseUpFunc, false);			
					
					view._instance.kypressFunc = function(evt) {
						var keyID = (evt.charCode) ? evt.charCode : ((evt.which) ? evt.which : evt.keyCode);
						if (keyID == 13 || keyID == 32) {
							evt.preventDefault();
							clickFunc(view, contentItem);
						}
					};					
					nameTextElement.addEventListener('keypress', view._instance.kypressFunc, false);
									
					domClass.add(nameTextElement, "CS_TitleAction");					
					domAttr.set(nameTextElement, "tabindex", "0");					
				}
				
				if (allowsActions) {
					view._instance.ctxMenuButton = this._renderContextMenuButton(view, contentItem, allowsClearDoc);
					var contextMenuHtml = view.context.element.querySelector(htmlButton);
					while (contextMenuHtml.firstChild) {
						contextMenuHtml.removeChild(contextMenuHtml.firstChild);
					}
					contextMenuHtml.appendChild(view._instance.ctxMenuButton);
				
					// Need to hide the clear link in the control, will be rendered in the context menu instead
					view._instance._clearLink = view.ui.get(clearLink);
					view._instance._clearLink.setVisible(false);
					if (view._instance._clearLink.context) {
						domStyle.set(view._instance._clearLink.context.element, "display", "none");
					}
				} else if (allowsClearDoc) {
					view._instance._clearLink = view.ui.get(clearLink);
					domAttr.set(view._instance._clearLink.context.element, "title", messages.docref_clear);

					var contextMenuHtml = view.context.element.querySelector(htmlButton);
					domStyle.set(contextMenuHtml, "display", "none");						
				} else {
					// Need to hide the clear link
					view._instance._clearLink = view.ui.get(clearLink);
					view._instance._clearLink.setVisible(false);
					if (view._instance._clearLink.context) {
						domStyle.set(view._instance._clearLink.context.element, "display", "none");
					}
				}					
			},
			
			_renderEmptyView: function(view, viewMode) {
				console.log("CS-DocumentReference:_renderEmptyView() : called, view mode = " + viewMode);
				if (viewMode == "N") {
					view._instance.normHorLayout = view.ui.get("NormalHorizontalLayout");
					view._instance.normHorLayout.setVisible(false);
					domStyle.set(view._instance.normHorLayout.context.element, "display", "none");
				} else {
					view._instance.thumbVerLayout = view.ui.get("ThumbnailVerticalLayout");
					view._instance.thumbVerLayout.setVisible(false);
					domStyle.set(view._instance.thumbVerLayout.context.element, "display", "none");
				}
				
				var addMode = view.context.options.addMode.get("value");
				if (addMode == "none") {
					// Grab the vertical layout and make it visible
					view._instance.emptyVerLayout = view.ui.get("EmptyVerticalLayout");
					view._instance.emptyVerLayout.setVisible(true);
					domStyle.set(view._instance.emptyVerLayout.context.element, "display", "");
							
					var helperText = view.context.options.helperText.get("value");
					if (helperText) {
						view._instance._emptyHelperText = view.ui.get("EmptyHelperText"); // Helper message below field
						view._instance._emptyHelperText.setVisible(true);
						view._instance._emptyHelperText.setText(helperText);
					}

					if (viewMode == "N") {
						// Need to set the height/width of the normal view by adding css class CS_EmptyNormalSize
						domClass.add(view._instance.emptyVerLayout.context.element, "CS_EmptyNormalSize");
					} else {
						// Set the height/width of the thumbnail sized view field by adding css class CS_EmptyThumbnailSize
						domClass.add(view._instance.emptyVerLayout.context.element, "CS_EmptyThumbnailSize");
					}
				} else {
					// Grab the vertical layout with add support and make it visible
					view._instance.emptyAddVerLayout = view.ui.get("EmptyAddVerticalLayout");
					view._instance.emptyAddVerLayout.setVisible(true);
					domStyle.set(view._instance.emptyAddVerLayout.context.element, "display", "");

					var hintText = view.context.options.hintText.get("value");
					if (hintText) {
						var fileButton = view.context.element.querySelector(".CS_DocRefFileButton");
						while (fileButton.firstChild) {
							fileButton.removeChild(fileButton.firstChild);
						}
						var txt = document.createTextNode(hintText);
						fileButton.appendChild(txt);	
					}
					
					var helperText = view.context.options.helperText.get("value");
					if (helperText) {
						view._instance._emptyAddHelperText = view.ui.get("EmptyAddHelperText"); // Helper message below field
						view._instance._emptyAddHelperText.setVisible(true);
						view._instance._emptyAddHelperText.setText(helperText);
					}

					this._createAddEventHandlers(view);
				}
			},
			
			_createAddEventHandlers: function(view) {
				console.log("CS-DocumentReference:_createAddEventHandlers() : called.");
				view._instance.uploadContent = view.ui.get("UploadContent");
			
				var fileUpload = view.context.element.querySelector(".CS_DocRefFileUpload");
				var self = this;

				fileUpload.addEventListener('dragover', function(evt) {
					evt.preventDefault();
					evt.stopPropagation();
					self._onExternalDragOver(evt, view, fileUpload);
				}, false);
			
				fileUpload.addEventListener('dragleave', function(evt) {
					evt.preventDefault();
					evt.stopPropagation();
					self._onExternalDragLeave(evt, view, fileUpload);
				}, false);

				var addMode = view.context.options.addMode.get("value");
				if (addMode == "withui") {

					fileUpload.addEventListener('drop', function(evt) {
						evt.preventDefault();
						evt.stopPropagation();
						event.stopPropagation();
						self._addDocument(view, event.dataTransfer.files);
					}, false);

					fileUpload.addEventListener('mouseup', function(evt) {
						evt.preventDefault();
						evt.stopPropagation();
						self._addDocument(view);					
					}, false);
					
					var clickFunction = function(evt) {
						var keyID = (evt.charCode) ? evt.charCode : ((evt.which) ? evt.which : evt.keyCode);
						if (keyID == 13 || keyID == 32) {
							evt.preventDefault();
							self._addDocument(view);					
						}
					};					
					fileUpload.addEventListener('keypress', clickFunction, false);

					var hintText = view.context.options.hintText.get("value");
					if (hintText) {
						var docRefFileModal = view.context.element.querySelector(".CS_DocRefFileModal");
						while (docRefFileModal.firstChild) {
							docRefFileModal.removeChild(docRefFileModal.firstChild);
						}
						var txt = document.createTextNode(hintText);
						docRefFileModal.appendChild(txt);	
					}
					
					var docRefFile = view.context.element.querySelector(".CS_DocRefFile");
					domStyle.set(docRefFile, "display", "none");
			
				} else {
					
					fileUpload.addEventListener('drop', function(evt) {
						evt.preventDefault();
						evt.stopPropagation();
						event.stopPropagation();
						self._onExternalDrop(evt, view, fileUpload);
					}, false);
					
					var fileInput = view.context.element.querySelector(".CS_DocRefFileInput");
					var acceptFileTypes = view.context.options.acceptFileTypes.get("value");
					if (acceptFileTypes && acceptFileTypes.items.length > 0) {
						var fileTypesString = "";
						for (var i = 0; i < acceptFileTypes.items.length; i++) {
							fileType = acceptFileTypes.items[i].trim();
							if (fileType.startsWith(".")) {
								fileTypesString += fileType;
							} else {
								fileTypesString += "." + fileType; // Add dot if missing
							}
							if (i < acceptFileTypes.items.length - 1) {
								fileTypesString += ",";
							}
						}
						domAttr.set(fileInput, "accept", fileTypesString);
					}

					fileInput.onchange = function() {
						if (this.files.length > 0) {
							self._uploadFiles(this.files, null, view);
						}
					}	
					
					var docRefFile = view.context.element.querySelector(".CS_DocRefFile");
					var clickFunction = function(evt) {
						var keyID = (evt.charCode) ? evt.charCode : ((evt.which) ? evt.which : evt.keyCode);
						if (keyID == 13 || keyID == 32) {
							evt.preventDefault();
							fileInput.dispatchEvent(new MouseEvent("click")); 
						}
					};					
					docRefFile.addEventListener('keypress', clickFunction, false);
				}
			},
			
			_onExternalDragOver: function(event, view, fileUpload) {
				event.preventDefault();
				domClass.add(fileUpload, "CS_DocRefDragOver");
			},

			_onExternalDrop: function(event, view, fileUpload) {
				this._onExternalDragLeave(event, view, fileUpload);
				event.preventDefault();
				this._uploadFiles(event.dataTransfer.files, event.dataTransfer.items, view);
			},
		
			_onExternalDragLeave: function(event, view, fileUpload) {
				event.preventDefault();
				domClass.remove(fileUpload, "CS_DocRefDragOver");
			},
		
			_uploadFiles: function(files, items, view) {
				document.body.style.cursor = 'wait';
				this._uploadFile(files, items, view, 0, function() {
					document.body.style.cursor = 'default';
					console.log("CS-DocumentReference:_uploadFiles() : Uploaded successfully.");
				}, function(error) {
					document.body.style.cursor = 'default';
					console.log("CS-DocumentReference:_uploadFiles() : Error occured.");
				});
			},

			_checkForFolders: function(view, items) {
				var foundFolder = false;
				if (items) {
					for (var i = 0; i < items.length; i++) {
						var item = items[i];
						var entry;
						if ((item.webkitGetAsEntry != null) && (entry = item.webkitGetAsEntry())) {
							if (!entry.isFile){
								foundFolder = true;
								break;
							}
						} else if (item.getAsFile == null || item.kind !== "file") {
							foundFolder = true;
							break;
						}
					}
				}
				return foundFolder;
			},
			
			_checkFileType: function(view, files) {
				var filesOfWrongType = [];
				var acceptFileTypes = view.context.options.acceptFileTypes.get("value");
				if (acceptFileTypes && acceptFileTypes.items.length > 0) {
					for (var i = 0; i < files.length; i++) {
						var file = files[i];
						var ext =  "." + file.name.split('.').pop();
						ext = ext.toLowerCase();
						// Compare the selected files dot etension with those that are allowed
						var allowedFileType = false;
						for (var j = 0; j < acceptFileTypes.items.length; j++) {
							var acceptFileType = acceptFileTypes.items[j].trim();
							if (!acceptFileType.startsWith(".")) {
								acceptFileType = "." + acceptFileType;
							}
							if (ext == acceptFileType.toLowerCase()) {
								allowedFileType = true;
								break;
							}
						}
						if (!allowedFileType) {
							filesOfWrongType.push(file.name);
						}
					}
				}
				return filesOfWrongType;
			},

			_checkFileSize: function(view, files) {
				var filesThatAreTooBig = [];
				var maxDocumentSize = view.context.options.maxDocumentSize.get("value");
				if (maxDocumentSize > 0) {
					for (var i = 0; i < files.length; i++) {
						var file = files[i];
						// Divide the real file size by 1024 to get the the size in KB 
						if ((file.size/1024) > maxDocumentSize) {
							filesThatAreTooBig.push(file.name);
						}
					}
				}
				return filesThatAreTooBig;
			},
			
			_addDocument: function(view, files) {
				console.log("CS-DocumentReference:_addDocument() : Called.");
				// Grab the parent folder id (if one has been set), will file the document in this folder
				var parentFolderId = view._instance.parentFolder;
				
				var addDocumentModal = view.ui.get("AddDocumentModal");
				addDocumentModal.setObjectStoreName(this._getObjectStoreName(view));
				
				// Check for any document classes configured, and pass them in if so
				var documentType = view.context.options.defaultDocumentType.get("value");
				if (documentType) {
					var docClasses = [];
					docClasses.push({
						name: documentType,
						value: documentType
					});
					addDocumentModal.setDocumentClasses(docClasses);
				}
				// Check to see if there were any accepted file types specified in config settings
				var acceptFileTypes = view.context.options.acceptFileTypes.get("value");
				if (acceptFileTypes && acceptFileTypes.items.length > 0) {
					addDocumentModal.setAcceptFileTypes(acceptFileTypes.items);
				}
				// Check for a max document size configured, and pass it in if so
				var maxDocumentSize = view.context.options.maxDocumentSize.get("value");
				if (maxDocumentSize > 0) {
					addDocumentModal.setMaxDocumentSize(maxDocumentSize);
				}
				// Check for the config setting to hide the time portion of date properties
				var hideTimePicker = view.context.options.hideTimePicker.get("value");
				if (hideTimePicker) {
					addDocumentModal.setHideTimePicker(hideTimePicker);
				}
				
				var self = this;
				addDocumentModal.addDocument(parentFolderId, files, null, null, null, null, function(contentItem) {
					// Completed successfully, send out event
					bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONADD, contentItem);
				}, function(message) {
					// There was an error trying to add the document
					bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONERROR, message);
				});		
			},		
			
			_uploadFile: function(files, items, view, index, callback, errback) {
				var self = this;
				// Check for folders, can only drop files
				var foundFolder = this._checkForFolders(view, items);
				if (foundFolder) {
					var message = messages.contlist_drop_folder_error;
					view._proto._setAlertMessage(view, message, true);
					bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONERROR, message);
					errback(message);
				} else if (files.length > 1) {  // Hard coding the max number of documents that can be added to 1.
					document.body.style.cursor = 'default';
					var message = string.substitute(messages.contlist_add_doc_max_exceeded, ["1", files.length]);
					view._proto._setAlertMessage(view, message, true, 6000);
					bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONERROR, message);
					errback(message);
				} else {
					// Check to see if the files are of the correct file type(s) if they have been specified
					var filesOfWrongType = this._checkFileType(view, files);
					if (filesOfWrongType && filesOfWrongType.length > 0) {
						var message = "";
						if (filesOfWrongType.length == 1) {
							message = string.substitute(messages.filedropzone_filewrongtype, [filesOfWrongType[0]]);
						} else {
							var filesMessage = "";
							for (var i = 0; i < filesOfWrongType.length; i++) {
								filesMessage += filesOfWrongType[i];
								if (i < filesOfWrongType.length - 1) {
									filesMessage += ", ";
								}
							}
							message = string.substitute(messages.filedropzone_fileswrongtype, [filesMessage]);							
						}
						if (files.length > filesOfWrongType.length) {
							message = string.substitute(messages.filedropzone_filesnotadded, [message]);
						}
						var alertTime = 6000;
						if (filesOfWrongType.length > 2) {
							alertTime = 10000;
						}
						view._proto._setAlertMessage(view, message, true, alertTime);
						bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONERROR, message);
						errback(message);					
					} else {
						// Check to see if a max file size setting has been specified and if any files are too big
						var filesThatAreTooBig = this._checkFileSize(view, files);
						if (filesThatAreTooBig && filesThatAreTooBig.length > 0) {
							var message = "";
							if (filesThatAreTooBig.length == 1) {
								message = string.substitute(messages.filedropzone_filetoobig, [filesThatAreTooBig[0]]);
							} else {
								var filesMessage = "";
								for (var i = 0; i < filesThatAreTooBig.length; i++) {
									filesMessage += filesThatAreTooBig[i];
									if (i < filesThatAreTooBig.length - 1) {
										filesMessage += ", ";
									}
								}
								message = string.substitute(messages.filedropzone_filestoobig, [filesMessage]);							
							}
							if (files.length > filesThatAreTooBig.length) {
								message = string.substitute(messages.filedropzone_filesnotadded, [message]);
							}
							var alertTime = 6000;
							if (filesThatAreTooBig.length > 2) {
								alertTime = 10000;
							}
							view._proto._setAlertMessage(view, message, true, alertTime);
							bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONERROR, message);
							errback(message);					
						} else {
							if (index >= files.length) {
								if (files.length == 1) {
									console.log("CS-DocumentReference:_uploadFile() : Successfully added the file.");
									view._proto._setAlertMessage(view, messages.contlist_add_doc_success, false);	
								} else {
									console.log("CS-DocumentReference:_uploadFile() : Successfully added the files.");
									view._proto._setAlertMessage(view, messages.contlist_add_docs_success, false);	
								}
								callback();
							} else {
								var file = files[index];
								// See if a document type has been specified in the config settings, if not use base Document type
								var documentType = view.context.options.defaultDocumentType.get("value");
								if (documentType == null || documentType == "") {
									documentType = "Document";
								}
								console.log("CS-DocumentReference:_uploadFile() : Adding document with type: " + documentType + " and name: " + file.name);
								
								view._instance.uploadContent.uploadFileSimpleWithClass(view._instance.parentFolder, file, documentType, function(result) {
									var contentItem = self._updateDocumentContentItem(result);
									// Load the view with the newly added document
									view._proto._loadView(view, contentItem);
									
									bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONADD, contentItem);

									// If there were multiple files selected or dropped, get the file at the next index and add it.
									view._proto._uploadFile(files, null, view, ++index, callback, errback);
								}, function(error) {
									var message = string.substitute(messages.contlist_add_document_failed, [file.name]);
									view._proto._setAlertMessage(view, message, true, 6000);
									bpmext.ui.executeEventHandlingFunction(view, self.EVT_ONERROR, message);
									errback(error);
								});		
							}
						}
					}
				}
			},

			_renderContextMenuButton: function(view, contentItem, allowsClearDoc) {
				var div = document.createElement("div");
				domAttr.set(div, "tabindex", "0");
				domAttr.set(div, "aria-label", "Open context menu button"); // Todo: add to resource bundle
				domClass.add(div, "bx--overflow-menu");
				
				// Save the context menu button div off for later, when we want to close the menu and restyle the button
				view._instance.ctxMenuButtonDiv = div;			
				
				div.onclick = function(event) {
					view._instance.event = event;
					var isVisible = window.CSContextMenu.determineContextMenuPopupVisibility(view, null, domClass);
					view._proto._showHideContextMenuPopup(view, contentItem, allowsClearDoc, isVisible);
					domAttr.set(div, "aria-expanded", isVisible);
					var isVisible = window.CSContextMenu.determineContextMenuPopupVisibility(view, null, domClass);
				};
				
				div.addEventListener('keypress', function(evt) {
					var keyID = (evt.charCode) ? evt.charCode : ((evt.which) ? evt.which : evt.keyCode);
					if (keyID == 13 || keyID == 32) {
						if (!domClass.contains(this, "disabled")) {
							view._instance.event = evt;
							var isVisible = window.CSContextMenu.determineContextMenuPopupVisibility(view, null, domClass);
							view._proto._showHideContextMenuPopup(view, contentItem, allowsClearDoc, isVisible);
							domAttr.set(div, "aria-expanded", isVisible);
							window.CSContextMenu.showHideContextMenuButton(event.srcElement, true, domClass);
						}
						evt.preventDefault();
					}
				});

				var	srcCtxButton = com_ibm_bpm_coach.getManagedAssetUrl('CS-ContextMenuButton.svg', com_ibm_bpm_coach.assetType_WEB, 'SYSCST', false);

				var iconImg = document.createElement("img");
				domClass.add(iconImg, "bx--overflow-menu__icon");
				domAttr.set(iconImg, "src", srcCtxButton);

				div.appendChild(iconImg);
				
				return div;
			},
	
			_showHideContextMenuPopup: function(view, contentItem, allowsClearDoc, isVisible) {
				if (!isVisible) {
					// Clear the old context menu and always recreate a new one (to have current state and access mask checking)
					window.CSContextMenu.removeContextMenu(view, domClass);
					
					view._instance.menu = {};
					var chartDiv = document.body;
			
					var wrapper = window.CSContextMenu.createWrapper(view, domClass, domAttr);
					var chartMenu = window.CSContextMenu.createChartMenu(view, domClass);
					var chartMenuInner = window.CSContextMenu.createChartMenuInner(view, chartMenu, domClass, domAttr);
					var menuTable = window.CSContextMenu.createMenuTable(view, domClass, domAttr);

					// Create the real menu actions
					var firstAction = view._proto._populateContextMenu(view, contentItem, allowsClearDoc); 
					
					chartMenuInner.appendChild(menuTable);

					var closeMenu = function(target) {
						setTimeout(function () {
							domClass.remove(chartMenu, "open");
//							target.focus();
							window.CSContextMenu.showHideContextMenuButton(target, false, domClass);
						});
					};
					
					chartMenuInner.onblur = function(event) {
						event.stopPropagation();
						setTimeout(function () {
							if (!chartMenu.contains(document.activeElement)) {
								var target = event.target || event.srcElement;
								closeMenu(target);
							}
						}, 150);
					};

					// Setup the mouse events so we can click outside the context menu and have it close
					var overMenu = false;
					chartMenuInner.onmouseover = function(evt) {
						overMenu = true;
					};

					chartMenuInner.onmouseout = function(evt) {
						overMenu = false;
					};

					document.onmousedown = function(evt) {
						if (overMenu == false) {
							var target = event.target || evt.srcElement;
							closeMenu(target);
						}
					};
					
					chartMenuInner.onkeydown = function(evt) {
						var keyID = (evt.charCode) ? evt.charCode : ((evt.which) ? evt.which : evt.keyCode);
						// Esc, Enter and Spacebar
						if (keyID == 27 || keyID == 13 || keyID == 32) {
							var target = event.target || event.srcElement;
							closeMenu(target);
						} else if (keyID == 9) { // Tab out of last item, should close the menu
							var classList = evt.srcElement.classList;
							for (var i = 0; i < classList.length; i++) {
								var className = classList[i];
								// If we are tabbing from the last action item in the menu, close it
								if (className == "LastMenuItem") {
									var target = event.target || event.srcElement;
									closeMenu(target);
									break;
								}
								if (evt.shiftKey && className == "FirstMenuItem") {
									var target = event.target || event.srcElement;
									closeMenu(target);
									break;
								}
							}
						} else if (keyID == 40) { // Arrow down
							evt.preventDefault();
							var nextSibling = evt.srcElement.nextSibling;
							if (nextSibling != null) {
								if (nextSibling.className == "mnTrSeparator") {
									nextSibling = nextSibling.nextSibling;
								}
								nextSibling.focus();
							} else { // Cycle around to top
								var parentElement = evt.srcElement.parentElement;
								parentElement.firstElementChild.focus();
							}
						} else if (keyID == 38) { // Arrow up
							evt.preventDefault();
							var previousSibling = evt.srcElement.previousSibling;
							if (previousSibling != null) {
								if (previousSibling.className == "mnTrSeparator") {
									previousSibling = previousSibling.previousSibling;
								}
								previousSibling.focus();
							} else { // Cycle around to bottom
								var parentElement = evt.srcElement.parentElement;
								parentElement.lastElementChild.focus();
							}
						}
					};

					chartMenu.onclick = function() {
						var target = event.target || event.srcElement;
						closeMenu(target);
					};

					wrapper.appendChild(chartMenu);
					view.context.element.appendChild(wrapper);

					var event = view._instance.event;

					// Fix chart menu visibility behavior on chart data point click
					domClass.add(chartMenu, "open");
					window.CSContextMenu.positionContextMenu(view, event, chartMenu, chartDiv);
					domClass.remove(chartMenu, "open");
					
					setTimeout(function () {
						domClass.add(chartMenu, "open");
						window.CSContextMenu.positionContextMenu(view, event, chartMenu, chartDiv);
						if (firstAction) {
							firstAction.focus(); // Set focus to first item in the context menu
						}
					}, 230);
					
				} else {
					var chartMenu = view._instance.menu.chartMenu;
					var event = view._instance.event;
					var target = event.target || event.srcElement;

					setTimeout(function () {
						domClass.remove(chartMenu, "open");
//						target.focus();
						window.CSContextMenu.showHideContextMenuButton(target, false, domClass);
					});
				}
			},

			_populateContextMenu: function(view, contentItem, allowsClearDoc) {
				view._instance.menu._ptMenuItems = [];
				
				// Check the configuration settings to see if actions have been hidden
/*
				var hideViewDocument = view.context.options.hideViewDocument.get("value");
				var hideUploadNewVersionDocument = view.context.options.hideUploadNewVersionDocument.get("value");
				var hideDownloadDocument = view.context.options.hideDownloadDocument.get("value");
				var hideEditDocument = view.context.options.hideEditDocument.get("value");
				var hideCheckoutDocument = view.context.options.hideCheckoutDocument.get("value");
				var hideCancelCheckoutDocument = view.context.options.hideCancelCheckoutDocument.get("value");
				var hideEditDocumentProperties = view.context.options.hideEditDocumentProperties.get("value");
				var hideDeleteDocument = view.context.options.hideDeleteDocument.get("value");
*/
				var hideViewDocument = false;
				var hideUploadNewVersionDocument = false;
				var hideDownloadDocument = false;
				var hideEditDocument = false;
				var hideCheckoutDocument = false;
				var hideCancelCheckoutDocument = false;
				var hideEditDocumentProperties = false;
				var hideDeleteDocument = false;
				
				// Check the access mask settings to see if actions should be disabled (greyed out)
				var canViewDoc = (contentItem.accessAllowed & this.privilegeToBitmask["privViewDoc"]) > 0;
				var canViewProperties = canViewDoc;
				if (canViewDoc) {
					// Check the mime type for being a no content element type document
					if (contentItem.mimeType == null) {
						canViewDoc = false;
					}
				}
				var canMajorVersion = (contentItem.accessAllowed & this.privilegeToBitmask["privMajorVersion"]) > 0;
				var canMinorVersion = (contentItem.accessAllowed & this.privilegeToBitmask["privMinorVersion"]) > 0;
				var canDelete = (contentItem.accessAllowed & this.privilegeToBitmask["privDelete"]) > 0;
	
				var isReserved = contentItem.isReserved;
//					var actionsEnabled = this._enableActionsCustomHandler(view, cellData);
				var actionsEnabled = true;

				if (!hideViewDocument) {
					var onclick = function() {
						view._proto._viewDocument(view, contentItem);
					};
					window.CSContextMenu.addMenuAction(view, view._instance.menu._ptMenuItems, "View", null, messages.contlist_menu_action_view, "", onclick, actionsEnabled && canViewDoc);
				}
				if (!hideUploadNewVersionDocument) {
					// Todo: if the document is already checked out, check if it's the current logged in user
					var canUploadNewVersion = canMajorVersion || canMinorVersion; 
					var onclick = function() {
						view._proto._onUploadVersion(view, contentItem);
					};
					window.CSContextMenu.addMenuAction(view, view._instance.menu._ptMenuItems, "Upload New Version", null, messages.contlist_menu_action_upload, "", onclick, actionsEnabled && canUploadNewVersion);
				}
				if (!hideDownloadDocument) {
					var onclick = function() {
						view._proto._onDownloadDocument(view, contentItem);
					};
					window.CSContextMenu.addMenuAction(view, view._instance.menu._ptMenuItems, "Download", null, messages.contlist_menu_action_download, "", onclick, actionsEnabled && canViewDoc);
				}
				if (!hideCheckoutDocument) {
					var canCheckout = !isReserved && (canMajorVersion || canMinorVersion); // Not checked out already and have permission to version
					
					var onclick = function() {
						view._proto._onCheckoutDocument(view, contentItem);
					};
					window.CSContextMenu.addMenuAction(view, view._instance.menu._ptMenuItems, "Check Out", null, messages.contlist_menu_action_checkout, "", onclick, actionsEnabled && canCheckout); 
				}
				if (!hideEditDocument) {
					// This is really the Checkout and Download action
					var canEdit = !isReserved && (canMajorVersion || canMinorVersion); // have permission to version
					
					var onclick = function() {
						view._proto._onEditDocument(view, contentItem);
					};
					window.CSContextMenu.addMenuAction(view, view._instance.menu._ptMenuItems, "Edit Document", null, messages.contlist_menu_action_edit_document, "", onclick, actionsEnabled && canEdit);
				}
				if (!hideCancelCheckoutDocument) {
					// Is checked out already and is same user that checked out the document in the first place
					var canCancel = isReserved; 
					// Need to check to see if current logged in user is the one who has the document checked out
					var isCurrentUser = window.CSContextMenu.isCurrentUserCheckout(view, contentItem);
					if (!isCurrentUser) {
						canCancel = false;
					}
					var onclick = function() {
						view._proto._onCancelCheckout(view, contentItem);
					};
					window.CSContextMenu.addMenuAction(view, view._instance.menu._ptMenuItems, "Cancel Check Out", null, messages.contlist_menu_action_cancel_checkout, "", onclick, actionsEnabled && canCancel);
				}
				if (!hideEditDocumentProperties){
					var onclick = function() {
						view._proto._onProperties(view, contentItem);
					};
					window.CSContextMenu.addMenuAction(view, view._instance.menu._ptMenuItems, "Properties", null, messages.contlist_menu_action_properties, "", onclick, actionsEnabled && canViewProperties);
				}
				if (!hideDeleteDocument) {
					var onclick = function() {
						view._proto._onDeleteObject(view, contentItem);
					};
					window.CSContextMenu.addMenuAction(view, view._instance.menu._ptMenuItems, "Delete Document", null, messages.contlist_menu_action_delete_doc, "", onclick, actionsEnabled && canDelete);
				}
				if (allowsClearDoc) {
					var onclick = function() {
						view._proto._onClearDocument(view, contentItem);
					};
					window.CSContextMenu.addMenuAction(view, view._instance.menu._ptMenuItems, "Clear Document", null, "Clear document", "", onclick, actionsEnabled);
				}
				
				// Setup and send out the open context menu event
				console.log("CS-DocumentReference:_populateContextMenu() : On context menu open event being fired.");
				bpmext.ui.executeEventHandlingFunction(view, this.EVT_ONCONTEXTMENUOPEN, view._instance.menu._ptMenuItems, contentItem);

				return window.CSContextMenu.populateMenuCategory(view, view._instance.menu._ptMenuItems, view._instance.menu.menuTable, domClass, domAttr);
			},

			_viewDocument: function(view, contentItem, callback) {
				console.log("CS-DocumentReference:_onUploadVersion() : called");
				var needToOpenWindow = true;
				var title = this._getWindowTitle(contentItem);
				// Check to see if this document is already opened in a viewer popup window
				if (view._instance._openDocumentWindows && view._instance._openDocumentWindows[title]) {
					if (view._instance._openDocumentWindows[title].window && !view._instance._openDocumentWindows[title].window.closed) {
						view._instance._openDocumentWindows[title].window.focus();
						needToOpenWindow = false;
					}
				}
				
				if (needToOpenWindow) {
					var contextRoot;
					var desktop = "default";
					var navUrl = window.location.href;
					
					var params = navUrl.split("&");
					for (var i = 0; i < params.length; i++) {
						var param = params[i].split("=");
						if (param[0] == "contextRoot") {
							var contextRootParam = decodeURIComponent(param[1]);
							// Still need to trim back to base Url part of this string
							var base = contextRootParam.split("?");
							var contextRoot = base[0];
							if (contextRoot[contextRoot.length - 1] != "/") {
								contextRoot += "/";
							}
						} else if (param[0] == "desktop") {
							// switch over to real desktop that is specified on url
							desktop = decodeURIComponent(param[1]);
						}
					}

					if (contextRoot != null) {
						var objectStoreName = this._getObjectStoreName(view);
						var id = contentItem.id;
						var className = contentItem.className;
						var mimeType = contentItem.mimeType;
						
						var docUrl = contextRoot + "bookmark.jsp?desktop=" + desktop;
						docUrl += "&objectStoreName=" + encodeURIComponent(objectStoreName);
						docUrl += "&repositoryType=p8";
						docUrl += "&docid=" + encodeURIComponent(id);
						docUrl += "&template_name=" + encodeURIComponent(className);
						docUrl += "&mimeType=" + encodeURIComponent(mimeType);
						docUrl += "&embedded=true";
						docUrl += "&hideToolbar=true"; // Hide the viewer containers banner bar (toolbar)
						
						var width = 860;
						var height = 600;
				
						var left = (screen.width - width) / 2;
						var top = (screen.height - height) / 2;
						
						var windowParams = "status=yes,location=no,scrollbars=yes,menubar=no,toolbar=no,personalbar=no,resizable=yes,left=" + left + ",top=" + top + ",width=" + width + ",height=" + height;
						
						var documentWindow = window.open(docUrl, title, windowParams); 
						view._instance._openDocumentWindows[title] = {
							window: documentWindow,
							callback: callback,  // Currently not used
							item: contentItem
						};
					} else {
						// No context root means we are running in test mode, display a alert message
						console.log("CS-DocumentReference:_viewDocument() : Running in test mode, no viewer will be displayed.");
						this._setAlertMessage(view, messages.contentviewer_test_mode, true, 6000);	
					}
				}
			},

			_getWindowTitle: function(contentItem) {
				var id = contentItem.id;
				var title = "file_" + id.replace(/[{,\-,},.,~,\t,\/]/g, "");  // Remove some characters that can not be used in a window title
				return title;
			},

			_onUploadVersion: function(view, contentItem) {
				console.log("CS-DocumentReference:_onUploadVersion() : called");
				view._instance.lastActionItem = contentItem;
				if (!contentItem.isReserved) {
					// Check out the document before opening the dialog.
					view._instance.checkoutForUpload = true;
					this._onCheckoutDocument(view, contentItem);
				} else {
					var uploadVersionModal = view.ui.get("UploadVersionModal");
					uploadVersionModal.uploadVersion(contentItem, function(updatedContentItem) {
						if (updatedContentItem) {
							// The document title may have changed and need to update the view if so
							updatedContentItem = view._proto._updateDocumentContentItem(updatedContentItem, view._instance.lastActionItem);
							view._proto._loadBindingView(view, updatedContentItem);
						}
					});
				}
			},

			_onCancelUploadVersion: function(view) {
				console.log("CS-DocumentReference:_onCancelUploadVersion() : called");
				if (view._instance.checkoutForUpload) {				
					var params = {
						action: this.actions.cancelCheckout,
						documentId: view._instance.lastActionItem.id,
						repository: this._getObjectStoreName(view),
						serverAppResource: view._instance.serverConfigurationName
					};
				
					view._instance.cancelCheckoutSvc = view.ui.get("CancelCheckoutSvc");
					this._callService(view._instance.cancelCheckoutSvc, params);
				}
			}, 

			_onDownloadDocument: function(view, contentItem) {
				console.log("CS-DocumentReference:_onDownloadDocument() : called");
				domStyle.set(view.context.element, "cursor", "wait"); 
				// Make call into get content componet to download the file contents to the browser (type = "file")
				var getContent = view.ui.get("GetContent");
				getContent.getContent(contentItem, "file", function() {
					// Don't display a success message, browser will do that
					domStyle.set(view.context.element, "cursor", "auto"); 
				}, function(error) {
					domStyle.set(view.context.element, "cursor", "auto"); 
					var errorText = error && error.errorText ? error.errorText : "";
					var errorMessage = string.substitute(messages.contlist_download_failed, [errorText]);
					view._proto._setAlertMessage(view, errorMessage, true);		
				});
			},
	
			_onCheckoutDocument: function(view, contentItem) {
				console.log("CS-DocumentReference:_onCheckoutDocument() : called");
				view._instance.actionName = this.actions.checkoutDocument;
				view._instance.lastActionItem = contentItem;
				
				// This action is ran without any UX
				var params = {
					action: this.actions.checkoutDocument,
					documentId: contentItem.id,
					repository: this._getObjectStoreName(view),
					serverAppResource: view._instance.serverConfigurationName
				};
				
				view._instance.checkoutDocumentSvc = view.ui.get("CheckoutDocumentSvc");
				this._callService(view._instance.checkoutDocumentSvc, params);
			},
	
			_onCheckoutDocumentResult: function(view) {
				try	{	
					var updatedContentItem;
					var response = view._instance.checkoutDocumentSvc && view._instance.checkoutDocumentSvc.getResult();
					if (response && response.results) {
						// The reservation state would have changed and need to update the view if so
						var reservationItem = response.results;
						updatedContentItem = this._updateDocumentContentItem(null, view._instance.lastActionItem, reservationItem);					
						view._proto._loadBindingView(view, updatedContentItem);
					}
					
					if (view._instance.checkoutForUpload) {
						// Make the checkout transparent when checking out prior to an upload.
						this._onUploadVersion(view, updatedContentItem);
					} else if (view._instance.actionName == this.actions.editDocument) {
						// Need to also download the document (after it's checked out)
						this._onDownloadDocument(view, view._instance.lastActionItem);
					} else {
						this._setAlertMessage(view, messages.contlist_checkout_success, false);
					}
				} catch(e) {
					bpmext.log.error("Error on AJAX service invocation [" + view.context.viewid + "]: " + e);
					if (e.stack) {
						bpmext.log.error("  Call stack: " + e.stack);
					}
				}
			},

			_onEditDocument: function(view, contentItem) {
				console.log("CS-DocumentReference:_onEditDocument() : called");
				view._instance.actionName = this.actions.editDocument;
				view._instance.lastActionItem = contentItem;

				// This action is ran without any UX
				var params = {
					action: this.actions.editDocument,
					documentId: contentItem.id,
					repository: this._getObjectStoreName(view),
					serverAppResource: view._instance.serverConfigurationName
				};
				
				view._instance.checkoutDocumentSvc = view.ui.get("CheckoutDocumentSvc");
				this._callService(view._instance.checkoutDocumentSvc, params);
			},

			_onCancelCheckout: function(view, contentItem) {
				console.log("CS-DocumentReference:_onCancelCheckout() : called");
				view._instance.actionName = this.actions.cancelCheckout;
				view._instance.lastActionItem = contentItem;
				
				// This action is ran without any UX
				var params = {
					documentId: contentItem.id,
					repository: this._getObjectStoreName(view),
					serverAppResource: view._instance.serverConfigurationName
				};
				
				view._instance.cancelCheckoutSvc = view.ui.get("CancelCheckoutSvc");
				this._callService(view._instance.cancelCheckoutSvc, params);
			},
			
			_onCancelCheckoutResult: function(view) {
				try	{
					if (view._instance.checkoutForUpload) {
						view._instance.checkoutForUpload = false;
						view._instance.actionName = "";
					} else {
						this._setAlertMessage(view, messages.contlist_cancel_checkout_success, false);
					}
				
					var response = view._instance.cancelCheckoutSvc && view._instance.cancelCheckoutSvc.getResult();
					if (response && response.results) {
						// The reservation state would have changed and need to update the view if so
						var lastContentItem = view._instance.lastActionItem;
						var updatedContentItem = this._updateDocumentContentItem(response.results, lastContentItem);
						view._proto._loadBindingView(view, updatedContentItem);
					}
				} catch(e) {
					bpmext.log.error("Error on AJAX service invocation [" + view.context.viewid + "]: " + e);
					if (e.stack) {
						bpmext.log.error("  Call stack: " + e.stack);
					}
				}
			},

			_onProperties: function(view, contentItem) {
				console.log("CS-DocumentReference:_onProperties() : called");
				view._instance.propertiesModal = view.ui.get("EditPropertiesModal");
				// Check for the config setting to hide the time portion of date properties
				var hideTimePicker = view.context.options.hideTimePicker.get("value");
				if (hideTimePicker) {
					view._instance.propertiesModal.setHideTimePicker(hideTimePicker);
				}
				view._instance.propertiesModal.editProperties(contentItem, function(updatedContentItem) {
					if (updatedContentItem) {
						// The document title may have changed and need to update the view if so
						updatedContentItem = view._proto._updateDocumentContentItem(updatedContentItem, contentItem, null);
						view._proto._loadBindingView(view, updatedContentItem);
					}
				});
			},

			_onDeleteObject: function(view, contentItem) {
				console.log("CS-DocumentReference:_onDeleteObject() : called");
				view._instance.deleteObjectModal = view.ui.get("DeleteObjectModal");
				view._instance.deleteObjectModal.deleteObject(contentItem, null, function(updatedContentItem) {
					if (updatedContentItem) {
						// The document title may have changed and need to update the view if so
						view._proto._loadView(view, null);						
					}
				});
			},
			
			_onClearDocument: function(view, contentItem) {
				console.log("CS-DocumentReference:_onClearDocument() : called");
				if (contentItem == null) {
					contentItem = view._instance.contentItem;
				}
				bpmext.ui.executeEventHandlingFunction(view, this.EVT_ONCLEAR, contentItem);
				view._proto._loadView(view, null);				
			},
	
			_loadBindingView(view, contentItem) {
				// Check for a bound object and update it's properties
				if (view.context.binding) {
					var boundProperty = view.context.binding.property;
					if (boundProperty != null) {
						contentItem.propertyUpdate = true;
						contentItem.viewerUpdate = false;
						view.context.binding.set("value", contentItem);
					}
				} else {
					// If there is no binding, just manually update the view
					view._proto._loadView(view, contentItem);	
				}
			},
			
			_updateDocumentContentItem: function(contentItem, lastContentItem, reservationItem) {
				var newContentItem;
				if (lastContentItem) {
					newContentItem = lastContentItem;
					if (contentItem && contentItem.properties) {
						newContentItem.properties = contentItem.properties;
					}
				} else {
					newContentItem = {
						baseType: "Document",
						isFolder: false,
						properties: contentItem.properties
					};
					if (contentItem.className) {
						newContentItem.className = contentItem.className;
					}
					if (contentItem.accessAllowed) {
						newContentItem.accessAllowed = contentItem.accessAllowed;
					}
				}
				
				if (contentItem && contentItem.contentElements != null) {
					newContentItem.contentElements = contentItem.contentElements;
				}
				if (contentItem && contentItem.cmThumbnails != null) {
					newContentItem.cmThumbnails = contentItem.cmThumbnails;
				}
				
				if (contentItem) {
					// Dig some properties out of the property bag and make first class properties
					var properties = contentItem.properties.items ? contentItem.properties.items : contentItem.properties;
					for (var i = 0; i < properties.length; i++) {
						var property = properties[i];
						if (property.id == "Id") {
							newContentItem.id = property.value;
						} else if (property.id == "Name") {
							newContentItem.name = property.value;
						} else if (property.id == "MimeType") {
							newContentItem.mimeType = property.value;
						} else if (property.id == "IsReserved") {
							newContentItem.isReserved = property.value;
							// The reservation information is a first class property that we may need to clear
							if (!property.value) {
								newContentItem.reservation = null;
							}
						}
					} 
				} else {
					// If there is no contentItem passed in, then there must be a reservationItem
					var properties = lastContentItem.properties.items ? lastContentItem.properties.items : lastContentItem.properties;
					for (var i = 0; i < properties.length; i++) {
						var property = properties[i];
						// Need to find the IsReserved property and update it
						if (property.id == "IsReserved") {					
							newContentItem.isReserved = true;
							newContentItem.reservation = {
								id: reservationItem.id,
								creator: reservationItem.creator
							};
						}
					}
				}
				return newContentItem;
			}
			
		}		
	}
	
	/*
	 * Private methods and event handlers *************************************************************
	 */
	 
	this.constructor.prototype._onGetPropertiesResults = function(view, results) {
		console.log("CS-DocumentReference:_onGetPropertiesResults");
		if (results && results.results) {
			var contentItem = results.results;
			if (contentItem) {
				this._instance._contentItem = contentItem;
				var newContentItem = this._proto._updateDocumentContentItem(contentItem);	

				// The return contentItem object always has an id first class property
				var callbacks = this._instance.getProperties[contentItem.id];
				if (callbacks && callbacks.callback) {
					callbacks.callback(newContentItem);
				}
			}
		}
	};
	
	this.constructor.prototype._onGetPropertiesError = function(view, error) {
		var logMessage = error && error.errorText ? error.errorText : messages.getcontent_ret_properties_error;
		console.log("CS-DocumentReference:_onGetPropertiesError : " + logMessage);
		var errback = this._instance.propertiesErrback;
		if (errback) {
			errback(error);
		}
		var self = this;
		setTimeout(function() {
			bpmext.ui.executeEventHandlingFunction(self, self._proto.EVT_ONERROR, messages.getcontent_ret_properties_error);
		});
	};
 
	this.constructor.prototype._onCheckoutDocumentResult = function() {
		try {
			this._proto._onCheckoutDocumentResult(this);
		} catch (e) {
			bpmext.log.error("Error on AJAX service invocation [" + this.context.viewid + "]: " + e);
			if (e.stack) {
				bpmext.log.error("  Call stack: " + e.stack);
			}
		}
	};

	this.constructor.prototype._onCheckoutDocumentError = function() {
		var view = this;
		view._instance.checkoutForUpload = false;
		var error = view._instance.checkoutDocumentSvc && view._instance.checkoutDocumentSvc.getLastError();
		if (error) {
			error.actionName = this._proto.actions.checkoutDocument;
			var message = messages.contlist_checkout_failed;
			this._proto._setAlertMessage(view, message, true);
			view._instance.error = error;

			setTimeout(function() {
				bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, view._instance.error);
			});
		}
	};

	this.constructor.prototype._onCancelCheckoutResult = function() {
		try {
			this._proto._onCancelCheckoutResult(this);
		} catch (e) {
			bpmext.log.error("Error on AJAX service invocation [" + this.context.viewid + "]: " + e);
			if (e.stack) {
				bpmext.log.error("  Call stack: " + e.stack);
			}
		}
	};

	this.constructor.prototype._onCancelCheckoutError = function() {
		var view = this;
		view._instance.checkoutForUpload = false;
		var error = view._instance.cancelCheckoutSvc && view._instance.cancelCheckoutSvc.getLastError();
		if (error) {
			error.actionName = this._proto.actions.cancelCheckout;
			var message = messages.contlist_cancel_checkout_failed;
			this._proto._setAlertMessage(view, message, true);
			view._instance.error = error;

			setTimeout(function() {
				bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, view._instance.error);
			});
		}
	};


	/*
	 * Public control methods *************************************************************
	 */
	
	/**
	 * @instance
	 * @memberof CS-DocumentReference
	 * @method setFolder
	 * @param {CSContentItem} contentItem object holding the folder information id or pathName
	 * @desc Changes the file in folder where the content will be added.
	 */
	this.constructor.prototype.setFolder = function(contentItem) {
		console.log("CS-DocumentReference:setFolder() : called");
		if (contentItem) {
			if (contentItem.baseType && contentItem.baseType == "Folder") {
				// Get the folder information out of the contentItem
				this._instance.parentFolder = contentItem.id ? contentItem.id : contentItem.pathName;
				console.log("CS-DocumentReference:setFolder() : Setting folder: " + this._instance.parentFolder);
			} else {
				console.log("CS-DocumentReference:setFolder() : Error: passed in object is not a folder.");
			}
		}
	};
	
	/**
	 * @instance
	 * @memberof CS-DocumentReference
	 * @method setDocument
	 * @param {CSContentItem} contentItem object holding the document information
	 * @desc Changes the document that will be displayed in the view.
	 */
	this.constructor.prototype.setDocument = function(contentItem) {
		console.log("CS-DocumentReference:setDocument() : called");
		if (contentItem) {
			if (contentItem.baseType && contentItem.baseType == "Document") {
				this._contentItem = contentItem;
				console.log("CS-DocumentReference:setDocument() : Setting document: " + contentItem.name);
				// Since a new document (contentItem) was set, need to reload the component
				var self = this;
				setTimeout(function() {
					self._proto._loadView(self, contentItem);
				}, 300);
			} else {
				console.log("CS-DocumentReference:setDocument() : Error: passed in object is not a document.");
			}
		}
	};
	
	/**
	 * @instance
	 * @memberof CS-DocumentReference
	 * @method addContextMenuAction
	 * @param {string} id of the context menu action
	 * @param {string} name of the context menu items to display
	 * @param {string} type of object to add this context menu action to "document"
	 * @param {boolean} enabled whether the context menu action is enabled in the menu or not
	 * @param {function} onClickFunc function that will be called when the context menu item is clicked
	 * @param {integer} index where to add the new action, if null will add action to end of list
	 * @desc Adds a custom context menu action to the context menu.
	 */
	this.constructor.prototype.addContextMenuAction = function(id, name, type, enabled, onClickFunc, index) {
		console.log("CS-DocumentReference:addContextMenuAction() : called with name: " + name + " at index: " + index);
		var addItem = false;
		if (type == null) {
			// If type is null, then add the custom menu action to all menu types
			addItem = true;
		} else if (type == "document" && this._instance.contentItem.baseType == "Document") {
			// Add the custom menu action to document context menus
			addItem = true;
		}
		
		if (addItem) {
			var actions = this._instance.menu._ptMenuItems;
			if (actions != null) {
				var action = {	
					actionId: id,
					icon: null,
					text: name,
					badgeText: "",
					isEnabled: enabled,
					onclick: onClickFunc
				};
				
				if (index == null || index > actions.length) {
					// Add the action to the end of the list
					actions.push(action);
				} else {
					// Add the action at the index specified
					actions.splice(index, 0, action);
				}
			}
		} else {
			console.log("CS-DocumentReference:addContextMenuAction() : no context menu action added.");
		}
	};		


	/*
	 * Coach NG Lifecycle methods *************************************************************
	 */
	
	this.constructor.prototype.load = function() {
		console.log("CS-DocumentReference:load() : called from: " + this.context.viewid);
		var options = this.context.options;
		
		if (!options.objectStoreName) {
			options.objectStoreName = bpmext.ui.substituteConfigOption(this, "objectStoreName", "");
		}

		if (!options.viewMode) {
			options.viewMode = bpmext.ui.substituteConfigOption(this, "viewMode", "N");
		}				
	
		if (!options.hintText) {
			options.hintText = bpmext.ui.substituteConfigOption(this, "hintText", "");
		}				
	
		if (!options.helperText) {
			options.helperText = bpmext.ui.substituteConfigOption(this, "helperText", "");
		}				

		if (!options.addMode) {
			options.addMode = bpmext.ui.substituteConfigOption(this, "addMode", "none");
		}				
		
		if (!options.allowsClearDoc) {
			options.allowsClearDoc = bpmext.ui.substituteConfigOption(this, "allowsClearDoc", false);
		}						

		if (!options.allowsTitleAction) {
			options.allowsTitleAction = bpmext.ui.substituteConfigOption(this, "allowsTitleAction", false);
		}						

		if (!options.allowsActions) {
			options.allowsActions = bpmext.ui.substituteConfigOption(this, "allowsActions", false);
		}						
	
		if (!options.documentId) {
			options.documentId = bpmext.ui.substituteConfigOption(this, "documentId", "");
		} else {
			this._documentId = options.documentId.get("value");
		}

		if (!options.folderId) {
			options.folderId = bpmext.ui.substituteConfigOption(this, "folderId", "");
		} else {
			this._instance.parentFolder = options.folderId.get("value");
		}
			
		if (!options.defaultDocumentType) {
			options.defaultDocumentType = bpmext.ui.substituteConfigOption(this, "defaultDocumentType", "");
		}

		if (!options.acceptFileTypes) {
			options.acceptFileTypes = bpmext.ui.substituteConfigOption(this, "acceptFileTypes", null);
		}
		
		if (!options.maxDocumentSize) {
			options.maxDocumentSize = bpmext.ui.substituteConfigOption(this, "maxDocumentSize", 0);
		}				

		if (!options.hideTimePicker) {
			options.hideTimePicker = bpmext.ui.substituteConfigOption(this, "hideTimePicker", false);
		}

		// Height would only apply to the thumbnail view mode
		if (!options.height) {
			options.height = bpmext.ui.substituteConfigOption(this, "height", null);
		}
		if (!options.width) {
			options.width = bpmext.ui.substituteConfigOption(this, "width", null);
		}

		domClass.add(this.context.element, "CS_DocumentReference");
	
	  	bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONADD, "contentItem");
	  	bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONCLEAR, "contentItem");
	  	bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONCONTEXTMENUOPEN, "menuItems", "contentItem");
		bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONERROR, "message");

		this._proto._setWidth(this);
		this._proto._setHeight(this);

		bpmext.ui.loadView(this);

		var contentItem;
		if (this._documentId) {
			// If there is a document id specified in the configuration settings, create content item for it
			contentItem = {
				id: this._documentId,
				baseType: "Document",
				isFolder: false
			};
		}
		var self = this;
		// Setting a time out interval here to allow other components on the same page as the doc reference
		// to load themselves and potentially call a public api on the doc reference before loadView is called.
		setTimeout(function() {
			self._proto._loadView(self, contentItem);
		}, 450);
	};

	this.constructor.prototype.view = function() {
		console.log("CS-DocumentReference:view() : called from: " + this.context.viewid);
		try {
			this._proto._handleVisibility(this);
			// Check for a bound object use it to re-render the properties UX with
			if (this.context.binding) {
				var boundProperty = this.context.binding.property;
				if (boundProperty != null) {
					var contentItem = this.context.binding.boundObject[boundProperty];
					if (contentItem.id != null && contentItem.id != "") {
						console.log("CS-DocumentReference:view() : View update for: " + contentItem.name);
						this._proto._loadView(this, contentItem);
					} else {
						console.log("CS-DocumentReference:view() : No bound object to view.");
					}
				}
			}
		} catch(e) {
			bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
		}
	};
	
	this.constructor.prototype.change = function(event) {
		console.log("CS-DocumentReference:change() : called from: " + this.context.viewid);
		try	{
			if (event.type != "config" && this.context.binding) {
				var contentItem = event.newVal;
				if (contentItem != null) {
					if (!contentItem.id) {
						this._proto._loadView(this, null);
					} else if (contentItem.id != null) {
						console.log("CS-DocumentReference:change() : Change update for bound object: " + contentItem.name);
						this._proto._loadView(this, contentItem);
					}
				}
			}
		} catch (e) {
			bpmext.log.error("Error on change event [" + this.ui.getAbsoluteName() + "]: " + e);
			if (e.stack) {
				bpmext.log.error("  Call stack: " + e.stack);
			}
		}
	};
}