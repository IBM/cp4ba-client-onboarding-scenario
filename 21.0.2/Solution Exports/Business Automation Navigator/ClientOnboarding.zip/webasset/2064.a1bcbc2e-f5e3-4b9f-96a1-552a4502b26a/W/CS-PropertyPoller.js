/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2020 - 2021. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

cs_InitPropertyPoller = function(bpmext, domClass, domStyle, domAttr, messages, cookie) {
	
	this._instance = {
		objectStoreName: null,
		documentIds: [],
		batchIds: [],
		controllerPropertyId: null,
		statusPropertyId: null,
		extraProperties: [],
		pollingInterval: 0,
		timeoutMillisecondsPerDocument: 0,
		noResponseIntervalHandle: null,
		exitValues: null,
		negativeExitValues: null,
		getDocumentsSvc: null,
		isPolling: false,
		isPaused: false,
		documentTimeouts: {},
		searchCriteria: null,
		batchProcessingDocumentStatus: {},
		pollingIntervalTimeout: null,
		requestInProcess: false
	};

	if (!this.constructor.prototype._proto)
	{
		this.constructor.prototype._proto =
		{
			_appResource: "GRAPHQL_APP_RESOURCE",
			_connectionStr: "/content-services-graphql/graphql",
			_pageSize: 2000,
			EVT_ONERROR: "eventON_ERROR",
			EVT_ONSTATUS: "eventON_STATUS",
			EVT_ONRESULTS: "eventON_RESULTS",
			
			_callService: function(view, service, params, setInputData) {
				// Create ecm token as a large random number
				var csrfToken = Math.floor(Math.random() * 10000000);
				console.log("CS-PropertyPoller:_callService() : Ecm token: " + csrfToken);

				// Add the required token value to the service params
				params.csrfToken = csrfToken;
				if (setInputData) {
					service.setInputData(params);
					service.execute();
				} else {
					service.execute(params);
				}
			},
			
			_callDocumentPollingService: function(view) {
				if (view._instance.searchCriteria){
					this._callSearchService(view, view._instance.documentIds, false);
				}
				else {
					this._callGetDocumentsService(view, view._instance.documentIds, false);
				}
			},

			_callGetDocumentsService: function(view, documentIds, manual) {
				var contentItems = [];
				for (var i = 0; i < documentIds.length; i++) {
					contentItems.push ({
						id: documentIds[i]
					});
				}
				
				var ovpProperties = [];
				var properties = ["Name", "DateLastModified", "LastModifier", "MimeType"];
	
				if (view._instance.controllerPropertyId) {
					ovpProperties.push(view._instance.statusPropertyId);
					properties.push(view._instance.controllerPropertyId)
				}
				
				this._checkForExtraProperties(view, properties, ovpProperties);
		
				var params = {
					manual: manual,
					pageSize: view._proto._pageSize,
					contentItems: contentItems,
					properties: properties,
					ovpProperties: ovpProperties,
					repository: view._instance.objectStoreName,
					serverAppResource: view._proto._appResource
				};
				console.log("CS-PropertyPoller:_callGetDocumentsService() : Polling -- calling getDocumentsSvc.execute");
				console.log("CS-PropertyPoller:_callGetDocumentsService() : Document Ids are: " + JSON.stringify(documentIds));
				this._callService(view, view._instance.getDocumentsSvc, params, true);
			},
			
			_callSearchService: function(view, itemIds, manual) {
				var searchProperties = [];
				for (var index = 0; index < itemIds.length; index++) {
					var searchProperty = {
						property: "Id",
						operator: "=",
						value: itemIds[index],
						dataType: "guid"	
					}
					if (index < itemIds.length - 1) {
						searchProperty.logical = "OR";
					}
					searchProperties.push(searchProperty);					
				}
				
				var properties = view._instance.searchCriteria.properties;
				var ovpProperties = view._instance.searchCriteria.ovpProperties;

				this._checkForExtraProperties(view, properties, ovpProperties);
				
				var params = {
					manual: manual,
					pageSize: 2000,
					searchFor: view._instance.searchCriteria.searchFor,
					searchType: view._instance.searchCriteria.searchType,
					searchProperties: searchProperties,
					properties: properties,
					ovpProperties: ovpProperties,
					repository: view._instance.objectStoreName,
					serverAppResource: view._proto._appResource
				};
				
				console.log("CS-PropertyPoller:_callSearchService() : Polling -- calling searchSvc.execute");
				console.log("CS-PropertyPoller:_callGetDocumentsService() : Document Ids are: " + JSON.stringify(itemIds));
				this._callService(view, view._instance.searchSvc, params, true);
			},
			
			_callGetBatchDocumentsService: function(view) {
				var properties = ["DbaClassificationController", "Id"];				
				var batchOrderBy = "DbaBatchController"; // Special property for the query results order
				var controllerProperties = [];
				controllerProperties.push(batchOrderBy);

				var ovpProperties = ["DbaCaptureStatus"];
				
				var searchParams = [];
					for (var i = 0; i < view._instance.batchIds.length; i++){
						var logical = i < (view._instance.batchIds.length - 1) ? "OR" : null;
						
						searchParams.push({
						name: "DbaBatchController",
						operator: "=",
						value: view._instance.batchIds[i],
						logical: logical
					});
				}

				var params = {
					pageSize: 2000,
					countLimit: 2000,
					documentBaseType: "DbaCaptureBase",
					controllerType: "DbaClassificationController",
					batchType: "DbaBatchController",
					batchOrderBy: batchOrderBy,
					order: "ASC",
					searchParams: searchParams,
					properties: properties,
					controllerProperties: controllerProperties,
					ovpProperties: ovpProperties,
					repository: view._instance.objectStoreName,
					serverAppResource: view._proto._appResource
				};
				console.log("CS-PropertyPoller:_callGetBatchDocumentsService() : Polling -- calling getBatchDocumentsSvc.execute");
				console.log("CS-PropertyPoller:_callGetDocumentsService() : Batch Ids are: " + JSON.stringify(view._instance.batchIds));
				this._callService(view, view._instance.getBatchDocumentsSvc, params);
			},
			
			_checkForExtraProperties: function(view, properties, ovpProperties) {
				if (view._instance.extraProperties){
					view._instance.extraProperties.forEach(function(extraProperty) {
						var primary = extraProperty.primary;
						if (properties.indexOf(primary) == -1) {
							properties.push(primary);
						}
						// Check for a secondary property, there maybe one if primary is an object value property
						var secondary = extraProperty.secondary;
						if (secondary != null) {
							if (ovpProperties.indexOf(secondary) == -1) {
								ovpProperties.push(secondary);
							}
						}
					});
				}
			},
			
			_initiatePolling: function(view) {
				if (view._instance.documentIds.length == 1 && (!view._instance.isPolling || view._instance.isPaused)){
					view._instance.isPaused = false;
					view._instance.isPolling = true;
					view._poll("documents");
				}
			
				if (view._instance.noResponseIntervalHandle){
					console.log("CS-PropertyPoller :_initiatePolling() : Clearing interval handle");
					clearInterval(view._instance.noResponseIntervalHandle);
				}
			
				// Handle case where we don't get a response back from server.
				if (view._instance.timeoutMillisecondsPerDocument > 0){
					view._instance.noResponseIntervalHandle = setInterval(function(){
						console.log("CS-PropertyPoller:_initiatePolling() : Checking timeouts");
						for (var i = 0; i < view._instance.documentIds.length; i++){
							var documentId = view._instance.documentIds[i];
							if (view._instance.documentTimeouts[documentId] && Date.now() > view._instance.documentTimeouts[documentId]){
								console.log("CS-PropertyPoller:initiatePolling() : Timed out for " + documentId);
								view._instance.documentIds = view._instance.documentIds.filter(docId => docId !== documentId);
								delete view._instance.documentTimeouts[documentId];
							
								var documentStatus = {
									id: documentId,
									processingStatus: "Timeout",
									properties: [],
									contentElements: [],
									terminal: true,
									numberDocumentsProcessing: view._instance.documentIds.length
								}
								bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONSTATUS, documentStatus);
							}
						}
						if (view._instance.documentIds.length == 0){
							view._proto._stopPolling(view);
						}
					}, view._instance.timeoutMillisecondsPerDocument);
				}				
			},
			
			_stopPolling: function(view) {
				console.log("CS-PropertyPoller:_stopPolling() : called");
				view._instance.isPolling = false;
				view._instance.documentIds = [];
				view._instance.documentTimeouts = {};
				if (view._instance.noResponseIntervalHandle){
					clearInterval(view._instance.noResponseIntervalHandle);
					view._instance.noResponseIntervalHandle = null;
				}
				if (view._instance.pollingIntervalTimeout){
					clearTimeout(view._instance.pollingIntervalTimeout);
					view._instance.pollingIntervalTimeout = null;
				}
			}
		}
	};
	
	this.constructor.prototype._poll = function(pollType) {
		console.log("CS-PropertyPoller:_poll() : pollType == " + pollType);
		
		if ((this._instance.documentIds.length > 0 || this._instance.batchIds.length > 0) && 
			this._instance.statusPropertyId && this._instance.pollingInterval > 0 && !this._instance.isPaused &&!this._instance.requestInProcess){
				
			if (this._instance.pollingIntervalTimeout){
				clearTimeout(this._instance.pollingIntervalTimeout);
				this._instance.pollingIntervalTimeout = null;
			}	
				
			var _this = this;
			this._instance.pollingIntervalTimeout = setTimeout(function(){
				if (_this._instance.isPolling && !_this._instance.isPaused && _this._instance.documentIds.length > 0){
					console.log("CS-PropertyPoller:_poll() Polling at " + new Date());
					if (pollType == "batchDocuments"){
						if (_this._instance.batchIds.length > 0){
							_this._proto._callGetBatchDocumentsService(_this);
						}
						else {
							_this._proto._callDocumentPollingService(_this);
						}
					}
					else {
						_this._proto._callDocumentPollingService(_this);
					}
				}
			}, this._instance.pollingInterval * 1000);
		}
		else if (!this._instance.isPaused) {
			console.log("CS-PropertyPoller:_poll() : stopping polling - no batches or documents to process");
			this._proto._stopPolling(this);
		}
	};
	
	this.constructor.prototype.setObjectStoreName = function(objectStoreName) {
		this._instance.objectStoreName = objectStoreName;
	};
	
	this.constructor.prototype.setControllerPropertyId = function(controllerPropertyId) {
		this._instance.controllerPropertyId = controllerPropertyId;
	};
	
	this.constructor.prototype.setStatusPropertyId = function(statusPropertyId) {
		this._instance.statusPropertyId = statusPropertyId;
	};
	
	this.constructor.prototype.setExtraProperties = function(extraProperties) {
		this._instance.extraProperties = extraProperties && extraProperties.items ? extraProperties.items : extraProperties;
	};
	
	this.constructor.prototype.setPollingInterval = function(pollingInterval) {
		this._instance.pollingInterval = pollingInterval;
	};
	
	this.constructor.prototype.setPollingTimeout = function(timeout) {
		this._instance.timeoutMillisecondsPerDocument = timeout * 1000;
	};
	
	this.constructor.prototype.setExitValues = function(exitValues) {
		this._instance.exitValues = exitValues && exitValues.items ? exitValues.items : exitValues;
	};
	
	this.constructor.prototype.setNegativeExitValues = function(negativeExitValues) {
		this._instance.negativeExitValues = negativeExitValues && negativeExitValues.items ? negativeExitValues.items : negativeExitValues;
	};
	
	this.constructor.prototype.getDocumentStatus = function(documentId) {
		if (this._instance.searchCriteria){
			this._proto._callSearchService(this, [documentId], true);
		}
		else {
			this._proto._callGetDocumentsService(this, [documentId], true);
		}
	};
	
	this.constructor.prototype.addDocumentId = function(documentId) {
		if (documentId && documentId.length > 0){
			if (!this._instance.documentIds.find(pollingDocumentId => pollingDocumentId == documentId)){
				this._instance.documentIds.push(documentId);
				if (this._instance.timeoutMillisecondsPerDocument > 0){		
					this._instance.documentTimeouts[documentId] = Date.now() + this._instance.timeoutMillisecondsPerDocument;
				}
			}			
			this._proto._initiatePolling(this);
		}
	};
	
	this.constructor.prototype.removeDocumentId = function(documentId) {
		if (this._instance.batchIds != null){	
			var index = this._instance.batchIds.indexOf(documentId);
			if (index !== -1){
				this._instance.batchIds.splice(index, 1);
			}
		}
		
		if (this._instance.documentIds != null){		
			var index = this._instance.documentIds.indexOf(documentId);
			if (index !== -1){
				this._instance.documentIds.splice(index, 1);
			}
			if (this._instance.documentIds.length == 0){
				bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONSTATUS, {
					terminal: true,
					numberDocumentsProcessing: 0
				});
				this._proto._stopPolling(this);
			}
		}
	};
	
	this.constructor.prototype.isPolling = function() {
		return this._instance.isPolling;
	};
	
	this.constructor.prototype.stopPolling = function() {
		this._proto._stopPolling(this);
	};
	
	this.constructor.prototype.pausePolling = function() {
		console.log("CS-PropertyPoller:pausePolling() : called");
		this._instance.isPaused = true;
	};
	
	this.constructor.prototype.resumePolling = function() {
		console.log("CS-PropertyPoller:resumePolling() : called");
		if (this._instance.isPaused){
			this._instance.isPaused = false;
			this._poll("documents");
		}
	};
	
	this.constructor.prototype.isPaused = function() {
		return(this._instance.isPaused);
	};
	
	this.constructor.prototype.isPollingForObject = function(objectId) {
		return this._instance.documentIds.find(pollingDocumentId => pollingDocumentId == objectId) ? true : false;
	};
	
	/*
	* Private event handlers and methods
	*/
	
	this.constructor.prototype._getClassificationBatchDocumentStatus = function(batchId) {
		var returnObject = null;

		if (this._instance.batchProcessingDocumentStatus[batchId] != null){
			returnObject = this._instance.batchProcessingDocumentStatus[batchId];
		}

		return returnObject;
	};
	
	/**
	* Used to poll the processing status for a recently uploaded batch.
	*/
	this.constructor.prototype._addBatchId = function(batchId, numberOfDocuments) {
		if (batchId && batchId.length > 0){
			if (!this._instance.batchIds.find(pollingBatchId => pollingBatchId == batchId)){
				this._instance.batchIds.push(batchId);				
				this._instance.batchProcessingDocumentStatus[batchId] = {
					documentsProcessing: numberOfDocuments,
					totalDocuments: numberOfDocuments
				}
			}
		}
	};
	
	this.constructor.prototype._onGetDocumentsResults = function(view, results) {
//		console.log("CS-PropertyPoller:_onGetDocumentsResults() : called : " + JSON.stringify(results));
		console.log("CS-PropertyPoller:_onGetDocumentsResults() called from: " + this.context.viewid);			
		this._instance.requestInProcess = false;

		var statusProperty;
		if (results && results.results){
			var documents = results.results.items ? results.results.items : results.results;
			bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONRESULTS, documents);
			if (documents){
				var _this = this;
				if (documents.length == 0){
					console.log("CS-PropertyPoller:_onGetDocumentsResults() : Clearing documents");
					this._instance.documentIds.forEach(function(documentId){
						bpmext.ui.executeEventHandlingFunction(_this, _this._proto.EVT_ONSTATUS, {
							terminal: true,
							id: documentId,
							processingStatus: 900,
							properties: [],
							contentElements: [],
							numberDocumentsProcessing: 0
						});
					});
					this._instance.documentIds.splice(0, this._instance.documentIds.length);
				} else {
					documents.forEach(function(doc){
						var properties = doc.properties.items ? doc.properties.items : doc.properties;		
						statusProperty = null;
						if (_this._instance.controllerPropertyId){
							var controllerProperty = properties.find(property => property.id == _this._instance.controllerPropertyId);
							if (controllerProperty){
								var controllerProperties = controllerProperty.objectValue.properties.items ? controllerProperty.objectValue.properties.items : controllerProperty.objectValue.properties;
								statusProperty = controllerProperties.find(property => property.id == _this._instance.statusPropertyId);
							}								
						}
						if (!statusProperty){
							statusProperty = properties.find(property => property.id == _this._instance.statusPropertyId);						
						}							
						var terminal = false;
						processingStatus = null;
						if (statusProperty && statusProperty.value){
							processingStatus = statusProperty.value;
							terminal = _this._instance.exitValues ? _this._instance.exitValues.find(exitValue => exitValue == processingStatus.toString()) : null;
							if (!terminal){
								terminal = !(_this._instance.negativeExitValues ? _this._instance.negativeExitValues.find(negativeExitValue => negativeExitValue == processingStatus.toString()) : null);
								if (!terminal && _this._instance.documentTimeouts[doc.id] && (Date.now() > _this._instance.documentTimeouts[doc.id])){									
									console.log("CS-PropertyPoller:_onGetDocumentsResults() : Timed out for " + doc.id + " Current time: " + Date.now() + " Timeout: " + _this._instance.documentTimeouts[doc.id]);
									_this._instance.documentIds = _this._instance.documentIds.filter(docId => docId !== doc.id);
									delete _this._instance.documentTimeouts[doc.id];									
									processingStatus = "Timeout";
									terminal = true;
								}		
							}		
						} else {
							console.log("CS-PropertyPoller:_onGetDocumentsResults() : Polling property not found");
							terminal = true;
							processingStatus = "";

							// Add a dummy property value for the status property so it will be reflected correctly in the content list.
							if (_this._instance.controllerPropertyId && _this._instance.statusPropertyId) {
								properties.push({
									id: _this._instance.controllerPropertyId,
									label: _this._instance.controllerPropertyId,
									type: "OBJECT",
									cardinality: "SINGLE",
									objectValue: {
										properties: [{
											id: _this._instance.statusPropertyId,
											type: "LONG",
											value: null
										}]
									}
								});
							}
						}
						if (terminal){
							_this._instance.documentIds = _this._instance.documentIds.filter(docId => docId !== doc.id);
						}
						var documentStatus = {
							id: doc.id,
							name: doc.name,
							mimeType: doc.mimeType,
							baseType: doc.baseType,
							properties: properties,
							contentElements: doc.contentElements,
							cmThumbnails: doc.cmThumbnails,
							className: doc.className,
							processingStatus: processingStatus,
							terminal: terminal,
							numberDocumentsProcessing: _this._instance.documentIds.length
						}
						bpmext.ui.executeEventHandlingFunction(_this, _this._proto.EVT_ONSTATUS, documentStatus);
					});
				}
				
				var params = this._instance.searchCriteria ? this._instance.searchSvc.getInputData() : this._instance.getDocumentsSvc.getInputData();
				if (params.manual){
					this._proto._stopPolling(this);					
				} else {
					_this._poll("batchDocuments");			
				}
			}
		}
	};
	
	this.constructor.prototype._onGetDocumentsError = function(view, error) {
		console.log("CS-PropertyPoller:_onGetDocumentsError() : called");
		this._instance.requestInProcess = false;
		this._instance.documentIds = [];
		var errorMessage = error && error.errorText ? error.errorText : error;
		if (errorMessage){
			console.log(errorMessage);
		}
		bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONERROR, messages.properties_document_or_folder_not_found);
		this._proto._stopPolling(this);
	};
	
	this.constructor.prototype._onGetBatchDocumentsResult = function(view, response) {
		console.log("CS-PropertyPoller:_onGetBatchDocumentsResult() : called : " + JSON.stringify(response));
//		console.log("CS-PropertyPoller:_onGetBatchDocumentsResult() called from: " + this.context.viewid);	
		this._instance.requestInProcess = false;
		
		var batchDocumentStatus = {};
		
		if (response && response.results){
			var documents = response.results.items ? response.results.items : response.results;
			if (documents){
				for (var i = 0; i < documents.length; i++){
					var batchDocument = documents[i];
					var properties = batchDocument.properties.items ? batchDocument.properties.items : batchDocument.properties;
					var batchController = properties.find(property => property.id == "DbaBatchController");
					if (batchController){
						var batchControllerId = batchController.value.identifier;
						if (!batchDocumentStatus[batchControllerId]) {
							batchDocumentStatus[batchControllerId] = {
								documentsProcessing: 0,
								totalDocuments: 0
							};
						}
							
						var classificationController = properties.find(property => property.id == "DbaClassificationController");
						if (classificationController){
							var classControllerOVPs = classificationController.objectValue.properties.items ? classificationController.objectValue.properties.items : classificationController.objectValue.properties;
							var documentStatus = classControllerOVPs.find(ovpProperty => ovpProperty.id == "DbaCaptureStatus");
							if (documentStatus.value == 20){
								batchDocumentStatus[batchControllerId].documentsProcessing++;
							}
							batchDocumentStatus[batchControllerId].totalDocuments++;
						}													
					}						
				}
				
				this._instance.batchProcessingDocumentStatus = {};
				var batchKeys = Object.keys(batchDocumentStatus);
				for (var i = 0; i < batchKeys.length; i++) {
					var batchKey = batchKeys[i];
					var batchStatus = batchDocumentStatus[batchKey];
					if (batchStatus.documentsProcessing > 0){
						this._instance.batchProcessingDocumentStatus[batchKey] = batchStatus;
					}
				}
				
				// Remove the batch id if the documents are through processing.
				for (var i = 0; i < this._instance.batchIds.length; i++){
					var batchId = this._instance.batchIds[i];
					if (!this._instance.batchProcessingDocumentStatus[batchId]){
						this._instance.batchIds = this._instance.batchIds.filter(currentBatchId => currentBatchId !== batchId);
					}
				}
			}
			
			this._poll("documents");
		}
	};
	
	this.constructor.prototype._onGetBatchDocumentsError = function(view, error) {
		console.log("CS-PropertyPoller:_onGetBatchDocumentsError() : called");
		this._instance.requestInProcess = false;
		this._instance.batchIds = [];
		var errorMessage = error && error.errorText ? error.errorText : error;
		if (errorMessage){
			console.log(errorMessage);
		}
		bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONERROR, messages.properties_document_or_folder_not_found);
		this._proto._stopPolling(this);
	};
	
	this.constructor.prototype.setSearchCriteria = function(searchCriteria) {
		// Only query for the properties we are interested in (status, DateLastModified, LastModifier).
		var filteredProperties = [];
		for (var i = 0; i < searchCriteria.properties.length; i++){
			property = searchCriteria.properties[i];
			switch(property){
				case this._instance.statusPropertyId:
				case "DateLastModified":
				case "LastModifier":
					filteredProperties.push(property);
					break;
			}
		}
		searchCriteria.properties = filteredProperties		
		this._instance.searchCriteria = searchCriteria;
	};
	
	this.constructor.prototype.load = function() {
		this._instance.getDocumentsSvc = this.ui.get("GetDocumentsSvc");
		this._instance.searchSvc = this.ui.get("SearchSvc");
		this._instance.getBatchDocumentsSvc = this.ui.get("GetBatchDocumentsSvc");
		
		bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONERROR, "message");
		bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONSTATUS, "results");
		bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONRESULTS, "pollResults");
	};
	
	this.constructor.prototype.change = function(event) {
	};
}