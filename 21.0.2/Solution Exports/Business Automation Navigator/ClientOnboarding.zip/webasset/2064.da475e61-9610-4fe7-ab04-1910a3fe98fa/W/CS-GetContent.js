/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2020. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

cs_InitGetContent = function (utilities, bpmext, messages, cookie)
{
	this._instance =
	{
		serverConfigurationName: "GRAPHQL_APP_RESOURCE",
		type: "file"
	};

	if (!this.constructor.prototype._proto)
	{
		this.constructor.prototype._proto =
		{
			EVT_ONERROR: "eventON_ERROR",
			EVT_ONCONTENTRECEIVED: "eventON_CONTENTRECEIVED",
			EVT_ONPROPERTIESUPDATED: "eventON_PROPERTIESUPDATED",
			EVT_ONGETCLASSACCESS: "eventON_GETCLASSACCESS",

			_handleVisibility: function (view) {
				var vis = utilities.handleVisibility(view.context);
			},
			
			/**
			 * Helper function to retrieve the Object Store Name as defined in ACCE admin tool. This is the 
			 * string that will be passed to all the graphql action services since it's working against CE
			 * and not ICN).
			 */
			_getObjectStoreName: function(view) {
				var objectStoreName = view._instance.objectStoreName;
				if (objectStoreName == null) {
					objectStoreName = view.context.options.objectStoreName.get("value");
				}
				return objectStoreName;
			},

			_callService: function(service, params) {
				// Add the required token value to the service params
				params.ecmToken = this._getEcmToken(false);
				service.execute(params);
			},
			
			_getEcmTokenName: function() {
				return "ECM-CS-XSRF-Token";
			}, 

			_getEcmToken: function(setCookie) {
				// Create ecm token as a large random number
				var ecmToken = Math.floor(Math.random() * 10000000);
				if (setCookie) {
					cookie(this._getEcmTokenName(), ecmToken);
				}
				console.log("CS-GetContent:_getEcmToken() : Ecm token: " + ecmToken);
				return ecmToken;
			},

			_buildDocumentURLString: function(view, contentItem) {
				var url;
				var item = contentItem;
				var contentElements = item.contentElements ? item.contentElements.items ? item.contentElements.items : item.contentElements : [];
				if (contentElements.length > 0) {
					var downloadUrl = contentElements[0].downloadUrl;
					// Todo: Temp URL modification for graphql
					url = downloadUrl.replace("content", "content-services-graphql/content");
				}
				return url;
			},
			
			_downloadDocument: function(view, contentItem, type, fromResponse, callback, errback) {
				console.log("CS-GetContent:_downloadDocument() : Attempting to download: " + contentItem.id);
				if (type != null) {
					view._instance.type = type;
				} else {
					type = view._instance.type;
				}
				
				var url = this._buildDocumentURLString(view, contentItem);
				if (url != null) {
					this._getDocumentContent(view, contentItem, url, type, callback, errback);
				} else if (!fromResponse) {
					// No url means most likely no content elements information in the contentItem passed in
					// Make the get properties service call to get the content elements property info and try again
					if (contentItem.className && contentItem.className == "VersionSeries") {
						// Need to make the service call to get the version series information so we can get the doc id
						this._getVersionSeries(view, contentItem);
					} else if (contentItem.id) {
						this._getProperties(view, contentItem);
					}
				} else {
					console.log("CS-GetContent:_downloadDocument() : Document content could not be retrieved.");
				}
			},

			_getVersionSeries: function(view, contentItem) {
				var versionSeriesId = contentItem.id;
				var params = {
					versionSeriesId: versionSeriesId,
					repository: this._getObjectStoreName(view),
					serverAppResource: view._instance.serverConfigurationName
				};
				console.log("CS-GetContent:_getVersionSeries() : Version series for: " + versionSeriesId);
				view._instance.getVersionSeriesSvc = view.ui.get("GetVersionSeriesSvc");
				this._callService(view._instance.getVersionSeriesSvc, params);
			},
			
			_getProperties: function(view, contentItem, properties, ovpProperties, update) {
				var params = {
					objectType: contentItem.baseType ? contentItem.baseType : "Document",
					objectId: contentItem.id,
					classId: contentItem.className,
					repository: this._getObjectStoreName(view),
					serverAppResource: view._instance.serverConfigurationName
				};
				
				if (properties && properties.length > 0) {
					params.properties = properties;
				} else {
					params.properties = ["DocumentTitle"];
				}
				
				if (ovpProperties && ovpProperties.length > 0) {
					params.ovpProperties = ovpProperties;
				}
				
				if (update != null ) {
					params.update = update;
				}
				
				console.log("CS-GetContent:_getProperties() : Document properties for: " + contentItem.id);
				view._instance.getPropertiesSvc = view.ui.get("GetPropertiesSvc");
				this._callService(view._instance.getPropertiesSvc, params);
			},
			
			_updateContentItemProperties: function(view, contentItem, callback, errback) {
				console.log("CS-GetContent:_updateContentItemProperties() : Updating the property values.");
				// Need to update the original contentItem object with the new property values
				var oriContentItem = view._instance.contentItem;
				var oriProperties = oriContentItem.properties.items ? oriContentItem.properties.items : oriContentItem.properties;
				var properties = contentItem.properties.items ? contentItem.properties.items : contentItem.properties;
				
				for (var i = 0; i < oriProperties.length; i++) {
					var oriProperty = oriProperties[i];
					for (var j = 0; j < properties.length; j++) {
						var property = properties[j];
						if (oriProperty.id == property.id) {
							if (oriProperty.type == "OBJECT") {
								// Object value property, copy over the objectValue
								oriProperty.objectValue = property.objectValue;
							} else {
								// Standard property, just copy over the value
								oriProperty.value = property.value;
								// Push few properties to primary level on the content item object
								if (property.id == "Name") {
									oriContentItem.name = property.value;
								} else if (property.id == "IsReserved") {
									oriContentItem.isReserved = property.value;
								}
							}
							break;
						}
					}
				}
				
				bpmext.ui.executeEventHandlingFunction(view, this.EVT_ONPROPERTIESUPDATED, oriContentItem);

				if (callback) {
					callback(oriContentItem);
				}
			},
			
			_getAnnotation: function(view, documentId, type, annotationVersion) {
				view._instance.type = type;
				
				var params = {
					documentId: documentId,
					annotationVersion: annotationVersion,
					repository: this._getObjectStoreName(view),
					serverAppResource: view._instance.serverConfigurationName,
				};
				console.log("CS-GetContent:_getAnnotation() : Retreiving annotation for: " + documentId);
				view._instance.getAnnotationSvc = view.ui.get("GetAnnotationSvc");
				this._callService(view._instance.getAnnotationSvc, params);
			},
	
			_getDocumentContent: function(view, contentItem, url, type, callback, errback) {
				var xhr = new XMLHttpRequest();
				// Get the URL to the proxy app server so we can call through it to graphql
				var serverResource = view._instance.serverConfigurationName;
				var connectionStr = url;
				connectionStr = view.context.rewriteURI(connectionStr, serverResource);
				
				xhr.open("GET", connectionStr, true);
				
				if (type == "json") {
					xhr.responseType = "json";
				} else {
					xhr.responseType = "blob";
				}
				xhr.setRequestHeader(view.context.getCSRFTokenHeaderName(), view.context.getCSRFToken());
				xhr.setRequestHeader(this._getEcmTokenName(), this._getEcmToken(true));
			
				xhr.onreadystatechange = function() {
					if (xhr.status == 200) {
						// Response is good
						if (xhr.readyState === 4) {
							// A 200 response may contain errors from graphql api.
							try {
								var responseJson = JSON.parse(xhr.response);
								if (responseJson.errors){
									var errorResponse = responseJson.errors[0];
									var error = {};
									error.errorText = errorResponse.extensions ? errorResponse.extensions.userResponse : errorResponse.message;
									error.errorCode = errorResponse.extensions ? errorResponse.extensions.errorCode : errorResponse.errorType;
									console.log("CS-GetContent:xhr.onreadystatechange() : Failed download, calling errback.");
									if (errback) {
										errback(error);	
									}
								} else {
									console.log("CS-GetContent:xhr.onreadystatechange() : Successful download, calling callback.");
									if (callback) {
										callback();
									}
								}
							} catch (e) {
								// Response is not json, and was successfully downloaded
								console.log("CS-GetContent:xhr.onreadystatechange() : Successful download, calling callback.");
								if (callback) {
									callback();
								}
							}
						}
					} else {
						var error = {};
						error.errorText = xhr.statusText;
						error.errorCode = xhr.status;
						console.log("CS-GetContent:xhr.onreadystatechange() : Failed download, calling errback.");
						if (errback) {
							errback(error);	
						}
					}
				};
				
				var _this = this;
				
				xhr.onload = function(e) {
					// Check which type of response was specified to be returned
					if (type == "json") {
						// Return the file contents as a json object (file should have been json in the first place)
/*
						// blob.stream is not supported in FireFox ESR 60 nor 68...
						var blob = this.response;
						var blobStream = blob.stream();
*/
						var content = this.response;
						if (content != null) {
							console.log("CS-GetContent:xhr.onload() : Finished receiving json content.");
							bpmext.ui.executeEventHandlingFunction(view, "eventON_CONTENTRECEIVED", content, contentItem);
						} else {
							console.log("CS-GetContent:xhr.onload() : Failed to retrieve json content.");
							bpmext.ui.executeEventHandlingFunction(view, "eventON_ERROR");
						}
/*					
						_this.fetchStream(blobStream, function(content) {
							if (content != null) {
								console.log("CS-GetContent:xhr.onload() : Finished streaming content.");
								bpmext.ui.executeEventHandlingFunction(view, "eventON_CONTENTRECEIVED", content, contentItem);
							} else {
								console.log("CS-GetContent:xhr.onload() : Failed to parse content into json format.");
								bpmext.ui.executeEventHandlingFunction(view, "eventON_ERROR");
							}
						});
*/
					} else if (type == "response") {
						// Return the response from the xhr request
						console.log("CS-GetContent:xhr.onload() : Returning xhr response.");
						var blob = this.response;
						bpmext.ui.executeEventHandlingFunction(view, "eventON_CONTENTRECEIVED", blob, contentItem);
					} else {
						var objectURL = window.URL.createObjectURL(e.currentTarget.response);
						var fileName = "temp";
						// Dig the downloaded file name out of the content disposition header
						var disposition = this.getResponseHeader("content-disposition");
						if (disposition && disposition.indexOf('attachment') !== -1) {
							var filename;
							var filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
							var matches = filenameRegex.exec(disposition);
							if (matches != null && matches[1]) { 
							    filename = matches[1].replace(/['"]/g, '');
							}
//							var filenameRegex = /filename[^;=\n]*=(UTF-8(['"]*))?(.*)/;
//							var matches = filenameRegex.exec(disposition);
//							if (matches != null && matches[3]) { 
//								filename = matches[3].replace(/['"]/g, '');
//							}
							fileName =  decodeURI(filename);
						}

						// Default is to download the file to the browser and no on received content event will be fired
						console.log("CS-GetContent:xhr.onload() : Downloading content to browser, filename: " + fileName);
						
						// Create a link pointing to the ObjectURL containing the blob.
						var link = document.createElement('a');
						link.href = objectURL;
						link.download = fileName;
						// For FireFox
						link.style.display = "none";
						document.body.appendChild(link);
						// Make the download happen in the browser
						link.click();
						document.body.removeChild(link);				
						setTimeout(function(){
							// For Firefox it is necessary to delay revoking the ObjectURL
							window.URL.revokeObjectURL(objectURL);
						}, 100);
					}
				};

				xhr.send();
			},
	
			fetchStream: function(stream, callback) {
				console.log("CS-GetContent:fetchStream()");
			    const reader = stream.getReader();
			    let charsReceived = 0;
			    let result = "";
				
				var _this = this;
			  
			    // read() returns a promise that resolves when a value has been received
				reader.read().then(function processText({ done, value }) {
					// Result objects contain two properties:
					// 		done  - true if the stream has already given you all its data.
					// 		value - some data. Always undefined when done is true.
					if (done) {
					    console.log("CS-GetContent:fetchStream() : Streaming is complete");
						if (callback) {
							try {
								var content = JSON.parse(result);
								callback(content);
							} catch (e) {
								// If the file content is not in json format, this will throw
								callback(null);
							}
						}
						return;
					}

					// Value for fetch streams is a Uint8Array
					charsReceived += value.length;
					const chunk = value;
					console.log("CS-GetContent:fetchStream() : Streamed " + charsReceived + " characters.");

					var decoder = new TextDecoder();
					result += decoder.decode(value);
										
					// Read some more, and call this function again
					return reader.read().then(processText);
				});
			},
			
			_getClassAccess: function(view, classDef, classId, accessMask, callback, errback) {
				console.log("CS-GetContent:_getClassAccess() : called.");
				view._instance.accessMask = accessMask;
				view._instance.classAccessCallback = callback; 
				view._instance.classAccessErrback = errback; // general error callback handling

				var params = {
					classDef: classDef,
					classId: classId,
					repository: view._instance.objectStoreName,
					serverAppResource: view._instance.serverConfigurationName
				};
										
				view._instance.getClassAccessSvc = view.ui.get("GetClassAccessSvc");
				this._callService(view._instance.getClassAccessSvc, params);
			}
		};
		
		/*
		 * Private methods and event handlers *************************************************************
		 */
	
	   	this.constructor.prototype._parseError = function(error) {
      		if (error.errorText) {
        		if (error.errorText.indexOf("CWTBI0006E") != -1) {
					var message = string.substitute(messages.contlist_invalid_server_error, [this._instance.serverConfigurationName]);
					return message;
				}
      		}
      		return null;
    	};

		this.constructor.prototype._onGetVersionSeriesResult = function() {
			var view = this;
			console.log("CS-GetContent:_onGetVersionSeriesResult() : called");

			// Check that there are results that came back from the service call
			var result = view._instance.getVersionSeriesSvc && view._instance.getVersionSeriesSvc.getResult();
			if (result) {
				var items = result.results.items ? result.results.items : result.results;
				var versionSeries = items[0]; // only one item returned
				var contentItem = {
					id: versionSeries.currentVersion.id
				};
				this._proto._downloadDocument(this, contentItem, null, false, view._instance.callback, view._instance.errback);
			}
		};

		this.constructor.prototype._onGetVersionSeriesError = function() {
			var view = this;
			var error = view._instance.getVersionSeriesSvc && view._instance.getVersionSeriesSvc.getLastError();
			if (error) {
				view._instance.error = error;

        		var message = this._parseError(error);
        		if (message == null) {
          			message = messages.getcontent_ret_versions_error;        
        		}
				console.log("CS-GetContent:_onGetVersionSeriesError() : " + message);

				setTimeout(function() {
					bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, message);
				});
			}
		};

		this.constructor.prototype._onGetPropertiesResult = function() {
			var view = this;
			console.log("CS-GetContent:_onGetPropertiesResult() : called");
			// Check that there are results that came back from the service call
			var result = view._instance.getPropertiesSvc && view._instance.getPropertiesSvc.getResult();
			if (result && result.update) {
				var contentItem = result;
				// This is a contentItem properties update, need to see new values back into the contentItem
				this._proto._updateContentItemProperties(this, contentItem, view._instance.propsCallback, view._instance.propsErrback);
			} else {
				this._proto._downloadDocument(this, contentItem, null, true, view._instance.callback, view._instance.errback);
			}
		};

		this.constructor.prototype._onGetPropertiesError = function() {
			var view = this;
			var error = view._instance.getPropertiesSvc && view._instance.getPropertiesSvc.getLastError();
			if (error) {
				view._instance.error = error;

        		var message = this._parseError(error);
        		if (message == null) {
          			message = messages.getcontent_ret_properties_error;        
        		}
				console.log("CS-GetContent:_onGetPropertiesError() : " + message);

				var errback = this._instance.propsErrback;
				if (errback) {
					errback(error);
				}

				setTimeout(function() {
					bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, message);
				});
			}
		};
		
		this.constructor.prototype._onGetAnnotationResult = function(view, results) {
			var view = this;
			console.log("CS-GetContent:_onGetAnnotationResult() : called");
			if (results && results.downloadUrl) {
				var url = results.downloadUrl.replace("content", "content-services-graphql/content");
				this._proto._getDocumentContent(this, null, url, view._instance.type, view._instance.callback, view._instance.errback);
			} else {
				console.log("CS-GetContent:_onGetAnnotationResult() : Error retrieving annotation, download Url is null.");
				setTimeout(function() {
					bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, messages.getcontent_ret_annotations_error);
				});
			}
		};
		
		this.constructor.prototype._onGetAnnotationError = function(view, error) {
			var view = this;
			if (error) {
				view._instance.error = error;
				var message = this._parseError(error);
				if (message == null) {
					message = messages.getcontent_ret_annotations_error;        
				}
				console.log("CS-GetContent:_onGetAnnotationError() : " + message);

				setTimeout(function() {
					bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, message);
				});
			}
		};
		 
	 	this.constructor.prototype._onGetClassAccessResults = function(view, results) {
			console.log("CS-GetContent:_onGetClassAccessResults() called");
			if (results) {
				var accessAllowed = results.accessAllowed;
				console.log("CS-GetContent._onGetClassAccessResults: Access allowed: " + accessAllowed);
				var access = false;
				if (this._instance.accessMask) {
					// There is an access mask value to compare
					if ((accessAllowed & this._instance.accessMask) > 0) {
						// Yes the access is allowed
						access = true;
					}
				}
				
				var callback = this._instance.classAccessCallback
				if (callback) {
					callback(accessAllowed, access);
				}
				bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONGETCLASSACCESS, accessAllowed, access);
			} else {
				console.log("CS-GetContent._onGetClassAccessResults: Error retrieving access allowed results: " + JSON.stringify(results));
				var message = messages.getcontent_ret_classaccess_error;
				var errback = this._instance.classAccessErrback;
				if (errback) {
					errback(message);
				}
				bpmext.ui.executeEventHandlingFunction(this, this.EVT_ONERROR, message);
			}
		};

		this.constructor.prototype._onGetClassAccessError = function(view, error) {
			var logMessage = error && error.errorText ? error.errorText : messages.batchcontent_search_error;
			console.log("CS-GetContent:_onGetClassAccessError : " + logMessage);
			var message = messages.getcontent_ret_classaccess_error;
			var errback = this._instance.classAccessErrback;
			if (errback) {
				errback(error);
			}
			var self = this;
			setTimeout(function() {
				bpmext.ui.executeEventHandlingFunction(self, self._proto.EVT_ONERROR, message);
			});
		};	

		/*
		 * Public control methods *************************************************************
		 */

		/**
		 * @instance
		 * @memberof CSGetContent
		 * @method getType
		 * @desc Returns the descriptive string that represents the control type.
		 * @returns {string}
		 */
		this.constructor.prototype.getType = function() {
			return "csGetContent.3";
		};
	
		this.constructor.prototype.setObjectStoreName = function(objectStoreName) {
			this._instance.objectStoreName = objectStoreName;
		};
	
		/**
		 * @instance
		 * @method getContent
		 * @desc Retrives the document content information and sends out an event when finished
		 * @param contentItem CSContentItem object for which we need to get the contentElement information out of
		 * @param type String "json", "file" or "response".
		 *		"file" will down load the content to the browser.
		 *      "json" will attempt to convert the file contnet into a json object before firing the on received event.
		 * 		"response" will send back the xhr response object in the on received event.
		 * @param callback: Function called when the properties are retrieved successfully.
		 * @param errback: Function called when an error occurs.
		 */
		this.constructor.prototype.getContent = function(contentItem, type, callback, errback) {
			console.log("CS-GetContent:getContent() : called");
		
			// Type can be "json", "file" or "response"
			this._instance.callback = callback;
			this._instance.errback = errback;
			
			this._proto._downloadDocument(this, contentItem, type, false, callback, errback);
		};
		
		/**
		 * @instance
		 * @method getAnnotationContent
		 * @desc Retrives annotation content and fires an event when finished.
		 * @param documentId String The identifier of the document from which to retrieve annotation content.
		 * @param type String "json", "file" or "response".
		 *		"file" will down load the content to the browser.
		 * 		"json" will attempt to convert the file contnet into a json object before firing the on received event.
		 * 		"response" will send back the xhr response object in the on received event.
		 * @param annotationVersion String "first" or "last"
		 * 		"last" will retreive the content of the last annotation added to the document
		 * 		"first" will retreive the content of the first annotation added to the document.
		 * @param callback: Function called when the properties are retrieved successfully.
		 * @param errback: Function called when an error occurs.
		 */
		this.constructor.prototype.getAnnotationContent = function(documentId, type, annotationVersion, callback, errback) {
			console.log("CS-GetContent:getAnnotationContent() : called");
			
			// Type can be "json", "file" or "response". AnnotationVersion can be "first" or "last". 
			this._instance.callback = callback;
			this._instance.errback = errback;
			
			this._proto._getAnnotation(this, documentId, type, annotationVersion);
		};
		
		/**
		 * @instance
		 * @method getContentItemProperties
		 * @desc Retrieves new updated property values for the passed in content item object.
		 * @param contentItem Object holding the object Id and properties to be retrieved
		 * @param callback: Function called when the properties are retrieved successfully.
		 * @param errback: Function called when an error occurs.
		 */
		this.constructor.prototype.getContentItemProperties = function(contentItem, callback, errback) {
			console.log("CS-GetContent:getContentItemProperties() : called");
			this._instance.propsCallback = callback;
			this._instance.propsErrback = errback;
			this._instance.contentItem = contentItem;
			
			var props = [];
			var ovpProps = [];
			
			var properties = contentItem.properties.items ? contentItem.properties.items : contentItem.properties;
			for (var i = 0; i < properties.length; i++) {
				var property = properties[i];			
				if (property.type == "OBJECT") {
					props.push(property.id);
					if (property.objectValue) {
						// This is an object value property, need to loop through it's property list
						var objectProperties = property.objectValue.properties.items ? property.objectValue.properties.items : property.objectValue.properties;
						for (j = 0; j < objectProperties.length; j++) {
							var objectProperty = objectProperties[j];
							// This is a property on the ovp, add it to list of ovp properties to be retrieved
							ovpProps.push(objectProperty.id);
						}
					}
				} else {
					// This is a standard property, add it to the collection of properties to retrieve
					props.push(property.id);
				}
			}
			
			this._proto._getProperties(this, contentItem, props, ovpProps, "properties");
		};

		/**
		 * @instance
		 * @memberof CS-GetContent
		 * @method getClassAccess
		 * @param classDef: Class definition name "ClassDefinition"
		 * @param classId: Class description id (symbolic name of class you are interested in) 
		 * @param accessMask: Access mask to check for (optional)
		 * @param callback: Function called when the access information has been returned successfully.
		 * @param errback: Function called when an error occurs.
		 * @desc Returns the specified class definitions access allowed information that can be use to check user accesss rights.
		 */
		this.constructor.prototype.getClassAccess = function(classDef, classId, accessMask, callback, errback) {	
			console.log("CS-GetContent:getClassAccess() : called for class definition: " + classDef);

			// Call the service to retrieve the class definitions access allowed information
			this._proto._getClassAccess(this, classDef, classId, accessMask, callback, errback);
		};

		/*
		 * Coach NG Lifecycle methods *************************************************************
		 */
		 
		this.constructor.prototype.load = function() {
			console.log("CS-GetContent:load() : called");
	
			try	{
				var opts = this.context.options;

				if (!opts.objectStoreName) {
                    opts.objectStoreName = bpmext.ui.substituteConfigOption(this, "objectStoreName", null);
				}

				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONERROR, "message");
				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONCONTENTRECEIVED, "content", "contentItem");
				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONPROPERTIESUPDATED, "contentItem");
				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONGETCLASSACCESS, "accessAllowed", "access");

				bpmext.ui.loadView(this);
				
			} catch (e) {
				bpmext.log.error("Error on load event [" + this.context.viewid + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};

		this.constructor.prototype.view = function () {
			console.log("CS-GetContent:view() : called");
            try {
				this._proto._handleVisibility(this);
 			} catch (e) {
                bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
                if (e.stack) {
                    bpmext.log.error("  Call stack: " + e.stack);
				}
            }
        };

		this.constructor.prototype.change = function(event)	{
			console.log("CS-GetContent:change() : called");
			try	{
				var view = this;
				if (event.type == "config")	{
					switch (event.property)	{
             			case "height": {
							this._proto._setHeight(this, event.newVal);
							break;
						}
            			case "width": {
							this._proto._setWidth(this, event.newVal);
							break;
						}
					}
				} else {
				}
			} catch (e) {
				bpmext.log.error("Error on change event [" + this.ui.getAbsoluteName() + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};
		
	}
}
	
