/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2020. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

cs_InitProgressIndicator = function(bpmext, domClass, domAttr, domStyle, messages, utilities, string){
	 _pos1: 0;
	 _pos2: 0;
	 _pos3: 0;
	 _pos4: 0;
	 _progressIndicatorLayout: null;
	 _progressIndicatorBodyLayout: null;
	 _showMoreLessLink: null;
	 _headerText: null;
	 _statusImageHeader: null;
	 _loadingImageHeader: null;
	 _actionLinkFunctions: null;
	 _itemName: "";
	 _fileData: [];
	 _removeFileFunction: null;
	 
	 if (!this.constructor.prototype._proto)
	{
		this.constructor.prototype._proto =
		{
			EVT_ONFILEREMOVED: "eventON_FILEREMOVED",
			EVT_ONCLOSE: "eventON_CLOSE",
			
			processingStatus: {
				PENDING: "pending",
				PROGRESS: "progress",
				WARNING: "warning",
				ERROR: "error",
				SUCCESS: "success"
			},
			
			statusPropertyValues: {
				PENDING: 3,
				UPLOADING: 5,
				UPLOADED: 10,
				PROCESSING: 20,
				REVIEW_REQUIRED: 30,
				UPDATING: 40,
				PROCESSING_ERROR: 900,
				FINALIZING_ERROR: 910,
				UPLOADING_ERROR: 920,
				SUCCESS: "",
				SUCCESS_NULL: null,
				NOT_FOUND: "Not found",
				TIMEOUT: "Timeout"
			},
			STATUS_PROPERTY_VALUE_ERROR_LOWER_BOUNDARY: 900,
			STATUS_PROPERTY_VALUE_ERROR_UPPER_BOUNDARY: 999,
			
			maxNumRows: 5,
			_handleVisibility: function (view) {
				var vis = utilities.handleVisibility(view.context);
			},
			
			removeFile(view, batchId, fileName){
				var numFiles = 0;
				var foundProcessing = false;
				for (var i = view._fileData.length - 1; i >= 0; i--){
					var fileData = view._fileData[i];
					if (fileData.batchId == batchId && fileData.name == fileName && fileData.status == this.statusPropertyValues.PENDING){
						bpmext.ui.executeEventHandlingFunction(view, this.EVT_ONFILEREMOVED, batchId, fileName);
						fileData.itemRow.remove();
						view._fileData.splice(i, 1);
					}
					else if (fileData.status == this.statusPropertyValues.PENDING ||
						fileData.status == this.statusPropertyValues.UPLOADING ||
						fileData.status == this.statusPropertyValues.PROCESSING){
						
						numFiles++;
						if (fileData.status == this.statusPropertyValues.PROCESSING){
							foundProcessing = true;
						}
					}
				}
				var headerText = foundProcessing ? getProcessingHeaderText(numFiles) : this.getUploadHeaderText(numFiles);
				this.updateHeader(view, headerText, this.processingStatus.PROGRESS);
			},
			
			getUploadHeaderText(numUploadingFiles){
				return (numUploadingFiles > 1 ? string.substitute(messages.progress_ind_headerUploadingMsg,[numUploadingFiles]) : messages.contlist_progress_uploading_text)
			},
			
			getProcessingHeaderText(numFiles){
				return (numFiles > 1 ? string.substitute(messages.progress_ind_headerProcessingMsg,[numFiles]) : messages.contlist_progress_processing)
			},
			
			updateRow: function(view, itemRow, itemName, status, actionLinkFunction, polling, terminal, documentId, batchId){
				if (status != this.statusPropertyValues.NOT_FOUND){
					var itemNameTxt = itemRow.querySelector(".CS_ItemName");
					var actionLink = itemRow.querySelector(".CS_ActionLink");
					var statusTxt = itemRow.querySelector(".CS_StatusText");
					var statusImage = itemRow.querySelector(".CS_StatusImageBody");
					var loadingImage =  itemRow.querySelector(".CS_Loading");
					
					var _this = this;
					var removeFromQueue = function(evt){
						var keyID = (evt.charCode) ? evt.charCode : ((evt.which) ? evt.which : evt.keyCode);
						if(keyID == 13 || keyID == 32){
							_this.removeFile(view, batchId, itemName);
						}
						return true;
					};
										
					if (itemName){
						var itemNameTextNode = this.getTextNode(itemNameTxt);
						itemNameTextNode.nodeValue = itemName;
						domAttr.set(itemNameTxt, "title", encodeURI(itemName));
					}
					domClass.remove(statusImage, "CS_StatusImageClose");
					domClass.remove(statusImage, "CS_StatusImageWarning");
					domClass.remove(statusImage, "CS_StatusImageSuccess");
					domClass.remove(statusImage, "CS_StatusImageError");
					statusImage.setAttribute("tabindex", "-1");
					statusImage.onclick = null;
					statusImage.removeEventListener('keypress', removeFromQueue);

					var statusText;
					var actionLinkHelp;
					switch(status){
						case this.statusPropertyValues.PENDING:
							statusText = "";
							statusImage.style.display = "";
							loadingImage.style.display = "none";
							domClass.add(statusImage, "CS_StatusImageClose");
							statusImage.setAttribute("tabindex", "0");
							domAttr.set(statusImage, "title", messages["status_"+ status]);
							statusImage.onclick = function(evt){
								_this.removeFile(view, batchId, itemName);
							}
							statusImage.addEventListener('keypress', removeFromQueue);
							break;
						case this.statusPropertyValues.UPLOADING:
							statusText = messages["status_"+ status];
							statusImage.style.display = "none";
							loadingImage.style.display = "";		
							domAttr.set(loadingImage, "title", messages["status_"+ status]);
							break;
						case this.statusPropertyValues.UPLOADED:	
							statusText = messages["status_"+ status];
							if (polling){
								if (terminal){
									statusImage.style.display = "";
									loadingImage.style.display = "none";
									domClass.add(statusImage, "CS_StatusImageWarning");
									domAttr.set(statusImage, "title", "Warning");
								}
								else {
									statusImage.style.display = "none";
									loadingImage.style.display = "";
								}
							}
							else {
								statusImage.style.display = "";
								loadingImage.style.display = "none";
								domClass.add(statusImage, "CS_StatusImageSuccess");
								domAttr.set(statusImage, "title", messages.contlist_progress_success);
							}
							break;
						case this.statusPropertyValues.PROCESSING:
							statusText = messages["status_"+ status];
							statusImage.style.display = "none";
							loadingImage.style.display = "";
							domAttr.set(loadingImage, "title", messages.progress_ind_processing_status);
							break;
						case this.statusPropertyValues.REVIEW_REQUIRED:
							statusText = messages.progress_ind_review_doc;
							statusImage.style.display = "";
							loadingImage.style.display = "none";
							domClass.add(statusImage, "CS_StatusImageWarning");
							domAttr.set(statusImage, "title", messages.progress_ind_review_doc);
							break;
						case this.statusPropertyValues.UPDATING:
							statusText = messages["status_"+ status];
							statusImage.style.display = "none";
							loadingImage.style.display = "";
							domAttr.set(loadingImage, "title", messages["status_"+ status]);
							break;
						case this.statusPropertyValues.PROCESSING_ERROR:
						case this.statusPropertyValues.UPLOADING_ERROR:
						case this.statusPropertyValues.FINALIZING_ERROR:
							statusText = messages["status_"+ status];
							statusImage.style.display = "";
							loadingImage.style.display = "none";
							domClass.add(statusImage, "CS_StatusImageError");
							domAttr.set(statusImage, "title", messages.contlist_progress_error);
							break;
						case this.statusPropertyValues.SUCCESS:
						case this.statusPropertyValues.SUCCESS_NULL:
							statusText = messages.contlist_progress_success;
							statusImage.style.display = "";
							loadingImage.style.display = "none";
							domClass.add(statusImage, "CS_StatusImageSuccess");
							domAttr.set(statusImage, "title", messages.contlist_progress_success);
							break;		
						case this.statusPropertyValues.TIMEOUT:
							statusText = messages.progress_ind_check_status;
							actionLinkHelp = messages.progress_ind_check_status_help;
							statusImage.style.display = "";
							loadingImage.style.display = "none";
							domClass.add(statusImage, "CS_StatusImageWarning");
							domAttr.set(statusImage, "title", messages.progress_ind_timeout);
							break;	
						default:
							statusText = messages.contlist_progress_error;
							status = this.processingStatus.ERROR;
							statusImage.style.display = "";
							loadingImage.style.display = "none";
							domClass.add(statusImage, "CS_StatusImageError");
							domAttr.set(statusImage, "title", messages.contlist_progress_error);
							break;
					}
				}
				
				if (actionLinkFunction){
					statusTxt.style.display = "none";
					actionLink.style.display = "";
					var actionTextNode = this.getTextNode(actionLink);
					actionTextNode.nodeValue = statusText;
					actionLink.onclick = actionLinkFunction;
					domAttr.set(actionLink, "name", documentId);
					domAttr.set(actionLink, "title", actionLinkHelp ? actionLinkHelp : statusText);
				}
				else if (statusTxt) {
					statusTxt.style.display = "";
					actionLink.style.display = "none";
					statusTextNode = this.getTextNode(statusTxt);
					statusTextNode.nodeValue = statusText;
					domAttr.set(statusTxt, "title", statusText);
				}
			},
			
			getTextNode: function(parentNode){
				var textNode;
				for(i = 0; i < parentNode.childNodes.length; i++){
					var child = parentNode.childNodes[i];
					if (child.nodeType == Node.TEXT_NODE){
						textNode = child;
						break;
					}
				}
				if (!textNode){
					textNode = document.createTextNode("");
					parentNode.appendChild(textNode);
				}
				return textNode;
			},
			
			addItemRow: function(view){
				var itemRow = document.createElement("div");
				domClass.add(itemRow, "CS_ProgressIndicatorItemRow");
				var body = view.context.element.querySelector(".CS_ProgressIndicatorBody");
				if (body.children.length > 0){
					body.insertBefore(itemRow, body.children[0]);
				}
				else {
					body.appendChild(itemRow);
				}
				
				var fileNameLayout = document.createElement("span");
				domClass.add(fileNameLayout, "CS_FileNameLayout");
				itemRow.appendChild(fileNameLayout);
				
				var itemName = document.createElement("span");
				domClass.add(itemName, "CS_ItemName");
				fileNameLayout.appendChild(itemName);
				
				var statusLayout = document.createElement("span");
				domClass.add(statusLayout, "CS_StatusLayout");
				itemRow.appendChild(statusLayout);
				
				var actionLink = document.createElement("a");
				domClass.add(actionLink, "CS_ActionLink");
				actionLink.href ="#";
				statusLayout.appendChild(actionLink);
				
				var statusText = document.createElement("span");
				domClass.add(statusText, "CS_StatusText");
				statusLayout.appendChild(statusText);
				
				var statusImage = document.createElement("span");
				domClass.add(statusImage, "CS_StatusImageBody");
				statusImage.style.display = "none";
				statusLayout.appendChild(statusImage);
				
				var loading = document.createElement("span");
				domClass.add(loading, "CS_Loading");
				statusImage.style.display = "none";
				statusLayout.appendChild(loading);
				
				loading.innerHTML = "<svg class=\"CS_Loader\" viewBox=\"25 25 50 50\"><circle class=\"CS_Loader__path\" cx=\"50\" cy=\"50\" r=\"13\"></circle></svg>";
					
				if (body.children.length <= this.maxNumRows){
					this._setHeightStyle(view, body.children.length);
				}
				
				return itemRow;
			},
			
			_setHeightStyle(view, numRows){
				var body = view.context.element.querySelector(".CS_ProgressIndicatorBody");
				var bodyLayout = view._progressIndicatorLayout.context.element;
				for (var i = 1; i <= this.maxNumRows; i++){
					var layoutStyle = "CS_ProgressIndicatorLayout" + i;
					domClass.remove(bodyLayout, layoutStyle);
					
					var bodyStyle = "CS_ProgressIndicatorBody" + i;
					domClass.remove(body, bodyStyle);
				}
				
				if (numRows > 0){
					var newLayoutStyle = "CS_ProgressIndicatorLayout" + numRows;
					domClass.add(bodyLayout, newLayoutStyle);	

					var newBodyStyle = "CS_ProgressIndicatorBody" + numRows;
					domClass.add(body, newBodyStyle);
				}
			},
			
			updateHeader: function(view, headingText, processingStatus){
				view._headerText.setText(headingText);

				var image = "";
				view._statusImageHeader.context.options._metadata.visibility.set("value", "DEFAULT");
				view._loadingImageHeader.style.display = "none";
				switch(processingStatus){
					case this.processingStatus.PROGRESS:
						view._statusImageHeader.context.options._metadata.visibility.set("value", "NONE");
						view._loadingImageHeader.style.display = "";
						break;
					case this.processingStatus.WARNING:
						image = "CS-Warning.svg";
						break;
					case this.processingStatus.ERROR:
						image = "CS-Error.svg";
						break;
					case this.processingStatus.SUCCESS:
						image = "CS-Success.svg";
						break;
					default:
					image = "";
				}
				view._statusImageHeader.setImage(image, "Web");
			}
		}
	};
	
	/**
	* Updates the progress indicator from data recieved from property status polling.
	**/
	this.constructor.prototype.updateFromPolling = function(pollingData){
		this.updateDocumentStatus(pollingData.name, pollingData.processingStatus, true, pollingData.terminal, pollingData.documentId);
	}
	
	/**
	* Updates the information displayed in the progress indicator header.
	**/
	this.constructor.prototype.updateHeader = function(headingText, headerStatus){
		this._proto.updateHeader(this, headingText, headerStatus);
	};
	
	/**
	* Displays  the progress indicator when files are being uploaded
	*/
	this.constructor.prototype.displayFileUploadStatus = function(batchId, files, clear){
		this._progressIndicatorLayout.context.options._metadata.visibility.set("value", "DEFAULT");
		
		if (clear){
			this.clear();
		}
		
		var sortedFiles = files.sort(function(file1, file2){
			return (file1.name).localeCompare(file2.name);
		});
		
		for (var i = sortedFiles.length - 1; i >= 0; i--){
			var file = sortedFiles[i];
			var itemRow = this._proto.addItemRow(this);
			this._fileData.push({
				name: file.name,
				batchId: batchId,
				status: this._proto.statusPropertyValues.PENDING,
				itemRow: itemRow,
				terminal: false
			});
			this._proto.updateRow(this, itemRow, file.name, this._proto.statusPropertyValues.PENDING, null, false, false, null, batchId);
		}
		
		if (clear){
			var numUploadingFiles = 0;
			for (var i = 0; i < this._fileData.length; i++){
				var fileData = this._fileData[i];
				if (fileData.status == this._proto.statusPropertyValues.PENDING ||
					fileData.status == this._proto.statusPropertyValues.UPLOADING){
						
					numUploadingFiles++;
				}
			}
			var headerText = this._proto.getUploadHeaderText(numUploadingFiles);
			this._proto.updateHeader(this, headerText, this._proto.processingStatus.PROGRESS);
		}
	};
	
	/**
	* Updates one row in the progress indicator with new document status.
	*/
	this.constructor.prototype.updateDocumentStatus = function(fileName, processingStatus, polling, terminal, documentId, batchId){
		console.log("CS-ProgressIndicator: updateDocumentStatus : fileName: " + fileName + " processingStatus: " + processingStatus + " documentId: " + documentId + " batchId: " + batchId);
		var allSuccess = true;
		var headerStatus;
		var headerText;
		var numFiles = 0;
		for (var i = 0; i < this._fileData.length; i++){
			var fileData = this._fileData[i];
			if (fileData.name == fileName && fileData.batchId == batchId && !fileData.docId && documentId){
				fileData.docId = documentId;
			}
			
			if ((documentId && fileData.docId == documentId) ||
				(fileData.name == fileName && fileData.batchId == batchId && 
				(fileData.status == this._proto.statusPropertyValues.PENDING && processingStatus == this._proto.statusPropertyValues.UPLOADING) || processingStatus == this._proto.processingStatus.ERROR)){
					
				if (terminal || fileData.status != this._proto.statusPropertyValues.TIMEOUT){
					fileData.status = processingStatus;
				}
				fileData.terminal = terminal;
				
				var actionLinkFunction = this._actionLinkFunctions && this._actionLinkFunctions[fileData.status] ? this._actionLinkFunctions[fileData.status] : null;
				this._proto.updateRow(this, fileData.itemRow, fileData.name, fileData.status, actionLinkFunction, polling, terminal, documentId, fileData.batchId);
			}			

			if (fileData.status != this._proto.statusPropertyValues.SUCCESS){
				allSuccess = false;
				if (fileData.status == this._proto.statusPropertyValues.TIMEOUT){
					headerStatus = this._proto.processingStatus.WARNING;
					headerText = messages.progress_ind_timeout;
				}
				else if (fileData.status == this._proto.processingStatus.ERROR || 
					(fileData.status >= this._proto.STATUS_PROPERTY_VALUE_ERROR_LOWER_BOUNDARY && fileData.status <= this._proto.STATUS_PROPERTY_VALUE_ERROR_UPPER_BOUNDARY)){
						
					headerStatus = this._proto.processingStatus.ERROR;
					headerText = messages.progress_ind_processing_err;
				}
			}

			if (headerStatus != this._proto.processingStatus.ERROR && (
				fileData.status == this._proto.statusPropertyValues.REVIEW_REQUIRED ||
				fileData.status == this._proto.statusPropertyValues.PROCESSING_ERROR)){
				
				headerStatus = this._proto.processingStatus.WARNING;
				headerText = fileData.status == this._proto.statusPropertyValues.REVIEW_REQUIRED ? messages.progress_ind_review_doc : messages.progress_ind_processing_err;
			}
			else if (headerStatus != this._proto.processingStatus.ERROR &&
				headerStatus != this._proto.processingStatus.WARNING &&
				(fileData.status == this._proto.statusPropertyValues.PENDING ||
				fileData.status == this._proto.statusPropertyValues.UPLOADING ||
				fileData.status == this._proto.statusPropertyValues.PROCESSING ||
				fileData.status == this._proto.statusPropertyValues.UPLOADED)){
					
				headerStatus = this._proto.processingStatus.PROGRESS;
				numFiles++;
			}			
		}
		if (allSuccess){
			var multiFileMessage = polling ? messages.progress_ind_processed_files : messages.progress_ind_uploaded_files;
			var singleFileMessage = polling ? messages.progress_ind_processed : messages.progress_ind_uploaded;
			var headerText = this._fileData.length == 1 ? singleFileMessage : string.substitute(multiFileMessage, [this._fileData.length]);	
			headerStatus = this._proto.processingStatus.SUCCESS;
		}
		else if (headerStatus == this._proto.processingStatus.PROGRESS){
			var multiFileMessage = polling ? messages.progress_ind_headerProcessingMsg : messages.progress_ind_headerUploadingMsg;
			var singleFileMessage = polling ? messages.contlist_progress_processing : messages.contlist_progress_uploading_text;
			headerText = this._fileData.length == 1 ? singleFileMessage : string.substitute(multiFileMessage, [numFiles]);		
		}
		this._proto.updateHeader(this, headerText, headerStatus);
	};
	
	/**
	* Called initially to display the progress indicator for a single item in a non-upload scenario.
	**/
	this.constructor.prototype.show = function(itemId, itemName, processingStatus){
		this._progressIndicatorLayout.context.options._metadata.visibility.set("value", "DEFAULT");
		var clear = true;
		for (var i = 0; i < this._fileData.length; i++){
			if (!this._fileData[i].terminal){
				clear = false;
				break;
			}
		}
		if (clear){
			this.clear();
		}
		
		var itemRow = this._proto.addItemRow(this);
		this._fileData.push({
			name: itemName,
			docId: itemId,
			batchId: "",
			status: processingStatus,
			itemRow: itemRow,
			terminal: false
		});
		this.updateDocumentStatus(itemName, processingStatus, true, false, itemId);
		
		/*
		// Reposition if not already displayed.
		if (initialVisibility == "NONE"){
			this._progressIndicatorLayout.context.element.style.width = (window.innerWidth/2) + "px";
			this._progressIndicatorLayout.context.element.style.top = (window.innerHeight - this._progressIndicatorLayout.context.element.offsetHeight) + 'px';
			this._progressIndicatorLayout.context.element.style.left = ((window.innerWidth/2) - (this._progressIndicatorLayout.context.element.offsetWidth/2)) + 'px';
		}
		*/
	};
	
	/**
	* Adds a function that will be executed when the user clicks a link in the progress indicator for a document.
	* @ param processingStatus: The processingStatus for whick the link will be displayed.
	* @ param linkFunction: The function that will be called when the link is clicked.
	*/
	this.constructor.prototype.addActionLinkFunction = function(processingStatus, linkFunction){
		if (!this._actionLinkFunctions){
			this._actionLinkFunctions = {};
		}
		this._actionLinkFunctions[processingStatus] = linkFunction;
	};
	
	/**
	* Registers a function that will be called when the user clicks the "delete" icon for pending files.
	*/
	this.constructor.prototype.setRemoveFileFunction = function(removeFileFunction){
		this._removeFileFunction = removeFileFunction;
	};
	
	/**
	* Hides the progress indicator.
	**/
	this.constructor.prototype.hideDisplay = function(){
		this._progressIndicatorLayout.context.options._metadata.visibility.set("value", "NONE");
		bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONCLOSE);
	};
	
	/**
	* Removes and item row from the display. Closes the dialog if there are no more rows remaining.
	*/
	this.constructor.prototype.removeItemRow = function(documentId){
		console.log("CS-ProgressIndicator: removeItemRow : documentId: " + documentId);
		var found = false;
		for (var i = 0; i < this._fileData.length; i++){
			var fileData = this._fileData[i];
			console.log("CS-ProgressIndicator: removeItemRow : fileData.docId: " + fileData.docId);
			if (fileData.docId == documentId){
				found = true;
				fileData.itemRow.remove();
				this._fileData.splice(i, 1);
				break;
			}
		}
		if (!found){
			console.log("CS-ProgressIndicator: removeItemRow : Didn't find documentId");
		}
		if (this._fileData.length == 0){
			this.hideDisplay();
		}
		else {
			var body = this.context.element.querySelector(".CS_ProgressIndicatorBody");
			if (body.children.length <= this._proto.maxNumRows){
				this._proto._setHeightStyle(this, body.children.length);
			}
		}
	};
	
	/**
	* Clears the progress indicator
	**/
	this.constructor.prototype.clear = function(){
		var body = this.context.element.querySelector(".CS_ProgressIndicatorBody");
		while (body.firstChild) {
			body.firstChild.remove();
		}
		this._proto._setHeightStyle(this, 0);
		this._fileData = [];
	}
	
	/**
	* Returns a boolean indicating the corresponding item is currently displayed in the indicator
	*/
	this.constructor.prototype.isItemDisplayed = function(itemId){
		var fileData =  this._fileData.find(fileDataItem => fileDataItem.docId == itemId);
		return fileData ? true : false;
	};
	
	/**
	* Returns a boolean indicating the corresponding item is currently active (is not in terminal state)
	*/
	this.constructor.prototype.isItemActive = function(itemId){
		var isActive = false;
		var fileData =  this._fileData.find(fileDataItem => fileDataItem.docId == itemId);
		if (fileData){
			isActive = !fileData.terminal;
		}
		return isActive;
	};
	
	this.constructor.prototype.isOpen = function(){
		var visibility = this._progressIndicatorLayout.context.options._metadata.visibility.get("value");
		return !(visibility == "NONE");
	}
	
	this.constructor.prototype.showMoreLess = function(){
		var visibility = this._progressIndicatorBodyLayout.context.options._metadata.visibility.get("value");
		if (visibility == "NONE"){
			this._progressIndicatorLayout.context.element.style.height = null;
			this._progressIndicatorBodyLayout.context.options._metadata.visibility.set("value", "DEFAULT");
			this._showMoreLessLink.setText(messages.progress_ind_show_less);
			
		}
		else {
			this._progressIndicatorLayout.context.element.style.height = "50px";	
			this._progressIndicatorBodyLayout.context.options._metadata.visibility.set("value", "NONE");
			this._showMoreLessLink.setText(messages.progress_ind_show_more);
		}
	};
	
	this.constructor.prototype.dragMouseDown = function(evt, view){
		evt = evt || window.event;
		evt.preventDefault();
		
		document.onmouseup = view.closeDragElement;
		
		// get the mouse cursor position at startup:
		view._pos3 = evt.clientX;
		view._pos4 = evt.clientY;
		
		// call a function whenever the cursor moves:
		document.onmousemove = function(evt){
			view.elementDrag(evt, view);
		}
	};
	
	this.constructor.prototype.elementDrag = function(evt, view){
		evt = evt || window.event;
		evt.preventDefault();
		
		// calculate the new cursor position:
		view._pos1 = view._pos3 - evt.clientX;
		view._pos2 = view._pos4 - evt.clientY;
		view._pos3 = evt.clientX;
		view._pos4 = evt.clientY;
		
		// set the element's new position:
		view._progressIndicatorLayout.context.element.style.top = (view._progressIndicatorLayout.context.element.offsetTop - view._pos2) + "px";
		view._progressIndicatorLayout.context.element.style.left = (view._progressIndicatorLayout.context.element.offsetLeft - view._pos1) + "px";
	};
	
	this.constructor.prototype.closeDragElement = function(){
		// Stop moving when mouse button is released
		document.onmouseup = null;
		document.onmousemove = null;
	};
	
	this.constructor.prototype.view = function () {
        try {
			this._proto._handleVisibility(this);
 		} catch (e) {
            bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
            if (e.stack) {
                bpmext.log.error("  Call stack: " + e.stack);
			}
        }
    };
		
	this.constructor.prototype.load = function(){
		this._progressIndicatorBodyLayout = this.ui.get("ProgressIndicatorBodyLayout");
		this._progressIndicatorLayout = this.ui.get("ProgressIndicatorLayout");
		this._showMoreLessLink = this.ui.get("ShowMoreLessLnk");
		this._headerText = this.ui.get("HeaderTxt");
		this._statusImageHeader = this.ui.get("StatusImageHeader");
		var progressIndicatorHeader = this.ui.get("ProgressIndicatorHeader");
		this._loadingImageHeader = progressIndicatorHeader.context.element.querySelector(".CS_Loading");
		this._showMoreLessLink.setText(messages.progress_ind_show_less);
		this._fileData = [];	

		bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONFILEREMOVED, "batchId", "fileName");
		bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONCLOSE);
		
		/*
		Don't allow dragging for now.
		var _this = this;
		progressIndicatorHeader.context.element.onmousedown = function(evt){
			_this.dragMouseDown(evt, _this);
		}
		*/
		domClass.add(this.context.element, "CS_ProgressIndicator");
	};
}