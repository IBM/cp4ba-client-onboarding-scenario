/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2020. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */
 
cs_InitThumbnail = function (utilities, bpmext, domClass, domStyle, domAttr, domConstruct, messages, string, cookie) {
	
	this._instance = {
		serverConfigurationName: "GRAPHQL_APP_RESOURCE"
	};

	if (!this.constructor.prototype._proto) {
		
		this.constructor.prototype._proto =
		{
			EVT_ONERROR: "eventON_ERROR",

			mimeTypeToCssClass: {
				"": "ftNoContent",
				"item": "ftNoContent",
				"application/afp": "ftAfp",
				"application/vnd.ibm.afplinedata": "ftAfp",
				"application/pdf": "ftPdf",
				"text/plain": "ftPlain",
				"application/rtf": "ftPlain",
				"application/x-rtf": "ftPlain",
				"text/richtext": "ftPlain",
				"application/dca-rft": "ftPlain",
				"text/html": "ftWeb",
				"text/htm": "ftWeb",
				"application/x-compress": "ftCompressed",
				"application/x-compressed": "ftCompressed",
				"application/x-zip-compressed": "ftCompressed",
				"application/x-zip": "ftCompressed",
				"application/zip": "ftCompressed",
				"multipart/x-zip": "ftCompressed",
				"application/x-rar-compressed": "ftCompressed",
				"application/x-gzip": "ftCompressed",
				"text/xml": "ftCode",
				"application/xml": "ftCode",
				"application/x-vnd.oasis.opendocument.presentation": "ftPresentation",
				"application/vnd.ms-powerpoint": "ftPresentation",
				"application/vnd.lotus-freelance": "ftPresentation",
				"application/vnd.oasis.opendocument.presentation": "ftPresentation",
				"application/vnd.oasis.opendocument.presentation-template": "ftPresentation",
				"application/vnd.openxmlformats-officedocument.presentationml.presentation": "ftPresentation",
				"application/vnd.openxmlformats-officedocument.presentationml.slideshow": "ftPresentation",
				"application/vnd.openxmlformats-officedocument.presentationml.template": "ftPresentation",
				"application/vnd.ms-powerpoint.addin.macroEnabled.12": "ftPresentation",
				"application/vnd.ms-powerpoint.presentation.macroEnabled.12": "ftPresentation",
				"application/vnd.ms-powerpoint.slideshow.macroEnabled.12": "ftPresentation",
				"application/vnd.ms-powerpoint.template.macroEnabled.12": "ftPresentation",
				"application/x-mspowerpoint": "ftPresentation",
				"application/vnd.ms-infopath": "ftInfoPath",
				"application/line": "ftData",
				"application/x-vnd.oasis.opendocument.spreadsheet": "ftData",
				"application/vnd.ms-excel": "ftData",
				"application/vnd.ms-excel.addin.macroEnabled.12": "ftData",
				"application/vnd.ms-excel.sheet.binary.macroEnabled.12": "ftData",
				"application/vnd.ms-excel.sheet.macroEnabled.12": "ftData",
				"application/vnd.ms-excel.template.macroEnabled.12": "ftData",
				"application/vnd.lotus-1-2-3": "ftData",
				"application/vnd.openxmlformats-officedocument.spreadsheetml.template": "ftData",
				"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "ftData",
				"application/vnd.oasis.opendocument.spreadsheet": "ftData",
				"application/vnd.oasis.opendocument.spreadsheet-template": "ftData",
				"application/x-msexcel": "ftData",
				"text/csv": "ftData",
				"application/csv": "ftData",
				"application/x-vnd.oasis.opendocument.text": "ftWordProcessing",
				"application/msword": "ftWordProcessing",
				"application/vnd.lotus-wordpro": "ftWordProcessing",
				"application/wordperfect5.1": "ftWordProcessing",
				"application/vnd.oasis.opendocument.text": "ftWordProcessing",
				"application/vnd.oasis.opendocument.text-template": "ftWordProcessing",
				"application/vnd.openxmlformats-officedocument.wordprocessingml.document": "ftWordProcessing",
				"application/vnd.openxmlformats-officedocument.wordprocessingml.template": "ftWordProcessing",
				"application/vnd.ms-word.template.macroEnabled.12": "ftWordProcessing",
				"application/vnd.ms-word.document.macroEnabled.12": "ftWordProcessing",
				"application/x-msword": "ftWordProcessing",
				"application/x-filenet-searchtemplate": "ftSearchTemplate",
				"application/x-searchtemplate": "ftSearchTemplate",
				"application/x-searchtemplate.automatic": "ftSearchStored",
				"application/x-filenet-search": "ftSearchStored",
				"application/x-unifiedsearchtemplate": "ftUnifiedSearch",
				"application/x-icn-documententrytemplate": "ftIcnDocumentEntryTemplate",
				"application/x-icn-folderentrytemplate": "ftIcnFolderEntryTemplate",
				"application/x-filenet-external": "ftExternalFile",
				"application/x-box-web-link": "ftExternalFile",
				"application/csbundled": "ftMail",
				"message/rfc822": "ftMail",
				"application/iccxit": "ftMail",
				"application/x-filenet-filetype-msg": "ftMail",
				"application/icccsn": "ftNotesMail",
				"application/vnd.ms-outlook": "ftOutlookMail",
				"application/x-box-note": "ftBoxNote",
				"application/vnd.google-apps.document": "ftGdoc",
				"application/vnd.google-apps.spreadsheet": "ftGsheet",
				"application/vnd.visio": "ftWordProcessing",
				"application/visio": "ftWordProcessing",
				"application/x-visio": "ftWordProcessing",
				"application/vnd.ms-project": "ftWordProcessing",
				"application/msproject": "ftWordProcessing",
				"application/x-project": "ftWordProcessing"
			},

			/**
			 * Helper function to retrieve the Object Store Name as defined in ACCE admin tool. 
			 */
			_getObjectStoreName: function(view) {
				var objectStoreName = view.context.options.objectStoreName.get("value");
				return objectStoreName;
			},

			_getVisibility: function(view) {
				var visibility = "DEFAULT";
				if (view.context.options._metadata.visibility) {
					visibility = view.context.options._metadata.visibility.get("value");
				}
				if (visibility == "DEFAULT") {
					visibility = view.context.getInheritedVisibility();
				}
				return visibility;
			},
			
			_setHeight: function(view) {
				var size = view.context.options.height.get("value") ? view.context.options.height.get("value") : null;
				try	{
					if (size != null && size != "")	{
						if (!isNaN(size)) {
							size += "px";
						}
//						view.context.element.style.height = size;
						view._instance.img.style.height = size;
					}
				} catch (e)	{
					bpmext.log.error("CS-Thumbnail._setHeight() error: " + e);
					if (e.stack) {
						bpmext.log.error("  Call stack: " + e.stack);
					}
				}
			},

			_setWidth: function(view) {
				var size = view.context.options.width.get("value") ? view.context.options.width.get("value") : null;
				try {
					if (size != null && size != "") {
						if (!isNaN(size)) {
							size += "px";
						}
//						view.context.element.style.width = size;
						view._instance.img.style.width = size;
					}
				} catch (e)	{
					bpmext.log.error("CS-Thumbnail._setWidth() error: " + e);
					if (e.stack) {
						bpmext.log.error("  Call stack: " + e.stack);
					}
				}
			},
			
			_handleVisibility: function(view) {
				var visibility = utilities.handleVisibility(view.context);		
//				if (visibility != "NONE") {
//				}
			},

			_callService: function(service, params) {
				// Create ecm token as a large random number
				var ecmToken = Math.floor(Math.random() * 10000000);
				console.log("CS-Thumbnail:_callService() : Ecm token: " + ecmToken);

				// Add the required token value to the service params
				params.ecmToken = ecmToken;
				service.execute(params);
			},
	
			_loadImage: function(view, contentItem) {
				console.log("CS-Thumbnail:_loadImage() : called");
				if (contentItem != null) {
					view._instance._mimeType = contentItem.mimeType;
					var retrievingThumbnail = false;
					// Get the thumbnails property, has id of thumbnail object we need to download the image bits from
					var cmThumbnails = contentItem.cmThumbnails;
					if (cmThumbnails && cmThumbnails.cmThumbnails) {
						cmThumbnails = cmThumbnails.cmThumbnails.items ? cmThumbnails.cmThumbnails.items : cmThumbnails.cmThumbnails;
						if (cmThumbnails.length > 0) {
							var thumbnailId = cmThumbnails[0].id;
							var params = {
								thumbnailId: thumbnailId,
								properties: ["name"],
								repository: this._getObjectStoreName(view),
								serverAppResource: view._instance.serverConfigurationName
							};
							view._instance.getThumbnailSvc = view.ui.get("GetThumbnailSvc");
							this._callService(view._instance.getThumbnailSvc, params);
							retrievingThumbnail = true;
						}
					} 
					
					if (!retrievingThumbnail) {
						// Display default icon based on mime type of original document
						this._displayDefaultMimeImage(view, contentItem.isFolder);
					}
				} else {
					// NA
				}
			},

			_displayDefaultMimeImage: function(view, isFolder) {
				// Todo: display default icon based on mime type of original document
				if (isFolder) {
					cssClass = "ftFolderLarge";
				} else {
					var mimeType = view._instance._mimeType;
					cssClass = this.mimeTypeToCssClass[mimeType];
					if (!cssClass) {
						if (mimeType == null || mimeType == "" || mimeType == "item") {
							cssClass = "ftNoContentLarge";
						} else if (mimeType.substr(0, "audio/".length) == "audio/") {
							cssClass = this.mimeTypeToCssClass["audio/*"] || "ftAudioLarge";
						} else if (mimeType.substr(0, "image/".length) == "image/") {
							cssClass = this.mimeTypeToCssClass["image/*"] || "ftGraphicLarge";
						} else if (mimeType.substr(0, "video/".length) == "video/") {
							cssClass = this.mimeTypeToCssClass["video/*"] || "ftVideoLarge";
						} else if (mimeType == "teamspace" || mimeType == "Teamspace") {
							cssClass = "ecmTeamspaceIcon";
						} else if (mimeType == "application/x-unifiedsearchtemplate") {
							cssClass = "ftUnifiedSearchLarge";
						} else if (mimeType == "application/x-icn-documententrytemplate") {
							cssClass = "ftIcnDocumentEntryTemplateLarge";
						} else if (mimeType == "application/x-icn-folderentrytemplate") {
							cssClass = "ftIcnFolderEntryTemplateLarge";
						} else {
							cssClass = "ftDefaultLarge";
						}
					} else {
						cssClass += "Large";  // need larger version of mime type image
					}
				}
			
				var iconImg = view._instance.img;
				domClass.remove(iconImg, "CS_Image");
				if (view._instance.lastCssClass) {
					domClass.remove(iconImg, view._instance.lastCssClass);
				}
				domClass.add(iconImg, cssClass);
				view._instance.lastCssClass = cssClass;

				var	srcBlank = com_ibm_bpm_coach.getManagedAssetUrl('CS-blank.gif', com_ibm_bpm_coach.assetType_WEB, 'SYSCST', false);
				domAttr.set(iconImg, "src", srcBlank);

				if (mimeType == null || mimeType == "" ) {
					if (isFolder) {
						domAttr.set(iconImg, "title", messages.contlist_folder_mimetype); 
						domAttr.set(iconImg, "alt", messages.contlist_folder_mimetype);
					} else {
						domAttr.set(iconImg, "title", messages.contlist_no_mimetype);
						domAttr.set(iconImg, "alt", messages.contlist_no_mimetype);
					}
				} else {
					domAttr.set(iconImg, "title", mimeType);
					domAttr.set(iconImg, "alt", mimeType);
				}
			},
			
			_displayNoItemSelected: function(view) {
				var iconImg = view._instance.img;
				domClass.remove(iconImg, "CS_Image");
				if (view._instance.lastCssClass) {
					domClass.remove(iconImg, view._instance.lastCssClass);
				}
				// Need to also set the src url to blank
				var	srcBlank = com_ibm_bpm_coach.getManagedAssetUrl('CS-blank.gif', com_ibm_bpm_coach.assetType_WEB, 'SYSCST', false);
				domAttr.set(iconImg, "src", srcBlank);
				
				domAttr.set(iconImg, "title", "");
				domAttr.set(iconImg, "alt", "");
			},
			
			_onLoadThumbnailResult: function(view, results) {
				console.log("CS-Thumbnail:_onLoadThumbnailResult() : called");
				var thumbnails = results.items ? results.items : results;
				var thumbnail = thumbnails[0]; 
				if (thumbnail.image) {
					var iconImg = view._instance.img;
					if (view._instance.lastCssClass) {
						domClass.remove(iconImg, view._instance.lastCssClass);
					}
					domClass.add(iconImg, "CS_Image");

					// Lop off the first two charaters "0x", the image format is hex
					var temp  = thumbnail.image.toString();
					temp = temp.substr(2);
					// Convert the image to base64 encoding
					iconImg.src = "data:" + thumbnail.mimeType + ";base64," + this.hexToBase64(temp);

					iconImg.alt = thumbnail.mimeType;
					iconImg.title = thumbnail.mimeType;
				} else {
					// If no thumbnail, display default image based on mimetype
					this._displayDefaultMimeImage(view, false);
				}
			},

			/**
			 * Graphql api returns image in Hex format, need to convert it into base64 for img element
			 */
			hexToBase64: function(str) {
				return btoa(String.fromCharCode.apply(null, str.replace(/\r|\n/g, "").replace(/([\da-fA-F]{2}) ?/g, "0x$1 ").replace(/ +$/, "").split(" ")));
			}

		};

		/**
		 * Public control methods *************************************************************
		 */

		/**
		 * @instance
		 * @memberof CS-Thumbnail
		 * @method getType
		 * @desc Returns the descriptive string that represents the control type.
		 * @returns {string}
		 */
		this.constructor.prototype.getType = function() {
			return "thumbnail.1";
		}

		/*
		 * Private methods and event handlers *************************************************************
		 */

		this.constructor.prototype._parseError = function(error) {
			if (error.errorText) {
			  if (error.errorText.indexOf("CWTBI0006E") != -1) {
				  var message = string.substitute(messages.contlist_invalid_server_error, [this._instance.serverConfigurationName]);
				  return message;
			  }
			}
			return null;
		};

		this.constructor.prototype._onGetThumbnailResult = function() {
			var view = this;
			console.log("CS-Thumbnail:_onGetThumbnailResult() : called");

			// Check that there are results that came back from the service call
			var resultSet = view._instance.getThumbnailSvc && view._instance.getThumbnailSvc.getResult();
			if (resultSet && resultSet.results) {
				view._proto._onLoadThumbnailResult(view, resultSet.results); 
			}
		};

		this.constructor.prototype._onGetThumbnailError = function() {
			var view = this;
			var error = view._instance.getThumbnailSvc && view._instance.getThumbnailSvc.getLastError();
			if (error) {
				view._instance.error = error;

        		var message = this._parseError(error);
        		if (message == null) {
          			message = messages.thumbnail_retreival_error;        
        		}
				console.log("CS-Thumbnail:_onGetThumbnailError() : " + message);

				setTimeout(function() {
					bpmext.ui.executeEventHandlingFunction(view, view._proto.EVT_ONERROR, message);
				});
			}
			view._instance.refreshing = false;
		};

		/**
		 * Coach NG Lifecycle methods *************************************************************
		 */

		this.constructor.prototype.load = function() {
			try {
				var options = this.context.options;

				if (!this.context.binding) {
					this.context.binding = bpmext.ui.substituteObject(this);
				}

				if (!options.height) {
					options.height = bpmext.ui.substituteConfigOption(this, "height", null);
				}
				if (!options.width) {
					options.width = bpmext.ui.substituteConfigOption(this, "width", null);
				}
				
				if (!options.objectStoreName) {
                    options.objectStoreName = bpmext.ui.substituteConfigOption(this, "objectStoreName", null);
				}
				
				this._instance.envelope = document.createElement("div");
				domClass.add(this._instance.envelope, "CS_ImageDiv");
				this._instance.img = document.createElement("img");

				this._proto._setHeight(this);
				this._proto._setWidth(this);

				this._instance.envelope.appendChild(this._instance.img);
				this.context.element.appendChild(this._instance.envelope);

				domClass.add(this.context.element, "CS_Thumbnail");

				bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONERROR, "message");

				bpmext.ui.loadView(this);

				this._proto._loadImage(this, null);
				
			} catch (e) {
				if (this.ui && this.ui.getAbsoluteName) {
					bpmext.log.error("Error on load event [" + this.ui.getAbsoluteName() + "]: " + e);
				} else {
					bpmext.log.error("Error on load event: " + e);
				}
			}
		};

		this.constructor.prototype.view = function() {
			try {
				this._proto._handleVisibility(this);
				// Check for a bound object use it to re-render the properties UX with
				if (this.context.binding) {
					var boundProperty = this.context.binding.property;
					if (boundProperty != null) {
						var contentItem = this.context.binding.boundObject[boundProperty];
						if (contentItem.id != null && contentItem.id != "") {
							console.log("CS-Thumbnail:view() : View update for: " + contentItem.name);
							this._proto._loadImage(this, contentItem);
						} else {
							console.log("CS-Thumbnail:view() : No bound object to view.");
						}
					}
				}
			} catch(e) {
				bpmext.log.error("Error on view event [" + this.ui.getAbsoluteName() + "]: " + e);
			}
		};

		this.constructor.prototype.change = function (event) {
			try {
				var view = this;
				if (event.type == "config") {
					switch (event.property) {
						case "width": {
							this._proto._setWidth(this, event.newVal);
							break;
						}
						case "height": {
							this._proto._setHeight(this, event.newVal);
							break;
						}
					}
				} else { 
					if (this.context.binding && event.newVal && event.newVal.id) {
						var boundObject = this.context.binding.boundObject;
						if (boundObject != null) {
							var contentItem = event.newVal;
							console.log("CS-Thumbnail:change() : Change update for bound object: " + contentItem.name);

							this._proto._loadImage(view, contentItem);
						}
					} else {
						this._proto._displayNoItemSelected(view);
					}
				}
			} catch (e) {
				bpmext.log.error("Error on change event [" + this.ui.getAbsoluteName() + "]: " + e);
				if (e.stack) {
					bpmext.log.error("  Call stack: " + e.stack);
				}
			}
		};

		this.constructor.prototype.unload = function() {
			bpmext.ui.unloadView(this);
		};
	}
}
