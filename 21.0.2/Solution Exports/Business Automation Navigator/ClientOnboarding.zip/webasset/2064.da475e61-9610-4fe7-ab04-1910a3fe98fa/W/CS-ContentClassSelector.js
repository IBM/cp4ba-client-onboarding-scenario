/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019 - 2020. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

cs_InitContentClassSelector = function(bpmext, domClass, domAttr, domStyle, messages, cookie) {
	
	this.constructor.prototype._serverConfigurationName = "GRAPHQL_APP_RESOURCE";	
	this.constructor.prototype._objectStoreName = "";
	this.constructor.prototype._documentClasses = "";
	this.constructor.prototype._folderClasses = "";
	this.constructor.prototype._callback = null;
	this.constructor.prototype._errback = null;
	
	if (!this.constructor.prototype._proto)	{
		this.constructor.prototype._proto = {
			EVT_ONCLASSSELECTED: "onClassSelected",
			EVT_ONSVCERROR: "onServiceError"
		}
	}
	
	this.constructor.prototype.view = function (){
		bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONCLASSSELECTED, "classId");
		bpmext.ui.registerEventHandlingFunction(this, this._proto.EVT_ONSVCERROR, "errors");
		var classSelectorDropdown = this.context.element.querySelector(".CS_ContentClassSelect");
		var _this = this;
		classSelectorDropdown.onchange = function(evt) {
			bpmext.ui.executeEventHandlingFunction(_this, _this._proto.EVT_ONCLASSSELECTED, _this.getSelectedItem());
		}
	}
	
	this.constructor.prototype.clearItems = function (){
		var classSelectorDropdown = this.context.element.querySelector(".CS_ContentClassSelect");
		for(var i = classSelectorDropdown.options.length - 1; i >= 0; i--) {
			classSelectorDropdown.remove(i);
		}
	}
	
	this.constructor.prototype.setSelectedItem = function (selectedItem){
		var classSelectorDropdown = this.context.element.querySelector(".CS_ContentClassSelect");
		for (var i = 0; i < classSelectorDropdown.options.length; i++) {
			var option = classSelectorDropdown.options[i];
			if (option.value == selectedItem){
				option.selected = true;
				break;
			}
		}
	}
	
	this.constructor.prototype.getSelectedItem = function (){
		var classSelectorDropdown = this.context.element.querySelector(".CS_ContentClassSelect");
		return classSelectorDropdown.options[classSelectorDropdown.selectedIndex].value;
	}
	
	this.constructor.prototype.setEnabled = function (enabled){
		this.context.element.querySelector(".CS_ContentClassSelect").disabled = !enabled;
		enabled ? domClass.remove(this.context.element, "CS_PropertyDisabled") : domClass.add(this.context.element, "CS_PropertyDisabled");
	}
	
	this.constructor.prototype.isEnabled = function (){
		return !this.context.element.querySelector(".CS_ContentClassSelect").disabled;
	}
	
	this.constructor.prototype.appendItem = function (value, label){
		var classSelectorDropdown = this.context.element.querySelector(".CS_ContentClassSelect");
		classSelectorDropdown.add(new Option(label, value));
	}
	
	this.constructor.prototype.setServerConfigurationName = function (serverConfigurationName){
		this._serverConfigurationName = serverConfigurationName;
	}
	
	this.constructor.prototype.getServerConfigurationName = function (){
		return this._serverConfigurationName;
	}
	
	this.constructor.prototype.setObjectStoreName = function(objectStoreName) {
		this._objectStoreName = objectStoreName;
	}
	
	this.constructor.prototype.getObjectStoreName = function() {
		return this._objectStoreName;
	}
	
	this.constructor.prototype.focus = function(){
		var classSelectorDropdown = this.context.element.querySelector(".CS_ContentClassSelect");
		classSelectorDropdown.focus();
	}
	
	this.constructor.prototype._callService = function(service, params) {
		// Create ecm token as a large random number
		var ecmToken = Math.floor(Math.random() * 10000000);
		console.log("CS-ContentClassSelector:_callService() : Ecm token: " + ecmToken);

		// Add the required token value to the service params
		params.ecmToken = ecmToken;
		service.execute(params);
	}

	/**
	 * A list of document classes to be displayed in the control. When set, the server is not called
	 * and these classes are displayed. 
	 *	@param documentClassesIn: An array of  name value pairs where the name of each class is displayed to the user, the value
	 *		corresponds to the symbolic name of the document class.
	 */
	this.constructor.prototype.setDocumentClasses = function(documentClassesIn){
		this._documentClasses = [];
		if (documentClassesIn){
			var documentClasses = documentClassesIn && documentClassesIn.items ? documentClassesIn.items : documentClassesIn;
			var _this = this;
			documentClasses.forEach(function(documentClass){
				if (documentClass.name.length > 0 && documentClass.value.length > 0){
					_this._documentClasses.push(documentClass);
				}
			});
		}
	}
	
	this.constructor.prototype.getDocumentClasses = function (){
		return this._documentClasses;
	}
	
	/**
	 * A list of folder classes to be displayed in the control. When set, the server is not called
	 * and these classes are displayed. 
	 *	@param folderClassesIn: An array of  name value pairs where the name of each class is displayed to the user, the value
	 *		corresponds to the symbolic name of the folder class.
	 */
	this.constructor.prototype.setFolderClasses = function(folderClassesIn){
		this._folderClasses = [];
		if (folderClassesIn){
			var folderClasses = folderClassesIn && folderClassesIn.items ? folderClassesIn.items : folderClassesIn;
			var _this = this;
			folderClasses.forEach(function(folderClass){
				if (folderClass.name.length > 0 && folderClass.value.length > 0){
					_this._folderClasses.push(folderClass);
				}
			});
		}
	}
		
	this.constructor.prototype.getFolderClasses = function (){
		return this._folderClasses;
	}
	
	/**
	 *  Retrieves classes from the server and displays them in the controllers
	 *	@param type: The root level class, either "Folder" or "Document".
	 *	@param callback: A function that is called when the update completes successfully.
	 *	@param errback: A function that is called when the update fails due to an error.
	 */
	this.constructor.prototype.displayContentClasses = function (type, callback, errback){
		this._callback = null;
		this._errback = null;
		var configClasses = type == "Document" ? this._documentClasses : this._folderClasses;
		var classes = configClasses && configClasses.items ? configClasses.items : configClasses;
		if (classes && classes.length > 0){
			this.clearItems();				
			var sortedClasses = classes.sort(function(a, b){
				var result = 0;
				if (a.name > b.name) {
					result = 1;
				}
				else if (a.name < b.name) {
					result = -1;
				}
				return result;
			});
			var _this = this;
			sortedClasses.forEach(function(classItem){
				_this.appendItem(classItem.value, classItem.name);
			});
			bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONCLASSSELECTED, this.getSelectedItem());
			if (callback){
				callback(this.getSelectedItem())
			}
		} else {
			if (callback != null){
				this._callback = callback;
			}
			if (errback != null){
				this._errback = errback;
			}
			
			var params = {
				topLevelClass: type,
				repository: this._objectStoreName,
				serverAppResource: this._serverConfigurationName
			};
			
			var getContentClassesSvc = this.ui.get("GetContentClassesSvc");
			this._callService(getContentClassesSvc, params);
		}
	}
	
	this.constructor.prototype._onGetClassesResult = function(view, response){
		var classSelectorDropdown = this.context.element.querySelector(".CS_ContentClassSelect");
		this.clearItems();
		
		var topClassDescription = response.topClassDescription;
		topClassDescription.subClassDescriptions = [];
		var classLookup = {};
		classLookup[topClassDescription.symbolicName] = topClassDescription;

		var subClassDescriptions = response.subClassDescriptions.items ? response.subClassDescriptions.items : response.subClassDescriptions;		
		for (var i = 0; i < subClassDescriptions.length; i++){
			var subClassDescription = subClassDescriptions[i];
			if (classLookup[subClassDescription.symbolicName]){
				var subClassLookup = classLookup[subClassDescription.symbolicName];
				subClassLookup.symbolicName = subClassDescription.symbolicName;
				subClassLookup.displayName = subClassDescription.displayName;
				subClassLookup.isHidden = subClassDescription.isHidden;
				subClassLookup.allowsInstances = subClassDescription.allowsInstances;
				subClassLookup.superClassDescription = {
					symbolicName: subClassDescription.superClassDescription.symbolicName
				}
			} else {
				subClassDescription.subClassDescriptions = [];
				classLookup[subClassDescription.symbolicName] = subClassDescription;
			}
			
			if (classLookup[subClassDescription.superClassDescription.symbolicName]){
				classLookup[subClassDescription.superClassDescription.symbolicName].subClassDescriptions.push(classLookup[subClassDescription.symbolicName]);
			} else {
				classLookup[subClassDescription.superClassDescription.symbolicName] = {
					subClassDescriptions: [classLookup[subClassDescription.symbolicName]]
				}				
			}			
		}
				
		var classOptions = [];
		var option = new Option(topClassDescription.displayName, topClassDescription.symbolicName);
		option.disabled = false;
		option.selected = false;
		domAttr.set(option, "role", "option");
		domClass.add(option, "CS_ContentClassOption");
		classOptions.push(option);
		this._addSubClasses(classOptions, topClassDescription.subClassDescriptions, 1);
		for (var i = 0; i < classOptions.length; i++) {
			classSelectorDropdown.add(classOptions[i]);
		}
		bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONCLASSSELECTED, this.getSelectedItem());
		if (this._callback){
			this._callback(this.getSelectedItem());
		}
			
		this._callback = null;
		this._errback = null;
	}
	
	this.constructor.prototype._addSubClasses = function(classOptions, subClasses, level) {
		var spaces = Array(4 * level).join("\u00a0");
		var _this = this;
		var subClassInstances = subClasses.items ? subClasses.items : subClasses;
		subClassInstances.sort(this._sortSubClasses);
		subClassInstances.forEach(function(subClass){
			if (!subClass.isHidden){
				var option = new Option(spaces + subClass.displayName, subClass.symbolicName);
				option.disabled = !subClass.allowsInstances
				domAttr.set(option, "role", "option");
				domClass.add(option, "CS_ContentClassOption");
				classOptions.push(option);
				_this._addSubClasses(classOptions, subClass.subClassDescriptions, level + 1);
			}
		});
	}
	
	this.constructor.prototype._sortSubClasses = function(subClass1, subClass2){
		return (subClass1.displayName).localeCompare(subClass2.displayName);
	}
	
	this.constructor.prototype._onGetClassesError = function(view, response){
		errorMessage = "The content classes could not be displayed."
		bpmext.ui.executeEventHandlingFunction(this, this._proto.EVT_ONSVCERROR, errorMessage);
		if (this._errback){
			this._errback(errorMessage);
		}
			
		this._callbacks = null;
		this._errbacks = null;
	}
	
	this.constructor.prototype.load = function(){
		var classSelectorDropdown = this.context.element.querySelector(".CS_ContentClassSelect");
		domAttr.set(classSelectorDropdown, "aria-label", messages.class_selector_class);
		
		var options = this.context.options;
		if (!options.documentClasses) {
			options.documentClasses = bpmext.ui.substituteConfigOption(this, "documentClasses", null);
		}
		this.setDocumentClasses(this.context.options.documentClasses.get("value"));
		
		if (!options.folderClasses) {
			options.folderClasses = bpmext.ui.substituteConfigOption(this, "folderClasses", null);
		}
		this.setFolderClasses(options.folderClasses.get("value"));
				
		if (!options.objectStoreName) {
            options.objectStoreName = bpmext.ui.substituteConfigOption(this, "objectStoreName", null);
		}
		this.setObjectStoreName(options.objectStoreName.get("value"));
	}
}