/*
 * #BEGIN COPYRIGHT
 *
 * Licensed Materials - Property of IBM
 * 5737-I23
 * Copyright IBM Corp. 2019 - 2020. All Rights Reserved.
 * U.S. Government Users Restricted Rights:
 * Use, duplication or disclosure restricted by GSA ADP Schedule
 * Contract with IBM Corp.
 *
 * #END COPYRIGHT
 */

cs_InitMultiValuePropertyStackContainer = function(bpmext, domClass, domAttr, domStyle, string, messages){
	
	_dataType = "";
	_choices = null;
	_disabled = false;
	_maxLength = null;
	_minValue = null;
	_maxValue = null;
	_uniqueValues = null;
	_includeTimePicker = null;
	_id = "";
	_deleteOffset = 0;
	_displayOnly = false;
	propertyName = "";
	_loading = false;
	
	if (!this.constructor.prototype._proto)
	{
		this.constructor.prototype._proto = {
			
			stackPanes: {
				STRING: 0,
				LONG_STRING: 1,
				DROPDOWN: 2,
				DATE: 3,
			},
						
			_showTab: function(view, setFocus, initializePanes){
				view._loading = true;
				var parent = view.ui.getParent(true);
				
				// Show the appropriate tab depending on the dataType.
				var binding;
				if (!view.context.binding){
					if (parent.context.binding){
						var parentBinding = parent.context.binding.get("value");
						var index = view.ui.getIndex();
						binding = parentBinding.get(index - view._deleteOffset);
					}
				}
				if (binding != null){
					var stack = view.ui.getChild("MultiValuePropertyStack");
					var pane = -1;
					var currentView; 
					if (view._choices && !view._displayOnly){
						pane = initializePanes ? this.stackPanes.DROPDOWN : 0;
						currentView = stack.getViewInPane(pane);
						currentView.clearItems();
						view._choices.forEach(function(choiceItem){
							var choiceValue = choiceItem.choiceStringValue ? choiceItem.choiceStringValue : choiceItem.choiceIntegerValue;
							currentView.appendItem(choiceValue, choiceItem.displayName);
						});
						currentView.setSelectedItem(binding);
					}
					else if (view._displayOnly ||
						view._dataType == "STRING" ||
						view._dataType == "GUID" ||
						view._dataType == "LONG" ||
						view._dataType == "DOUBLE"){

						if (!initializePanes){
							pane = 0;
						}
						else if (view._dataType == "DATE"){
							pane = this.stackPanes.DATE;
						}
						else if (view._maxLength > 255){
							pane = this.stackPanes.LONG_STRING;
						}
						else{
							pane = this.stackPanes.STRING;
						}
						currentView = stack.getViewInPane(pane);
						if (binding != null){
							if (view._dataType == "DATE"){
								currentView.context.options.includeTimePicker.set("value", view._includeTimePicker);	
								currentView.setDate(binding);
							}
							else if (view._choices){
								var displayName;
								for (var i = 0; i < view._choices.length; i++){
									var choice = view._choices[i];
									if ((view._dataType == "STRING" && choice.choiceStringValue == binding) ||
										(view._dataType == "LONG" && choice.choiceIntegerValue == binding)){
										
										displayName = choice.displayName;
										break;
									}
								}
								if (displayName){
									currentView.setText(displayName);
								}
							}
							else {
								currentView.setText(binding.toString());
							}							
						}
					}
					else if (view._dataType == "BOOLEAN"){
						pane = initializePanes ? this.stackPanes.DROPDOWN : 0;
						currentView = stack.getViewInPane(pane);
						if (currentView.getItemCount() == 0){
							currentView.appendItem("true", "True");
							currentView.appendItem("false", "False");
						}
						currentView.setSelectedItem(binding.toString());
					}
					else if (view._dataType == "DATE"){
						pane = initializePanes ? this.stackPanes.DATE : 0;
						currentView = stack.getViewInPane(pane);			

						currentView.context.options.includeTimePicker.set("value", view._includeTimePicker);
								
						if (view._minValue){
							var minDate = new Date(view._minValue);
							currentView.setStart(minDate);
						}
						if (view._maxValue){
							var maxDate = new Date(view._maxValue);
							currentView.setEnd(maxDate);
						}
						if (currentView.setDate  && binding.getTime){
							currentView.setDate(binding);
						}
					}

					var parentElement = view.context.element.parentElement;
					domClass.add(parentElement, "CS_MultiValuePropertyStackContentBox");
					if (view._disabled || view._displayOnly){
						stack.context.options._metadata.visibility.set("value", "READONLY");
					}
					else{
						stack.context.options._metadata.visibility.set("value", "DEFAULT");
					}
					if (currentView){
						currentView.setLabel(view._propertyName);
						if (pane > -1 && !view._disabled && !view._displayOnly){
							this._createDeleteButton(view);
						}
					}
					stack.setCurrentPane(pane);
					if (initializePanes){				
						var paneCount = stack.getPaneCount();
						for (var i = paneCount - 1; i >= 0; i--){
							if (i != pane){
								var viewInPane = stack.getViewInPane(i);
								var viewDiv = viewInPane.context.element;
								stack.context.deleteView(viewDiv);
								viewDiv.parentNode.removeChild(viewDiv);
							}
						}
					}
					
					if (setFocus){
						setTimeout(function(){
							currentView.focus();
						}, 300);
					}
				}
				view._loading = false;				
			},
			
			_createDeleteButton: function(view){
				var delButton = document.createElement("div");	
				domClass.add(delButton, "CS_PropertyListIconButton");
				domAttr.set(delButton, "tabindex", "0");
				
				var icon = document.createElement("i");
				domClass.add(icon, "fa fa-minus CS_MVCPIconButton");
				domAttr.set(icon, "alt", "Remove");
				delButton.href = "javascript:void(0)";
				domClass.add(delButton, "CS_MultiValueDeleteButton");
				delButton.appendChild(icon);
				domAttr.set(delButton, "title", string.substitute(messages.properties_remove_mvcp, [view._propertyName]));
				
				domStyle.set(view.context.element, "position", "relative");
				view.context.element.appendChild(delButton);
				
				var _removeItem = function(){
					var newList = [];
					var layout = view.ui.getAncestor("MultiValueLayout", true);				
					var bindingList = layout.context.binding.get("value");
					
					// Recreating the list causes the index of the new ones to start where the old ones ended.
					layout._multiValueData.deleteOffset += bindingList.items.length;
					if (bindingList && bindingList.items){
						for (var i = 0; i < bindingList.items.length; i++){
							var stackContainer = layout.ui.getChild("CSMultiValuePropertyStackContainer", i);
							var containerStackId = domAttr.get(stackContainer.context.element, "id");
							if (view.context.element.id != containerStackId){
								newList.push(stackContainer.getRawPropertyValue());
							}
						}
					}
					layout.context.binding.set("value", newList);
				}
				
				delButton.onclick = function() {
					_removeItem();
				};
				
				delButton.addEventListener('keypress', function(evt) {
					var keyID = (evt.charCode) ? evt.charCode : ((evt.which) ? evt.which : evt.keyCode);
					if(keyID == 13 || keyID == 32){
						if(!domClass.contains(this, "disabled"))
						{
							_removeItem();
						}
						evt.preventDefault();
					}
					return true;
				});
			},
			
			_getRawPropertyValue: function (view){
				var value;
				var stack = view.ui.getChild("MultiValuePropertyStack");
				
				var pane = stack.getCurrentPane();				
				if (pane != null){
					var currentView = stack.getViewInPane(0);
					if (currentView.getText){
						value = currentView.getText();
					} else if (currentView.getDate){
						value = currentView.getDate();
					} else if (currentView.getSelectedItem){
						value = currentView.getSelectedItem();
						if (view._dataType == "BOOLEAN"){
							value = (value === "true")
						}
					} else if (currentView.getValue){
						value = currentView.getValue();
					}
				}
				return value;
			},
			
			_getPropertyValue: function(view){
				var propertyValue;
				var stack = view.ui.getChild("MultiValuePropertyStack");							
				var pane = stack.getCurrentPane();				
				if (pane != null){
					var currentView = stack.getViewInPane(0);
					if (currentView.getText){
						var value = currentView.getText();
						if (value.length < 1){
							propertyValue = null;
						}
						else if (view._dataType == "STRING" || view._dataType == "GUID"){
							var sanitizedValue = value.replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/\t/g,'\\t').replace(/'/g,"\\'").replace(/"/g,'\\"').replace(/\r/g,'\\r');
							propertyValue = "\"" + sanitizedValue + "\"";
						}
						else {
							propertyValue = value;
						}
					}
					else if (currentView.getDate){
						var dateValue = currentView.getDate();
						propertyValue = "\"" + dateValue.toISOString() + "\"";
					}
					else if (currentView.getSelectedItem){
						var value = currentView.getSelectedItem();
						if (view._dataType == "STRING"){
							propertyValue = "\"" + value + "\"";
						}
						else {
							propertyValue = value;
						}				
					}
					else{
						propertyValue = currentView.getValue();
					}
				}
				return propertyValue;
			},
			
			_validate: function(view){
				var isValid = true;
				var stack = view.ui.getChild("MultiValuePropertyStack");
				var currentPane = stack.getCurrentPane();
				if (currentPane != null){
					var currentView = stack.getViewInPane(0);
					isValid = currentView.isValid ? currentView.isValid() : true;
					if (!isValid){
						currentView.context.element.scrollIntoView(true);
					}
				}

				return isValid;
			}
		};
		
		this.constructor.prototype.onPropertyValueChange = function (newValue){
			if (!this._loading){
				var errorDiv = this.context.element.querySelector(".CS_ValidationMessage");
				var stack = this.ui.getChild("MultiValuePropertyStack");
				var currentPane = stack.getCurrentPane();
				if (currentPane != null && currentPane > -1){			
					currentView = stack.getViewInPane(0);
					var validationData = {
						id: this._id,
						value: newValue,
						minValue: this._minValue,
						maxValue: this._maxValue,
						maxLength: this._maxLength,
						dataType: this._dataType,
						required: false,
						view: currentView,
						errorDiv: errorDiv
					}
					var propertyStackContainer = this.ui.getAncestor("PropertyStackContainer");
					propertyStackContainer._proto._validateValue(this, validationData);
					var stackLayout = this.ui.getAncestor("StackLayout", true);
					var propertyList = stackLayout.ui.getParent();
					propertyList._propertyChanged();
				}
			}
		};
		
		this.constructor.prototype.getPropertyValue = function(){
			return this._proto._getPropertyValue(this); 
		};
		
		this.constructor.prototype.getRawPropertyValue = function(){
			return this._proto._getRawPropertyValue(this); 
		};
		
		this.constructor.prototype.change = function (event){
			if (!(event.type == "config" && event.property == "_metadata.visibility" && event.newVal == "HIDDEN")){
				this._proto._showTab(this, false, false);
			}
		};
		
		this.constructor.prototype.load = function (){
			var parent = this.ui.getParent(true);
			this._dataType = parent._multiValueData.dataType;
			this._choices = parent._multiValueData.choices;
			this._disabled = parent._multiValueData.disabled;
			this._maxLength = parent._multiValueData.maxLength;
			this._minValue = parent._multiValueData.minValue;
			this._maxValue = parent._multiValueData.maxValue;
			this._uniqueValues = parent._multiValueData.uniqueValues;
			this._includeTimePicker = parent._multiValueData.includeTimePicker;
			this._id = parent._multiValueData.id;
			this._deleteOffset = parent._multiValueData.deleteOffset;
			this._displayOnly = parent._multiValueData.displayOnly;
			this._propertyName = parent._multiValueData.propertyName;
			this._proto._showTab(this, false, true);
		}
		
		this.constructor.prototype.isValid = function(){
			return this._proto._validate(this);
		};
	}			
}